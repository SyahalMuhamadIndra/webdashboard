# Simaung Corporation Platform

Private team monorepo for the Simaung business platform. The application source is organized under `production-work/KARTINI-B36/`:

- `absensi-full/` — attendance backend and web clients, POS clients, admin, and download pages
- `jurnal-web/` — journal and accounting web application
- `opname-web/` — inventory opname application
- `report-web/` — owner and multi-business reporting application

## Local development

Each app has its own README, package manifest, or build instructions. Install dependencies inside the app folder you are working on. Do not commit production credentials, signing keys, APKs/installers, generated build folders, database exports, or `.vercel` project metadata. Store secrets in the appropriate deployment environment and share access through GitHub repository permissions.

## Collaboration

Create a feature branch for changes, open a pull request, and request review before merging to the default branch. Keep deployment credentials in Vercel/Neon or the relevant provider, never in this repository.
