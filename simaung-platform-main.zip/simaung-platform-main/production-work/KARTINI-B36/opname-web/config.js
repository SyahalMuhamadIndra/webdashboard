// Konfigurasi alamat API — SATU backend untuk semua aplikasi Simaung Corporation.
window.__API_BASE__ = 'https://api.tokokartini.com/api/';
