/* =====================================================================
   SIMAUNG CORPORATION — STOCK OPNAME (Karyawan: Pramuniaga & Kepala Gudang)
   Design System v2 · responsif Desktop / Tablet / HP
   ---------------------------------------------------------------------
   • Login memakai AKUN ABSENSI yang sama (POST /api/auth/login).
   • Satu backend: https://api.tokokartini.com  (lihat config.js).
   • Warna selaras project (hijau #0B6B2E + oranye #F26A1B).
   ===================================================================== */
(function () {
  'use strict';

  var API = ((window.__API_BASE__ || 'https://api.tokokartini.com/api/').replace(/\/+$/, '')) + '/';
  var LS = { token: 'tk_opname_token', user: 'tk_opname_user', device: 'tk_opname_device' };
  var ALLOWED = ['PRAMUNIAGA', 'KEPALA_GUDANG', 'KASIR'];

  var S = {
    token: localStorage.getItem(LS.token) || null,
    user: safeParse(localStorage.getItem(LS.user)) || null,
    me: null,
    deviceId: localStorage.getItem(LS.device) || '',
    products: [],
    loaded: false,
    draft: {},
    nav: 'opname',
    area: '', note: '',
    query: '', filter: '__all__',
    current: null,
    scanStream: null, scanStop: null,
  };

  function safeParse(s) { try { return JSON.parse(s); } catch (e) { return null; } }
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); }
  function fmt(n) { var v = Number(n) || 0; return v.toLocaleString('id-ID'); }
  function initials(name) { var p = String(name || 'K').trim().split(/\s+/); return ((p[0] || 'K')[0] + (p[1] ? p[1][0] : '')).toUpperCase(); }
  function todayISO() { var d = new Date(); var tz = d.getTimezoneOffset() * 60000; return new Date(d.getTime() - tz).toISOString().slice(0, 10); }
  function isDesktop() { return window.matchMedia && window.matchMedia('(min-width:1100px)').matches; }

  function deviceIdOf() {
    if (!S.deviceId) {
      S.deviceId = 'OPN-' + Math.random().toString(36).slice(2, 8).toUpperCase() + '-' + Date.now().toString(36).toUpperCase();
      localStorage.setItem(LS.device, S.deviceId);
    }
    return S.deviceId;
  }

  /* ---------------- API CLIENT ---------------- */
  function api(path, opts) {
    opts = opts || {};
    var headers = { 'Content-Type': 'application/json' };
    if (opts.auth !== false && S.token) headers['Authorization'] = 'Bearer ' + S.token;
    return fetch(API + String(path).replace(/^\/+/, ''), {
      method: opts.method || 'GET', headers: headers,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (res.status === 401) { if (opts.auth !== false) logout(true); throw new Error(data.message || 'Sesi berakhir, silakan masuk kembali.'); }
        if (!res.ok) throw new Error(data.message || ('Gagal (' + res.status + ')'));
        return data;
      });
    });
  }

  /* ---------------- TOAST / SHEETS ---------------- */
  function toast(msg, kind) {
    var w = $('toast'); var el = document.createElement('div');
    el.className = 'toast ' + (kind || ''); el.textContent = msg; w.appendChild(el);
    setTimeout(function () { el.style.transition = 'opacity .25s'; el.style.opacity = '0'; setTimeout(function () { el.remove(); }, 250); }, 2700);
  }
  function openSheet(id) { $(id).classList.add('show'); }
  window.closeSheet = function (id) { if (id === 'sheet-scan') stopScan(); $(id).classList.remove('show'); };
  function firstOpenSheet() {
    var ids = ['sheet-item', 'sheet-draft', 'sheet-review', 'sheet-scan'];
    for (var i = 0; i < ids.length; i++) if ($(ids[i]).classList.contains('show')) return ids[i];
    return null;
  }

  /* =====================================================================
     LOGIN
     ===================================================================== */
  function showLogin() { $('auth').classList.remove('hidden'); $('app').classList.add('hidden'); $('lg-btn').disabled = false; $('lg-msg').textContent = ''; try { $('lg-code').focus(); } catch (e) {} }
  function showApp() { $('auth').classList.add('hidden'); $('app').classList.remove('hidden'); }

  window.doLogin = function (e) {
    if (e && e.preventDefault) e.preventDefault();
    var code = ($('lg-code').value || '').trim(); var pass = $('lg-pass').value || '';
    if (!code || !pass) { $('lg-msg').textContent = 'Kode karyawan dan password wajib diisi.'; return; }
    var btn = $('lg-btn'); btn.disabled = true; $('lg-msg').textContent = 'Menghubungkan…';
    api('auth/login', { method: 'POST', auth: false, body: { employeeCode: code, password: pass, deviceId: deviceIdOf() } })
      .then(function (r) {
        S.token = r.token; S.user = r;
        localStorage.setItem(LS.token, r.token); localStorage.setItem(LS.user, JSON.stringify(r));
        $('lg-msg').textContent = ''; $('lg-pass').value = '';
        return bootstrap();
      })
      .catch(function (err) { $('lg-msg').textContent = err.message || 'Gagal masuk.'; btn.disabled = false; });
  };

  window.logout = function (silent) {
    S.token = null; S.user = null; S.me = null; S.products = []; S.draft = {}; S.loaded = false;
    localStorage.removeItem(LS.token); localStorage.removeItem(LS.user);
    showLogin();
    if (!silent) toast('Anda telah keluar', '');
  };

  /* =====================================================================
     BOOTSTRAP
     ===================================================================== */
  function bootstrap() {
    return api('me', {}).then(function (me) {
      S.me = me;
      var roles = (me.roles || []).map(function (r) { return String(r).toUpperCase(); });
      var allowed = roles.some(function (r) { return ALLOWED.indexOf(r) >= 0; });
      if (!allowed) {
        logout(true);
        $('lg-msg').innerHTML = 'Akun Anda tidak memiliki akses Stock Opname.<br>Hanya jabatan <b>Pramuniaga</b> atau <b>Kepala Gudang</b>.';
        throw new Error('no-access');
      }
      paintIdentity(); applyRoles(roles); showApp(); setNav('opname');
      return loadProducts();
    }).then(function () { return loadRekap(true); })
      .catch(function (err) { if (err && err.message === 'no-access') return; });
  }

  function applyRoles(roles) {
    var isKG = roles.indexOf('KEPALA_GUDANG') >= 0;
    var sb = $('sb-crosscek'); var bn = document.querySelector('.bottomnav [data-nav="crosscek"]');
    if (isKG) { sb && sb.classList.remove('hidden'); bn && bn.classList.remove('hidden'); }
    else { sb && sb.classList.add('hidden'); bn && bn.classList.add('hidden'); if (S.nav === 'crosscek') setNav('opname'); }
  }

  function paintIdentity() {
    var me = S.me || {};
    var name = me.fullName || (S.user && S.user.employeeName) || 'Karyawan';
    var roles = (me.roles || []);
    $('sb-name').textContent = name;
    $('sb-role').textContent = roles.join(' · ') || 'Karyawan';
    var sbAv = $('sb-av');
    if (me.photoBase64) sbAv.innerHTML = '<img src="data:image/jpeg;base64,' + me.photoBase64 + '" alt="">'; else sbAv.textContent = initials(name);

    $('pf-name').textContent = name;
    $('pf-code').textContent = (me.employeeCode || '-') + ' · ' + (me.companyName || 'Simaung Corporation');
    $('pf-pos').textContent = me.position || '-';
    $('pf-roles').textContent = roles.join(', ') || '-';
    $('pf-shift').textContent = me.isOffToday ? 'Libur' : ((me.shiftName || '-') + (me.shiftStart ? ' (' + me.shiftStart + '–' + (me.shiftEnd || '') + ')' : ''));
    $('pf-company').textContent = me.companyName || 'Simaung Corporation';
    var pfa = $('pf-avatar');
    if (me.photoBase64) pfa.innerHTML = '<img src="data:image/jpeg;base64,' + me.photoBase64 + '" style="width:100%;height:100%;object-fit:cover" alt="">'; else pfa.textContent = initials(name);
    $('ab-sub').textContent = (me.companyName || 'Simaung Corporation') + ' · ' + name;
    $('op-title').textContent = (roles.indexOf('KEPALA_GUDANG') >= 0) ? 'Stock Opname & Crosscek' : 'Stock Opname';
  }

  /* =====================================================================
     NAVIGASI
     ===================================================================== */
  var TITLES = { opname: ['Stock Opname', 'Catat barang masuk, keluar & reject'], rekap: ['Rekap Harian', 'Rekapitulasi mutasi stok'], crosscek: ['Crosscek Opname', 'Validasi hasil opname pramuniaga'], profil: ['Profil', 'Data akun absensi Anda'] };

  window.setNav = function (nav) {
    S.nav = nav;
    ['opname', 'rekap', 'crosscek', 'profil'].forEach(function (v) { var el = $('view-' + v); if (el) el.classList.toggle('hidden', v !== nav); });
    document.querySelectorAll('.bottomnav button').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-nav') === nav); });
    document.querySelectorAll('.sb-item').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-nav') === nav); });
    var t = TITLES[nav] || TITLES.opname;
    $('ab-title').textContent = t[0]; $('ab-sub').textContent = (S.me && S.me.companyName ? S.me.companyName + ' · ' : '') + (S.me ? S.me.fullName : '');
    $('fab').classList.toggle('hidden', !(nav === 'opname' && draftCount() > 0));
    if (nav === 'rekap') loadRekap();
    if (nav === 'crosscek') loadCrosscek();
    closeSidebar();
    window.scrollTo(0, 0);
  };

  /* Tombol garis tiga — berfungsi di HP, tablet & desktop */
  function isDesktopView() { return window.matchMedia('(min-width:1100px)').matches; }
  window.openSidebar = function () {
    document.body.classList.remove('sb-collapsed');
    document.body.classList.add('sb-open');
  };
  /* closeSidebar hanya menutup drawer HP/tablet (tidak mengubah state desktop) */
  window.closeSidebar = function () { document.body.classList.remove('sb-open'); };
  window.toggleSidebar = function () {
    if (isDesktopView()) document.body.classList.toggle('sb-collapsed');
    else document.body.classList.toggle('sb-open');
  };
  /* Tutup drawer otomatis saat layar membesar ke ukuran desktop */
  window.addEventListener('resize', function () { if (isDesktopView()) document.body.classList.remove('sb-open'); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeSidebar(); });

  /* =====================================================================
     PRODUK & DAFTAR
     ===================================================================== */
  function loadProducts() {
    if (!S.loaded) $('op-items').innerHTML = '<div class="loading"><div class="spin"></div><span>Memuat katalog…</span></div>';
    return api('ops/products', {}).then(function (d) {
      S.products = d.items || d.products || []; S.loaded = true;
      renderFilters(); renderItemList();
    }).catch(function (err) {
      $('op-items').innerHTML = emptyBlock('Gagal memuat katalog', err.message);
    });
  }
  // Diekspos ke global agar tombol "Muat ulang data" (onclick di index.html)
  // dapat memanggilnya — sebelumnya hanya fungsi lokal IIFE sehingga klik tombol
  // melempar ReferenceError dan rekap ikut tidak dimuat.
  window.loadProducts = loadProducts;

  function categories() {
    var set = {}; S.products.forEach(function (p) { if (p.category) set[p.category] = 1; });
    return Object.keys(set).sort();
  }
  function renderFilters() {
    var cats = categories();
    var html = '<button class="fchip ' + (S.filter === '__all__' ? 'active' : '') + '" onclick="setFilter(\'__all__\')">Semua</button>';
    html += '<button class="fchip ' + (S.filter === '__low__' ? 'active' : '') + '" onclick="setFilter(\'__low__\')">Stok Menipis</button>';
    html += '<button class="fchip ' + (S.filter === '__draft__' ? 'active' : '') + '" onclick="setFilter(\'__draft__\')">Didraf</button>';
    cats.forEach(function (c) { html += '<button class="fchip ' + (S.filter === c ? 'active' : '') + '" onclick="setFilter(\'' + esc(c).replace(/'/g, "\\'") + '\')">' + esc(c) + '</button>'; });
    $('op-filters').innerHTML = html;
  }
  window.setFilter = function (f) { S.filter = f; renderFilters(); renderItemList(); };

  function filteredProducts() {
    var q = S.query.toLowerCase();
    return S.products.filter(function (p) {
      if (S.filter === '__low__' && !p.low) return false;
      if (S.filter === '__draft__' && !S.draft[p.id]) return false;
      if (S.filter !== '__all__' && S.filter !== '__low__' && S.filter !== '__draft__' && p.category !== S.filter) return false;
      if (!q) return true;
      return (p.name || '').toLowerCase().indexOf(q) >= 0 || (p.sku || '').toLowerCase().indexOf(q) >= 0 || (p.barcode || '').toLowerCase().indexOf(q) >= 0;
    });
  }
  function emptyBlock(t, d) { return '<div class="empty"><div class="ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 13V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h7"/><path d="M16 19h6"/><path d="M19 16v6"/></svg></div><div class="t">' + esc(t) + '</div><div class="d">' + esc(d || '') + '</div></div>'; }

  function stockChip(p) { return p.low ? '<span class="chip danger">Stok ' + fmt(p.stock) + '</span>' : '<span class="chip mut">Stok ' + fmt(p.stock) + '</span>'; }
  function draftBadges(pid) {
    var d = S.draft[pid]; if (!d) return '';
    var out = [];
    if (d.qtyIn) out.push('<span class="chip ok">+ ' + fmt(d.qtyIn) + ' masuk</span>');
    if (d.qtyOut) out.push('<span class="chip warn">- ' + fmt(d.qtyOut) + ' keluar</span>');
    if (d.qtyReject) out.push('<span class="chip danger">' + fmt(d.qtyReject) + ' reject</span>');
    return out.join(' ');
  }

  window.renderItemList = function () {
    S.query = ($('op-search').value || '').trim();
    var list = filteredProducts();
    var wrap = $('op-items');
    if (!list.length) { wrap.innerHTML = emptyBlock('Barang tidak ditemukan', 'Coba kata kunci lain atau ubah filter.'); return; }
    var cap = 200, shown = list.slice(0, cap);

    /* Kartu (mobile) */
    var cards = shown.map(function (p) {
      var d = S.draft[p.id];
      var badges = draftBadges(p.id);
      return '<div class="prow' + (d ? ' drafted' : '') + '" onclick="openItem(\'' + p.id + '\')">' +
        '<div class="prow-thumb">' + (p.image ? '<img src="' + esc(p.image) + '" alt="">' : esc(initials(p.name))) + '</div>' +
        '<div class="prow-info"><div class="prow-name">' + esc(p.name) + '</div>' +
          '<div class="prow-meta">' + (p.sku ? '<span>' + esc(p.sku) + '</span>' : '') + '<span>' + esc(p.unit || 'pcs') + '</span>' + stockChip(p) + '</div>' +
          (badges ? '<div class="prow-badges">' + badges + '</div>' : '') +
        '</div>' +
        '<div class="prow-caret"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg></div>' +
      '</div>';
    }).join('');

    /* Tabel (desktop) */
    var rows = shown.map(function (p) {
      var d = S.draft[p.id];
      var badges = draftBadges(p.id) || '<span style="color:var(--mut-2)">—</span>';
      var counted = d ? ((Number(p.stock) || 0) + d.qtyIn - d.qtyOut - d.qtyReject) : null;
      return '<tr onclick="openItem(\'' + p.id + '\')" style="cursor:pointer">' +
        '<td><div style="display:flex;align-items:center;gap:11px"><div class="prow-thumb" style="width:38px;height:38px;border-radius:10px">' + (p.image ? '<img src="' + esc(p.image) + '" alt="">' : esc(initials(p.name))) + '</div>' +
          '<div style="min-width:0"><div class="b" style="font-size:13.5px">' + esc(p.name) + '</div><div style="font-size:11.5px;color:var(--mut)">' + esc(p.sku || '-') + ' · ' + esc(p.unit || 'pcs') + '</div></div></div></td>' +
        '<td>' + esc(p.category || '-') + '</td>' +
        '<td class="r num b">' + fmt(p.stock) + '</td>' +
        '<td class="r num">' + (counted == null ? '—' : fmt(counted)) + '</td>' +
        '<td>' + badges + '</td>' +
        '<td class="r"><button class="btn sm ghost">Isi</button></td>' +
      '</tr>';
    }).join('');

    var more = list.length > shown.length ? '<div class="tac" style="color:var(--mut);font-size:12.5px;padding:12px">Menampilkan ' + shown.length + ' dari ' + list.length + ' barang — persempit pencarian.</div>' : '';

    wrap.innerHTML =
      '<div class="plist cards-mobile">' + cards + '</div>' +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr>' +
        '<th>Barang</th><th>Kategori</th><th class="r">Stok</th><th class="r">Fisik</th><th>Perubahan</th><th class="r">Aksi</th>' +
      '</tr></thead><tbody>' + rows + '</tbody></table></div>' + more;
  };

  /* =====================================================================
     INPUT BARANG (SHEET)
     ===================================================================== */
  window.openItem = function (pid) {
    var p = S.products.filter(function (x) { return x.id === pid; })[0]; if (!p) return;
    S.current = p;
    var d = S.draft[pid] || { qtyIn: 0, qtyOut: 0, qtyReject: 0, note: '' };
    $('si-title').textContent = p.name;
    $('si-sub').textContent = (p.sku ? 'SKU ' + p.sku + ' · ' : '') + (p.unit || 'pcs') + (p.category ? ' · ' + p.category : '');
    $('si-body').innerHTML =
      '<div style="display:flex;gap:13px;align-items:center;margin-bottom:12px">' +
        '<div class="prow-thumb" style="width:56px;height:56px;border-radius:14px;font-size:17px">' + (p.image ? '<img src="' + esc(p.image) + '" alt="">' : esc(initials(p.name))) + '</div>' +
        '<div style="flex:1;min-width:0"><div style="font-weight:800;font-size:15px">' + esc(p.name) + '</div>' +
        '<div style="color:var(--mut);font-size:12px;margin-top:2px">Stok sistem saat ini: <b style="color:var(--ink)">' + fmt(p.stock) + '</b> ' + esc(p.unit || '') + '</div></div>' +
      '</div>' +
      '<div class="qty-grid">' +
        qtyCell('in', 'Masuk', 'qi-in', d.qtyIn) +
        qtyCell('out', 'Keluar', 'qi-out', d.qtyOut) +
        qtyCell('reject', 'Reject', 'qi-rej', d.qtyReject) +
      '</div>' +
      '<div style="margin-top:14px" id="si-preview"></div>' +
      '<div class="field" style="margin-top:12px"><label>Catatan (opsional)</label><input id="qi-note" placeholder="Contoh: kiriman supplier / barang rusak" value="' + esc(d.note || '') + '"></div>' +
      '<div style="display:flex;gap:10px;margin-top:6px">' +
        (S.draft[pid] ? '<button class="btn ghost danger" style="flex:0 0 auto" onclick="removeDraft(\'' + pid + '\', true)">Hapus</button>' : '') +
        '<button class="btn block" onclick="saveItem(\'' + pid + '\')">Simpan ke Draf</button>' +
      '</div>';
    ['qi-in', 'qi-out', 'qi-rej'].forEach(function (id) { $(id).addEventListener('input', updatePreview); });
    updatePreview(); openSheet('sheet-item');
  };
  function qbox(kind, label, id, val) { return '<div class="qbox ' + kind + '"><label>' + label + '</label><input id="' + id + '" inputmode="numeric" value="' + (val || 0) + '"></div>'; }
  function qtyCell(kind, label, id, val) {
    return '<div class="qty-cell ' + kind + '">' +
      '<div class="qc-label">' + label + '</div>' +
      '<div class="qc-row">' +
        '<button class="qcbtn" type="button" aria-label="Kurangi ' + label + '" onclick="bump(\'' + id + '\',-1)">−</button>' +
        '<input id="' + id + '" inputmode="numeric" value="' + (val || 0) + '">' +
        '<button class="qcbtn" type="button" aria-label="Tambah ' + label + '" onclick="bump(\'' + id + '\',1)">+</button>' +
      '</div>' +
    '</div>';
  }
  window.bump = function (id, delta) { var el = $(id); var v = (parseInt(el.value, 10) || 0) + delta; if (v < 0) v = 0; el.value = v; updatePreview(); };
  function readQty(id) { return Math.max(0, parseInt($(id).value, 10) || 0); }
  function updatePreview() {
    var p = S.current; if (!p) return;
    var inQ = readQty('qi-in'), outQ = readQty('qi-out'), rejQ = readQty('qi-rej');
    var counted = (Number(p.stock) || 0) + inQ - outQ - rejQ; var diff = counted - (Number(p.stock) || 0);
    var cls = diff === 0 ? 'mut' : (diff > 0 ? 'ok' : 'danger');
    $('si-preview').innerHTML = '<div class="card tight" style="background:var(--surface-2);margin-bottom:0">' +
      '<div class="kv"><span class="k">Stok fisik setelah mutasi</span><span class="v num">' + fmt(counted) + '</span></div>' +
      '<div class="kv"><span class="k">Selisih vs sistem</span><span class="v"><span class="chip ' + cls + '">' + (diff > 0 ? '+' : '') + fmt(diff) + '</span></span></div></div>';
  }
  window.saveItem = function (pid) {
    var p = S.products.filter(function (x) { return x.id === pid; })[0];
    var inQ = readQty('qi-in'), outQ = readQty('qi-out'), rejQ = readQty('qi-rej');
    var note = ($('qi-note') ? $('qi-note').value : '').trim();
    if (!inQ && !outQ && !rejQ && !note) { toast('Belum ada perubahan', 'err'); return; }
    S.draft[pid] = { productId: pid, name: p.name, sku: p.sku, unit: p.unit, stock: p.stock, qtyIn: inQ, qtyOut: outQ, qtyReject: rejQ, note: note };
    closeSheet('sheet-item'); toast('Ditambahkan ke draf', 'ok');
    renderItemList(); refreshDraftUI();
  };
  window.removeDraft = function (pid, fromSheet) {
    delete S.draft[pid];
    if (fromSheet) closeSheet('sheet-item');
    toast('Dihapus dari draf', ''); renderItemList(); refreshDraftUI();
  };
  function draftCount() { return Object.keys(S.draft).length; }

  function refreshDraftUI() {
    var n = draftCount();
    ['draft-count', 'sb-draft-count'].forEach(function (id) { var el = $(id); if (el) { el.textContent = n; el.classList.toggle('hidden', n === 0); } });
    $('fab').classList.toggle('hidden', !(S.nav === 'opname' && n > 0));
    $('draft-hint').textContent = n + ' barang';
    var list = Object.keys(S.draft).map(function (k) { return S.draft[k]; });
    if (!list.length) { $('draft-list').innerHTML = '<div class="draft-empty">Belum ada barang.<br>Pilih barang lalu isi masuk / keluar / reject.</div>'; }
    else {
      $('draft-list').innerHTML = list.map(function (d) {
        var badges = [];
        if (d.qtyIn) badges.push('<span class="chip ok">+ ' + fmt(d.qtyIn) + '</span>');
        if (d.qtyOut) badges.push('<span class="chip warn">- ' + fmt(d.qtyOut) + '</span>');
        if (d.qtyReject) badges.push('<span class="chip danger">' + fmt(d.qtyReject) + '</span>');
        return '<div class="draft-item"><div class="di-info"><div class="di-name">' + esc(d.name) + '</div>' +
          '<div class="di-meta">' + (d.sku ? '<span>' + esc(d.sku) + '</span>' : '') + badges.join('') + '</div></div>' +
          '<button class="di-x" onclick="removeDraft(\'' + d.productId + '\')"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>';
      }).join('');
    }
    var isKG = S.me && (S.me.roles || []).map(function (r) { return String(r).toUpperCase(); }).indexOf('KEPALA_GUDANG') >= 0;
    $('draft-submit').textContent = (isKG ? 'Kirim Opname (Full)' : 'Kirim Opname') + (n ? ' · ' + n + ' barang' : '');
  }

  /* =====================================================================
     DRAF (Sheet mobile)
     ===================================================================== */
  window.openDraftSheet = function () {
    var list = Object.keys(S.draft).map(function (k) { return S.draft[k]; });
    if (!list.length) return;
    $('sd-sub').textContent = list.length + ' barang akan dikirim';
    $('sd-body').innerHTML = list.map(function (d) {
      var badges = [];
      if (d.qtyIn) badges.push('<span class="chip ok">+ ' + fmt(d.qtyIn) + ' masuk</span>');
      if (d.qtyOut) badges.push('<span class="chip warn">- ' + fmt(d.qtyOut) + ' keluar</span>');
      if (d.qtyReject) badges.push('<span class="chip danger">' + fmt(d.qtyReject) + ' reject</span>');
      return '<div class="draft-item" style="margin-bottom:8px"><div class="di-info"><div class="di-name">' + esc(d.name) + '</div>' +
        '<div class="di-meta">' + (d.sku ? '<span>' + esc(d.sku) + '</span>' : '') + badges.join('') + '</div></div>' +
        '<div class="num b">' + fmt((Number(d.stock) || 0) + d.qtyIn - d.qtyOut - d.qtyReject) + '</div></div>';
    }).join('') +
      '<div class="field" style="margin-top:8px"><label>Area / Lokasi</label><input id="sd-area" placeholder="Contoh: Rak A, Gudang Belakang" value="' + esc(S.area || '') + '"></div>' +
      '<div class="field"><label>Catatan sesi (opsional)</label><input id="sd-note" placeholder="Catatan keseluruhan" value="' + esc(S.note || '') + '"></div>' +
      '<button class="btn block" id="sd-submit-btn" onclick="submitDraft()">Kirim Opname (' + list.length + ' barang)</button>';
    openSheet('sheet-draft');
  };

  window.submitDraft = function () {
    var items = Object.keys(S.draft).map(function (k) {
      var d = S.draft[k]; return { productId: d.productId, qtyIn: d.qtyIn, qtyOut: d.qtyOut, qtyReject: d.qtyReject, note: d.note };
    });
    if (!items.length) { toast('Draf kosong', 'err'); return; }
    var areaEl = $('sd-area') || $('draft-area'); var noteEl = $('sd-note') || $('draft-note');
    S.area = (areaEl ? areaEl.value : S.area) || ''; S.note = (noteEl ? noteEl.value : S.note) || '';
    var isKG = S.me && (S.me.roles || []).map(function (r) { return String(r).toUpperCase(); }).indexOf('KEPALA_GUDANG') >= 0;
    var btn = firstOpenSheet() === 'sheet-draft' ? $('sd-submit-btn') : $('draft-submit');
    var orig = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Mengirim…'; }
    api('ops/opnames', { method: 'POST', body: { area: S.area, note: S.note, kind: isKG ? 'FULL' : undefined, items: items } })
      .then(function (r) {
        S.draft = {}; closeSheet('sheet-draft');
        toast('Opname tersimpan (' + (r.totalItems || items.length) + ' barang)', 'ok');
        renderItemList(); refreshDraftUI(); loadProducts(); loadRekap(true);
      })
      .catch(function (err) {
        toast(err.message, 'err');
        if (btn) { btn.disabled = false; btn.textContent = orig || ('Kirim Opname (' + items.length + ' barang)'); }
      });
  };

  /* =====================================================================
     REKAP HARIAN
     ===================================================================== */
  window.loadRekap = function (silent) {
    var date = ($('rk-date') && $('rk-date').value) || todayISO();
    if ($('rk-date')) $('rk-date').value = date;
    var mine = ($('rk-mine') && $('rk-mine').checked) ? '1' : '';
    if (!silent) $('rk-list').innerHTML = '<div class="panel"><div class="panel-body"><div class="loading"><div class="spin"></div><span>Memuat rekap…</span></div></div></div>';
    var qs = 'ops/opnames/log?date=' + encodeURIComponent(date) + (mine ? '&mine=1' : '');
    return api(qs, {}).then(function (d) {
      $('rk-in').textContent = fmt(d.totals && d.totals.in);
      $('rk-out').textContent = fmt(d.totals && d.totals.out);
      $('rk-reject').textContent = fmt(d.totals && d.totals.reject);
      var items = d.items || [];
      if (!items.length) { $('rk-list').innerHTML = emptyBlock('Belum ada mutasi', 'Tidak ada aktivitas opname pada tanggal ini.'); return; }
      $('rk-list').innerHTML = '<div class="panel"><div class="tbl-wrap"><table class="tbl"><thead><tr>' +
        '<th>Barang</th><th>Petugas</th><th>Kategori</th><th class="r">Masuk</th><th class="r">Keluar</th><th class="r">Reject</th>' +
        '</tr></thead><tbody>' + items.map(function (it) {
          return '<tr><td><div class="b" style="font-size:13.5px">' + esc(it.productName) + '</div><div style="font-size:11.5px;color:var(--mut)">' + esc(it.sku || '-') + (it.note ? ' · ' + esc(it.note) : '') + '</div></td>' +
            '<td><div style="font-size:13px">' + esc(it.employeeName || '-') + '</div><div style="font-size:11px;color:var(--mut)">' + (it.kind === 'KEPALA_GUDANG' ? '<span class="chip mut">Kepala Gudang</span>' : '<span class="chip mut">Pramuniaga</span>') + (it.area ? ' ' + esc(it.area) : '') + '</div></td>' +
            '<td>' + esc(it.category || '-') + '</td>' +
            '<td class="r num ' + (it.qtyIn ? 'b' : '') + '" style="color:' + (it.qtyIn ? 'var(--ok)' : 'var(--mut-2)') + '">' + (it.qtyIn ? '+' + fmt(it.qtyIn) : '—') + '</td>' +
            '<td class="r num ' + (it.qtyOut ? 'b' : '') + '" style="color:' + (it.qtyOut ? 'var(--accent-700)' : 'var(--mut-2)') + '">' + (it.qtyOut ? '-' + fmt(it.qtyOut) : '—') + '</td>' +
            '<td class="r num ' + (it.qtyReject ? 'b' : '') + '" style="color:' + (it.qtyReject ? 'var(--danger)' : 'var(--mut-2)') + '">' + (it.qtyReject ? fmt(it.qtyReject) : '—') + '</td></tr>';
        }).join('') + '</tbody></table></div></div>' +
        '<div class="plist cards-mobile">' + items.map(function (it) {
          var badges = [];
          if (it.qtyIn) badges.push('<span class="chip ok">+ ' + fmt(it.qtyIn) + ' masuk</span>');
          if (it.qtyOut) badges.push('<span class="chip warn">- ' + fmt(it.qtyOut) + ' keluar</span>');
          if (it.qtyReject) badges.push('<span class="chip danger">' + fmt(it.qtyReject) + ' reject</span>');
          return '<div class="card tight"><div style="display:flex;justify-content:space-between;gap:10px"><div style="min-width:0">' +
            '<div style="font-weight:700;font-size:14px">' + esc(it.productName) + '</div>' +
            '<div style="color:var(--mut);font-size:11.5px;margin-top:2px">' + esc(it.sku || '-') + ' · ' + esc(it.employeeName || '-') + (it.area ? ' · ' + esc(it.area) : '') + '</div>' +
            '<div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap">' + badges.join('') + '</div></div>' +
            (it.note ? '<div style="color:var(--mut);font-size:11.5px;text-align:right;max-width:120px">' + esc(it.note) + '</div>' : '') + '</div></div>';
        }).join('') + '</div>';
    }).catch(function (err) { $('rk-list').innerHTML = emptyBlock('Gagal memuat rekap', err.message); });
  };

  /* =====================================================================
     CROSSCEK (KEPALA GUDANG)
     ===================================================================== */
  window.loadCrosscek = function () {
    $('cc-list').innerHTML = '<div class="panel"><div class="panel-body"><div class="loading"><div class="spin"></div><span>Memuat sesi…</span></div></div></div>';
    api('ops/opnames', {}).then(function (d) {
      var items = d.items || d.opnames || [];
      if (!items.length) { $('cc-list').innerHTML = emptyBlock('Belum ada sesi opname', 'Sesi dari pramuniaga akan muncul di sini.'); return; }
      var rows = items.map(function (o) {
        var st = o.status || 'SUBMITTED'; var cls = st === 'APPROVED' ? 'ok' : (st === 'REJECTED' ? 'danger' : 'warn');
        return '<div class="prow" onclick="openReview(\'' + o.id + '\')">' +
          '<div class="prow-thumb">' + esc(initials(o.employeeName)) + '</div>' +
          '<div class="prow-info"><div class="prow-name">' + esc(o.employeeName || '-') + '</div>' +
            '<div class="prow-meta"><span>' + (o.kind === 'KEPALA_GUDANG' ? 'Full' : 'Area') + '</span>' + (o.area ? '<span>' + esc(o.area) + '</span>' : '') + '<span>' + fmt(o.totalItems) + ' barang</span></div>' +
            '<div class="prow-badges"><span class="chip ' + cls + '">' + esc(st) + '</span>' + (o.totalDiff ? '<span class="chip mut">selisih ' + fmt(o.totalDiff) + '</span>' : '') + '</div></div>' +
          '<div class="prow-caret"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg></div></div>';
      }).join('');
      $('cc-list').innerHTML = '<div class="plist">' + rows + '</div>';
    }).catch(function (err) { $('cc-list').innerHTML = emptyBlock('Gagal memuat', err.message); });
  };

  window.openReview = function (id) {
    $('rv-sub').textContent = 'Memuat…'; $('rv-body').innerHTML = '<div class="loading"><div class="spin"></div><span>Memuat detail…</span></div>'; openSheet('sheet-review');
    api('ops/opnames/' + id, {}).then(function (d) {
      var o = d.opname || {}, items = d.items || [];
      $('rv-sub').textContent = (o.employeeName || '-') + ' · ' + (o.kind === 'KEPALA_GUDANG' ? 'Full' : 'Area');
      var rows = items.map(function (it) {
        var badges = [];
        if (it.qtyIn) badges.push('<span class="chip ok">+ ' + fmt(it.qtyIn) + '</span>');
        if (it.qtyOut) badges.push('<span class="chip warn">- ' + fmt(it.qtyOut) + '</span>');
        if (it.qtyReject) badges.push('<span class="chip danger">' + fmt(it.qtyReject) + '</span>');
        var dcls = it.diff === 0 ? 'mut' : (it.diff > 0 ? 'ok' : 'danger');
        return '<div class="card tight"><div style="display:flex;justify-content:space-between;gap:10px"><div style="min-width:0">' +
          '<div style="font-weight:700;font-size:13.5px">' + esc(it.productName) + '</div>' +
          '<div style="color:var(--mut);font-size:11.5px">Sistem ' + fmt(it.systemStock) + ' → Fisik ' + fmt(it.countedStock) + '</div>' +
          (badges.length ? '<div style="margin-top:5px;display:flex;gap:5px;flex-wrap:wrap">' + badges.join('') + '</div>' : '') + '</div>' +
          '<span class="chip ' + dcls + '">' + (it.diff > 0 ? '+' : '') + fmt(it.diff) + '</span></div></div>';
      }).join('');
      var st = o.status || 'SUBMITTED';
      $('rv-body').innerHTML =
        '<div class="card tight" style="background:var(--surface-2)">' +
        '<div class="kv"><span class="k">Petugas</span><span class="v">' + esc(o.employeeName || '-') + '</span></div>' +
        '<div class="kv"><span class="k">Area</span><span class="v">' + esc(o.area || '-') + '</span></div>' +
        '<div class="kv"><span class="k">Total selisih</span><span class="v num">' + fmt(o.totalDiff) + '</span></div>' +
        '<div class="kv"><span class="k">Status</span><span class="v">' + esc(st) + '</span></div>' +
        (o.note ? '<div class="kv"><span class="k">Catatan</span><span class="v">' + esc(o.note) + '</span></div>' : '') + '</div>' +
        '<div style="font-weight:800;font-size:14px;margin:8px 0 10px">Rincian barang (' + items.length + ')</div>' + rows +
        (st === 'APPROVED' || st === 'REJECTED'
          ? '<div class="card tight" style="background:var(--brand-050);color:var(--brand-700);font-weight:700;text-align:center">Sudah dicrosscek: ' + esc(st) + '</div>'
          : '<div class="field" style="margin-top:6px"><label>Catatan crosscek (opsional)</label><input id="rv-note" placeholder="Catatan untuk petugas"></div>' +
            '<div style="display:flex;gap:10px">' +
            '<button class="btn ghost" style="flex:1" onclick="review(\'' + id + '\',\'REJECTED\')">Tolak</button>' +
            '<button class="btn" style="flex:1" onclick="review(\'' + id + '\',\'APPROVED\')">Setujui</button></div>') +
        '<div class="divider"></div>' +
        '<button class="btn danger block" onclick="deleteSession(\'' + id + '\')">Hapus &amp; Batalkan Mutasi Stok</button>';
    }).catch(function (err) { $('rv-body').innerHTML = emptyBlock('Gagal memuat', err.message); });
  };

  window.review = function (id, decision) {
    var note = ($('rv-note') ? $('rv-note').value : '').trim();
    api('ops/opnames/' + id + '/review', { method: 'POST', body: { decision: decision, note: note } })
      .then(function () { toast(decision === 'APPROVED' ? 'Opname disetujui' : 'Opname ditolak', 'ok'); closeSheet('sheet-review'); loadCrosscek(); })
      .catch(function (err) { toast(err.message, 'err'); });
  };

  window.deleteSession = function (id) {
    if (!confirm('Hapus sesi ini dan kembalikan mutasi stok? Tindakan ini tidak dapat dibatalkan.')) return;
    api('ops/opnames/' + id, { method: 'DELETE' }).then(function (r) {
      toast(r.message || 'Sesi dihapus', 'ok'); closeSheet('sheet-review'); loadCrosscek(); loadProducts();
    }).catch(function (err) { toast(err.message, 'err'); });
  };

  /* =====================================================================
     SCAN BARCODE
     ===================================================================== */
  window.openScan = function () {
    $('sc-body').innerHTML =
      '<div id="sc-cam" style="position:relative;border-radius:16px;overflow:hidden;background:#000;aspect-ratio:4/3;display:grid;place-items:center">' +
        '<video id="sc-video" playsinline muted style="width:100%;height:100%;object-fit:cover"></video>' +
        '<div style="position:absolute;inset:22% 14%;border:3px solid rgba(255,255,255,.85);border-radius:14px;box-shadow:0 0 0 9999px rgba(0,0,0,.28)"></div>' +
      '</div>' +
      '<div style="color:var(--mut);font-size:12.5px;text-align:center;margin-top:11px" id="sc-hint">Arahkan kamera ke barcode / QR barang…</div>' +
      '<div class="divider"></div>' +
      '<div class="field"><label>atau masukkan kode manual (barcode / SKU)</label><input id="sc-manual" placeholder="Ketik kode lalu Enter" autocomplete="off"></div>' +
      '<button class="btn block" onclick="manualLookup()">Cari Kode</button>';
    openSheet('sheet-scan'); startScan();
    var m = $('sc-manual'); if (m) m.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); manualLookup(); } });
  };
  function supportsBD() { return typeof window.BarcodeDetector === 'function'; }
  function startScan() {
    var video = $('sc-video'); if (!video) return;
    if (!supportsBD()) { $('sc-hint').textContent = 'Perangkat belum mendukung pemindai otomatis. Gunakan kode manual di bawah.'; $('sc-cam').style.display = 'none'; return; }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { $('sc-hint').textContent = 'Kamera tidak tersedia. Gunakan kode manual.'; return; }
    var detector = new window.BarcodeDetector({ formats: ['ean_13', 'ean_8', 'code_128', 'code_39', 'upc_a', 'upc_e', 'qr_code', 'itf', 'codabar'] });
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false }).then(function (stream) {
      S.scanStream = stream; video.srcObject = stream; video.play().catch(function () {});
      var stop = false; S.scanStop = function () { stop = true; };
      (function tick() {
        if (stop) return;
        if (video.readyState >= 2) {
          detector.detect(video).then(function (codes) {
            if (codes && codes.length && codes[0].rawValue) { onScan(codes[0].rawValue); return; }
            requestAnimationFrame(tick);
          }).catch(function () { requestAnimationFrame(tick); });
        } else requestAnimationFrame(tick);
      })();
    }).catch(function () { $('sc-hint').textContent = 'Tidak dapat mengakses kamera. Gunakan kode manual.'; });
  }
  function stopScan() { try { if (S.scanStop) S.scanStop(); } catch (e) {} try { if (S.scanStream) { S.scanStream.getTracks().forEach(function (t) { t.stop(); }); S.scanStream = null; } } catch (e) {} }
  function onScan(code) { stopScan(); closeSheet('sheet-scan'); lookup(code); }
  window.manualLookup = function () { var code = ($('sc-manual') ? $('sc-manual').value : '').trim(); if (!code) { toast('Masukkan kode terlebih dahulu', 'err'); return; } stopScan(); closeSheet('sheet-scan'); lookup(code); };
  function lookup(code) {
    api('ops/products/lookup?code=' + encodeURIComponent(code), {}).then(function (d) {
      var p = d.product; if (!p) { toast('Barang tidak ditemukan', 'err'); return; }
      if (!S.products.filter(function (x) { return x.id === p.id; }).length) S.products.unshift(p);
      openItem(p.id);
    }).catch(function (err) { toast(err.message || 'Barang tidak ditemukan', 'err'); });
  }

  /* =====================================================================
     INIT
     ===================================================================== */
  function init() {
    var dt = $('rk-date'); if (dt) dt.value = todayISO();
    refreshDraftUI();
    if (S.token) bootstrap().catch(function () { showLogin(); }); else showLogin();
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden && S.token && S.nav === 'opname') loadProducts();
    });
    // Muat ulang saat layar berubah ukuran (desktop <-> mobile)
    var lastW = window.innerWidth;
    window.addEventListener('resize', function () {
      if ((lastW < 1100) !== (window.innerWidth < 1100)) { lastW = window.innerWidth; if (S.loaded) renderItemList(); }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
