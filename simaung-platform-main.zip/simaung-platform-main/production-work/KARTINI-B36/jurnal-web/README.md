# Laporan Kartini — Platform Akuntansi & Jurnal Keuangan (Kledo-like)

Platform jurnal dan laporan keuangan berbasis **double-entry accounting**, dibangun mengikuti roadmap
Enterprise Accounting & ERP (Kledo-like). Seluruh laporan keuangan berasal dari **accounting engine**
(entri jurnal berpasangan) yang konsisten — bukan dari penjualan dikurangi pengeluaran secara langsung.

## Stack
- **Frontend**: Next.js 14 (App Router) + React + TypeScript
- **Styling**: Tailwind CSS + shadcn/ui-style components + lucide icons
- **Database**: Supabase (PostgreSQL)
- **Charts**: Recharts (siap digunakan)
- **Deploy**: Vercel (project `laporan-kartini`)
- **Logo**: SVG custom di `/logo.svg` (monogram "K" + panah pertumbuhan, tema warna brand `#6366f1`)

## URLs
- **Production**: https://laporan-kartini.vercel.app
- **Login**: https://laporan-kartini.vercel.app/login

## Fitur Utama
- **Accounting Engine (double-entry)** — posting rules otomatis untuk:
  - Sales Invoice → AR/Cash + Revenue + Inventory ↓ + COGS
  - Purchase Bill → Inventory/Expense + Input tax + AP
  - Customer Payment → Cash + AR (pelunasan piutang)
  - Supplier Payment → AP + Cash
  - Expense, Depreciation, Opening Balance, Reversal
  - Invariant: **total debit = total kredit** pada setiap jurnal yang di-posting
- **Laporan Keuangan** (semua bersumber dari jurnal):
  - Neraca Saldo (Trial Balance)
  - Laba Rugi (Income Statement)
  - Neraca (Balance Sheet) — Aset = Liabilitas + Ekuitas
  - Arus Kas (Cash Flow)
  - Buku Besar (General Ledger) — running balance per akun
  - Budget (anggaran vs realisasi) & Rekonsiliasi Bank & Dunning
- **Multi-tenant** — companies, branches, warehouses, RBAC, audit log
- **Auth** — Supabase SSR + middleware (session refresh), login/signup
- **Master data** — COA, customers, suppliers, products, units, tax rates, payment methods, currencies

## Audit Fitur vs Odoo.com (modul ERP yang sudah ditambahkan)
| Modul Odoo | Route / Fitur | Status |
|---|---|---|
| Sales / Quotation | `/sales/quotations` — input & list penawaran | ✅ Implemented |
| Sales Invoice + posting otomatis | `/sales/invoices` | ✅ Implemented |
| Purchasing / Purchase Order | `/purchase/orders` — input & list PO | ✅ Implemented |
| Purchase / Bills + posting | `/purchase/bills` | ✅ Implemented |
| Inventory — Delivery (DO) | `/inventory/transfers` (keluar barang) | ✅ Implemented |
| Inventory — Goods Receipt (GR) | `/inventory/transfers` (masuk barang) | ✅ Implemented |
| Inventory — Stock Transfer | `/inventory/transfers` (pindah gudang) | ✅ Implemented |
| Inventory — Stock Opname | `/inventory/opname` | ✅ Implemented |
| Currency & FX | `/master/currencies` — mata uang + kurs | ✅ Implemented |
| Budget | `/reports/budget` — anggaran per akun | ✅ Implemented |
| CRM Pipeline | `/crm` — opportunity + stage | ✅ Implemented |
| Project & Task | `/projects` — project + task | ✅ Implemented |
| Bank Reconciliation | `/reports/bank-reconciliation` | ✅ Implemented |
| Dunning / Penagihan | `/reports/dunning` — rules + fee | ✅ Implemented |
| Closing Periode | `/reports/closing` — buka/tutup periode fiskal | ✅ Implemented |
| Settings | `/settings` | ✅ Implemented |
| Notifications | `/notifications` | ✅ Implemented |
| Fixed Asset + Depresiasi | posting jurnal otomatis | ✅ Implemented |
| Piutang / Hutang (AR/AP) | receivables / payables | ✅ Implemented |

**Kesimpulan**: Akuntansi inti (double-entry engine + laporan keuangan) dan seluruh modul transaksi
bismiss Odoo inti (Sales, Purchasing, Inventory, Currency & FX, Budget, CRM, Project, Bank Reconciliation,
Dunning) sudah **berjalan penuh dengan halaman UI CRUD + migrasi tabel (0002) terverifikasi**.

## Struktur Database (Supabase) — 61 tabel aktif
- `companies`, `branches`, `warehouses`, `profiles`, `roles`, `permissions`, `user_scopes`, `audit_logs`
- `type_of_account`, `accounts`, `fiscal_periods`, `journal_entries`, `journal_lines`, `account_balances`, `closing_entries`
- `customers`, `suppliers`, `categories`, `units`, `products`, `tax_rates`, `payment_methods`
- `stock_movements`, `stock_balances`, `stock_opnames`, `stock_opname_lines`
- `invoices`, `invoice_items`, `bills`, `bill_items`, `payments`, `payment_allocations`
- `receivables`, `payables`, `cash_accounts`, `bank_accounts`
- `fixed_assets`, `depreciation_entries`
- `notifications`, `settings`

**Migration 0002 (modul Odoo baru, di-apply & terverifikasi):**
- `quotations`, `quotation_lines` — Sales / Quotation
- `purchase_orders`, `po_items` — Purchasing / PO
- `delivery_orders`, `delivery_items` — Inventory (Delivery/Keluar)
- `goods_receipts`, `receipt_items` — Inventory (Goods Receipt/Masuk)
- `stock_transfers`, `transfer_items` — Inventory (Transfer)
- `currencies`, `currency_rates` — Currency & FX
- `budgets`, `budget_items` — Budget
- `opportunities` — CRM Pipeline
- `projects`, `project_tasks` — Project & Task
- `bank_reconciliations` — Bank Reconciliation
- `dunning_rules` — Dunning

## Setup & Cara Menjalankan
```bash
npm install
# Isi .env.local sesuai .env.example (kredensial Supabase)
npm run build      # build production
npm run dev        # development
```

### Migrasi & Seed ke Supabase
```bash
node scripts/apply-migration.js supabase/migrations/0001_init.sql   # skema
node scripts/apply-migration.js supabase/seed/0002_seed.sql         # seed COA & master
node scripts/apply-migration.js supabase/seed/0003_demo.sql         # demo opening entry
```

## Alur Akuntansi (Core)
```
Transaksi Bisnis → Posting Rule → Jurnal (double-entry) → Buku Besar → Neraca Saldo → Laporan Keuangan
```

Semua dokumen transaksi (invoice, bill, payment, dsb.) menghasilkan jurnal otomatis melalui server.
Jurnal yang sudah di-posting **tidak dihapus fisik** — koreksi dilakukan via reversal/adjustment.
Periode yang ditutup (fiscal period closed) tidak dapat diubah tanpa mekanisme reopen terotorisasi.

## Deployment Status
- **Platform**: Vercel
- **Project**: `laporan-kartini`
- **Status**: ✅ Live
- **Last Updated**: 2026-09-09
- **Tech Stack**: Next.js 14 + TypeScript + Supabase + Tailwind CSS

## Perubahan Terbaru (2026-09-10)
### 0. Fix Overflow Horizontal di Mode Landscape (Dashboard & Report)
- **Gejala**: Pada viewport landscape (≥1280px) konten dashboard masih "keluar"/terpotong ke kanan,
  muncul scrollbar horizontal; kartu KPI (mis. "Kas Bersih") dan deretan kartu modul terpenggal.
- **Akar masalah**: CSS Grid secara default memberi `min-width: auto` pada setiap grid item, sehingga
  angka Rupiah panjang (mis. `Rp108.030.000.000,00`) dan teks kartu modul memaksa track grid melebar
  melebihi lebar viewport (main di-clamp `overflow-x-hidden` → konten terpotong).
- **Solusi**:
  - Tambah `min-w-0` pada komponen `Card` (`src/components/ui/card.tsx`) agar tiap kartu bisa menyusut.
  - Dashboard: `min-w-0` pada KPI card & kartu modul, angka KPI diberi `break-words` + `overflow-hidden`,
    serta label modul diberi `truncate`.
  - `globals.css`: guard global `overflow-x: clip` pada `html` & `body` (memakai `clip`, bukan `hidden`,
    agar tidak memecah `position: sticky` pada top bar mobile), plus `main > * { min-width: 0 }`.
- **Verifikasi**: `tsc --noEmit` lulus dan `next build` produksi sukses.

### 1. Fix Bug Autentikasi — "PKCE code verifier not found in storage"
- **Akar masalah**: `signUp` sebelumnya dijalankan di **server action** (`/app/actions/auth.ts`).
  Dengan `createServerClient`, `code_verifier` PKCE memang ditulis ke cookie, tetapi propagasinya ke
  `redirect()` tidak selalu andal → saat link konfirmasi diklik di browser yang sama pun
  `code_verifier` tidak ditemukan, sehingga `exchangeCodeForSession` gagal
  (persis pesan: "PKCE code verifier not found in storage...").
- **Solusi**: Memindahkan inisiasi `signUp` ke **browser client** (`createBrowserClient`) di
  `auth-card.tsx`. `@supabase/ssr` kini menyimpan `code_verifier` langsung di `document.cookie`,
  sehingga route `/auth/confirm` (yang memanggil `exchangeCodeForSession`) selalu menemukannya.
- **Server action** `signup` dipecah menjadi `createUserProfile` — dipanggil setelah `signUp` sukses
  untuk membuat baris `profiles` + default `user_scopes` (company KARTINI).
- Route `/auth/confirm` diperkuat: menangani `?code=`, `?token=pkce_*`, dan `?token_hash=`
  (OTP/recovery/invite), dengan fallback ke `/dashboard` bila sesi sudah valid.

### 2. Overhaul UI/UX Premium & Profesional
- **Halaman Login** (`/login`): layout 2 kolom (brand value-proposition + kartu auth),
  dekorasi ambient gradient/dot-grid, badge fitur, tombol dengan state loading, popup sukses
  pendaftaran yang lebih halus.
- **Sidebar**: navigasi dikelompokkan per modul (Ringkasan, Jurnal, Master Data, Transaksi,
  Persediaan & Piutang, Aktiva & Proyek, Laporan Keuangan, Sistem), badge aktif dengan accent bar,
  grup bisa di-collapse, lebar diperbesar (w-72).
- **Design system global**: tema Tailwind diperluas (font Inter, shadow `card`/`card-hover`/`soft-glow`,
  radius, animasi `fade-in`/`slide-up`), `globals.css` dirapikan (scrollbar, focus ring, badge, button
  & input lebih premium), komponen `Card`/`CardHeader`/`ReportShell` disempurnakan.
- **Dashboard**: KPI cards dengan ikon berwarna, link modul dengan hover lift, badge margin,
  indikator balanced dengan ikon check/warning.

### Catatan Auth Supabase (manual Prasyarat)
Pastikan di **Supabase Dashboard → Authentication → URL Configuration** daftar Redirect URLs memuat:
```
https://laporan-kartini.vercel.app/*
```
dan gunakan template email konfirmasi di `supabase/email-template-confirm.md` (kolom Message Body),
dengan tombol CTA pada `{{ .ConfirmationURL }}` yang mengarah ke `https://laporan-kartini.vercel.app/auth/confirm`.

## Catatan Scope
Roadmap Kledo Clone adalah ERP enterprise 22 fase. Iterasi ini berfokus pada **fondasi production-grade**
inti yang berjalan penuh: **accounting engine + laporan keuangan**, plus modul bisnis inti
(master data, multi-company, RBAC, auth, skeleton sales/purchase/inventory/AR-AP/asset) sesuai struktur
DB roadmap. Modul lanjutan (approval matrix, bank reconciliation UI, fixed-asset UI, tax reporting,
import/export, notification engine, API/webhooks) dapat dikembangkan pada iterasi berikutnya.
