require('dotenv').config({ path: require('path').resolve(__dirname, '../.env.local') });
const { Client } = require('pg');
const u = new URL(process.env.POSTGRES_URL_NON_POOLING);
const client = new Client({
  host: u.hostname, port: u.port?parseInt(u.port,10):5432,
  user: decodeURIComponent(u.username), password: decodeURIComponent(u.password),
  database: u.pathname.replace(/^\//,'')||'postgres', ssl:{rejectUnauthorized:false}
});
(async()=>{
  await client.connect();
  const r = await client.query("select tablename from pg_tables where schemaname='public' order by tablename");
  console.log("TABLES ("+r.rows.length+"):");
  console.log(r.rows.map(x=>x.tablename).join(', '));
  const en = await client.query("select typname from pg_type where typtype='e'");
  console.log("\nENUMS:"); console.log(en.rows.map(x=>x.typname).join(', '));
  await client.end();
})().catch(e=>{console.error(e.message);process.exit(1);});
