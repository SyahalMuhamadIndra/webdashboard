// scripts/apply-migration.js
// Applies a SQL migration file to Supabase Postgres using the direct (non-pooling) connection.
// Usage: node scripts/apply-migration.js <sqlfile>
require('dotenv').config?.();
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

// Load env from .env.local (override default .env)
require('dotenv')?.config?.({ path: require('path').resolve(__dirname, '../.env.local') });
require('dotenv')?.config?.({ path: require('path').resolve(__dirname, '../.env') });

const file = process.argv[2];
if (!file) {
  console.error('Usage: node scripts/apply-migration.js <sqlfile>');
  process.exit(1);
}

const pgUrl =
  process.env.POSTGRES_URL_NON_POOLING ||
  process.env.DATABASE_URL;
if (!pgUrl) {
  console.error('Set POSTGRES_URL_NON_POOLING or DATABASE_URL in the environment before running this script.');
  process.exit(1);
}

// Build connection config from URL parts explicitly (bypasses pg-connection-string
// which treats sslmode=require as verify-full and rejects self-signed certs).
function buildPgConfig(inputUrl) {
  const u = new URL(inputUrl);
  return {
    host: u.hostname,
    port: u.port ? parseInt(u.port, 10) : 5432,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: u.pathname.replace(/^\//, '') || 'postgres',
    ssl: { rejectUnauthorized: false }, // accept Supabase self-signed cert chain
    statement_timeout: 120000,
    query_timeout: 120000,
  };
}

async function main() {
  const sql = fs.readFileSync(path.resolve(file), 'utf8');
  const client = new Client(buildPgConfig(pgUrl));
  await client.connect();
  console.log('✅ Connected to Supabase Postgres (direct).');

  // Split on semicolons at top level is fragile; execute whole file via simple query.
  // We run the entire migration as one multi-statement query (pg supports this).
  try {
    await client.query(sql);
    console.log(`✅ Migration applied successfully: ${file}`);
  } catch (err) {
    console.error('❌ Migration failed:', err.message);
    // Try to identify which statement failed by splitting.
    const stmts = sql
      .split(/;\s*(\r?\n)/)
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
    for (let i = 0; i < stmts.length; i++) {
      try {
        await client.query(stmts[i] + ';');
      } catch (e) {
        console.error(`  ⚠️ Statement ${i + 1} failed: ${e.message}`);
        console.error('  --------');
        console.error(stmts[i].slice(0, 400));
        console.error('  --------');
        break;
      }
    }
  } finally {
    await client.end();
  }
}

main().catch((e) => {
  console.error('Fatal:', e.message);
  process.exit(1);
});
