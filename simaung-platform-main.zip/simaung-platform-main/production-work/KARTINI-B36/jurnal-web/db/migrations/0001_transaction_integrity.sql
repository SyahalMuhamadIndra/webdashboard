CREATE TABLE IF NOT EXISTS public.erp_operation_receipts (
 company_id uuid NOT NULL REFERENCES public.companies(id),
 admin_id uuid NOT NULL REFERENCES public.profiles(id),
 operation_id uuid NOT NULL,
 action text NOT NULL,
 payload_hash text NOT NULL,
 result jsonb,
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(company_id,admin_id,operation_id)
);

CREATE OR REPLACE FUNCTION public.kartini_check_journal_balance() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE entry_id uuid; posted boolean; d numeric; c numeric; n integer;
BEGIN
 IF TG_TABLE_NAME='journal_entries' THEN entry_id=COALESCE(NEW.id,OLD.id);
 ELSE entry_id=COALESCE(NEW.journal_entry_id,OLD.journal_entry_id); END IF;
 SELECT is_posted INTO posted FROM public.journal_entries WHERE id=entry_id;
 IF posted IS TRUE THEN
  SELECT COALESCE(sum(debit),0),COALESCE(sum(credit),0),count(*) INTO d,c,n FROM public.journal_lines WHERE journal_entry_id=entry_id;
  IF n<2 OR d<=0 OR d<>c THEN RAISE EXCEPTION 'Posted journal must have balanced nonzero lines' USING ERRCODE='23514'; END IF;
 END IF;
 RETURN NULL;
END $$;
DROP TRIGGER IF EXISTS kartini_journal_balance_lines ON public.journal_lines;
CREATE CONSTRAINT TRIGGER kartini_journal_balance_lines AFTER INSERT OR UPDATE OR DELETE ON public.journal_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.kartini_check_journal_balance();
DROP TRIGGER IF EXISTS kartini_journal_balance_entry ON public.journal_entries;
CREATE CONSTRAINT TRIGGER kartini_journal_balance_entry AFTER INSERT OR UPDATE ON public.journal_entries DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.kartini_check_journal_balance();

CREATE OR REPLACE FUNCTION public.kartini_protect_posted_journal() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE posted boolean;
BEGIN
 IF TG_TABLE_NAME='journal_entries' THEN
  IF OLD.is_posted THEN
   IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Posted journal cannot be deleted'; END IF;
   IF (to_jsonb(NEW)-ARRAY['is_reversed','reversed_entry_id','updated_at']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['is_reversed','reversed_entry_id','updated_at']) THEN RAISE EXCEPTION 'Posted journal is immutable'; END IF;
  END IF;
 ELSE
  IF TG_OP='INSERT' THEN SELECT is_posted INTO posted FROM public.journal_entries WHERE id=NEW.journal_entry_id;
  ELSE SELECT is_posted INTO posted FROM public.journal_entries WHERE id=OLD.journal_entry_id; END IF;
  IF posted THEN RAISE EXCEPTION 'Posted journal lines are immutable'; END IF;
 END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS kartini_journal_immutable_entry ON public.journal_entries;
CREATE TRIGGER kartini_journal_immutable_entry BEFORE UPDATE OR DELETE ON public.journal_entries FOR EACH ROW EXECUTE FUNCTION public.kartini_protect_posted_journal();
DROP TRIGGER IF EXISTS kartini_journal_immutable_lines ON public.journal_lines;
CREATE TRIGGER kartini_journal_immutable_lines BEFORE INSERT OR UPDATE OR DELETE ON public.journal_lines FOR EACH ROW EXECUTE FUNCTION public.kartini_protect_posted_journal();
