import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import type { ReactNode } from 'react';

export function ReportShell({
  title,
  subtitle,
  backHref,
  children,
  actions,
}: {
  title: string;
  subtitle?: string;
  backHref?: string;
  children: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {backHref && (
            <Link href={backHref} className="btn-secondary">
              <ArrowLeft className="h-4 w-4" /> Kembali
            </Link>
          )}
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">{title}</h1>
            {subtitle && <p className="mt-0.5 text-sm text-slate-500">{subtitle}</p>}
          </div>
        </div>
        {actions}
      </div>
      {children}
    </div>
  );
}

export function MoneyCell({ value, className }: { value: number; className?: string }) {
  return (
    <span
      className={
        className ??
        (value < 0
          ? 'text-right font-medium text-red-600'
          : 'text-right font-medium text-slate-800')
      }
    >
      {new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(value || 0)}
    </span>
  );
}
