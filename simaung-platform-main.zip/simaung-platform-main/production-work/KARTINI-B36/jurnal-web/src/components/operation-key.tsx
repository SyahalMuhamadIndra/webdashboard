import {randomUUID} from 'node:crypto';
/** A server-rendered key stays stable across retries and changes after revalidation. */
export function OperationKey(){return <input type="hidden" name="_operationId" value={randomUUID()} readOnly />}
