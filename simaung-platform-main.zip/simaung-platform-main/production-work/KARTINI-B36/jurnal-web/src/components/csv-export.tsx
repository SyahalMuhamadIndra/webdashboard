'use client';

import { Download } from 'lucide-react';
import { toCSV } from '@/lib/csv';

export function CsvExportButton({
  filename,
  headers,
  rows,
  label = 'Export CSV',
  className,
}: {
  filename: string;
  headers: string[];
  rows: (string | number | null | undefined)[][];
  label?: string;
  className?: string;
}) {
  function handleExport() {
    const csv = toCSV(headers, rows);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  return (
    <button
      type="button"
      onClick={handleExport}
      className={
        className ??
        'inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50'
      }
    >
      <Download className="h-4 w-4" />
      {label}
    </button>
  );
}
