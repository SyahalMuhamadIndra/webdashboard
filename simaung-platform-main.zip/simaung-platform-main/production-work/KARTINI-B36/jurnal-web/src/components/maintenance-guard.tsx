'use client';
import { useEffect } from 'react';
export function MaintenanceGuard() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = '/maintenance-guard.js?v=2';
    document.head.appendChild(script);
    return () => { script.remove(); };
  }, []);
  return null;
}
