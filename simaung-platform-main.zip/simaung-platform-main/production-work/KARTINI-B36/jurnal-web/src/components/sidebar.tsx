'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useState } from 'react';
import {
  LayoutDashboard,
  BookOpen,
  Receipt,
  Scale,
  TrendingUp,
  FileBarChart,
  Wallet,
  LogOut,
  Calculator,
  Landmark,
  Users,
  Truck,
  Package,
  ShoppingCart,
  ShoppingBag,
  Banknote,
  FileClock,
  Boxes,
  Percent,
  Settings,
  Bell,
  FileText,
  ClipboardList,
  Layers,
  Coins,
  Target,
  BellRing,
  Filter,
  FolderKanban,
  Menu,
  X,
  ChevronDown,
  ChevronRight,
  Building2,
  Repeat,
  CalendarClock,
  ShieldCheck,
  History,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { logout } from '@/app/actions/auth';

type NavItem = { href: string; label: string; icon: any };

const navGroups: { title: string; items: NavItem[] }[] = [
  {
    title: 'Ringkasan',
    items: [
      { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    ],
  },
  {
    title: 'Jurnal',
    items: [
      { href: '/journal', label: 'Jurnal', icon: BookOpen },
      { href: '/journal/new', label: 'Entri Jurnal', icon: Calculator },
    ],
  },
  {
    title: 'Master Data',
    items: [
      { href: '/master/accounts', label: 'Bagan Akun', icon: Landmark },
      { href: '/master/customers', label: 'Pelanggan', icon: Users },
      { href: '/master/suppliers', label: 'Pemasok', icon: Truck },
      { href: '/master/products', label: 'Produk', icon: Package },
      { href: '/master/taxes', label: 'Pajak', icon: Percent },
      { href: '/master/currencies', label: 'Mata Uang', icon: Coins },
      { href: '/master/branches', label: 'Cabang', icon: Building2 },
    ],
  },
  {
    title: 'Transaksi',
    items: [
      { href: '/sales/invoices', label: 'Invoice Penjualan', icon: ShoppingCart },
      { href: '/sales/recurring', label: 'Invois Berulang', icon: Repeat },
      { href: '/sales/quotations', label: 'Quotation', icon: FileText },
      { href: '/purchase/bills', label: 'Bill Pembelian', icon: ShoppingBag },
      { href: '/purchase/orders', label: 'Purchase Order', icon: ClipboardList },
      { href: '/payments', label: 'Pembayaran', icon: Banknote },
      { href: '/finance', label: 'Kas & Bank', icon: Banknote },
      { href: '/expenses', label: 'Beban', icon: FileClock },
    ],
  },
  {
    title: 'Persediaan & Piutang',
    items: [
      { href: '/inventory', label: 'Persediaan', icon: Boxes },
      { href: '/inventory/opname', label: 'Stock Opname', icon: Boxes },
      { href: '/inventory/transfers', label: 'Keluar/Masuk Barang', icon: Layers },
      { href: '/inventory/movements', label: 'Riwayat Mutasi Stok', icon: History },
      { href: '/ar', label: 'Piutang (AR)', icon: Wallet },
      { href: '/ap', label: 'Hutang (AP)', icon: Wallet },
    ],
  },
  {
    title: 'Aktiva & Proyek',
    items: [
      { href: '/assets', label: 'Aktiva Tetap', icon: Landmark },
      { href: '/crm', label: 'CRM Pipeline', icon: Filter },
      { href: '/projects', label: 'Proyek', icon: FolderKanban },
      { href: '/projects/tasks', label: 'Task Proyek', icon: ClipboardList },
    ],
  },
  {
    title: 'Laporan Keuangan',
    items: [
      { href: '/reports/trial-balance', label: 'Neraca Saldo', icon: Scale },
      { href: '/reports/income-statement', label: 'Laba Rugi', icon: TrendingUp },
      { href: '/reports/balance-sheet', label: 'Neraca', icon: Receipt },
      { href: '/reports/cash-flow', label: 'Arus Kas', icon: Wallet },
      { href: '/reports/general-ledger', label: 'Buku Besar', icon: FileBarChart },
      { href: '/reports/budget', label: 'Budget', icon: Target },
      { href: '/reports/inventory-valuation', label: 'Valuasi Persediaan', icon: Boxes },
      { href: '/reports/low-stock', label: 'Stok Menipis', icon: Boxes },
      { href: '/reports/deferred', label: 'Pendapatan/Beban Ditangguhkan', icon: CalendarClock },
      { href: '/reports/depreciation', label: 'Jadwal Penyusutan', icon: Calculator },
      { href: '/reports/account-balances', label: 'Saldo Akun / Periode', icon: Layers },
      { href: '/reports/allocations', label: 'Alokasi Pembayaran', icon: Banknote },
      { href: '/reports/bank-reconciliation', label: 'Rekonsiliasi Bank', icon: Landmark },
      { href: '/reports/dunning', label: 'Dunning', icon: BellRing },
      { href: '/reports/closing', label: 'Periode & Closing', icon: FileClock },
    ],
  },
  {
    title: 'Sistem',
    items: [
      { href: '/notifications', label: 'Notifikasi', icon: Bell },
      { href: '/audit-log', label: 'Audit Log', icon: FileText },
      { href: '/settings/users', label: 'Manajemen Pengguna', icon: Users },
      { href: '/settings/roles', label: 'Roles & Permissions', icon: ShieldCheck },
      { href: '/settings', label: 'Pengaturan', icon: Settings },
    ],
  },
];

export function Sidebar({
  companyName,
  userName,
}: {
  companyName: string;
  userName?: string;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  function closeMobile() {
    setMobileOpen(false);
  }

  async function handleLogout() {
    try {
      await logout();
    } finally {
      router.push('/login');
      router.refresh();
    }
  }

  const isActive = (href: string) =>
    href === '/journal' ? pathname === '/journal' : pathname.startsWith(href);

  function toggleGroup(title: string) {
    setCollapsed((c) => ({ ...c, [title]: !c[title] }));
  }

  const brand = (
    <div className="flex h-16 shrink-0 items-center gap-3 border-b border-slate-200/70 px-5">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/logo.png"
        alt="Laporan Simaung Corporation"
        className="h-10 w-10 shrink-0 rounded-lg object-contain ring-1 ring-slate-200"
      />
      <div className="leading-tight">
        <div className="text-sm font-bold tracking-tight text-slate-900">Laporan Simaung Corporation</div>
        <div className="flex items-center gap-1 text-xs font-medium text-accent-600">
          <Building2 className="h-3 w-3" />
          {companyName}
        </div>
      </div>
    </div>
  );

  const renderGroup = (group: { title: string; items: NavItem[] }) => {
    const isCollapsed = collapsed[group.title];
    return (
      <div key={group.title}>
        <div className="flex items-center justify-between px-3 pt-5 pb-1.5">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            {group.title}
          </span>
          {group.items.length > 1 && (
            <button
              type="button"
              onClick={() => toggleGroup(group.title)}
              className="rounded p-0.5 text-slate-300 hover:text-slate-500"
              aria-label={`${isCollapsed ? 'Buka' : 'Tutup'} grup ${group.title}`}
            >
              {isCollapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            </button>
          )}
        </div>
        {!isCollapsed && (
          <div className="space-y-0.5 px-2">
            {group.items.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={closeMobile}
                  className={cn(
                    'group relative flex items-center gap-3 rounded-lg px-3 py-2 text-[13px] font-medium transition-colors',
                    active
                      ? 'bg-brand-50 text-brand-700'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  )}
                >
                  {active && (
                    <span className="absolute left-0 top-1/2 h-5 w-1 -translate-y-1/2 rounded-full bg-brand-600" />
                  )}
                  <Icon
                    className={cn(
                      'h-4 w-4 shrink-0',
                      active ? 'text-brand-600' : 'text-slate-400 group-hover:text-slate-600'
                    )}
                  />
                  {item.label}
                </Link>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  const nav = (
    <nav className="flex-1 overflow-y-auto px-0 pb-4">{navGroups.map(renderGroup)}</nav>
  );

  const footer = (
    <div className="shrink-0 border-t border-slate-200/70 p-3">
      {userName && (
        <div className="mb-2 flex items-center gap-2 px-2">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-600 text-xs font-bold text-white">
            {userName.charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0 leading-tight">
            <div className="truncate text-[13px] font-semibold text-slate-800">{userName}</div>
            <div className="text-[11px] text-slate-400">Masuk</div>
          </div>
        </div>
      )}
      <button
        onClick={handleLogout}
        className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-[13px] font-medium text-slate-600 transition-colors hover:bg-red-50 hover:text-red-600"
      >
        <LogOut className="h-4 w-4 shrink-0" />
        Keluar
      </button>
    </div>
  );

  return (
    <>
      {/* ===== Mobile / tablet top bar ===== */}
      <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-slate-200 bg-white px-4 xl:hidden">
        <button
          type="button"
          onClick={() => setMobileOpen(true)}
          aria-label="Buka menu"
          className="rounded-md p-1.5 text-slate-600 hover:bg-slate-100"
        >
          <Menu className="h-6 w-6" />
        </button>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/logo.png" alt="Laporan Simaung Corporation" className="h-8 w-8 rounded-md object-contain" />
        <div className="leading-tight">
          <div className="text-sm font-bold text-slate-900">Laporan Simaung Corporation</div>
          <div className="text-xs text-accent-600">{companyName}</div>
        </div>
      </header>

      {/* ===== Desktop sidebar ===== */}
      <aside className="hidden h-screen w-72 shrink-0 flex-col border-r border-slate-200 bg-white xl:flex">
        {brand}
        {nav}
        {footer}
      </aside>

      {/* ===== Mobile / tablet drawer ===== */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 xl:hidden">
          {/* backdrop */}
          <div
            className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm"
            onClick={closeMobile}
            aria-hidden="true"
          />
          {/* drawer panel */}
          <aside className="absolute inset-y-0 left-0 flex w-72 flex-col border-r border-slate-200 bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200">
              {brand}
              <button
                type="button"
                onClick={closeMobile}
                aria-label="Tutup menu"
                className="mr-3 rounded-md p-1.5 text-slate-600 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            {nav}
            {footer}
          </aside>
        </div>
      )}
    </>
  );
}
