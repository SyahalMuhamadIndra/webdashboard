'use client';

import { useRouter, useSearchParams } from 'next/navigation';

// Client component — dropdown akun untuk laporan Buku Besar.
// Server Component tidak boleh menerima event handler (onChange),
// jadi interaktivitas dipisahkan ke Client Component ini.
export function AccountSelector({
  accounts,
  currentId,
  basePath,
}: {
  accounts: { id: string; code: string; name: string }[];
  currentId?: string;
  basePath: string;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const current = currentId || accounts[0]?.id;

  return (
    <select
      defaultValue={current}
      className="input max-w-md"
      onChange={(e) => {
        const v = e.target.value;
        if (v) router.push(`${basePath}?account_id=${v}`);
      }}
    >
      {(accounts || []).map((a) => (
        <option key={a.id} value={a.id}>
          {a.code} · {a.name}
        </option>
      ))}
    </select>
  );
}
