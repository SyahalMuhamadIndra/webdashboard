'use client';

import { useState } from 'react';
import { Loader2, AlertCircle, Mail, Clock, ArrowRight } from 'lucide-react';
import { login, register } from '@/app/actions/auth';
import { cn } from '@/lib/utils';

export function AuthCard({
  error,
  message,
  pending,
}: {
  error?: string;
  message?: string;
  pending?: boolean;
}) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [localError, setLocalError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Popup sukses setelah daftar (muncul otomatis saat ?message=... di URL)
  const [showMessage, setShowMessage] = useState(!!message);

  function switchMode(m: 'login' | 'register') {
    setMode(m);
    setLocalError(null);
    setPassword('');
    setConfirm('');
    setEmail('');
  }

  // Client-side validation for the register form (email + password).
  function validateRegister(): boolean {
    if (!email.trim() || !password) {
      setLocalError('Email dan kata sandi wajib diisi.');
      return false;
    }
    if (password.length < 6) {
      setLocalError('Kata sandi minimal 6 karakter.');
      return false;
    }
    if (password !== confirm) {
      setLocalError('Konfirmasi kata sandi tidak cocok.');
      return false;
    }
    setLocalError(null);
    return true;
  }

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || !password) {
      setLocalError('Email dan kata sandi wajib diisi.');
      return;
    }
    setLocalError(null);
    setSubmitting(true);
    try {
      const fd = new FormData();
      fd.set('email', email);
      fd.set('password', password);
      await login(fd);
    } catch (err: any) {
      setLocalError(err?.message || 'Gagal masuk. Periksa kembali kredensial Anda.');
      setSubmitting(false);
    }
  }

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    if (!validateRegister()) return;

    setSubmitting(true);
    try {
      // Registrasi langsung ke SERVER TERPADU (api.tokokartini.com /admin/register).
      // Tetap satu backend & satu database dengan POS, absensi, & panel admin.
      const fd = new FormData();
      fd.set('name', name || email.split('@')[0]);
      fd.set('email', email.trim());
      fd.set('password', password);
      await register(fd);
    } catch (err: any) {
      setLocalError(err?.message || 'Terjadi kesalahan saat mendaftar. Coba lagi.');
      setSubmitting(false);
    }
  }

  const tabClass = (m: 'login' | 'register') =>
    cn(
      'relative flex-1 rounded-lg px-3 py-2.5 text-sm font-medium transition-all',
      mode === m
        ? 'bg-white text-slate-900 shadow-sm ring-1 ring-slate-200'
        : 'text-slate-500 hover:text-slate-800'
    );

  const labelClass = 'mb-1.5 block text-sm font-medium text-slate-700';

  return (
    <div className="rounded-2xl border border-slate-200 bg-white/90 p-6 shadow-xl shadow-slate-200/50 backdrop-blur sm:p-8">
      <div className="mb-6 text-center sm:text-left">
        <h2 className="text-xl font-semibold tracking-tight text-slate-900">
          {mode === 'login' ? 'Selamat datang kembali' : 'Buat akun baru'}
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          {mode === 'login'
            ? 'Masuk untuk mengelola jurnal & laporan keuangan Anda.'
            : 'Mulai kelola keuangan bisnis Anda dengan profesional.'}
        </p>
      </div>

      {/* Toggle */}
      <div className="mb-6 flex rounded-xl bg-slate-100 p-1">
        <button
          type="button"
          onClick={() => switchMode('login')}
          className={tabClass('login')}
        >
          Masuk
        </button>
        <button
          type="button"
          onClick={() => switchMode('register')}
          className={tabClass('register')}
        >
          Daftar
        </button>
      </div>

      {error && (
        <div className="mb-4 flex items-start gap-2 rounded-xl border border-red-100 bg-red-50 px-3.5 py-3 text-sm text-red-700">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {localError && (
        <div className="mb-4 flex items-start gap-2 rounded-xl border border-red-100 bg-red-50 px-3.5 py-3 text-sm text-red-700">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{localError}</span>
        </div>
      )}

      {/* Popup status setelah daftar: menunggu persetujuan / sukses */}
      {showMessage && message && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-7 text-center shadow-2xl">
            <div
              className={
                'mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full ' +
                (pending ? 'bg-amber-50' : 'bg-emerald-50')
              }
            >
              {pending ? (
                <Clock className="h-7 w-7 text-amber-600" />
              ) : (
                <Mail className="h-7 w-7 text-emerald-600" />
              )}
            </div>
            <h3 className="text-lg font-bold text-slate-900">
              {pending ? 'Menunggu Persetujuan' : 'Pendaftaran Berhasil'}
            </h3>
            <p className="mt-2 text-sm text-slate-500">{message}</p>
            {pending ? (
              <p className="mt-2 text-xs text-slate-400">
                Anda akan bisa masuk setelah Superadmin menyetujui akun ini.
              </p>
            ) : null}
            <button
              type="button"
              onClick={() => setShowMessage(false)}
              className="btn-primary mt-6 w-full justify-center"
            >
              Mengerti
            </button>
          </div>
        </div>
      )}

      {mode === 'login' ? (
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className={labelClass} htmlFor="login-email">
              Email
            </label>
            <input
              id="login-email"
              name="email"
              type="email"
              autoComplete="email"
              placeholder="nama@perusahaan.com"
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div>
            <label className={labelClass} htmlFor="login-password">
              Kata Sandi
            </label>
            <input
              id="login-password"
              name="password"
              type="password"
              autoComplete="current-password"
              placeholder="••••••••"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="btn-primary w-full justify-center py-2.5"
          >
            {submitting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                Masuk <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>
          <p className="mt-2 text-center text-sm text-slate-500">
            Belum punya akun?{' '}
            <button
              type="button"
              onClick={() => switchMode('register')}
              className="font-semibold text-brand-600 hover:text-brand-700"
            >
              Daftar di sini
            </button>
          </p>
        </form>
      ) : (
        <form onSubmit={handleSignup} className="space-y-4">
          <div>
            <label className={labelClass} htmlFor="reg-name">
              Nama Lengkap <span className="font-normal text-slate-400">(opsional)</span>
            </label>
            <input
              id="reg-name"
              name="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nama Anda"
              className="input"
            />
          </div>
          <div>
            <label className={labelClass} htmlFor="reg-email">
              Email
            </label>
            <input
              id="reg-email"
              name="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              placeholder="nama@perusahaan.com"
              className="input"
            />
          </div>
          <div>
            <label className={labelClass} htmlFor="reg-password">
              Kata Sandi
            </label>
            <input
              id="reg-password"
              name="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
              placeholder="Minimal 6 karakter"
              className="input"
            />
          </div>
          <div>
            <label className={labelClass} htmlFor="reg-confirm">
              Konfirmasi Kata Sandi
            </label>
            <input
              id="reg-confirm"
              name="confirm"
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              autoComplete="new-password"
              placeholder="Ulangi kata sandi"
              className="input"
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="btn-primary w-full justify-center py-2.5"
          >
            {submitting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                Daftar Akun <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>
          <p className="mt-2 text-center text-sm text-slate-500">
            Sudah punya akun?{' '}
            <button
              type="button"
              onClick={() => switchMode('login')}
              className="font-semibold text-brand-600 hover:text-brand-700"
            >
              Masuk di sini
            </button>
          </p>
        </form>
      )}
    </div>
  );
}
