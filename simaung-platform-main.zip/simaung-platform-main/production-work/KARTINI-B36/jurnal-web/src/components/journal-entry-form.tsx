'use client';

import { useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Trash2, Save } from 'lucide-react';
import { cn } from '@/lib/utils';
import { AccountingError } from '@/lib/accounting';
import { formatIDR } from '@/lib/format';

interface Account {
  id: string;
  code: string;
  name: string;
  normal_balance: 'debit' | 'credit';
  report_section: string;
}

interface LineRow {
  accountId: string;
  debit: string;
  credit: string;
  description: string;
}

function emptyLine(): LineRow {
  return { accountId: '', debit: '', credit: '', description: '' };
}

export function JournalEntryForm({
  companyId,
  accounts,
}: {
  companyId: string;
  accounts: Account[];
}) {
  const router = useRouter();
  const operation = useRef<{payload: string; key: string} | null>(null);
  const [memo, setMemo] = useState('');
  const [entryDate, setEntryDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [lines, setLines] = useState<LineRow[]>([emptyLine()]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const totalDebit = useMemo(
    () => lines.reduce((s, l) => s + (parseFloat(l.debit) || 0), 0),
    [lines]
  );
  const totalCredit = useMemo(
    () => lines.reduce((s, l) => s + (parseFloat(l.credit) || 0), 0),
    [lines]
  );
  const balanced = Math.abs(totalDebit - totalCredit) < 0.009;

  function updateLine(idx: number, field: keyof LineRow, value: string) {
    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, [field]: value } : l)));
  }

  function addLine() {
    setLines((prev) => [...prev, emptyLine()]);
  }

  function removeLine(idx: number) {
    setLines((prev) => prev.filter((_, i) => i !== idx));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError(null);
    setLoading(true);

    const payloadLines = lines
      .filter((l) => l.accountId && (parseFloat(l.debit) || parseFloat(l.credit)))
      .map((l) => ({
        accountId: l.accountId,
        debit: parseFloat(l.debit) || 0,
        credit: parseFloat(l.credit) || 0,
        description: l.description || memo || undefined,
      }));

    if (payloadLines.length === 0) {
      setError('Tambahkan minimal satu baris dengan nilai.');
      setLoading(false);
      return;
    }

    try {
      const payload = {companyId, entryDate, memo: memo || undefined, source: 'manual', lines: payloadLines};
      const serialized = JSON.stringify(payload);
      if (operation.current?.payload !== serialized) operation.current = {payload: serialized, key: crypto.randomUUID()};
      const res = await fetch('/api/journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({...payload, idempotencyKey: operation.current.key}),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new AccountingError(data.error || 'Gagal posting jurnal');
      }
      router.push('/journal');
      router.refresh();
    } catch (e: any) {
      setError(e.message || 'Gagal posting jurnal');
      setLoading(false);
    }
  }

  const validAccounts = accounts.filter((a) => !a.code.includes('.')); // only non-header

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label className="label">Tanggal Jurnal</label>
          <input
            type="date"
            value={entryDate}
            onChange={(e) => setEntryDate(e.target.value)}
            className="input"
            required
          />
        </div>
        <div>
          <label className="label">Memo / Keterangan</label>
          <input
            type="text"
            value={memo}
            onChange={(e) => setMemo(e.target.value)}
            placeholder="contoh: Penjualan tunai"
            className="input"
          />
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="card-header">
          <h3 className="text-base font-semibold text-slate-900">Baris Jurnal</h3>
          <p className="text-xs text-slate-500">
            Setiap entri harus balance (total debit = total kredit)
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th className="w-16">#</th>
                <th>Akun</th>
                <th className="w-24">Debit</th>
                <th className="w-24">Kredit</th>
                <th>Deskripsi</th>
                <th className="w-10"></th>
              </tr>
            </thead>
            <tbody>
              {lines.map((line, idx) => (
                <tr key={idx}>
                  <td className="text-slate-400">{idx + 1}</td>
                  <td>
                    <select
                      value={line.accountId}
                      onChange={(e) => updateLine(idx, 'accountId', e.target.value)}
                      className="input"
                    >
                      <option value="">— Pilih Akun —</option>
                      {validAccounts.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.code} · {a.name}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={line.debit}
                      onChange={(e) => updateLine(idx, 'debit', e.target.value)}
                      placeholder="0"
                      className="input text-right"
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={line.credit}
                      onChange={(e) => updateLine(idx, 'credit', e.target.value)}
                      placeholder="0"
                      className="input text-right"
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      value={line.description}
                      onChange={(e) => updateLine(idx, 'description', e.target.value)}
                      placeholder="opsional"
                      className="input"
                    />
                  </td>
                  <td>
                    <button
                      type="button"
                      onClick={() => removeLine(idx)}
                      disabled={lines.length === 1}
                      className="text-slate-400 hover:text-red-500 disabled:opacity-30"
                      aria-label="hapus baris"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50">
                <td colSpan={2} className="px-3 py-2 text-right text-xs font-semibold uppercase text-slate-500">
                  Total
                </td>
                <td className="px-3 py-2 text-right font-bold text-slate-900">
                  {formatIDR(totalDebit)}
                </td>
                <td className="px-3 py-2 text-right font-bold text-slate-900">
                  {formatIDR(totalCredit)}
                </td>
                <td colSpan={2}></td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="flex items-center justify-between border-t border-slate-100 px-5 py-3">
          <button type="button" onClick={addLine} className="btn-secondary">
            <Plus className="h-4 w-4" /> Tambah Baris
          </button>
          <div
            className={cn(
              'text-sm font-medium',
              balanced ? 'text-emerald-600' : 'text-red-600'
            )}
          >
            {balanced ? '✓ Balanced' : `Selisih: ${formatIDR(totalDebit - totalCredit)}`}
          </div>
        </div>
      </div>

      {error && (
        <div className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-600">{error}</div>
      )}

      <div className="flex items-center gap-3">
        <button type="submit" disabled={loading || !balanced} className="btn-primary">
          <Save className="h-4 w-4" />
          {loading ? 'Menyimpan…' : 'Posting Jurnal'}
        </button>
        <button
          type="button"
          onClick={() => router.back()}
          className="btn-secondary"
          disabled={loading}
        >
          Batal
        </button>
      </div>
    </form>
  );
}
