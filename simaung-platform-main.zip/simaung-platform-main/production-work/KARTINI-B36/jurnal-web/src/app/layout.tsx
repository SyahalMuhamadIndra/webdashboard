import Script from 'next/script';
import { MaintenanceGuard } from '@/components/maintenance-guard';
import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Laporan Simaung Corporation — Akuntansi & Jurnal Keuangan',
  description:
    'Platform jurnal dan laporan keuangan double-entry. Kledo-like accounting & ERP.',
  manifest: '/manifest.webmanifest',
  appleWebApp: { capable: true, title: 'Simaung Jurnal', statusBarStyle: 'black-translucent' },
  icons: {
    icon: '/logo.png',
    shortcut: '/logo.png',
    apple: '/logo.png',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        <MaintenanceGuard />{children}
        <Script src="/simaung-fullscreen.js?v=1" strategy="afterInteractive" />
      </body>
    </html>
  );
}
