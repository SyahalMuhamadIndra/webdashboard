'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import {
  createInvoiceAndPost,
  createBillAndPost,
  createCustomerPayment,
  createSupplierPayment,
  createExpense,
  createStockAdjustment,
  createFixedAsset,
} from '@/lib/odoo';

// ---- Invoice (Penjualan) ---------------------------------------------------

export async function createInvoice(formData: FormData) {
  return withErpFormAction('createInvoice', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const customer_id = String(formData.get('customer_id') || '');
  const invoice_date = String(formData.get('invoice_date') || '');
  const isCash = formData.get('is_cash_sale') === 'on';
  const desc = String(formData.get('desc') || '');
  const qty = Number(formData.get('qty') || 0);
  const price = Number(formData.get('price') || 0);

  if (!customer_id || !invoice_date || qty <= 0) throw new Error('Data invoice belum lengkap.');

  await createInvoiceAndPost(companyId, {
    customer_id,
    invoice_date,
    due_date: String(formData.get('due_date') || '') || undefined,
    is_cash_sale: isCash,
    items: [{ product_id: undefined, description: desc || 'Penjualan', quantity: qty, unit_price: price, discount: Number(formData.get('discount') || 0) }],
  });

  revalidatePath('/sales/invoices');

  });
}

export async function createBill(formData: FormData) {
  return withErpFormAction('createBill', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const supplier_id = String(formData.get('supplier_id') || '');
  const bill_date = String(formData.get('bill_date') || '');
  const desc = String(formData.get('desc') || '');
  const qty = Number(formData.get('qty') || 0);
  const price = Number(formData.get('price') || 0);

  if (!supplier_id || !bill_date || qty <= 0) throw new Error('Data bill belum lengkap.');

  await createBillAndPost(companyId, {
    supplier_id,
    bill_date,
    due_date: String(formData.get('due_date') || '') || undefined,
    items: [{ product_id: undefined, description: desc || 'Pembelian', quantity: qty, unit_price: price, discount: Number(formData.get('discount') || 0) }],
  });

  revalidatePath('/purchase/bills');

  });
}

export async function createPayment(formData: FormData) {
  return withErpFormAction('createPayment', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const direction = String(formData.get('direction') || 'in');
  const amount = Number(formData.get('amount') || 0);
  const payment_date = String(formData.get('payment_date') || '');
  if (amount <= 0) throw new Error('Nominal pembayaran salah.');

  if (direction === 'in') {
    const customer_id = String(formData.get('customer_id') || '');
    const receivable_id = String(formData.get('receivable_id') || '') || undefined;
    await createCustomerPayment(companyId, { customer_id, amount, payment_date, receivable_id });
  } else {
    const supplier_id = String(formData.get('supplier_id') || '');
    const payable_id = String(formData.get('payable_id') || '') || undefined;
    await createSupplierPayment(companyId, { supplier_id, amount, payment_date, payable_id });
  }
  revalidatePath('/payments');
  revalidatePath('/ar');
  revalidatePath('/ap');

  });
}

export async function createExpenseAction(formData: FormData) {
  return withErpFormAction('createExpenseAction', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const amount = Number(formData.get('amount') || 0);
  const expense_date = String(formData.get('expense_date') || '');
  const expense_account_id = String(formData.get('expense_account_id') || '');
  const memo = String(formData.get('memo') || '');
  if (amount <= 0) throw new Error('Nominal beban salah.');

  await createExpense(companyId, {
    expense_date, amount, memo, expense_account_id,
  });
  revalidatePath('/expenses');
  revalidatePath('/journal');

  });
}

export async function createStockAdjustmentAction(formData: FormData) {
  return withErpFormAction('createStockAdjustmentAction', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const product_id = String(formData.get('product_id') || '');
  const warehouse_id = String(formData.get('warehouse_id') || '');
  const quantity = Number(formData.get('quantity') || 0);
  const unit_cost = Number(formData.get('unit_cost') || 0);
  const memo = String(formData.get('memo') || '');
  if (!product_id || !warehouse_id) throw new Error('Pilih produk dan gudang.');

  await createStockAdjustment(companyId, { product_id, warehouse_id, quantity, unit_cost, memo });
  revalidatePath('/inventory');

  });
}

export async function createAsset(formData: FormData) {
  return withErpFormAction('createAsset', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const name = String(formData.get('name') || '');
  const acquisition_date = String(formData.get('acquisition_date') || '');
  const acquisition_cost = Number(formData.get('acquisition_cost') || 0);
  if (!name || !acquisition_date) throw new Error('Nama dan tanggal aset wajib diisi.');

  await createFixedAsset(companyId, {
    name,
    category: String(formData.get('category') || '') || undefined,
    acquisition_date,
    acquisition_cost,
    salvage_value: Number(formData.get('salvage_value') || 0),
    useful_life_months: Number(formData.get('useful_life_months') || 60),
    depreciation_method: String(formData.get('depreciation_method') || 'straight_line'),
  });
  revalidatePath('/assets');

  });
}
