'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import { createAdminClient } from '@/lib/supabase/admin';
import {
  createAccount,
  createCustomer,
  createSupplier,
  createProduct,
} from '@/lib/odoo';

// ---- Chart of Accounts -----------------------------------------------------

export async function createNewAccount(formData: FormData) {
  return withErpFormAction('createNewAccount', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const code = String(formData.get('code') || '');
  const name = String(formData.get('name') || '');
  const type_of_account_id = String(formData.get('type_of_account_id') || '');
  const is_header = formData.get('is_header') === 'on';
  const is_cash = formData.get('is_cash') === 'on';
  const is_bank = formData.get('is_bank') === 'on';
  const is_receivable = formData.get('is_receivable') === 'on';
  const is_payable = formData.get('is_payable') === 'on';
  const is_inventory = formData.get('is_inventory') === 'on';

  if (!companyId || !code || !name || !type_of_account_id) {
    throw new Error('Kode, nama, dan tipe akun wajib diisi.');
  }

  await createAccount(companyId, {
    code, name, type_of_account_id,
    is_header, is_cash, is_bank, is_receivable, is_payable, is_inventory,
    is_active: true,
  });

  revalidatePath('/master/accounts');

  });
}

export async function toggleAccountActive(formData: FormData) {
  return withErpFormAction('toggleAccountActive', formData, async () => {
  await requireServiceAvailable();

  const id = String(formData.get('id') || '');
  const is_active = formData.get('is_active') === 'true';
  const s = createAdminClient();
  await s.from('accounts').update({ is_active: !is_active }).eq('id', id);
  revalidatePath('/master/accounts');

  });
}

// ---- Customers -------------------------------------------------------------

export async function createNewCustomer(formData: FormData) {
  return withErpFormAction('createNewCustomer', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const name = String(formData.get('name') || '');
  if (!companyId || !name) throw new Error('Nama pelanggan wajib diisi.');

  await createCustomer(companyId, {
    name,
    customer_type: String(formData.get('customer_type') || 'customer'),
    tax_id: String(formData.get('tax_id') || '') || undefined,
    phone: String(formData.get('phone') || '') || undefined,
    email: String(formData.get('email') || '') || undefined,
    address: String(formData.get('address') || '') || undefined,
    credit_limit: Number(formData.get('credit_limit') || 0),
    term_days: Number(formData.get('term_days') || 0),
  });

  revalidatePath('/master/customers');

  });
}

// ---- Suppliers -------------------------------------------------------------

export async function createNewSupplier(formData: FormData) {
  return withErpFormAction('createNewSupplier', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const name = String(formData.get('name') || '');
  if (!companyId || !name) throw new Error('Nama pemasok wajib diisi.');

  await createSupplier(companyId, {
    name,
    tax_id: String(formData.get('tax_id') || '') || undefined,
    phone: String(formData.get('phone') || '') || undefined,
    email: String(formData.get('email') || '') || undefined,
    address: String(formData.get('address') || '') || undefined,
    term_days: Number(formData.get('term_days') || 0),
  });

  revalidatePath('/master/suppliers');

  });
}

// ---- Products --------------------------------------------------------------

export async function createNewProduct(formData: FormData) {
  return withErpFormAction('createNewProduct', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const name = String(formData.get('name') || '');
  if (!companyId || !name) throw new Error('Nama produk wajib diisi.');

  await createProduct(companyId, {
    name,
    sku: String(formData.get('sku') || '') || undefined,
    category_id: String(formData.get('category_id') || '') || undefined,
    unit_id: String(formData.get('unit_id') || '') || undefined,
    description: String(formData.get('description') || '') || undefined,
    barcode: String(formData.get('barcode') || '') || undefined,
    cost_method: String(formData.get('cost_method') || 'average'),
    is_track_inventory: formData.get('is_track_inventory') !== 'off',
  });

  revalidatePath('/master/products');

  });
}

// ---- Tax rates -------------------------------------------------------------

export async function createNewTaxRate(formData: FormData) {
  return withErpFormAction('createNewTaxRate', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const name = String(formData.get('name') || '');
  const rate = Number(formData.get('rate') || 0);
  if (!companyId || !name) throw new Error('Nama pajak wajib diisi.');

  const s = createAdminClient();
  const { error } = await s.from('tax_rates').insert({
    company_id: companyId, name, rate, is_active: true,
  });
  if (error) throw new Error(error.message);
  revalidatePath('/master/taxes');

  });
}

// ---- Categories / Units placeholder ---------------------------------------

export async function createNewCategory(formData: FormData) {
  return withErpFormAction('createNewCategory', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const name = String(formData.get('name') || '');
  if (!companyId || !name) throw new Error('Nama kategori wajib diisi.');
  const s = createAdminClient();
  await s.from('categories').insert({ company_id: companyId, name });
  revalidatePath('/master/products');

  });
}

export async function createNewUnit(formData: FormData) {
  return withErpFormAction('createNewUnit', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const name = String(formData.get('name') || '');
  const code = String(formData.get('code') || '');
  if (!companyId || !name || !code) throw new Error('Nama & kode satuan wajib diisi.');
  const s = createAdminClient();
  await s.from('units').insert({ company_id: companyId, name, code });
  revalidatePath('/master/products');

  });
}
