'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import { assignRole, toggleUserActive } from '@/lib/users';

export async function assignRoleAction(formData: FormData) {
  return withErpFormAction('assignRoleAction', formData, async () => {
  await requireServiceAvailable();

  const userId = String(formData.get('userId') || '');
  const roleId = String(formData.get('roleId') || '');
  const enabled = formData.get('enabled') === 'true';
  await assignRole(userId, roleId, enabled);
  revalidatePath('/settings/users');

  });
}

export async function toggleUserActiveAction(formData: FormData) {
  return withErpFormAction('toggleUserActiveAction', formData, async () => {
  await requireServiceAvailable();

  const userId = String(formData.get('userId') || '');
  const isActive = formData.get('isActive') === 'true';
  await toggleUserActive(userId, isActive);
  revalidatePath('/settings/users');

  });
}
