'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import { createRole, togglePermission, deleteRole } from '@/lib/rbac';

export async function addRole(formData: FormData) {
  return withErpFormAction('addRole', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createRole(companyId, {
    name: String(formData.get('name') || ''),
    description: String(formData.get('description') || '') || undefined,
  });
  revalidatePath('/settings/roles');

  });
}

export async function togglePermissionAction(formData: FormData) {
  return withErpFormAction('togglePermissionAction', formData, async () => {
  await requireServiceAvailable();

  const roleId = String(formData.get('roleId') || '');
  const permissionId = String(formData.get('permissionId') || '');
  const enabled = formData.get('enabled') === 'true';
  await togglePermission(roleId, permissionId, enabled);
  revalidatePath('/settings/roles');

  });
}

export async function removeRole(formData: FormData) {
  return withErpFormAction('removeRole', formData, async () => {
  await requireServiceAvailable();

  const roleId = String(formData.get('roleId') || '');
  await deleteRole(roleId);
  revalidatePath('/settings/roles');

  });
}
