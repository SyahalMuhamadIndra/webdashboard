'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import { createDeferred, recognizeDueDeferred, deactivateDeferred } from '@/lib/deferred';

export async function addDeferred(formData: FormData) {
  return withErpFormAction('addDeferred', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createDeferred(companyId, {
    kind: (String(formData.get('kind') || 'revenue') as 'revenue' | 'expense'),
    ref_number: String(formData.get('ref_number') || '') || undefined,
    total_amount: Number(formData.get('total_amount') || 0),
    start_date: String(formData.get('start_date') || ''),
    end_date: String(formData.get('end_date') || ''),
    interval_type: String(formData.get('interval_type') || 'monthly'),
    target_account_id: String(formData.get('target_account_id') || '') || undefined,
  });
  revalidatePath('/reports/deferred');

  });
}

export async function runRecognition(formData: FormData) {
  return withErpFormAction('runRecognition', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await recognizeDueDeferred(companyId);
  revalidatePath('/reports/deferred');
  revalidatePath('/journal');
  revalidatePath('/reports/income-statement');
  revalidatePath('/reports/balance-sheet');

  });
}

export async function disableDeferred(formData: FormData) {
  return withErpFormAction('disableDeferred', formData, async () => {
  await requireServiceAvailable();

  const id = String(formData.get('id') || '');
  await deactivateDeferred(id);
  revalidatePath('/reports/deferred');

  });
}
