'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import { createAdminClient } from '@/lib/supabase/admin';
import {
  ensureFiscalPeriods,
  closeFiscalPeriod,
  createStockOpname,
  upsertSetting,
  markNotificationRead,
} from '@/lib/ops';

// ---- Fiscal periods / closing ---------------------------------------------
export async function generatePeriods(formData: FormData) {
  return withErpFormAction('generatePeriods', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const year = Number(formData.get('year') || 0);
  if (!companyId || !year) throw new Error('Perusahaan & tahun wajib diisi.');
  await ensureFiscalPeriods(companyId, year);
  revalidatePath('/reports/closing');

  });
}

export async function closePeriod(formData: FormData) {
  return withErpFormAction('closePeriod', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const periodId = String(formData.get('periodId') || '');
  if (!periodId) throw new Error('Periode tidak dipilih.');
  await closeFiscalPeriod(companyId, periodId);
  revalidatePath('/reports/closing');

  });
}

// ---- Stock opname ---------------------------------------------------------
export async function createOpname(formData: FormData) {
  return withErpFormAction('createOpname', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const warehouse_id = String(formData.get('warehouse_id') || '');
  const opname_number = String(formData.get('opname_number') || '');
  const opname_date = String(formData.get('opname_date') || '');
  if (!warehouse_id || !opname_number) throw new Error('Gudang & nomor opname wajib diisi.');

  // One line per product with posted actual_qty; simplest: use qty fields.
  const products = formData.getAll('product_id');
  const qtys = formData.getAll('actual_qty');
  const lines = products.map((pid, i) => ({ product_id: String(pid), actual_qty: Number(qtys[i] || 0) }));

  await createStockOpname(companyId, warehouse_id, opname_number, opname_date, lines);
  revalidatePath('/inventory/opname');

  });
}

// ---- Settings -------------------------------------------------------------
export async function saveSetting(formData: FormData) {
  return withErpFormAction('saveSetting', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const key = String(formData.get('key') || '');
  const value = String(formData.get('value') || '');
  if (!key) throw new Error('Key pengaturan wajib diisi.');
  await upsertSetting(companyId, key, value);
  revalidatePath('/settings');

  });
}

// ---- Notifications --------------------------------------------------------
export async function readNotification(formData: FormData) {
  return withErpFormAction('readNotification', formData, async () => {
  await requireServiceAvailable();

  const id = String(formData.get('id') || '');
  if (id) {
    await markNotificationRead(id);
    revalidatePath('/notifications');
  }

  });
}
