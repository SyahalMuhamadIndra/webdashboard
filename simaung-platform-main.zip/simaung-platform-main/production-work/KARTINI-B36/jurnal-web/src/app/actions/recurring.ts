'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import { createRecurring, processDueRecurring, deactivateRecurring } from '@/lib/recurring';

export async function addRecurring(formData: FormData) {
  return withErpFormAction('addRecurring', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const product_id = String(formData.get('product_id') || '') || undefined;
  const qty = Number(formData.get('quantity') || 0);
  const price = Number(formData.get('unit_price') || 0);
  const interval = String(formData.get('interval_type') || 'monthly');
  await createRecurring(companyId, {
    customer_id: String(formData.get('customer_id') || '') || undefined,
    description: String(formData.get('description') || 'Langganan'),
    interval_type: interval,
    start_date: String(formData.get('start_date') || '') || undefined,
    next_run_date: String(formData.get('start_date') || '') || undefined,
    lines: [{ product_id, description: String(formData.get('desc') || 'Item langganan'), quantity: qty, unit_price: price }],
  });
  revalidatePath('/sales/recurring');

  });
}

export async function runRecurringNow(formData: FormData) {
  return withErpFormAction('runRecurringNow', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await processDueRecurring(companyId);
  revalidatePath('/sales/recurring');
  revalidatePath('/sales/invoices');

  });
}

export async function disableRecurring(formData: FormData) {
  return withErpFormAction('disableRecurring', formData, async () => {
  await requireServiceAvailable();

  const id = String(formData.get('id') || '');
  await deactivateRecurring(id);
  revalidatePath('/sales/recurring');

  });
}
