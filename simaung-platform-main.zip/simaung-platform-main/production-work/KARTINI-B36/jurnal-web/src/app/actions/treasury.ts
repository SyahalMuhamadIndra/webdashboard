'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import { createBankAccount, createCashAccount } from '@/lib/treasury';

export async function addBankAccount(formData: FormData) {
  return withErpFormAction('addBankAccount', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createBankAccount(companyId, {
    bank_name: String(formData.get('bank_name') || ''),
    account_number: String(formData.get('account_number') || '') || undefined,
    account_name: String(formData.get('account_name') || '') || undefined,
    currency: String(formData.get('currency') || 'IDR'),
    opening_balance: Number(formData.get('opening_balance') || 0),
  });
  revalidatePath('/finance');

  });
}

export async function addCashAccount(formData: FormData) {
  return withErpFormAction('addCashAccount', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createCashAccount(companyId, {
    name: String(formData.get('name') || ''),
    currency: String(formData.get('currency') || 'IDR'),
    opening_balance: Number(formData.get('opening_balance') || 0),
  });
  revalidatePath('/finance');

  });
}
