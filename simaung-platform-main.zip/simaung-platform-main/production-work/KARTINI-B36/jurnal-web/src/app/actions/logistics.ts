'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import { createBranch, createProjectTask, updateTaskStatus } from '@/lib/logistics';

export async function addBranch(formData: FormData) {
  return withErpFormAction('addBranch', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createBranch(companyId, {
    code: String(formData.get('code') || ''),
    name: String(formData.get('name') || ''),
    address: String(formData.get('address') || '') || undefined,
    phone: String(formData.get('phone') || '') || undefined,
    email: String(formData.get('email') || '') || undefined,
  });
  revalidatePath('/master/branches');

  });
}

export async function addTask(formData: FormData) {
  return withErpFormAction('addTask', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createProjectTask(companyId, {
    project_id: String(formData.get('project_id') || '') || undefined,
    title: String(formData.get('title') || ''),
    status: String(formData.get('status') || 'todo'),
    priority: String(formData.get('priority') || 'normal'),
    due_date: String(formData.get('due_date') || '') || undefined,
  });
  revalidatePath('/projects/tasks');

  });
}

export async function changeTaskStatus(formData: FormData) {
  return withErpFormAction('changeTaskStatus', formData, async () => {
  await requireServiceAvailable();

  const id = String(formData.get('id') || '');
  const status = String(formData.get('status') || 'todo');
  await updateTaskStatus(id, status);
  revalidatePath('/projects/tasks');

  });
}
