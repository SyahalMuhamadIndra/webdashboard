'use server';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { accountingPost } from '@/lib/accounting-api';
import { SESSION_COOKIE, signSession } from '@/lib/session';

// ============================================================
// Auth terpadu. Login diverifikasi ke backend bersama
// (api.tokokartini.com /admin/login). Sesi disimpan di cookie
// bertanda-tangan (HMAC). Tidak memakai Supabase.
// ============================================================

const COOKIE_OPTS = {
  httpOnly: true as const,
  sameSite: 'lax' as const,
  secure: true,
  path: '/',
  maxAge: 60 * 60 * 24 * 7,
};

export async function login(formData: FormData) {
  await requireServiceAvailable();

  const email = String(formData.get('email') || '').trim();
  const password = String(formData.get('password') || '');

  if (!email || !password) {
    redirect('/login?error=' + encodeURIComponent('Email dan kata sandi wajib diisi.'));
  }

  try {
    const res = await accountingPost<{
      token?: string;
      name?: string;
      email?: string;
      role?: string;
      companyId?: string;
    }>('/admin/login', { email, password });

    if (!res?.token) {
      redirect('/login?error=' + encodeURIComponent('Email atau kata sandi salah.'));
    }

    const sessionValue = await signSession({
      backendToken: res.token,
      email: res.email || email,
      name: res.name || email.split('@')[0],
      role: res.role || 'ADMIN',
      companyId: res.companyId || '',
    });

    const store = await cookies();
    store.set(SESSION_COOKIE, sessionValue, COOKIE_OPTS);
  } catch (e: any) {
    // Next.js redirect throws — biarkan diteruskan.
    if (e && typeof e.digest === 'string' && e.digest.startsWith('NEXT_REDIRECT')) throw e;
    const msg =
      e?.status === 401 || e?.status === 400
        ? 'Email atau kata sandi salah.'
        : 'Gagal menghubungi server. Coba lagi.';
    redirect('/login?error=' + encodeURIComponent(msg));
  }

  revalidatePath('/', 'layout');
  redirect('/dashboard');
}

export async function logout() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
  revalidatePath('/', 'layout');
  redirect('/login');
}

// ------------------------------------------------------------
// REGISTRASI akun baru (self-service) — tetap SATU backend.
// Memanggil POST /admin/register di server terpadu, lalu sesi
// cookie HMAC dibuat & user langsung diarahkan ke dashboard.
// ------------------------------------------------------------
export async function register(formData: FormData) {
  await requireServiceAvailable();

  const name = String(formData.get('name') || '').trim();
  const email = String(formData.get('email') || '').trim();
  const password = String(formData.get('password') || '');

  if (!name || !email || !password) {
    redirect('/login?error=' + encodeURIComponent('Nama, email, dan kata sandi wajib diisi.'));
  }
  if (password.length < 6) {
    redirect('/login?error=' + encodeURIComponent('Kata sandi minimal 6 karakter.'));
  }

  try {
    const res = await accountingPost<{
      token?: string;
      name?: string;
      email?: string;
      role?: string;
      companyId?: string;
      pending?: boolean;
      message?: string;
    }>('/admin/register', { name, email, password });

    // Akun baru berstatus PENDING: menunggu persetujuan Superadmin.
    // Tidak ada token & tidak auto-login — arahkan ke info "menunggu persetujuan".
    if (res?.pending) {
      const info = res.message || 'Pendaftaran berhasil. Akun menunggu persetujuan Superadmin.';
      redirect('/login?message=' + encodeURIComponent(info) + '&pending=1');
    }

    // Fallback bila (kelak) backend langsung mengembalikan token.
    if (!res?.token) {
      redirect('/login?error=' + encodeURIComponent('Pendaftaran gagal. Coba lagi.'));
    }

    const sessionValue = await signSession({
      backendToken: res.token,
      email: res.email || email,
      name: res.name || name,
      role: res.role || 'MANAGER',
      companyId: res.companyId || '',
    });

    const store = await cookies();
    store.set(SESSION_COOKIE, sessionValue, COOKIE_OPTS);
  } catch (e: any) {
    if (e && typeof e.digest === 'string' && e.digest.startsWith('NEXT_REDIRECT')) throw e;
    const msg =
      e?.status === 409
        ? 'Email sudah terdaftar. Silakan masuk.'
        : e?.status === 400
          ? 'Data pendaftaran tidak valid. Periksa kembali.'
          : 'Gagal menghubungi server. Coba lagi.';
    redirect('/login?error=' + encodeURIComponent(msg));
  }

  revalidatePath('/', 'layout');
  redirect('/dashboard');
}

// Tidak dipakai lagi (registrasi mandiri dinonaktifkan pada arsitektur terpadu).
export async function createUserProfile(_input: {
  userId: string;
  email: string;
  name?: string;
}) {
  await requireServiceAvailable();

  return;
}
