'use server';
import {withErpFormAction, withErpTransaction} from '@/lib/erp/runtime';
import { requireServiceAvailable } from '@/lib/maintenance-server';


import { revalidatePath } from 'next/cache';
import {
  createQuotation, createPurchaseOrder, createDelivery, createReceipt, createTransfer,
  createCurrency, createBudget, createOpportunity, createProject, createReconciliation, createDunning,
  convertQuotationToInvoice, convertPurchaseOrderToBill,
} from '@/lib/modules';

export async function addQuotation(formData: FormData) {
  return withErpFormAction('addQuotation', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const product_id = String(formData.get('product_id') || '') || undefined;
  const qty = Number(formData.get('quantity') || 0);
  const price = Number(formData.get('unit_price') || 0);
  await createQuotation(companyId, { customer_id: String(formData.get('customer_id') || '') || undefined, lines: [{ product_id, description: String(formData.get('desc') || 'Penawaran'), quantity: qty, unit_price: price }] });
  revalidatePath('/sales/quotations');

  });
}

export async function addPurchaseOrder(formData: FormData) {
  return withErpFormAction('addPurchaseOrder', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const product_id = String(formData.get('product_id') || '') || undefined;
  const qty = Number(formData.get('quantity') || 0);
  const price = Number(formData.get('unit_price') || 0);
  await createPurchaseOrder(companyId, { supplier_id: String(formData.get('supplier_id') || '') || undefined, lines: [{ product_id, description: String(formData.get('desc') || 'PO'), quantity: qty, unit_price: price }] });
  revalidatePath('/purchase/orders');

  });
}

export async function addDelivery(formData: FormData) {
  return withErpFormAction('addDelivery', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const product_id = String(formData.get('product_id') || '');
  const qty = Number(formData.get('quantity') || 0);
  await createDelivery(companyId, { warehouse_id: String(formData.get('warehouse_id') || '') || undefined, lines: [{ product_id, quantity: qty }] });
  revalidatePath('/inventory/transfers');

  });
}

export async function addReceipt(formData: FormData) {
  return withErpFormAction('addReceipt', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const product_id = String(formData.get('product_id') || '');
  const qty = Number(formData.get('quantity') || 0);
  await createReceipt(companyId, { warehouse_id: String(formData.get('warehouse_id') || '') || undefined, lines: [{ product_id, quantity: qty }] });
  revalidatePath('/inventory/transfers');

  });
}

export async function addTransfer(formData: FormData) {
  return withErpFormAction('addTransfer', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const product_id = String(formData.get('product_id') || '');
  const qty = Number(formData.get('quantity') || 0);
  await createTransfer(companyId, { from_warehouse_id: String(formData.get('from_warehouse_id') || '') || undefined, to_warehouse_id: String(formData.get('to_warehouse_id') || '') || undefined, lines: [{ product_id, quantity: qty }] });
  revalidatePath('/inventory/transfers');

  });
}

export async function addCurrency(formData: FormData) {
  return withErpFormAction('addCurrency', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createCurrency(companyId, { code: String(formData.get('code') || ''), name: String(formData.get('name') || ''), symbol: String(formData.get('symbol') || '') || undefined, rate: Number(formData.get('rate') || 1) });
  revalidatePath('/master/currencies');

  });
}

export async function addBudget(formData: FormData) {
  return withErpFormAction('addBudget', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const account_id = String(formData.get('account_id') || '');
  const amount = Number(formData.get('amount') || 0);
  await createBudget(companyId, { name: String(formData.get('name') || ''), fiscal_year: Number(formData.get('fiscal_year') || 0), lines: [{ account_id, amount }] });
  revalidatePath('/reports/budget');

  });
}

export async function addOpportunity(formData: FormData) {
  return withErpFormAction('addOpportunity', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createOpportunity(companyId, { title: String(formData.get('title') || ''), customer_id: String(formData.get('customer_id') || '') || undefined, expected_amount: Number(formData.get('expected_amount') || 0), probability: Number(formData.get('probability') || 0), stage: String(formData.get('stage') || 'new') });
  revalidatePath('/crm');

  });
}

export async function addProject(formData: FormData) {
  return withErpFormAction('addProject', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createProject(companyId, { name: String(formData.get('name') || ''), description: String(formData.get('description') || '') || undefined });
  revalidatePath('/projects');

  });
}

export async function addReconciliation(formData: FormData) {
  return withErpFormAction('addReconciliation', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createReconciliation(companyId, { bank_account_id: String(formData.get('bank_account_id') || '') || undefined, statement_balance: Number(formData.get('statement_balance') || 0), book_balance: Number(formData.get('book_balance') || 0), notes: String(formData.get('notes') || '') || undefined });
  revalidatePath('/reports/bank-reconciliation');

  });
}

export async function convertQuotationToInvoiceAction(formData: FormData) {
  return withErpFormAction('convertQuotationToInvoiceAction', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const quotationId = String(formData.get('quotationId') || '');
  await convertQuotationToInvoice(companyId, quotationId);
  revalidatePath('/sales/quotations');
  revalidatePath('/sales/invoices');

  });
}

export async function convertPurchaseOrderToBillAction(formData: FormData) {
  return withErpFormAction('convertPurchaseOrderToBillAction', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  const poId = String(formData.get('poId') || '');
  await convertPurchaseOrderToBill(companyId, poId);
  revalidatePath('/purchase/orders');
  revalidatePath('/purchase/bills');

  });
}

export async function addDunning(formData: FormData) {
  return withErpFormAction('addDunning', formData, async () => {
  await requireServiceAvailable();

  const companyId = String(formData.get('companyId') || '');
  await createDunning(companyId, { name: String(formData.get('name') || ''), days_overdue: Number(formData.get('days_overdue') || 0), fee: Number(formData.get('fee') || 0), template: String(formData.get('template') || '') || undefined });
  revalidatePath('/reports/dunning');

  });
}
