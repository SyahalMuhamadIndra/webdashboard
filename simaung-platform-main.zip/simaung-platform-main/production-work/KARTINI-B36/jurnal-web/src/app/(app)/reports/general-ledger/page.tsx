import Link from 'next/link';
import { getGeneralLedger, getAccounts } from '@/lib/reports';
import { getDefaultCompany } from '@/lib/company';
import { monthStartISO, monthEndISO } from '@/lib/format';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { AccountSelector } from '@/components/account-selector';

export const dynamic = 'force-dynamic';

export default async function GeneralLedgerPage({
  searchParams,
}: {
  searchParams?: Promise<{ account_id?: string }>;
}) {
  const query = await searchParams;
  const company = await getDefaultCompany();
  const from = monthStartISO();
  const to = monthEndISO();

  let accounts: { id: string; code: string; name: string }[] = [];
  try {
    const all = await getAccounts(company.id);
    accounts = all.map((a) => ({ id: a.id, code: a.code, name: a.name }));
  } catch (e: any) {
    return (
      <div className="text-center py-20 text-slate-500">Gagal memuat akun: {e?.message}</div>
    );
  }

  const accountId = query?.account_id || (accounts && accounts[0]?.id);
  let ledger: Awaited<ReturnType<typeof getGeneralLedger>> | null = null;
  let ledgerError: string | null = null;

  if (accountId) {
    try {
      ledger = await getGeneralLedger(company.id, accountId, from, to);
    } catch (e: any) {
      ledgerError = e.message || 'Terjadi kesalahan';
    }
  }

  return (
    <ReportShell
      title="Buku Besar (General Ledger)"
      subtitle={`${company.name} · Periode ${from} s/d ${to}`}
      backHref="/dashboard"
    >
      <Card>
        <CardHeader title="Pilih Akun" />
        <div className="p-5">
          <AccountSelector
            accounts={accounts as { id: string; code: string; name: string }[]}
            currentId={accountId}
            basePath="/reports/general-ledger"
          />
        </div>
      </Card>

      {ledger && !ledgerError && (
        <Card>
          <CardHeader
            title={`${ledger.account.code} · ${ledger.account.name}`}
            subtitle={`${ledger.rows.length} mutasi · Saldo normal: ${ledger.account.normalBalance}`}
          />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Tanggal</th>
                  <th>No. Jurnal</th>
                  <th>Keterangan</th>
                  <th className="text-right">Debit</th>
                  <th className="text-right">Kredit</th>
                  <th className="text-right">Saldo</th>
                </tr>
              </thead>
              <tbody>
                {ledger.rows.map((r, idx) => (
                  <tr key={idx}>
                    <td className="whitespace-nowrap">{r.date}</td>
                    <td className="font-mono text-xs text-brand-600">{r.entryNumber}</td>
                    <td className="max-w-xs truncate">{r.memo || '-'}</td>
                    <td className="text-right">
                      {r.debit !== 0 ? <MoneyCell value={r.debit} /> : '-'}
                    </td>
                    <td className="text-right">
                      {r.credit !== 0 ? <MoneyCell value={r.credit} /> : '-'}
                    </td>
                    <td className="text-right font-semibold">
                      <MoneyCell value={r.balance} />
                    </td>
                  </tr>
                ))}
                {ledger.rows.length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400">
                      Tidak ada mutasi pada periode ini.
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr className="bg-slate-50">
                  <td colSpan={3} className="px-3 py-3 text-right text-xs uppercase text-slate-500">
                    Total
                  </td>
                  <td className="px-3 py-3 text-right">
                    <MoneyCell value={ledger.totalDebit} />
                  </td>
                  <td className="px-3 py-3 text-right">
                    <MoneyCell value={ledger.totalCredit} />
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </Card>
      )}

      {ledgerError && (
        <div className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-600">
          {ledgerError}
        </div>
      )}
    </ReportShell>
  );
}
