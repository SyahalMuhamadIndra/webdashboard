import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listTaxRates } from '@/lib/odoo';
import { createNewTaxRate } from '@/app/actions/master';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function MasterTaxesPage() {
  const company = await getDefaultCompany();
  const taxes = await listTaxRates(company.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Tarif Pajak</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {taxes.length} tarif</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Pajak" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Nama</th>
                  <th className="text-right">Tarif (%)</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {(taxes || []).map((t: any) => (
                  <tr key={t.id}>
                    <td className="font-medium text-slate-800">{t.name}</td>
                    <td className="text-right">{t.rate}%</td>
                    <td>
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${t.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                        {t.is_active ? 'Aktif' : 'Nonaktif'}
                      </span>
                    </td>
                  </tr>
                ))}
                {(!taxes || taxes.length === 0) && (
                  <tr><td colSpan={3} className="py-12 text-center text-slate-400">Belum ada tarif pajak.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Tambah Pajak" />
          <form action={createNewTaxRate} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Nama</label><input className="input" name="name" placeholder="PPN 11%" required /></div>
            <div><label className="label">Tarif (%)</label><input className="input" name="rate" type="number" step="0.01" defaultValue="11" required /></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan Pajak</button>
          </form>
        </Card>
      </div>
    </div>
  );
}
