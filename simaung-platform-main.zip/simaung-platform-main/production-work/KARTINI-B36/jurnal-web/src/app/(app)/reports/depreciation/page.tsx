import { getDefaultCompany } from '@/lib/company';
import { listDepreciationSchedule } from '@/lib/depreciation';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

const METHOD_LABEL: Record<string, string> = {
  straight_line: 'Straight Line',
  declining: 'Declining Balance',
};

export default async function DepreciationPage() {
  const company = await getDefaultCompany();
  const assets = await listDepreciationSchedule(company.id, 12);

  const monthlyTotal = assets.reduce((s, a) => s + a.monthlyDep, 0);

  return (
    <ReportShell
      title="Jadwal Penyusutan"
      subtitle={`${company.name} · ${assets.length} aset · proyeksi 12 bulan`}
      backHref="/assets"
    >
      <Card>
        <CardHeader
          title="Ringkasan Penyusutan"
          subtitle="Estimasi beban penyusutan bulanan (straight-line / declining)"
        />
        <div className="grid grid-cols-1 gap-4 px-5 pb-5 sm:grid-cols-3">
          <div className="rounded-lg bg-slate-50 p-4">
            <div className="text-xs font-medium text-slate-500">Total Aset</div>
            <div className="mt-1 text-xl font-bold text-slate-800">{assets.length}</div>
          </div>
          <div className="rounded-lg bg-slate-50 p-4">
            <div className="text-xs font-medium text-slate-500">Beban Penyusutan / Bulan</div>
            <div className="mt-1 text-xl font-bold text-brand-600"><MoneyCell value={monthlyTotal} /></div>
          </div>
          <div className="rounded-lg bg-slate-50 p-4">
            <div className="text-xs font-medium text-slate-500">Proyeksi Tahunan</div>
            <div className="mt-1 text-xl font-bold text-emerald-600"><MoneyCell value={monthlyTotal * 12} /></div>
          </div>
        </div>
      </Card>

      <Card>
        <CardHeader title="Rincian per Aset" subtitle="Jadwal 12 bulan pertama" />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Kode</th>
                <th>Nama Aset</th>
                <th>Metode</th>
                <th className="text-right">Biaya</th>
                <th className="text-right">Nilai Sisa</th>
                <th className="text-right">Umur (bln)</th>
                <th className="text-right">Bulanan</th>
              </tr>
            </thead>
            <tbody>
              {assets.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    Belum ada aset tetap. Tambahkan aset di halaman Aktiva Tetap.
                  </td>
                </tr>
              )}
              {assets.map((a) => (
                <tr key={a.id}>
                  <td className="font-mono text-xs text-brand-600">{a.code}</td>
                  <td className="font-medium text-slate-800">{a.name}</td>
                  <td className="text-slate-500">{METHOD_LABEL[a.method] || a.method}</td>
                  <td className="text-right"><MoneyCell value={a.cost} /></td>
                  <td className="text-right text-slate-500"><MoneyCell value={a.salvage} /></td>
                  <td className="text-right text-slate-500">{a.lifeMonths}</td>
                  <td className="text-right font-semibold text-slate-800"><MoneyCell value={a.monthlyDep} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <CardHeader title="Proyeksi Bulanan (12 bulan)" subtitle="Nilai buku di akhir tiap bulan" />
        <div className="grid grid-cols-1 gap-4 p-5 md:grid-cols-3">
          {assets.map((a) => (
            <div key={a.id} className="rounded-lg border border-slate-100 p-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-sm font-semibold text-slate-800">{a.code}</span>
                <span className="text-xs text-slate-400">{a.name}</span>
              </div>
              <div className="space-y-1">
                {a.schedule.map((s) => (
                  <div key={s.monthIndex} className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">{s.label}</span>
                    <span className="font-medium text-slate-700"><MoneyCell value={s.runningBook} /></span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </ReportShell>
  );
}
