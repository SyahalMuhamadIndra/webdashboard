import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listSuppliers } from '@/lib/odoo';
import { createNewSupplier } from '@/app/actions/master';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function MasterSuppliersPage() {
  const company = await getDefaultCompany();
  const suppliers = await listSuppliers(company.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Pemasok</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {suppliers.length} pemasok</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Pemasok" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Telepon</th>
                  <th className="text-right">Term (hari)</th>
                </tr>
              </thead>
              <tbody>
                {(suppliers || []).map((s: any) => (
                  <tr key={s.id}>
                    <td className="font-mono text-xs text-brand-600">{s.code}</td>
                    <td className="font-medium text-slate-800">{s.name}</td>
                    <td className="text-slate-600">{s.email || '-'}</td>
                    <td className="text-slate-600">{s.phone || '-'}</td>
                    <td className="text-right">{s.term_days}</td>
                  </tr>
                ))}
                {(!suppliers || suppliers.length === 0) && (
                  <tr><td colSpan={5} className="py-12 text-center text-slate-400">Belum ada pemasok.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Tambah Pemasok" />
          <form action={createNewSupplier} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Nama</label><input className="input" name="name" required /></div>
            <div><label className="label">Email</label><input className="input" name="email" type="email" /></div>
            <div><label className="label">Telepon</label><input className="input" name="phone" /></div>
            <div><label className="label">NPWP</label><input className="input" name="tax_id" /></div>
            <div><label className="label">Alamat</label><textarea className="input" name="address" rows={2} /></div>
            <div><label className="label">Term (hari)</label><input className="input" name="term_days" type="number" defaultValue="0" /></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan Pemasok</button>
          </form>
        </Card>
      </div>
    </div>
  );
}
