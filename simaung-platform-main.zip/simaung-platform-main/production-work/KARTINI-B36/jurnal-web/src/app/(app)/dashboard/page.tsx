import Link from 'next/link';
import {
  getIncomeStatement,
  getBalanceSheet,
  getCashFlow,
  getTrialBalance,
} from '@/lib/reports';
import { getDefaultCompany } from '@/lib/company';
import { formatIDR, monthStartISO, monthEndISO } from '@/lib/format';
import {
  listInvoices,
  listBills,
  listReceivables,
  listPayables,
  listProducts,
  listFixedAssets,
} from '@/lib/odoo';
import { Card, CardHeader } from '@/components/ui/card';
import {
  ArrowUpRight,
  TrendingUp,
  Receipt,
  Landmark,
  Wallet,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  const company = await getDefaultCompany();
  const from = monthStartISO();
  const to = monthEndISO();

  // Panggil berurutan (menghindari cold-start backend saat 4 request paralel),
  // dan aman: satu kegagalan tidak membuat seluruh dashboard crash.
  let income: Awaited<ReturnType<typeof getIncomeStatement>> = {
    revenueRows: [],
    expenseRows: [],
    totalRevenue: 0,
    totalExpenses: 0,
    netIncome: 0,
  };
  let balance: Awaited<ReturnType<typeof getBalanceSheet>> = {
    assets: [],
    liabilities: [],
    equity: [],
    totalAssets: 0,
    totalLiabilities: 0,
    totalEquity: 0,
    balanced: true,
  };
  let cash: Awaited<ReturnType<typeof getCashFlow>> = {
    inflow: 0,
    outflow: 0,
    net: 0,
    accounts: [],
  };
  let trial: Awaited<ReturnType<typeof getTrialBalance>> = {
    rows: [],
    totalDebit: 0,
    totalCredit: 0,
    balanced: true,
  };
  try {
    income = await getIncomeStatement(company.id, from, to);
  } catch {}
  try {
    balance = await getBalanceSheet(company.id, from, to);
  } catch {}
  try {
    cash = await getCashFlow(company.id, from, to);
  } catch {}
  try {
    trial = await getTrialBalance(company.id, from, to);
  } catch {}

  let invoices: any[] = [];
  let bills: any[] = [];
  let recv: any[] = [];
  let pay: any[] = [];
  let products: any[] = [];
  let assets: any[] = [];
  try {
    [invoices, bills, recv, pay, products, assets] = await Promise.all([
      listInvoices(company.id),
      listBills(company.id),
      listReceivables(company.id),
      listPayables(company.id),
      listProducts(company.id),
      listFixedAssets(company.id),
    ]);
  } catch {}

  const openAR = (recv || []).reduce((s, r: any) => s + (Number(r.original_amount) - Number(r.paid_amount || 0)), 0);
  const openAP = (pay || []).reduce((s, p: any) => s + (Number(p.original_amount) - Number(p.paid_amount || 0)), 0);

  const kpis = [
    { label: 'Omzet (Pendapatan)', value: formatIDR(income.totalRevenue), hint: 'Periode berjalan', icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Laba Bersih', value: formatIDR(income.netIncome), hint: 'Pendapatan - Beban', icon: ArrowUpRight, color: income.netIncome >= 0 ? 'text-emerald-600' : 'text-red-600', bg: income.netIncome >= 0 ? 'bg-emerald-50' : 'bg-red-50' },
    { label: 'Total Aset', value: formatIDR(balance.totalAssets), hint: 'Neraca', icon: Landmark, color: 'text-brand-600', bg: 'bg-brand-50' },
    { label: 'Kas Bersih', value: formatIDR(cash.net), hint: 'Arus kas', icon: Wallet, color: 'text-accent-600', bg: 'bg-accent-50' },
  ];

  const modules = [
    { href: '/master/accounts', label: 'Bagan Akun', value: '', hint: 'Chart of Accounts' },
    { href: '/sales/invoices', label: 'Invoice Penjualan', value: String((invoices || []).length), hint: 'dokumen' },
    { href: '/purchase/bills', label: 'Bill Pembelian', value: String((bills || []).length), hint: 'dokumen' },
    { href: '/ar', label: 'Piutang Terbuka', value: formatIDR(openAR), hint: 'AR' },
    { href: '/ap', label: 'Hutang Terbuka', value: formatIDR(openAP), hint: 'AP' },
    { href: '/inventory', label: 'Persediaan', value: String((products || []).length), hint: 'produk' },
    { href: '/assets', label: 'Aktiva Tetap', value: String((assets || []).length), hint: 'aset' },
  ];

  const margin = income.totalRevenue > 0 ? (income.netIncome / income.totalRevenue) * 100 : 0;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Dashboard</h1>
          <p className="mt-1 text-sm text-slate-500">
            {company.name} · Periode {from} s/d {to}
          </p>
        </div>
        <div className="badge bg-brand-50 text-brand-700">
          <CheckCircle2 className="h-3.5 w-3.5" />
          Akuntansi konsisten
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="min-w-0 animate-slide-up">
            <div className="p-5">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0 text-xs font-medium uppercase tracking-wide text-slate-500">{kpi.label}</div>
                <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${kpi.bg}`}>
                  <kpi.icon className={`h-4 w-4 ${kpi.color}`} />
                </div>
              </div>
              <div className={`mt-2 break-words overflow-hidden text-2xl font-bold tracking-tight ${kpi.color}`}>{kpi.value}</div>
              <div className="mt-1 text-xs text-slate-400">{kpi.hint}</div>
            </div>
          </Card>
        ))}
      </div>

      {/* Module quick links */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-7">
        {modules.map((m) => (
          <Link
            key={m.href}
            href={m.href}
            className="group min-w-0 rounded-xl border border-slate-200 bg-white p-4 shadow-card transition-all hover:-translate-y-0.5 hover:border-brand-200 hover:shadow-card-hover"
          >
            <div className="truncate text-xs font-medium uppercase tracking-wide text-slate-500">{m.label}</div>
            <div className="mt-2 truncate text-lg font-bold tracking-tight text-slate-900">{m.value || '•'}</div>
            <div className="mt-1 truncate text-[11px] text-slate-400 group-hover:text-brand-600">{m.hint}</div>
          </Link>
        ))}
      </div>

      {/* Income statement + Balance sheet */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader
            title="Laba Rugi Ringkas"
            subtitle="Pendapatan vs Beban"
            action={
              <span className="badge bg-accent-50 text-accent-700">{margin.toFixed(1)}% margin</span>
            }
          />
          <div className="p-5">
            <div className="flex items-center justify-between border-b border-slate-100 py-2.5">
              <span className="text-sm text-slate-600">Pendapatan</span>
              <span className="text-sm font-semibold text-emerald-600">{formatIDR(income.totalRevenue)}</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 py-2.5">
              <span className="text-sm text-slate-600">Beban</span>
              <span className="text-sm font-semibold text-red-600">({formatIDR(income.totalExpenses)})</span>
            </div>
            <div className="mt-3 flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2.5">
              <span className="text-sm font-medium text-slate-800">Laba Bersih</span>
              <span className="text-base font-bold text-slate-900">{formatIDR(income.netIncome)}</span>
            </div>
          </div>
        </Card>

        <Card>
          <CardHeader title="Neraca" subtitle="Aset = Liabilitas + Ekuitas" />
          <div className="p-5">
            <div className="flex items-center justify-between border-b border-slate-100 py-2.5">
              <span className="text-sm text-slate-600">Total Aset</span>
              <span className="text-sm font-semibold text-slate-900">{formatIDR(balance.totalAssets)}</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 py-2.5">
              <span className="text-sm text-slate-600">Total Liabilitas</span>
              <span className="text-sm font-semibold text-slate-900">{formatIDR(balance.totalLiabilities)}</span>
            </div>
            <div className="flex items-center justify-between py-2.5">
              <span className="text-sm text-slate-600">Total Ekuitas</span>
              <span className="text-sm font-semibold text-slate-900">{formatIDR(balance.totalEquity)}</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Trial balance status */}
      <Card>
        <CardHeader title="Neraca Saldo" subtitle={`${trial.rows.length} akun aktif`} />
        <div className="flex flex-wrap items-center justify-between gap-3 p-5">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            {trial.balanced ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-600" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-amber-500" />
            )}
            <span>
              Status keseimbangan:
              {trial.balanced ? (
                <span className="ml-2 font-semibold text-emerald-600">Balanced ✓</span>
              ) : (
                <span className="ml-2 font-semibold text-red-600">Tidak balance</span>
              )}
            </span>
          </div>
          <Link href="/reports/trial-balance" className="btn-secondary">Lihat lengkap</Link>
        </div>
      </Card>
    </div>
  );
}
