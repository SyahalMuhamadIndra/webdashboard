import Link from 'next/link';
import { listJournal } from '@/lib/reports';
import { formatIDR, formatDate } from '@/lib/format';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function JournalListPage() {
  let entries: Awaited<ReturnType<typeof listJournal>> = [];
  let errorMessage: string | null = null;
  try {
    entries = await listJournal(100);
  } catch (e: any) {
    errorMessage = e?.message || 'Terjadi kesalahan';
  }

  if (errorMessage) {
    return (
      <div className="text-center py-20 text-slate-500">
        Gagal memuat jurnal: {errorMessage}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Jurnal Umum</h1>
          <p className="mt-1 text-sm text-slate-500">
            Daftar entri jurnal double-entry
          </p>
        </div>
        <Link href="/journal/new" className="btn-primary">
          + Entri Jurnal
        </Link>
      </div>

      <Card>
        <CardHeader title={`Jurnal (${entries.length})`} />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>No. Jurnal</th>
                <th>Tanggal</th>
                <th>Memo</th>
                <th>Sumber</th>
                <th className="text-right">Total Debit</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((entry) => {
                const totalDebit = Number(entry.totalDebit || 0);
                return (
                  <tr key={entry.id}>
                    <td className="font-mono text-xs text-brand-600">
                      {entry.entryNumber}
                    </td>
                    <td>{formatDate(entry.entryDate)}</td>
                    <td className="max-w-xs truncate">{entry.memo || '-'}</td>
                    <td>
                      <span className="inline-flex rounded-md bg-slate-100 px-2 py-0.5 text-xs text-slate-600">
                        {entry.source === 'manual' ? 'Manual' : entry.source}
                      </span>
                    </td>
                    <td className="text-right font-semibold">
                      {formatIDR(totalDebit, { decimals: 2 })}
                    </td>
                    <td>
                      {entry.isPosted ? (
                        <span className="text-xs font-medium text-emerald-600">
                          Posted
                        </span>
                      ) : (
                        <span className="text-xs font-medium text-slate-400">
                          Draft
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
              {entries.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Belum ada entri jurnal. Klik &quot;+ Entri Jurnal&quot; untuk membuat.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
