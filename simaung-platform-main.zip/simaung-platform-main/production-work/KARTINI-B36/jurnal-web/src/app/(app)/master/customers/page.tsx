import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listCustomers } from '@/lib/odoo';
import { createNewCustomer } from '@/app/actions/master';
import { Card, CardHeader } from '@/components/ui/card';
import { formatIDR } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function MasterCustomersPage() {
  const company = await getDefaultCompany();
  const customers = await listCustomers(company.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Pelanggan</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {customers.length} pelanggan</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Pelanggan" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Telepon</th>
                  <th className="text-right">Limit Kredit</th>
                </tr>
              </thead>
              <tbody>
                {(customers || []).map((c: any) => (
                  <tr key={c.id}>
                    <td className="font-mono text-xs text-brand-600">{c.code}</td>
                    <td className="font-medium text-slate-800">{c.name}</td>
                    <td className="text-slate-600">{c.email || '-'}</td>
                    <td className="text-slate-600">{c.phone || '-'}</td>
                    <td className="text-right">{formatIDR(c.credit_limit)}</td>
                  </tr>
                ))}
                {(!customers || customers.length === 0) && (
                  <tr><td colSpan={5} className="py-12 text-center text-slate-400">Belum ada pelanggan.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Tambah Pelanggan" />
          <form action={createNewCustomer} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Nama</label><input className="input" name="name" required /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Tipe</label>
                <select className="input" name="customer_type">
                  <option value="customer">Customer</option>
                  <option value="vendor">Vendor</option>
                  <option value="retail">Retail</option>
                </select>
              </div>
              <div><label className="label">Term (hari)</label><input className="input" name="term_days" type="number" defaultValue="0" /></div>
            </div>
            <div><label className="label">Email</label><input className="input" name="email" type="email" /></div>
            <div><label className="label">Telepon</label><input className="input" name="phone" /></div>
            <div><label className="label">NPWP</label><input className="input" name="tax_id" /></div>
            <div><label className="label">Alamat</label><textarea className="input" name="address" rows={2} /></div>
            <div><label className="label">Limit Kredit</label><input className="input" name="credit_limit" type="number" defaultValue="0" /></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan Pelanggan</button>
          </form>
        </Card>
      </div>
    </div>
  );
}
