import { getDefaultCompany } from '@/lib/company';
import { createAdminClient } from '@/lib/supabase/admin';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDateTime } from '@/lib/format';

export const dynamic = 'force-dynamic';

async function listAuditLogs(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('audit_logs')
    .select('*')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(100);
  if (error) throw new Error(`Gagal memuat audit log: ${error.message}`);
  const logs = data || [];

  // Ambil info pengguna dari tabel profiles secara terpisah, bukan lewat
  // embed PostgREST. Ini menghindari error saat kolom relasi tidak cocok
  // (profiles memakai full_name, bukan name).
  const userIds = [...new Set(logs.map((l: any) => l.user_id).filter(Boolean))];
  let profileMap: Record<string, any> = {};
  if (userIds.length > 0) {
    const { data: prof, error: profErr } = await s
      .from('profiles')
      .select('id, full_name, email')
      .in('id', userIds);
    if (!profErr && prof) profileMap = Object.fromEntries(prof.map((p: any) => [p.id, p]));
  }
  return logs.map((l: any) => ({
    ...l,
    profiles: l.user_id ? profileMap[l.user_id] : null,
  }));
}

const ACTION_BADGE: Record<string, string> = {
  create: 'bg-emerald-50 text-emerald-600',
  update: 'bg-blue-50 text-blue-600',
  delete: 'bg-red-50 text-red-600',
  post: 'bg-indigo-50 text-indigo-600',
  login: 'bg-slate-100 text-slate-600',
  logout: 'bg-slate-100 text-slate-500',
};

export default async function AuditLogPage() {
  const company = await getDefaultCompany();
  const logs = await listAuditLogs(company.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Audit Log</h1>
        <p className="mt-1 text-sm text-slate-500">
          {company.name} · {logs.length} aktivitas terakhir
        </p>
      </div>

      <Card>
        <CardHeader title="Riwayat Aktivitas" subtitle="Jejak perubahan & tindakan sistem" />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Waktu</th>
                <th>Pengguna</th>
                <th>Aksi</th>
                <th>Entitas</th>
                <th>Detail</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((l: any) => (
                <tr key={l.id}>
                  <td className="whitespace-nowrap text-slate-500">{formatDateTime(l.created_at)}</td>
                  <td className="text-slate-700">{(l.profiles as any)?.email || l.user_id?.slice(0, 8) || '-'}</td>
                  <td>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${ACTION_BADGE[l.action] || 'bg-slate-100 text-slate-600'}`}>
                      {l.action}
                    </span>
                  </td>
                  <td className="font-medium text-slate-800">{l.entity}{l.entity_id ? ` · ${String(l.entity_id).slice(0, 12)}` : ''}</td>
                  <td className="max-w-xs text-xs text-slate-500">
                    {l.new_data ? (
                      <pre className="whitespace-pre-wrap break-words">{JSON.stringify(l.new_data).slice(0, 180)}</pre>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </td>
                </tr>
              ))}
              {logs.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    Belum ada aktivitas tercatat.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
