import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listOpportunities } from '@/lib/modules';
import { listCustomers } from '@/lib/odoo';
import { addOpportunity } from '@/app/actions/modules';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

const STAGES = ['new','qualified','proposal','won','lost'];

export default async function CrmPage() {
  const company = await getDefaultCompany();
  const [opportunities, customers] = await Promise.all([listOpportunities(company.id), listCustomers(company.id)]);

  return (
    <ReportShell title="CRM Pipeline" subtitle={`${company.name} · ${opportunities.length} peluang`} backHref="/dashboard">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Peluang" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>Judul</th><th>Pelanggan</th><th className="text-right">Nilai</th><th className="text-right">Peluang %</th><th className="text-right">Stage</th></tr></thead>
              <tbody>
                {opportunities.map((o:any)=>(<tr key={o.id}><td className="font-medium text-slate-800">{o.title}</td><td className="text-slate-500">{o.customer_id ? (customers.find((c:any)=>c.id===o.customer_id)?.name || '-') : '-'}</td><td className="text-right"><MoneyCell value={o.expected_amount} /></td><td className="text-right text-slate-500">{o.probability}%</td><td className="text-right"><span className="rounded-full bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-600">{o.stage}</span></td></tr>))}
                {opportunities.length===0 && <tr><td colSpan={6} className="py-12 text-center text-slate-400">Belum ada peluang.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>
        <Card>
          <CardHeader title="Tambah Peluang" />
          <form action={addOpportunity} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Judul</label><input className="input" name="title" required /></div>
            <div><label className="label">Pelanggan</label><select className="input" name="customer_id"><option value="">— Pilih —</option>{customers.map((c:any)=><option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
            <div><label className="label">Nilai</label><input className="input" type="number" name="expected_amount" defaultValue={0} /></div>
            <div><label className="label">Peluang %</label><input className="input" type="number" name="probability" defaultValue={0} /></div>
            <div><label className="label">Stage</label><select className="input" name="stage">{STAGES.map((s:any)=><option key={s} value={s}>{s}</option>)}</select></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
