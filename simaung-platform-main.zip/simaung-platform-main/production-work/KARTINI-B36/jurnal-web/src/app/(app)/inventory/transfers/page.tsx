import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listDeliveries, listReceipts, listTransfers } from '@/lib/modules';
import { listProducts, listLocations, listCustomers, listSuppliers } from '@/lib/odoo';
import { addDelivery, addReceipt, addTransfer } from '@/app/actions/modules';
import { ReportShell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function TransfersPage() {
  const company = await getDefaultCompany();
  const [deliveries, receipts, transfers, products, locations, customers, suppliers] = await Promise.all([
    listDeliveries(company.id), listReceipts(company.id), listTransfers(company.id),
    listProducts(company.id), listLocations(company.id), listCustomers(company.id), listSuppliers(company.id),
  ]);

  return (
    <ReportShell title="Keluar Masuk Barang" subtitle={`${company.name} · Delivery, Receipt & Transfer`} backHref="/inventory">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Riwayat" subtitle="Transaksi keluar/masuk/pindah barang" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>Tipe</th><th>No.</th><th className="text-right">Tanggal</th><th className="text-right">Status</th></tr></thead>
              <tbody>
                {deliveries.map((d:any)=>(<tr key={'d'+d.id}><td><span className="rounded bg-blue-50 px-2 py-0.5 text-xs text-blue-600">Delivery</span></td><td className="font-mono text-xs text-brand-600">{d.delivery_number}</td><td className="text-right text-slate-500">{formatDate(d.delivery_date)}</td><td className="text-right text-slate-500">{d.status}</td></tr>))}
                {receipts.map((r:any)=>(<tr key={'r'+r.id}><td><span className="rounded bg-emerald-50 px-2 py-0.5 text-xs text-emerald-600">Receipt</span></td><td className="font-mono text-xs text-brand-600">{r.receipt_number}</td><td className="text-right text-slate-500">{formatDate(r.receipt_date)}</td><td className="text-right text-slate-500">{r.status}</td></tr>))}
                {transfers.map((t:any)=>(<tr key={'t'+t.id}><td><span className="rounded bg-amber-50 px-2 py-0.5 text-xs text-amber-600">Transfer</span></td><td className="font-mono text-xs text-brand-600">{t.transfer_number}</td><td className="text-right text-slate-500">{formatDate(t.transfer_date)}</td><td className="text-right text-slate-500">{t.status}</td></tr>))}
                {deliveries.length+receipts.length+transfers.length === 0 && <tr><td colSpan={4} className="py-12 text-center text-slate-400">Belum ada transaksi barang.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="space-y-6">
          <Card><CardHeader title="Delivery (Keluar)" /><form action={addDelivery} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Gudang</label><select className="input" name="warehouse_id"><option value="">— Pilih —</option>{locations.map((l:any)=><option key={l.id} value={l.id}>{l.name}</option>)}</select></div>
            <div><label className="label">Produk</label><select className="input" name="product_id">{products.map((p:any)=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
            <div><label className="label">Qty</label><input className="input" type="number" name="quantity" defaultValue={1} /></div>
            <button type="submit" className="btn-primary w-full justify-center">Buat Delivery</button>
          </form></Card>

          <Card><CardHeader title="Receipt (Masuk)" /><form action={addReceipt} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Gudang</label><select className="input" name="warehouse_id"><option value="">— Pilih —</option>{locations.map((l:any)=><option key={l.id} value={l.id}>{l.name}</option>)}</select></div>
            <div><label className="label">Produk</label><select className="input" name="product_id">{products.map((p:any)=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
            <div><label className="label">Qty</label><input className="input" type="number" name="quantity" defaultValue={1} /></div>
            <button type="submit" className="btn-primary w-full justify-center">Buat Receipt</button>
          </form></Card>

          <Card><CardHeader title="Transfer Antar Gudang" /><form action={addTransfer} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Dari Gudang</label><select className="input" name="from_warehouse_id"><option value="">— Pilih —</option>{locations.map((l:any)=><option key={l.id} value={l.id}>{l.name}</option>)}</select></div>
            <div><label className="label">Ke Gudang</label><select className="input" name="to_warehouse_id"><option value="">— Pilih —</option>{locations.map((l:any)=><option key={l.id} value={l.id}>{l.name}</option>)}</select></div>
            <div><label className="label">Produk</label><select className="input" name="product_id">{products.map((p:any)=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
            <div><label className="label">Qty</label><input className="input" type="number" name="quantity" defaultValue={1} /></div>
            <button type="submit" className="btn-primary w-full justify-center">Buat Transfer</button>
          </form></Card>
        </div>
      </div>
    </ReportShell>
  );
}
