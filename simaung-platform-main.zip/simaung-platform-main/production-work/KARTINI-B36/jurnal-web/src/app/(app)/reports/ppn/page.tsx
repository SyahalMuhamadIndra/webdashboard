import Link from 'next/link';
import { getDefaultCompany } from '@/lib/company';
import { getPpnReport } from '@/lib/finance';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';
import { monthStartISO, monthEndISO } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function PpnPage() {
  const company = await getDefaultCompany();
  const from = monthStartISO();
  const to = monthEndISO();
  const ppn = await getPpnReport(company.id, from, to);

  return (
    <ReportShell
      title="Laporan PPN"
      subtitle={`${company.name} · Periode ${from} s/d ${to}`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="ppn"
          headers={['Kode', 'Nama', 'PPN Keluaran', 'PPN Masukan']}
          rows={ppn.rows.map((r: any) => [r.code, r.name, r.collect, r.input])}
        />
      }
    >
      <Card>
        <CardHeader
          title="PPN Keluaran vs PPN Masukan"
          subtitle={`${ppn.rows.length} akun pajak aktif`}
        />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Kode</th>
                <th>Nama Akun</th>
                <th className="text-right">PPN Keluaran (Kredit)</th>
                <th className="text-right">PPN Masukan (Debit)</th>
              </tr>
            </thead>
            <tbody>
              {ppn.rows.map((r: any) => (
                <tr key={r.code}>
                  <td className="font-mono text-xs text-brand-600">{r.code}</td>
                  <td className="font-medium text-slate-800">{r.name}</td>
                  <td className="text-right">{r.collect !== 0 ? <MoneyCell value={r.collect} /> : '-'}</td>
                  <td className="text-right">{r.input !== 0 ? <MoneyCell value={r.input} /> : '-'}</td>
                </tr>
              ))}
              {ppn.rows.length === 0 && (
                <tr><td colSpan={4} className="py-12 text-center text-slate-400">
                  Tidak ada transaksi pajak pada periode ini. Tagihan dengan PPN akan muncul di sini.
                </td></tr>
              )}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50 font-semibold">
                <td colSpan={2} className="px-3 py-3 text-right text-xs uppercase text-slate-500">Total</td>
                <td className="px-3 py-3 text-right"><MoneyCell value={ppn.totalCollect} /></td>
                <td className="px-3 py-3 text-right"><MoneyCell value={ppn.totalInput} /></td>
              </tr>
            </tfoot>
          </table>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 px-5 py-3">
          <div className="text-sm">
            <span className="text-slate-500">PPN kurang bayar (lebih bayar jika negatif):</span>
            <span className={`ml-2 font-semibold ${ppn.netPayable >= 0 ? 'text-red-600' : 'text-emerald-600'}`}>
              <MoneyCell value={ppn.netPayable} />
            </span>
          </div>
          <Link href="/master/taxes" className="btn-secondary">Kelola Pajak</Link>
        </div>
      </Card>
    </ReportShell>
  );
}
