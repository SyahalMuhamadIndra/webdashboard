import { getBalanceSheet } from '@/lib/reports';
import { getDefaultCompany } from '@/lib/company';
import { monthStartISO, monthEndISO } from '@/lib/format';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

export default async function BalanceSheetPage() {
  const company = await getDefaultCompany();
  const from = monthStartISO();
  const to = monthEndISO();
  const bs = await getBalanceSheet(company.id, from, to);

  return (
    <ReportShell
      title="Neraca (Balance Sheet)"
      subtitle={`${company.name} · Periode ${from} s/d ${to}`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="neraca"
          headers={['Kode', 'Pos', 'Jenis', 'Jumlah']}
          rows={[
            ...bs.assets.map((r) => [r.code, r.name, 'Aktiva', r.amount]),
            ...bs.liabilities.map((r) => [r.code, r.name, 'Liabilitas', r.amount]),
            ...bs.equity.map((r) => [r.code, r.name, 'Ekuitas', r.amount]),
          ]}
        />
      }
    >
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Aktiva" subtitle={`${bs.assets.length} pos`} />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Aktiva</th>
                  <th className="text-right">Jumlah</th>
                </tr>
              </thead>
              <tbody>
                {bs.assets.map((r) => (
                  <tr key={r.code}>
                    <td className="font-mono text-xs text-brand-600">{r.code}</td>
                    <td>{r.name}</td>
                    <td className="text-right">
                      <MoneyCell value={r.amount} />
                    </td>
                  </tr>
                ))}
                {bs.assets.length === 0 && (
                  <tr>
                    <td colSpan={3} className="py-8 text-center text-slate-400">
                      Tidak ada aktiva.
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr className="bg-slate-50 font-semibold">
                  <td colSpan={2} className="px-3 py-3 text-right text-xs uppercase text-slate-500">
                    Total Aktiva
                  </td>
                  <td className="px-3 py-3 text-right">
                    <MoneyCell value={bs.totalAssets} />
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Liabilitas & Ekuitas" subtitle={`${bs.liabilities.length + bs.equity.length} pos`} />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Item</th>
                  <th className="text-right">Jumlah</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan={3} className="bg-slate-50 px-3 py-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Liabilitas
                  </td>
                </tr>
                {bs.liabilities.map((r) => (
                  <tr key={r.code}>
                    <td className="font-mono text-xs text-brand-600">{r.code}</td>
                    <td>{r.name}</td>
                    <td className="text-right">
                      <MoneyCell value={r.amount} />
                    </td>
                  </tr>
                ))}
                <tr>
                  <td colSpan={3} className="bg-slate-50 px-3 py-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Ekuitas
                  </td>
                </tr>
                {bs.equity.map((r) => (
                  <tr key={r.code}>
                    <td className="font-mono text-xs text-brand-600">{r.code}</td>
                    <td>{r.name}</td>
                    <td className="text-right">
                      <MoneyCell value={r.amount} />
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-50 font-semibold">
                  <td colSpan={2} className="px-3 py-3 text-right text-xs uppercase text-slate-500">
                    Total Liabilitas + Ekuitas
                  </td>
                  <td className="px-3 py-3 text-right">
                    <MoneyCell value={bs.totalLiabilities + bs.totalEquity} />
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </Card>
      </div>

      <Card>
        <div className="flex items-center justify-between p-5">
          <div className="text-sm text-slate-500">Status keseimbangan:</div>
          {bs.balanced ? (
            <span className="font-semibold text-emerald-600">
              Balanced ✓ — Aset = Liabilitas + Ekuitas
            </span>
          ) : (
            <span className="font-semibold text-red-600">
              Tidak balance — selisih {bs.totalAssets - (bs.totalLiabilities + bs.totalEquity)}
            </span>
          )}
        </div>
      </Card>
    </ReportShell>
  );
}
