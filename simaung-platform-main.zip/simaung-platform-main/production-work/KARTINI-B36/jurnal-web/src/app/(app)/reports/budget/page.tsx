import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listBudgets } from '@/lib/modules';
import { listAccounts } from '@/lib/odoo';
import { getBudgetVsActual } from '@/lib/reports';
import { addBudget } from '@/app/actions/modules';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function BudgetPage() {
  const company = await getDefaultCompany();
  const year = new Date().getFullYear();
  const [budgets, accounts, vsActual] = await Promise.all([
    listBudgets(company.id),
    listAccounts(company.id),
    getBudgetVsActual(company.id, year),
  ]);

  return (
    <ReportShell
      title="Budget vs Aktual"
      subtitle={`${company.name} · Tahun fiskal ${year}`}
      backHref="/dashboard"
    >
      {/* Result summary cards */}
      {vsActual.budget && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Card>
            <div className="p-5">
              <div className="text-sm font-medium text-slate-500">Anggaran</div>
              <div className="mt-1 text-2xl font-bold text-slate-800">
                <MoneyCell value={vsActual.totalBudget} />
              </div>
            </div>
          </Card>
          <Card>
            <div className="p-5">
              <div className="text-sm font-medium text-slate-500">Realisasi (Aktual)</div>
              <div className="mt-1 text-2xl font-bold text-slate-800">
                <MoneyCell value={vsActual.totalActual} />
              </div>
            </div>
          </Card>
          <Card>
            <div className="p-5">
              <div className="text-sm font-medium text-slate-500">Selisih (Variance)</div>
              <div
                className={`mt-1 text-2xl font-bold ${
                  vsActual.variance >= 0 ? 'text-emerald-600' : 'text-red-600'
                }`}
              >
                <MoneyCell value={vsActual.variance} />
              </div>
            </div>
          </Card>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title={vsActual.budget ? `Anggaran "${vsActual.budget.name}" vs Realisasi` : 'Daftar Anggaran'}
            subtitle={
              vsActual.budget
                ? `${vsActual.rows.length} baris akun`
                : `${budgets.length} anggaran tersedia`
            }
          />

          {vsActual.budget ? (
            <div className="overflow-x-auto">
              <table className="table-base">
                <thead>
                  <tr>
                    <th>Kode</th>
                    <th>Akun</th>
                    <th className="text-right">Anggaran</th>
                    <th className="text-right">Realisasi</th>
                    <th className="text-right">Selisih</th>
                  </tr>
                </thead>
                <tbody>
                  {vsActual.rows.map((r) => (
                    <tr key={r.accountId}>
                      <td className="font-mono text-xs text-brand-600">{r.code}</td>
                      <td>{r.name}</td>
                      <td className="text-right">
                        <MoneyCell value={r.budget} />
                      </td>
                      <td className="text-right">
                        <MoneyCell value={r.actual} />
                      </td>
                      <td
                        className={`text-right font-semibold ${
                          r.variance >= 0 ? 'text-emerald-600' : 'text-red-600'
                        }`}
                      >
                        <MoneyCell value={r.variance} />
                      </td>
                    </tr>
                  ))}
                  {vsActual.rows.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-400">
                        Belum ada item anggaran.
                      </td>
                    </tr>
                  )}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-50 font-semibold">
                    <td colSpan={2} className="px-3 py-3 text-right text-xs uppercase text-slate-500">
                      Total
                    </td>
                    <td className="px-3 py-3 text-right">
                      <MoneyCell value={vsActual.totalBudget} />
                    </td>
                    <td className="px-3 py-3 text-right">
                      <MoneyCell value={vsActual.totalActual} />
                    </td>
                    <td
                      className={`px-3 py-3 text-right ${
                        vsActual.variance >= 0 ? 'text-emerald-600' : 'text-red-600'
                      }`}
                    >
                      <MoneyCell value={vsActual.variance} />
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table-base">
                <thead>
                  <tr>
                    <th>Nama</th>
                    <th className="text-right">Tahun</th>
                    <th className="text-right">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {budgets.map((b: any) => (
                    <tr key={b.id}>
                      <td className="font-medium text-slate-800">{b.name}</td>
                      <td className="text-right text-slate-500">{b.fiscal_year}</td>
                      <td className="text-right">
                        <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-600">
                          {b.is_active ? 'Aktif' : 'Tidak aktif'}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {budgets.length === 0 && (
                    <tr>
                      <td colSpan={3} className="py-12 text-center text-slate-400">
                        Belum ada anggaran. Buat anggaran aktif tahun {year} untuk melihat perbandingan.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card>
          <CardHeader title="Buat Anggaran" />
          <form action={addBudget} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Nama</label>
              <input className="input" name="name" placeholder={`Anggaran ${year}`} required />
            </div>
            <div>
              <label className="label">Tahun</label>
              <input
                className="input"
                type="number"
                name="fiscal_year"
                defaultValue={year}
              />
            </div>
            <div>
              <label className="label">Akun</label>
              <select className="input" name="account_id">
                {accounts.map((a: any) => (
                  <option key={a.id} value={a.id}>
                    {a.code} · {a.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Jumlah</label>
              <input className="input" type="number" name="amount" defaultValue={0} />
            </div>
            <button type="submit" className="btn-primary w-full justify-center">
              Simpan
            </button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
