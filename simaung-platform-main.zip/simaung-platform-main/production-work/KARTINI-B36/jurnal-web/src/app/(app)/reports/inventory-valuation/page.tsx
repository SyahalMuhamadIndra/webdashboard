import { getDefaultCompany } from '@/lib/company';
import { listStockBalance, listLocations } from '@/lib/odoo';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

export default async function InventoryValuationPage() {
  const company = await getDefaultCompany();
  const [balances, locations] = await Promise.all([
    listStockBalance(company.id),
    listLocations(company.id),
  ]);

  // Aggregate by warehouse (skip zero qty)
  const byWarehouse = new Map<string, { name: string; totalQty: number; totalValue: number }>();
  let grandQty = 0;
  let grandValue = 0;
  let zeroStock = 0;

  const rows = (balances || [])
    .map((b: any) => {
      const qty = Number(b.quantity) || 0;
      const cost = Number(b.avg_cost) || 0;
      const value = qty * cost;
      grandQty += qty;
      grandValue += value;
      if (qty === 0) zeroStock++;
      const whName = b.warehouses?.name || '—';
      const wh = byWarehouse.get(whName) || { name: whName, totalQty: 0, totalValue: 0 };
      wh.totalQty += qty;
      wh.totalValue += value;
      byWarehouse.set(whName, wh);
      return { name: b.products?.name, sku: b.products?.sku, qty, cost, value, warehouse: whName };
    })
    .sort((a: any, b: any) => b.value - a.value);

  const warehouseSummary = [...byWarehouse.values()].map((w) => ({
    name: w.name,
    totalQty: Number(w.totalQty.toFixed(2)),
    totalValue: Number(w.totalValue.toFixed(2)),
  }));

  return (
    <ReportShell
      title="Valuasi Persediaan (Inventory Valuation)"
      subtitle={`${company.name} · Nilai stok berdasarkan biaya rata-rata`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="valuasi-persediaan"
          headers={['Produk', 'SKU', 'Gudang', 'Qty', 'Avg Cost', 'Nilai']}
          rows={rows.map((r: any) => [r.name, r.sku, r.warehouse, r.qty, r.cost, r.value])}
        />
      }
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Total Item (baris)</div>
            <div className="mt-1 text-2xl font-bold text-slate-800">{rows.length}</div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Total Kuantitas</div>
            <div className="mt-1 text-2xl font-bold text-slate-800">{grandQty.toLocaleString('id-ID')}</div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Total Nilai Stok</div>
            <div className="mt-1 text-2xl font-bold text-brand-700">
              <MoneyCell value={grandValue} />
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Rincian per Produk" subtitle={`${rows.length} produk · ${zeroStock} stok habis`} />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Produk</th>
                  <th>SKU</th>
                  <th>Gudang</th>
                  <th className="text-right">Qty</th>
                  <th className="text-right">Avg Cost</th>
                  <th className="text-right">Nilai</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r: any, i: number) => (
                  <tr key={i}>
                    <td className="font-medium text-slate-800">{r.name}</td>
                    <td className="font-mono text-xs text-brand-600">{r.sku}</td>
                    <td className="text-slate-600">{r.warehouse}</td>
                    <td className="text-right">{r.qty.toLocaleString('id-ID')}</td>
                    <td className="text-right text-slate-600">
                      <MoneyCell value={r.cost} />
                    </td>
                    <td className="text-right font-semibold">
                      <MoneyCell value={r.value} />
                    </td>
                  </tr>
                ))}
                {rows.length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400">
                      Belum ada data stok / saldo persediaan.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Nilai per Gudang" subtitle={`${warehouseSummary.length} gudang`} />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Gudang</th>
                  <th className="text-right">Qty</th>
                  <th className="text-right">Nilai</th>
                </tr>
              </thead>
              <tbody>
                {warehouseSummary.map((w) => (
                  <tr key={w.name}>
                    <td className="font-medium text-slate-800">{w.name}</td>
                    <td className="text-right">{w.totalQty.toLocaleString('id-ID')}</td>
                    <td className="text-right font-semibold">
                      <MoneyCell value={w.totalValue} />
                    </td>
                  </tr>
                ))}
                {warehouseSummary.length === 0 && (
                  <tr>
                    <td colSpan={3} className="py-10 text-center text-slate-400">
                      Tidak ada gudang.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </ReportShell>
  );
}
