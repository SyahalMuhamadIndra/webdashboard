import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listRoles, listPermissions, listRolePermissions } from '@/lib/rbac';
import { addRole, togglePermissionAction, removeRole } from '@/app/actions/rbac';
import { ReportShell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function RolesPage() {
  const company = await getDefaultCompany();
  const [roles, permissions] = await Promise.all([
    listRoles(company.id),
    listPermissions(),
  ]);

  // Group permissions by module
  const grouped = permissions.reduce<Record<string, any[]>>((m, p) => {
    (m[p.module] ||= []).push(p);
    return m;
  }, {});

  // Resolve each role's granted permission ids
  const rolesWithPerms = await Promise.all(
    roles.map(async (r: any) => ({ role: r, perms: await listRolePermissions(r.id) }))
  );

  return (
    <ReportShell
      title="Roles & Permissions (RBAC)"
      subtitle={`${company.name} · ${roles.length} role · ${permissions.length} permission`}
      backHref="/settings"
    >
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Role" subtitle="Klik toggle untuk memberi/mencabut izin" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Role</th>
                  <th>Deskripsi</th>
                  <th className="text-right">Izin</th>
                  <th className="text-right">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {rolesWithPerms.length === 0 && (
                  <tr><td colSpan={4} className="py-12 text-center text-slate-400">Belum ada role. Buat role pertama.</td></tr>
                )}
                {rolesWithPerms.map(({ role, perms }) => (
                  <tr key={role.id}>
                    <td className="font-medium text-slate-800">
                      {role.name}
                      {role.is_system && <span className="ml-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-500">System</span>}
                    </td>
                    <td className="text-slate-500">{role.description || '—'}</td>
                    <td className="text-right">
                      <span className="rounded-full bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-600">{perms.length}</span>
                    </td>
                    <td className="text-right">
                      {!role.is_system && (
                        <form action={removeRole} className="inline"><OperationKey />
                          <input type="hidden" name="roleId" value={role.id} />
                          <button type="submit" className="rounded-md bg-slate-50 px-2 py-1 text-xs font-medium text-slate-600 hover:bg-red-50 hover:text-red-600">
                            Hapus
                          </button>
                        </form>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="grid grid-cols-1 gap-6 p-5 md:grid-cols-2">
            {rolesWithPerms.map(({ role, perms }) => (
              <div key={role.id} className="rounded-lg border border-slate-100 p-4">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-semibold text-slate-800">{role.name}</span>
                  <span className="text-xs text-slate-400">{perms.length} izin</span>
                </div>
                <div className="space-y-1">
                  {Object.entries(grouped).map(([module, list]) => (
                    <div key={module}>
                      <div className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-slate-400">{module}</div>
                      {list.map((p) => {
                        const granted = perms.includes(p.id);
                        return (
                          <form key={p.id} action={togglePermissionAction} className="flex items-center justify-between py-0.5"><OperationKey />
                            <input type="hidden" name="roleId" value={role.id} />
                            <input type="hidden" name="permissionId" value={p.id} />
                            <input type="hidden" name="enabled" value={String(!granted)} />
                            <span className="text-xs text-slate-600">{p.name}</span>
                            <button
                              type="submit"
                              className={`relative h-5 w-9 rounded-full transition-colors ${granted ? 'bg-brand-600' : 'bg-slate-200'}`}
                              aria-label={p.name}
                            >
                              <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${granted ? 'left-4' : 'left-0.5'}`} />
                            </button>
                          </form>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Role" />
          <form action={addRole} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Nama Role</label>
              <input className="input" name="name" placeholder="Akuntan" required />
            </div>
            <div>
              <label className="label">Deskripsi</label>
              <textarea className="input" name="description" placeholder="Deskripsi role" />
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
