import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listBankAccounts, listCashAccounts } from '@/lib/treasury';
import { addBankAccount, addCashAccount } from '@/app/actions/treasury';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

export default async function FinancePage() {
  const company = await getDefaultCompany();
  const [banks, cash] = await Promise.all([
    listBankAccounts(company.id),
    listCashAccounts(company.id),
  ]);

  const totalBank = banks.reduce((s: number, b: any) => s + Number(b.opening_balance || 0), 0);
  const totalCash = cash.reduce((s: number, c: any) => s + Number(c.opening_balance || 0), 0);

  return (
    <ReportShell
      title="Kas & Bank (Treasury)"
      subtitle={`${company.name} · ${banks.length} rekening bank · ${cash.length} kas`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="kas-bank"
          headers={['Jenis', 'Nama', 'Mata Uang', 'Saldo Awal', 'Status']}
          rows={[
            ...banks.map((b: any) => ['Bank', b.bank_name, b.currency, Number(b.opening_balance), b.is_active ? 'Aktif' : 'Nonaktif']),
            ...cash.map((c: any) => ['Kas', c.name, c.currency, Number(c.opening_balance), c.is_active ? 'Aktif' : 'Nonaktif']),
          ]}
        />
      }
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Total Bank</div>
            <div className="mt-1 text-xl font-bold text-slate-800"><MoneyCell value={totalBank} /></div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Total Kas</div>
            <div className="mt-1 text-xl font-bold text-slate-800"><MoneyCell value={totalCash} /></div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Saldo Tunai</div>
            <div className="mt-1 text-xl font-bold text-emerald-600"><MoneyCell value={totalBank + totalCash} /></div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Rekening Bank" subtitle="Akun kas di bank" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Nama Bank</th>
                  <th>Nomor</th>
                  <th className="text-right">Saldo Awal</th>
                  <th className="text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {banks.map((b: any) => (
                  <tr key={b.id}>
                    <td className="font-medium text-slate-800">{b.bank_name}{b.account_name ? <span className="ml-1 text-xs text-slate-400">· {b.account_name}</span> : null}</td>
                    <td className="font-mono text-xs text-brand-600">{b.account_number || '-'}</td>
                    <td className="text-right"><MoneyCell value={Number(b.opening_balance)} /></td>
                    <td className="text-right">
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${b.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-500'}`}>
                        {b.is_active ? 'Aktif' : 'Nonaktif'}
                      </span>
                    </td>
                  </tr>
                ))}
                {banks.length === 0 && (
                  <tr><td colSpan={4} className="py-12 text-center text-slate-400">Belum ada rekening bank.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Tambah Rekening Bank" />
          <form action={addBankAccount} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Nama Bank</label><input className="input" name="bank_name" required /></div>
            <div><label className="label">Nomor Rekening</label><input className="input" name="account_number" /></div>
            <div><label className="label">Nama Pemilik</label><input className="input" name="account_name" /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Mata Uang</label><input className="input" name="currency" defaultValue="IDR" /></div>
              <div><label className="label">Saldo Awal</label><input className="input" type="number" name="opening_balance" defaultValue={0} step="any" /></div>
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Kas Nontunai" subtitle="Kas fisik / petty cash" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Nama</th>
                  <th className="text-right">Saldo Awal</th>
                  <th className="text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {cash.map((c: any) => (
                  <tr key={c.id}>
                    <td className="font-medium text-slate-800">{c.name}<span className="ml-1 text-xs text-slate-400">{c.currency}</span></td>
                    <td className="text-right"><MoneyCell value={Number(c.opening_balance)} /></td>
                    <td className="text-right">
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${c.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-500'}`}>
                        {c.is_active ? 'Aktif' : 'Nonaktif'}
                      </span>
                    </td>
                  </tr>
                ))}
                {cash.length === 0 && (
                  <tr><td colSpan={3} className="py-12 text-center text-slate-400">Belum ada kas.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Tambah Kas" />
          <form action={addCashAccount} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Nama Kas</label><input className="input" name="name" placeholder="Kas Kecil" required /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Mata Uang</label><input className="input" name="currency" defaultValue="IDR" /></div>
              <div><label className="label">Saldo Awal</label><input className="input" type="number" name="opening_balance" defaultValue={0} step="any" /></div>
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
