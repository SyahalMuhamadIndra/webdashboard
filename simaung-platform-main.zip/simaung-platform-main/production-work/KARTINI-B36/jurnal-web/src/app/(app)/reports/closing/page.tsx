import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listFiscalPeriods } from '@/lib/ops';
import { generatePeriods, closePeriod } from '@/app/actions/ops';
import { ReportShell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function ClosingPage() {
  const company = await getDefaultCompany();
  const periods = await listFiscalPeriods(company.id);
  const hasPeriods = periods.length > 0;

  return (
    <ReportShell
      title="Periode & Penutupan Buku"
      subtitle={`${company.name} · Buat periode fiskal lalu kunci yang sudah final`}
      backHref="/dashboard"
    >
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Periode Fiskal" subtitle={`${periods.length} periode`} />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Periode</th>
                  <th className="text-right">Mulai</th>
                  <th className="text-right">Selesai</th>
                  <th className="text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {periods.map((p: any) => (
                  <tr key={p.id}>
                    <td className="font-medium text-slate-800">{p.name}</td>
                    <td className="text-right text-slate-500">{formatDate(p.start_date)}</td>
                    <td className="text-right text-slate-500">{formatDate(p.end_date)}</td>
                    <td className="text-right">
                      <form action={closePeriod} className="inline-block"><OperationKey />
                        <input type="hidden" name="companyId" value={company.id} />
                        <input type="hidden" name="periodId" value={p.id} />
                        <button
                          type="submit"
                          disabled={p.is_closed}
                          className={`rounded-full px-2 py-0.5 text-xs font-medium ${p.is_closed ? 'bg-slate-100 text-slate-400' : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'}`}
                        >
                          {p.is_closed ? 'Terkunci' : 'Kunci'}
                        </button>
                      </form>
                    </td>
                  </tr>
                ))}
                {!hasPeriods && (
                  <tr><td colSpan={4} className="py-12 text-center text-slate-400">Belum ada periode. Buat periode terlebih dahulu.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Periode" subtitle="Generate 12 periode untuk tahun berjalan" />
          <form action={generatePeriods} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Tahun Fiskal</label>
              <input className="input" type="number" name="year" defaultValue={new Date().getFullYear()} required />
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Buat Periode</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
