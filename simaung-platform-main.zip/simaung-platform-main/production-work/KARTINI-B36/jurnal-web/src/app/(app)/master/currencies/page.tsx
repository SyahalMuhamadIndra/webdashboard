import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listCurrencies } from '@/lib/modules';
import { addCurrency } from '@/app/actions/modules';
import { ReportShell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function CurrenciesPage() {
  const company = await getDefaultCompany();
  const currencies = await listCurrencies(company.id);

  return (
    <ReportShell title="Mata Uang & Kurs" subtitle={`${company.name} · ${currencies.length} valuta`} backHref="/dashboard">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Valuta" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>Kode</th><th>Nama</th><th>Simbol</th><th className="text-right">Kurs</th></tr></thead>
              <tbody>
                {currencies.map((c:any)=>(<tr key={c.id}><td className="font-mono text-xs text-brand-600">{c.code}</td><td className="font-medium text-slate-800">{c.name}</td><td className="text-slate-500">{c.symbol || '-'}</td><td className="text-right text-slate-600">{c.rate || '-'}</td></tr>))}
                {currencies.length===0 && <tr><td colSpan={4} className="py-12 text-center text-slate-400">Belum ada mata uang.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>
        <Card>
          <CardHeader title="Tambah Valuta" />
          <form action={addCurrency} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Kode</label><input className="input" name="code" placeholder="USD" required /></div>
            <div><label className="label">Nama</label><input className="input" name="name" placeholder="US Dollar" required /></div>
            <div className="grid grid-cols-2 gap-2"><div><label className="label">Simbol</label><input className="input" name="symbol" placeholder="$" /></div><div><label className="label">Kurs</label><input className="input" type="number" name="rate" defaultValue={1} step="any" /></div></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
