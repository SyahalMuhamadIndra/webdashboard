import {OperationKey} from '@/components/operation-key';
import Link from 'next/link';
import { createAdminClient } from '@/lib/supabase/admin';
import { getDefaultCompany } from '@/lib/company';
import { listAccounts, listTypeOfAccount } from '@/lib/odoo';
import { createNewAccount, toggleAccountActive } from '@/app/actions/master';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function MasterAccountsPage() {
  const company = await getDefaultCompany();
  const [accounts, types] = await Promise.all([
    listAccounts(company.id),
    listTypeOfAccount(company.id),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Bagan Akun (Chart of Accounts)</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {accounts.length} akun</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        {/* List */}
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Akun" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Nama Akun</th>
                  <th>Tipe</th>
                  <th>Tanda</th>
                  <th className="text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {(accounts || []).map((a: any) => (
                  <tr key={a.id}>
                    <td className="font-mono text-xs text-brand-600">{a.code}</td>
                    <td className="font-medium text-slate-800">
                      {a.name}
                      {a.is_header && <span className="ml-2 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-500">Header</span>}
                    </td>
                    <td>
                      <span className="rounded-md bg-slate-100 px-2 py-0.5 text-xs text-slate-600">
                        {a.type_of_account?.name}
                      </span>
                    </td>
                    <td className="text-xs text-slate-500">
                      {a.type_of_account?.normal_balance === 'debit' ? 'Debit' : 'Kredit'}
                    </td>
                    <td className="text-right">
                      <form action={toggleAccountActive}><OperationKey />
                        <input type="hidden" name="id" value={a.id} />
                        <input type="hidden" name="is_active" value={String(a.is_active)} />
                        <button
                          type="submit"
                          className={`rounded-full px-2 py-0.5 text-xs font-medium ${a.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}
                        >
                          {a.is_active ? 'Aktif' : 'Nonaktif'}
                        </button>
                      </form>
                    </td>
                  </tr>
                ))}
                {(!accounts || accounts.length === 0) && (
                  <tr><td colSpan={5} className="py-12 text-center text-slate-400">Belum ada akun. Isi seed COA.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Create form */}
        <Card>
          <CardHeader title="Tambah Akun" />
          <form action={createNewAccount} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Kode</label>
              <input className="input" name="code" placeholder="1-1500" required />
            </div>
            <div>
              <label className="label">Nama Akun</label>
              <input className="input" name="name" placeholder="Kas Kecil" required />
            </div>
            <div>
              <label className="label">Tipe Akun</label>
              <select className="input" name="type_of_account_id" required>
                <option value="">— Pilih —</option>
                {(types || []).map((t: any) => (
                  <option key={t.id} value={t.id}>{t.name} ({t.normal_balance})</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <label className="flex items-center gap-2"><input type="checkbox" name="is_header" /> Header</label>
              <label className="flex items-center gap-2"><input type="checkbox" name="is_cash" /> Kas</label>
              <label className="flex items-center gap-2"><input type="checkbox" name="is_bank" /> Bank</label>
              <label className="flex items-center gap-2"><input type="checkbox" name="is_receivable" /> Piutang</label>
              <label className="flex items-center gap-2"><input type="checkbox" name="is_payable" /> Hutang</label>
              <label className="flex items-center gap-2"><input type="checkbox" name="is_inventory" /> Persediaan</label>
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan Akun</button>
          </form>
          <div className="border-t border-slate-100 px-5 py-3">
            <Link href="/reports/trial-balance" className="btn-secondary w-full justify-center">Lihat Neraca Saldo</Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
