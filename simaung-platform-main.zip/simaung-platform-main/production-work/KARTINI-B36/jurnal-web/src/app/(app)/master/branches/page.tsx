import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listBranches } from '@/lib/odoo';
import { addBranch } from '@/app/actions/logistics';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function BranchesPage() {
  const company = await getDefaultCompany();
  const branches = await listBranches(company.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Cabang</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {branches.length} cabang</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Cabang" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Nama</th>
                  <th>Telepon</th>
                  <th>Alamat</th>
                  <th className="text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {(branches || []).map((b: any) => (
                  <tr key={b.id}>
                    <td className="font-mono text-xs text-brand-600">{b.code}</td>
                    <td className="font-medium text-slate-800">{b.name}</td>
                    <td className="text-slate-600">{b.phone || '-'}</td>
                    <td className="text-slate-500">{b.address || '-'}</td>
                    <td className="text-right">
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${b.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-500'}`}>
                        {b.is_active ? 'Aktif' : 'Nonaktif'}
                      </span>
                    </td>
                  </tr>
                ))}
                {(!branches || branches.length === 0) && (
                  <tr><td colSpan={5} className="py-12 text-center text-slate-400">Belum ada cabang.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Tambah Cabang" />
          <form action={addBranch} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Kode</label><input className="input" name="code" placeholder="HQ" required /></div>
            <div><label className="label">Nama</label><input className="input" name="name" placeholder="Kantor Pusat" required /></div>
            <div><label className="label">Telepon</label><input className="input" name="phone" /></div>
            <div><label className="label">Email</label><input className="input" name="email" type="email" /></div>
            <div><label className="label">Alamat</label><textarea className="input" name="address" rows={2} /></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </div>
  );
}
