import { getDefaultCompany } from '@/lib/company';
import { getReceivableAging, getPayableAging } from '@/lib/finance';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

const BUCKET_COLORS = [
  'bg-emerald-50 text-emerald-600',
  'bg-amber-50 text-amber-600',
  'bg-orange-50 text-orange-600',
  'bg-red-50 text-red-600',
  'bg-red-100 text-red-700',
];

export default async function AgingPage() {
  const company = await getDefaultCompany();
  const [ar, ap] = await Promise.all([
    getReceivableAging(company.id),
    getPayableAging(company.id),
  ]);

  return (
    <ReportShell
      title="Aging Piutang & Hutang"
      subtitle={`${company.name} · Umur saldo terbuka berdasarkan jatuh tempo`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="aging-ar-ap"
          headers={['Tipe', 'Mitra', 'Referensi', 'Jatuh Tempo', 'Hari Lewat', 'Terbuka']}
          rows={[
            ...ar.rows.map((r: any) => ['AR', r.partnerName, r.refNumber, r.dueDate || '', r.daysOverdue, r.openAmount]),
            ...ap.rows.map((r: any) => ['AP', r.partnerName, r.refNumber, r.dueDate || '', r.daysOverdue, r.openAmount]),
          ]}
        />
      }
    >
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {[
          { title: 'Piutang (AR)', result: ar, empty: 'Tidak ada piutang terbuka.' },
          { title: 'Hutang (AP)', result: ap, empty: 'Tidak ada hutang terbuka.' },
        ].map(({ title, result, empty }) => (
          <Card key={title}>
            <CardHeader title={title} subtitle={`Total terbuka ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 2 }).format((result as any).totalOpen)}`} />
            <div className="overflow-x-auto">
              <table className="table-base">
                <thead>
                  <tr>
                    <th>Pihak</th>
                    <th>No. Ref</th>
                    <th className="text-right">Jatuh Tempo</th>
                    <th className="text-right">Umur</th>
                    <th className="text-right">Saldo</th>
                  </tr>
                </thead>
                <tbody>
                  {(result as any).rows.map((r: any) => (
                    <tr key={r.id}>
                      <td className="font-medium text-slate-800">{r.partnerName}</td>
                      <td className="font-mono text-xs text-brand-600">{r.refNumber}</td>
                      <td className="text-right text-slate-500">{formatDate(r.dueDate)}</td>
                      <td className="text-right">
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${BUCKET_COLORS[r.bucketIndex] || BUCKET_COLORS[0]}`}>
                          {r.daysOverdue === 0 ? 'Belum jatuh tempo' : `${r.daysOverdue} hari`}
                        </span>
                      </td>
                      <td className="text-right font-semibold">
                        <MoneyCell value={r.openAmount} />
                      </td>
                    </tr>
                  ))}
                  {(result as any).rows.length === 0 && (
                    <tr><td colSpan={5} className="py-10 text-center text-slate-400">{empty}</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="border-t border-slate-100 px-5 py-3">
              <div className="text-xs font-medium uppercase tracking-wide text-slate-500">Grup Umur</div>
              <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-5">
                {(result as any).buckets.map((b: any, i: number) => (
                  <div key={b.label} className={`rounded-lg px-2 py-1.5 text-center ${BUCKET_COLORS[i] || BUCKET_COLORS[0]}`}>
                    <div className="truncate text-[11px]">{b.label}</div>
                    <div className="text-sm font-bold">{new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(b.amount)}</div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </ReportShell>
  );
}
