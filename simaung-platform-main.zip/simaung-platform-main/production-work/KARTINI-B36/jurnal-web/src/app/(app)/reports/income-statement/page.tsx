import { getIncomeStatement } from '@/lib/reports';
import { getDefaultCompany } from '@/lib/company';
import { monthStartISO, monthEndISO } from '@/lib/format';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

export default async function IncomeStatementPage() {
  const company = await getDefaultCompany();
  const from = monthStartISO();
  const to = monthEndISO();
  const pl = await getIncomeStatement(company.id, from, to);

  return (
    <ReportShell
      title="Laba Rugi (Income Statement)"
      subtitle={`${company.name} · Periode ${from} s/d ${to}`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="laba-rugi"
          headers={['Kode', 'Pos', 'Jenis', 'Jumlah']}
          rows={[
            ...pl.revenueRows.map((r) => [r.code, r.name, 'Pendapatan', r.amount]),
            ...pl.expenseRows.map((r) => [r.code, r.name, 'Beban', r.amount]),
            ['', 'Laba Bersih', '', pl.netIncome],
          ]}
        />
      }
    >
      <Card>
        <CardHeader title="Pendapatan" subtitle={`${pl.revenueRows.length} pos pendapatan`} />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Kode</th>
                <th>Pendapatan</th>
                <th className="text-right">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              {pl.revenueRows.map((r) => (
                <tr key={r.code}>
                  <td className="font-mono text-xs text-brand-600">{r.code}</td>
                  <td>{r.name}</td>
                  <td className="text-right">
                    <MoneyCell value={r.amount} />
                  </td>
                </tr>
              ))}
              {pl.revenueRows.length === 0 && (
                <tr>
                  <td colSpan={3} className="py-8 text-center text-slate-400">
                    Belum ada pendapatan.
                  </td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr className="bg-emerald-50 font-semibold">
                <td colSpan={2} className="px-3 py-3 text-right text-xs uppercase text-emerald-700">
                  Total Pendapatan
                </td>
                <td className="px-3 py-3 text-right">
                  <MoneyCell value={pl.totalRevenue} />
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>

      <Card>
        <CardHeader title="Beban" subtitle={`${pl.expenseRows.length} pos beban`} />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Kode</th>
                <th>Beban</th>
                <th className="text-right">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              {pl.expenseRows.map((r) => (
                <tr key={r.code}>
                  <td className="font-mono text-xs text-brand-600">{r.code}</td>
                  <td>{r.name}</td>
                  <td className="text-right">
                    <MoneyCell value={r.amount} />
                  </td>
                </tr>
              ))}
              {pl.expenseRows.length === 0 && (
                <tr>
                  <td colSpan={3} className="py-8 text-center text-slate-400">
                    Belum ada beban.
                  </td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr className="bg-red-50 font-semibold">
                <td colSpan={2} className="px-3 py-3 text-right text-xs uppercase text-red-700">
                  Total Beban
                </td>
                <td className="px-3 py-3 text-right">
                  <MoneyCell value={-pl.totalExpenses} />
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between p-5">
          <div>
            <div className="text-sm text-slate-500">Laba / Rugi Bersih</div>
            <div className="text-xs text-slate-400">Pendapatan - Beban</div>
          </div>
          <div className="text-2xl font-bold">
            <MoneyCell
              value={pl.netIncome}
              className={pl.netIncome >= 0 ? 'text-emerald-600' : 'text-red-600'}
            />
          </div>
        </div>
      </Card>
    </ReportShell>
  );
}
