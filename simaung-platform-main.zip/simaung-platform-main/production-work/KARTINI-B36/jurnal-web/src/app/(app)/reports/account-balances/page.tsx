import { getDefaultCompany } from '@/lib/company';
import { listFiscalPeriods, listAccountBalances } from '@/lib/account-balances';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

export default async function AccountBalancesPage({
  searchParams,
}: {
  searchParams?: Promise<{ period?: string }>;
}) {
  const query = await searchParams;
  const company = await getDefaultCompany();
  const periods = await listFiscalPeriods(company.id);
  const selected = query?.period || periods[0]?.id || undefined;

  const rows = await listAccountBalances(company.id, selected);
  const period = periods.find((p) => p.id === selected);

  const totalOpeningDebit = rows.reduce((s, r) => s + Number(r.opening_debit || 0), 0);
  const totalOpeningCredit = rows.reduce((s, r) => s + Number(r.opening_credit || 0), 0);
  const totalPeriodDebit = rows.reduce((s, r) => s + Number(r.period_debit || 0), 0);
  const totalPeriodCredit = rows.reduce((s, r) => s + Number(r.period_credit || 0), 0);
  const totalClosingDebit = rows.reduce((s, r) => s + Number(r.closing_debit || 0), 0);
  const totalClosingCredit = rows.reduce((s, r) => s + Number(r.closing_credit || 0), 0);

  return (
    <ReportShell
      title="Saldo Akun per Periode"
      subtitle={`${company.name} · ${period?.name || 'Semua periode'} · ${rows.length} akun`}
      backHref="/reports/trial-balance"
      actions={
        <div className="flex items-center gap-2">
          <select
            className="input"
            defaultValue={selected || ''}
            onChange={(e) => window.location.assign(`/reports/account-balances?period=${e.target.value}`)}
          >
            <option value="">— Semua Periode —</option>
            {periods.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}{p.is_closed ? ' (tutup)' : ''}
              </option>
            ))}
          </select>
          <CsvExportButton
            filename="saldo-akun-periode"
            headers={['Kode', 'Nama Akun', 'Opening Debit', 'Opening Credit', 'Periode Debit', 'Periode Credit', 'Closing Debit', 'Closing Credit']}
            rows={rows.map((r) => [
              r.account_code,
              r.account_name,
              Number(r.opening_debit || 0),
              Number(r.opening_credit || 0),
              Number(r.period_debit || 0),
              Number(r.period_credit || 0),
              Number(r.closing_debit || 0),
              Number(r.closing_credit || 0),
            ])}
          />
        </div>
      }
    >
      <Card>
        <CardHeader title="Bagan Saldo" subtitle="Opening, pergerakan periode, dan closing per akun" />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Kode</th>
                <th>Nama Akun</th>
                <th className="text-right">Opening (D)</th>
                <th className="text-right">Opening (K)</th>
                <th className="text-right">Periode (D)</th>
                <th className="text-right">Periode (K)</th>
                <th className="text-right">Closing (D)</th>
                <th className="text-right">Closing (K)</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    Tidak ada saldo akun untuk periode ini.
                  </td>
                </tr>
              )}
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="font-mono text-xs text-brand-600">{r.account_code}</td>
                  <td className="font-medium text-slate-800">{r.account_name}</td>
                  <td className="text-right text-slate-600"><MoneyCell value={Number(r.opening_debit || 0)} /></td>
                  <td className="text-right text-slate-600"><MoneyCell value={Number(r.opening_credit || 0)} /></td>
                  <td className="text-right text-slate-600"><MoneyCell value={Number(r.period_debit || 0)} /></td>
                  <td className="text-right text-slate-600"><MoneyCell value={Number(r.period_credit || 0)} /></td>
                  <td className="text-right font-semibold text-slate-800"><MoneyCell value={Number(r.closing_debit || 0)} /></td>
                  <td className="text-right font-semibold text-slate-800"><MoneyCell value={Number(r.closing_credit || 0)} /></td>
                </tr>
              ))}
            </tbody>
            {rows.length > 0 && (
              <tfoot>
                <tr className="border-t border-slate-200 bg-slate-50 font-semibold">
                  <td colSpan={2} className="text-slate-700">Total</td>
                  <td className="text-right"><MoneyCell value={totalOpeningDebit} /></td>
                  <td className="text-right"><MoneyCell value={totalOpeningCredit} /></td>
                  <td className="text-right"><MoneyCell value={totalPeriodDebit} /></td>
                  <td className="text-right"><MoneyCell value={totalPeriodCredit} /></td>
                  <td className="text-right"><MoneyCell value={totalClosingDebit} /></td>
                  <td className="text-right"><MoneyCell value={totalClosingCredit} /></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </Card>
    </ReportShell>
  );
}
