import { getDefaultCompany } from '@/lib/company';
import { listAllocations } from '@/lib/allocations';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

export default async function AllocationsPage() {
  const company = await getDefaultCompany();
  const rows = await listAllocations(company.id);

  const totalIn = rows.filter((r) => r.direction === 'in').reduce((s, r) => s + r.amount, 0);
  const totalOut = rows.filter((r) => r.direction === 'out').reduce((s, r) => s + r.amount, 0);

  return (
    <ReportShell
      title="Alokasi Pembayaran"
      subtitle={`${company.name} · ${rows.length} alokasi`}
      backHref="/payments"
      actions={
        <CsvExportButton
          filename="alokasi-pembayaran"
          headers={['Payment', 'Tanggal', 'Arah', 'Pihak', 'Invoice', 'Bill', 'Jumlah']}
          rows={rows.map((r) => [
            r.payment_number,
            r.payment_date,
            r.direction === 'in' ? 'Masuk' : 'Keluar',
            r.party,
            r.invoice_number || '',
            r.bill_number || '',
            r.amount,
          ])}
        />
      }
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Total Alokasi</div>
            <div className="mt-1 text-xl font-bold text-slate-800"><MoneyCell value={totalIn + totalOut} /></div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Masuk (Terima)</div>
            <div className="mt-1 text-xl font-bold text-emerald-600"><MoneyCell value={totalIn} /></div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Keluar (Bayar)</div>
            <div className="mt-1 text-xl font-bold text-red-600"><MoneyCell value={totalOut} /></div>
          </div>
        </Card>
      </div>

      <Card>
        <CardHeader title="Rincian Alokasi" subtitle="Pembayaran vs faktur / bill yang ditagih" />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>No. Pembayaran</th>
                <th className="text-right">Tanggal</th>
                <th>Arah</th>
                <th>Pihak</th>
                <th>Invoice</th>
                <th>Bill</th>
                <th className="text-right">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    Belum ada alokasi pembayaran. Buat pembayaran dan kaitkan ke invoice/bill.
                  </td>
                </tr>
              )}
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="font-mono text-xs text-brand-600">{r.payment_number}</td>
                  <td className="text-right text-slate-500">{formatDate(r.payment_date)}</td>
                  <td>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${r.direction === 'in' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                      {r.direction === 'in' ? 'Masuk' : 'Keluar'}
                    </span>
                  </td>
                  <td className="font-medium text-slate-800">{r.party}</td>
                  <td className="font-mono text-xs text-slate-600">{r.invoice_number || '—'}</td>
                  <td className="font-mono text-xs text-slate-600">{r.bill_number || '—'}</td>
                  <td className="text-right font-semibold text-slate-800"><MoneyCell value={r.amount} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </ReportShell>
  );
}
