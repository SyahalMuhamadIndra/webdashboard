import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { createAdminClient } from '@/lib/supabase/admin';
import { getDefaultCompany } from '@/lib/company';
import { JournalEntryForm } from '@/components/journal-entry-form';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function NewJournalPage() {
  const company = await getDefaultCompany();
  const supabase = createAdminClient();

  const { data: accounts, error } = await supabase
    .from('accounts')
    .select('id, code, name, type_of_account!inner(normal_balance, report_section)')
    .eq('company_id', company.id)
    .eq('is_active', true)
    .order('code');

  if (error) {
    return (
      <div className="text-center py-20 text-slate-500">Gagal memuat akun: {error.message}</div>
    );
  }

  const accountOptions = (accounts || []).map((a: any) => ({
    id: a.id,
    code: a.code,
    name: a.name,
    normal_balance: a.type_of_account?.normal_balance || 'debit',
    report_section: a.type_of_account?.report_section || '',
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/journal" className="btn-secondary">
          <ArrowLeft className="h-4 w-4" /> Kembali
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Entri Jurnal Baru</h1>
          <p className="text-sm text-slate-500">{company.name}</p>
        </div>
      </div>

      <Card>
        <CardHeader title="Form Entri Jurnal" subtitle="Double-entry — total debit harus = total kredit" />
        <div className="p-5">
          <JournalEntryForm companyId={company.id} accounts={accountOptions} />
        </div>
      </Card>
    </div>
  );
}
