import { readMaintenanceStatus } from '@/lib/maintenance-server';
import { redirect } from 'next/navigation';
import { getDefaultCompany } from '@/lib/company';
import { getSession } from '@/lib/session';
import { Sidebar } from '@/components/sidebar';

export const dynamic = 'force-dynamic';

// Gerbang login: wajib punya sesi (cookie bertanda-tangan).
// Sesi dibuat saat login ke backend terpadu (api.tokokartini.com).
export default async function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();
  if (!session) {
    redirect('/login');
  }

  const service = await readMaintenanceStatus();
  if (service.enabled) return <main data-maintenance-page style={{padding:32, textAlign:'center'}}>
    <h1>Layanan ditutup sementara</h1><p>{service.message}</p><a href="/dashboard">Periksa kembali</a>
  </main>;

  let companyName = 'Simaung Corporation';
  try {
    const company = await getDefaultCompany();
    companyName = company.name;
  } catch {
    // company may not exist yet; layout still renders with default title
  }

  return (
    <div className="flex min-h-screen flex-col bg-slate-100/60 xl:flex-row">
      <Sidebar companyName={companyName} userName={session.name} />
      <main className="min-w-0 flex-1 overflow-x-hidden overflow-y-auto p-4 md:p-6 lg:p-8">
        <div className="animate-fade-in mx-auto w-full max-w-7xl">{children}</div>
      </main>
    </div>
  );
}
