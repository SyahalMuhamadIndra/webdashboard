import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listStockOpnames } from '@/lib/ops';
import { listProducts, listLocations } from '@/lib/odoo';
import { createOpname } from '@/app/actions/ops';
import { ReportShell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function OpnamePage() {
  const company = await getDefaultCompany();
  const [opnames, products, locations] = await Promise.all([
    listStockOpnames(company.id),
    listProducts(company.id),
    listLocations(company.id),
  ]);

  return (
    <ReportShell title="Stock Opname" subtitle={`${company.name} · Penghitungan fisik persediaan`} backHref="/inventory">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Opname" subtitle={`${opnames.length} dokumen`} />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Gudang</th>
                  <th className="text-right">Tanggal</th>
                  <th className="text-right">Baris</th>
                  <th className="text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {opnames.map((o: any) => (
                  <tr key={o.id}>
                    <td className="font-mono text-xs text-brand-600">{o.opname_number}</td>
                    <td className="font-medium text-slate-800">{o.warehouse?.name || '-'}</td>
                    <td className="text-right text-slate-500">{formatDate(o.opname_date)}</td>
                    <td className="text-right text-slate-500">{o.stock_opname_lines?.length ?? 0}</td>
                    <td className="text-right">
                      <span className="rounded-full bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-600">{o.status}</span>
                    </td>
                  </tr>
                ))}
                {opnames.length === 0 && (
                  <tr><td colSpan={5} className="py-12 text-center text-slate-400">Belum ada opname.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Opname" />
          <form action={createOpname} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">No. Opname</label>
              <input className="input" name="opname_number" placeholder="OPN-0001" required />
            </div>
            <div>
              <label className="label">Gudang</label>
              <select className="input" name="warehouse_id" required>
                <option value="">— Pilih —</option>
                {locations.map((l: any) => <option key={l.id} value={l.id}>{l.name} ({l.code})</option>)}
              </select>
            </div>
            <div>
              <label className="label">Tanggal</label>
              <input className="input" type="date" name="opname_date" defaultValue={new Date().toISOString().slice(0, 10)} required />
            </div>
            <div>
              <label className="label">Produk & Qty Faktual</label>
              <div className="space-y-2">
                {products.map((p: any) => (
                  <div key={p.id} className="flex items-center gap-2 text-sm">
                    <span className="flex-1 truncate text-slate-600">{p.sku} · {p.name}</span>
                    <input type="hidden" name="product_id" value={p.id} />
                    <input className="input w-24" type="number" name="actual_qty" defaultValue={0} step="any" />
                  </div>
                ))}
                {products.length === 0 && <p className="text-xs text-slate-400">Belum ada produk.</p>}
              </div>
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan Opname</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
