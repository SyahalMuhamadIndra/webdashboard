import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listPayments, listCustomers, listSuppliers, listReceivables, listPayables } from '@/lib/odoo';
import { createPayment } from '@/app/actions/transactions';
import { Card, CardHeader } from '@/components/ui/card';
import { formatIDR, formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function PaymentsPage() {
  const company = await getDefaultCompany();
  const [payments, customers, suppliers, recvs, pays] = await Promise.all([
    listPayments(company.id),
    listCustomers(company.id),
    listSuppliers(company.id),
    listReceivables(company.id),
    listPayables(company.id),
  ]);
  const today = new Date().toISOString().slice(0, 10);

  const openRecv = (recvs || []).filter((r: any) => (r.paid_amount || 0) < (r.original_amount || 0));
  const openPay = (pays || []).filter((p: any) => (p.paid_amount || 0) < (p.original_amount || 0));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Pembayaran</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {payments.length} transaksi</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Riwayat Pembayaran" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Tanggal</th>
                  <th>Arah</th>
                  <th>Pihak</th>
                  <th className="text-right">Jumlah</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {(payments || []).map((p: any) => (
                  <tr key={p.id}>
                    <td className="font-mono text-xs text-brand-600">{p.payment_number}</td>
                    <td className="whitespace-nowrap">{formatDate(p.payment_date)}</td>
                    <td>
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${p.direction === 'in' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                        {p.direction === 'in' ? 'Masuk' : 'Keluar'}
                      </span>
                    </td>
                    <td className="font-medium text-slate-800">{p.customers?.name || p.suppliers?.name || '-'}</td>
                    <td className="text-right font-semibold">{formatIDR(p.amount)}</td>
                    <td className="text-xs text-slate-500">{p.status}</td>
                  </tr>
                ))}
                {(!payments || payments.length === 0) && (
                  <tr><td colSpan={6} className="py-12 text-center text-slate-400">Belum ada pembayaran.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Pembayaran" />
          <form action={createPayment} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Arah</label>
              <select className="input" name="direction">
                <option value="in">Masuk (Terima dari Pelanggan)</option>
                <option value="out">Keluar (Bayar ke Pemasok)</option>
              </select>
            </div>
            <div>
              <label className="label">Pelanggan</label>
              <select className="input" name="customer_id">
                <option value="">—</option>
                {(customers || []).map((c: any) => <option key={c.id} value={c.id}>{c.code} · {c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Pemasok</label>
              <select className="input" name="supplier_id">
                <option value="">—</option>
                {(suppliers || []).map((s: any) => <option key={s.id} value={s.id}>{s.code} · {s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Tanggal</label>
              <input className="input" name="payment_date" type="date" defaultValue={today} required />
            </div>
            <div><label className="label">Jumlah</label><input className="input" name="amount" type="number" step="0.01" required /></div>
            <button type="submit" className="btn-primary w-full justify-center">Posting Pembayaran</button>
            <p className="text-center text-xs text-slate-400">Akan membuat jurnal kas/piutang atau kas/hutang.</p>
          </form>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Piutang Terbuka" subtitle={`${openRecv.length} piutang belum lunas`} />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>Pelanggan</th><th className="text-right">Sisa</th><th className="text-right">Jatuh Tempo</th></tr></thead>
              <tbody>
                {openRecv.slice(0, 10).map((r: any) => (
                  <tr key={r.id}>
                    <td className="font-medium text-slate-800">{r.customers?.name}</td>
                    <td className="text-right text-red-600">{formatIDR(r.original_amount - r.paid_amount)}</td>
                    <td className="text-right text-slate-500">{formatDate(r.due_date)}</td>
                  </tr>
                ))}
                {openRecv.length === 0 && <tr><td colSpan={3} className="py-8 text-center text-slate-400">Tidak ada piutang terbuka.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>
        <Card>
          <CardHeader title="Hutang Terbuka" subtitle={`${openPay.length} hutang belum lunas`} />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>Pemasok</th><th className="text-right">Sisa</th><th className="text-right">Jatuh Tempo</th></tr></thead>
              <tbody>
                {openPay.slice(0, 10).map((p: any) => (
                  <tr key={p.id}>
                    <td className="font-medium text-slate-800">{p.suppliers?.name}</td>
                    <td className="text-right text-red-600">{formatIDR(p.original_amount - p.paid_amount)}</td>
                    <td className="text-right text-slate-500">{formatDate(p.due_date)}</td>
                  </tr>
                ))}
                {openPay.length === 0 && <tr><td colSpan={3} className="py-8 text-center text-slate-400">Tidak ada hutang terbuka.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
