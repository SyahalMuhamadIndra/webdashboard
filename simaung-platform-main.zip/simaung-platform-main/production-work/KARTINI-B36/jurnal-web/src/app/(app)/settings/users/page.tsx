import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listUsers } from '@/lib/users';
import { listRoles } from '@/lib/rbac';
import { assignRoleAction, toggleUserActiveAction } from '@/app/actions/users';
import { ReportShell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function UsersPage() {
  const company = await getDefaultCompany();
  const [users, roles] = await Promise.all([
    listUsers(company.id),
    listRoles(company.id),
  ]);

  return (
    <ReportShell
      title="Manajemen Pengguna"
      subtitle={`${company.name} · ${users.length} pengguna`}
      backHref="/settings"
    >
      <Card>
        <CardHeader title="Daftar Pengguna" subtitle="Kelola akun & assign role" />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Email</th>
                <th>Nama</th>
                <th className="text-right">Terdaftar</th>
                <th className="text-right">Roles</th>
                <th className="text-right">Status</th>
              </tr>
            </thead>
            <tbody>
              {users.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    Belum ada pengguna terhubung ke perusahaan ini.
                  </td>
                </tr>
              )}
              {users.map((u: any) => (
                <tr key={u.id}>
                  <td className="font-medium text-slate-800">{u.email}</td>
                  <td className="text-slate-500">{u.full_name || '—'}</td>
                  <td className="text-right text-slate-500">{formatDate(u.created_at)}</td>
                  <td className="text-right">
                    <div className="flex flex-wrap items-center justify-end gap-1">
                      {roles.map((r: any) => {
                        const granted = (u.roles || []).includes(r.id);
                        return (
                          <form key={r.id} action={assignRoleAction} className="inline"><OperationKey />
                            <input type="hidden" name="userId" value={u.id} />
                            <input type="hidden" name="roleId" value={r.id} />
                            <input type="hidden" name="enabled" value={String(!granted)} />
                            <button
                              type="submit"
                              className={`rounded-full px-2 py-0.5 text-[10px] font-medium transition-colors ${
                                granted
                                  ? 'bg-brand-600 text-white'
                                  : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                              }`}
                              title={granted ? `Cabut ${r.name}` : `Beri ${r.name}`}
                            >
                              {r.name}
                            </button>
                          </form>
                        );
                      })}
                    </div>
                  </td>
                  <td className="text-right">
                    <form action={toggleUserActiveAction} className="inline"><OperationKey />
                      <input type="hidden" name="userId" value={u.id} />
                      <input type="hidden" name="isActive" value={String(u.is_active)} />
                      <button
                        type="submit"
                        className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                          u.is_active
                            ? 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'
                            : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                        title={u.is_active ? 'Nonaktifkan' : 'Aktifkan'}
                      >
                        {u.is_active ? 'Aktif' : 'Nonaktif'}
                      </button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </ReportShell>
  );
}
