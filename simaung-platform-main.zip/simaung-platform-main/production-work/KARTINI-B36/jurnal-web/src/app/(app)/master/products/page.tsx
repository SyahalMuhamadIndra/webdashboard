import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listProducts, listUnits, listCategories } from '@/lib/odoo';
import { createNewProduct, createNewCategory, createNewUnit } from '@/app/actions/master';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function MasterProductsPage() {
  const company = await getDefaultCompany();
  const [products, units, categories] = await Promise.all([
    listProducts(company.id),
    listUnits(company.id),
    listCategories(company.id),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Produk</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {products.length} produk</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Produk" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>SKU</th>
                  <th>Nama</th>
                  <th>Kategori</th>
                  <th>Satuan</th>
                  <th>Stok</th>
                  <th>Metode</th>
                </tr>
              </thead>
              <tbody>
                {(products || []).map((p: any) => (
                  <tr key={p.id}>
                    <td className="font-mono text-xs text-brand-600">{p.sku}</td>
                    <td className="font-medium text-slate-800">{p.name}</td>
                    <td className="text-slate-600">{p.categories?.name || '-'}</td>
                    <td className="text-slate-600">{p.units?.code || '-'}</td>
                    <td className="text-slate-600">{p.is_track_inventory ? 'Ya' : 'Tidak'}</td>
                    <td className="text-slate-600">{p.cost_method}</td>
                  </tr>
                ))}
                {(!products || products.length === 0) && (
                  <tr><td colSpan={6} className="py-12 text-center text-slate-400">Belum ada produk.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Tambah Produk" />
          <form action={createNewProduct} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">SKU</label><input className="input" name="sku" placeholder="Otomatis jika kosong" /></div>
            <div><label className="label">Nama</label><input className="input" name="name" required /></div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="label">Kategori</label>
                <select className="input" name="category_id">
                  <option value="">—</option>
                  {(categories || []).map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Satuan</label>
                <select className="input" name="unit_id">
                  <option value="">—</option>
                  {(units || []).map((u: any) => <option key={u.id} value={u.id}>{u.code}</option>)}
                </select>
              </div>
            </div>
            <div><label className="label">Barcode</label><input className="input" name="barcode" /></div>
            <div>
              <label className="label">Metode Biaya</label>
              <select className="input" name="cost_method">
                <option value="average">Average</option>
                <option value="fifo">FIFO</option>
                <option value="standard">Standard</option>
              </select>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" name="is_track_inventory" defaultChecked /> Lacak persediaan
            </label>
            <div><label className="label">Deskripsi</label><textarea className="input" name="description" rows={2} /></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan Produk</button>
          </form>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Kategori" />
          <form action={createNewCategory} className="flex gap-2 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <input className="input" name="name" placeholder="Nama kategori baru" required />
            <button type="submit" className="btn-secondary shrink-0">Tambah</button>
          </form>
          <div className="flex flex-wrap gap-2 px-5 pb-5">
            {(categories || []).map((c: any) => (
              <span key={c.id} className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600">{c.name}</span>
            ))}
          </div>
        </Card>
        <Card>
          <CardHeader title="Satuan" />
          <form action={createNewUnit} className="flex gap-2 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <input className="input" name="name" placeholder="Nama satuan" required />
            <input className="input max-w-[100px]" name="code" placeholder="Kode" required />
            <button type="submit" className="btn-secondary shrink-0">Tambah</button>
          </form>
          <div className="flex flex-wrap gap-2 px-5 pb-5">
            {(units || []).map((u: any) => (
              <span key={u.id} className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600">{u.code} · {u.name}</span>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
