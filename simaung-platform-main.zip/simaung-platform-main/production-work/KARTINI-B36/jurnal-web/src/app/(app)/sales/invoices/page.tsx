import {OperationKey} from '@/components/operation-key';
import Link from 'next/link';
import { getDefaultCompany } from '@/lib/company';
import { listInvoices, listCustomers } from '@/lib/odoo';
import { createInvoice } from '@/app/actions/transactions';
import { Card, CardHeader } from '@/components/ui/card';
import { formatIDR, formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function InvoicesPage() {
  const company = await getDefaultCompany();
  const [invoices, customers] = await Promise.all([
    listInvoices(company.id),
    listCustomers(company.id),
  ]);
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Invoice Penjualan</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {invoices.length} invoice</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Invoice" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Tanggal</th>
                  <th>Pelanggan</th>
                  <th className="text-right">Subtotal</th>
                  <th className="text-right">Total</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {(invoices || []).map((inv: any) => (
                  <tr key={inv.id}>
                    <td className="font-mono text-xs text-brand-600">
                      <Link href={`/sales/invoices/${inv.id}`} className="hover:underline">{inv.invoice_number}</Link>
                    </td>
                    <td className="whitespace-nowrap">{formatDate(inv.invoice_date)}</td>
                    <td className="font-medium text-slate-800">{inv.customers?.name}</td>
                    <td className="text-right">{formatIDR(inv.subtotal)}</td>
                    <td className="text-right font-semibold">{formatIDR(inv.total)}</td>
                    <td>
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${inv.status === 'paid' ? 'bg-emerald-50 text-emerald-600' : inv.status === 'posted' ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-500'}`}>
                        {inv.status}
                      </span>
                    </td>
                  </tr>
                ))}
                {(!invoices || invoices.length === 0) && (
                  <tr><td colSpan={6} className="py-12 text-center text-slate-400">Belum ada invoice.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Invoice" subtitle="Posting jurnal otomatis (double-entry)" />
          <form action={createInvoice} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Pelanggan</label>
              <select className="input" name="customer_id" required>
                <option value="">— Pilih —</option>
                {(customers || []).map((c: any) => <option key={c.id} value={c.id}>{c.code} · {c.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Tanggal</label><input className="input" name="invoice_date" type="date" defaultValue={today} required /></div>
              <div><label className="label">Jatuh Tempo</label><input className="input" name="due_date" type="date" /></div>
            </div>
            <div><label className="label">Deskripsi Item</label><input className="input" name="desc" placeholder="Penjualan barang/jasa" /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Qty</label><input className="input" name="qty" type="number" defaultValue="1" min="1" required /></div>
              <div><label className="label">Harga</label><input className="input" name="price" type="number" step="0.01" defaultValue="0" required /></div>
            </div>
            <div><label className="label">Diskon (%)</label><input className="input" name="discount" type="number" defaultValue="0" /></div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" name="is_cash_sale" /> Penjualan Tunai (tanpa piutang)
            </label>
            <button type="submit" className="btn-primary w-full justify-center">Posting Invoice</button>
            <p className="text-center text-xs text-slate-400">Akan membuat jurnal debit piutang/kas, kredit pendapatan.</p>
          </form>
          <div className="border-t border-slate-100 px-5 py-3">
            <Link href="/journal" className="btn-secondary w-full justify-center">Lihat Jurnal</Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
