import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listQuotations } from '@/lib/modules';
import { listCustomers, listProducts } from '@/lib/odoo';
import { addQuotation, convertQuotationToInvoiceAction } from '@/app/actions/modules';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function QuotationsPage() {
  const company = await getDefaultCompany();
  const [quotations, customers, products] = await Promise.all([
    listQuotations(company.id), listCustomers(company.id), listProducts(company.id),
  ]);

  return (
    <ReportShell title="Quotation / Penawaran" subtitle={`${company.name} · ${quotations.length} penawaran`} backHref="/dashboard">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Penawaran" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>No.</th><th>Pelanggan</th><th className="text-right">Tanggal</th><th className="text-right">Total</th><th className="text-right">Status</th><th className="text-right">Aksi</th></tr></thead>
              <tbody>
                {quotations.map((q: any) => (
                  <tr key={q.id}>
                    <td className="font-mono text-xs text-brand-600">{q.quotation_number}</td>
                    <td className="font-medium text-slate-800">{q.customer_id ? (customers.find((c:any)=>c.id===q.customer_id)?.name || '-') : '-'}</td>
                    <td className="text-right text-slate-500">{formatDate(q.quotation_date)}</td>
                    <td className="text-right"><MoneyCell value={q.total} /></td>
                    <td className="text-right"><span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-600">{q.status}</span></td>
                    <td className="text-right">
                      {q.converted_invoice_id ? (
                        <span className="text-xs text-emerald-600">✓ Invoice</span>
                      ) : (
                        <form action={convertQuotationToInvoiceAction} className="inline"><OperationKey />
                          <input type="hidden" name="companyId" value={company.id} />
                          <input type="hidden" name="quotationId" value={q.id} />
                          <button type="submit" className="rounded-md bg-brand-50 px-2 py-1 text-xs font-medium text-brand-700 hover:bg-brand-100">
                            Konversi → Invoice
                          </button>
                        </form>
                      )}
                    </td>
                  </tr>
                ))}
                {quotations.length === 0 && <tr><td colSpan={6} className="py-12 text-center text-slate-400">Belum ada penawaran.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Penawaran" />
          <form action={addQuotation} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Pelanggan</label><select className="input" name="customer_id"><option value="">— Pilih —</option>{customers.map((c:any)=><option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
            <div><label className="label">Produk</label><select className="input" name="product_id"><option value="">— Pilih —</option>{products.map((p:any)=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
            <div className="grid grid-cols-2 gap-2"><div><label className="label">Qty</label><input className="input" type="number" name="quantity" defaultValue={1} /></div><div><label className="label">Harga</label><input className="input" type="number" name="unit_price" defaultValue={0} /></div></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
