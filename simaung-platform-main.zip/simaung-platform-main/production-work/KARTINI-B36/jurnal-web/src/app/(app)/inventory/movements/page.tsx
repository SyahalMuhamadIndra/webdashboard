import { getDefaultCompany } from '@/lib/company';
import { listStockMovements } from '@/lib/logistics';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDateTime } from '@/lib/format';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

const MOVE_LABEL: Record<string, string> = {
  adjustment: 'Penyesuaian',
  purchase: 'Pembelian',
  sale: 'Penjualan',
  transfer_in: 'Transfer Masuk',
  transfer_out: 'Transfer Keluar',
};

const MOVE_ICON: Record<string, string> = {
  adjustment: 'bg-amber-50 text-amber-600',
  purchase: 'bg-emerald-50 text-emerald-600',
  sale: 'bg-blue-50 text-blue-600',
  transfer_in: 'bg-violet-50 text-violet-600',
  transfer_out: 'bg-rose-50 text-rose-600',
};

export default async function StockMovementsPage() {
  const company = await getDefaultCompany();
  const movements = await listStockMovements(company.id);

  return (
    <ReportShell
      title="Riwayat Mutasi Stok"
      subtitle={`${company.name} · ${movements.length} pergerakan`}
      backHref="/inventory"
      actions={
        <CsvExportButton
          filename="mutasi-stok"
          headers={['Tanggal', 'Produk', 'SKU', 'Gudang', 'Tipe', 'Qty', 'Unit Cost', 'Keterangan']}
          rows={movements.map((m: any) => [
            formatDateTime(m.created_at),
            m.products?.name,
            m.products?.sku,
            m.warehouses?.name,
            MOVE_LABEL[m.movement_type] || m.movement_type,
            Number(m.quantity),
            Number(m.unit_cost),
            m.description || '',
          ])}
        />
      }
    >
      <Card>
        <CardHeader title="Pergerakan Barang" subtitle="Semua mutasi masuk/keluar/pindah" />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Tanggal</th>
                <th>Produk</th>
                <th>Gudang</th>
                <th>Tipe</th>
                <th className="text-right">Qty</th>
                <th className="text-right">Unit Cost</th>
              </tr>
            </thead>
            <tbody>
              {movements.map((m: any) => (
                <tr key={m.id}>
                  <td className="text-slate-500">{formatDateTime(m.created_at)}</td>
                  <td className="font-medium text-slate-800">
                    {m.products?.name}
                    {m.products?.sku ? <span className="ml-1 font-mono text-xs text-brand-600">{m.products.sku}</span> : null}
                  </td>
                  <td className="text-slate-500">{m.warehouses?.name || '—'}</td>
                  <td>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${MOVE_ICON[m.movement_type] || 'bg-slate-100 text-slate-600'}`}>
                      {MOVE_LABEL[m.movement_type] || m.movement_type}
                    </span>
                  </td>
                  <td className={`text-right font-semibold ${Number(m.quantity) >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                    {Number(m.quantity) > 0 ? '+' : ''}{Number(m.quantity).toLocaleString('id-ID')}
                  </td>
                  <td className="text-right text-slate-600"><MoneyCell value={Number(m.unit_cost)} /></td>
                </tr>
              ))}
              {movements.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Belum ada mutasi stok. Lakukan penyesuaian atau transaksi barang terlebih dahulu.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </ReportShell>
  );
}
