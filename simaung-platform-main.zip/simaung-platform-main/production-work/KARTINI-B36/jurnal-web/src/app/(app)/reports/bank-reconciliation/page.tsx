import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listReconciliations } from '@/lib/modules';
import { addReconciliation } from '@/app/actions/modules';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function BankReconPage() {
  const company = await getDefaultCompany();
  const reconciliations = await listReconciliations(company.id);

  return (
    <ReportShell title="Rekonsiliasi Bank" subtitle={`${company.name} · ${reconciliations.length} rekonsiliasi`} backHref="/dashboard">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Riwayat Rekonsiliasi" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th className="text-right">Tanggal</th><th className="text-right">Saldo Buku</th><th className="text-right">Saldo Bank</th><th className="text-right">Selisih</th><th className="text-right">Status</th></tr></thead>
              <tbody>
                {reconciliations.map((r:any)=>(<tr key={r.id}><td className="text-right text-slate-500">{formatDate(r.recon_date)}</td><td className="text-right"><MoneyCell value={r.book_balance} /></td><td className="text-right"><MoneyCell value={r.statement_balance} /></td><td className="text-right"><MoneyCell value={r.difference} /></td><td className="text-right"><span className={`rounded-full px-2 py-0.5 text-xs font-medium ${r.difference===0?'bg-emerald-50 text-emerald-600':'bg-amber-50 text-amber-600'}`}>{r.status}</span></td></tr>))}
                {reconciliations.length===0 && <tr><td colSpan={5} className="py-12 text-center text-slate-400">Belum ada rekonsiliasi.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>
        <Card>
          <CardHeader title="Buat Rekonsiliasi" />
          <form action={addReconciliation} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Saldo Buku</label><input className="input" type="number" name="book_balance" defaultValue={0} /></div>
            <div><label className="label">Saldo Bank</label><input className="input" type="number" name="statement_balance" defaultValue={0} /></div>
            <div><label className="label">Catatan</label><input className="input" name="notes" /></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
