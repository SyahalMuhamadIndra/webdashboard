import { getDefaultCompany } from '@/lib/company';
import { listPayables } from '@/lib/odoo';
import { Card, CardHeader } from '@/components/ui/card';
import { formatIDR, formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function APPage() {
  const company = await getDefaultCompany();
  const payables = await listPayables(company.id);

  const totalOpen = (payables || []).reduce((s, p: any) => s + (Number(p.original_amount) - Number(p.paid_amount || 0)), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Hutang Usaha (Accounts Payable)</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · Total hutang terbuka {formatIDR(totalOpen)}</p>
      </div>

      <Card>
        <CardHeader title="Daftar Hutang" />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Pemasok</th>
                <th>Bill</th>
                <th className="text-right">Nilai Awal</th>
                <th className="text-right">Sudah Dibayar</th>
                <th className="text-right">Sisa</th>
                <th className="text-right">Jatuh Tempo</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {(payables || []).map((p: any) => {
                const open = Number(p.original_amount) - Number(p.paid_amount || 0);
                return (
                  <tr key={p.id}>
                    <td className="font-medium text-slate-800">{p.suppliers?.name}</td>
                    <td className="font-mono text-xs text-brand-600">{p.bills?.bill_number || '-'}</td>
                    <td className="text-right">{formatIDR(p.original_amount)}</td>
                    <td className="text-right text-emerald-600">{formatIDR(p.paid_amount)}</td>
                    <td className="text-right font-semibold text-red-600">{formatIDR(open)}</td>
                    <td className="text-right text-slate-500">{formatDate(p.due_date)}</td>
                    <td>
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${p.status === 'paid' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                        {p.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {(!payables || payables.length === 0) && (
                <tr><td colSpan={7} className="py-12 text-center text-slate-400">Belum ada hutang.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
