import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listRecurring } from '@/lib/recurring';
import { listCustomers, listProducts } from '@/lib/odoo';
import { addRecurring, runRecurringNow, disableRecurring } from '@/app/actions/recurring';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

const INTERVALS: Record<string, string> = {
  daily: 'Harian',
  weekly: 'Mingguan',
  monthly: 'Bulanan',
  yearly: 'Tahunan',
};

const INTERVAL_ICON: Record<string, string> = {
  daily: 'bg-emerald-50 text-emerald-600',
  weekly: 'bg-blue-50 text-blue-600',
  monthly: 'bg-indigo-50 text-indigo-600',
  yearly: 'bg-violet-50 text-violet-600',
};

export default async function RecurringPage() {
  const company = await getDefaultCompany();
  const [recurring, customers, products] = await Promise.all([
    listRecurring(company.id),
    listCustomers(company.id),
    listProducts(company.id),
  ]);

  return (
    <ReportShell
      title="Invois Berulang (Subscription)"
      subtitle={`${company.name} · ${recurring.length} langganan`}
      backHref="/dashboard"
    >
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Langganan" subtitle="Invoice periodik otomatis" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Pelanggan</th>
                  <th>Interval</th>
                  <th className="text-right">Jatuh Tempo Berikut</th>
                  <th className="text-right">Aktif</th>
                  <th className="text-right">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {recurring.map((r: any) => {
                  const total = (r.recurring_invoice_items || []).reduce(
                    (s: number, l: any) => s + Number(l.line_total) + Number(l.line_total) * 0.11,
                    0
                  );
                  return (
                    <tr key={r.id}>
                      <td className="font-medium text-slate-800">
                        {r.customers?.name || '—'}
                        {r.description ? <span className="ml-2 text-xs text-slate-400">· {r.description}</span> : null}
                      </td>
                      <td>
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${INTERVAL_ICON[r.interval_type] || 'bg-slate-100 text-slate-600'}`}>
                          {INTERVALS[r.interval_type] || r.interval_type}
                        </span>
                        <span className="ml-2 text-xs text-slate-400">
                          <MoneyCell value={total} />
                        </span>
                      </td>
                      <td className="text-right text-slate-500">{formatDate(r.next_run_date)}</td>
                      <td className="text-right">
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${r.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-500'}`}>
                          {r.is_active ? 'Aktif' : 'Nonaktif'}
                        </span>
                      </td>
                      <td className="text-right">
                        {r.is_active ? (
                          <form action={disableRecurring} className="inline"><OperationKey />
                            <input type="hidden" name="id" value={r.id} />
                            <button type="submit" className="rounded-md bg-slate-50 px-2 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100">
                              Nonaktifkan
                            </button>
                          </form>
                        ) : (
                          <span className="text-xs text-slate-400">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
                {recurring.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-400">
                      Belum ada langganan. Buat langganan pertama Anda.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between border-t border-slate-100 px-5 py-3">
            <span className="text-xs text-slate-400">Proses & buat invoice untuk semua langganan yang jatuh tempo.</span>
            <form action={runRecurringNow}><OperationKey />
              <input type="hidden" name="companyId" value={company.id} />
              <button type="submit" className="btn-primary">Jalankan Sekarang</button>
            </form>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Langganan" subtitle="Invoice otomatis per interval" />
          <form action={addRecurring} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Pelanggan</label>
              <select className="input" name="customer_id">
                <option value="">— Pilih —</option>
                {customers.map((c: any) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Interval</label>
              <select className="input" name="interval_type">
                <option value="daily">Harian</option>
                <option value="weekly">Mingguan</option>
                <option value="monthly" defaultChecked>Bulanan</option>
                <option value="yearly">Tahunan</option>
              </select>
            </div>
            <div>
              <label className="label">Tanggal Mulai</label>
              <input className="input" type="date" name="start_date" defaultValue={new Date().toISOString().slice(0, 10)} />
            </div>
            <div>
              <label className="label">Deskripsi</label>
              <input className="input" name="description" placeholder="Langganan bulanan" />
            </div>
            <div>
              <label className="label">Produk</label>
              <select className="input" name="product_id">
                <option value="">— Pilih —</option>
                {products.map((p: any) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="label">Qty</label>
                <input className="input" type="number" name="quantity" defaultValue={1} />
              </div>
              <div>
                <label className="label">Harga</label>
                <input className="input" type="number" name="unit_price" defaultValue={0} />
              </div>
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
