import { getCashFlow, getCashFlowForecast } from '@/lib/reports';
import { getDefaultCompany } from '@/lib/company';
import { monthStartISO, monthEndISO } from '@/lib/format';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';
import { ArrowDownRight, ArrowUpRight, Scale, TrendingUp } from 'lucide-react';

export const dynamic = 'force-dynamic';

export default async function CashFlowPage() {
  const company = await getDefaultCompany();
  const from = monthStartISO();
  const to = monthEndISO();
  const [cf, forecast] = await Promise.all([
    getCashFlow(company.id, from, to),
    getCashFlowForecast(company.id),
  ]);

  return (
    <ReportShell
      title="Arus Kas (Cash Flow)"
      subtitle={`${company.name} · Periode ${from} s/d ${to}`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="arus-kas"
          headers={['Kode', 'Akun', 'Masuk', 'Keluar', 'Bersih']}
          rows={cf.accounts.map((a) => [a.code, a.name, a.inflow, a.outflow, a.inflow - a.outflow])}
        />
      }
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <div className="p-5">
            <div className="flex items-center gap-2 text-sm text-emerald-600">
              <ArrowDownRight className="h-4 w-4" />
              <span className="font-medium">Arus Kas Masuk</span>
            </div>
            <div className="mt-2 text-2xl font-bold text-emerald-600">
              <MoneyCell value={cf.inflow} />
            </div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="flex items-center gap-2 text-sm text-red-600">
              <ArrowUpRight className="h-4 w-4" />
              <span className="font-medium">Arus Kas Keluar</span>
            </div>
            <div className="mt-2 text-2xl font-bold text-red-600">
              <MoneyCell value={-cf.outflow} />
            </div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Scale className="h-4 w-4" />
              <span className="font-medium">Arus Kas Bersih</span>
            </div>
            <div
              className={`mt-2 text-2xl font-bold ${
                cf.net >= 0 ? 'text-emerald-600' : 'text-red-600'
              }`}
            >
              <MoneyCell value={cf.net} />
            </div>
          </div>
        </Card>
      </div>

      <Card>
        <CardHeader title="Rincian per Akun Kas/Bank" subtitle={`${cf.accounts.length} akun`} />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Kode</th>
                <th>Akun</th>
                <th className="text-right">Masuk</th>
                <th className="text-right">Keluar</th>
                <th className="text-right">Bersih</th>
              </tr>
            </thead>
            <tbody>
              {cf.accounts.map((a) => (
                <tr key={a.code}>
                  <td className="font-mono text-xs text-brand-600">{a.code}</td>
                  <td>{a.name}</td>
                  <td className="text-right">
                    <MoneyCell value={a.inflow} />
                  </td>
                  <td className="text-right">
                    <MoneyCell value={-a.outflow} />
                  </td>
                  <td className="text-right font-semibold">
                    <MoneyCell value={a.inflow - a.outflow} />
                  </td>
                </tr>
              ))}
              {cf.accounts.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    Tidak ada pergerakan kas/bank pada periode ini.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* ===== Cash Flow Forecast ===== */}
      <Card>
        <CardHeader
          title="Forecast Arus Kas"
          subtitle="Proyeksi kumulatif 30/60/90 hari dari sisa tagihan sesuai jatuh tempo, termasuk yang terlambat. Tagihan tanpa jatuh tempo belum dihitung; realisasi pembayaran dapat berbeda."
        />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <div className="p-5">
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <TrendingUp className="h-4 w-4 text-brand-600" />
              <span className="font-medium">Saldo Kas Saat Ini</span>
            </div>
            <div className="mt-2 text-2xl font-bold text-slate-800">
              <MoneyCell value={forecast.cashBalance} />
            </div>
          </div>
          <div className="p-5">
            <div className="text-sm text-slate-500">Piutang Masuk (AR)</div>
            <div className="mt-2 text-2xl font-bold text-emerald-600">
              <MoneyCell value={forecast.arInflow} />
            </div>
          </div>
          <div className="p-5">
            <div className="text-sm text-slate-500">Hutang Keluar (AP)</div>
            <div className="mt-2 text-2xl font-bold text-red-600">
              <MoneyCell value={-forecast.apOutflow} />
            </div>
          </div>
          <div className="p-5">
            <div className="text-sm text-slate-500">Proyeksi Bersih</div>
            <div className={`mt-2 text-2xl font-bold ${forecast.projected >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              <MoneyCell value={forecast.projected} />
            </div>
          </div>
        </div>

        <div className="overflow-x-auto border-t border-slate-100">
          <table className="table-base">
            <thead>
              <tr>
                <th>Horizon</th>
                <th className="text-right">Arus Masuk</th>
                <th className="text-right">Arus Keluar</th>
                <th className="text-right">Bersih</th>
                <th className="text-right">Saldo Akhir</th>
              </tr>
            </thead>
            <tbody>
              {forecast.buckets.map((b) => (
                <tr key={b.days}>
                  <td className="font-medium text-slate-700">{b.label}</td>
                  <td className="text-right text-emerald-600">
                    <MoneyCell value={b.inflow} />
                  </td>
                  <td className="text-right text-red-600">
                    <MoneyCell value={-b.outflow} />
                  </td>
                  <td className={`text-right font-medium ${b.net >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                    <MoneyCell value={b.net} />
                  </td>
                  <td className={`text-right font-semibold ${b.balance >= 0 ? 'text-slate-800' : 'text-red-600'}`}>
                    <MoneyCell value={b.balance} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </ReportShell>
  );
}
