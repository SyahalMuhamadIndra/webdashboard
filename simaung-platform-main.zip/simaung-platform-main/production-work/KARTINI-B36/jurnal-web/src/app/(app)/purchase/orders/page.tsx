import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listPurchaseOrders } from '@/lib/modules';
import { listSuppliers, listProducts } from '@/lib/odoo';
import { addPurchaseOrder, convertPurchaseOrderToBillAction } from '@/app/actions/modules';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function PurchaseOrdersPage() {
  const company = await getDefaultCompany();
  const [orders, suppliers, products] = await Promise.all([
    listPurchaseOrders(company.id), listSuppliers(company.id), listProducts(company.id),
  ]);

  return (
    <ReportShell title="Purchase Order" subtitle={`${company.name} · ${orders.length} PO`} backHref="/dashboard">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar PO" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>No.</th><th>Pemasok</th><th className="text-right">Tanggal</th><th className="text-right">Total</th><th className="text-right">Status</th><th className="text-right">Aksi</th></tr></thead>
              <tbody>
                {orders.map((o: any) => (
                  <tr key={o.id}>
                    <td className="font-mono text-xs text-brand-600">{o.po_number}</td>
                    <td className="font-medium text-slate-800">{o.supplier_id ? (suppliers.find((s:any)=>s.id===o.supplier_id)?.name || '-') : '-'}</td>
                    <td className="text-right text-slate-500">{formatDate(o.po_date)}</td>
                    <td className="text-right"><MoneyCell value={o.total} /></td>
                    <td className="text-right"><span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-600">{o.status}</span></td>
                    <td className="text-right">
                      {o.converted_bill_id ? (
                        <span className="text-xs text-emerald-600">✓ Bill</span>
                      ) : (
                        <form action={convertPurchaseOrderToBillAction} className="inline"><OperationKey />
                          <input type="hidden" name="companyId" value={company.id} />
                          <input type="hidden" name="poId" value={o.id} />
                          <button type="submit" className="rounded-md bg-brand-50 px-2 py-1 text-xs font-medium text-brand-700 hover:bg-brand-100">
                            Konversi → Bill
                          </button>
                        </form>
                      )}
                    </td>
                  </tr>
                ))}
                {orders.length === 0 && <tr><td colSpan={6} className="py-12 text-center text-slate-400">Belum ada PO.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat PO" />
          <form action={addPurchaseOrder} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Pemasok</label><select className="input" name="supplier_id"><option value="">— Pilih —</option>{suppliers.map((s:any)=><option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
            <div><label className="label">Produk</label><select className="input" name="product_id"><option value="">— Pilih —</option>{products.map((p:any)=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
            <div className="grid grid-cols-2 gap-2"><div><label className="label">Qty</label><input className="input" type="number" name="quantity" defaultValue={1} /></div><div><label className="label">Harga</label><input className="input" type="number" name="unit_price" defaultValue={0} /></div></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
