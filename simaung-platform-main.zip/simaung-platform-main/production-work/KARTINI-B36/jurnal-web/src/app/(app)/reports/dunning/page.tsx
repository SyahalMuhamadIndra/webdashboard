import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listDunning } from '@/lib/modules';
import { addDunning } from '@/app/actions/modules';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function DunningPage() {
  const company = await getDefaultCompany();
  const dunning = await listDunning(company.id);

  return (
    <ReportShell title="Aturan Tagihan (Dunning)" subtitle={`${company.name} · ${dunning.length} aturan`} backHref="/dashboard">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Aturan" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>Nama</th><th className="text-right">Terlambat (hari)</th><th className="text-right">Biaya</th><th className="text-right">Status</th></tr></thead>
              <tbody>
                {dunning.map((d:any)=>(<tr key={d.id}><td className="font-medium text-slate-800">{d.name}</td><td className="text-right text-slate-500">{d.days_overdue}</td><td className="text-right"><MoneyCell value={d.fee} /></td><td className="text-right"><span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-600">{d.is_active?'Aktif':'Nonaktif'}</span></td></tr>))}
                {dunning.length===0 && <tr><td colSpan={4} className="py-12 text-center text-slate-400">Belum ada aturan dunning.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>
        <Card>
          <CardHeader title="Buat Aturan" />
          <form action={addDunning} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Nama</label><input className="input" name="name" required /></div>
            <div><label className="label">Terlambat (hari)</label><input className="input" type="number" name="days_overdue" defaultValue={30} /></div>
            <div><label className="label">Biaya</label><input className="input" type="number" name="fee" defaultValue={0} /></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
