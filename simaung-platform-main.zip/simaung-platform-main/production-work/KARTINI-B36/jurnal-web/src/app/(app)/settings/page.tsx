import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listSettings } from '@/lib/ops';
import { saveSetting } from '@/app/actions/ops';
import { ReportShell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function SettingsPage() {
  const company = await getDefaultCompany();
  const settings = await listSettings(company.id);

  return (
    <ReportShell title="Pengaturan" subtitle={`${company.name} · Konfigurasi sistem`} backHref="/dashboard">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Perusahaan" subtitle="Informasi profil & identitas" />
          <div className="space-y-3 p-5 text-sm">
            <div className="flex justify-between border-b border-slate-100 py-2"><span className="text-slate-500">Kode</span><span className="font-medium">{company.code}</span></div>
            <div className="flex justify-between border-b border-slate-100 py-2"><span className="text-slate-500">Nama</span><span className="font-medium">{company.name}</span></div>
            <div className="flex justify-between border-b border-slate-100 py-2"><span className="text-slate-500">Mata Uang</span><span className="font-medium">{company.base_currency}</span></div>
            <div className="flex justify-between py-2"><span className="text-slate-500">Zona Waktu</span><span className="font-medium">{company.timezone}</span></div>
          </div>
        </Card>

        <Card>
          <CardHeader title="Konfigurasi Kunci" subtitle="Pengaturan key-value (tabel settings)" />
          <form action={saveSetting} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Key</label>
              <input className="input" name="key" placeholder="company.logo_url" required />
            </div>
            <div>
              <label className="label">Value</label>
              <input className="input" name="value" placeholder="Nilai" />
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
          <div className="border-t border-slate-100 px-5 py-3">
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">Tersimpan</div>
            <div className="mt-2 space-y-1">
              {settings.length === 0 && <p className="text-xs text-slate-400">Belum ada pengaturan.</p>}
              {settings.map((s: any) => (
                <div key={s.id} className="flex justify-between text-sm">
                  <span className="font-mono text-brand-600">{s.key}</span>
                  <span className="truncate pl-4 text-slate-600">{JSON.stringify(s.value)}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </ReportShell>
  );
}
