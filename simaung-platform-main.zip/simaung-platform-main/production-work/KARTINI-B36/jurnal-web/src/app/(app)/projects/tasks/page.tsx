import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listProjectTasks } from '@/lib/logistics';
import { listProjects } from '@/lib/modules';
import { addTask, changeTaskStatus } from '@/app/actions/logistics';
import { ReportShell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

const STATUS_LABEL: Record<string, string> = {
  todo: 'To Do',
  in_progress: 'In Progress',
  done: 'Selesai',
  cancelled: 'Batal',
};

const STATUS_ICON: Record<string, string> = {
  todo: 'bg-slate-100 text-slate-600',
  in_progress: 'bg-amber-50 text-amber-600',
  done: 'bg-emerald-50 text-emerald-600',
  cancelled: 'bg-red-50 text-red-600',
};

const PRIORITY_LABEL: Record<string, string> = {
  low: 'Rendah',
  normal: 'Normal',
  high: 'Tinggi',
  urgent: 'Urgent',
};

const PRIORITY_ICON: Record<string, string> = {
  low: 'bg-slate-100 text-slate-600',
  normal: 'bg-blue-50 text-blue-600',
  high: 'bg-orange-50 text-orange-600',
  urgent: 'bg-red-50 text-red-600',
};

export default async function TasksPage() {
  const company = await getDefaultCompany();
  const [tasks, projects] = await Promise.all([
    listProjectTasks(company.id),
    listProjects(company.id),
  ]);

  return (
    <ReportShell
      title="Task Proyek"
      subtitle={`${company.name} · ${tasks.length} tugas`}
      backHref="/projects"
    >
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Tugas" subtitle="Task list per proyek" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Judul</th>
                  <th>Proyek</th>
                  <th>Prioritas</th>
                  <th className="text-right">Tenggat</th>
                  <th className="text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {tasks.map((t: any) => (
                  <tr key={t.id}>
                    <td className="font-medium text-slate-800">{t.title}</td>
                    <td className="text-slate-500">{t.projects?.name || '—'}</td>
                    <td>
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${PRIORITY_ICON[t.priority] || 'bg-slate-100 text-slate-600'}`}>
                        {PRIORITY_LABEL[t.priority] || t.priority}
                      </span>
                    </td>
                    <td className="text-right text-slate-500">{formatDate(t.due_date)}</td>
                    <td className="text-right">
                      <form action={changeTaskStatus} className="inline-flex items-center gap-1"><OperationKey />
                        <input type="hidden" name="id" value={t.id} />
                        <select
                          name="status"
                          defaultValue={t.status}
                          className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs"
                          onChange={(e) => e.currentTarget.form?.requestSubmit()}
                        >
                          {Object.entries(STATUS_LABEL).map(([k, v]) => (
                            <option key={k} value={k}>{v}</option>
                          ))}
                        </select>
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${STATUS_ICON[t.status] || 'bg-slate-100 text-slate-600'}`}>
                          {STATUS_LABEL[t.status] || t.status}
                        </span>
                      </form>
                    </td>
                  </tr>
                ))}
                {tasks.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-400">
                      Belum ada tugas. Buat tugas pertama Anda.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Tugas" />
          <form action={addTask} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Judul</label>
              <input className="input" name="title" required />
            </div>
            <div>
              <label className="label">Proyek</label>
              <select className="input" name="project_id">
                <option value="">— Pilih —</option>
                {projects.map((p: any) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="label">Prioritas</label>
                <select className="input" name="priority" defaultValue="normal">
                  <option value="low">Rendah</option>
                  <option value="normal">Normal</option>
                  <option value="high">Tinggi</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>
              <div>
                <label className="label">Status</label>
                <select className="input" name="status" defaultValue="todo">
                  <option value="todo">To Do</option>
                  <option value="in_progress">In Progress</option>
                  <option value="done">Selesai</option>
                  <option value="cancelled">Batal</option>
                </select>
              </div>
            </div>
            <div>
              <label className="label">Tenggat</label>
              <input className="input" type="date" name="due_date" defaultValue={new Date().toISOString().slice(0, 10)} />
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
