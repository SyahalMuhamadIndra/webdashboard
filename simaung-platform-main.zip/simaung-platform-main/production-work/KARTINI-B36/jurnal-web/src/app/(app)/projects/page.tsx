import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listProjects } from '@/lib/modules';
import { addProject } from '@/app/actions/modules';
import { ReportShell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function ProjectsPage() {
  const company = await getDefaultCompany();
  const projects = await listProjects(company.id);

  return (
    <ReportShell title="Proyek" subtitle={`${company.name} · ${projects.length} proyek`} backHref="/dashboard">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Proyek" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>Nama</th><th>Status</th><th className="text-right">Mulai</th><th className="text-right">Selesai</th></tr></thead>
              <tbody>
                {projects.map((p:any)=>(<tr key={p.id}><td className="font-medium text-slate-800">{p.name}</td><td><span className="rounded-full bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-600">{p.status}</span></td><td className="text-right text-slate-500">{formatDate(p.start_date)}</td><td className="text-right text-slate-500">{formatDate(p.end_date)}</td></tr>))}
                {projects.length===0 && <tr><td colSpan={4} className="py-12 text-center text-slate-400">Belum ada proyek.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>
        <Card>
          <CardHeader title="Buat Proyek" />
          <form action={addProject} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Nama Proyek</label><input className="input" name="name" required /></div>
            <div><label className="label">Deskripsi</label><textarea className="input" name="description" /></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
