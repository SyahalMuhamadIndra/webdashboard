import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { createClient } from '@/lib/supabase/server';
import { listNotifications } from '@/lib/ops';
import { readNotification } from '@/app/actions/ops';
import { ReportShell } from '@/components/report-shell';
import { Card } from '@/components/ui/card';
import { formatDateTime } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function NotificationsPage() {
  const company = await getDefaultCompany();
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const notifications = await listNotifications(company.id, user?.id);
  const unread = notifications.filter((n: any) => !n.is_read).length;

  return (
    <ReportShell title="Notifikasi" subtitle={`${company.name} · ${unread} belum dibaca`} backHref="/dashboard">
      <div className="space-y-3">
        {notifications.length === 0 && (
          <Card className="p-10 text-center text-slate-400">Belum ada notifikasi.</Card>
        )}
        {notifications.map((n: any) => (
          <Card key={n.id} className={n.is_read ? 'opacity-70' : ''}>
            <div className="flex items-start justify-between gap-4 p-5">
              <div>
                <div className="flex items-center gap-2">
                  {!n.is_read && <span className="h-2 w-2 rounded-full bg-brand-500" />}
                  <h3 className="text-sm font-semibold text-slate-900">{n.title}</h3>
                  <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] uppercase tracking-wide text-slate-500">{n.type || 'info'}</span>
                </div>
                {n.message && <p className="mt-1 text-sm text-slate-600">{n.message}</p>}
                <p className="mt-1 text-xs text-slate-400">{formatDateTime(n.created_at)}</p>
              </div>
              {!n.is_read && (
                <form action={readNotification}><OperationKey />
                  <input type="hidden" name="id" value={n.id} />
                  <button type="submit" className="btn-secondary text-xs">Tandai dibaca</button>
                </form>
              )}
            </div>
          </Card>
        ))}
      </div>
    </ReportShell>
  );
}
