import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listStockBalance, listProducts, listLocations } from '@/lib/odoo';
import { createStockAdjustmentAction } from '@/app/actions/transactions';
import { Card, CardHeader } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function InventoryPage() {
  const company = await getDefaultCompany();
  const [balances, products, locations] = await Promise.all([
    listStockBalance(company.id),
    listProducts(company.id),
    listLocations(company.id),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Persediaan (Stock)</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {balances.length} catatan stok</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Saldo Stok" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Produk</th>
                  <th>SKU</th>
                  <th>Gudang</th>
                  <th className="text-right">Qty</th>
                  <th className="text-right">Avg Cost</th>
                </tr>
              </thead>
              <tbody>
                {(balances || []).map((b: any) => (
                  <tr key={b.id}>
                    <td className="font-medium text-slate-800">{b.products?.name}</td>
                    <td className="font-mono text-xs text-brand-600">{b.products?.sku}</td>
                    <td className="text-slate-600">{b.warehouses?.name}</td>
                    <td className="text-right font-semibold">{b.quantity}</td>
                    <td className="text-right text-slate-600">{b.avg_cost}</td>
                  </tr>
                ))}
                {(!balances || balances.length === 0) && (
                  <tr><td colSpan={5} className="py-12 text-center text-slate-400">Belum ada saldo stok. Lakukan penyesuaian stok atau purchase.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Penyesuaian Stok" subtitle="Mencatat pergerakan & saldo" />
          <form action={createStockAdjustmentAction} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Produk</label>
              <select className="input" name="product_id" required>
                <option value="">— Pilih —</option>
                {(products || []).map((p: any) => <option key={p.id} value={p.id}>{p.sku} · {p.name}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Gudang</label>
              <select className="input" name="warehouse_id" required>
                <option value="">— Pilih —</option>
                {(locations || []).map((w: any) => <option key={w.id} value={w.id}>{w.code} · {w.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Qty (±)</label><input className="input" name="quantity" type="number" step="0.01" defaultValue="0" required /></div>
              <div><label className="label">Unit Cost</label><input className="input" name="unit_cost" type="number" step="0.01" defaultValue="0" /></div>
            </div>
            <div><label className="label">Keterangan</label><input className="input" name="memo" /></div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan Penyesuaian</button>
          </form>
        </Card>
      </div>
    </div>
  );
}
