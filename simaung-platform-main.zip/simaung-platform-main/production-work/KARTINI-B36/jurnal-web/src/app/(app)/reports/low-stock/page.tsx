import { getDefaultCompany } from '@/lib/company';
import { listStockBalance, listProducts, listLocations } from '@/lib/odoo';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

const LOW_STOCK_THRESHOLD = 5;

export default async function LowStockPage() {
  const company = await getDefaultCompany();
  const [balances, products, locations] = await Promise.all([
    listStockBalance(company.id),
    listProducts(company.id),
    listLocations(company.id),
  ]);

  // Aggregate quantity per product across warehouses
  const byProduct = new Map<string, { name: string; sku: string; qty: number; value: number }>();
  for (const b of balances as any[]) {
    const pid = b.product_id;
    const qty = Number(b.quantity) || 0;
    const val = qty * (Number(b.avg_cost) || 0);
    const cur = byProduct.get(pid) || { name: b.products?.name, sku: b.products?.sku, qty: 0, value: 0 };
    cur.qty += qty;
    cur.value += val;
    byProduct.set(pid, cur);
  }

  const lowStock = [...byProduct.values()]
    .filter((p) => p.qty <= LOW_STOCK_THRESHOLD)
    .sort((a, b) => a.qty - b.qty);

  const outOfStock = lowStock.filter((p) => p.qty <= 0);
  const critical = lowStock.filter((p) => p.qty > 0 && p.qty <= LOW_STOCK_THRESHOLD);
  const totalProducts = products.length;
  const declared = byProduct.size;

  // Products with no stock balance at all (never received) -> treat as 0
  const neverHeld = products.filter((p: any) => !byProduct.has(p.id)).map((p: any) => ({
    name: p.name, sku: p.sku, qty: 0, value: 0,
  })) as any[];

  return (
    <ReportShell
      title="Stok Menipis (Low Stock)"
      subtitle={`${company.name} · Ambang batas ≤ ${LOW_STOCK_THRESHOLD}`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="stok-menipis"
          headers={['Produk', 'SKU', 'Stok', 'Nilai Stok', 'Status']}
          rows={[...lowStock, ...neverHeld].map((r: any) => [r.name, r.sku, r.qty, r.value, r.qty <= 0 ? 'Habis' : 'Menipis'])}
        />
      }
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Habis (0)</div>
            <div className="mt-1 text-2xl font-bold text-red-600">{outOfStock.length}</div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Menipis (≤ {LOW_STOCK_THRESHOLD})</div>
            <div className="mt-1 text-2xl font-bold text-amber-600">{critical.length}</div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Total Produk</div>
            <div className="mt-1 text-2xl font-bold text-slate-800">{totalProducts}</div>
          </div>
        </Card>
      </div>

      <Card>
        <CardHeader
          title="Daftar Perlu Diorder"
          subtitle={`${lowStock.length + neverHeld.length} produk di bawah ambang`}
        />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Produk</th>
                <th>SKU</th>
                <th className="text-right">Stok</th>
                <th className="text-right">Nilai Stok</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {[...lowStock, ...neverHeld].map((r: any, i: number) => (
                <tr key={i}>
                  <td className="font-medium text-slate-800">{r.name}</td>
                  <td className="font-mono text-xs text-brand-600">{r.sku}</td>
                  <td className="text-right font-semibold text-red-600">{r.qty.toLocaleString('id-ID')}</td>
                  <td className="text-right text-slate-600">
                    <MoneyCell value={r.value} />
                  </td>
                  <td>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${r.qty <= 0 ? 'bg-red-50 text-red-600' : 'bg-amber-50 text-amber-600'}`}>
                      {r.qty <= 0 ? 'Habis' : 'Menipis'}
                    </span>
                  </td>
                </tr>
              ))}
              {lowStock.length + neverHeld.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    Semua stok di atas ambang batas. 👍
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </ReportShell>
  );
}
