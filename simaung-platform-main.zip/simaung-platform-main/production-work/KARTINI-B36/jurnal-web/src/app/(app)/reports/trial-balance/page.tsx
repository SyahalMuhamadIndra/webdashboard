import { getTrialBalance } from '@/lib/reports';
import { getDefaultCompany } from '@/lib/company';
import { monthStartISO, monthEndISO } from '@/lib/format';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

export default async function TrialBalancePage() {
  const company = await getDefaultCompany();
  const from = monthStartISO();
  const to = monthEndISO();
  const tb = await getTrialBalance(company.id, from, to);

  return (
    <ReportShell
      title="Neraca Saldo"
      subtitle={`${company.name} · Periode ${from} s/d ${to}`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="neraca-saldo"
          headers={['Kode', 'Nama Akun', 'Tipe', 'Debit', 'Kredit', 'Saldo']}
          rows={tb.rows.map((r) => [r.code, r.name, r.typeName, r.debit, r.credit, r.balance])}
        />
      }
    >
      <Card>
        <CardHeader
          title="Trial Balance"
          subtitle={`${tb.rows.length} akun dengan aktivitas`}
        />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Kode</th>
                <th>Nama Akun</th>
                <th>Tipe</th>
                <th className="text-right">Debit</th>
                <th className="text-right">Kredit</th>
                <th className="text-right">Saldo</th>
              </tr>
            </thead>
            <tbody>
              {tb.rows.map((row) => (
                <tr key={row.code}>
                  <td className="font-mono text-xs text-brand-600">{row.code}</td>
                  <td className="font-medium text-slate-800">{row.name}</td>
                  <td>
                    <span className="rounded-md bg-slate-100 px-2 py-0.5 text-xs text-slate-600">
                      {row.typeName}
                    </span>
                  </td>
                  <td className="text-right">{row.debit !== 0 ? <><MoneyCell value={row.debit} /></> : '-'}</td>
                  <td className="text-right">{row.credit !== 0 ? <><MoneyCell value={row.credit} /></> : '-'}</td>
                  <td className="text-right font-semibold text-slate-800">
                    {new Intl.NumberFormat('id-ID', {
                      style: 'currency',
                      currency: 'IDR',
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    }).format(row.balance)}
                  </td>
                </tr>
              ))}
              {tb.rows.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Belum ada aktivitas jurnal pada periode ini.
                  </td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50 font-semibold">
                <td colSpan={3} className="px-3 py-3 text-right text-xs uppercase text-slate-500">
                  Total
                </td>
                <td className="px-3 py-3 text-right">
                  <MoneyCell value={tb.totalDebit} />
                </td>
                <td className="px-3 py-3 text-right">
                  <MoneyCell value={tb.totalCredit} />
                </td>
                <td className="px-3 py-3 text-right">
                  <MoneyCell value={tb.totalDebit - tb.totalCredit} />
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
        <div className="flex items-center gap-2 border-t border-slate-100 px-5 py-3 text-sm">
          <span className="text-slate-500">Status:</span>
          {tb.balanced ? (
            <span className="font-semibold text-emerald-600">Balanced ✓ — Debit = Kredit</span>
          ) : (
            <span className="font-semibold text-red-600">Tidak balance — selisih {tb.totalDebit - tb.totalCredit}</span>
          )}
        </div>
      </Card>
    </ReportShell>
  );
}
