import { getDefaultCompany } from '@/lib/company';
import { listReceivables } from '@/lib/odoo';
import { Card, CardHeader } from '@/components/ui/card';
import { formatIDR, formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function ARPage() {
  const company = await getDefaultCompany();
  const receivables = await listReceivables(company.id);

  const totalOpen = (receivables || []).reduce((s, r: any) => s + (Number(r.original_amount) - Number(r.paid_amount || 0)), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Piutang Usaha (Accounts Receivable)</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · Total piutang terbuka {formatIDR(totalOpen)}</p>
      </div>

      <Card>
        <CardHeader title="Daftar Piutang" />
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>Pelanggan</th>
                <th>Invoice</th>
                <th className="text-right">Nilai Awal</th>
                <th className="text-right">Sudah Dibayar</th>
                <th className="text-right">Sisa</th>
                <th className="text-right">Jatuh Tempo</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {(receivables || []).map((r: any) => {
                const open = Number(r.original_amount) - Number(r.paid_amount || 0);
                return (
                  <tr key={r.id}>
                    <td className="font-medium text-slate-800">{r.customers?.name}</td>
                    <td className="font-mono text-xs text-brand-600">{r.invoices?.invoice_number || '-'}</td>
                    <td className="text-right">{formatIDR(r.original_amount)}</td>
                    <td className="text-right text-emerald-600">{formatIDR(r.paid_amount)}</td>
                    <td className="text-right font-semibold text-red-600">{formatIDR(open)}</td>
                    <td className="text-right text-slate-500">{formatDate(r.due_date)}</td>
                    <td>
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${r.status === 'paid' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                        {r.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {(!receivables || receivables.length === 0) && (
                <tr><td colSpan={7} className="py-12 text-center text-slate-400">Belum ada piutang.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
