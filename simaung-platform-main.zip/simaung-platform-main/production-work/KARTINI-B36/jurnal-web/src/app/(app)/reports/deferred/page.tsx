import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listDeferred } from '@/lib/deferred';
import { listAccounts } from '@/lib/odoo';
import { addDeferred, runRecognition, disableDeferred } from '@/app/actions/deferred';
import { ReportShell, MoneyCell } from '@/components/report-shell';
import { Card, CardHeader } from '@/components/ui/card';
import { formatDate } from '@/lib/format';
import { CsvExportButton } from '@/components/csv-export';

export const dynamic = 'force-dynamic';

const INTERVALS: Record<string, string> = {
  daily: 'Harian',
  weekly: 'Mingguan',
  monthly: 'Bulanan',
  yearly: 'Tahunan',
};

const KIND_LABEL: Record<string, string> = {
  revenue: 'Pendapatan Ditangguhkan',
  expense: 'Beban Dibayar Dimuka',
};

const KIND_ICON: Record<string, string> = {
  revenue: 'bg-indigo-50 text-indigo-600',
  expense: 'bg-amber-50 text-amber-600',
};

export default async function DeferredPage() {
  const company = await getDefaultCompany();
  const [deferred, accounts] = await Promise.all([
    listDeferred(company.id),
    listAccounts(company.id),
  ]);

  // Filter akun pendapatan & beban untuk dropdown target
  const targetAccounts = accounts.filter((a: any) => {
    const code = String(a.code || '');
    return code.startsWith('4-') || code.startsWith('5-');
  });

  const totalPending = deferred.reduce((s: number, d: any) => s + (Number(d.total_amount) - Number(d.recognized_amount)), 0);
  const activeCount = deferred.filter((d: any) => d.is_active).length;
  const doneCount = deferred.filter((d: any) => !d.is_active).length;

  return (
    <ReportShell
      title="Pendapatan & Beban Ditangguhkan"
      subtitle={`${company.name} · ${deferred.length} entri`}
      backHref="/dashboard"
      actions={
        <CsvExportButton
          filename="pendapatan-beban-ditangguhkan"
          headers={['Referensi', 'Jenis', 'Total', 'Sudah Diakui', 'Sisa', 'Mulai', 'Selesai', 'Status']}
          rows={deferred.map((d: any) => [
            d.ref_number || '-', KIND_LABEL[d.kind] || d.kind,
            Number(d.total_amount), Number(d.recognized_amount),
            Number(d.total_amount) - Number(d.recognized_amount),
            d.start_date, d.end_date, d.is_active ? 'Aktif' : 'Selesai',
          ])}
        />
      }
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Belum Diakui (Sisa)</div>
            <div className="mt-1 text-xl font-bold text-slate-800">
              <MoneyCell value={totalPending} />
            </div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Entri Aktif</div>
            <div className="mt-1 text-xl font-bold text-indigo-600">{activeCount}</div>
          </div>
        </Card>
        <Card>
          <div className="p-5">
            <div className="text-sm font-medium text-slate-500">Selesai</div>
            <div className="mt-1 text-xl font-bold text-emerald-600">{doneCount}</div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Entri Ditangguhkan" subtitle="Pengakuan periodik multi-periode" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Referensi</th>
                  <th>Jenis</th>
                  <th className="text-right">Total</th>
                  <th className="text-right">Diakui</th>
                  <th className="text-right">Sisa</th>
                  <th className="text-right">Periode</th>
                  <th className="text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {deferred.map((d: any) => {
                  const sisa = Number(d.total_amount) - Number(d.recognized_amount);
                  return (
                    <tr key={d.id}>
                      <td className="font-medium text-slate-800">{d.ref_number || '—'}</td>
                      <td>
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${KIND_ICON[d.kind] || 'bg-slate-100 text-slate-600'}`}>
                          {KIND_LABEL[d.kind] || d.kind}
                        </span>
                        <span className="ml-1 text-xs text-slate-400">{INTERVALS[d.interval_type]}</span>
                      </td>
                      <td className="text-right"><MoneyCell value={Number(d.total_amount)} /></td>
                      <td className="text-right text-slate-500"><MoneyCell value={Number(d.recognized_amount)} /></td>
                      <td className={`text-right ${sisa > 0 ? 'font-semibold text-amber-600' : 'text-emerald-600'}`}>
                        <MoneyCell value={sisa} />
                      </td>
                      <td className="text-right text-xs text-slate-500">
                        {formatDate(d.start_date)} – {formatDate(d.end_date)}
                      </td>
                      <td className="text-right">
                        {d.is_active ? (
                          <form action={disableDeferred} className="inline"><OperationKey />
                            <input type="hidden" name="id" value={d.id} />
                            <button type="submit" className="rounded-md bg-slate-50 px-2 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100">
                              Nonaktifkan
                            </button>
                          </form>
                        ) : (
                          <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-600">Selesai</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
                {deferred.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      Belum ada entri ditangguhkan. Buat entri pertama Anda.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between border-t border-slate-100 px-5 py-3">
            <span className="text-xs text-slate-400">
              Proses pengakuan untuk semua entri aktif yang jatuh tempo.
            </span>
            <form action={runRecognition}><OperationKey />
              <input type="hidden" name="companyId" value={company.id} />
              <button type="submit" className="btn-primary">Jalankan Pengakuan</button>
            </form>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Entri Ditangguhkan" subtitle="Amortisasi multi-periode" />
          <form action={addDeferred} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Jenis</label>
              <select className="input" name="kind">
                <option value="revenue" defaultChecked>Pendapatan Ditangguhkan</option>
                <option value="expense">Beban Dibayar Dimuka</option>
              </select>
            </div>
            <div>
              <label className="label">Referensi</label>
              <input className="input" name="ref_number" placeholder="INV-0001 / Kontrak" />
            </div>
            <div>
              <label className="label">Jumlah Total</label>
              <input className="input" type="number" name="total_amount" defaultValue={0} step="any" />
            </div>
            <div>
              <label className="label">Akun Tujuan (Pendapatan/Beban)</label>
              <select className="input" name="target_account_id">
                <option value="">— Otomatis —</option>
                {targetAccounts.map((a: any) => (
                  <option key={a.id} value={a.id}>
                    {a.code} · {a.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="label">Tanggal Mulai</label>
                <input className="input" type="date" name="start_date" defaultValue={new Date().toISOString().slice(0, 10)} />
              </div>
              <div>
                <label className="label">Tanggal Selesai</label>
                <input className="input" type="date" name="end_date" defaultValue={new Date().toISOString().slice(0, 10)} />
              </div>
            </div>
            <div>
              <label className="label">Interval</label>
              <select className="input" name="interval_type">
                <option value="weekly">Mingguan</option>
                <option value="monthly" defaultChecked>Bulanan</option>
                <option value="yearly">Tahunan</option>
              </select>
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan</button>
          </form>
        </Card>
      </div>
    </ReportShell>
  );
}
