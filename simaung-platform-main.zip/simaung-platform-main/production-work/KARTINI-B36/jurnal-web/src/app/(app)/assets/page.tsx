import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { listFixedAssets } from '@/lib/odoo';
import { createAsset } from '@/app/actions/transactions';
import { Card, CardHeader } from '@/components/ui/card';
import { formatIDR, formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function AssetsPage() {
  const company = await getDefaultCompany();
  const assets = await listFixedAssets(company.id);
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Aktiva Tetap</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {assets.length} aset</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Aset" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Nama</th>
                  <th>Kategori</th>
                  <th className="text-right">Biaya Perolehan</th>
                  <th className="text-right">Nilai Buku</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {(assets || []).map((a: any) => (
                  <tr key={a.id}>
                    <td className="font-mono text-xs text-brand-600">{a.code}</td>
                    <td className="font-medium text-slate-800">{a.name}</td>
                    <td className="text-slate-600">{a.category || '-'}</td>
                    <td className="text-right">{formatIDR(a.acquisition_cost)}</td>
                    <td className="text-right font-semibold">{formatIDR(a.net_book_value)}</td>
                    <td>
                      <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-600">{a.status}</span>
                    </td>
                  </tr>
                ))}
                {(!assets || assets.length === 0) && (
                  <tr><td colSpan={6} className="py-12 text-center text-slate-400">Belum ada aset tetap.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Tambah Aset" />
          <form action={createAsset} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div><label className="label">Nama Aset</label><input className="input" name="name" required /></div>
            <div><label className="label">Kategori</label><input className="input" name="category" placeholder="Tanah, Kendaraan, Mesin" /></div>
            <div><label className="label">Tanggal Perolehan</label><input className="input" name="acquisition_date" type="date" defaultValue={today} required /></div>
            <div><label className="label">Biaya Perolehan</label><input className="input" name="acquisition_cost" type="number" step="0.01" required /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Nilai Sisa</label><input className="input" name="salvage_value" type="number" step="0.01" defaultValue="0" /></div>
              <div><label className="label">Umur (bulan)</label><input className="input" name="useful_life_months" type="number" defaultValue="60" /></div>
            </div>
            <div>
              <label className="label">Metode</label>
              <select className="input" name="depreciation_method">
                <option value="straight_line">Straight Line</option>
                <option value="declining">Declining Balance</option>
              </select>
            </div>
            <button type="submit" className="btn-primary w-full justify-center">Simpan Aset</button>
          </form>
        </Card>
      </div>
    </div>
  );
}
