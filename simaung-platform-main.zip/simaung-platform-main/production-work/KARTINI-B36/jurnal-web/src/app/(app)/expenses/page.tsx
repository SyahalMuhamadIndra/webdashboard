import {OperationKey} from '@/components/operation-key';
import { getDefaultCompany } from '@/lib/company';
import { createAdminClient } from '@/lib/supabase/admin';
import { createExpenseAction } from '@/app/actions/transactions';
import { Card, CardHeader } from '@/components/ui/card';
import { formatIDR, formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function ExpensesPage() {
  const company = await getDefaultCompany();
  const s = createAdminClient();

  const { data: accounts } = await s
    .from('accounts')
    .select('id, code, name, type_of_account!inner(name)')
    .eq('company_id', company.id)
    .eq('is_active', true);
  const expenseAccounts = (accounts || []).filter((a: any) => a.type_of_account?.name === 'Beban');

  // Recent expense-type journal entries (source=expense)
  const { data: entries } = await s
    .from('journal_entries')
    .select('id, entry_number, entry_date, memo, source, journal_lines(debit, credit, accounts(code, name))')
    .eq('company_id', company.id)
    .eq('source', 'expense')
    .order('entry_date', { ascending: false })
    .limit(100);

  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Beban &amp; Pengeluaran</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · catat beban operasional</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Riwayat Beban" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Tanggal</th>
                  <th>Keterangan</th>
                  <th>Akun Beban</th>
                  <th className="text-right">Jumlah</th>
                </tr>
              </thead>
              <tbody>
                {(entries || []).map((e: any) => {
                  const debitLine = (e.journal_lines || []).find((l: any) => l.debit > 0);
                  return (
                    <tr key={e.id}>
                      <td className="font-mono text-xs text-brand-600">{e.entry_number}</td>
                      <td className="whitespace-nowrap">{formatDate(e.entry_date)}</td>
                      <td className="max-w-xs truncate">{e.memo || '-'}</td>
                      <td className="text-slate-600">{debitLine?.accounts?.name || '-'}</td>
                      <td className="text-right font-semibold">{formatIDR(debitLine?.debit || 0)}</td>
                    </tr>
                  );
                })}
                {(!entries || entries.length === 0) && (
                  <tr><td colSpan={5} className="py-12 text-center text-slate-400">Belum ada beban tercatat.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Catat Beban" subtitle="Posting jurnal otomatis" />
          <form action={createExpenseAction} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Akun Beban</label>
              <select className="input" name="expense_account_id" required>
                <option value="">— Pilih —</option>
                {(expenseAccounts || []).map((a: any) => <option key={a.id} value={a.id}>{a.code} · {a.name}</option>)}
              </select>
            </div>
            <div><label className="label">Tanggal</label><input className="input" name="expense_date" type="date" defaultValue={today} required /></div>
            <div><label className="label">Jumlah</label><input className="input" name="amount" type="number" step="0.01" required /></div>
            <div><label className="label">Keterangan</label><input className="input" name="memo" placeholder="Sewa, listrik, dll." /></div>
            <button type="submit" className="btn-primary w-full justify-center">Posting Beban</button>
            <p className="text-center text-xs text-slate-400">Debit beban, kredit kas.</p>
          </form>
        </Card>
      </div>
    </div>
  );
}
