import { notFound } from 'next/navigation';
import Link from 'next/link';
import { createAdminClient } from '@/lib/supabase/admin';
import { formatIDR, formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

async function getBill(companyId: string, id: string) {
  const s = createAdminClient();
  const { data } = await s
    .from('bills')
    .select('*, suppliers(id, code, name, address, email, phone, tax_id), bill_items(*)')
    .eq('company_id', companyId)
    .eq('id', id)
    .maybeSingle();
  return data;
}

async function getCompany(companyId: string) {
  const s = createAdminClient();
  const { data } = await s
    .from('companies')
    .select('name, legal_name, tax_id, address, phone, email, logo_url')
    .eq('id', companyId)
    .maybeSingle();
  return data;
}

export default async function BillDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const s = createAdminClient();
  const { data: company } = await s
    .from('companies')
    .select('id')
    .eq('is_active', true)
    .eq('code', 'KARTINI')
    .maybeSingle();
  const companyId = company?.id || id;

  const [bill, companyInfo] = await Promise.all([
    getBill(companyId, id),
    getCompany(companyId),
  ]);
  if (!bill) notFound();

  const items = (bill.bill_items || []) as any[];
  const subtotal = Number(bill.subtotal) || 0;
  const taxAmount = Number(bill.tax_amount) || 0;
  const discountAmount = Number(bill.discount_amount) || 0;
  const total = Number(bill.total) || 0;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-center justify-between print:hidden">
        <Link href="/purchase/bills" className="text-sm text-slate-500 hover:text-slate-800">
          ← Kembali ke Bill
        </Link>
        <button type="button" onClick={() => window.print()} className="btn-primary px-4 py-2">
          Cetak PDF
        </button>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-card print:border-0 print:shadow-none">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-6">
          <div>
            {companyInfo?.logo_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={companyInfo.logo_url} alt="logo" className="mb-3 h-12 w-12 object-contain" />
            ) : (
              <div className="mb-3 text-2xl font-bold text-brand-600">{companyInfo?.name || 'Company'}</div>
            )}
            <div className="text-sm text-slate-600">
              <div className="text-base font-semibold text-slate-800">{companyInfo?.legal_name || companyInfo?.name}</div>
              {companyInfo?.address && <div>{companyInfo.address}</div>}
              {companyInfo?.tax_id && <div>NPWP: {companyInfo.tax_id}</div>}
              {companyInfo?.phone && <div>{companyInfo.phone}</div>}
              {companyInfo?.email && <div>{companyInfo.email}</div>}
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold tracking-tight text-slate-700">BILL</div>
            <div className="mt-1 font-mono text-sm text-slate-600">{bill.bill_number}</div>
            <div className="mt-2 text-xs text-slate-500">
              <div>Tanggal: {formatDate(bill.bill_date)}</div>
              {bill.due_date && <div>Jatuh Tempo: {formatDate(bill.due_date)}</div>}
              <div>Status: <span className="font-medium uppercase text-slate-700">{bill.status}</span></div>
            </div>
          </div>
        </div>

        {/* Vendor */}
        <div className="grid grid-cols-2 gap-6 py-6">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">Dari</div>
            <div className="mt-2 text-sm">
              <div className="font-semibold text-slate-800">{bill.suppliers?.name || '-'}</div>
              {bill.suppliers?.address && <div className="text-slate-600">{bill.suppliers.address}</div>}
              {bill.suppliers?.tax_id && <div className="text-slate-600">NPWP: {bill.suppliers.tax_id}</div>}
              {bill.suppliers?.email && <div className="text-slate-600">{bill.suppliers.email}</div>}
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">Ringkasan</div>
            <div className="mt-2 text-sm text-slate-600">
              <div>Subtotal: {formatIDR(subtotal)}</div>
              {discountAmount > 0 && <div>Diskon: -{formatIDR(discountAmount)}</div>}
              {taxAmount > 0 && <div>Pajak: {formatIDR(taxAmount)}</div>}
            </div>
          </div>
        </div>

        {/* Items */}
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wider text-slate-500">
              <th className="py-2">#</th>
              <th className="py-2">Deskripsi</th>
              <th className="py-2 text-right">Qty</th>
              <th className="py-2 text-right">Harga</th>
              <th className="py-2 text-right">Diskon</th>
              <th className="py-2 text-right">Jumlah</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it: any, i: number) => (
              <tr key={it.id} className="border-b border-slate-100">
                <td className="py-2 text-slate-400">{i + 1}</td>
                <td className="py-2 text-slate-700">{it.description}</td>
                <td className="py-2 text-right">{Number(it.quantity)?.toLocaleString('id-ID')}</td>
                <td className="py-2 text-right">{formatIDR(Number(it.unit_price))}</td>
                <td className="py-2 text-right">{(Number(it.discount) || 0) > 0 ? `${Number(it.discount)}%` : '-'}</td>
                <td className="py-2 text-right font-medium">{formatIDR(Number(it.line_total))}</td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr><td colSpan={6} className="py-8 text-center text-slate-400">Tidak ada item.</td></tr>
            )}
          </tbody>
        </table>

        {/* Totals */}
        <div className="ml-auto mt-6 w-64 space-y-1 text-sm">
          <div className="flex justify-between text-slate-600">
            <span>Subtotal</span><span>{formatIDR(subtotal)}</span>
          </div>
          {discountAmount > 0 && (
            <div className="flex justify-between text-slate-600">
              <span>Diskon</span><span>-{formatIDR(discountAmount)}</span>
            </div>
          )}
          {taxAmount > 0 && (
            <div className="flex justify-between text-slate-600">
              <span>PPN</span><span>{formatIDR(taxAmount)}</span>
            </div>
          )}
          <div className="flex justify-between border-t border-slate-200 pt-2 text-base font-bold text-slate-900">
            <span>Total</span><span>{formatIDR(total)}</span>
          </div>
        </div>

        <div className="mt-10 border-t border-slate-100 pt-4 text-center text-xs text-slate-400">
          Tagihan pembelian ini dicatat otomatis ke jurnal (double-entry).
        </div>
      </div>
    </div>
  );
}
