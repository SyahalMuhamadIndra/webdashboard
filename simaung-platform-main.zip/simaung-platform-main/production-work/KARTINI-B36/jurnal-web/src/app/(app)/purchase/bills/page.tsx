import {OperationKey} from '@/components/operation-key';
import Link from 'next/link';
import { getDefaultCompany } from '@/lib/company';
import { listBills, listSuppliers } from '@/lib/odoo';
import { createBill } from '@/app/actions/transactions';
import { Card, CardHeader } from '@/components/ui/card';
import { formatIDR, formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function BillsPage() {
  const company = await getDefaultCompany();
  const [bills, suppliers] = await Promise.all([
    listBills(company.id),
    listSuppliers(company.id),
  ]);
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Bill Pembelian</h1>
        <p className="mt-1 text-sm text-slate-500">{company.name} · {bills.length} bill</p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Daftar Bill" />
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Tanggal</th>
                  <th>Pemasok</th>
                  <th className="text-right">Subtotal</th>
                  <th className="text-right">Total</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {(bills || []).map((b: any) => (
                  <tr key={b.id}>
                    <td className="font-mono text-xs text-brand-600">
                      <Link href={`/purchase/bills/${b.id}`} className="hover:underline">{b.bill_number}</Link>
                    </td>
                    <td className="whitespace-nowrap">{formatDate(b.bill_date)}</td>
                    <td className="font-medium text-slate-800">{b.suppliers?.name}</td>
                    <td className="text-right">{formatIDR(b.subtotal)}</td>
                    <td className="text-right font-semibold">{formatIDR(b.total)}</td>
                    <td>
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${b.status === 'paid' ? 'bg-emerald-50 text-emerald-600' : b.status === 'posted' ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-500'}`}>
                        {b.status}
                      </span>
                    </td>
                  </tr>
                ))}
                {(!bills || bills.length === 0) && (
                  <tr><td colSpan={6} className="py-12 text-center text-slate-400">Belum ada bill.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title="Buat Bill" subtitle="Posting jurnal otomatis (double-entry)" />
          <form action={createBill} className="space-y-3 p-5"><OperationKey />
            <input type="hidden" name="companyId" value={company.id} />
            <div>
              <label className="label">Pemasok</label>
              <select className="input" name="supplier_id" required>
                <option value="">— Pilih —</option>
                {(suppliers || []).map((s: any) => <option key={s.id} value={s.id}>{s.code} · {s.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Tanggal</label><input className="input" name="bill_date" type="date" defaultValue={today} required /></div>
              <div><label className="label">Jatuh Tempo</label><input className="input" name="due_date" type="date" /></div>
            </div>
            <div><label className="label">Deskripsi Item</label><input className="input" name="desc" placeholder="Pembelian barang" /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Qty</label><input className="input" name="qty" type="number" defaultValue="1" min="1" required /></div>
              <div><label className="label">Harga</label><input className="input" name="price" type="number" step="0.01" defaultValue="0" required /></div>
            </div>
            <div><label className="label">Diskon (%)</label><input className="input" name="discount" type="number" defaultValue="0" /></div>
            <button type="submit" className="btn-primary w-full justify-center">Posting Bill</button>
            <p className="text-center text-xs text-slate-400">Akan membuat jurnal debit persediaan, kredit hutang.</p>
          </form>
          <div className="border-t border-slate-100 px-5 py-3">
            <Link href="/journal" className="btn-secondary w-full justify-center">Lihat Jurnal</Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
