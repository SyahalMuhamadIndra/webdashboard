import { getSession } from '@/lib/session';
import { maintenanceResponse } from '@/lib/maintenance-server';
import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { postJournalEntry, reverseJournalEntry } from '@/lib/journal';
import { z } from 'zod';

const lineSchema = z.object({
  accountId: z.string().uuid(),
  debit: z.number().min(0).default(0),
  credit: z.number().min(0).default(0),
  branchId: z.string().uuid().nullable().optional(),
  description: z.string().optional(),
});

const entrySchema = z.object({
  idempotencyKey: z.string().uuid(),
  companyId: z.string().uuid(),
  entryDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  memo: z.string().optional(),
  source: z.string().default('manual'),
  referenceType: z.string().optional(),
  referenceId: z.string().optional(),
  branchId: z.string().uuid().nullable().optional(),
  fiscalPeriodId: z.string().uuid().optional(),
  createdBy: z.string().uuid().optional(),
  lines: z.array(lineSchema).min(1),
});

// GET /api/journal?company_id=... — list journal entries with lines.
export async function GET(request: Request) {
  const closedForMaintenance = await maintenanceResponse();
  if (closedForMaintenance) return closedForMaintenance;
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  if (!['SUPERADMIN','ADMIN','ACCOUNTANT'].includes(session.role.toUpperCase()))
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  const { searchParams } = new URL(request.url);
  const companyId = session.companyId;
  if (searchParams.get('company_id') && searchParams.get('company_id') !== companyId) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  if (!companyId) {
    return NextResponse.json({ error: 'company_id required' }, { status: 400 });
  }

  const supabase = createAdminClient();
  const { data, error } = await supabase
    .from('journal_entries')
    .select('*, journal_lines(id, debit, credit, amount, account_id, description, accounts(code, name))')
    .eq('company_id', companyId)
    .order('entry_date', { ascending: false })
    .limit(100);

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json({ entries: data });
}

// POST /api/journal — post a new double-entry journal.
export async function POST(request: Request) {
  const closedForMaintenance = await maintenanceResponse();
  if (closedForMaintenance) return closedForMaintenance;
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await request.json().catch(() => null);
  if (!body) return NextResponse.json({ error: 'invalid body' }, { status: 400 });

  const parsed = entrySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues }, { status: 400 });
  }

  if (parsed.data.companyId !== session.companyId) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  if (!['SUPERADMIN', 'DEV', 'ADMIN', 'ACCOUNTANT', 'MANAGER'].includes(session.role.toUpperCase())) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  try {
    const result = await postJournalEntry({
      companyId: parsed.data.companyId,
      idempotencyKey: parsed.data.idempotencyKey,
      entryDate: parsed.data.entryDate,
      memo: parsed.data.memo,
      source: parsed.data.source as any,
      referenceType: parsed.data.referenceType,
      referenceId: parsed.data.referenceId,
      branchId: parsed.data.branchId,
      fiscalPeriodId: parsed.data.fiscalPeriodId,
      createdBy: session.adminId,
      lines: parsed.data.lines,
    });
    return NextResponse.json({ success: true, ...result });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 422 });
  }
}
