import { maintenanceResponse } from '@/lib/maintenance-server';
import { NextResponse } from 'next/server';
import { Pool } from 'pg';

export const dynamic = 'force-dynamic';

// DDL modul Odoo yang belum ada (migration 0002). Dijalankan melalui cron/curl
// dari luar (di Vercel) sehingga memakai service-role JWT asli sebagai password
// pooler. Dilindungi header x-migrate-key agar tidak bisa di-trigger sembarangan.
const DDL = `
create extension if not exists "uuid-ossp";

create table if not exists public.quotations (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  quotation_number text not null,
  quotation_date date not null default current_date,
  valid_until date,
  status doc_status not null default 'draft',
  subtotal numeric(19,4) not null default 0,
  tax_amount numeric(19,4) not null default 0,
  total numeric(19,4) not null default 0,
  converted_invoice_id uuid references public.invoices(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, quotation_number)
);
create table if not exists public.quotation_lines (
  id uuid primary key default uuid_generate_v4(),
  quotation_id uuid not null references public.quotations(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  description text,
  quantity numeric(19,4) not null default 1,
  unit_price numeric(19,4) not null default 0,
  discount numeric(19,4) not null default 0,
  tax_rate_id uuid references public.tax_rates(id) on delete set null,
  line_total numeric(19,4) not null default 0
);

create table if not exists public.purchase_orders (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  supplier_id uuid references public.suppliers(id) on delete set null,
  po_number text not null,
  po_date date not null default current_date,
  expected_date date,
  status doc_status not null default 'draft',
  subtotal numeric(19,4) not null default 0,
  tax_amount numeric(19,4) not null default 0,
  total numeric(19,4) not null default 0,
  converted_bill_id uuid references public.bills(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, po_number)
);
create table if not exists public.po_items (
  id uuid primary key default uuid_generate_v4(),
  po_id uuid not null references public.purchase_orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  description text,
  quantity numeric(19,4) not null default 1,
  unit_price numeric(19,4) not null default 0,
  tax_rate_id uuid references public.tax_rates(id) on delete set null,
  line_total numeric(19,4) not null default 0
);

create table if not exists public.delivery_orders (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  warehouse_id uuid not null references public.warehouses(id),
  customer_id uuid references public.customers(id) on delete set null,
  delivery_number text not null,
  delivery_date date not null default current_date,
  status doc_status not null default 'draft',
  total numeric(19,4) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, delivery_number)
);
create table if not exists public.delivery_items (
  id uuid primary key default uuid_generate_v4(),
  delivery_id uuid not null references public.delivery_orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(19,4) not null default 0
);

create table if not exists public.goods_receipts (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  warehouse_id uuid not null references public.warehouses(id),
  supplier_id uuid references public.suppliers(id) on delete set null,
  receipt_number text not null,
  receipt_date date not null default current_date,
  status doc_status not null default 'draft',
  total numeric(19,4) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, receipt_number)
);
create table if not exists public.receipt_items (
  id uuid primary key default uuid_generate_v4(),
  receipt_id uuid not null references public.goods_receipts(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(19,4) not null default 0
);

create table if not exists public.stock_transfers (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  from_warehouse_id uuid not null references public.warehouses(id),
  to_warehouse_id uuid not null references public.warehouses(id),
  transfer_number text not null,
  transfer_date date not null default current_date,
  status doc_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, transfer_number)
);
create table if not exists public.transfer_items (
  id uuid primary key default uuid_generate_v4(),
  transfer_id uuid not null references public.stock_transfers(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(19,4) not null default 0
);

create table if not exists public.currencies (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  code text not null,
  name text not null,
  symbol text,
  is_base boolean not null default false,
  created_at timestamptz not null default now(),
  unique (company_id, code)
);
create table if not exists public.currency_rates (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  currency_id uuid not null references public.currencies(id) on delete cascade,
  rate numeric(19,6) not null default 1,
  effective_date date not null default current_date,
  created_at timestamptz not null default now()
);

create table if not exists public.budgets (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  fiscal_year int not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.budget_items (
  id uuid primary key default uuid_generate_v4(),
  budget_id uuid not null references public.budgets(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  amount numeric(19,4) not null default 0
);

create table if not exists public.opportunities (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  title text not null,
  stage text not null default 'new',
  expected_amount numeric(19,4) not null default 0,
  probability int not null default 0,
  expected_close date,
  assigned_to uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  description text,
  status text not null default 'on_track',
  start_date date,
  end_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.project_tasks (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  title text not null,
  status text not null default 'todo',
  priority text not null default 'medium',
  due_date date,
  assigned_to uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.bank_reconciliations (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  bank_account_id uuid not null references public.bank_accounts(id) on delete cascade,
  recon_date date not null default current_date,
  statement_balance numeric(19,4) not null default 0,
  book_balance numeric(19,4) not null default 0,
  difference numeric(19,4) not null default 0,
  status doc_status not null default 'draft',
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.dunning_rules (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  days_overdue int not null default 0,
  fee numeric(19,4) not null default 0,
  template text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
`;

function requireKey(req: Request): boolean {
  if (process.env.VERCEL_ENV === 'production' || process.env.ENABLE_SETUP_ROUTES !== 'true') return false;
  const expected = process.env.MIGRATE_KEY;
  return Boolean(expected && expected.length >= 32 && req.headers.get('x-migrate-key') === expected);
}

export async function POST(request: Request) {
  const closedForMaintenance = await maintenanceResponse();
  if (closedForMaintenance) return closedForMaintenance;

  if (!requireKey(request)) {
    return NextResponse.json({ error: 'x-migrate-key salah' }, { status: 403 });
  }

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
  const dbPassword = process.env.POSTGRES_PASSWORD || '';
  const ref = url.match(/https:\/\/([^.]+)/)?.[1];
  if (!ref || !dbPassword) return NextResponse.json({ error: 'env supabase tidak lengkap (butuh POSTGRES_PASSWORD)' }, { status: 500 });

  // Use the session/transaction pooler host for this project's region (ap-southeast-1 / Singapore).
  // The pooler username is postgres.<project-ref> and the password is the real
  // Postgres database password (not the API JWT), which is what the pooler requires.
  const pool = new Pool({
    host: 'aws-0-ap-southeast-1.pooler.supabase.com',
    port: 5432,
    database: 'postgres',
    user: `postgres.${ref}`,
    password: dbPassword,
    ssl: { rejectUnauthorized: false },
    connectionTimeoutMillis: 15000,
    max: 1,
  });

  try {
    const client = await pool.connect();
    try {
      await client.query(DDL);
      await client.query(`do $$ declare r record; begin
        for r in select tablename from pg_tables where schemaname='public' loop
          execute format('alter table public.%I enable row level security', r.tablename);
        end loop; end $$;`);
    } finally {
      client.release();
    }
    return NextResponse.json({ ok: true, ref });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || String(e) }, { status: 500 });
  } finally {
    await pool.end();
  }
}
