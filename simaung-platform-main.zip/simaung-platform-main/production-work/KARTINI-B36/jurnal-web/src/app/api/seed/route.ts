import { maintenanceResponse } from '@/lib/maintenance-server';
import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import {
  createCustomer,
  createSupplier,
  createProduct,
  createInvoiceAndPost,
  createBillAndPost,
  createCustomerPayment,
  createFixedAsset,
} from '@/lib/odoo';
import { postDepreciation } from '@/lib/finance';

export const dynamic = 'force-dynamic';

// POST /api/seed — isi data demo (idempotent & resumable).
// Dijalankan dari server (Vercel) sehingga memakai SERVICE_ROLE_KEY asli.
// Dijaga header x-seed-key agar tidak bisa di-trigger sembarangan.
function requireKey(req: Request): boolean {
  if (process.env.VERCEL_ENV === 'production' || process.env.ENABLE_SETUP_ROUTES !== 'true') return false;
  const expected = process.env.DEMO_SEED_KEY;
  return Boolean(expected && expected.length >= 32 && req.headers.get('x-seed-key') === expected);
}

async function firstRow(table: string, match: Record<string, any>) {
  const s = createAdminClient();
  const { data } = await s.from(table).select('*').match(match).maybeSingle();
  return data || null;
}

async function count(table: string, match: Record<string, any>): Promise<number> {
  const s = createAdminClient();
  const { count } = await s.from(table).select('*', { count: 'exact', head: true }).match(match);
  return count || 0;
}

function today(offsetDays = 0): string {
  return new Date(Date.now() + offsetDays * 86400000).toISOString().slice(0, 10);
}

export async function POST(request: Request) {
  const closedForMaintenance = await maintenanceResponse();
  if (closedForMaintenance) return closedForMaintenance;

  if (!requireKey(request)) {
    return NextResponse.json({ error: 'x-seed-key salah atau tidak diberikan' }, { status: 403 });
  }

  const summary: Record<string, number> = {};
  const errors: string[] = [];

  const s = createAdminClient();

  // 1. Company KARTINI
  let company: any = await firstRow('companies', { code: 'KARTINI' });
  if (!company) {
    const { data, error } = await s
      .from('companies')
      .insert({ code: 'KARTINI', name: 'Kartini Boga Nusantara', legal_name: 'Kartini Boga Nusantara', base_currency: 'IDR', fiscal_year_start: 1, timezone: 'Asia/Jakarta' })
      .select('id')
      .single();
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    company = { id: data.id, code: 'KARTINI' };
    summary.company = 1;
  }
  const cid = company.id;

  // Hoisted references (filled in the master-data step, used later).
  let cust: any = null;
  let sup: any = null;
  let prodA: any = null;
  let prodB: any = null;
  let taxRate: any = null;

  try {
    // 2. Master data (guarded by unique business key)
    cust = await firstRow('customers', { company_id: cid, code: 'CUS-0001' });
    if (!cust) {
      cust = await createCustomer(cid, { code: 'CUS-0001', name: 'PT Maju Jaya', customer_type: 'customer', tax_id: '01.234.567.8-901.000', address: 'Jl. Sudirman 12, Jakarta', term_days: 30 });
      summary.customers = 1;
    }
    sup = await firstRow('suppliers', { company_id: cid, code: 'SUP-0001' });
    if (!sup) {
      sup = await createSupplier(cid, { code: 'SUP-0001', name: 'CV Barokah', address: 'Jl. Merdeka 5, Bandung', term_days: 30 });
      summary.suppliers = 1;
    }
    prodA = await firstRow('products', { company_id: cid, sku: 'SKU-0001' });
    if (!prodA) {
      prodA = await createProduct(cid, { sku: 'SKU-0001', name: 'Produk A', is_track_inventory: true });
      summary.products = (summary.products || 0) + 1;
    }
    prodB = await firstRow('products', { company_id: cid, sku: 'SKU-0002' });
    if (!prodB) {
      prodB = await createProduct(cid, { sku: 'SKU-0002', name: 'Produk B', is_track_inventory: true });
      summary.products = (summary.products || 0) + 1;
    }
    taxRate = await firstRow('tax_rates', { company_id: cid, name: 'PPN 11%' });
  } catch (e: any) {
    errors.push(`Master: ${e?.message || String(e)}`);
  }

  try {
    // 3. Demo invoice (skip if any invoice already exists)
    const invCount = await count('invoices', { company_id: cid });
    if (invCount === 0 && cust) {
      await createInvoiceAndPost(cid, {
        customer_id: cust.id,
        invoice_date: today(0),
        due_date: today(30),
        items: [
          { product_id: prodA?.id, description: 'Penjualan Produk A', quantity: 10, unit_price: 250000, tax_rate_id: taxRate?.id, discount: 0 },
          { product_id: prodB?.id, description: 'Penjualan Produk B', quantity: 5, unit_price: 500000, tax_rate_id: taxRate?.id, discount: 0 },
        ],
      });
      summary.invoices = 1;
    }
  } catch (e: any) {
    errors.push(`Invoice: ${e?.message || String(e)}`);
  }

  try {
    // 4. Demo bill (skip if any bill already exists)
    const billCount = await count('bills', { company_id: cid });
    if (billCount === 0 && sup) {
      await createBillAndPost(cid, {
        supplier_id: sup.id,
        bill_date: today(0),
        due_date: today(30),
        items: [
          { product_id: prodA?.id, description: 'Pembelian barang dagang', quantity: 20, unit_price: 150000, tax_rate_id: taxRate?.id, discount: 0 },
        ],
      });
      summary.bills = 1;
    }
  } catch (e: any) {
    errors.push(`Bill: ${e?.message || String(e)}`);
  }

  try {
    // 5. Demo customer payment (lunasi sebagian piutang)
    const payCount = await count('payments', { company_id: cid });
    const { data: receiv } = await s
      .from('receivables')
      .select('id, original_amount, paid_amount')
      .eq('company_id', cid)
      .eq('status', 'posted')
      .maybeSingle();
    if (payCount === 0 && receiv && cust) {
      const open = Number(receiv.original_amount) - Number(receiv.paid_amount || 0);
      if (open > 0) {
        await createCustomerPayment(cid, {
          customer_id: cust.id,
          amount: Math.round(open / 2),
          payment_date: today(0),
          receivable_id: receiv.id,
        });
        summary.payments = 1;
      }
    }
  } catch (e: any) {
    errors.push(`Payment: ${e?.message || String(e)}`);
  }

  try {
    // 6. Demo fixed asset + auto depreciation (skip if any asset exists)
    const faCount = await count('fixed_assets', { company_id: cid });
    if (faCount === 0) {
      const fa = await createFixedAsset(cid, {
        code: 'FA-0001',
        name: 'Mesin Produksi',
        category: 'Mesin',
        acquisition_date: today(-30),
        acquisition_cost: 50_000_000,
        salvage_value: 2_000_000,
        useful_life_months: 60,
        depreciation_method: 'straight_line',
      });
      const { data: asset } = await s.from('fixed_assets').select('*').eq('id', fa.assetId).single();
      if (asset) {
        await postDepreciation(cid, asset, 'Bulan berjalan', today(0));
        summary.depreciation = 1;
      }
      summary.assets = 1;
    }
  } catch (e: any) {
    errors.push(`Aset: ${e?.message || String(e)}`);
  }

  try {
    // 7. Opening balance journal — only if the company has NO journal at all.
    const jeCount = await count('journal_entries', { company_id: cid });
    if (jeCount === 0) {
      const kas = await firstRow('accounts', { company_id: cid, code: '1-1000' });
      const modal = await firstRow('accounts', { company_id: cid, code: '3-1000' });
      if (kas && modal) {
        const { data: je, error: jeErr } = await s
          .from('journal_entries')
          .insert({
            company_id: cid,
            entry_number: 'OP-1',
            entry_date: today(0),
            memo: 'Setoran modal awal (demo)',
            source: 'opening_balance',
            is_posted: true,
          })
          .select('id')
          .single();
        if (jeErr) throw new Error(jeErr.message);
        const { error: linesErr } = await s.from('journal_lines').insert([
          { company_id: cid, journal_entry_id: je.id, account_id: kas.id, debit: 100_000_000, credit: 0, amount: 100_000_000, description: 'Setoran modal awal (demo)' },
          { company_id: cid, journal_entry_id: je.id, account_id: modal.id, debit: 0, credit: 100_000_000, amount: 100_000_000, description: 'Setoran modal awal (demo)' },
        ]);
        if (linesErr) throw new Error(linesErr.message);
        summary.opening = 1;
      }
    }
  } catch (e: any) {
    errors.push(`Opening: ${e?.message || String(e)}`);
  }

  // Diagnostic table counts for this company (using service role, so RLS is bypassed).
  const counts: Record<string, number> = {};
  for (const t of [
    'companies', 'accounts', 'customers', 'suppliers', 'products', 'tax_rates',
    'journal_entries', 'journal_lines', 'invoices', 'bills', 'payments',
    'receivables', 'payables', 'fixed_assets', 'depreciation_entries',
  ]) {
    const c = await count(t, { company_id: cid }).catch(() => 0);
    counts[t] = t === 'companies' ? (company ? 1 : 0) : c;
  }

  return NextResponse.json({ ok: errors.length === 0, company: company.code, summary, errors, counts });
}
