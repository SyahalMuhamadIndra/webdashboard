import { NextResponse } from 'next/server';
import {Pool} from 'pg';

export const dynamic = 'force-dynamic';

// Read-only diagnostics. Verify the existing owner's controller token directly;
// no public secret, alternate admin password or maintenance bypass credential.
export async function GET(request: Request) {
  const authorization = request.headers.get('authorization');
  if (!authorization?.startsWith('Bearer ')) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const owner = await fetch('https://api.tokokartini.com/api/admin/maintenance', {
      headers: { Authorization: authorization }, cache: 'no-store', redirect: 'error', signal: AbortSignal.timeout(8000),
    });
    if (!owner.ok) return NextResponse.json({ error: 'Unauthorized' }, { status: owner.status === 503 ? 503 : 401 });
  } catch { return NextResponse.json({ error: 'Owner verification unavailable' }, { status: 503 }); }
  if(!process.env.DATABASE_URL)return NextResponse.json({configured:false},{status:503});
  let pool:Pool|undefined;
  try{
    const url=new URL(process.env.DATABASE_URL);
    for(const key of ['sslmode','sslrootcert','sslcert','sslkey','channel_binding'])url.searchParams.delete(key);
    pool=new Pool({connectionString:url.toString(),ssl:{rejectUnauthorized:true},enableChannelBinding:true,max:1,connectionTimeoutMillis:8000,statement_timeout:8000});
    const client=await pool.connect();
    try{
      await client.query('BEGIN READ ONLY');
      const tables=[];
      for(const table of ['companies','accounts','journal_entries','journal_lines','products','invoices','bills','profiles','stock_balances','ops_branch_config']){
        const result=await client.query(`SELECT count(*)::int AS count FROM public.${table}`);
        tables.push({table,status:200,count:result.rows[0].count,error:null});
      }
      await client.query('COMMIT');
      return NextResponse.json({configured:true,storage:'Neon PostgreSQL',tables},{headers:{'Cache-Control':'no-store'}});
    }finally{await client.query('ROLLBACK').catch(()=>{});client.release();}
  }catch{return NextResponse.json({configured:true,error:'DATABASE_UNAVAILABLE'},{status:503});}
  finally{await pool?.end().catch(()=>{});}
}
