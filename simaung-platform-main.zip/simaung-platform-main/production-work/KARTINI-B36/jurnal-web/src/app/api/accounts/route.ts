import { getSession } from '@/lib/session';
import { maintenanceResponse } from '@/lib/maintenance-server';
import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';

// GET /api/accounts?company_id=... — list chart of accounts with type info.
export async function GET(request: Request) {
  const closedForMaintenance = await maintenanceResponse();
  if (closedForMaintenance) return closedForMaintenance;

  const session=await getSession();
  if(!session)return NextResponse.json({error:'Unauthorized'},{status:401});
  if(!['SUPERADMIN','ADMIN','ACCOUNTANT'].includes(session.role.toUpperCase()))
    return NextResponse.json({error:'Forbidden'},{status:403});
  const requested=new URL(request.url).searchParams.get('company_id');
  const companyId=session.companyId;
  if(requested&&requested!==companyId)return NextResponse.json({error:'Forbidden'},{status:403});

  const supabase = createAdminClient();
  const { data, error } = await supabase
    .from('accounts')
    .select('id, code, name, is_header, is_active, description, type_of_account!inner(normal_balance, name, report_section)')
    .eq('company_id', companyId)
    .order('code');

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ accounts: data },{headers:{'Cache-Control':'no-store'}});
}
