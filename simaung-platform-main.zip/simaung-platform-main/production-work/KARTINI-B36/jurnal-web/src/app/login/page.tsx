import { Suspense } from 'react';
import { redirect } from 'next/navigation';
import { AuthCard } from '@/components/auth-card';
import { getSession } from '@/lib/session';
import { ShieldCheck, BarChart3, Landmark, LineChart } from 'lucide-react';

export const dynamic = 'force-dynamic';

function LoginInner({
  searchParams,
}: {
  searchParams?: { error?: string; message?: string; pending?: string };
}) {
  return (
    <AuthCard
      error={searchParams?.error}
      message={searchParams?.message}
      pending={searchParams?.pending === '1'}
    />
  );
}

export default async function LoginPage({
  searchParams,
}: {
  searchParams?: Promise<{ error?: string; message?: string; pending?: string }>;
}) {
  const query = await searchParams;
  // If already authenticated, go to dashboard.
  const session = await getSession();
  if (session) redirect('/dashboard');

  return (
    <div className="simaung-login relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-50 px-4 py-10">
      {/* Ambient background decoration */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-40 -top-40 h-96 w-96 rounded-full bg-brand-600/10 blur-3xl" />
        <div className="absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-accent-500/10 blur-3xl" />
        <div
          className="absolute inset-0 opacity-[0.4]"
          style={{
            backgroundImage:
              'radial-gradient(circle at 1px 1px, rgb(15 23 42 / 0.06) 1px, transparent 0)',
            backgroundSize: '24px 24px',
          }}
        />
      </div>

      <div className="relative grid w-full max-w-5xl gap-8 lg:grid-cols-[1.1fr_1fr] lg:items-center lg:gap-10">
        {/* Left: brand / value proposition — tampil di SEMUA ukuran layar (konsisten HP vs Desktop) */}
        <div className="simaung-login-brand flex flex-col items-center text-center lg:items-start lg:text-left">
          <div className="flex items-center gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/logo.png" alt="Laporan Simaung Corporation" className="h-14 w-14 rounded-xl object-contain shadow-lg lg:h-16 lg:w-16" />
            <div>
              <div className="text-xl font-bold tracking-tight text-slate-900">Laporan Simaung Corporation</div>
              <div className="text-sm font-medium text-accent-600">Accounting Suite</div>
            </div>
          </div>

          <h1 className="mt-8 max-w-md text-3xl font-bold leading-tight tracking-tight text-slate-900 lg:mt-10 lg:text-4xl">
            Kelola jurnal &amp; laporan keuangan bisnis Anda dengan{' '}
            <span className="bg-gradient-to-r from-brand-600 to-accent-500 bg-clip-text text-transparent">
              presisi profesional
            </span>
          </h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-slate-500 lg:text-base">
            Platform akuntansi double-entry yang konsisten. Semua laporan — Laba Rugi,
            Neraca, Arus Kas, Neraca Saldo — berasal dari satu accounting engine yang teruji.
          </p>

          <div className="mt-8 grid w-full max-w-md grid-cols-1 gap-3 lg:max-w-none lg:grid-cols-2 lg:gap-4">
            {[
              { icon: Landmark, title: 'Double-entry', desc: 'Jurnal berpasangan, selalu balance' },
              { icon: BarChart3, title: 'Laporan Real-time', desc: '5 laporan keuangan otomatis' },
              { icon: ShieldCheck, title: 'Multi-tenant', desc: 'RBAC & audit log lengkap' },
              { icon: LineChart, title: 'ERP Modules', desc: 'Sales, Purchase, Inventory, CRM' },
            ].map((f) => (
              <div
                key={f.title}
                className="flex w-full items-center gap-3 rounded-xl border border-slate-200/80 bg-white/70 p-3.5 text-left backdrop-blur lg:items-start"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
                  <f.icon className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-800">{f.title}</div>
                  <div className="mt-0.5 text-xs leading-snug text-slate-500">{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: auth card */}
        <div className="mx-auto w-full max-w-md">
          <Suspense>
            <LoginInner searchParams={query} />
          </Suspense>

          <p className="mt-6 text-center text-xs text-slate-400">
            © {new Date().getFullYear()} Laporan Simaung Corporation · Powered by MrFine
          </p>
        </div>
      </div>
    </div>
  );
}
