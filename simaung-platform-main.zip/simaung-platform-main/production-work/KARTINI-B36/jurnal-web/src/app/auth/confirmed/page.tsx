'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { CheckCircle2, ArrowRight } from 'lucide-react';

export default function ConfirmedPage() {
  const router = useRouter();
  const [seconds, setSeconds] = useState(5);

  useEffect(() => {
    if (seconds <= 0) {
      router.push('/login');
      return;
    }
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [seconds, router]);

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-50 px-4 py-10">
      {/* Ambient decoration */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-32 -top-32 h-80 w-80 rounded-full bg-brand-600/10 blur-3xl" />
        <div className="absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-accent-500/10 blur-3xl" />
      </div>

      <div className="relative w-full max-w-md animate-slide-up rounded-2xl border border-slate-200 bg-white/95 p-8 text-center shadow-xl shadow-slate-200/60 backdrop-blur">
        <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50">
          <CheckCircle2 className="h-9 w-9 text-emerald-600" />
        </div>

        <h1 className="text-xl font-bold tracking-tight text-slate-900">
          Email Berhasil Dikonfirmasi
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-slate-500">
          Akun Anda sudah aktif. Anda akan diarahkan ke halaman login secara otomatis.
        </p>

        <div className="mt-6">
          <p className="text-sm text-slate-500">
            Dialihkan dalam{' '}
            <span className="inline-flex h-7 min-w-7 items-center justify-center rounded-md bg-brand-600 px-2 text-sm font-bold text-white">
              {seconds}
            </span>{' '}
            detik
          </p>
          <div className="mx-auto mt-4 h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
            <div
              className="h-full rounded-full bg-brand-600 transition-all duration-1000 ease-linear"
              style={{ width: `${(seconds / 5) * 100}%` }}
            />
          </div>
        </div>

        <button
          type="button"
          onClick={() => router.push('/login')}
          className="btn-primary mt-7 w-full justify-center py-2.5"
        >
          Masuk Sekarang <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
