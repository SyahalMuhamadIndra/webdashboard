import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

/**
 * /auth/confirm — callback dari link konfirmasi email Supabase.
 * Menangani 3 bentuk link (PKCE + OTP):
 *   1) PKCE: ?code=pkce_xxx
 *   2) PKCE varian : ?token=pkce_xxx&type=signup
 *   3) OTP / magic-link: ?token_hash=xxx&type=signup|recovery|invite|email_change|email
 *
 * Pendekatan: gunakan createClient (server, @supabase/ssr) yang membaca
 * code_verifier PEMCE dari cookie. Karena signUp sekarang dilakukan di browser
 * (createBrowserClient), "code_verifier" tersimpan di document.cookie sehingga
 * tukar kode di sini berhasil dan tidak lagi error "PKCE code verifier not found
 * in storage". Sesi hasil pertukaran ditulis kembali ke cookie oleh @supabase/ssr.
 *
 * Setelah berhasil -> arahkan ke /auth/confirmed (halaman sukses + countdown).
 */
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get('code');
  const token = searchParams.get('token'); // PKCE varian (bisa berawalan pkce_)
  const token_hash = searchParams.get('token_hash');
  const type = searchParams.get('type');
  const next = searchParams.get('next') ?? '/auth/confirmed';

  // Pakai URL produksi bila tersedia; fallback ke origin request.
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
  const origin = siteUrl || request.nextUrl.origin;

  const supabase = await createClient();

  // 1) & 2) PKCE flow — tukar kode dengan code_verifier yang tersimpan di cookie.
  const pkceValue = code || (token && token.startsWith('pkce_') ? token : null);
  if (pkceValue) {
    const { error, data } = await supabase.auth.exchangeCodeForSession(pkceValue);
    if (!error) {
      // Setelah sesi terpasang, arahkan ke /auth/confirmed.
      return NextResponse.redirect(`${origin}/auth/confirmed`);
    }
    // Jika session sudah valid (mis. user sudah login), langsung ke dashboard.
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      return NextResponse.redirect(`${origin}/dashboard`);
    }
    return NextResponse.redirect(
      `${origin}/login?error=${encodeURIComponent(error.message)}`
    );
  }

  // 3) OTP / token_hash flow.
  if (token_hash && type) {
    const { error } = await supabase.auth.verifyOtp({
      type: type as 'signup' | 'recovery' | 'invite' | 'email_change' | 'email',
      token_hash,
      options: { redirectTo: `${origin}/auth/confirm` },
    });
    if (!error) {
      return NextResponse.redirect(`${origin}/auth/confirmed`);
    }
    return NextResponse.redirect(
      `${origin}/login?error=${encodeURIComponent(error.message)}`
    );
  }

  // Fallback: tanpa kredensial yang valid.
  return NextResponse.redirect(
    `${origin}/login?error=${encodeURIComponent(
      'Tautan konfirmasi tidak valid atau sudah kedaluwarsa.'
    )}`
  );
}
