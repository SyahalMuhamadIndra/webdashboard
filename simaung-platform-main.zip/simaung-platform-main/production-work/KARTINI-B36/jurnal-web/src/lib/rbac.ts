import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';

// ============================================================
// RBAC: Roles & Permissions (tabel sudah ada di schema)
// Fitur ringan untuk kelola role & hak akses ala Odoo.
// ============================================================

export async function listRoles(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('roles')
    .select('*')
    .eq('company_id', companyId)
    .order('created_at', { ascending: true })
    .limit(200);
  if (error) throw new Error(error.message);
  return (data || []) as any[];
}

export async function listPermissions() {
  const s = createAdminClient();
  const { data, error } = await s
    .from('permissions')
    .select('*')
    .order('module')
    .order('name')
    .limit(500);
  if (error) throw new Error(error.message);
  return (data || []) as any[];
}

export async function listRolePermissions(roleId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('role_permissions')
    .select('permission_id')
    .eq('role_id', roleId);
  if (error) throw new Error(error.message);
  return (data || []).map((r: any) => r.permission_id as string);
}

export async function createRole(companyId: string, input: { name: string; description?: string }) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data, error } = await s
    .from('roles')
    .insert({ company_id: companyId, name: input.name, description: input.description || null, is_system: false })
    .select('id')
    .single();
  if (error || !data) throw new Error(error?.message || 'Gagal membuat role.');
  return { id: data.id as string };

  }, 'createRole');
}

export async function togglePermission(roleId: string, permissionId: string, enabled: boolean) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  if (enabled) {
    const { error } = await s.from('role_permissions').insert({ role_id: roleId, permission_id: permissionId });
    if (error) throw new Error(error.message);
  } else {
    const { error } = await s
      .from('role_permissions')
      .delete()
      .eq('role_id', roleId)
      .eq('permission_id', permissionId);
    if (error) throw new Error(error.message);
  }

  }, 'togglePermission');
}

export async function deleteRole(roleId: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { error } = await s.from('roles').delete().eq('id', roleId);
  if (error) throw new Error(error.message);

  }, 'deleteRole');
}
