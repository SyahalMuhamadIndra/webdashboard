
export async function readMaintenanceStatus(): Promise<{enabled: boolean; message: string}> {
  try {
    const response = await fetch('https://api.tokokartini.com/api/maintenance/status', {
      cache: 'no-store', signal: AbortSignal.timeout(5000),
    });
    if (!response.ok) throw new Error('Unavailable');
    const state = await response.json();
    if (typeof state.enabled !== 'boolean') throw new Error('Invalid status');
    return {enabled: state.enabled, message: String(state.message || 'Sistem sedang maintenance.')};
  } catch {
    return {enabled: true, message: 'Status layanan belum dapat diperiksa. Silakan coba kembali.'};
  }
}
export async function requireServiceAvailable() {
  const state = await readMaintenanceStatus();
  if (state.enabled) throw new Error(state.message);
}
export async function maintenanceResponse() {
  const state = await readMaintenanceStatus();
  if (!state.enabled) return null;
  return Response.json({code: 'SERVICE_CLOSED', message: state.message}, {
    status: 503, headers: {'Cache-Control':'no-store','Retry-After':'30'},
  });
}
