import {erp} from './erp/runtime';
import {createStockService} from './erp/stock-service';
import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';
import { createInvoiceAndPost, createBillAndPost } from './odoo';

// ============================================================
// Module services untuk modul Odoo baru (tabel migration 0002)
// ============================================================
async function list<T>(table: string, companyId: string, order: string) {
  const s = createAdminClient();
  const { data, error } = await s.from(table).select('*').eq('company_id', companyId).order(order, { ascending: false }).limit(200);
  if (error) throw new Error(error.message);
  return (data || []) as T[];
}

async function nextNum(table: string, companyId: string, column: string, prefix: string) {
  const s = createAdminClient();
  const { data } = await s.from(table).select(column).eq('company_id', companyId).ilike(column, `${prefix}-%`);
  let max = 0;
  for (const r of data || []) {
    const n = parseInt(String((r as any)[column]).replace(`${prefix}-`, ''), 10);
    if (!isNaN(n) && n > max) max = n;
  }
  return `${prefix}-${String(max + 1).padStart(4, '0')}`;
}

function today(offset = 0) { return new Date(Date.now() + offset * 86400000).toISOString().slice(0, 10); }

// ---- Quotation ------------------------------------------------------------
export async function listQuotations(companyId: string) {
  return list<any>('quotations', companyId, 'created_at');
}
export async function createQuotation(companyId: string, input: { customer_id?: string; quotation_date?: string; valid_until?: string; lines: { product_id?: string; description?: string; quantity: number; unit_price: number; discount?: number; tax_rate_id?: string }[] }) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const number = await nextNum('quotations', companyId, 'quotation_number', 'QUO');
  const lines = input.lines.map((l: any) => ({ ...l, line_total: (+l.quantity || 0) * (+l.unit_price || 0) * (1 - (+(l.discount ?? 0) || 0) / 100) }));
  const subtotal = lines.reduce((a, l) => a + l.line_total, 0);
  const tax = lines.reduce((a, l) => a + (l.tax_rate_id ? (l.line_total * 0.11) : 0), 0);
  const { data: q, error } = await s.from('quotations').insert({
    company_id: companyId, customer_id: input.customer_id || null, quotation_number: number,
    quotation_date: input.quotation_date || today(0), valid_until: input.valid_until || today(30),
    status: 'confirmed', subtotal, tax_amount: tax, total: subtotal + tax,
  }).select('id').single();
  if (error || !q) throw new Error(error?.message || 'Gagal membuat quotation.');
  await s.from('quotation_lines').insert(lines.map((l) => ({ quotation_id: q.id, ...l })));
  return { number };

  }, 'createQuotation');
}

// ---- Purchase Order -------------------------------------------------------
export async function listPurchaseOrders(companyId: string) {
  return list<any>('purchase_orders', companyId, 'created_at');
}
export async function createPurchaseOrder(companyId: string, input: { supplier_id?: string; po_date?: string; expected_date?: string; lines: { product_id?: string; description?: string; quantity: number; unit_price: number; tax_rate_id?: string }[] }) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const number = await nextNum('purchase_orders', companyId, 'po_number', 'PO');
  const lines = input.lines.map((l) => ({ ...l, line_total: (+l.quantity || 0) * (+l.unit_price || 0) }));
  const subtotal = lines.reduce((a, l) => a + l.line_total, 0);
  const { error } = await s.from('purchase_orders').insert({
    company_id: companyId, supplier_id: input.supplier_id || null, po_number: number,
    po_date: input.po_date || today(0), expected_date: input.expected_date || today(14),
    status: 'confirmed', subtotal, tax_amount: 0, total: subtotal,
  });
  if (error) throw new Error(error.message);
  const { data: q } = await s.from('purchase_orders').select('id').eq('company_id', companyId).eq('po_number', number).single();
  if (q) await s.from('po_items').insert(lines.map((l) => ({ po_id: q.id, ...l })));
  return { number };

  }, 'createPurchaseOrder');
}

// ---- Convert Quotation -> Invoice (Odoo "confirm → invoice" workflow) ------
export async function convertQuotationToInvoice(companyId: string, quotationId: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data: q, error } = await s.from('quotations').select('*, quotation_lines(*)').eq('id', quotationId).eq('company_id', companyId).single();
  if (error || !q) throw new Error(error?.message || 'Quotation tidak ditemukan.');
  if (q.converted_invoice_id) throw new Error('Quotation ini sudah dikonversi menjadi invoice.');
  if (!q.customer_id) throw new Error('Quotation belum memiliki pelanggan.');

  const items = (q.quotation_lines || []).map((l: any) => ({
    product_id: l.product_id, description: l.description || 'Item',
    quantity: Number(l.quantity) || 0, unit_price: Number(l.unit_price) || 0,
    discount: Number(l.discount) || 0, tax_rate_id: l.tax_rate_id || undefined,
  }));
  const res = await createInvoiceAndPost(companyId, {
    customer_id: q.customer_id,
    invoice_date: q.quotation_date || today(0),
    due_date: q.valid_until || null,
    items,
  });
  await s.from('quotations').update({ status: 'posted', converted_invoice_id: res.invoiceId }).eq('id', quotationId);
  return res;

  }, 'convertQuotationToInvoice');
}

// ---- Convert Purchase Order -> Bill (Odoo "receive → bill" workflow) -------
export async function convertPurchaseOrderToBill(companyId: string, poId: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data: po, error } = await s.from('purchase_orders').select('*, po_items(*)').eq('id', poId).eq('company_id', companyId).single();
  if (error || !po) throw new Error(error?.message || 'Purchase Order tidak ditemukan.');
  if (po.converted_bill_id) throw new Error('Purchase Order ini sudah dikonversi menjadi bill.');
  if (!po.supplier_id) throw new Error('Purchase Order belum memiliki pemasok.');

  const items = (po.po_items || []).map((l: any) => ({
    product_id: l.product_id, description: l.description || 'Item',
    quantity: Number(l.quantity) || 0, unit_price: Number(l.unit_price) || 0,
    discount: Number(l.discount) || 0, tax_rate_id: l.tax_rate_id || undefined,
  }));
  const res = await createBillAndPost(companyId, {
    supplier_id: po.supplier_id,
    bill_date: po.po_date || today(0),
    due_date: po.expected_date || null,
    items,
  });
  await s.from('purchase_orders').update({ status: 'posted', converted_bill_id: res.billId }).eq('id', poId);
  return res;

  }, 'convertPurchaseOrderToBill');
}

// ---- Delivery / Receipt / Transfer ---------------------------------------
export async function listDeliveries(companyId: string) { return list<any>('delivery_orders', companyId, 'created_at'); }
export async function createDelivery(companyId: string, input: { warehouse_id?: string; customer_id?: string; delivery_date?: string; lines: { product_id: string; quantity: number }[] }) {
  return withErpTransaction(async () => {
  if(!input.lines.length||input.lines.some(l=>!Number.isFinite(l.quantity)||l.quantity<=0))throw Error('Isi baris dengan jumlah positif.');
  if(!input.warehouse_id)throw Error('Gudang wajib dipilih.');
  const s = createAdminClient();
  const number = await nextNum('delivery_orders', companyId, 'delivery_number', 'DO');
  const { error } = await s.from('delivery_orders').insert({ company_id: companyId, warehouse_id: input.warehouse_id || null, customer_id: input.customer_id || null, delivery_number: number, delivery_date: input.delivery_date || today(0), status: 'posted', total: 0 });
  if (error) throw new Error(error.message);
  const { data: q } = await s.from('delivery_orders').select('id').eq('company_id', companyId).eq('delivery_number', number).single();
  if (q) await s.from('delivery_items').insert(input.lines.map((l) => ({ delivery_id: q.id, ...l })));
  if(!q)throw Error('Dokumen tidak tersimpan.');
  const stock=createStockService(erp());
  for(const line of [...input.lines].sort((a,b)=>a.product_id.localeCompare(b.product_id))){
    await stock.adjust(companyId,{product_id:line.product_id,warehouse_id:input.warehouse_id!,quantity:-line.quantity,reference_type:'delivery',reference_id:q.id,memo:number});
  }
  return { number };

  }, 'createDelivery');
}

export async function listReceipts(companyId: string) { return list<any>('goods_receipts', companyId, 'created_at'); }
export async function createReceipt(companyId: string, input: { warehouse_id?: string; supplier_id?: string; receipt_date?: string; lines: { product_id: string; quantity: number }[] }) {
  return withErpTransaction(async () => {
  if(!input.lines.length||input.lines.some(l=>!Number.isFinite(l.quantity)||l.quantity<=0))throw Error('Isi baris dengan jumlah positif.');
  if(!input.warehouse_id)throw Error('Gudang wajib dipilih.');
  const s = createAdminClient();
  const number = await nextNum('goods_receipts', companyId, 'receipt_number', 'GR');
  const { error } = await s.from('goods_receipts').insert({ company_id: companyId, warehouse_id: input.warehouse_id || null, supplier_id: input.supplier_id || null, receipt_number: number, receipt_date: input.receipt_date || today(0), status: 'posted', total: 0 });
  if (error) throw new Error(error.message);
  const { data: q } = await s.from('goods_receipts').select('id').eq('company_id', companyId).eq('receipt_number', number).single();
  if (q) await s.from('receipt_items').insert(input.lines.map((l) => ({ receipt_id: q.id, ...l })));
  if(!q)throw Error('Dokumen tidak tersimpan.');
  const stock=createStockService(erp());
  for(const line of [...input.lines].sort((a,b)=>a.product_id.localeCompare(b.product_id))){
    await stock.adjust(companyId,{product_id:line.product_id,warehouse_id:input.warehouse_id!,quantity:line.quantity,reference_type:'receipt',reference_id:q.id,memo:number});
  }
  return { number };

  }, 'createReceipt');
}

export async function listTransfers(companyId: string) { return list<any>('stock_transfers', companyId, 'created_at'); }
export async function createTransfer(companyId: string, input: { from_warehouse_id?: string; to_warehouse_id?: string; transfer_date?: string; lines: { product_id: string; quantity: number }[] }) {
  return withErpTransaction(async () => {
  if(!input.lines.length||input.lines.some(l=>!Number.isFinite(l.quantity)||l.quantity<=0))throw Error('Isi baris dengan jumlah positif.');
  if(!input.from_warehouse_id||!input.to_warehouse_id||input.from_warehouse_id===input.to_warehouse_id)throw Error('Pilih gudang asal dan tujuan yang berbeda.');
  const s = createAdminClient();
  const number = await nextNum('stock_transfers', companyId, 'transfer_number', 'TR');
  const { error } = await s.from('stock_transfers').insert({ company_id: companyId, from_warehouse_id: input.from_warehouse_id || null, to_warehouse_id: input.to_warehouse_id || null, transfer_number: number, transfer_date: input.transfer_date || today(0), status: 'posted' });
  if (error) throw new Error(error.message);
  const { data: q } = await s.from('stock_transfers').select('id').eq('company_id', companyId).eq('transfer_number', number).single();
  if (q) await s.from('transfer_items').insert(input.lines.map((l) => ({ transfer_id: q.id, ...l })));
  if(!q)throw Error('Dokumen tidak tersimpan.');
  const stock=createStockService(erp());
  for(const line of [...input.lines].sort((a,b)=>a.product_id.localeCompare(b.product_id))){
    const source=await stock.adjust(companyId,{product_id:line.product_id,warehouse_id:input.from_warehouse_id!,quantity:-line.quantity,reference_type:'stock_transfer',reference_id:q.id,memo:'Transfer keluar '+number});
    await stock.adjust(companyId,{product_id:line.product_id,warehouse_id:input.to_warehouse_id!,quantity:line.quantity,unit_cost:source.avgCost,reference_type:'stock_transfer',reference_id:q.id,memo:'Transfer masuk '+number});
  }
  return { number };

  }, 'createTransfer');
}

// ---- Currency & FX --------------------------------------------------------
export async function listCurrencies(companyId: string) { return list<any>('currencies', companyId, 'created_at'); }
export async function createCurrency(companyId: string, input: { code: string; name: string; symbol?: string; rate: number }) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data: cur, error } = await s.from('currencies').insert({ company_id: companyId, code: input.code, name: input.name, symbol: input.symbol || null, is_base: false }).select('id').single();
  if (error) throw new Error(error.message);
  await s.from('currency_rates').insert({ company_id: companyId, currency_id: cur.id, rate: input.rate, effective_date: today(0) });
  return { id: cur.id };

  }, 'createCurrency');
}

// ---- Budget ---------------------------------------------------------------
export async function listBudgets(companyId: string) { return list<any>('budgets', companyId, 'created_at'); }
export async function createBudget(companyId: string, input: { name: string; fiscal_year: number; lines: { account_id: string; amount: number }[] }) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data: b, error } = await s.from('budgets').insert({ company_id: companyId, name: input.name, fiscal_year: input.fiscal_year, is_active: true }).select('id').single();
  if (error) throw new Error(error.message);
  await s.from('budget_items').insert(input.lines.map((l) => ({ budget_id: b.id, ...l })));
  return { id: b.id };

  }, 'createBudget');
}

// ---- CRM opportunities ----------------------------------------------------
export async function listOpportunities(companyId: string) { return list<any>('opportunities', companyId, 'created_at'); }
export async function createOpportunity(companyId: string, input: { title: string; customer_id?: string; expected_amount: number; probability?: number; stage?: string; expected_close?: string }) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { error } = await s.from('opportunities').insert({ company_id: companyId, title: input.title, customer_id: input.customer_id || null, expected_amount: input.expected_amount, probability: input.probability || 0, stage: input.stage || 'new', expected_close: input.expected_close || null });
  if (error) throw new Error(error.message);

  }, 'createOpportunity');
}

// ---- Projects & tasks -----------------------------------------------------
export async function listProjects(companyId: string) { return list<any>('projects', companyId, 'created_at'); }
export async function createProject(companyId: string, input: { name: string; description?: string; start_date?: string; end_date?: string }) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { error } = await s.from('projects').insert({ company_id: companyId, name: input.name, description: input.description || null, start_date: input.start_date || today(0), end_date: input.end_date || null, status: 'on_track' });
  if (error) throw new Error(error.message);

  }, 'createProject');
}

// ---- Bank reconciliation --------------------------------------------------
export async function listReconciliations(companyId: string) { return list<any>('bank_reconciliations', companyId, 'created_at'); }
export async function createReconciliation(companyId: string, input: { bank_account_id?: string; statement_balance: number; book_balance: number; notes?: string }) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const diff = (+input.statement_balance || 0) - (+input.book_balance || 0);
  const { error } = await s.from('bank_reconciliations').insert({ company_id: companyId, bank_account_id: input.bank_account_id || null, recon_date: today(0), statement_balance: input.statement_balance, book_balance: input.book_balance, difference: diff, status: diff === 0 ? 'approved' : 'draft', notes: input.notes || null });
  if (error) throw new Error(error.message);

  }, 'createReconciliation');
}

// ---- Dunning rules --------------------------------------------------------
export async function listDunning(companyId: string) { return list<any>('dunning_rules', companyId, 'created_at'); }
export async function createDunning(companyId: string, input: { name: string; days_overdue: number; fee: number; template?: string }) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { error } = await s.from('dunning_rules').insert({ company_id: companyId, name: input.name, days_overdue: input.days_overdue, fee: input.fee, template: input.template || null, is_active: true });
  if (error) throw new Error(error.message);

  }, 'createDunning');
}
