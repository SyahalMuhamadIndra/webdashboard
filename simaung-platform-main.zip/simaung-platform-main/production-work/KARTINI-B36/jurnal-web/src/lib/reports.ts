// ============================================================
// LAPORAN KARTINI — Report Engine (UNIFIED BACKEND)
// Membaca laporan keuangan dari backend terpadu:
//   https://api.tokokartini.com/api/accounting/*
// (Neon Postgres — DB yang sama dengan aplikasi absensi & POS).
//
// Catatan: parameter `companyId` tetap dipertahankan pada signature agar
// seluruh halaman report TIDAK perlu diubah. Backend terpadu bersifat
// single-tenant (satu company: KARTINI) dan menyelesaikan company sendiri.
// ============================================================

import { accountingGet } from './accounting-api';
import {erp} from './erp/runtime';
import {createSupplementalReports} from './erp/report-service';

export interface AccountInfo {
  id: string;
  code: string;
  name: string;
  typeName: string;
  normalBalance: 'debit' | 'credit';
}

export interface JournalLineRow {
  account_id: string;
  debit: number;
  credit: number;
  entry_date: string;
  company_id: string;
  branch_id: string | null;
}

export interface TrialBalanceRow {
  code: string;
  name: string;
  typeName: string;
  normalBalance: 'debit' | 'credit';
  debit: number;
  credit: number;
  balance: number;
}

export interface IncomeStatementRow {
  code: string;
  name: string;
  amount: number;
}

// ------------------------------------------------------------
// Accounts
// ------------------------------------------------------------
export async function getAccounts(_companyId?: string): Promise<AccountInfo[]> {
  const data = await accountingGet<{ items: AccountInfo[] }>('/accounting/accounts');
  const items = data.items || [];
  return items
    .map((a) => ({
      id: a.id,
      code: a.code,
      name: a.name,
      typeName: a.typeName || '',
      normalBalance: (a.normalBalance || 'debit') as 'debit' | 'credit',
    }))
    .sort((a, b) => String(a.code).localeCompare(String(b.code)));
}

// ------------------------------------------------------------
// Trial Balance
// ------------------------------------------------------------
export async function getTrialBalance(_companyId: string, from: string, to: string) {
  const data = await accountingGet<{
    rows: TrialBalanceRow[];
    totalDebit: number;
    totalCredit: number;
    balanced: boolean;
  }>('/accounting/trial-balance', { from, to });
  return {
    rows: data.rows || [],
    totalDebit: data.totalDebit || 0,
    totalCredit: data.totalCredit || 0,
    balanced:
      data.balanced ?? Math.abs((data.totalDebit || 0) - (data.totalCredit || 0)) < 0.009,
  };
}

// ------------------------------------------------------------
// Income Statement (P&L)
// ------------------------------------------------------------
export async function getIncomeStatement(_companyId: string, from: string, to: string) {
  const data = await accountingGet<{
    revenueRows: IncomeStatementRow[];
    expenseRows: IncomeStatementRow[];
    totalRevenue: number;
    totalExpenses: number;
    netIncome: number;
  }>('/accounting/income-statement', { from, to });
  return {
    revenueRows: data.revenueRows || [],
    expenseRows: data.expenseRows || [],
    totalRevenue: data.totalRevenue || 0,
    totalExpenses: data.totalExpenses || 0,
    netIncome: data.netIncome || 0,
  };
}

// ------------------------------------------------------------
// Balance Sheet
// ------------------------------------------------------------
export async function getBalanceSheet(_companyId: string, from: string, to: string) {
  const data = await accountingGet<{
    assets: IncomeStatementRow[];
    liabilities: IncomeStatementRow[];
    equity: IncomeStatementRow[];
    totalAssets: number;
    totalLiabilities: number;
    totalEquity: number;
    balanced: boolean;
  }>('/accounting/balance-sheet', { from, to });
  return {
    assets: data.assets || [],
    liabilities: data.liabilities || [],
    equity: data.equity || [],
    totalAssets: data.totalAssets || 0,
    totalLiabilities: data.totalLiabilities || 0,
    totalEquity: data.totalEquity || 0,
    balanced: data.balanced ?? true,
  };
}

// ------------------------------------------------------------
// Cash Flow
// ------------------------------------------------------------
export async function getCashFlow(_companyId: string, from: string, to: string) {
  const data = await accountingGet<{
    inflow: number;
    outflow: number;
    net: number;
    accounts: { code: string; name: string; inflow: number; outflow: number }[];
  }>('/accounting/cash-flow', { from, to });
  return {
    inflow: data.inflow || 0,
    outflow: data.outflow || 0,
    net: data.net || 0,
    accounts: data.accounts || [],
  };
}

// ------------------------------------------------------------
// General Ledger (per akun)
// ------------------------------------------------------------
export async function getGeneralLedger(
  _companyId: string,
  accountId: string,
  from: string,
  to: string
) {
  const data = await accountingGet<{
    account: { id: string; code: string; name: string; normalBalance: 'debit' | 'credit' };
    rows: {
      date: string;
      entryNumber: string;
      memo: string;
      debit: number;
      credit: number;
      balance: number;
    }[];
    totalDebit: number;
    totalCredit: number;
  }>('/accounting/general-ledger', { accountId, from, to });
  return {
    account: data.account,
    rows: data.rows || [],
    totalDebit: data.totalDebit || 0,
    totalCredit: data.totalCredit || 0,
  };
}

// ------------------------------------------------------------
// Dashboard summary (KPI) — dari endpoint /accounting/summary
// ------------------------------------------------------------
export async function getAccountingSummary(from: string, to: string) {
  return accountingGet<{
    companyId: string;
    range: { from: string; to: string };
    kpi: {
      revenue: number;
      expenses: number;
      netIncome: number;
      assets: number;
      liabilities: number;
      equity: number;
      journalCount: number;
      accountCount: number;
      totalDebit: number;
      totalCredit: number;
      balanced: boolean;
    };
  }>('/accounting/summary', { from, to });
}

// ------------------------------------------------------------
// Jurnal Umum (list entri)
// ------------------------------------------------------------
export interface JournalListItem {
  id: string;
  entryNumber: string;
  entryDate: string;
  memo: string | null;
  source: string | null;
  isPosted: boolean;
  lineCount: number;
  totalDebit: number;
  totalCredit: number;
}

export async function listJournal(limit = 100): Promise<JournalListItem[]> {
  const data = await accountingGet<{ items: JournalListItem[] }>('/accounting/journal', {
    limit,
  });
  return data.items || [];
}

export async function getJournalEntry(id: string) {
  return accountingGet<{
    entry: JournalListItem;
    lines: {
      id: string;
      accountId: string;
      accountCode: string;
      accountName: string;
      debit: number;
      credit: number;
      description: string | null;
    }[];
  }>(`/accounting/journal/${id}`);
}

// ------------------------------------------------------------
// Backward-compat helpers
// ------------------------------------------------------------
export async function getJournalLines(
  _companyId?: string,
  _from?: string,
  _to?: string
): Promise<JournalLineRow[]> {
  if (!_companyId) throw new Error('Perusahaan diperlukan.');
  return createSupplementalReports(erp()).lines(_companyId,_from,_to);
}

export interface BudgetVsActualRow {
  accountId: string;
  code: string;
  name: string;
  budget: number;
  actual: number;
  variance: number;
  variancePct: number;
}

export interface BudgetVsActualResult {
  budget: { id: string; name: string; fiscal_year: number } | null;
  rows: BudgetVsActualRow[];
  totalBudget: number;
  totalActual: number;
  variance: number;
}

export async function getBudgetVsActual(
  _companyId: string,
  _fiscalYear: number
): Promise<BudgetVsActualResult> {
  return createSupplementalReports(erp()).budget(_companyId,_fiscalYear);
}

export async function getCashFlowForecast(_companyId: string) {
  return createSupplementalReports(erp()).forecast(_companyId);
}

export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}
