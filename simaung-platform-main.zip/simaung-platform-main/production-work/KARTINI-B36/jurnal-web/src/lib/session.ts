import { createHmac, timingSafeEqual } from 'node:crypto';
import { cookies } from 'next/headers';

// ============================================================
// Sesi login Laporan Simaung Corporation — cookie bertanda-tangan (HMAC-SHA256).
// Login diverifikasi ke backend terpadu (api.tokokartini.com /admin/login).
// Tidak memakai Supabase.
// ============================================================

export const SESSION_COOKIE = 'lk_session';

function getSecret(): string {
  const secret = process.env.SESSION_SECRET || process.env.JWT_SECRET;
  if (!secret || secret.length < 32) throw new Error('Session signing key is not configured securely');
  return secret;
}

export interface SessionUser {
  email: string;
  name: string;
  role: string;
  companyId: string;
  exp: number;
  backendToken: string;
  adminId?: string;
  companyName?: string;
}

function b64url(buf: Buffer): string {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function fromB64url(s: string): Buffer {
  return Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
}

export async function signSession(
  user: Omit<SessionUser, 'exp'>,
  ttlSeconds = 60 * 60 * 24 * 7
): Promise<string> {
  const payload: SessionUser = { ...user, exp: Math.floor(Date.now() / 1000) + ttlSeconds };
  const body = b64url(Buffer.from(JSON.stringify(payload)));
  const sig = b64url(createHmac('sha256', getSecret()).update(body).digest());
  return `${body}.${sig}`;
}

export function verifySessionToken(token: string | undefined | null): SessionUser | null {
  if (!token || token.split('.').length !== 2) return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  try {
    const expected = b64url(createHmac('sha256', getSecret()).update(body).digest());
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    const payload = JSON.parse(fromB64url(body).toString('utf8')) as SessionUser;
    if (!Number.isFinite(payload?.exp) || payload.exp * 1000 <= Date.now()) return null;
    if (![payload.email, payload.name, payload.role, payload.companyId, payload.backendToken].every(v => typeof v === 'string' && v.length > 0)) return null;
    return payload;
  } catch {
    return null;
  }
}

export async function getSession(): Promise<SessionUser | null> {
  try {
    const store = await cookies();
    const session = verifySessionToken(store.get(SESSION_COOKIE)?.value);
    if (!session) return null;
    const response = await fetch('https://api.tokokartini.com/api/admin/me', {
      headers: { Authorization: `Bearer ${session.backendToken}` }, cache: 'no-store', signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) return null;
    const current = await response.json();
    if (!current.adminId || current.companyId !== session.companyId) return null;
    return { ...session, adminId: current.adminId, name: current.name, email: current.email, role: current.role, companyName: current.companyName };
  } catch {
    return null;
  }
}
