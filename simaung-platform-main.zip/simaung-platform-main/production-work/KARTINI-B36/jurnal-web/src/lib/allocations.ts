import { createAdminClient } from './supabase/admin';

// ============================================================
// Payment Allocations — read-only.
// Mencocokkan setiap alokasi pembayaran ke invoice / bill.
// Tabel existing (payment_allocations) tanpa migration baru.
// Query dipisah (tidak pakai embed PostgREST) agar aman dari
// kesalahan relasi seperti yang dulu terjadi di /audit-log.
// ============================================================

export interface AllocationRow {
  id: string;
  payment_id: string | null;
  invoice_id: string | null;
  bill_id: string | null;
  amount: number;
  payment_number: string;
  payment_date: string;
  direction: string;
  party: string;
  invoice_number: string | null;
  bill_number: string | null;
}

async function fetchNameMap(
  s: any,
  table: string,
  ids: string[],
  labelField: string
): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  if (ids.length === 0) return map;
  const { data, error } = await s.from(table).select(`id, ${labelField}`).in('id', ids);
  if (error) throw new Error(error.message);
  for (const row of data || []) map.set(row.id, row[labelField]);
  return map;
}

export async function listAllocations(companyId: string): Promise<AllocationRow[]> {
  const s = createAdminClient();

  const { data: payments, error: pErr } = await s
    .from('payments')
    .select('id, payment_number, payment_date, direction, customer_id, supplier_id')
    .eq('company_id', companyId)
    .order('payment_date', { ascending: false });
  if (pErr) throw new Error(pErr.message);
  const payList = (payments || []) as any[];
  if (payList.length === 0) return [];

  const paymentIds = payList.map((p) => p.id);
  const { data: allocs, error: aErr } = await s
    .from('payment_allocations')
    .select('*')
    .in('payment_id', paymentIds);
  if (aErr) throw new Error(aErr.message);
  const allocList = (allocs || []) as any[];
  if (allocList.length === 0) return [];

  const custIds = [...new Set(payList.map((p) => p.customer_id).filter(Boolean))];
  const suppIds = [...new Set(payList.map((p) => p.supplier_id).filter(Boolean))];
  const invoiceIds = [...new Set(allocList.map((a) => a.invoice_id).filter(Boolean))];
  const billIds = [...new Set(allocList.map((a) => a.bill_id).filter(Boolean))];

  const [custMap, suppMap, invMap, billMap] = await Promise.all([
    fetchNameMap(s, 'customers', custIds, 'name'),
    fetchNameMap(s, 'suppliers', suppIds, 'name'),
    fetchNameMap(s, 'invoices', invoiceIds, 'invoice_number'),
    fetchNameMap(s, 'bills', billIds, 'bill_number'),
  ]);

  const payMap = new Map<string, any>(payList.map((p) => [p.id, p]));

  return allocList.map((a) => {
    const pay = payMap.get(a.payment_id) || {};
    const party =
      (pay.customer_id && custMap.get(pay.customer_id)) ||
      (pay.supplier_id && suppMap.get(pay.supplier_id)) ||
      '-';
    return {
      id: a.id,
      payment_id: a.payment_id,
      invoice_id: a.invoice_id,
      bill_id: a.bill_id,
      amount: Number(a.amount || 0),
      payment_number: pay.payment_number || '-',
      payment_date: pay.payment_date || '',
      direction: pay.direction || 'in',
      party,
      invoice_number: (a.invoice_id && invMap.get(a.invoice_id)) || null,
      bill_number: (a.bill_id && billMap.get(a.bill_id)) || null,
    };
  });
}
