import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';

// ============================================================
// User management: profiles + role assignment (RBAC).
// Memakai tabel yang sudah ada (profiles, roles, user_roles)
// tanpa migration baru. Fitur ringan ala Odoo "Users".
// ============================================================

export async function listUsers(companyId: string) {
  const s = createAdminClient();
  // Kumpulkan user yang terhubung ke company (via user_scopes)
  const { data: scopes, error: scopeErr } = await s
    .from('user_scopes')
    .select('user_id')
    .eq('company_id', companyId);
  if (scopeErr) throw new Error(scopeErr.message);
  const userIds = (scopes || []).map((r: any) => r.user_id as string);
  if (userIds.length === 0) return [];

  const { data, error } = await s
    .from('profiles')
    .select('*')
    .in('id', userIds)
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);

  // Attach roles for each user
  const users = (data || []) as any[];
  const withRoles = await Promise.all(
    users.map(async (u) => ({ ...u, roles: await listUserRoles(u.id) }))
  );
  return withRoles;
}

export async function listUserRoles(userId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('user_roles')
    .select('role_id, roles!inner(name)')
    .eq('user_id', userId);
  if (error) throw new Error(error.message);
  return (data || []).map((r: any) => r.role_id as string);
}

export async function assignRole(userId: string, roleId: string, enabled: boolean) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  if (enabled) {
    const { data: exists } = await s
      .from('user_roles')
      .select('role_id')
      .eq('user_id', userId)
      .eq('role_id', roleId)
      .limit(1)
      .maybeSingle();
    if (!exists) {
      const { error } = await s.from('user_roles').insert({ user_id: userId, role_id: roleId });
      if (error) throw new Error(error.message);
    }
  } else {
    const { error } = await s
      .from('user_roles')
      .delete()
      .eq('user_id', userId)
      .eq('role_id', roleId);
    if (error) throw new Error(error.message);
  }

  }, 'assignRole');
}

export async function toggleUserActive(userId: string, isActive: boolean) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { error } = await s.from('profiles').update({ is_active: !isActive }).eq('id', userId);
  if (error) throw new Error(error.message);

  }, 'toggleUserActive');
}
