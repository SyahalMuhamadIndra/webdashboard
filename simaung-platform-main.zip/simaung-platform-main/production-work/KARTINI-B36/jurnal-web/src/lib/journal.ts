import {erp} from './erp/runtime';
import {createJournalService} from './erp/journal-service';
import type {JournalEntryInput} from './accounting';
export interface PostJournalResult {entryId:string;entryNumber:string}
export async function postJournalEntry(input:JournalEntryInput):Promise<PostJournalResult>{return createJournalService(erp()).post(input)}
export async function reverseJournalEntry(companyId:string,entryId:string,reversalDate:string,memo:string,createdBy?:string):Promise<PostJournalResult>{return createJournalService(erp()).reverse(companyId,entryId,reversalDate,memo,createdBy)}
