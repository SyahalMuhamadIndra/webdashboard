// Formatting utilities (IDR currency, dates)
import { format, parseISO } from 'date-fns';

export function formatIDR(amount: number, opts?: { symbol?: boolean; decimals?: number }): string {
  const dec = opts?.decimals ?? 2;
  const symbol = opts?.symbol ?? 'Rp';
  return (
    symbol +
    new Intl.NumberFormat('id-ID', {
      minimumFractionDigits: dec,
      maximumFractionDigits: dec,
    }).format(amount || 0)
  );
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat('id-ID').format(n || 0);
}

export function formatDate(date?: string | null): string {
  if (!date) return '-';
  try {
    return format(parseISO(date), 'dd MMM yyyy');
  } catch {
    return date;
  }
}

export function formatDateTime(date?: string | null): string {
  if (!date) return '-';
  try {
    return format(parseISO(date), 'dd MMM yyyy HH:mm');
  } catch {
    return date;
  }
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function monthStartISO(): string {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
}

export function monthEndISO(): string {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth() + 1, 0).toISOString().slice(0, 10);
}
