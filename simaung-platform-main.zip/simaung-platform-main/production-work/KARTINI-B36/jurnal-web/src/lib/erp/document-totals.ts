import {cents,amount} from './money';
type Item={quantity:number;unit_price:number;discount?:number;tax_rate_id?:string};
const scaled=(value:number,label:string)=>{
 const text=String(value);
 if(!/^\d+(?:\.\d{1,4})?$/.test(text))throw Error(label+' tidak valid (maksimal empat desimal).');
 const [whole,fraction='']=text.split('.');return BigInt(whole)*10000n+BigInt(fraction.padEnd(4,'0'));
};
const rounded=(n:bigint,d:bigint)=>(n+d/2n)/d;
export async function calculateDocument(items:Item[],taxRate:(id:string)=>Promise<number>){
 if(!Array.isArray(items)||!items.length||items.length>1000)throw Error('Isi minimal satu dan maksimal 1.000 baris.');
 let net=0n,tax=0n,discount=0n;
 const calculated=[];
 for(const item of items){
  const qty=scaled(item.quantity,'Kuantitas'),price=cents(item.unit_price),disc=scaled(item.discount??0,'Diskon');
  if(qty<=0n||price<0n||disc>1000000n)throw Error('Kuantitas, harga, atau diskon tidak valid.');
  const rate=item.tax_rate_id?scaled(await taxRate(item.tax_rate_id),'Tarif pajak'):0n;
  if(rate>1000000n)throw Error('Tarif pajak tidak valid.');
  const gross=rounded(qty*price,10000n),lineDiscount=rounded(gross*disc,1000000n),lineNet=gross-lineDiscount,lineTax=rounded(lineNet*rate,1000000n);
  net+=lineNet;tax+=lineTax;discount+=lineDiscount;
  calculated.push({quantity:item.quantity,unit_price:amount(price),discount:item.discount??0,tax_amount:amount(lineTax),line_total:amount(lineNet+lineTax)});
 }
 if(net+tax<=0n)throw Error('Total dokumen harus lebih dari nol.');
 return {items:calculated,subtotal:amount(net),taxAmount:amount(tax),discountAmount:amount(discount),total:amount(net+tax)};
}
