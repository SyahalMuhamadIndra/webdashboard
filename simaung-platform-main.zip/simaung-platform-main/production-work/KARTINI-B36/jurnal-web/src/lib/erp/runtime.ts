import 'server-only';
import {Pool} from 'pg';
import {getSession} from '../session';
import {requireServiceAvailable} from '../maintenance-server';
import schema from './schema.json';
import allowed from './allowed-tables.json';
import {createErpStore} from './store';
import type {Schema} from './query-engine';

let instance:ReturnType<typeof createErpStore>|undefined;
export function erp(){
 if(!instance){
  if(!process.env.DATABASE_URL)throw new Error('Layanan data belum dikonfigurasi.');
  const url=new URL(process.env.DATABASE_URL);
  const local=['127.0.0.1','localhost'].includes(url.hostname)&&process.env.KARTINI_ALLOW_LOCAL_DB==='true';
  if(!local&&!['postgres:','postgresql:'].includes(url.protocol))throw new Error('Koneksi database tidak valid.');
  for(const key of ['sslmode','sslrootcert','sslcert','sslkey','channel_binding'])url.searchParams.delete(key);
  const pool=new Pool({connectionString:url.toString(),ssl:local?false:{rejectUnauthorized:true},enableChannelBinding:true,max:3,idleTimeoutMillis:10000,connectionTimeoutMillis:10000});
  instance=createErpStore(pool,schema as Schema,allowed,async()=>{
   const session=await getSession();return session?.adminId?{adminId:session.adminId,companyId:session.companyId,role:session.role,email:session.email,name:session.name}:null;
  },requireServiceAvailable);
 }
 return instance;
}
export async function withErpTransaction<T>(work:()=>Promise<T>,action='erp.transaction'):Promise<T>{return erp().write(work,action)}

export async function withErpFormAction<T>(action:string,form:FormData,work:()=>Promise<T>):Promise<T>{return erp().formAction(action,form,work)}
