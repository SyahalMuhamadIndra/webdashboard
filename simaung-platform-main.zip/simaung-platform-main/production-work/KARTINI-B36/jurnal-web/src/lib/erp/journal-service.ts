import {randomUUID} from 'node:crypto';
import {cents,decimal} from './money';
import type {Database,Identity} from './query-engine';
import type {JournalEntryInput} from '../accounting';
import type {createErpStore} from './store';
const prefixes:Record<string,string>={manual:'JM',sales_invoice:'SINV',purchase_bill:'PB',customer_payment:'CP',supplier_payment:'SP',expense:'EXP',depreciation:'DEP',stock_adjustment:'STKA',bank_reconciliation:'BK',opening_balance:'OP',sales_return:'SR',purchase_return:'PR',deferred:'DEF'};
const uuid=(v:unknown):v is string=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
const date=(value:string)=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;const d=new Date(value+'T00:00:00Z');return Number.isFinite(d.valueOf())&&d.toISOString().slice(0,10)===value};
type Store=Pick<ReturnType<typeof createErpStore>,'transaction'>;
export function createJournalService(store:Store){
 async function postWithin(db:Database,user:Identity,input:JournalEntryInput){
  if(input.companyId!==user.companyId)throw Error('Perusahaan tidak diizinkan.');
  if(!prefixes[input.source]||!date(input.entryDate)||input.lines.length<2||input.lines.length>1000)throw Error('Data jurnal tidak valid.');
  if(!['SUPERADMIN','DEV','ADMIN','MANAGER','ACCOUNTANT'].includes(user.role.toUpperCase()))throw Error('Hak posting diperlukan.');
  const lines=input.lines.map(line=>{const debit=cents(line.debit||0),credit=cents(line.credit||0);if(!uuid(line.accountId)||debit<0n||credit<0n||(debit>0n&&credit>0n))throw Error('Baris jurnal tidak valid.');return {...line,debit,credit}}).filter(l=>l.debit>0n||l.credit>0n);
  const totalD=lines.reduce((s,l)=>s+l.debit,0n),totalC=lines.reduce((s,l)=>s+l.credit,0n);
  if(lines.length<2||totalD<=0n||totalD!==totalC)throw Error('Jurnal harus seimbang dan bernilai lebih dari nol.');
  const branches=[...new Set([input.branchId,...lines.map(l=>l.branchId)].filter(Boolean))] as string[];
  if(branches.length>1)throw Error('Satu jurnal hanya boleh mencatat satu cabang.');
  let branch=branches[0]||null;
  if(!branch&&user.branchIds!==null){if(user.branchIds.length!==1)throw Error('Pilih cabang yang diizinkan.');branch=user.branchIds[0]}
  if(branch){if(!uuid(branch)||(user.branchIds!==null&&!user.branchIds.includes(branch)))throw Error('Cabang tidak diizinkan.');if(!(await db.query('SELECT 1 FROM branches WHERE id=$1 AND company_id=$2 AND is_active=true',[branch,user.companyId])).rows.length)throw Error('Cabang tidak tersedia.')}
  const accounts=[...new Set(lines.map(l=>l.accountId))];const valid=await db.query('SELECT id FROM accounts WHERE id=ANY($1::uuid[]) AND company_id=$2 AND is_active=true AND is_header=false',[accounts,user.companyId]);
  if(valid.rows.length!==accounts.length)throw Error('Akun tidak aktif, akun header, atau tidak diizinkan.');
  const periods=(await db.query('SELECT id,is_closed FROM fiscal_periods WHERE company_id=$1 AND start_date<=$2::date AND end_date>=$2::date FOR UPDATE',[user.companyId,input.entryDate])).rows;
  if(periods.some(p=>p.is_closed)||periods.length>1)throw Error('Periode ditutup atau tumpang tindih.');
  const period=periods[0]?.id||null;
  if(input.fiscalPeriodId&&input.fiscalPeriodId!==period)throw Error('Periode tidak sesuai tanggal jurnal.');
  const reference=input.referenceId||null;
  if(reference&&!uuid(reference))throw Error('Referensi jurnal tidak valid.');
  if(input.idempotencyKey&&!uuid(input.idempotencyKey))throw Error('Kunci operasi tidak valid.');
  const memo=(input.memo||'').slice(0,4000)||null;
  const canonical=(rows:any[])=>rows.map(l=>[l.account_id||l.accountId,decimal(typeof l.debit==='bigint'?l.debit:cents(l.debit)),decimal(typeof l.credit==='bigint'?l.credit:cents(l.credit)),l.description||memo||null]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
  let prior:any;
  if(input.idempotencyKey)prior=(await db.query('SELECT *,entry_date::text AS entry_day FROM journal_entries WHERE id=$1 AND company_id=$2',[input.idempotencyKey,user.companyId])).rows[0];
  if(!prior&&reference)prior=(await db.query('SELECT *,entry_date::text AS entry_day FROM journal_entries WHERE company_id=$1 AND source=$2 AND reference_type IS NOT DISTINCT FROM $3 AND reference_id=$4 AND entry_date=$5::date',[user.companyId,input.source,input.referenceType||null,reference,input.entryDate])).rows[0];
  if(prior){const old=(await db.query('SELECT account_id,debit,credit,description FROM journal_lines WHERE journal_entry_id=$1 AND company_id=$2',[prior.id,user.companyId])).rows;
   if(prior.memo!==memo||prior.branch_id!==branch||prior.entry_day!==input.entryDate||JSON.stringify(canonical(old))!==JSON.stringify(canonical(lines)))throw Error('Referensi telah dipakai dengan isi berbeda.');
   return {entryId:prior.id,entryNumber:prior.entry_number};
  }
  const prefix=prefixes[input.source];const sequence=(await db.query("SELECT COALESCE(max(split_part(entry_number,'-',2)::bigint),0)::text AS n FROM journal_entries WHERE company_id=$1 AND entry_number ~ $2",[user.companyId,'^'+prefix+'-[0-9]+$'])).rows[0].n;
  const entryNumber=prefix+'-'+(BigInt(sequence)+1n),entryId=input.idempotencyKey||randomUUID();
  await db.query(`INSERT INTO journal_entries(id,company_id,branch_id,fiscal_period_id,entry_number,entry_date,memo,reference_type,reference_id,source,is_posted,created_by)
   VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,false,$11)`,[entryId,user.companyId,branch,period,entryNumber,input.entryDate,memo,input.referenceType||null,reference,input.source,user.adminId]);
  for(const line of lines)await db.query(`INSERT INTO journal_lines(company_id,journal_entry_id,account_id,branch_id,debit,credit,amount,description)VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,[user.companyId,entryId,line.accountId,branch,decimal(line.debit),decimal(line.credit),decimal(line.debit+line.credit),(line.description||memo||null)]);
  await db.query('UPDATE journal_entries SET is_posted=true WHERE id=$1 AND company_id=$2',[entryId,user.companyId]);
  return {entryId,entryNumber};
 }
 return {post:(input:JournalEntryInput)=>store.transaction((db,user)=>postWithin(db,user,input),true),
  reverse:(companyId:string,entryId:string,reversalDate:string,memo:string,_createdBy?:string)=>store.transaction(async(db,user)=>{
   if(companyId!==user.companyId||!uuid(entryId))throw Error('Jurnal tidak diizinkan.');
   const original=(await db.query('SELECT * FROM journal_entries WHERE id=$1 AND company_id=$2 FOR UPDATE',[entryId,companyId])).rows[0];
   if(!original||!original.is_posted||original.is_reversed)throw Error('Jurnal tidak ditemukan atau telah dibalik.');
   if(user.branchIds!==null&&!user.branchIds.includes(original.branch_id))throw Error('Cabang tidak diizinkan.');
   const lines=(await db.query('SELECT account_id,debit,credit,description FROM journal_lines WHERE journal_entry_id=$1 AND company_id=$2',[entryId,companyId])).rows;
   const result=await postWithin(db,user,{companyId,entryDate:reversalDate,source:'manual',referenceType:'reversal',referenceId:entryId,branchId:original.branch_id,memo:'REVERSAL '+original.entry_number+': '+memo,lines:lines.map(l=>({accountId:l.account_id,debit:Number(l.credit),credit:Number(l.debit),description:'REVERSAL: '+(l.description||memo)}))});
   await db.query('UPDATE journal_entries SET is_reversed=true,reversed_entry_id=$3 WHERE id=$1 AND company_id=$2',[entryId,companyId,result.entryId]);return result;
  },true)};
}
