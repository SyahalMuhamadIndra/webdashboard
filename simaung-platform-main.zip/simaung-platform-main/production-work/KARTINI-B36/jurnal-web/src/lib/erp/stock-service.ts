import type {createErpStore} from './store';
import {cents,decimal,amount} from './money';
export function createStockService(store:ReturnType<typeof createErpStore>){
 async function adjust(company:string,input:{product_id:string;warehouse_id:string;quantity:number;unit_cost?:number;memo?:string;reference_type?:string;reference_id?:string}){
  return store.transaction(async(db,user)=>{
   if(company!==user.companyId)throw Error('Perusahaan tidak diizinkan.');
   const qty=input.quantity;
   if(!Number.isFinite(qty)||qty===0||Math.round(qty*100)/100!==qty)throw Error('Kuantitas tidak valid (maksimal dua desimal).');
   const p=(await store.client.from('products').select('id,is_active,is_track_inventory').eq('id',input.product_id).single()).data;
   const w=(await store.client.from('warehouses').select('id,is_active').eq('id',input.warehouse_id).single()).data;
   if(!p?.is_active||!p.is_track_inventory||!w?.is_active)throw Error('Produk atau gudang tidak aktif atau tidak diizinkan.');
   if(input.unit_cost!==undefined&&cents(input.unit_cost)<0n)throw Error('Biaya tidak valid.');
   await db.query('INSERT INTO stock_balances(company_id,warehouse_id,product_id,quantity,avg_cost)VALUES($1,$2,$3,0,0)ON CONFLICT DO NOTHING',[company,w.id,p.id]);
   const balance=(await db.query('SELECT id,quantity,avg_cost FROM stock_balances WHERE company_id=$1 AND warehouse_id=$2 AND product_id=$3 FOR UPDATE',[company,w.id,p.id])).rows[0];
   const before=Math.round(Number(balance.quantity)*100),change=Math.round(qty*100),after=before+change;
   if(after<0)throw Error('Persediaan tidak mencukupi.');
   const cost=qty<0?cents(balance.avg_cost):cents(input.unit_cost??balance.avg_cost);
   const average=qty>0&&after>0?(BigInt(before)*cents(balance.avg_cost)+BigInt(change)*cost+BigInt(after)/2n)/BigInt(after):cents(balance.avg_cost);
   await db.query('UPDATE stock_balances SET quantity=$2,avg_cost=$3,updated_at=now()WHERE id=$1',[balance.id,after/100,decimal(average)]);
   await db.query("INSERT INTO stock_movements(company_id,warehouse_id,product_id,movement_type,quantity,unit_cost,description,reference_type,reference_id)VALUES($1,$2,$3,'adjustment',$4,$5,$6,$7,$8)",[company,w.id,p.id,qty,decimal(cost),input.memo||null,input.reference_type||null,input.reference_id||null]);
   return {success:true,quantity:after/100,avgCost:amount(average)};
  },true);
 }
 return {adjust};
}
