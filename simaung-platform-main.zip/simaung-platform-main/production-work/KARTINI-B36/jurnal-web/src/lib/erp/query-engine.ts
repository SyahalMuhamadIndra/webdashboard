export type Database = {query:(sql:string,values?:any[])=>Promise<{rows:any[];rowCount?:number|null}>};
export type Identity = {companyId:string;adminId:string;role:string;branchIds:string[]|null};
export type Schema = {tables:Record<string,{columns:Record<string,string>}>;foreignKeys:{conname:string;source:string;target:string;columns:string[];target_columns:string[]}[]};
export type Transaction = <T>(work:(db:Database,identity:Identity)=>Promise<T>,write:boolean)=>Promise<T>;
const ident=(s:string)=>{if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(s))throw Error('Nama kolom tidak valid.');return '"'+s+'"'};
const split=(text:string)=>{let depth=0,start=0;const result:string[]=[];for(let i=0;i<text.length;i++){if(text[i]==='(')depth++;if(text[i]===')')depth--;if(depth<0)throw Error('Select tidak valid.');if(text[i]===','&&depth===0){result.push(text.slice(start,i).trim());start=i+1}}if(depth!==0)throw Error('Select tidak valid.');result.push(text.slice(start).trim());return result.filter(Boolean)};
const management=new Set(['roles','role_permissions','user_roles','user_scopes','profiles','settings','fiscal_periods','branches','warehouses']);
export function createErpClient(schema:Schema,allowedNames:string[],transaction:Transaction){
 const allowed=new Set(allowedNames);let aliases=0;
 const actual=(name:string)=>name==='notifications'?'acc_notifications':name;
 const table=(name:string)=>{const n=actual(name);if(!allowed.has(n)||!schema.tables[n])throw Error('Tabel tidak diizinkan.');return n};
 const column=(name:string,key:string)=>{if(!schema.tables[name]?.columns[key])throw Error('Kolom tidak tersedia: '+name+'.'+key);return ident(key)};
 const foreign=(from:string,to:string,hint?:string)=>{
  const matches=schema.foreignKeys.filter(f=>(f.source===from&&f.target===to)||(f.target===from&&f.source===to)).filter(f=>!hint||hint===f.conname||f.columns.includes(hint));
  if(matches.length!==1)throw Error('Relasi tidak tersedia atau ambigu: '+from+' ke '+to);
  const fk=matches[0],many=fk.target===from;
  return {fk,many,join:(a:string,b:string)=>fk.columns.map((c,i)=>many?`${b}.${ident(c)}=${a}.${ident(fk.target_columns[i])}`:`${a}.${ident(c)}=${b}.${ident(fk.target_columns[i])}`).join(' AND ')};
 };
 function scope(name:string,alias:string,user:Identity,values:any[],visited:string[]=[]):string{
  const param=(v:any)=>{values.push(v);return '$'+values.length};
  if(visited.includes(name))return 'FALSE';
  let base:string;
  if(name==='permissions')return 'TRUE';
  if(name==='companies')base=`${alias}.id=${param(user.companyId)}`;
  else if(name==='profiles')base=`EXISTS(SELECT 1 FROM public.user_scopes us WHERE us.user_id=${alias}.id AND us.company_id=${param(user.companyId)})`;
  else if(schema.tables[name].columns.company_id)base=`${alias}.company_id=${param(user.companyId)}`;
  else {
   const parents=schema.foreignKeys.filter(f=>f.source===name&&allowed.has(f.target)&&f.target!=='profiles'&&!visited.includes(f.target));
   const candidate=parents.find(f=>schema.tables[f.target]?.columns.company_id)||parents[0];
   if(!candidate)throw Error('Cakupan perusahaan belum ditetapkan: '+name);
   const a='s'+(++aliases);base=`EXISTS(SELECT 1 FROM public.${ident(candidate.target)} ${a} WHERE ${candidate.columns.map((c,i)=>`${alias}.${ident(c)}=${a}.${ident(candidate.target_columns[i])}`).join(' AND ')} AND ${scope(candidate.target,a,user,values,[...visited,name])})`;
  }
  if(user.branchIds!==null){
   if(name==='branches')base+=` AND ${alias}.id=ANY(${param(user.branchIds)}::uuid[])`;
   else if(schema.tables[name].columns.branch_id)base+=` AND ${alias}.branch_id=ANY(${param(user.branchIds)}::uuid[])`;
   else if(schema.tables[name].columns.warehouse_id){const a='w'+(++aliases);base+=` AND EXISTS(SELECT 1 FROM public.warehouses ${a} WHERE ${a}.id=${alias}.warehouse_id AND ${scope('warehouses',a,user,values,[...visited,name])})`}
   else if(name==='receivables'||name==='payables'){
    const parent=name==='receivables'?'invoices':'bills',key=name==='receivables'?'invoice_id':'bill_id',a='d'+(++aliases);
    base+=` AND EXISTS(SELECT 1 FROM public.${ident(parent)} ${a} WHERE ${a}.id=${alias}.${ident(key)} AND ${scope(parent,a,user,values,[...visited,name])})`;
   }
   else if(name==='stock_transfers'){
    const a='w'+(++aliases);base+=` AND EXISTS(SELECT 1 FROM public.warehouses ${a} WHERE (${a}.id=${alias}.from_warehouse_id OR ${a}.id=${alias}.to_warehouse_id) AND ${scope('warehouses',a,user,values,[...visited,name])})`;
   }
  }
  return '('+base+')';
 }
 type Filter={field:string;op:string;value:any};
 class Builder {
  name:string;selection='*';filters:Filter[]=[];sorts:{field:string;asc:boolean}[]=[];take:number|null=null;skip=0;mode='read';payload:any;one=false;optional=false;count=false;head=false;conflict:string[]=[];promise?:Promise<any>;
  constructor(name:string){this.name=table(name)}
  select(fields='*',opts:any={}){this.selection=fields;this.count=opts.count==='exact';this.head=opts.head===true;return this}
  eq(field:string,value:any){this.filters.push({field,op:'=',value});return this} neq(field:string,value:any){this.filters.push({field,op:'<>',value});return this}
  gt(field:string,value:any){this.filters.push({field,op:'>',value});return this}gte(field:string,value:any){this.filters.push({field,op:'>=',value});return this}
  lt(field:string,value:any){this.filters.push({field,op:'<',value});return this}lte(field:string,value:any){this.filters.push({field,op:'<=',value});return this}
  ilike(field:string,value:any){this.filters.push({field,op:'ILIKE',value});return this}like(field:string,value:any){this.filters.push({field,op:'LIKE',value});return this}
  in(field:string,value:any[]){if(!Array.isArray(value))throw Error('Filter harus berupa daftar.');this.filters.push({field,op:'IN',value});return this}
  is(field:string,value:any){if(value!==null&&typeof value!=='boolean')throw Error('Filter IS tidak valid.');this.filters.push({field,op:'IS',value});return this}
  match(input:Record<string,any>){for(const [k,v]of Object.entries(input))this.eq(k,v);return this}
  order(field:string,opts:any={}){this.sorts.push({field,asc:opts.ascending!==false});return this}limit(n:number){if(!Number.isInteger(n)||n<0||n>10000)throw Error('Limit tidak valid.');this.take=n;return this}
  range(from:number,to:number){this.limit(to-from+1);if(!Number.isInteger(from)||from<0)throw Error('Offset tidak valid.');this.skip=from;return this}
  insert(input:any){this.mode='insert';this.payload=input;return this}update(input:any){this.mode='update';this.payload=input;return this}delete(){this.mode='delete';return this}
  upsert(input:any,opts:any){this.mode='upsert';this.payload=input;this.conflict=String(opts?.onConflict||'id').split(',').map(s=>s.trim());return this}
  single(){this.one=true;return this}maybeSingle(){this.one=true;this.optional=true;return this}
  then<TResult1=any,TResult2=never>(resolve?:((value:any)=>TResult1|PromiseLike<TResult1>)|null,reject?:((reason:any)=>TResult2|PromiseLike<TResult2>)|null):Promise<TResult1|TResult2>{this.promise??=transaction((db,user)=>this.execute(db,user),this.mode!=='read');return this.promise.then(resolve,reject)}
  filterSql(name:string,alias:string,filter:Filter,values:any[],user:Identity):string{
   const parts=filter.field.split('.');
   if(parts.length>1){const child=table(parts.shift()!);const r=foreign(name,child);const a='f'+(++aliases);return `EXISTS(SELECT 1 FROM public.${ident(child)} ${a} WHERE ${r.join(alias,a)} AND ${scope(child,a,user,values)} AND ${this.filterSql(child,a,{...filter,field:parts.join('.')},values,user)})`}
   const field=alias+'.'+column(name,filter.field);
   if(filter.op==='IS')return field+(filter.value===null?' IS NULL':filter.value?' IS TRUE':' IS FALSE');
   if(filter.op==='IN'){if(!filter.value.length)return 'FALSE';return field+' IN ('+filter.value.map((v:any)=>{values.push(v);return '$'+values.length}).join(',')+')'}
   if(filter.value===null)return field+(filter.op==='='?' IS NULL':filter.op==='<>'?' IS NOT NULL':(()=>{throw Error('Filter null tidak valid.')})());
   values.push(filter.value);return `${field} ${filter.op} $${values.length}`;
  }
  projection(name:string,alias:string,selection:string,values:any[],user:Identity):{sql:string;extra:string[]}{
   const fields:string[]=[],extra:string[]=[];
   for(const item of split(selection)){
    if(item==='*'){for(const key of Object.keys(schema.tables[name].columns))fields.push(`${alias}.${ident(key)} AS ${ident(key)}`);continue}
    const open=item.indexOf('(');
    if(open<0){const [output,source]=item.includes(':')?item.split(':'):[item,item];fields.push(`${alias}.${column(name,source)} AS ${ident(output)}`);continue}
    const descriptor=item.slice(0,open);const [output,relation]=descriptor.includes(':')?descriptor.split(':'):[descriptor,descriptor];const [target,...hints]=relation.split('!');const child=table(target),r=foreign(name,child,hints.find(h=>h!=='inner'));const a='j'+(++aliases);
    const body=item.slice(open+1,-1),where=`${r.join(alias,a)} AND ${scope(child,a,user,values)}`;
    if(hints.includes('inner'))extra.push(`EXISTS(SELECT 1 FROM public.${ident(child)} ${a} WHERE ${where})`);
    const key=output.split('!')[0];
    if(body.trim()==='count')fields.push(`(SELECT jsonb_build_array(jsonb_build_object('count',count(*))) FROM public.${ident(child)} ${a} WHERE ${where}) AS ${ident(key)}`);
    else{const projection=this.projection(child,a,body,values,user);const query=`SELECT ${projection.sql} FROM public.${ident(child)} ${a} WHERE ${where}${projection.extra.length?' AND '+projection.extra.join(' AND '):''}`;
     fields.push((r.many?`(SELECT COALESCE(jsonb_agg(row_to_json(q)),'[]'::jsonb) FROM (${query}) q)`:`(SELECT row_to_json(q) FROM (${query}) q LIMIT 1)`)+` AS ${ident(key)}`)}
   }
   if(!fields.length)throw Error('Select kosong.');return {sql:fields.join(','),extra};
  }
  async validateRow(db:Database,user:Identity,input:any,update=false){
   if(!input||Array.isArray(input)||typeof input!=='object')throw Error('Data tidak valid.');const row={...input};
   for(const key of Object.keys(row))column(this.name,key);
   if(schema.tables[this.name].columns.company_id){if(row.company_id!==undefined&&row.company_id!==user.companyId)throw Error('Perusahaan tidak diizinkan.');if(!update)row.company_id=user.companyId}
   if(update&&('id'in row||'company_id'in row))throw Error('Identitas data tidak boleh diubah.');
   if(schema.tables[this.name].columns.created_by){
    if(update&&'created_by'in row)throw Error('Pembuat data tidak boleh diubah.');
    if(!update)row.created_by=user.adminId;
   }
   if(!update && schema.tables[this.name].columns.branch_id && user.branchIds!==null && !row.branch_id){if(user.branchIds.length!==1)throw Error('Pilih cabang yang diizinkan.');row.branch_id=user.branchIds[0]}
   if('branch_id'in row&&row.branch_id!==null&&user.branchIds!==null&&!user.branchIds.includes(row.branch_id))throw Error('Cabang tidak diizinkan.');
   for(const fk of schema.foreignKeys.filter(f=>f.source===this.name)){
    if(!fk.columns.every(c=>row[c]!==undefined&&row[c]!==null))continue;
    if(fk.target==='companies'){if(row[fk.columns[0]]!==user.companyId)throw Error('Perusahaan tidak diizinkan.');continue}
    if(!allowed.has(fk.target))throw Error('Referensi data tidak diizinkan.');
    const params:any[]=[],a='v';const restriction=scope(fk.target,a,user,params);const checks=fk.target_columns.map((c,i)=>{params.push(row[fk.columns[i]]);return `${a}.${column(fk.target,c)}=$${params.length}`});
    const found=await db.query(`SELECT 1 FROM public.${ident(fk.target)} ${a} WHERE ${restriction} AND ${checks.join(' AND ')} LIMIT 1`,params);if(!found.rows.length)throw Error('Referensi tidak ditemukan atau tidak diizinkan.');
   }
   return row;
  }
  async execute(db:Database,user:Identity):Promise<any>{
   const write=this.mode!=='read';
   if(write){if(['journal_entries','journal_lines'].includes(this.name))throw Error('Gunakan layanan posting jurnal.');if(!['SUPERADMIN','DEV','ADMIN','MANAGER','ACCOUNTANT'].includes(user.role.toUpperCase()))throw Error('Hak tulis diperlukan.');if(management.has(this.name)&&!['SUPERADMIN','DEV'].includes(user.role.toUpperCase()))throw Error('Akses pengelola diperlukan.');if(['permissions','companies'].includes(this.name))throw Error('Data sistem ini tidak boleh dibuat melalui formulir.');if(['update','delete'].includes(this.mode)&&!this.filters.length)throw Error('Filter perubahan wajib diisi.')}
   const values:any[]=[];const a='t';const where=[scope(this.name,a,user,values),...this.filters.map(f=>this.filterSql(this.name,a,f,values,user))];
   let source=`public.${ident(this.name)}`;
   if(write){
    if(this.mode==='insert'||this.mode==='upsert'){
     const inputs=Array.isArray(this.payload)?this.payload:[this.payload];if(!inputs.length)return {data:[],error:null,count:0};if(inputs.length>1000)throw Error('Terlalu banyak baris.');
     const rows=[];for(const row of inputs)rows.push(await this.validateRow(db,user,row));const keys=[...new Set(rows.flatMap(row=>Object.keys(row)))];for(const row of rows)if(keys.length!==Object.keys(row).length||keys.some(k=>!(k in row)))throw Error('Kolom tiap baris harus sama.');
     const binds:any[]=[];const tuples=rows.map(row=>'('+keys.map(key=>{binds.push(row[key]);return '$'+binds.length}).join(',')+')');
     let conflict='';if(this.mode==='upsert'){for(const key of this.conflict)column(this.name,key);if(!this.conflict.includes('company_id')&&!this.conflict.includes('id'))throw Error('Kunci upsert tidak sah.');conflict=` ON CONFLICT (${this.conflict.map(ident).join(',')}) DO UPDATE SET ${keys.filter(k=>!this.conflict.includes(k)).map(k=>`${ident(k)}=EXCLUDED.${ident(k)}`).join(',')} WHERE ${scope(this.name,ident(this.name),user,binds)}`}
     const result=await db.query(`INSERT INTO ${source}(${keys.map(ident).join(',')}) VALUES ${tuples.join(',')}${conflict} RETURNING *`,binds);
     if(!result.rows.length)throw Error('Data tidak ditemukan atau tidak diizinkan.');
     // Parent ownership is checked before writes and the result is returned only to this tenant.
     return this.result(result.rows);
    }
    const row=this.mode==='update'?await this.validateRow(db,user,this.payload,true):null;
    const sets=row?Object.entries(row).map(([key,value])=>{values.push(value);return `${ident(key)}=$${values.length}`}):[];
    if(row&&!sets.length)throw Error('Tidak ada perubahan.');
    const result=await db.query(this.mode==='update'?`UPDATE ${source} ${a} SET ${sets.join(',')} WHERE ${where.join(' AND ')} RETURNING ${a}.*`:`DELETE FROM ${source} ${a} WHERE ${where.join(' AND ')} RETURNING ${a}.*`,values);if(!result.rows.length)throw Error('Data tidak ditemukan atau tidak diizinkan.');return this.result(result.rows);
   }
   const projection=this.projection(this.name,a,this.selection,values,user);where.push(...projection.extra);
   let count:number|undefined;
   if(this.count){const query=await db.query(`SELECT count(*)::int AS count FROM (SELECT ${projection.sql} FROM ${source} ${a} WHERE ${where.join(' AND ')}) counted`,values);count=query.rows[0].count;if(this.head)return {data:null,error:null,count}}
   const order=this.sorts.length?' ORDER BY '+this.sorts.map(o=>`${a}.${column(this.name,o.field)} ${o.asc?'ASC':'DESC'}`).join(','):'';
   const limit=this.take??(this.one?2:10000);values.push(limit);let tail=` LIMIT $${values.length}`;if(this.skip){values.push(this.skip);tail+=` OFFSET $${values.length}`}
   const result=await db.query(`SELECT ${projection.sql} FROM ${source} ${a} WHERE ${where.join(' AND ')}${order}${tail}`,values);return {...this.result(result.rows),...(count===undefined?{}:{count})};
  }
  result(rows:any[]){
   rows=rows.map(row=>Object.fromEntries(Object.entries(row).map(([key,value])=>{const type=schema.tables[this.name].columns[key];if(value!==null && ['numeric','double precision','real','bigint'].includes(type)){const n=Number(value);if(!Number.isFinite(n))throw Error('Angka database tidak valid.');return [key,n]}if(value instanceof Date)return [key,type==='date'?[value.getFullYear(),String(value.getMonth()+1).padStart(2,'0'),String(value.getDate()).padStart(2,'0')].join('-'):value.toISOString()];return [key,value]}))); 
   if(this.one){if(rows.length!==1){if(this.optional&&!rows.length)return {data:null,error:null};return {data:null,error:{message:'Data tunggal tidak ditemukan atau lebih dari satu.',code:'PGRST116'}}}return {data:rows[0],error:null}}
   return {data:rows,error:null};
  }
 }
 return {from:(name:string)=>new Builder(name)};
}
