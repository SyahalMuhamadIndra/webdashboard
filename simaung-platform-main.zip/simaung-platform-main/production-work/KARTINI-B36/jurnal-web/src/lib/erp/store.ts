import {createHash} from 'node:crypto';
import {AsyncLocalStorage} from 'node:async_hooks';
import type {Pool,PoolClient} from 'pg';
import {createErpClient,type Identity,type Schema,type Database,type Transaction} from './query-engine';
export type ErpSession={adminId:string;companyId:string;role:string;email:string;name:string};
type Context={db:PoolClient;identity:Identity;write:boolean};
export function createErpStore(pool:Pool,schema:Schema,allowed:string[],resolveSession:()=>Promise<ErpSession|null>,ensureAvailable:()=>Promise<void>){
 const contexts=new AsyncLocalStorage<Context>();
 const central=(role:string)=>['SUPERADMIN','DEV'].includes(role.toUpperCase());
 async function run<T>(work:(db:Database,identity:Identity)=>Promise<T>,write:boolean,action='erp.transaction'):Promise<T>{
  const existing=contexts.getStore();
  if(existing){if(write&&!existing.write)throw Error('Transaksi baca tidak menerima perubahan.');return work(existing.db,existing.identity)}
  await ensureAvailable();
  const session=await resolveSession();
  if(!session?.adminId||!session.companyId||!['SUPERADMIN','DEV','ADMIN','MANAGER','ACCOUNTANT','VIEWER'].includes(session.role.toUpperCase()))throw Error('Silakan masuk dengan akun yang diizinkan.');
  if(write&&session.role.toUpperCase()==='VIEWER')throw Error('Akun ini hanya dapat membaca.');
  const db=await pool.connect();
  try{
   await db.query(write?'BEGIN':'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
   await db.query("SET LOCAL statement_timeout='20s'");
   // A company lock serializes numbering and read/modify/write workflows.
   if(write)await db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['kartini.erp:'+session.companyId]);
   const current=(await db.query('SELECT is_active FROM profiles WHERE id=$1',[session.adminId])).rows[0];
   if(current?.is_active===false)throw Error('Akses ERP akun ini dinonaktifkan.');
   if(write){
    await db.query(`INSERT INTO profiles(id,email,full_name,is_active) VALUES($1,$2,$3,true) ON CONFLICT(id) DO NOTHING`,[session.adminId,session.email,session.name]);
    if(central(session.role))await db.query(`INSERT INTO user_scopes(user_id,company_id) SELECT $1,$2 WHERE NOT EXISTS(SELECT 1 FROM user_scopes WHERE user_id=$1 AND company_id=$2 AND branch_id IS NULL AND warehouse_id IS NULL)`,[session.adminId,session.companyId]);
   }
   const scopes=(await db.query('SELECT DISTINCT branch_id FROM user_scopes WHERE user_id=$1 AND company_id=$2 AND branch_id IS NOT NULL',[session.adminId,session.companyId])).rows;
   const identity:Identity={companyId:session.companyId,adminId:session.adminId,role:session.role,branchIds:central(session.role)?null:scopes.map(r=>String(r.branch_id))};
   const output=await contexts.run({db,identity,write},()=>work(db,identity));
   if(write)await db.query(`INSERT INTO audit_logs(company_id,user_id,action,entity) VALUES($1,$2,$3,'erp')`,[identity.companyId,identity.adminId,action]);
   await db.query('COMMIT');return output;
  }catch(error){await db.query('ROLLBACK').catch(()=>{});throw error}finally{db.release()}
 }
 const transaction:Transaction=(work,write)=>run(work,write);
 return {client:createErpClient(schema,allowed,transaction),transaction,
  write:<T>(work:()=>Promise<T>,action='erp.transaction')=>run(()=>work(),true,action),
  formAction:async <T>(action:string,form:FormData,work:()=>Promise<T>):Promise<T>=>{
   const key=String(form.get('_operationId')||'');
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(key))throw Error('Muat ulang formulir sebelum menyimpan.');
   const entries=[...form.entries()].filter(([k])=>k!=='_operationId'&&!k.startsWith('$ACTION_')).sort(([a,av],[b,bv])=>a.localeCompare(b)||String(av).localeCompare(String(bv)));
   if(entries.some(([,v])=>typeof v!=='string'))throw Error('Formulir berkas belum didukung.');
   const hash=createHash('sha256').update(JSON.stringify(entries)).digest('hex');
   return run(async(db,identity)=>{
    const prior=(await db.query('SELECT action,payload_hash,result FROM erp_operation_receipts WHERE company_id=$1 AND admin_id=$2 AND operation_id=$3',[identity.companyId,identity.adminId,key])).rows[0];
    if(prior){if(prior.action!==action||prior.payload_hash!==hash)throw Error('Kunci operasi telah dipakai dengan data berbeda.');return (prior.result===null?undefined:prior.result) as T}
    const result=await work();
    await db.query('INSERT INTO erp_operation_receipts(company_id,admin_id,operation_id,action,payload_hash,result)VALUES($1,$2,$3,$4,$5,$6)',[identity.companyId,identity.adminId,key,action,hash,result===undefined?null:JSON.stringify(result)]);
    return result;
   },true,action);
  },
  read:<T>(work:(db:Database,identity:Identity)=>Promise<T>)=>run(work,false)};
}
