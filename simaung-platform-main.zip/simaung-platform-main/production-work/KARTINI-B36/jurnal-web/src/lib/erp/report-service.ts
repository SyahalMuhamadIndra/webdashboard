import {cents,amount} from './money';
import type {createErpStore} from './store';
type Store=ReturnType<typeof createErpStore>;
export function createSupplementalReports(store:Store){
 async function all(query:()=>any){
  const rows:any[]=[];
  for(let offset=0;offset<400000;offset+=2000){const page=await query().order('id').range(offset,offset+1999);rows.push(...page.data);if(page.data.length<2000)return rows;}
  throw Error('Laporan terlalu besar; persempit rentang tanggal.');
 }
 const verify=(company:string,identity:{companyId:string})=>{if(company!==identity.companyId)throw Error('Perusahaan tidak diizinkan.');};
 async function lines(company:string,from?:string,to?:string){
  return store.read(async(_db,user)=>{
   verify(company,user);
   const rows=await all(()=>{
    let q=store.client.from('journal_lines').select('account_id,debit,credit,branch_id,journal_entries!inner(entry_date,company_id,is_posted)').eq('journal_entries.is_posted',true);
    if(from)q=q.gte('journal_entries.entry_date',from);
    if(to)q=q.lte('journal_entries.entry_date',to);
    return q;
   });
   return rows.map((r:any)=>({account_id:r.account_id,debit:Number(r.debit),credit:Number(r.credit),entry_date:r.journal_entries.entry_date,company_id:user.companyId,branch_id:r.branch_id}));
  });
 }
 async function budget(company:string,year:number){
  if(!Number.isInteger(year)||year<1900||year>9999)throw Error('Tahun tidak valid.');
  return store.read(async(_db,user)=>{
   verify(company,user);
   const budgets=(await store.client.from('budgets').select('*').eq('fiscal_year',year).eq('is_active',true)).data;
   if(budgets.length>1)throw Error('Lebih dari satu anggaran aktif untuk tahun ini.');
   const selected=budgets[0]||null;
   if(!selected)return {budget:null,rows:[],totalBudget:0,totalActual:0,variance:0};
   const items=(await store.client.from('budget_items').select('account_id,amount,accounts!inner(code,name,type_of_account!inner(normal_balance))').eq('budget_id',selected.id)).data;
   const movements=await lines(company,`${year}-01-01`,`${year}-12-31`);
   const actual=new Map<string,bigint>();
   for(const line of movements)actual.set(line.account_id,(actual.get(line.account_id)||0n)+cents(line.debit)-cents(line.credit));
   const grouped=new Map<string,{accountId:string;code:string;name:string;budget:bigint;actual:bigint}>();
   for(const item of items){const row=grouped.get(item.account_id)||{accountId:item.account_id,code:item.accounts.code,name:item.accounts.name,budget:0n,actual:(actual.get(item.account_id)||0n)*(item.accounts.type_of_account.normal_balance==='credit'?-1n:1n)};row.budget+=cents(item.amount);grouped.set(item.account_id,row)}
   let totalBudget=0n,totalActual=0n;
   const rows=[...grouped.values()].sort((a,b)=>a.code.localeCompare(b.code)).map(row=>{totalBudget+=row.budget;totalActual+=row.actual;return {...row,budget:amount(row.budget),actual:amount(row.actual),variance:amount(row.actual-row.budget),variancePct:row.budget===0n?0:Number((row.actual-row.budget)*10000n/row.budget)/100}});
   return {budget:{id:selected.id,name:selected.name,fiscal_year:selected.fiscal_year},rows,totalBudget:amount(totalBudget),totalActual:amount(totalActual),variance:amount(totalActual-totalBudget)};
  });
 }
 async function forecast(company:string,today=new Date().toISOString().slice(0,10)){
  return store.read(async(_db,user)=>{
   verify(company,user);
   const accounts=(await store.client.from('accounts').select('id,is_cash,is_bank')).data;
   const cashIds=new Set(accounts.filter((a:any)=>a.is_cash||a.is_bank).map((a:any)=>a.id));
   const movements=await lines(company,undefined,today);
   const cash=movements.filter((line:any)=>cashIds.has(line.account_id)).reduce((sum:bigint,line:any)=>sum+cents(line.debit)-cents(line.credit),0n);
   const receivables=await all(()=>store.client.from('receivables').select('*').eq('status','posted'));
   const payables=await all(()=>store.client.from('payables').select('*').eq('status','posted'));
   const due=(rows:any[],days:number):bigint=>rows.filter(r=>r.due_date&&r.due_date<=new Date(Date.parse(today+'T00:00:00Z')+days*86400000).toISOString().slice(0,10)).reduce<bigint>((sum,r)=>sum+(cents(r.original_amount)>cents(r.paid_amount)?cents(r.original_amount)-cents(r.paid_amount):0n),0n);
   const buckets=[30,60,90].map(days=>{const inflow=due(receivables,days),outflow=due(payables,days);return {days,label:`${days} hari`,inflow:amount(inflow),outflow:amount(outflow),net:amount(inflow-outflow),balance:amount(cash+inflow-outflow)}});
   const ar=due(receivables,90),ap=due(payables,90);
   return {cashBalance:amount(cash),arInflow:amount(ar),apOutflow:amount(ap),netFuture:amount(ar-ap),projected:amount(cash+ar-ap),buckets};
  });
 }
 return {lines,budget,forecast};
}
