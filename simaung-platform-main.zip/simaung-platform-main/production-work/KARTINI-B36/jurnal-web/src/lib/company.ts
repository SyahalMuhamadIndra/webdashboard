import { getSession } from './session';

export async function getDefaultCompany(): Promise<CompanyInfo> {
  const session = await getSession();
  if (!session?.companyId) throw new Error('Silakan masuk kembali.');
  return {
    id: session.companyId,
    code: 'KARTINI',
    name: session.companyName || 'Simaung Corporation',
    base_currency: 'IDR',
    timezone: 'Asia/Jakarta',
  };
}

export interface CompanyInfo {
  id: string;
  code: string;
  name: string;
  base_currency: string;
  timezone: string;
}
