import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';

// ============================================================
// Treasury: Bank & Cash accounts (tabel sudah ada di schema)
// Modul kas/bank ala Odoo. Fitur ringan, tanpa migration baru.
// ============================================================

export async function listBankAccounts(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('bank_accounts')
    .select('*, accounts(code, name)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) throw new Error(error.message);
  return (data || []) as any[];
}

export async function createBankAccount(
  companyId: string,
  input: {
    bank_name: string;
    account_number?: string;
    account_name?: string;
    currency?: string;
    opening_balance?: number;
    account_id?: string;
    is_active?: boolean;
  }
) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data, error } = await s
    .from('bank_accounts')
    .insert({
      company_id: companyId,
      bank_name: input.bank_name,
      account_number: input.account_number || null,
      account_name: input.account_name || null,
      currency: input.currency || 'IDR',
      opening_balance: Number(input.opening_balance || 0),
      account_id: input.account_id || null,
      is_active: input.is_active ?? true,
    })
    .select('id')
    .single();
  if (error || !data) throw new Error(error?.message || 'Gagal membuat rekening bank.');
  return { id: data.id as string };

  }, 'createBankAccount');
}

export async function listCashAccounts(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('cash_accounts')
    .select('*')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) throw new Error(error.message);
  return (data || []) as any[];
}

export async function createCashAccount(
  companyId: string,
  input: { name: string; currency?: string; opening_balance?: number; is_active?: boolean }
) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data, error } = await s
    .from('cash_accounts')
    .insert({
      company_id: companyId,
      name: input.name,
      currency: input.currency || 'IDR',
      opening_balance: Number(input.opening_balance || 0),
      is_active: input.is_active ?? true,
    })
    .select('id')
    .single();
  if (error || !data) throw new Error(error?.message || 'Gagal membuat kas.');
  return { id: data.id as string };

  }, 'createCashAccount');
}
