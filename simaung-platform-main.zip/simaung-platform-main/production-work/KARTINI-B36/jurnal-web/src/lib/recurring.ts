import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';
import { createInvoiceAndPost } from './odoo';

// ============================================================
// Recurring Invoice / Subscription engine (migration 0003)
// Membuat invoice periodik otomatis (mingguan/bulanan/tahunan).
// ============================================================

export async function listRecurring(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('recurring_invoices')
    .select('*, customers(name, code), recurring_invoice_items(*)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) throw new Error(error.message);
  return (data || []) as any[];
}

export async function createRecurring(
  companyId: string,
  input: {
    customer_id?: string;
    description?: string;
    interval_type?: string;
    start_date?: string;
    next_run_date?: string;
    end_date?: string;
    auto_post?: boolean;
    lines: { product_id?: string; description?: string; quantity: number; unit_price: number; discount?: number; tax_rate_id?: string }[];
  }
) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const interval = input.interval_type || 'monthly';
  const start = input.start_date || today();
  const lines = input.lines.map((l: any) => ({
    ...l,
    line_total: (+l.quantity || 0) * (+l.unit_price || 0) * (1 - (+(l.discount ?? 0) || 0) / 100),
  }));

  const { data: rec, error } = await s
    .from('recurring_invoices')
    .insert({
      company_id: companyId,
      customer_id: input.customer_id || null,
      description: input.description || 'Langganan',
      interval_type: interval,
      start_date: start,
      next_run_date: input.next_run_date || start,
      end_date: input.end_date || null,
      auto_post: input.auto_post ?? true,
      is_active: true,
    })
    .select('id')
    .single();
  if (error || !rec) throw new Error(error?.message || 'Gagal membuat langganan.');
  await s.from('recurring_invoice_items').insert(lines.map((l: any) => ({ recurring_invoice_id: rec.id, ...l })));
  return { id: rec.id as string };

  }, 'createRecurring');
}

function today(offset = 0) {
  return new Date(Date.now() + offset * 86400000).toISOString().slice(0, 10);
}

function addInterval(dateStr: string, interval: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d.getTime())) return today(1);
  if (interval === 'weekly') d.setDate(d.getDate() + 7);
  else if (interval === 'monthly') d.setMonth(d.getMonth() + 1);
  else if (interval === 'yearly') d.setFullYear(d.getFullYear() + 1);
  else if (interval === 'daily') d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

// Proses semua langganan aktif yang jatuh tempo; buat invoice & geser next_run_date.
// Aman dipanggil on-demand (dari halaman) maupun via cron eksternal.
export async function processDueRecurring(companyId: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const todayIso = today();
  const { data: due, error } = await s
    .from('recurring_invoices')
    .select('*, recurring_invoice_items(*)')
    .eq('company_id', companyId)
    .eq('is_active', true)
    .lte('next_run_date', todayIso);
  if (error) throw new Error(error.message);

  let processed = 0;
  for (const rec of (due || []) as any[]) {
    // End date reached → deactivate
    if (rec.end_date && rec.end_date <= todayIso) {
      await s.from('recurring_invoices').update({ is_active: false }).eq('id', rec.id);
      continue;
    }
    if (!rec.customer_id) {
      // skip & deactivate if no customer
      await s.from('recurring_invoices').update({ is_active: false }).eq('id', rec.id);
      continue;
    }
    const items = (rec.recurring_invoice_items || []).map((l: any) => ({
      product_id: l.product_id,
      description: l.description || 'Item langganan',
      quantity: Number(l.quantity) || 0,
      unit_price: Number(l.unit_price) || 0,
      discount: Number(l.discount) || 0,
      tax_rate_id: l.tax_rate_id || undefined,
    }));
    await createInvoiceAndPost(companyId, {
      customer_id: rec.customer_id,
      invoice_date: todayIso,
      due_date: today(30),
      items,
    });
    const nextRun = addInterval(rec.next_run_date, rec.interval_type);
    await s
      .from('recurring_invoices')
      .update({ last_run_date: todayIso, next_run_date: nextRun })
      .eq('id', rec.id);
    processed++;
  }
  return { processed };

  }, 'processDueRecurring');
}

export async function deactivateRecurring(recurringId: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { error } = await s.from('recurring_invoices').update({ is_active: false }).eq('id', recurringId);
  if (error) throw new Error(error.message);

  }, 'deactivateRecurring');
}
