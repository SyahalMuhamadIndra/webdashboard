// Legacy modules must never report a successful save or an empty financial
// result when their storage adapter has not been connected.
export class DataUnavailableError extends Error {
  readonly code = 'DATA_UNAVAILABLE';
  constructor() { super('Layanan data belum tersedia. Silakan hubungi pengelola.'); }
}

export function makeSupabaseStub(): any {
  let proxy: any;
  const unavailable = async () => { throw new DataUnavailableError(); };
  proxy = new Proxy(function () {}, {
    get(_target, property) {
      if (property === 'then') {
        return (resolve: (value: unknown) => unknown, reject: (reason: unknown) => unknown) =>
          Promise.reject(new DataUnavailableError()).then(resolve, reject);
      }
      if (property === 'single' || property === 'maybeSingle') return unavailable;
      if (property === 'auth') return {
        getUser: unavailable, getSession: unavailable, signInWithPassword: unavailable,
        signUp: unavailable, signOut: unavailable,
        onAuthStateChange: () => ({ data: { subscription: { unsubscribe() {} } } }),
      };
      return () => proxy;
    },
  });
  return proxy;
}
