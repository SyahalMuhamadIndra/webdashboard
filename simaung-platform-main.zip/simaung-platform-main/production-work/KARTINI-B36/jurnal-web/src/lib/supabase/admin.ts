import 'server-only';
import {erp} from '../erp/runtime';
/** Scoped, authenticated PostgreSQL client. Never uses a shared service identity. */
export function createAdminClient(){return erp().client;}
