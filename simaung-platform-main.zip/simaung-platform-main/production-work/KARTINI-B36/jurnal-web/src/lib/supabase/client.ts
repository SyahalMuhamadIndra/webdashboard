import { makeSupabaseStub } from './stub';

// Browser Supabase client — dinonaktifkan pada arsitektur TERPADU.
// Data & auth diselesaikan di backend bersama (api.tokokartini.com).
export function createClient() {
  return makeSupabaseStub();
}
