import { makeSupabaseStub } from './stub';

// Server Supabase client — dinonaktifkan pada arsitektur TERPADU.
// Data & auth diselesaikan di backend bersama (api.tokokartini.com).
// Mengembalikan stub (empty-state) agar halaman tetap render.
export async function createClient() {
  return makeSupabaseStub();
}
