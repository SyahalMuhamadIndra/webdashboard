import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';
import { postJournalEntry } from './journal';
import { depreciationPosting, round2 } from './accounting';

// ============================================================
// LAPORAN KARTINI — Finance modules
// Aging (AR/AP), PPN (VAT) report, depreciation auto-posting,
// and CSV export helpers.
// ============================================================

export interface AgingBucket {
  label: string;
  amount: number;
  count: number;
}

export interface AgingRow {
  id: string;
  partnerName: string;
  refNumber: string;
  dueDate: string | null;
  daysOverdue: number;
  openAmount: number;
  bucketIndex: number;
}

export interface AgingResult {
  rows: AgingRow[];
  buckets: AgingBucket[];
  totalOpen: number;
}

const AGING_BUCKETS = [
  { label: 'Belum Jatuh Tempo', test: (d: number) => d <= 0 },
  { label: '1–30 hari', test: (d: number) => d >= 1 && d <= 30 },
  { label: '31–60 hari', test: (d: number) => d >= 31 && d <= 60 },
  { label: '61–90 hari', test: (d: number) => d >= 61 && d <= 90 },
  { label: '> 90 hari', test: (d: number) => d > 90 },
];

function daysBetween(from: string, to: string): number {
  const a = new Date(from).getTime();
  const b = new Date(to).getTime();
  return Math.ceil((b - a) / 86400000);
}

function buildAging(
  records: any[],
  partnerField: string,
  refField: string,
  todayIso: string
): AgingResult {
  const rows: AgingRow[] = [];
  for (const r of records) {
    const open = round2(Number(r.original_amount) - Number(r.paid_amount || 0));
    if (open <= 0) continue;
    const due = r.due_date || null;
    const days = due ? Math.max(0, daysBetween(due, todayIso)) : 0;
    let bucketIndex = 0;
    for (let i = 0; i < AGING_BUCKETS.length; i++) {
      if (AGING_BUCKETS[i].test(days)) { bucketIndex = i; break; }
      if (i === 0 && days > 0) continue;
    }
    rows.push({
      id: r.id,
      partnerName: r[partnerField]?.name || '-',
      refNumber: r[refField] || '-',
      dueDate: due,
      daysOverdue: days,
      openAmount: open,
      bucketIndex,
    });
  }

  const buckets: AgingBucket[] = AGING_BUCKETS.map((b, i) => ({
    label: b.label,
    amount: round2(rows.filter((r) => r.bucketIndex === i).reduce((s, r) => s + r.openAmount, 0)),
    count: rows.filter((r) => r.bucketIndex === i).length,
  }));

  const totalOpen = round2(rows.reduce((s, r) => s + r.openAmount, 0));
  return { rows, buckets, totalOpen };
}

// ---- AR Aging ----
export async function getReceivableAging(companyId: string): Promise<AgingResult> {
  const s = createAdminClient();
  const { data, error } = await s
    .from('receivables')
    .select('id, original_amount, paid_amount, due_date, status, customers(name), invoices(invoice_number)')
    .eq('company_id', companyId);
  if (error) throw new Error(`Gagal memuat piutang: ${error.message}`);
  return buildAging(data || [], 'customers', 'invoices?.invoice_number', todayISO());
}

// ---- AP Aging ----
export async function getPayableAging(companyId: string): Promise<AgingResult> {
  const s = createAdminClient();
  const { data, error } = await s
    .from('payables')
    .select('id, original_amount, paid_amount, due_date, status, suppliers(name), bills(bill_number)')
    .eq('company_id', companyId);
  if (error) throw new Error(`Gagal memuat hutang: ${error.message}`);
  return buildAging(data || [], 'suppliers', 'bills?.bill_number', todayISO());
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);

  }

// ============================================================
// PPN (VAT) report — from posted journal lines on tax accounts
// ============================================================
export interface PpnRow {
  code: string;
  name: string;
  collect: number; // PPN Keluaran (credit on is_collected_tax)
  input: number;   // PPN Masukan (debit on is_paid_tax)
}

export async function getPpnReport(companyId: string, from: string, to: string) {
  const s = createAdminClient();
  const { data: accounts, error: aErr } = await s
    .from('accounts')
    .select('id, code, name, is_collected_tax, is_paid_tax')
    .eq('company_id', companyId);
  if (aErr) throw new Error(`Gagal memuat akun pajak: ${aErr.message}`);

  const taxAccounts = (accounts || []).filter((a: any) => a.is_collected_tax || a.is_paid_tax);
  const taxIds = taxAccounts.map((a: any) => a.id);
  if (taxIds.length === 0) {
    return { rows: [], totalCollect: 0, totalInput: 0, netPayable: 0 };
  }

  const { data: lines, error: lErr } = await s
    .from('journal_lines')
    .select('account_id, debit, credit, journal_entries!inner(entry_date, is_posted, company_id)')
    .in('account_id', taxIds)
    .eq('journal_entries.company_id', companyId)
    .eq('journal_entries.is_posted', true)
    .gte('journal_entries.entry_date', from)
    .lte('journal_entries.entry_date', to);
  if (lErr) throw new Error(`Gagal memuat jurnal pajak: ${lErr.message}`);

  const agg: Record<string, { collect: number; input: number }> = {};
  for (const l of lines || []) {
    if (!agg[l.account_id]) agg[l.account_id] = { collect: 0, input: 0 };
    agg[l.account_id].collect += Number(l.credit) || 0;
    agg[l.account_id].input += Number(l.debit) || 0;
  }

  const rows: PpnRow[] = taxAccounts.map((a: any) => ({
    code: a.code,
    name: a.name,
    collect: round2(agg[a.id]?.collect || 0),
    input: round2(agg[a.id]?.input || 0),
  })).filter((r: PpnRow) => r.collect !== 0 || r.input !== 0);

  const totalCollect = round2(rows.reduce((s: number, r: PpnRow) => s + r.collect, 0));
  const totalInput = round2(rows.reduce((s: number, r: PpnRow) => s + r.input, 0));
  return { rows, totalCollect, totalInput, netPayable: round2(totalCollect - totalInput) };
}

// ============================================================
// Auto depreciation posting
// ============================================================
export async function postDepreciation(
  companyId: string,
  asset: any,
  periodLabel: string,
  entryDate: string,
  createdBy?: string
) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const life = Number(asset.useful_life_months) || 60;
  const cost = Number(asset.acquisition_cost) || 0;
  const salvage = Number(asset.salvage_value) || 0;
  const lifeMonths = Math.max(life, 1);
  let amount = 0;
  if (asset.depreciation_method === 'declining') {
    const annualRate = 2 / lifeMonths;
    amount = round2((cost - salvage) * annualRate / 12);
  } else {
    amount = round2((cost - salvage) / lifeMonths);
  }
  if (amount <= 0) throw new Error('Nilai penyusutan 0 atau aset sudah habis disusutkan.');

  // Resolve accounts (depreciation expense + accumulated depreciation)
  let expAcct = asset.expense_account_id;
  let accumAcct = asset.accum_dep_account_id;
  if (!expAcct || !accumAcct) {
    const { data: accs } = await s.from('accounts')
      .select('id, code, is_depreciation, is_accum_depreciation')
      .eq('company_id', companyId);
    expAcct = expAcct || (accs || []).find((a: any) => a.is_depreciation)?.id || (accs || []).find((a: any) => a.code === '5-3000')?.id;
    accumAcct = accumAcct || (accs || []).find((a: any) => a.is_accum_depreciation)?.id || (accs || []).find((a: any) => a.code === '1-2100')?.id;
  }
  if (!expAcct || !accumAcct) throw new Error('Akun beban penyusutan / akumulasi tidak ditemukan.');

  const lines = depreciationPosting({ expenseAccountId: expAcct, accumDepAccountId: accumAcct, amount });
  const result = await postJournalEntry({
    companyId,
    entryDate,
    memo: `Penyusutan ${asset.name} — ${periodLabel}`,
    source: 'depreciation',
    referenceType: 'fixed_asset',
    referenceId: asset.id,
    lines,
    createdBy,
  });

  const newAccum = round2((Number(asset.accumulated_depreciation) || 0) + amount);
  const newNbv = round2((Number(asset.acquisition_cost) || 0) - newAccum);
  await s.from('fixed_assets').update({
    accumulated_depreciation: newAccum,
    net_book_value: newNbv,
  }).eq('id', asset.id);

  await s.from('depreciation_entries').insert({
    company_id: companyId,
    asset_id: asset.id,
    journal_entry_id: result.entryId,
    amount,
    period_label: periodLabel,
    entry_date: entryDate,
  });

  return { entryId: result.entryId, amount, assetId: asset.id };

  }, 'postDepreciation');
}

// ============================================================
// CSV export helper
// ============================================================
export {toCSV} from './csv';
