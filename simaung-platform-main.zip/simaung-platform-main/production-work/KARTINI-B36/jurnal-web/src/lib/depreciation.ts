import { listFixedAssets } from './odoo';

// ============================================================
// Depreciation schedule (Jadwal Penyusutan) — compute-only.
// Memakai tabel existing (fixed_assets) tanpa migration baru.
// Perhitungan: straight-line & double-declining.
// ============================================================

export interface DepItem {
  monthIndex: number; // 1-based
  label: string;
  amount: number;
  runningBook: number;
}

export interface DepAsset {
  id: string;
  code: string;
  name: string;
  category: string | null;
  cost: number;
  salvage: number;
  lifeMonths: number;
  method: string;
  monthlyDep: number;
  remaining: number;
  endBook: number;
  schedule: DepItem[];
}

export function buildDepreciationSchedule(
  assets: any[],
  maxPeriods = 12
): DepAsset[] {
  return assets.map((a) => {
    const cost = Number(a.acquisition_cost || 0);
    const salvage = Number(a.salvage_value || 0);
    const life = Number(a.useful_life_months || 1);
    const method = a.depreciation_method || 'straight_line';
    const depreciable = cost - salvage;

    let monthlyDep = 0;
    if (method === 'declining') {
      // Double declining balance: rate = 2 / life, applied to remaining book.
      monthlyDep = life > 0 ? round2((depreciable * 2) / life / 1) : 0;
    } else {
      monthlyDep = life > 0 ? round2(depreciable / life) : 0;
    }

    // Build a capped schedule (first N months) for display.
    let book = cost;
    const schedule: DepItem[] = [];
    for (let i = 1; i <= Math.min(life, maxPeriods); i++) {
      let amount = monthlyDep;
      if (method === 'declining') {
        amount = round2((book - salvage) * (2 / life));
        if (amount < 0) amount = 0;
      }
      const after = round2(Math.max(book - amount, salvage));
      schedule.push({ monthIndex: i, label: `Bulan ${i}`, amount, runningBook: after });
      book = after;
    }

    return {
      id: a.id,
      code: a.code,
      name: a.name,
      category: a.category || null,
      cost,
      salvage,
      lifeMonths: life,
      method,
      monthlyDep,
      remaining: round2(Math.max(cost - salvage, 0)),
      endBook: round2(schedule.length ? schedule[schedule.length - 1].runningBook : cost),
      schedule,
    };
  });
}

export async function listDepreciationSchedule(companyId: string, maxPeriods = 12) {
  const assets = await listFixedAssets(companyId);
  return buildDepreciationSchedule(assets, maxPeriods);
}

function round2(n: number) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}
