import {erp} from './erp/runtime';
import {createStockService} from './erp/stock-service';
import {calculateDocument} from './erp/document-totals';
import {cents, decimal} from './erp/money';
import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';
import { postJournalEntry } from './journal';
import {
  salesInvoicePosting,
  purchaseBillPosting,
  customerPaymentPosting,
  supplierPaymentPosting,
  expensePosting,
  depreciationPosting,
  round2,
} from './accounting';

// ============================================================
// LAPORAN KARTINI — Modul Odoo (data layer + posting helpers)
// Master data + transaksi bisnis (invoice/bill/payment/asset/stock)
// yang menghasilkan jurnal otomatis (double-entry).
// ============================================================

// ---- Generic list fetchers -------------------------------------------------

export async function listAccounts(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('accounts')
    .select('id, code, name, is_header, is_active, is_cash, is_bank, is_receivable, is_payable, is_inventory, type_of_account!inner(normal_balance, name, report_section)')
    .eq('company_id', companyId)
    .order('code');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listTypeOfAccount(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('type_of_account')
    .select('*')
    .eq('company_id', companyId)
    .order('sort_order');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listCustomers(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('customers')
    .select('*')
    .eq('company_id', companyId)
    .order('name');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listSuppliers(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('suppliers')
    .select('*')
    .eq('company_id', companyId)
    .order('name');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listProducts(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('products')
    .select('*, units(name, code), categories(name)')
    .eq('company_id', companyId)
    .order('name');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listUnits(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('units')
    .select('*')
    .eq('company_id', companyId)
    .order('code');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listTaxRates(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('tax_rates')
    .select('*')
    .eq('company_id', companyId)
    .order('name');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listCategories(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('categories')
    .select('*')
    .eq('company_id', companyId)
    .order('name');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listInvoices(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('invoices')
    .select('*, customers(name, code), invoice_items(*)')
    .eq('company_id', companyId)
    .order('invoice_date', { ascending: false });
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listBills(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('bills')
    .select('*, suppliers(name, code), bill_items(*)')
    .eq('company_id', companyId)
    .order('bill_date', { ascending: false });
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listReceivables(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('receivables')
    .select('*, customers(name, code), invoices(invoice_number)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listPayables(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('payables')
    .select('*, suppliers(name, code), bills(bill_number)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listLocations(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('warehouses')
    .select('*')
    .eq('company_id', companyId)
    .order('code');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listBranches(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('branches')
    .select('*')
    .eq('company_id', companyId)
    .order('code');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listStockBalance(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('stock_balances')
    .select('*, products(name, sku), warehouses(name)')
    .eq('company_id', companyId)
    .order('updated_at', { ascending: false });
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listFixedAssets(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('fixed_assets')
    .select('*')
    .eq('company_id', companyId)
    .order('code');
  if (error) throw new Error(error.message);
  return data as any[];
}

export async function listPayments(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('payments')
    .select('*, customers(name), suppliers(name), payment_methods(name)')
    .eq('company_id', companyId)
    .order('payment_date', { ascending: false });
  if (error) throw new Error(error.message);
  return data as any[];
}

// ---- Next sequence number -------------------------------------------------

async function nextNumber(s: any, table: string, companyId: string, field: string, prefix: string) {
  const pattern = `${prefix}%`;
  const { data, error } = await s
    .from(table)
    .select(field)
    .eq('company_id', companyId)
    .ilike(field, pattern);
  if (error) throw new Error(error.message);
  let max = 0;
  for (const row of data || []) {
    const n = parseInt(String(row[field]).replace(prefix, ''), 10);
    if (!isNaN(n) && n > max) max = n;
  }
  return `${prefix}${max + 1}`;
}

// ---- Master data inserters ------------------------------------------------

export async function createAccount(companyId: string, input: {
  code: string; name: string; type_of_account_id: string; is_header?: boolean;
  is_cash?: boolean; is_bank?: boolean; is_receivable?: boolean; is_payable?: boolean;
  is_inventory?: boolean; is_active?: boolean; description?: string;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data, error } = await s.from('accounts').insert({
    company_id: companyId,
    code: input.code,
    name: input.name,
    type_of_account_id: input.type_of_account_id,
    is_header: input.is_header ?? false,
    is_cash: input.is_cash ?? false,
    is_bank: input.is_bank ?? false,
    is_receivable: input.is_receivable ?? false,
    is_payable: input.is_payable ?? false,
    is_inventory: input.is_inventory ?? false,
    is_active: input.is_active ?? true,
    description: input.description ?? null,
  }).select('id').single();
  if (error) throw new Error(error.message);
  return data;

  }, 'createAccount');
}

export async function createCustomer(companyId: string, input: {
  code?: string; name: string; customer_type?: string; tax_id?: string; phone?: string;
  email?: string; address?: string; credit_limit?: number; term_days?: number;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const code = input.code || await nextNumber(s, 'customers', companyId, 'code', 'CUS-');
  const { data, error } = await s.from('customers').insert({
    company_id: companyId,
    code,
    name: input.name,
    customer_type: input.customer_type ?? 'customer',
    tax_id: input.tax_id ?? null,
    phone: input.phone ?? null,
    email: input.email ?? null,
    address: input.address ?? null,
    credit_limit: input.credit_limit ?? 0,
    term_days: input.term_days ?? 0,
    is_active: true,
  }).select('id').single();
  if (error) throw new Error(error.message);
  return data;

  }, 'createCustomer');
}

export async function createSupplier(companyId: string, input: {
  code?: string; name: string; tax_id?: string; phone?: string; email?: string;
  address?: string; term_days?: number;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const code = input.code || await nextNumber(s, 'suppliers', companyId, 'code', 'SUP-');
  const { data, error } = await s.from('suppliers').insert({
    company_id: companyId,
    code,
    name: input.name,
    tax_id: input.tax_id ?? null,
    phone: input.phone ?? null,
    email: input.email ?? null,
    address: input.address ?? null,
    term_days: input.term_days ?? 0,
    is_active: true,
  }).select('id').single();
  if (error) throw new Error(error.message);
  return data;

  }, 'createSupplier');
}

export async function createProduct(companyId: string, input: {
  sku?: string; name: string; category_id?: string; unit_id?: string; description?: string;
  cost_method?: string; is_track_inventory?: boolean; barcode?: string;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const sku = input.sku || await nextNumber(s, 'products', companyId, 'sku', 'SKU-');
  const { data, error } = await s.from('products').insert({
    company_id: companyId,
    sku,
    name: input.name,
    category_id: input.category_id ?? null,
    unit_id: input.unit_id ?? null,
    description: input.description ?? null,
    cost_method: input.cost_method ?? 'average',
    is_track_inventory: input.is_track_inventory ?? true,
    barcode: input.barcode ?? null,
    is_active: true,
  }).select('id').single();
  if (error) throw new Error(error.message);
  return data;

  }, 'createProduct');
}

// ---- Sales invoice posting -------------------------------------------------

export async function createInvoiceAndPost(companyId: string, input: {
  customer_id: string;
  invoice_date: string;
  due_date?: string;
  items: { product_id?: string; description: string; quantity: number; unit_price: number; discount?: number; tax_rate_id?: string }[];
  is_cash_sale?: boolean;
  payment_account_id?: string;
  created_by?: string;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();

  // Default accounts (from COA)
  const { data: accs } = await s.from('accounts').select('id, code, name, is_cash, is_bank, is_receivable').eq('company_id', companyId);
  const accMap = (accs || []).map((a: any) => ({ ...a }) );
  const receivable = (accs || []).find((a: any) => a.is_receivable) || (accs || []).find((a: any) => a.code === '1-1100');
  const revenue = (accs || []).find((a: any) => a.code === '4-1000');
  const cogs = (accs || []).find((a: any) => a.code === '5-1000');
  const inventory = (accs || []).find((a: any) => a.is_inventory) || (accs || []).find((a: any) => a.code === '1-1200');
  const outputTax = (accs || []).find((a: any) => a.code === '2-1100');
  const cashPayment = (accs || []).find((a: any) => a.is_cash || a.is_bank || a.code === '1-1000');
  const paymentAccount = input.payment_account_id
    ? (accs || []).find((a: any) => a.id === input.payment_account_id)
    : input.is_cash_sale ? cashPayment : receivable;
  if(input.is_cash_sale && (!paymentAccount || (!paymentAccount.is_cash && !paymentAccount.is_bank))) throw new Error('Akun kas/bank wajib dipilih untuk penjualan tunai.');

  if (!receivable || !revenue) throw new Error('Akun Piutang/Pendapatan tidak ditemukan. Isi Chart of Accounts dulu.');

  // Compute line totals & tax
  const calculation = await calculateDocument(input.items,async(id)=>{
    const rate=(await s.from('tax_rates').select('rate').eq('id',id).single()).data;
    if(!rate)throw new Error('Tarif pajak tidak ditemukan atau tidak diizinkan.');
    return Number(rate.rate);
  });
  const {subtotal,taxAmount,discountAmount,total}=calculation;
  const itemRows=input.items.map((item,index)=>({
    ...calculation.items[index],product_id:item.product_id??null,description:item.description,
    tax_rate_id:item.tax_rate_id??null,revenue_account_id: revenue.id, inventory_account_id: inventory?.id ?? null,
  }));

  const invoiceNumber = await nextNumber(s, 'invoices', companyId, 'invoice_number', 'INV-');
  const { data: invoice, error: invErr } = await s.from('invoices').insert({
    company_id: companyId,
    customer_id: input.customer_id,
    invoice_number: invoiceNumber,
    invoice_date: input.invoice_date,
    due_date: input.due_date ?? null,
    status: input.is_cash_sale ? 'paid' : 'posted',
    subtotal: round2(subtotal),
    tax_amount: round2(taxAmount),
    discount_amount: round2(discountAmount),
    total,
    created_by: input.created_by ?? null,
  }).select('id').single();
  if (invErr) throw new Error(invErr.message);

  const { error: itemsErr } = await s.from('invoice_items').insert(
    itemRows.map((r: any) => ({ ...r, invoice_id: invoice.id }))
  );
  if (itemsErr) throw new Error(itemsErr.message);

  // Post journal
  const journalLines = salesInvoicePosting({
    receivableAccountId: (paymentAccount || receivable).id,
    revenueAccountId: revenue.id,
    cogsAccountId: (cogs as any)?.id || revenue.id,
    inventoryAccountId: (inventory as any)?.id || revenue.id,
    outputTaxAccountId: taxAmount > 0 ? (outputTax as any)?.id : undefined,
    isCashSale: !!input.is_cash_sale,
    salesAmount: round2(subtotal),
    taxAmount: round2(taxAmount),
    cogsAmount: 0,
  });

  const result = await postJournalEntry({
    companyId,
    entryDate: input.invoice_date,
    memo: `Invoice ${invoiceNumber}`,
    source: 'sales_invoice',
    referenceType: 'invoice',
    referenceId: invoice.id,
    lines: journalLines,
    createdBy: input.created_by,
  });

  await s.from('invoices').update({ journal_entry_id: result.entryId }).eq('id', invoice.id);

  // Create receivable record
  if (!input.is_cash_sale) await s.from('receivables').insert({
    company_id: companyId,
    customer_id: input.customer_id,
    invoice_id: invoice.id,
    original_amount: total,
    paid_amount: 0,
    due_date: input.due_date ?? null,
    status: 'posted',
  });

  return { invoiceId: invoice.id as string, invoiceNumber };

  }, 'createInvoiceAndPost');
}

// ---- Purchase bill posting -------------------------------------------------

export async function createBillAndPost(companyId: string, input: {
  supplier_id: string;
  bill_date: string;
  due_date?: string;
  items: { product_id?: string; description: string; quantity: number; unit_price: number; discount?: number; tax_rate_id?: string }[];
  created_by?: string;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data: accs } = await s.from('accounts').select('id, code').eq('company_id', companyId);
  const payable = (accs || []).find((a: any) => a.code === '2-1000');
  const inventory = (accs || []).find((a: any) => a.code === '1-1200');
  const expense = (accs || []).find((a: any) => a.code === '5-2500');
  const inputTax = (accs || []).find((a: any) => a.code === '1-1300');
  if (!payable || !inventory) throw new Error('Akun Hutang/Persediaan tidak ditemukan.');

  const calculation = await calculateDocument(input.items,async(id)=>{
    const rate=(await s.from('tax_rates').select('rate').eq('id',id).single()).data;
    if(!rate)throw new Error('Tarif pajak tidak ditemukan atau tidak diizinkan.');
    return Number(rate.rate);
  });
  const {subtotal,taxAmount,discountAmount,total}=calculation;
  const itemRows=input.items.map((item,index)=>({
    ...calculation.items[index],product_id:item.product_id??null,description:item.description,
    tax_rate_id:item.tax_rate_id??null,expense_account_id: expense?.id ?? null, inventory_account_id: inventory.id,
  }));

  const billNumber = await nextNumber(s, 'bills', companyId, 'bill_number', 'BILL-');
  const { data: bill, error: billErr } = await s.from('bills').insert({
    company_id: companyId,
    supplier_id: input.supplier_id,
    bill_number: billNumber,
    bill_date: input.bill_date,
    due_date: input.due_date ?? null,
    status: 'posted',
    subtotal: round2(subtotal),
    tax_amount: round2(taxAmount),
    discount_amount: round2(discountAmount),
    total,
    created_by: input.created_by ?? null,
  }).select('id').single();
  if (billErr) throw new Error(billErr.message);

  const { error: itemsErr } = await s.from('bill_items').insert(
    itemRows.map((r: any) => ({ ...r, bill_id: bill.id }))
  );
  if (itemsErr) throw new Error(itemsErr.message);

  const journalLines = purchaseBillPosting({
    payableAccountId: payable.id,
    inventoryAccountId: inventory.id,
    expenseAccountId: (expense as any)?.id,
    inputTaxAccountId: taxAmount > 0 ? (inputTax as any)?.id : undefined,
    inventoryAmount: round2(subtotal),
    expenseAmount: 0,
    taxAmount: round2(taxAmount),
  });

  const result = await postJournalEntry({
    companyId,
    entryDate: input.bill_date,
    memo: `Bill ${billNumber}`,
    source: 'purchase_bill',
    referenceType: 'bill',
    referenceId: bill.id,
    lines: journalLines,
    createdBy: input.created_by,
  });

  await s.from('bills').update({ journal_entry_id: result.entryId }).eq('id', bill.id);

  await s.from('payables').insert({
    company_id: companyId,
    supplier_id: input.supplier_id,
    bill_id: bill.id,
    original_amount: total,
    paid_amount: 0,
    due_date: input.due_date ?? null,
    status: 'posted',
  });

  return { billId: bill.id as string, billNumber };

  }, 'createBillAndPost');
}

// ---- Customer / supplier payment ------------------------------------------

export async function createCustomerPayment(companyId: string, input: {
  customer_id: string; amount: number; payment_date: string;
  payment_method_id?: string; receivable_id?: string; created_by?: string;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const paymentCents = cents(input.amount);
  if (paymentCents <= 0n) throw new Error('Nominal pembayaran harus lebih dari nol.');
  let obligation: any = null;
  if (input.receivable_id) {
    const result = await s.from('receivables').select('*').eq('id', input.receivable_id).single();
    obligation = result.data;
    if (!obligation || obligation.customer_id !== input.customer_id || obligation.status !== 'posted') throw new Error('Tagihan tidak ditemukan, bukan milik pihak ini, atau sudah ditutup.');
    if (paymentCents > cents(obligation.original_amount) - cents(obligation.paid_amount)) throw new Error('Pembayaran melebihi sisa tagihan.');
  }

  const { data: accs } = await s.from('accounts').select('id, code, is_cash, is_bank, is_receivable, is_payable').eq('company_id', companyId);
  const cash = (accs || []).find((a: any) => a.code === '1-1000' || a.is_cash);
  const receivable = (accs || []).find((a: any) => a.is_receivable) || (accs || []).find((a: any) => a.code === '1-1100');
  if (!cash || !receivable) throw new Error('Akun Kas/Piutang tidak ditemukan.');

  const paymentNumber = await nextNumber(s, 'payments', companyId, 'payment_number', 'PAY-');
  const { data: payment, error: payErr } = await s.from('payments').insert({
    company_id: companyId,
    direction: 'in',
    customer_id: input.customer_id,
    payment_number: paymentNumber,
    payment_date: input.payment_date,
    payment_method_id: input.payment_method_id ?? null,
    amount: round2(input.amount),
    status: 'posted',
    created_by: input.created_by ?? null,
  }).select('id').single();
  if (payErr) throw new Error(payErr.message);

  const journalLines = customerPaymentPosting({ cashAccountId: cash.id, receivableAccountId: receivable.id, amount: input.amount });
  const result = await postJournalEntry({
    companyId, entryDate: input.payment_date, memo: `Pembayaran ${paymentNumber}`,
    source: 'customer_payment', referenceType: 'payment', referenceId: payment.id,
    lines: journalLines, createdBy: input.created_by,
  });
  await s.from('payments').update({ journal_entry_id: result.entryId }).eq('id', payment.id);

  // Allocate & reduce receivable
  if (input.receivable_id) {
    const recv = obligation;
    if (recv) {
      const newPaid = Number(decimal(cents(recv.paid_amount) + paymentCents));
      await s.from('receivables').update({ paid_amount: newPaid, status: newPaid >= recv.original_amount ? 'paid' : 'posted' }).eq('id', recv.id);
      await s.from('payment_allocations').insert({ payment_id: payment.id, invoice_id: recv.invoice_id ?? null, amount: round2(input.amount) });
      if (recv.invoice_id) await s.from('invoices').update({ status: newPaid >= recv.original_amount ? 'paid' : 'posted' }).eq('id', recv.invoice_id);
    }
  }

  return { paymentId: payment.id as string, paymentNumber };

  }, 'createCustomerPayment');
}

export async function createSupplierPayment(companyId: string, input: {
  supplier_id: string; amount: number; payment_date: string;
  payment_method_id?: string; payable_id?: string; created_by?: string;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const paymentCents = cents(input.amount);
  if (paymentCents <= 0n) throw new Error('Nominal pembayaran harus lebih dari nol.');
  let obligation: any = null;
  if (input.payable_id) {
    const result = await s.from('payables').select('*').eq('id', input.payable_id).single();
    obligation = result.data;
    if (!obligation || obligation.supplier_id !== input.supplier_id || obligation.status !== 'posted') throw new Error('Tagihan tidak ditemukan, bukan milik pihak ini, atau sudah ditutup.');
    if (paymentCents > cents(obligation.original_amount) - cents(obligation.paid_amount)) throw new Error('Pembayaran melebihi sisa tagihan.');
  }

  const { data: accs } = await s.from('accounts').select('id, code, is_cash, is_bank, is_receivable, is_payable').eq('company_id', companyId);
  const cash = (accs || []).find((a: any) => a.code === '1-1000' || a.is_cash);
  const payable = (accs || []).find((a: any) => a.code === '2-1000' || a.is_payable);
  if (!cash || !payable) throw new Error('Akun Kas/Hutang tidak ditemukan.');

  const paymentNumber = await nextNumber(s, 'payments', companyId, 'payment_number', 'PAY-');
  const { data: payment, error: payErr } = await s.from('payments').insert({
    company_id: companyId,
    direction: 'out',
    supplier_id: input.supplier_id,
    payment_number: paymentNumber,
    payment_date: input.payment_date,
    payment_method_id: input.payment_method_id ?? null,
    amount: round2(input.amount),
    status: 'posted',
    created_by: input.created_by ?? null,
  }).select('id').single();
  if (payErr) throw new Error(payErr.message);

  const journalLines = supplierPaymentPosting({ payableAccountId: payable.id, cashAccountId: cash.id, amount: input.amount });
  const result = await postJournalEntry({
    companyId, entryDate: input.payment_date, memo: `Pembayaran ${paymentNumber}`,
    source: 'supplier_payment', referenceType: 'payment', referenceId: payment.id,
    lines: journalLines, createdBy: input.created_by,
  });
  await s.from('payments').update({ journal_entry_id: result.entryId }).eq('id', payment.id);

  if (input.payable_id) {
    const pay = obligation;
    if (pay) {
      const newPaid = Number(decimal(cents(pay.paid_amount) + paymentCents));
      await s.from('payables').update({ paid_amount: newPaid, status: newPaid >= pay.original_amount ? 'paid' : 'posted' }).eq('id', pay.id);
      await s.from('payment_allocations').insert({ payment_id: payment.id, bill_id: pay.bill_id ?? null, amount: round2(input.amount) });
      if (pay.bill_id) await s.from('bills').update({ status: newPaid >= pay.original_amount ? 'paid' : 'posted' }).eq('id', pay.bill_id);
    }
  }

  return { paymentId: payment.id as string, paymentNumber };

  }, 'createSupplierPayment');
}

// ---- Fixed asset ----------------------------------------------------------

export async function createFixedAsset(companyId: string, input: {
  code?: string; name: string; category?: string; acquisition_date: string;
  acquisition_cost: number; salvage_value?: number; useful_life_months?: number;
  depreciation_method?: string; created_by?: string;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const code = input.code || await nextNumber(s, 'fixed_assets', companyId, 'code', 'FA-');
  const method = input.depreciation_method || 'straight_line';
  const life = input.useful_life_months || 60;
  const salvage = input.salvage_value || 0;
  const cost = Number(input.acquisition_cost) || 0;
  const annualDep = method === 'straight_line' ? round2((cost - salvage) / Math.max(life, 1) * 12) : 0;

  // NOTE: the `fixed_assets` table has NO `created_by` column — do not insert it.
  const { data: asset, error } = await s.from('fixed_assets').insert({
    company_id: companyId,
    code,
    name: input.name,
    category: input.category ?? null,
    acquisition_date: input.acquisition_date,
    acquisition_cost: cost,
    salvage_value: salvage,
    useful_life_months: life,
    depreciation_method: method,
    accumulated_depreciation: 0,
    net_book_value: cost,
    status: 'active',
  }).select('id').single();
  if (error) throw new Error(error.message);
  return { assetId: asset.id as string, code };

  }, 'createFixedAsset');
}

// ---- Expense --------------------------------------------------------------

export async function createExpense(companyId: string, input: {
  expense_date: string; amount: number; memo?: string;
  expense_account_id: string; payment_account_id?: string; created_by?: string;
}) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data: accs } = await s.from('accounts').select('id, code').eq('company_id', companyId);
  const cash = (accs || []).find((a: any) => a.code === '1-1000' || a.is_cash || a.is_bank);
  const paymentAccount = input.payment_account_id || (cash as any)?.id;
  if (!paymentAccount) throw new Error('Akun pembayaran tidak ditemukan.');

  const journalLines = expensePosting({
    expenseAccountId: input.expense_account_id,
    paymentAccountId: paymentAccount,
    amount: input.amount,
  });
  const result = await postJournalEntry({
    companyId, entryDate: input.expense_date, memo: input.memo || 'Beban',
    source: 'expense', lines: journalLines, createdBy: input.created_by,
  });
  return result;

  }, 'createExpense');
}

// ---- Payments / Deposit helpers are exported above. ------------------------
// ---- Stock adjustment (write-off) -----------------------------------------

export async function createStockAdjustment(companyId: string, input: {
  product_id: string; warehouse_id: string; quantity: number; unit_cost?: number; memo?: string; created_by?: string;
}) {
  return withErpTransaction(async () => {
  return createStockService(erp()).adjust(companyId,input);

  }, 'createStockAdjustment');
}
