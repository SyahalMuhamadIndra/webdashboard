// ============================================================
// LAPORAN KARTINI — Accounting Engine
// Core: all financial reports derive from double-entry journaling.
// This module defines account conventions and posting rules that
// convert business transactions into balanced journal entries.
// ============================================================

export type BalanceSide = 'debit' | 'credit';

export interface JournalLine {
  accountId: string;
  debit: number;
  credit: number;
  branchId?: string | null;
  description?: string;
}

export interface JournalEntryInput {
  companyId: string;
  entryDate: string; // YYYY-MM-DD
  memo?: string;
  source: JournalSource;
  referenceType?: string;
  referenceId?: string;
  branchId?: string | null;
  lines: JournalLine[];
  fiscalPeriodId?: string;
  createdBy?: string;
  idempotencyKey?: string;
}

export type JournalSource =
  | 'manual'
  | 'sales_invoice'
  | 'purchase_bill'
  | 'customer_payment'
  | 'supplier_payment'
  | 'expense'
  | 'depreciation'
  | 'stock_adjustment'
  | 'bank_reconciliation'
  | 'opening_balance'
  | 'sales_return'
  | 'purchase_return'
  | 'deferred';

// --- Accounting invariant: total debit === total credit ---
export class AccountingError extends Error {}

export function validateBalance(lines: JournalLine[]): { debit: number; credit: number } {
  const debit = round2(lines.reduce((s, l) => s + (l.debit || 0), 0));
  const credit = round2(lines.reduce((s, l) => s + (l.credit || 0), 0));
  if (Math.abs(debit - credit) > 0.009) {
    throw new AccountingError(
      `Journal tidak balance: total debit ${debit.toFixed(2)} ≠ total kredit ${credit.toFixed(2)}`
    );
  }
  return { debit, credit };
}

// --- Numeric helpers ---
export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

// --- Account classification tags ---
export interface AccountFlags {
  isCash?: boolean;
  isBank?: boolean;
  isReceivable?: boolean;
  isPayable?: boolean;
  isInventory?: boolean;
  isPaidTax?: boolean;      // PPN Masukan
  isCollectedTax?: boolean; // PPN Keluaran
  isDepreciation?: boolean;
  isAccumDepreciation?: boolean;
  isRetainedEarnings?: boolean;
}

export const AccountTypeName = {
  asset: 'Aktiva',
  liability: 'Liabilitas',
  equity: 'Ekuitas',
  revenue: 'Pendapatan',
  expense: 'Beban',
} as const;

// ============================================================
// POSTING RULES — convert a business transaction into journal lines
// ============================================================

// Sales invoice:    AR/receivable (debit) -> Revenue (credit), + tax,
//                   and inventory:  COGS (debit) -> Inventory (credit)
export interface SalesInvoicePostingInput {
  receivableAccountId: string;      // Piutang Usaha / Kas/Bank for cash sale
  revenueAccountId: string;         // Penjualan
  cogsAccountId: string;            // HPP
  inventoryAccountId: string;       // Persediaan
  outputTaxAccountId?: string;      // PPN Keluaran
  isCashSale: boolean;
  salesAmount: number;              // net after discount, before tax
  taxAmount: number;
  cogsAmount: number;               // cost of goods sold (inventory decrease)
}

export function salesInvoicePosting(p: SalesInvoicePostingInput): JournalLine[] {
  const total = round2(p.salesAmount + p.taxAmount);
  const lines: JournalLine[] = [];
  // DR receivable/cash for the total billed
  lines.push({
    accountId: p.receivableAccountId,
    debit: total,
    credit: 0,
    description: 'Penjualan (total tagihan)',
  });
  // CR revenue (net)
  lines.push({
    accountId: p.revenueAccountId,
    debit: 0,
    credit: round2(p.salesAmount),
    description: 'Pendapatan penjualan',
  });
  // CR output tax
  if (p.outputTaxAccountId && p.taxAmount > 0) {
    lines.push({
      accountId: p.outputTaxAccountId,
      debit: 0,
      credit: round2(p.taxAmount),
      description: 'PPN Keluaran',
    });
  }
  // Inventory: DR COGS, CR Inventory (if not cash & inventory tracked)
  if (!p.isCashSale && p.cogsAmount > 0) {
    lines.push({
      accountId: p.cogsAccountId,
      debit: round2(p.cogsAmount),
      credit: 0,
      description: 'Harga Pokok Penjualan',
    });
    lines.push({
      accountId: p.inventoryAccountId,
      debit: 0,
      credit: round2(p.cogsAmount),
      description: 'Pengurangan persediaan',
    });
  }
  validateBalance(lines);
  return lines;
}

// Purchase bill: Inventory/Expense (debit) + input tax (debit) -> AP (credit)
export function purchaseBillPosting(p: {
  payableAccountId: string;
  inventoryAccountId: string;
  expenseAccountId?: string;
  inputTaxAccountId?: string;
  inventoryAmount: number;
  expenseAmount: number;
  taxAmount: number;
}): JournalLine[] {
  const total = round2(p.inventoryAmount + p.expenseAmount + p.taxAmount);
  const lines: JournalLine[] = [];
  if (p.inventoryAmount > 0) {
    lines.push({
      accountId: p.inventoryAccountId,
      debit: round2(p.inventoryAmount),
      credit: 0,
      description: 'Pembelian persediaan',
    });
  }
  if (p.expenseAmount > 0 && p.expenseAccountId) {
    lines.push({
      accountId: p.expenseAccountId,
      debit: round2(p.expenseAmount),
      credit: 0,
      description: 'Beban pembelian',
    });
  }
  if (p.taxAmount > 0 && p.inputTaxAccountId) {
    lines.push({
      accountId: p.inputTaxAccountId,
      debit: round2(p.taxAmount),
      credit: 0,
      description: 'PPN Masukan',
    });
  }
  lines.push({
    accountId: p.payableAccountId,
    debit: 0,
    credit: total,
    description: 'Hutang Usaha',
  });
  validateBalance(lines);
  return lines;
}

// Customer payment: Cash/Bank (debit) -> AR (credit)
export function customerPaymentPosting(p: {
  cashAccountId: string;
  receivableAccountId: string;
  amount: number;
}): JournalLine[] {
  const lines: JournalLine[] = [
    {
      accountId: p.cashAccountId,
      debit: round2(p.amount),
      credit: 0,
      description: 'Penerimaan pembayaran',
    },
    {
      accountId: p.receivableAccountId,
      debit: 0,
      credit: round2(p.amount),
      description: 'Pelunasan piutang',
    },
  ];
  validateBalance(lines);
  return lines;
}

// Supplier payment: AP (debit) -> Cash/Bank (credit)
export function supplierPaymentPosting(p: {
  payableAccountId: string;
  cashAccountId: string;
  amount: number;
}): JournalLine[] {
  const lines: JournalLine[] = [
    {
      accountId: p.payableAccountId,
      debit: round2(p.amount),
      credit: 0,
      description: 'Pelunasan hutang',
    },
    {
      accountId: p.cashAccountId,
      debit: 0,
      credit: round2(p.amount),
      description: 'Pembayaran ke supplier',
    },
  ];
  validateBalance(lines);
  return lines;
}

// Expense: Expense (debit) -> Cash/AP (credit)
export function expensePosting(p: {
  expenseAccountId: string;
  paymentAccountId: string;
  amount: number;
}): JournalLine[] {
  const lines: JournalLine[] = [
    {
      accountId: p.expenseAccountId,
      debit: round2(p.amount),
      credit: 0,
      description: 'Beban',
    },
    {
      accountId: p.paymentAccountId,
      debit: 0,
      credit: round2(p.amount),
      description: 'Pembayaran beban',
    },
  ];
  validateBalance(lines);
  return lines;
}

// Depreciation: Depreciation expense (debit) -> Accumulated depreciation (credit)
export function depreciationPosting(p: {
  expenseAccountId: string;
  accumDepAccountId: string;
  amount: number;
}): JournalLine[] {
  const lines: JournalLine[] = [
    {
      accountId: p.expenseAccountId,
      debit: round2(p.amount),
      credit: 0,
      description: 'Beban penyusutan',
    },
    {
      accountId: p.accumDepAccountId,
      debit: 0,
      credit: round2(p.amount),
      description: 'Akumulasi penyusutan',
    },
  ];
  validateBalance(lines);
  return lines;
}

// ============================================================
// REPORT BUILDERS — derive financial reports from journal lines
// ============================================================

export interface ReportAccountRow {
  code: string;
  name: string;
  type: string;          // type_of_account name
  normalBalance: BalanceSide;
  opening: number;       // signed per normal side
  debit: number;
  credit: number;
  net: number;
}

export interface TrialBalanceResult {
  rows: ReportAccountRow[];
  totalDebit: number;
  totalCredit: number;
  balanced: boolean;
}

// Recalculate a single account's signed balance from lines.
// Each line carries accountId, debit, credit. Returns signed balance
// where + is the "normal" direction (debit-normal accounts -> debit-credit;
// credit-normal accounts -> credit-debit).
export function balanceFromLines(
  lines: { accountId: string; debit: number; credit: number }[],
  accountMap: Record<string, { normalBalance: BalanceSide }>
): number {
  const agg: Record<string, { debit: number; credit: number }> = {};
  for (const l of lines) {
    if (!agg[l.accountId]) agg[l.accountId] = { debit: 0, credit: 0 };
    agg[l.accountId].debit += l.debit || 0;
    agg[l.accountId].credit += l.credit || 0;
  }
  let signed = 0;
  for (const accId of Object.keys(agg)) {
    const nb = accountMap[accId]?.normalBalance ?? 'debit';
    const net = agg[accId].debit - agg[accId].credit;
    signed += nb === 'debit' ? net : -net;
  }
  return round2(signed);
}

// Convert raw journal line aggregates into a trial balance.
export function buildTrialBalance(params: {
  lines: { accountId: string; debit: number; credit: number }[];
  accounts: { id: string; code: string; name: string; type: string; normalBalance: BalanceSide }[];
}): TrialBalanceResult {
  const accountMap: Record<string, { normalBalance: BalanceSide }> = {};
  for (const a of params.accounts) accountMap[a.id] = { normalBalance: a.normalBalance };

  const agg: Record<string, { debit: number; credit: number }> = {};
  for (const l of params.lines) {
    if (!agg[l.accountId]) agg[l.accountId] = { debit: 0, credit: 0 };
    agg[l.accountId].debit += l.debit || 0;
    agg[l.accountId].credit += l.credit || 0;
  }

  const rows: ReportAccountRow[] = params.accounts
    .filter((a) => agg[a.id])
    .map((a) => {
      const d = round2(agg[a.id]?.debit || 0);
      const c = round2(agg[a.id]?.credit || 0);
      const net = round2(a.normalBalance === 'debit' ? d - c : c - d);
      return {
        code: a.code,
        name: a.name,
        type: a.type,
        normalBalance: a.normalBalance,
        opening: 0,
        debit: d,
        credit: c,
        net,
      };
    });

  const totalDebit = round2(rows.reduce((s, r) => s + r.debit, 0));
  const totalCredit = round2(rows.reduce((s, r) => s + r.credit, 0));
  return {
    rows,
    totalDebit,
    totalCredit,
    balanced: Math.abs(totalDebit - totalCredit) < 0.009,
  };
}
