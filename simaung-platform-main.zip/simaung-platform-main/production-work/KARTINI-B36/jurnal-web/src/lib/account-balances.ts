import { createAdminClient } from './supabase/admin';
import { listAccounts } from './odoo';

// ============================================================
// Account Balances per Period — read-only report.
// Memakai tabel existing (account_balances) tanpa migration baru.
// Query dipisah (tidak pakai embed PostgREST) agar aman.
// ============================================================

export interface PeriodRow {
  id: string;
  name: string;
  fiscal_year: number;
  month: number | null;
  is_closed: boolean;
}

export async function listFiscalPeriods(companyId: string): Promise<PeriodRow[]> {
  const s = createAdminClient();
  const { data, error } = await s
    .from('fiscal_periods')
    .select('id, name, fiscal_year, month, is_closed')
    .eq('company_id', companyId)
    .order('fiscal_year', { ascending: false })
    .order('month', { ascending: false })
    .limit(24);
  if (error) throw new Error(error.message);
  return (data || []) as PeriodRow[];
}

export async function listAccountBalances(companyId: string, periodId?: string | null) {
  const s = createAdminClient();
  let query = s
    .from('account_balances')
    .select('*')
    .eq('company_id', companyId);
  if (periodId) query = query.eq('fiscal_period_id', periodId);
  const { data, error } = await query.limit(1000);
  if (error) throw new Error(error.message);

  // Map akun (nama + kode) secara terpisah — hindari embed yang rawan error.
  const accounts = await listAccounts(companyId);
  const acctMap = new Map<string, { code: string; name: string }>();
  for (const a of accounts) acctMap.set(a.id, { code: a.code, name: a.name });

  return ((data || []) as any[])
    .map((b) => {
      const acc = acctMap.get(b.account_id) || { code: '-', name: '-' };
      return {
        ...b,
        account_code: acc.code,
        account_name: acc.name,
      };
    })
    .sort((x: any, y: any) => x.account_code.localeCompare(y.account_code));
}
