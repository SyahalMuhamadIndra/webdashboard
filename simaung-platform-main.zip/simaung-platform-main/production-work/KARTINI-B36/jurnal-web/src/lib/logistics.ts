import {erp} from './erp/runtime';
import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';

// ============================================================
// Logistics: stock movements, branches, project tasks.
// Semua memakai tabel yang sudah ada di schema (tanpa migration baru).
// ============================================================

// ---- Stock movements (riwayat mutasi stok) ---------------------------------
export async function listStockMovements(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('stock_movements')
    .select('*, products(name, sku), warehouses(name, code)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(300);
  if (error) throw new Error(error.message);
  return (data || []) as any[];
}

// ---- Branches (cabang) -----------------------------------------------------
export async function createBranch(
  companyId: string,
  input: { code: string; name: string; address?: string; phone?: string; email?: string }
) {
  return withErpTransaction(async () => {
  return erp().transaction(async(db,user)=>{
    if(user.companyId!==companyId||!['SUPERADMIN','DEV'].includes(user.role.toUpperCase()))throw Error('Akses pengelola diperlukan.');
    const code=input.code.trim().toUpperCase(),name=input.name.trim();
    if(!/^[A-Z0-9_-]{1,24}$/.test(code)||!name||name.length>120)throw Error('Kode atau nama cabang tidak valid.');
    const branch=(await db.query('INSERT INTO branches(company_id,code,name,address,phone,email)VALUES($1,$2,$3,$4,$5,$6)RETURNING id',[companyId,code,name,input.address||null,input.phone||null,input.email||null])).rows[0];
    const warehouse=(await db.query('INSERT INTO warehouses(company_id,branch_id,code,name)VALUES($1,$2,$3,$4)RETURNING id',[companyId,branch.id,code+'-MAIN','Gudang '+name])).rows[0];
    await db.query('INSERT INTO ops_branch_config(company_id,branch_id,warehouse_id)VALUES($1,$2,$3)',[companyId,branch.id,warehouse.id]);
    return {id:String(branch.id)};
  },true);

  }, 'createBranch');
}

// ---- Project tasks ---------------------------------------------------------
export async function listProjectTasks(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('project_tasks')
    .select('*, projects(name)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(300);
  if (error) throw new Error(error.message);
  return (data || []) as any[];
}

export async function createProjectTask(
  companyId: string,
  input: { project_id?: string; title: string; status?: string; priority?: string; due_date?: string }
) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data, error } = await s
    .from('project_tasks')
    .insert({
      company_id: companyId,
      project_id: input.project_id || null,
      title: input.title,
      status: input.status || 'todo',
      priority: input.priority || 'normal',
      due_date: input.due_date || null,
    })
    .select('id')
    .single();
  if (error || !data) throw new Error(error?.message || 'Gagal membuat tugas.');
  return { id: data.id as string };

  }, 'createProjectTask');
}

export async function updateTaskStatus(taskId: string, status: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { error } = await s.from('project_tasks').update({ status }).eq('id', taskId);
  if (error) throw new Error(error.message);

  }, 'updateTaskStatus');
}
