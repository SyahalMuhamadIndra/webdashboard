import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';
import { postJournalEntry } from './journal';
import { round2 } from './accounting';

// ============================================================
// Deferred Revenue & Expense engine (migration 0004-0006)
// Mengakui pendapatan/beban ditangguhkan secara periodik ala Odoo.
// Satu entri mencatat "kolam" jumlah yang belum diakui; proses
// pengakuan mem-posting jurnal amortisasi ke akun tujuan.
// ============================================================

const DEFERRED_REVENUE_ACC = '2-1250'; // Pendapatan Ditangguhkan (liabilitas, credit-normal)
const DEFERRED_EXPENSE_ACC = '1-1250'; // Beban Dibayar Dimuka (aktiva, debit-normal)

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function addInterval(dateStr: string, interval: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d.getTime())) return dateStr;
  if (interval === 'weekly') d.setDate(d.getDate() + 7);
  else if (interval === 'monthly') d.setMonth(d.getMonth() + 1);
  else if (interval === 'yearly') d.setFullYear(d.getFullYear() + 1);
  else if (interval === 'daily') d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

function monthsBetween(a: string, b: string): number {
  const da = new Date(a + 'T00:00:00');
  const db = new Date(b + 'T00:00:00');
  return (db.getFullYear() - da.getFullYear()) * 12 + (db.getMonth() - da.getMonth());
}

// Total periode pengakuan (inclusive) antara start_date dan end_date.
function totalPeriods(start: string, end: string, interval: string): number {
  if (interval === 'monthly') return Math.max(1, monthsBetween(start, end) + 1);
  if (interval === 'yearly') return Math.max(1, new Date(end).getFullYear() - new Date(start).getFullYear() + 1);
  if (interval === 'weekly') {
    const diff = Math.ceil((+new Date(end) - +new Date(start)) / (7 * 86400000));
    return Math.max(1, diff + 1);
  }
  const diff = Math.ceil((+new Date(end) - +new Date(start)) / 86400000);
  return Math.max(1, diff + 1);
}

// Cari akun berdasarkan kode dalam chart of accounts perusahaan.
async function findAccounts(companyId: string) {
  const s = createAdminClient();
  const { data: accs, error } = await s
    .from('accounts')
    .select('id, code, name')
    .eq('company_id', companyId);
  if (error) throw new Error(error.message);
  const map = (accs || []).reduce((m: any, a: any) => ({ ...m, [a.code]: a.id }), {});
  return map as Record<string, string>;
}

export async function listDeferred(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('deferred_entries')
    .select('*')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) throw new Error(error.message);
  return (data || []) as any[];
}

export async function createDeferred(
  companyId: string,
  input: {
    kind?: 'revenue' | 'expense';
    source?: string;
    source_id?: string;
    ref_number?: string;
    total_amount: number;
    start_date: string;
    end_date: string;
    interval_type?: string;
    target_account_id?: string;
  }
) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const kind = input.kind || 'revenue';
  const interval = input.interval_type || 'monthly';
  const start = input.start_date || todayIso();
  const end = input.end_date || start;
  const { data: entry, error } = await s
    .from('deferred_entries')
    .insert({
      company_id: companyId,
      kind,
      source: input.source || (kind === 'revenue' ? 'invoice' : 'bill'),
      source_id: input.source_id || null,
      ref_number: input.ref_number || null,
      total_amount: round2(input.total_amount),
      recognized_amount: 0,
      start_date: start,
      end_date: end,
      next_recognition: start,
      interval_type: interval,
      target_account_id: input.target_account_id || null,
      is_active: true,
    })
    .select('id')
    .single();
  if (error || !entry) throw new Error(error?.message || 'Gagal membuat entri ditangguhkan.');
  return { id: entry.id as string };

  }, 'createDeferred');
}

// Proses semua entri aktif yang jatuh tempo pengakuan (next_recognition <= hari ini).
// Mem-posting jurnal amortisasi & memajukan next_recognition. Aman dipanggil on-demand.
export async function recognizeDueDeferred(companyId: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const today = todayIso();
  const { data: due, error } = await s
    .from('deferred_entries')
    .select('*')
    .eq('company_id', companyId)
    .eq('is_active', true)
    .lte('next_recognition', today);
  if (error) throw new Error(error.message);

  const accMap = await findAccounts(companyId);
  const deferredRevenueAcc = accMap[DEFERRED_REVENUE_ACC];
  const deferredExpenseAcc = accMap[DEFERRED_EXPENSE_ACC];

  let processed = 0;
  for (const entry of (due || []) as any[]) {
    // Sudah penuh → nonaktifkan
    if ((Number(entry.recognized_amount) || 0) >= (Number(entry.total_amount) || 0)) {
      await s.from('deferred_entries').update({ is_active: false }).eq('id', entry.id);
      continue;
    }

    let amount: number;
    // Sisa periode sampai end_date (inclusive)
    const periodsLeft = totalPeriods(entry.next_recognition, entry.end_date, entry.interval_type);
    const remaining = round2((Number(entry.total_amount) || 0) - (Number(entry.recognized_amount) || 0));
    if (periodsLeft <= 1) amount = remaining; // periode terakhir → selesaikan
    else amount = Math.min(remaining, round2((Number(entry.total_amount) || 0) / totalPeriods((entry as any).start_date, (entry as any).end_date, entry.interval_type)));

    if (amount <= 0) {
      await s.from('deferred_entries').update({ is_active: false }).eq('id', entry.id);
      continue;
    }

    let lines: { accountId: string; debit: number; credit: number; description: string }[] = [];
    if (entry.kind === 'expense') {
      const target = entry.target_account_id || accMap['5-2000'];
      if (!target || !deferredExpenseAcc) throw new Error('Akun beban ditangguhkan tidak ditemukan.');
      // DR Beban (target) -> CR Beban Dibayar Dimuka
      lines = [
        { accountId: target, debit: amount, credit: 0, description: `Pengakuan beban ditangguhkan ${entry.ref_number ?? ''}`.trim() },
        { accountId: deferredExpenseAcc, debit: 0, credit: amount, description: 'Amortisasi beban dibayar dimuka' },
      ];
    } else {
      const target = entry.target_account_id || accMap['4-1000'];
      if (!target || !deferredRevenueAcc) throw new Error('Akun pendapatan ditangguhkan tidak ditemukan.');
      // DR Pendapatan Ditangguhkan -> CR Pendapatan (target)
      lines = [
        { accountId: deferredRevenueAcc, debit: amount, credit: 0, description: 'Amortisasi pendapatan ditangguhkan' },
        { accountId: target, debit: 0, credit: amount, description: `Pengakuan pendapatan ditangguhkan ${entry.ref_number ?? ''}`.trim() },
      ];
    }

    const result = await postJournalEntry({
      companyId,
      entryDate: today,
      memo: `Pengakuan ${entry.kind === 'expense' ? 'beban' : 'pendapatan'} ditangguhkan ${entry.ref_number ?? ''}`.trim(),
      source: 'deferred',
      referenceType: 'deferred',
      referenceId: entry.id,
      lines,
    });

    const newRecognized = round2((Number(entry.recognized_amount) || 0) + amount);
    const nextRec = addInterval(entry.next_recognition, entry.interval_type);
    await s
      .from('deferred_entries')
      .update({
        recognized_amount: newRecognized,
        next_recognition: nextRec,
        is_active: newRecognized < (Number(entry.total_amount) || 0),
      })
      .eq('id', entry.id);

    processed++;
  }
  return { processed };

  }, 'recognizeDueDeferred');
}

export async function deactivateDeferred(entryId: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { error } = await s.from('deferred_entries').update({ is_active: false }).eq('id', entryId);
  if (error) throw new Error(error.message);

  }, 'deactivateDeferred');
}
