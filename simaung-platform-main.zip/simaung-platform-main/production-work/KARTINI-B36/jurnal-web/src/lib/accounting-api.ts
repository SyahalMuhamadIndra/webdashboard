// ============================================================
// LAPORAN KARTINI — Unified Accounting API client
// Satu backend untuk SEMUA project: api.tokokartini.com
// (Neon Postgres — DB yang sama dengan aplikasi absensi & POS).
// ============================================================

const API_BASE =
  process.env.ACCOUNTING_API_BASE ||
  process.env.NEXT_PUBLIC_ACCOUNTING_API_BASE ||
  'https://api.tokokartini.com/api';

export interface ApiError extends Error {
  status?: number;
}

// Use the current user's server-only HttpOnly session, never a shared admin account.
async function currentToken(): Promise<string> {
  const { getSession } = await import('./session');
  const session = await getSession();
  if (!session?.backendToken) {
    const error: ApiError = new Error('Silakan masuk kembali.');
    error.status = 401;
    throw error;
  }
  return session.backendToken;
}

async function fetchWithRetry(buildRequest: (token: string) => Promise<Response>, _attempts = 1): Promise<Response> {
  // Writes are not automatically replayed: the server may already have committed.
  return buildRequest(await currentToken());
}

export async function accountingGet<T = any>(
  path: string,
  params?: Record<string, string | number | undefined>
): Promise<T> {
  const url = new URL(`${API_BASE}${path}`);
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && `${v}` !== '') url.searchParams.set(k, String(v));
    }
  }

  const res = await fetchWithRetry((token) =>
    fetch(url.toString(), {
      headers: { Authorization: `Bearer ${token}` },
      cache: 'no-store',
    })
  );
  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    const err: ApiError = new Error(
      `Request ${path} gagal (${res.status}): ${txt.slice(0, 300)}`
    );
    err.status = res.status;
    throw err;
  }
  return (await res.json()) as T;
}

export async function accountingPost<T = any>(
  path: string,
  body?: unknown
): Promise<T> {
  const publicAuth = path === '/admin/login' || path === '/admin/register';
  const token = publicAuth ? null : await currentToken();
  const res = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), 'Content-Type': 'application/json' },
    body: JSON.stringify(body ?? {}), cache: 'no-store', signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    const err: ApiError = new Error(
      `POST ${path} gagal (${res.status}): ${txt.slice(0, 300)}`
    );
    err.status = res.status;
    throw err;
  }
  return (await res.json()) as T;
}

export const API_BASE_URL = API_BASE;
