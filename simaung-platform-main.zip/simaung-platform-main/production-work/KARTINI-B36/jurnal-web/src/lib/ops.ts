import {withErpTransaction} from './erp/runtime';
import { createAdminClient } from './supabase/admin';

// ============================================================
// Operational services for tables that already exist in schema
// but have no UI yet. Lightweight server-side helpers only.
// ============================================================

// ---- Fiscal periods & closing -------------------------------------------
// Ensure fiscal periods exist for a year; closes one (posts a summing
// reversal to retained earnings is out of scope — we just lock it).
export async function ensureFiscalPeriods(companyId: string, year: number) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data: existing } = await s
    .from('fiscal_periods')
    .select('*')
    .eq('company_id', companyId)
    .eq('fiscal_year', year);

  if (!Number.isInteger(year) || year < 1900 || year > 9999) throw new Error('Tahun tidak valid.');

  const rows = Array.from({ length: 12 }, (_, i) => {
    const m = i + 1;
    const start = new Date(Date.UTC(year, m - 1, 1));
    const end = new Date(Date.UTC(year, m, 0));
    return {
      company_id: companyId,
      name: `Periode ${m} ${year}`,
      fiscal_year: year,
      month: m,
      start_date: start.toISOString().slice(0, 10),
      end_date: end.toISOString().slice(0, 10),
      is_closed: false,
    };
  }).filter(row => !(existing || []).some((period: any) => period.month === row.month));

  if (!rows.length) return existing;

  const { data, error } = await s.from('fiscal_periods').insert(rows).select('*');
  if (error) throw new Error(error.message);
  return data;

  }, 'ensureFiscalPeriods');
}

export async function closeFiscalPeriod(companyId: string, periodId: string, byUser?: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data, error } = await s
    .from('fiscal_periods')
    .update({ is_closed: true, closed_at: new Date().toISOString(), closed_by: byUser || null })
    .eq('id', periodId)
    .eq('company_id', companyId)
    .select('*')
    .single();
  if (error) throw new Error(error.message);
  return data;

  }, 'closeFiscalPeriod');
}

export async function listFiscalPeriods(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('fiscal_periods')
    .select('*')
    .eq('company_id', companyId)
    .order('fiscal_year', { ascending: false })
    .order('month', { ascending: true })
    .limit(120);
  if (error) throw new Error(error.message);
  return data || [];
}

// ---- Stock opname --------------------------------------------------------
export async function createStockOpname(companyId: string, warehouseId: string, opnameNumber: string, opnameDate: string, lines: { product_id: string; actual_qty: number }[]) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { data: op, error: opErr } = await s
    .from('stock_opnames')
    .insert({ company_id: companyId, warehouse_id: warehouseId, opname_number: opnameNumber, opname_date: opnameDate, status: 'draft' })
    .select('id')
    .single();
  if (opErr) throw new Error(opErr.message);

  const detail = lines.map((l) => ({ opname_id: op.id, product_id: l.product_id, actual_qty: l.actual_qty }));
  const { error: lineErr } = await s.from('stock_opname_lines').insert(detail);
  if (lineErr) throw new Error(lineErr.message);
  return op.id;

  }, 'createStockOpname');
}

export async function listStockOpnames(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s
    .from('stock_opnames')
    .select('*, warehouse:warehouses(name), stock_opname_lines(count)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) throw new Error(error.message);
  return data || [];
}

// ---- Notifications -------------------------------------------------------
export async function listNotifications(companyId: string, userId?: string) {
  const s = createAdminClient();
  let q = s.from('notifications').select('*').eq('company_id', companyId);
  if (userId) q = q.eq('user_id', userId);
  const { data, error } = await q.order('created_at', { ascending: false }).limit(50);
  if (error) throw new Error(error.message);
  return data || [];
}

export async function markNotificationRead(id: string) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  await s.from('notifications').update({ is_read: true }).eq('id', id);

  }, 'markNotificationRead');
}

// ---- Settings ------------------------------------------------------------
export async function listSettings(companyId: string) {
  const s = createAdminClient();
  const { data, error } = await s.from('settings').select('*').eq('company_id', companyId);
  if (error) throw new Error(error.message);
  return data || [];
}

export async function upsertSetting(companyId: string, key: string, value: unknown) {
  return withErpTransaction(async () => {
  const s = createAdminClient();
  const { error } = await s
    .from('settings')
    .upsert({ company_id: companyId, key, value }, { onConflict: 'company_id,key' });
  if (error) throw new Error(error.message);

  }, 'upsertSetting');
}
