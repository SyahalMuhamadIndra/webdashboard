import { type NextRequest, NextResponse } from 'next/server';

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
}

export async function middleware(request: NextRequest) {
  // This read-only diagnostic route independently verifies the private controller token.
  if (request.nextUrl.pathname === '/api/internal/readiness' && request.method === 'GET') return NextResponse.next();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  let enabled = true;
  let message = 'Status layanan belum dapat diperiksa. Silakan coba kembali.';
  let code = 'STATUS_UNAVAILABLE';
  try {
    const response = await fetch('https://api.tokokartini.com/api/maintenance/status', {
      cache: 'no-store', signal: controller.signal,
    });
    if (!response.ok) throw new Error('Status unavailable');
    const state = await response.json();
    if (typeof state.enabled !== 'boolean') throw new Error('Invalid status');
    enabled = state.enabled;
    message = String(state.message || 'Sistem sedang maintenance. Silakan coba kembali nanti.');
    code = 'MAINTENANCE';
  } catch { /* Fail closed, including server actions and old local API routes. */ }
  finally { clearTimeout(timeout); }
  if (!enabled) return NextResponse.next();
  const headers = { 'Cache-Control': 'no-store', 'Retry-After': '30' };
  if (request.nextUrl.pathname.startsWith('/api/') || request.method !== 'GET') {
    return NextResponse.json({code, message}, { status: 503, headers });
  }
  return new NextResponse(`<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Simaung Corporation • Status layanan</title></head><body style="margin:0;background:#102a23;color:#edf5f0;font:17px system-ui;display:grid;min-height:100vh;place-items:center;text-align:center"><main style="max-width:460px;padding:28px"><small>SIMAUNG CORPORATION</small><h1>${code === 'MAINTENANCE' ? 'Sedang maintenance' : 'Layanan belum dapat diperiksa'}</h1><p>${escapeHtml(message)}</p><button onclick="location.reload()" style="padding:14px 24px">Periksa kembali</button></main><script>setInterval(async()=>{try{const r=await fetch('https://api.tokokartini.com/api/maintenance/status',{cache:'no-store'});if(r.ok&&(await r.json()).enabled===false)location.reload();}catch{}},15000)</script></body></html>`, {
    status: 503, headers: {...headers, 'Content-Type': 'text/html; charset=utf-8'},
  });
}

export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|css|js|woff2?)$).*)'] };
