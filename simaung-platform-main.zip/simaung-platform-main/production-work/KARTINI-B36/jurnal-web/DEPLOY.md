# Deploy Jurnal Kartini

Status: integrasi akuntansi belum layak rilis penuh. Lihat KESIAPAN-JUAL-KARTINI.md di workspace.

- Login diverifikasi langsung melalui backend bersama. Cookie HttpOnly berisi token masing-masing pengguna yang ditandatangani dengan SESSION_SECRET minimal 32 karakter.
- Identitas dan hak akses diverifikasi ulang ke /api/admin/me. Tidak ada akun admin bersama atau password default dalam klien.
- SESSION_SECRET harus disimpan di environment produksi; jangan menyimpan kredensial di source.
- API seed dan migrasi web dinonaktifkan pada produksi. Migrasi produksi harus melalui prosedur terkontrol setelah backup dan uji restore.
- Endpoint /api/internal/readiness hanya membaca status tabel dan memerlukan token kontrol pemilik.
- Source ERP masih mempunyai stub data dan endpoint accounting belum lengkap. Build berhasil tidak membuktikan transaksi atau laporan siap dipakai.
- APK kontrol pribadi tidak boleh disertakan pada pusat unduhan publik.
