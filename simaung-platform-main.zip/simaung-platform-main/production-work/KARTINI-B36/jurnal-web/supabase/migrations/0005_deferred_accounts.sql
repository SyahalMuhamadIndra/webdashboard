-- ============================================================
-- LAPORAN KARTINI — Migration 0005: Deferred accounts
-- Menambahkan akun Pendapatan Ditangguhkan & Beban Dibayar Dimuka
-- beserta index pada tabel deferred_entries.
-- Idempotent (create/insert where not exists).
-- ============================================================

create extension if not exists "uuid-ossp";

-- Beban Dibayar Dimuka (Aktiva Lancar, normal balance debit)
insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '1-1250', 'Beban Dibayar Dimuka', t.id
from public.companies c
join public.type_of_account t on t.name = 'Aktiva' and t.company_id = c.id
where not exists (
  select 1 from public.accounts a where a.company_id = c.id and a.code = '1-1250'
);

-- Pendapatan Ditangguhkan (Liabilitas, normal balance credit)
insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '2-1250', 'Pendapatan Ditangguhkan', t.id
from public.companies c
join public.type_of_account t on t.name = 'Liabilitas' and t.company_id = c.id
where not exists (
  select 1 from public.accounts a where a.company_id = c.id and a.code = '2-1250'
);

-- Index untuk query pengakuan / pelaporan
create index if not exists idx_deferred_company on public.deferred_entries (company_id);
create index if not exists idx_deferred_next_recog on public.deferred_entries (company_id, is_active, next_recognition);
