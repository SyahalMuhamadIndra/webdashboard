-- ============================================================
-- LAPORAN KARTINI — Migration 0002: modul Odoo yang belum ada
-- Sales (quotation), Purchasing (PO), Inventory (delivery/
-- receipt/transfer), Currency & FX, Budget, CRM, Project,
-- Bank reconciliation. Semua idempotent.
-- ============================================================

create extension if not exists "uuid-ossp";

-- Quotation / Sales Order
create table if not exists public.quotations (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  quotation_number text not null,
  quotation_date date not null default current_date,
  valid_until date,
  status doc_status not null default 'draft',
  subtotal numeric(19,4) not null default 0,
  tax_amount numeric(19,4) not null default 0,
  total numeric(19,4) not null default 0,
  converted_invoice_id uuid references public.invoices(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, quotation_number)
);
create table if not exists public.quotation_lines (
  id uuid primary key default uuid_generate_v4(),
  quotation_id uuid not null references public.quotations(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  description text,
  quantity numeric(19,4) not null default 1,
  unit_price numeric(19,4) not null default 0,
  discount numeric(19,4) not null default 0,
  tax_rate_id uuid references public.tax_rates(id) on delete set null,
  line_total numeric(19,4) not null default 0
);

-- Purchase Order
create table if not exists public.purchase_orders (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  supplier_id uuid references public.suppliers(id) on delete set null,
  po_number text not null,
  po_date date not null default current_date,
  expected_date date,
  status doc_status not null default 'draft',
  subtotal numeric(19,4) not null default 0,
  tax_amount numeric(19,4) not null default 0,
  total numeric(19,4) not null default 0,
  converted_bill_id uuid references public.bills(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, po_number)
);
create table if not exists public.po_items (
  id uuid primary key default uuid_generate_v4(),
  po_id uuid not null references public.purchase_orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  description text,
  quantity numeric(19,4) not null default 1,
  unit_price numeric(19,4) not null default 0,
  tax_rate_id uuid references public.tax_rates(id) on delete set null,
  line_total numeric(19,4) not null default 0
);

-- Inventory: delivery, receipt, transfer (header + lines)
create table if not exists public.delivery_orders (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  warehouse_id uuid not null references public.warehouses(id),
  customer_id uuid references public.customers(id) on delete set null,
  delivery_number text not null,
  delivery_date date not null default current_date,
  status doc_status not null default 'draft',
  total numeric(19,4) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, delivery_number)
);
create table if not exists public.delivery_items (
  id uuid primary key default uuid_generate_v4(),
  delivery_id uuid not null references public.delivery_orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(19,4) not null default 0
);

create table if not exists public.goods_receipts (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  warehouse_id uuid not null references public.warehouses(id),
  supplier_id uuid references public.suppliers(id) on delete set null,
  receipt_number text not null,
  receipt_date date not null default current_date,
  status doc_status not null default 'draft',
  total numeric(19,4) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, receipt_number)
);
create table if not exists public.receipt_items (
  id uuid primary key default uuid_generate_v4(),
  receipt_id uuid not null references public.goods_receipts(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(19,4) not null default 0
);

create table if not exists public.stock_transfers (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  from_warehouse_id uuid not null references public.warehouses(id),
  to_warehouse_id uuid not null references public.warehouses(id),
  transfer_number text not null,
  transfer_date date not null default current_date,
  status doc_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, transfer_number)
);
create table if not exists public.transfer_items (
  id uuid primary key default uuid_generate_v4(),
  transfer_id uuid not null references public.stock_transfers(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(19,4) not null default 0
);

-- Currency & FX rates
create table if not exists public.currencies (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  code text not null,
  name text not null,
  symbol text,
  is_base boolean not null default false,
  created_at timestamptz not null default now(),
  unique (company_id, code)
);
create table if not exists public.currency_rates (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  currency_id uuid not null references public.currencies(id) on delete cascade,
  rate numeric(19,6) not null default 1,
  effective_date date not null default current_date,
  created_at timestamptz not null default now()
);

-- Budget vs actual
create table if not exists public.budgets (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  fiscal_year int not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.budget_items (
  id uuid primary key default uuid_generate_v4(),
  budget_id uuid not null references public.budgets(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  amount numeric(19,4) not null default 0
);

-- CRM pipeline
create table if not exists public.opportunities (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  title text not null,
  stage text not null default 'new',
  expected_amount numeric(19,4) not null default 0,
  probability int not null default 0,
  expected_close date,
  assigned_to uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Project & tasks
create table if not exists public.projects (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  description text,
  status text not null default 'on_track',
  start_date date,
  end_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.project_tasks (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  title text not null,
  status text not null default 'todo',
  priority text not null default 'medium',
  due_date date,
  assigned_to uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

-- Bank reconciliation
create table if not exists public.bank_reconciliations (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  bank_account_id uuid not null references public.bank_accounts(id) on delete cascade,
  recon_date date not null default current_date,
  statement_balance numeric(19,4) not null default 0,
  book_balance numeric(19,4) not null default 0,
  difference numeric(19,4) not null default 0,
  status doc_status not null default 'draft',
  notes text,
  created_at timestamptz not null default now()
);

-- Dunning / reminder rules
create table if not exists public.dunning_rules (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  days_overdue int not null default 0,
  fee numeric(19,4) not null default 0,
  template text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- RLS (service role bypasses)
do $$
declare r record;
begin
  for r in select tablename from pg_tables where schemaname='public'
  loop
    execute format('alter table public.%I enable row level security', r.tablename);
  end loop;
end $$;
