-- ============================================================
-- LAPORAN KARTINI — Migration 0006: deferred target account
-- Menambahkan kolom target_account_id untuk memilih akun
-- pendapatan/beban yang di-defer. Idempotent.
-- ============================================================

do $$
begin
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'deferred_entries' and column_name = 'target_account_id'
  ) then
    alter table public.deferred_entries
      add column target_account_id uuid references public.accounts(id) on delete set null;
  end if;
end $$;
