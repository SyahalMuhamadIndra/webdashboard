-- ============================================================
-- LAPORAN KARTINI — Migration 0004: Deferred Revenue & Expense
-- Pengakuan pendapatan/beban ditangguhkan (multi-period) ala Odoo.
-- Idempotent (create table if not exists).
-- ============================================================

create extension if not exists "uuid-ossp";

create table if not exists public.deferred_entries (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  kind text not null default 'revenue',            -- revenue | expense
  source text not null default 'invoice',          -- invoice | bill
  source_id uuid,                                   -- id invoice/bill asal
  ref_number text,
  total_amount numeric(19,4) not null default 0,
  recognized_amount numeric(19,4) not null default 0,
  start_date date not null default current_date,
  end_date date not null default current_date,
  next_recognition date not null default current_date,
  interval_type text not null default 'monthly',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.deferred_entries enable row level security;
