-- ============================================================
-- LAPORAN KARTINI — Kledo-like Accounting & ERP
-- Skema Database Supabase (PostgreSQL)
-- Migration 0001: Foundation, Identity/tenant, Master data,
--                 Accounting engine (COA, journal), core modules
-- ============================================================
-- Migration runner sends this whole file as one query (atomic-safe
-- for a fresh database). Each `create table` uses `if not exists`.
-- ============================================================

-- ==== Extensions ====
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- ==== Enums (idempotent) ====
do $$ begin
  create type user_role as enum ('owner','admin','manager','accountant','staff','viewer');
exception when duplicate_object then null; end $$;

do $$ begin
  create type doc_status as enum ('draft','pending','approved','posted','confirmed',
                                 'partially_paid','paid','void','cancelled','rejected');
exception when duplicate_object then null; end $$;

do $$ begin
  create type movement_type as enum ('purchase','sale','sale_return','purchase_return',
                                     'transfer_in','transfer_out','adjustment','opname','initial');
exception when duplicate_object then null; end $$;

do $$ begin
  create type asset_status as enum ('active','disposed','sold','written_off','transferred');
exception when duplicate_object then null; end $$;

do $$ begin
  create type journal_source as enum ('manual','sales_invoice','purchase_bill','customer_payment',
                                      'supplier_payment','expense','depreciation','stock_adjustment',
                                      'bank_reconciliation','opening_balance','sales_return','purchase_return');
exception when duplicate_object then null; end $$;

-- ==== updated_at trigger (no args — valid) ====
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- ============================================================
-- IDENTITY & TENANT
-- ============================================================

create table if not exists public.companies (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  name text not null,
  legal_name text,
  tax_id text,
  address text,
  phone text,
  email text,
  base_currency text not null default 'IDR',
  fiscal_year_start int not null default 1,
  timezone text not null default 'Asia/Jakarta',
  logo_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.branches (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  code text not null,
  name text not null,
  address text,
  phone text,
  email text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, code)
);

create table if not exists public.warehouses (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  code text not null,
  name text not null,
  address text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, code)
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  phone text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.roles (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid references public.companies(id) on delete cascade,
  name text not null,
  description text,
  is_system boolean not null default false,
  created_at timestamptz not null default now(),
  unique (company_id, name)
);

create table if not exists public.permissions (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  module text not null,
  name text not null,
  description text
);

create table if not exists public.role_permissions (
  role_id uuid not null references public.roles(id) on delete cascade,
  permission_id uuid not null references public.permissions(id) on delete cascade,
  primary key (role_id, permission_id)
);

create table if not exists public.user_roles (
  user_id uuid not null references public.profiles(id) on delete cascade,
  role_id uuid not null references public.roles(id) on delete cascade,
  primary key (user_id, role_id)
);

create table if not exists public.user_scopes (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  company_id uuid references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete cascade,
  warehouse_id uuid references public.warehouses(id) on delete cascade
);

create table if not exists public.audit_logs (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid references public.companies(id) on delete set null,
  user_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity text not null,
  entity_id text,
  old_data jsonb,
  new_data jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz not null default now()
);
create index if not exists idx_audit_logs_company on public.audit_logs(company_id, created_at desc);
create index if not exists idx_audit_logs_user on public.audit_logs(user_id, created_at desc);

-- ============================================================
-- ACCOUNTING ENGINE
-- ============================================================

create table if not exists public.type_of_account (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  normal_balance text not null check (normal_balance in ('debit','credit')),
  report_section text not null check (report_section in ('balance_sheet','income_statement','equity')),
  sort_order int not null default 0
);

create table if not exists public.accounts (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  code text not null,
  name text not null,
  type_of_account_id uuid not null references public.type_of_account(id),
  parent_id uuid references public.accounts(id) on delete set null,
  is_header boolean not null default false,
  is_cash boolean not null default false,
  is_bank boolean not null default false,
  is_receivable boolean not null default false,
  is_payable boolean not null default false,
  is_inventory boolean not null default false,
  is_paid_tax boolean not null default false,
  is_collected_tax boolean not null default false,
  is_depreciation boolean not null default false,
  is_accum_depreciation boolean not null default false,
  is_retained_earnings boolean not null default false,
  is_closing boolean not null default false,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, code)
);
create index if not exists idx_accounts_company on public.accounts(company_id);

create table if not exists public.fiscal_periods (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  fiscal_year int not null,
  month int not null check (month between 1 and 12),
  start_date date not null,
  end_date date not null,
  is_closed boolean not null default false,
  closed_at timestamptz,
  closed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (company_id, fiscal_year, month)
);

create table if not exists public.journal_entries (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  fiscal_period_id uuid references public.fiscal_periods(id) on delete set null,
  entry_number text not null,
  entry_date date not null,
  memo text,
  reference_type text,
  reference_id uuid,
  source journal_source not null default 'manual',
  is_posted boolean not null default false,
  is_reversed boolean not null default false,
  reversed_entry_id uuid references public.journal_entries(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, entry_number)
);
create index if not exists idx_journal_entries_company_date on public.journal_entries(company_id, entry_date desc);

create table if not exists public.journal_lines (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  journal_entry_id uuid not null references public.journal_entries(id) on delete cascade,
  account_id uuid not null references public.accounts(id),
  branch_id uuid references public.branches(id) on delete set null,
  debit numeric(19,4) not null default 0 check (debit >= 0),
  credit numeric(19,4) not null default 0 check (credit >= 0),
  amount numeric(19,4) not null,
  description text,
  created_at timestamptz not null default now()
);
create index if not exists idx_journal_lines_entry on public.journal_lines(journal_entry_id);
create index if not exists idx_journal_lines_account on public.journal_lines(account_id);
create index if not exists idx_journal_lines_company on public.journal_lines(company_id);

create table if not exists public.account_balances (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  fiscal_period_id uuid references public.fiscal_periods(id) on delete cascade,
  opening_debit numeric(19,4) not null default 0,
  opening_credit numeric(19,4) not null default 0,
  period_debit numeric(19,4) not null default 0,
  period_credit numeric(19,4) not null default 0,
  closing_debit numeric(19,4) not null default 0,
  closing_credit numeric(19,4) not null default 0,
  updated_at timestamptz not null default now(),
  unique (company_id, account_id, fiscal_period_id)
);

create table if not exists public.closing_entries (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  journal_entry_id uuid not null references public.journal_entries(id) on delete cascade,
  fiscal_period_id uuid not null references public.fiscal_periods(id) on delete cascade,
  is_reversal boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

-- ============================================================
-- MASTER DATA
-- ============================================================

create table if not exists public.customers (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  code text not null,
  name text not null,
  customer_type text default 'customer',
  tax_id text,
  phone text,
  email text,
  address text,
  credit_limit numeric(19,4) default 0,
  term_days int default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, code)
);

create table if not exists public.suppliers (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  code text not null,
  name text not null,
  tax_id text,
  phone text,
  email text,
  address text,
  term_days int default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, code)
);

create table if not exists public.categories (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  parent_id uuid references public.categories(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.units (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  code text not null,
  created_at timestamptz not null default now(),
  unique (company_id, code)
);

create table if not exists public.products (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  sku text not null,
  name text not null,
  category_id uuid references public.categories(id) on delete set null,
  unit_id uuid references public.units(id) on delete set null,
  description text,
  cost_method text not null default 'average',
  is_track_inventory boolean not null default true,
  is_active boolean not null default true,
  barcode text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, sku)
);

create table if not exists public.tax_rates (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  rate numeric(8,4) not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.payment_methods (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  account_id uuid references public.accounts(id) on delete set null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ============================================================
-- INVENTORY
-- ============================================================

create table if not exists public.stock_movements (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  warehouse_id uuid not null references public.warehouses(id),
  product_id uuid not null references public.products(id),
  movement_type movement_type not null,
  quantity numeric(19,4) not null,
  unit_cost numeric(19,4) not null default 0,
  reference_type text,
  reference_id uuid,
  description text,
  created_at timestamptz not null default now()
);
create index if not exists idx_stock_movements_product on public.stock_movements(product_id, warehouse_id);
create index if not exists idx_stock_movements_ref on public.stock_movements(reference_type, reference_id);

create table if not exists public.stock_balances (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  warehouse_id uuid not null references public.warehouses(id),
  product_id uuid not null references public.products(id),
  quantity numeric(19,4) not null default 0,
  avg_cost numeric(19,4) not null default 0,
  updated_at timestamptz not null default now(),
  unique (company_id, warehouse_id, product_id)
);

create table if not exists public.stock_opnames (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  warehouse_id uuid not null references public.warehouses(id),
  opname_number text not null,
  opname_date date not null,
  status doc_status not null default 'draft',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, opname_number)
);

create table if not exists public.stock_opname_lines (
  id uuid primary key default uuid_generate_v4(),
  opname_id uuid not null references public.stock_opnames(id) on delete cascade,
  product_id uuid not null references public.products(id),
  system_qty numeric(19,4) not null default 0,
  actual_qty numeric(19,4) not null default 0,
  diff_qty numeric(19,4) generated always as (actual_qty - system_qty) stored,
  unit_cost numeric(19,4) not null default 0
);

-- ============================================================
-- SALES / PURCHASE / PAYMENT (documents that post journals)
-- ============================================================

create table if not exists public.invoices (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  customer_id uuid not null references public.customers(id),
  warehouse_id uuid references public.warehouses(id) on delete set null,
  invoice_number text not null,
  invoice_date date not null,
  due_date date,
  status doc_status not null default 'draft',
  subtotal numeric(19,4) not null default 0,
  tax_amount numeric(19,4) not null default 0,
  discount_amount numeric(19,4) not null default 0,
  total numeric(19,4) not null default 0,
  journal_entry_id uuid references public.journal_entries(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, invoice_number)
);

create table if not exists public.invoice_items (
  id uuid primary key default uuid_generate_v4(),
  invoice_id uuid not null references public.invoices(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  description text,
  quantity numeric(19,4) not null default 1,
  unit_price numeric(19,4) not null default 0,
  discount numeric(19,4) not null default 0,
  tax_rate_id uuid references public.tax_rates(id) on delete set null,
  tax_amount numeric(19,4) not null default 0,
  line_total numeric(19,4) not null default 0,
  revenue_account_id uuid references public.accounts(id),
  inventory_account_id uuid references public.accounts(id)
);

create table if not exists public.bills (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  supplier_id uuid not null references public.suppliers(id),
  warehouse_id uuid references public.warehouses(id) on delete set null,
  bill_number text not null,
  bill_date date not null,
  due_date date,
  status doc_status not null default 'draft',
  subtotal numeric(19,4) not null default 0,
  tax_amount numeric(19,4) not null default 0,
  discount_amount numeric(19,4) not null default 0,
  total numeric(19,4) not null default 0,
  journal_entry_id uuid references public.journal_entries(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, bill_number)
);

create table if not exists public.bill_items (
  id uuid primary key default uuid_generate_v4(),
  bill_id uuid not null references public.bills(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  description text,
  quantity numeric(19,4) not null default 1,
  unit_price numeric(19,4) not null default 0,
  discount numeric(19,4) not null default 0,
  tax_rate_id uuid references public.tax_rates(id) on delete set null,
  tax_amount numeric(19,4) not null default 0,
  line_total numeric(19,4) not null default 0,
  expense_account_id uuid references public.accounts(id),
  inventory_account_id uuid references public.accounts(id)
);

create table if not exists public.payments (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  direction text not null check (direction in ('in','out')),
  customer_id uuid references public.customers(id),
  supplier_id uuid references public.suppliers(id),
  payment_number text not null,
  payment_date date not null,
  payment_method_id uuid references public.payment_methods(id) on delete set null,
  amount numeric(19,4) not null default 0,
  status doc_status not null default 'draft',
  journal_entry_id uuid references public.journal_entries(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, payment_number)
);

create table if not exists public.payment_allocations (
  id uuid primary key default uuid_generate_v4(),
  payment_id uuid not null references public.payments(id) on delete cascade,
  invoice_id uuid references public.invoices(id) on delete cascade,
  bill_id uuid references public.bills(id) on delete cascade,
  amount numeric(19,4) not null default 0
);

-- ============================================================
-- AR / AP
-- ============================================================

create table if not exists public.receivables (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  customer_id uuid not null references public.customers(id),
  invoice_id uuid references public.invoices(id) on delete set null,
  original_amount numeric(19,4) not null default 0,
  paid_amount numeric(19,4) not null default 0,
  due_date date,
  status doc_status not null default 'posted',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.payables (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  supplier_id uuid not null references public.suppliers(id),
  bill_id uuid references public.bills(id) on delete set null,
  original_amount numeric(19,4) not null default 0,
  paid_amount numeric(19,4) not null default 0,
  due_date date,
  status doc_status not null default 'posted',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- CASH & BANK
-- ============================================================

create table if not exists public.cash_accounts (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  account_id uuid not null references public.accounts(id) on delete cascade,
  name text not null,
  currency text not null default 'IDR',
  opening_balance numeric(19,4) not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.bank_accounts (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  account_id uuid not null references public.accounts(id) on delete cascade,
  bank_name text not null,
  account_number text,
  account_name text,
  currency text not null default 'IDR',
  opening_balance numeric(19,4) not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ============================================================
-- FIXED ASSETS
-- ============================================================

create table if not exists public.fixed_assets (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  code text not null,
  name text not null,
  category text,
  acquisition_date date not null,
  acquisition_cost numeric(19,4) not null default 0,
  salvage_value numeric(19,4) not null default 0,
  useful_life_months int not null default 60,
  depreciation_method text not null default 'straight_line',
  accumulated_depreciation numeric(19,4) not null default 0,
  net_book_value numeric(19,4) not null default 0,
  asset_account_id uuid references public.accounts(id),
  accum_dep_account_id uuid references public.accounts(id),
  expense_account_id uuid references public.accounts(id),
  status asset_status not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, code)
);

create table if not exists public.depreciation_entries (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  asset_id uuid not null references public.fixed_assets(id) on delete cascade,
  fiscal_period_id uuid references public.fiscal_periods(id) on delete set null,
  journal_entry_id uuid references public.journal_entries(id) on delete set null,
  amount numeric(19,4) not null default 0,
  period_label text,
  entry_date date not null,
  created_at timestamptz not null default now()
);

-- ============================================================
-- NOTIFICATIONS / SETTINGS
-- ============================================================

create table if not exists public.notifications (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid references public.companies(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  title text not null,
  message text,
  type text,
  is_read boolean not null default false,
  data jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_notifications_user on public.notifications(user_id, is_read);

create table if not exists public.settings (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  key text not null,
  value jsonb,
  updated_at timestamptz not null default now(),
  unique (company_id, key)
);

-- ============================================================
-- Wire up updated_at triggers (valid no-arg trigger function)
-- ============================================================
do $$
declare t text;
begin
  foreach t in array array[
    'companies','branches','warehouses','profiles','accounts','journal_entries',
    'account_balances','customers','suppliers','products','stock_balances',
    'stock_opnames','invoices','bills','payments','receivables','payables',
    'fixed_assets','settings'
  ]
  loop
    execute format('drop trigger if exists trg_%s_updated on public.%I', t, t);
    execute format(
      'create trigger trg_%s_updated before update on public.%I
       for each row execute procedure public.set_updated_at()', t, t);
  end loop;
end $$;

-- ============================================================
-- Row Level Security (RLS) & membership helper
-- ============================================================

create or replace function public.is_company_member(company_id uuid)
returns boolean as $$
begin
  return exists (
    select 1 from public.user_scopes s
    where s.user_id = auth.uid() and s.company_id = is_company_member.company_id
  ) or exists (
    select 1 from public.roles r
    join public.user_roles ur on ur.role_id = r.id
    where ur.user_id = auth.uid() and r.company_id = is_company_member.company_id
  );
end;
$$ language plpgsql security definer stable;

do $$
declare r record;
begin
  for r in
    select tablename from pg_tables where schemaname = 'public'
  loop
    execute format('alter table public.%I enable row level security', r.tablename);
  end loop;
end $$;
