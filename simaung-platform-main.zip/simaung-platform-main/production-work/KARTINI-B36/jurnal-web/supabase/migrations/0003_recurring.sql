-- ============================================================
-- LAPORAN KARTINI — Migration 0003: Recurring Invoice (Subscription)
-- Menghasilkan invoice periodik otomatis (mingguan/bulanan/tahunan).
-- Idempotent (create table if not exists).
-- ============================================================

create extension if not exists "uuid-ossp";

create table if not exists public.recurring_invoices (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid not null references public.companies(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  description text,
  interval_type text not null default 'monthly',
  start_date date not null default current_date,
  next_run_date date not null default current_date,
  end_date date,
  auto_post boolean not null default true,
  is_active boolean not null default true,
  last_run_date date,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.recurring_invoice_items (
  id uuid primary key default uuid_generate_v4(),
  recurring_invoice_id uuid not null references public.recurring_invoices(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  description text,
  quantity numeric(19,4) not null default 1,
  unit_price numeric(19,4) not null default 0,
  discount numeric(19,4) not null default 0,
  tax_rate_id uuid references public.tax_rates(id) on delete set null,
  line_total numeric(19,4) not null default 0
);

-- RLS for the new tables (service role bypasses)
alter table public.recurring_invoices enable row level security;
alter table public.recurring_invoice_items enable row level security;
