TEMPLATE EMAIL SUPABASE — "Confirm signup"
=====================================================================
Cara pakai:
1. Buka Supabase Dashboard proyek Anda (https://supabase.com/dashboard)
   -> Authentication -> Email Templates -> pilih "Confirm signup"
2. Ganti isi kolom "Message Body" (aktifkan mode HTML) dengan kode HTML di bawah.
3. Variabel {{ .ConfirmationURL }} = link verifikasi dari Supabase —
   dipakai sebagai href pada tombol CTA. WAJIB ada, jangan hapus.
4. Subject: "Konfirmasi Email Anda — Laporan Kartini"
5. Save. Berlaku untuk email konfirmasi berikutnya.

PENTING (menentukan arah link konfirmasi):
- Sudah saya perbaiki di kode: signUp sekarang mengirim emailRedirectTo
  ke https://laporan-kartini.vercel.app/auth/confirm
- TETAP pastikan di Auth -> URL Configuration, daftar Redirect URLs memuat:
    https://laporan-kartini.vercel.app/*
  (kalau tidak, Supabase memakai SITE_URL bawaan = localhost:3000)

=====================================================================
<html>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Arial,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:32px 16px;">
    <tr>
      <td align="center">
        <table role="presentation" width="520" cellpadding="0" cellspacing="0" style="max-width:520px;width:100%;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #e2e8f0;">
          <!-- Header -->
          <tr>
            <td style="background:#0d5e0d;padding:24px 32px;">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="vertical-align:middle;">
                    <span style="font-size:20px;font-weight:700;color:#ffffff;">Laporan Kartini</span>
                  </td>
                  <td align="right" style="vertical-align:middle;">
                    <span style="background:#f85000;color:#ffffff;font-size:12px;font-weight:600;padding:4px 12px;border-radius:999px;">MrFine</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <!-- Body -->
          <tr>
            <td style="padding:32px;">
              <h1 style="margin:0 0 12px;font-size:22px;color:#0f172a;font-weight:700;">Konfirmasi Email Anda</h1>
              <p style="margin:0 0 16px;font-size:15px;line-height:1.6;color:#475569;">
                Terima kasih telah mendaftar. Untuk mengaktifkan akun Anda,
                silakan klik tombol di bawah ini:
              </p>
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center" style="padding:8px 0 16px;">
                    <a href="{{ .ConfirmationURL }}"
                       style="display:inline-block;background:#0d5e0d;color:#ffffff;font-size:16px;font-weight:600;text-decoration:none;padding:14px 32px;border-radius:8px;">
                      Konfirmasi Email
                    </a>
                  </td>
                </tr>
              </table>
              <p style="margin:8px 0 0;font-size:13px;line-height:1.6;color:#94a3b8;">
                Jika tombol di atas tidak berfungsi, salin dan buka tautan berikut di browser Anda:<br/>
              </p>
              <p style="margin:4px 0 0;font-size:12px;word-break:break-all;color:#64748b;">
                <a href="{{ .ConfirmationURL }}" style="color:#0d5e0d;text-decoration:underline;">{{ .ConfirmationURL }}</a>
              </p>
            </td>
          </tr>
          <!-- Footer -->
          <tr>
            <td style="padding:16px 32px;border-top:1px solid #f1f5f9;background:#f8fafc;">
              <p style="margin:0;font-size:12px;color:#94a3b8;text-align:center;">
                &copy; 2026 Laporan Kartini &middot; Powered by MrFine<br/>
                Jika Anda tidak mendaftar, abaikan email ini.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
=====================================================================
