-- ============================================================
-- LAPORAN KARTINI — Seed Data (idempotent)
-- Default company + Chart of Accounts + master lookup data
-- Uses INSERT ... SELECT ... WHERE NOT EXISTS for full idempotency
-- (works regardless of unique constraints).
-- ============================================================

-- Default company: Kartini Boga Nusantara
insert into public.companies (code, name, legal_name, base_currency, fiscal_year_start, timezone)
select 'KARTINI', 'Kartini Boga Nusantara', 'Kartini Boga Nusantara', 'IDR', 1, 'Asia/Jakarta'
where not exists (select 1 from public.companies where code='KARTINI');

-- Type of Accounts (5 standard groups)
insert into public.type_of_account (company_id, name, normal_balance, report_section, sort_order)
select c.id, 'Aktiva', 'debit', 'balance_sheet', 1
from public.companies c where c.code='KARTINI'
and not exists (select 1 from public.type_of_account t where t.company_id=c.id and t.name='Aktiva');

insert into public.type_of_account (company_id, name, normal_balance, report_section, sort_order)
select c.id, 'Liabilitas', 'credit', 'balance_sheet', 2
from public.companies c where c.code='KARTINI'
and not exists (select 1 from public.type_of_account t where t.company_id=c.id and t.name='Liabilitas');

insert into public.type_of_account (company_id, name, normal_balance, report_section, sort_order)
select c.id, 'Ekuitas', 'credit', 'equity', 3
from public.companies c where c.code='KARTINI'
and not exists (select 1 from public.type_of_account t where t.company_id=c.id and t.name='Ekuitas');

insert into public.type_of_account (company_id, name, normal_balance, report_section, sort_order)
select c.id, 'Pendapatan', 'credit', 'income_statement', 4
from public.companies c where c.code='KARTINI'
and not exists (select 1 from public.type_of_account t where t.company_id=c.id and t.name='Pendapatan');

insert into public.type_of_account (company_id, name, normal_balance, report_section, sort_order)
select c.id, 'Beban', 'debit', 'income_statement', 5
from public.companies c where c.code='KARTINI'
and not exists (select 1 from public.type_of_account t where t.company_id=c.id and t.name='Beban');

-- ============================================================
-- CHART OF ACCOUNTS
-- ============================================================

-- AKTIVA
insert into public.accounts (company_id, code, name, type_of_account_id, is_cash, is_bank, is_inventory, is_paid_tax, is_receivable)
select c.id, '1-1000', 'Kas', t.id, true, false, false, false, false
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1000');

insert into public.accounts (company_id, code, name, type_of_account_id, is_bank)
select c.id, '1-1010', 'Bank BCA', t.id, true
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1010');

insert into public.accounts (company_id, code, name, type_of_account_id, is_receivable)
select c.id, '1-1100', 'Piutang Usaha', t.id, true
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1100');

insert into public.accounts (company_id, code, name, type_of_account_id, is_inventory)
select c.id, '1-1200', 'Persediaan Barang', t.id, true
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1200');

insert into public.accounts (company_id, code, name, type_of_account_id, is_paid_tax)
select c.id, '1-1300', 'PPN Masukan', t.id, true
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1300');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '1-1400', 'Tanah', t.id
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1400');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '1-1410', 'Bangunan', t.id
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1410');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '1-1420', 'Kendaraan', t.id
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1420');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '1-1430', 'Mesin & Peralatan', t.id
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1430');

insert into public.accounts (company_id, code, name, type_of_account_id, is_accum_depreciation)
select c.id, '1-1440', 'Akumulasi Penyusutan', t.id, true
from public.companies c join public.type_of_account t on t.name='Aktiva' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='1-1440');

-- LIABILITAS
insert into public.accounts (company_id, code, name, type_of_account_id, is_payable)
select c.id, '2-1000', 'Hutang Usaha', t.id, true
from public.companies c join public.type_of_account t on t.name='Liabilitas' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='2-1000');

insert into public.accounts (company_id, code, name, type_of_account_id, is_collected_tax)
select c.id, '2-1100', 'Hutang PPN', t.id, true
from public.companies c join public.type_of_account t on t.name='Liabilitas' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='2-1100');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '2-1200', 'Hutang Bank', t.id
from public.companies c join public.type_of_account t on t.name='Liabilitas' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='2-1200');

-- EKUITAS
insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '3-1000', 'Modal Pemilik', t.id
from public.companies c join public.type_of_account t on t.name='Ekuitas' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='3-1000');

insert into public.accounts (company_id, code, name, type_of_account_id, is_retained_earnings)
select c.id, '3-1100', 'Laba Ditahan', t.id, true
from public.companies c join public.type_of_account t on t.name='Ekuitas' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='3-1100');

-- PENDAPATAN
insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '4-1000', 'Pendapatan Penjualan', t.id
from public.companies c join public.type_of_account t on t.name='Pendapatan' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='4-1000');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '4-1010', 'Pendapatan Jasa', t.id
from public.companies c join public.type_of_account t on t.name='Pendapatan' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='4-1010');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '4-1100', 'Pendapatan Lain-lain', t.id
from public.companies c join public.type_of_account t on t.name='Pendapatan' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='4-1100');

-- BEBAN
insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '5-1000', 'Harga Pokok Penjualan', t.id
from public.companies c join public.type_of_account t on t.name='Beban' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='5-1000');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '5-2000', 'Gaji & Upah', t.id
from public.companies c join public.type_of_account t on t.name='Beban' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='5-2000');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '5-2100', 'Beban Sewa', t.id
from public.companies c join public.type_of_account t on t.name='Beban' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='5-2100');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '5-2200', 'Beban Listrik & Air', t.id
from public.companies c join public.type_of_account t on t.name='Beban' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='5-2200');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '5-2300', 'Beban Transportasi', t.id
from public.companies c join public.type_of_account t on t.name='Beban' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='5-2300');

insert into public.accounts (company_id, code, name, type_of_account_id, is_depreciation)
select c.id, '5-2400', 'Beban Penyusutan', t.id, true
from public.companies c join public.type_of_account t on t.name='Beban' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='5-2400');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '5-2500', 'Beban Lain-lain', t.id
from public.companies c join public.type_of_account t on t.name='Beban' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='5-2500');

insert into public.accounts (company_id, code, name, type_of_account_id)
select c.id, '5-2600', 'Beban PPN', t.id
from public.companies c join public.type_of_account t on t.name='Beban' and t.company_id=c.id
where c.code='KARTINI' and not exists (select 1 from public.accounts a where a.company_id=c.id and a.code='5-2600');

-- ============================================================
-- UNITS
-- ============================================================
insert into public.units (company_id, name, code)
select c.id, 'Pcs', 'PCS' from public.companies c where c.code='KARTINI' and not exists (select 1 from public.units u where u.company_id=c.id and u.code='PCS');
insert into public.units (company_id, name, code)
select c.id, 'Box', 'BOX' from public.companies c where c.code='KARTINI' and not exists (select 1 from public.units u where u.company_id=c.id and u.code='BOX');
insert into public.units (company_id, name, code)
select c.id, 'Kg', 'KG' from public.companies c where c.code='KARTINI' and not exists (select 1 from public.units u where u.company_id=c.id and u.code='KG');
insert into public.units (company_id, name, code)
select c.id, 'Liter', 'LTR' from public.companies c where c.code='KARTINI' and not exists (select 1 from public.units u where u.company_id=c.id and u.code='LTR');

-- ============================================================
-- TAX RATES
-- ============================================================
insert into public.tax_rates (company_id, name, rate)
select c.id, 'PPN 11%', 11
from public.companies c where c.code='KARTINI' and not exists (select 1 from public.tax_rates tr where tr.company_id=c.id and tr.name='PPN 11%');

-- ============================================================
-- PAYMENT METHODS
-- ============================================================
insert into public.payment_methods (company_id, name, account_id)
select c.id, 'Cash (Tunai)', (select a.id from public.accounts a where a.company_id=c.id and a.code='1-1000')
from public.companies c where c.code='KARTINI' and not exists (select 1 from public.payment_methods pm where pm.company_id=c.id and pm.name='Cash (Tunai)');
insert into public.payment_methods (company_id, name, account_id)
select c.id, 'Transfer Bank', (select a.id from public.accounts a where a.company_id=c.id and a.code='1-1010')
from public.companies c where c.code='KARTINI' and not exists (select 1 from public.payment_methods pm where pm.company_id=c.id and pm.name='Transfer Bank');
insert into public.payment_methods (company_id, name, account_id)
select c.id, 'QRIS', (select a.id from public.accounts a where a.company_id=c.id and a.code='1-1000')
from public.companies c where c.code='KARTINI' and not exists (select 1 from public.payment_methods pm where pm.company_id=c.id and pm.name='QRIS');
insert into public.payment_methods (company_id, name, account_id)
select c.id, 'Kartu Kredit', (select a.id from public.accounts a where a.company_id=c.id and a.code='1-1000')
from public.companies c where c.code='KARTINI' and not exists (select 1 from public.payment_methods pm where pm.company_id=c.id and pm.name='Kartu Kredit');

-- ============================================================
-- PERMISSIONS (sampling of permission matrix)
-- ============================================================
insert into public.permissions (code, module, name) values
  ('dashboard.view','dashboard','Lihat Dashboard'),
  ('accounting.journal.create','accounting','Buat Jurnal'),
  ('accounting.journal.post','accounting','Posting Jurnal'),
  ('accounting.journal.view','accounting','Lihat Jurnal'),
  ('accounting.report.view','accounting','Lihat Laporan'),
  ('sales.invoice.create','sales','Buat Invoice'),
  ('sales.invoice.post','sales','Posting Invoice'),
  ('purchase.bill.create','purchase','Buat Bill'),
  ('purchase.bill.post','purchase','Posting Bill'),
  ('inventory.stock.view','inventory','Lihat Stok'),
  ('master.account.create','master','Buat Akun')
on conflict (code) do nothing;
