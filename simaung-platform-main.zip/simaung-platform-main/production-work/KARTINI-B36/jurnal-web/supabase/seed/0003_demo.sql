-- ============================================================
-- LAPORAN KARTINI — Demo Opening Entry (idempotent)
-- Posts a balanced journal entry so reports populate immediately:
--   Debit  Kas           100,000,000
--   Credit Modal Pemilik 100,000,000
-- Runs through the same double-entry invariant (debit = credit).
-- ============================================================

insert into public.journal_entries
  (company_id, entry_number, entry_date, memo, source, is_posted)
select
  c.id, 'JDEMO-1', current_date, 'Setoran modal awal (demo)', 'opening_balance', true
from public.companies c
where c.code='KARTINI'
  and not exists (select 1 from public.journal_entries je where je.company_id=c.id and je.entry_number='JDEMO-1');

insert into public.journal_lines
  (company_id, journal_entry_id, account_id, debit, credit, amount, description)
select
  c.id,
  je.id,
  a.id,
  case when a.code='1-1000' then 100000000.0000 else 0.0000 end,
  case when a.code='3-1000' then 100000000.0000 else 0.0000 end,
  100000000.0000,
  'Setoran modal awal (demo)'
from public.companies c
join public.journal_entries je on je.company_id=c.id and je.entry_number='JDEMO-1'
join public.accounts a on a.company_id=c.id
where c.code='KARTINI'
  and a.code in ('1-1000','3-1000');
