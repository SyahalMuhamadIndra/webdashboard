(function(){
 'use strict';
 const labels={NEW:'Baru',PREPARING:'Dimasak',READY:'Siap',SERVED:'Disajikan'};
 const route='/ops/pos/restaurant/tickets';
 const draftKey='simaung.fnb-ticket-draft';
 let loading=false, list=[];
 const ticketLabel=t=>t.kind==='DINE_IN'?'Meja '+t.table_code:'Bungkus';
 function setTicket(id,split=false){
  S.restaurantTicketId=id||null;S.restaurantSplit=!!split;
  const mark=document.getElementById('fnb-active-ticket');
  if(mark){mark.hidden=!id;mark.textContent=id?(split?'Pisah tagihan ':'Tiket dapur ')+id.slice(0,8).toUpperCase():'';}
 }
 window.fnbClearTicket=()=>setTicket(null);
 window.openFnbTickets=async function(){
  if(!S.cart.length)setTicket(null);
  openModal({title:'Meja dan Tiket Dapur',sub:'Kirim sebelum bayar, atau lanjutkan pembayaran tiket terbuka',size:'wide',body:'<div class="empty">Memuat…</div>',
   footer:'<button class="btn-sec" onclick="closeModal()">Tutup</button>'});
  try{
   list=S.demo?[]:(await api(route)).items||[];
   const form=S.restaurantTicketId?'<div class="banner info">Pembayaran tiket sedang dibuka. Kosongkan keranjang untuk memulai pesanan baru.</div>':
    S.cart.length?'<form id="fnb-send-form"><div class="row2"><div class="field"><label for="fnb-kind">Jenis pesanan</label><select id="fnb-kind"><option value="DINE_IN">Makan di tempat</option><option value="TAKEAWAY">Bungkus</option></select></div>'+
      '<div class="field" id="fnb-table-field"><label for="fnb-table">Kode meja</label><input id="fnb-table" maxlength="20" placeholder="Contoh A-01" required></div></div>'+
      '<button type="submit" class="btn-primary" style="width:auto">Kirim Keranjang ke Dapur</button><p id="fnb-send-msg" role="status"></p></form>':
      '<div class="banner info">Isi keranjang untuk membuat tiket dapur baru.</div>';
   mbody((S.demo?'<div class="banner info">Fitur tiket sebelum bayar aktif pada outlet F&amp;B di produksi.</div>':'')+form+
    '<h3 style="margin-top:16px">Tiket Belum Dibayar</h3>'+(!list.length?'<div class="empty">Belum ada tiket terbuka.</div>':
    '<div style="overflow:auto"><table class="tbl"><thead><tr><th>Pesanan</th><th>Status</th><th>Item</th><th>Aksi</th></tr></thead><tbody>'+
    list.map((t,i)=>'<tr><td><b>'+esc(ticketLabel(t))+'</b><br><small>'+esc(t.id.slice(0,8).toUpperCase())+'</small></td><td>'+esc(labels[t.status]||t.status)+'</td>'+
     '<td>'+esc(t.items.map(x=>x.qty+' × '+x.name).join(', '))+'</td><td><button type="button" class="btn-sec sm" data-fnb-resume="'+i+'">Bayar Sisa</button> <button type="button" class="btn-sec sm" data-fnb-split="'+i+'">Pisah Tagihan</button> '+
     (t.status==='NEW'&&!t.partPaid?'<button type="button" class="btn-sec sm" data-fnb-cancel="'+i+'">Batalkan</button>':'')+'</td></tr>').join('')+'</tbody></table></div>'));
   const f=document.getElementById('fnb-send-form');
   if(f){
    const kind=document.getElementById('fnb-kind'), table=document.getElementById('fnb-table');
    kind.onchange=()=>{
     const use=kind.value==='DINE_IN';table.required=use;table.disabled=!use;document.getElementById('fnb-table-field').hidden=!use;
    };
    const button=f.querySelector('button');button.disabled=!!S.demo;
    f.onsubmit=async e=>{
     e.preventDefault();
     if(loading||S.demo)return;
     loading=true;button.disabled=true;
     const body={kind:kind.value,table:table.value.trim().toUpperCase(),items:S.cart.map(x=>({productId:x.id,variantId:x.variantId||null,qty:x.qty}))};
     const stamp=JSON.stringify([S.user?.employeeId||S.user?.employeeCode||'',localStorage.getItem('kartini.branchId'),body]);
     try{
      let draft;
      try{draft=JSON.parse(localStorage.getItem(draftKey)||'null');}catch{}
      if(!draft||draft.stamp!==stamp){draft={stamp,id:crypto.randomUUID()};localStorage.setItem(draftKey,JSON.stringify(draft));}
      await api(route,{method:'POST',body:{...body,id:draft.id}});
      localStorage.removeItem(draftKey);
      clearCart();closeModal();toast('Tiket dikirim ke dapur. Pembayaran bisa dilanjutkan dari daftar tiket.','ok');
     }catch(err){document.getElementById('fnb-send-msg').textContent=err.message;button.disabled=false;}
     finally{loading=false;}
    };
   }
   function resume(t,items,split){
    S.cart=items.map(x=>({...x,disc:0}));
    S.disc=0;S.cust=null;billsClear();setTicket(t.id,split);
    closeModal();renderCart();toast(split?'Bagian tagihan siap dibayar.':'Sisa tiket siap dibayar.','ok');
   }
   document.querySelectorAll('[data-fnb-resume]').forEach(btn=>btn.onclick=()=>{
    const t=list[Number(btn.dataset.fnbResume)];
    if(S.cart.length&&!confirm('Ganti keranjang yang sedang dibuka dengan tiket ini?'))return;
    resume(t,t.items,false);
   });
   document.querySelectorAll('[data-fnb-split]').forEach(btn=>btn.onclick=()=>{
    const t=list[Number(btn.dataset.fnbSplit)];
    if(S.cart.length&&!confirm('Ganti keranjang yang sedang dibuka dengan bagian tiket ini?'))return;
    mbody('<form id="fnb-split-form"><p>Pilih jumlah setiap item yang dibayar sekarang. Sisa item tetap ada di tiket.</p><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Item</th><th>Sisa</th><th>Bayar sekarang</th></tr></thead><tbody>'+
      t.items.map((x,i)=>'<tr><td>'+esc(x.name)+'</td><td>'+esc(x.qty)+'</td><td><input type="number" min="0" max="'+x.qty+'" step="1" value="0" aria-label="Jumlah dibayar: '+esc(x.name)+'" data-fnb-qty="'+i+'" required></td></tr>').join('')+
      '</tbody></table></div><button type="submit" class="btn-primary" style="width:auto">Lanjutkan Pembayaran</button><p id="fnb-split-msg" role="status"></p></form>');
    document.getElementById('fnb-split-form').onsubmit=e=>{
      e.preventDefault();
      const selected=Array.from(e.currentTarget.querySelectorAll('[data-fnb-qty]')).flatMap(input=>{
        const qty=Number(input.value),item=t.items[Number(input.dataset.fnbQty)];return qty>0?[{...item,qty}]:[];
      });
      if(!selected.length){document.getElementById('fnb-split-msg').textContent='Pilih setidaknya satu item.';return;}
      resume(t,selected,true);
    };
   });
   document.querySelectorAll('[data-fnb-cancel]').forEach(btn=>btn.onclick=async()=>{
    const t=list[Number(btn.dataset.fnbCancel)];
    if(!confirm('Batalkan tiket '+ticketLabel(t)+'?'))return;
    btn.disabled=true;
    try{await api(route+'/'+encodeURIComponent(t.id)+'/cancel',{method:'POST'});if(S.restaurantTicketId===t.id)clearCart();await window.openFnbTickets();}
    catch(e){toast(e.message,'err');btn.disabled=false;}
   });
  }catch(e){mbody('<div class="banner bad">'+esc(e.message)+'</div>');}
 };
})();
