/* Service worker Kasir Simaung Corporation (B28) — agar aplikasi bisa dipasang di tablet
   dan tetap terbuka saat offline, TANPA menyajikan berkas basi.
   Strategi: NETWORK-FIRST (selalu ambil versi terbaru; cache hanya sebagai cadangan offline). */
const CACHE = 'simaung-pos-tablet-silent-v2';
const ASET = ['./maintenance-guard.js?v=2', './', './index.html', './manifest.webmanifest', './ikon-192.png', './ikon-512.png'];
self.addEventListener('install', (e) => { self.skipWaiting(); e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASET)).catch(() => {})); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const u = new URL(req.url);
  if (u.origin !== location.origin) return; /* panggilan API backend langsung ke server */
  /* Jaringan dulu; bila gagal (offline) baru pakai cache. */
  e.respondWith(
    fetch(req).then((res) => {
      const cp = res.clone();
      caches.open(CACHE).then((c) => c.put(req, cp)).catch(() => {});
      return res;
    }).catch(() => caches.match(req).then((r) => r || caches.match('./index.html')))
  );
});
