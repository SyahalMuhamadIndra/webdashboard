#!/usr/bin/env python3
# Server kecil agar aplikasi kasir bisa dibuka dari tablet di jaringan toko yang sama.
# Jalankan di komputer kasir:  python serve.py     lalu buka di tablet:  http://<IP-komputer>:8080
import http.server, socketserver, socket, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
PORT = 8080
class H(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()
    def log_message(self, *a):
        pass
try:
    ip = socket.gethostbyname(socket.gethostname())
except Exception:
    ip = '127.0.0.1'
print('Aplikasi kasir siap diakses tablet di jaringan yang sama:')
print('   http://%s:%d' % (ip, PORT))
print('Tekan Ctrl+C untuk berhenti.')
socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(('0.0.0.0', PORT), H) as httpd:
    httpd.serve_forever()
