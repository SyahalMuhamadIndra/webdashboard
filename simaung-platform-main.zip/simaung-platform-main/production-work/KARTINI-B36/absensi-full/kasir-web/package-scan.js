/* POS clients provide the current branch catalog and their existing cart API. */
function packageCandidates(read, products) {
  const normalized = value => String(value ?? '').toLowerCase()
    .normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/(\d)\s+(ml|kg|gr|mg|g|l)\b/g, '$1$2');
  const tokens = value => normalized(value).match(/[a-z0-9]+/g) || [];
  const core = new Set(tokens([read.brand, read.name].join(' ')).filter(token => token.length > 2));
  const variant = tokens([read.variant, read.size].join(' '));
  const exact = normalized(read.sku).trim();
  return products.map(product => {
    const terms = new Set(tokens(product.name));
    const hits = [...core].filter(token => terms.has(token));
    const codeHit = exact && [product.sku, product.barcode].some(code => normalized(code).trim() === exact);
    return { product, score: codeHit ? 1000 : hits.length ? hits.length * 10 + variant.filter(token => terms.has(token)).length * 3 : 0 };
  }).filter(item => item.score > 0).sort((a, b) => b.score - a.score).slice(0, 6);
}

// Check exposure, detail, and movement within the camera guide.
function packageFrame(rgba, previous, width) {
  const pixels = new Uint8Array(rgba.length / 4);
  let light = 0, edges = 0, movement = 0;
  for (let i = 0; i < pixels.length; i++) {
    const offset = i * 4;
    const value = (rgba[offset] * 77 + rgba[offset + 1] * 150 + rgba[offset + 2] * 29) >> 8;
    pixels[i] = value;
    light += value;
    if (previous) movement += Math.abs(value - previous[i]);
    if ((i % width && Math.abs(value - pixels[i - 1]) >= 22) ||
        (i >= width && Math.abs(value - pixels[i - width]) >= 22)) edges++;
  }
  return {
    pixels,
    readable: light / pixels.length >= 40 && light / pixels.length <= 230 &&
      edges / pixels.length >= 0.07,
    steady: !!previous && movement / pixels.length < 7
  };
}

function openPackageScan() {
  if (document.getElementById('package-scan')) return;
  const dialog = document.createElement('dialog');
  dialog.id = 'package-scan';
  dialog.style.cssText = 'width:min(30rem,calc(100% - 2rem));max-height:90vh;border:0;border-radius:16px;padding:20px;color:#172738;background:#fff';
  dialog.setAttribute('aria-labelledby', 'package-scan-title');
  dialog.innerHTML = `<h2 id="package-scan-title">Scan Bungkus</h2>
    <p>Foto bagian depan satu kemasan, termasuk merek, varian, dan ukuran. Foto dikirim ke Gemini untuk dibaca.</p>
    <div data-preview hidden style="position:relative;background:#172738;line-height:0">
      <video playsinline muted style="width:100%;height:min(35vh,300px);object-fit:cover"></video>
      <span aria-hidden="true" style="position:absolute;inset:18% 15%;border:2px dashed white;border-radius:10px;pointer-events:none"></span>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin:12px 0">
      <button class="btn-ghost" data-camera>Buka kamera</button><button class="btn-ghost" data-capture hidden>Ambil foto</button>
      <button class="btn-ghost" data-file>Pilih foto</button><button class="btn-ghost" data-close>Tutup</button>
    </div>
    <input type="file" accept="image/*" hidden><p role="status" aria-live="polite"></p><div data-results></div>`;
  document.body.appendChild(dialog);
  const video = dialog.querySelector('video');
  const preview = dialog.querySelector('[data-preview]');
  const camera = dialog.querySelector('[data-camera]');
  const capture = dialog.querySelector('[data-capture]');
  const file = dialog.querySelector('input');
  const status = dialog.querySelector('[role="status"]');
  const results = dialog.querySelector('[data-results]');
  const initialProducts = S.products;
  let stream;
  let busy = false;
  let captureTimer;

  function watchCamera() {
    const sample = document.createElement('canvas');
    sample.width = 48;
    sample.height = 36;
    const ctx = sample.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    let previous, stableFrames = 0;
    captureTimer = setInterval(() => {
      if (!dialog.open || busy || document.hidden || video.readyState < 2 ||
          !video.videoWidth || !video.videoHeight) {
        previous = undefined;
        stableFrames = 0;
        return;
      }
      const w = video.videoWidth, h = video.videoHeight;
      // Match the central guide even when the preview crops the source.
      const scale = Math.max(video.clientWidth / w, video.clientHeight / h);
      if (!scale) return;
      const sw = video.clientWidth * 0.7 / scale, sh = video.clientHeight * 0.64 / scale;
      ctx.drawImage(video, (w - sw) / 2, (h - sh) / 2, sw, sh, 0, 0, sample.width, sample.height);
      const frame = packageFrame(ctx.getImageData(0, 0, sample.width, sample.height).data, previous, sample.width);
      previous = frame.pixels;
      stableFrames = frame.readable && frame.steady ? stableFrames + 1 : 0;
      if (stableFrames >= 5) void scan(video, w, h);
    }, 220);
  }

  function stopCamera() {
    clearInterval(captureTimer);
    stream?.getTracks().forEach(track => track.stop());
    stream = undefined;
    video.srcObject = null;
    preview.hidden = capture.hidden = true;
  }

  async function scan(source, width, height) {
    if (busy || !width || !height) return;
    busy = true;
    results.replaceChildren();
    status.textContent = 'Sedang membaca kemasan…';
    try {
      let read;
      if (S.demo) {
        const sample = initialProducts.find(product => product.name);
        read = { name: sample?.name, sku: sample?.sku };
      } else {
        const scale = Math.min(1, 960 / Math.max(width, height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(width * scale));
        canvas.height = Math.max(1, Math.round(height * scale));
        canvas.getContext('2d').drawImage(source, 0, 0, canvas.width, canvas.height);
        stopCamera();
        read = await api('/ops/pos/package-scan', { method:'POST', body:{ image:canvas.toDataURL('image/jpeg', 0.76).split(',')[1] } });
      }
      if (!dialog.open || initialProducts !== S.products) return;
      const candidates = packageCandidates(read, S.products);
      status.textContent = candidates.length
        ? (S.demo ? 'Contoh demo. Pilih produk untuk ditambahkan.' : 'Cocokkan varian dan ukuran, lalu pilih produk.')
        : 'Produk tidak ditemukan di katalog cabang. Coba foto ulang, pencarian, atau barcode.';
      for (const { product } of candidates) {
        const button = document.createElement('button');
        button.className = 'btn-ghost';
        button.style.cssText = 'display:block;width:100%;text-align:left;margin-top:8px';
        button.textContent = [product.name, product.sku, 'Rp ' + Number(product.price || 0).toLocaleString('id-ID')].filter(Boolean).join(' · ');
        button.onclick = () => {
          if (initialProducts !== S.products) {
            status.textContent = 'Katalog berubah. Tutup dan scan lagi.';
            results.replaceChildren();
            return;
          }
          dialog.close();
          addProduct(product.id);
        };
        results.append(button);
      }
    } catch (error) {
      status.textContent = error.message || 'Scan gagal. Coba foto ulang atau gunakan barcode.';
    } finally {
      stopCamera();
      busy = false;
    }
  }

  camera.onclick = async () => {
    if (busy || stream) return;
    camera.disabled = true;
    try {
      const opened = await navigator.mediaDevices.getUserMedia({ audio:false, video:{ facingMode:{ ideal:'environment' } } });
      if (!dialog.open) { opened.getTracks().forEach(track => track.stop()); return; }
      stream = opened;
      video.srcObject = opened;
      preview.hidden = false;
      await video.play();
      capture.hidden = false;
      status.textContent = 'Posisikan kemasan di tengah dan tahan sebentar. Foto diambil otomatis saat gambar stabil.';
      watchCamera();
    } catch {
      stopCamera();
      status.textContent = 'Kamera tidak tersedia. Izinkan akses kamera atau pilih foto.';
    } finally {
      camera.disabled = false;
    }
  };
  capture.onclick = () => scan(video, video.videoWidth, video.videoHeight);
  dialog.querySelector('[data-file]').onclick = () => {
    if (busy) return;
    stopCamera();
    file.click();
  };
  file.onchange = async () => {
    const photo = file.files[0];
    file.value = '';
    if (!photo || busy) return;
    if (photo.size > 12_000_000) { status.textContent = 'Pilih foto di bawah 12 MB.'; return; }
    try {
      const bitmap = await createImageBitmap(photo);
      try { await scan(bitmap, bitmap.width, bitmap.height); } finally { bitmap.close(); }
    } catch {
      status.textContent = 'Foto tidak bisa dibaca. Coba JPG atau PNG.';
    }
  };
  dialog.querySelector('[data-close]').onclick = () => dialog.close();
  dialog.addEventListener('close', () => { stopCamera(); dialog.remove(); });
  dialog.showModal();
}

