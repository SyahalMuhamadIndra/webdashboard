'use strict';

const fields = {
  products: [
    ['sku','SKU',1,'kode produk|kode barang|product sku|item code'],
    ['name','Nama produk',1,'nama barang|product name|nama|name'],
    ['barcode','Barcode',0,'kode barcode|bar code'],
    ['category','Kategori',0,'category|kategori produk'],
    ['unit','Satuan',1,'unit|uom|unit of measure'],
    ['price','Harga jual',1,'selling price|price|harga|retail price'],
    ['cost','Harga modal',0,'cost|hpp|harga beli|cost price'],
    ['stock','Stok awal',0,'stok|stock|quantity|qty|stok tersedia'],
    ['minStock','Stok minimum',0,'minimum stock|min stock|stok minimal']
  ],
  materials: [
    ['sku','SKU bahan',1,'sku|kode bahan|ingredient sku|kode barang'],
    ['name','Nama bahan',1,'nama|bahan|ingredient name|material name|name'],
    ['unit','Satuan',1,'unit|uom|satuan dasar'],
    ['cost','Biaya per satuan',0,'cost|harga modal|harga beli|hpp'],
    ['stock','Stok awal',0,'stok|stock|quantity|qty|stok tersedia'],
    ['minStock','Stok minimum',0,'minimum stock|min stock|stok minimal']
  ],
  recipes: [
    ['sku','SKU produk',1,'sku|product sku|kode produk'],
    ['materialSku','SKU bahan',1,'ingredient sku|material sku|kode bahan'],
    ['qty','Takaran',1,'qty|quantity|jumlah|kuantitas'],
    ['unit','Satuan bahan',1,'unit|uom|satuan']
  ]
};

function parseOlseraCsv(input) {
  const text = input.replace(/^\uFEFF/,'');
  const first = text.split(/\r?\n/,1)[0].replace(/"(?:[^"]|"")*"/g,'');
  const delimiter = [',',';','\t'].sort((a,b)=>first.split(b).length-first.split(a).length)[0];
  const rows = [];
  let row = [], value = '', quoted = false, closed = false;
  for (let i=0;i<text.length;i++) {
    const char = text[i];
    if (quoted) {
      if (char === '"' && text[i+1] === '"') { value += '"'; i++; }
      else if (char === '"') { quoted = false; closed = true; }
      else value += char;
    } else if (char === '"' && !value && !closed) {
      quoted = true;
    } else if (char === delimiter || char === '\r' || char === '\n') {
      row.push(value.trim()); value = ''; closed = false;
      if (char !== delimiter) {
        if (char === '\r' && text[i+1] === '\n') i++;
        if (row.some(Boolean)) rows.push(row);
        row = [];
      }
    } else {
      if (closed || char === '"') throw Error('Tanda kutip CSV tidak valid.');
      value += char;
    }
  }
  if (quoted) throw Error('Ada tanda kutip CSV yang belum ditutup.');
  row.push(value.trim());
  if (row.some(Boolean)) rows.push(row);
  if (rows.length < 2 || rows.length > 201) throw Error('File harus memiliki header dan 1–200 baris isi.');
  if (rows[0].length > 100 || rows.some(r=>r.length !== rows[0].length)) throw Error('Jumlah kolom tidak konsisten.');
  return rows;
}

const byId = id => document.getElementById(id);
const branch = byId('branch'), kind = byId('kind'), file = byId('file'), status = byId('status');
const mapping = byId('mapping'), review = byId('review'), preview = byId('preview'), commit = byId('commit');
let token, csv, pending, busy = false;
function message(value) { status.textContent = value; }
function invalidate() { pending = undefined; review.hidden = true; commit.disabled = true; }
function updateControls() { preview.disabled = busy || !csv || !branch.value; commit.disabled = busy || !pending; }
async function api(path, body) {
  const headers = {'Content-Type':'application/json'};
  if (token) headers.Authorization = 'Bearer '+token;
  if (path.startsWith('/ops/') && branch.value) headers['X-Branch-Id'] = branch.value;
  const r = await fetch('https://api.tokokartini.com/api'+path,{headers,method:body?'POST':'GET',body:body?JSON.stringify(body):undefined});
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw Error(data.message || 'Permintaan gagal ('+r.status+').');
  return data;
}

byId('login').onsubmit = async event => {
  event.preventDefault();
  const form = event.currentTarget;
  form.querySelector('button').disabled = true;
  message('Memeriksa akun dan cabang…');
  try {
    const result = await api('/admin/login',Object.fromEntries(new FormData(form)));
    token = result.token;
    if (!token) throw Error('Login tidak menghasilkan sesi.');
    const locations = await api('/ops/branches');
    if (!locations.canManage) throw Error('Fitur ini memerlukan akun admin pusat.');
    if (!locations.items?.length) throw Error('Belum ada cabang POS yang siap untuk impor.');
    for (const item of locations.items) branch.add(new Option(item.name,item.id));
    form.reset();
    form.hidden = true;
    byId('import').hidden = false;
    message('');
  } catch(error) { token = undefined; message(error.message); }
  finally { form.querySelector('button').disabled = false; }
};

function showMapping() {
  invalidate();
  mapping.replaceChildren();
  if (csv) {
    const normalize = value => value.toLowerCase().replace(/[^a-z0-9]/g,'');
    for (const [key,label,required,aliases] of fields[kind.value]) {
      const labelNode = document.createElement('label');
      const select = document.createElement('select');
      select.name = key;
      select.required = !!required;
      select.add(new Option(required?'Pilih kolom':'Lewati kolom',''));
      csv[0].forEach((heading,i)=>select.add(new Option(heading || 'Kolom '+(i+1),String(i))));
      const names = [key,label,...aliases.split('|')].map(normalize);
      const index = csv[0].findIndex(heading=>names.includes(normalize(heading)));
      if (index !== -1) select.value = String(index);
      select.onchange = invalidate;
      labelNode.append(label+(required?' (wajib) ': ' '),select);
      mapping.append(labelNode);
    }
  }
  updateControls();
}

file.onchange = async () => {
  const selected = file.files[0];
  csv = undefined;
  showMapping();
  byId('file-info').textContent = '';
  if (!selected) return;
  try {
    if (selected.size > 1_000_000 || !/\.csv$/i.test(selected.name)) throw Error('Pilih file CSV UTF-8 maksimal 1 MB.');
    const rows = parseOlseraCsv(await selected.text());
    if (file.files[0] !== selected) return;
    csv = rows;
    byId('file-info').textContent = selected.name+' · '+(csv.length-1)+' baris data';
    showMapping();
    message('');
  } catch(error) { message(error.message); }
};
kind.onchange = showMapping;
branch.onchange = invalidate;

byId('template').onclick = () => {
  const headings = fields[kind.value].map(field=>field[1]).join(',');
  const url = URL.createObjectURL(new Blob(['\uFEFF'+headings+'\r\n'],{type:'text/csv;charset=utf-8'}));
  const link = document.createElement('a');
  link.href = url; link.download = 'template-olsera-'+kind.value+'.csv'; link.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
};

function lock(locked) {
  busy = locked;
  for (const input of [branch,kind,file,...mapping.querySelectorAll('select')]) input.disabled = locked;
  updateControls();
}

preview.onclick = async () => {
  invalidate();
  lock(true);
  message('Memvalidasi data…');
  try {
    const selections = [...mapping.querySelectorAll('select')];
    if (selections.some(s=>s.required&&!s.value)) throw Error('Petakan semua kolom wajib.');
    const columns = selections.filter(s=>s.value).map(s=>s.value);
    if (new Set(columns).size !== columns.length) throw Error('Satu kolom CSV hanya boleh dipakai sekali.');
    const rows = csv.slice(1).map(row=>Object.fromEntries(selections.map(s=>[s.name,s.value===''?'':row[Number(s.value)]])));
    const body = {kind:kind.value,rows};
    const result = await api('/ops/admin/olsera-import/preview',body);
    const counts = {add:0,skip:0,error:0};
    const tbody = review.querySelector('tbody');
    tbody.replaceChildren();
    for (const entry of result.plan) {
      counts[entry.status]++;
      const tr = document.createElement('tr');
      if (entry.status === 'error') tr.className='error';
      for (const value of [entry.line,entry.label,{add:'Tambah',skip:'Lewati',error:'Perbaiki'}[entry.status],entry.message]) {
        const td = document.createElement('td'); td.textContent = value; tr.append(td);
      }
      tbody.append(tr);
    }
    byId('summary').textContent = result.branchName+' · '+counts.add+' tambah · '+counts.skip+' lewati · '+counts.error+' perlu diperbaiki';
    if (counts.add && !counts.error) pending = {...body,branch:result.branch,fingerprint:result.fingerprint};
    review.hidden = false;
    message(counts.error ? 'Perbaiki baris yang ditandai, lalu buat pratinjau baru.' : '');
  } catch(error) { message(error.message); }
  finally { lock(false); }
};

commit.onclick = async () => {
  if (!pending || busy) return;
  if (!confirm('Simpan impor ke cabang tujuan yang tercantum di pratinjau?')) return;
  lock(true);
  try {
    const result = await api('/ops/admin/olsera-import/commit',pending);
    invalidate();
    message('Impor berhasil. '+result.added+' baris ditambahkan ke '+result.branchName+'. Muat ulang katalog di POS.');
  } catch(error) { invalidate(); message(error.message); }
  finally { lock(false); }
};
