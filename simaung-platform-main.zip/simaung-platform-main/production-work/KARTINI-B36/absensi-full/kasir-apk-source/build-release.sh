#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ ! -f android/key.properties ]]; then
  printf '%s\n' 'Siapkan android/key.properties dengan keystore rilis Kasir yang lama.' >&2
  exit 1
fi
sdk="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$sdk" ]]; then
  printf '%s\n' 'Atur ANDROID_HOME ke SDK Android yang sudah terpasang.' >&2
  exit 1
fi
tools="$(find "$sdk/build-tools" -name apksigner -type f | sort -V | tail -1)"
test -n "$tools"
bin="$(dirname "$tools")"
python3 -c 'from PIL import Image'
chmod +x android/gradlew
flutter clean
flutter pub get
flutter build apk --release --build-name 2.4.10 --build-number 15
apk=build/app/outputs/flutter-apk/app-release.apk
python3 verify-apk.py "$apk"
"$bin/aapt" dump badging "$apk" | grep "^package: name='com.tokokartini.kasir' versionCode='15' versionName='2.4.10'"
"$tools" verify --print-certs "$apk" | grep -i 'f46d7fafbc8788458c67672fb18917e73fdb2814dc048f3a4b7d6101a5e44c25'
cp "$apk" Kasir-Simaung-v2.4.10-code15.apk
printf '%s\n' 'Hasil: Kasir-Simaung-v2.4.10-code15.apk'
