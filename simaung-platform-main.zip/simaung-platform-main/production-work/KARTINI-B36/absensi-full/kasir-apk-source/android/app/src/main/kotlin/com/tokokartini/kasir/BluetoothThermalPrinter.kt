package com.tokokartini.kasir

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import androidx.core.app.ActivityCompat
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.UUID

/**
 * Driver ESC/POS thermal Bluetooth NATIF — DIADOPSI dari modul
 * "Modul Thermal Printer Full" (KolekNusambaCiparay) yang sudah terbukti
 * NORMAL mencetak pada APK lain. Dipakai sebagai MESIN CETAK UTAMA APK Kasir
 * Toko Kartini.
 *
 * Prinsip modul (dipertahankan):
 *  - Object singleton (stateless): buka socket SPP → tulis → tutup.
 *  - UUID SPP standar 00001101-0000-1000-8000-00805F9B34FB.
 *  - Menangani permission BLUETOOTH_CONNECT/SCAN (Android 12+).
 *  - Cetak teks ESC/POS (ESC @, ESC ! 0, feed, potong kertas).
 *  - wrap32: word-wrap 32 kolom (dapat disetel untuk kertas 80mm = 48 kolom).
 *
 * Penyempurnaan (dari pelajaran B30 pada APK kasir):
 *  - Tulis per-blok (chunk) + jeda kecil agar buffer printer tidak meluap.
 *  - Jeda singkat setelah connect (settle) dan setelah flush.
 *  - Logo kop struk dicetak sebagai GAMBAR RASTER ESC/POS (GS v 0) yang
 *    dibangkitkan NATIF dari Bitmap (bukan blob base64 dari JavaScript).
 */
object BluetoothThermalPrinter {

    /** UUID Serial Port Profile (SPP) standar printer thermal. */
    val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    // Ukuran blok tulis & jeda (ms) — mencegah gejala "kertas hanya keluar sedikit".
    private const val CHUNK = 128
    private const val CHUNK_DELAY_MS = 12L
    private const val CONNECT_SETTLE_MS = 350L
    private const val FLUSH_SETTLE_MS = 260L

    /** Ambil adapter Bluetooth dari context. */
    fun adapter(context: Context): BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    /** Cek izin Bluetooth (Android 12+ butuh BLUETOOTH_CONNECT/SCAN). */
    fun hasPermission(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else true

    private fun hasConnectPermission(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else true

    private fun canScan(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else true

    /**
     * Cetak teks (ESC/POS) ke printer thermal Bluetooth pada [macAddress].
     * Teks dipecah per baris dan di-word-wrap selebar [wrapWidth] kolom.
     */
    fun printText(
        context: Context,
        macAddress: String,
        lines: List<String>,
        wrapWidth: Int = 32,
        cut: Boolean = true
    ): Boolean {
        val payload = buildTextPayload(lines, wrapWidth, cut)
        return send(context, macAddress, payload)
    }

    /**
     * Cetak struk: logo (opsional, native raster) di kop, lalu teks 32/48 kolom,
     * lalu potong kertas. Inilah jalur utama tombol "Cetak Struk" APK kasir.
     */
    fun printReceipt(
        context: Context,
        macAddress: String,
        text: String,
        wrapWidth: Int,
        logo: Bitmap?,
        cut: Boolean
    ): Boolean {
        val payload = buildReceiptPayload(text, wrapWidth, logo, cut)
        return send(context, macAddress, payload)
    }

    // ---------------------------------------------------------------------
    //  Pengiriman ke socket SPP
    // ---------------------------------------------------------------------

    private fun send(context: Context, macAddress: String, payload: ByteArray): Boolean {
        if (macAddress.isBlank()) return false
        val bt = adapter(context) ?: return false
        if (!bt.isEnabled) return false
        if (!hasConnectPermission(context)) return false

        val device = try { bt.getRemoteDevice(macAddress) } catch (_: Exception) { null } ?: return false
        var socket: BluetoothSocket? = null
        return try {
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            // cancelDiscovery butuh BLUETOOTH_SCAN di Android 12+. Lewati bila belum diberikan
            // agar tidak melempar SecurityException yang membuat cetak tampak "gagal senyap".
            if (canScan(context)) {
                try { bt.cancelDiscovery() } catch (_: SecurityException) {}
            }
            socket.connect()
            Thread.sleep(CONNECT_SETTLE_MS)
            val out = socket.outputStream
            writeChunked(out, payload)
            try { out.flush() } catch (_: Exception) {}
            Thread.sleep(FLUSH_SETTLE_MS)
            true
        } catch (_: Exception) {
            false
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    /** Tulis payload per blok kecil agar buffer printer tidak meluap. */
    private fun writeChunked(o: OutputStream, data: ByteArray) {
        var i = 0
        while (i < data.size) {
            val n = minOf(CHUNK, data.size - i)
            o.write(data, i, n)
            i += n
            if (i < data.size) {
                try { Thread.sleep(CHUNK_DELAY_MS) } catch (_: Exception) {}
            }
        }
    }

    // ---------------------------------------------------------------------
    //  Penyusunan payload ESC/POS
    // ---------------------------------------------------------------------

    private fun buildTextPayload(lines: List<String>, wrapWidth: Int, cut: Boolean): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(ESC_INIT)                       // ESC @  (reset)
        out.write(ESC_FONT_NORMAL)                // ESC ! 0
        writeLines(out, lines, wrapWidth)
        out.write(ESC_FEED)                       // ESC d 3 (feed 3 baris)
        if (cut) out.write(CUT_PARTIAL)           // GS V B 0 (potong sebagian)
        return out.toByteArray()
    }

    private fun buildReceiptPayload(
        text: String,
        wrapWidth: Int,
        logo: Bitmap?,
        cut: Boolean
    ): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(ESC_INIT)                       // ESC @  (reset)
        if (logo != null && logo.width > 0 && logo.height > 0) {
            // B41.3: logo di-render sebagai raster BERLEBAR PENUH kertas dengan logo
            // di TENGAH, dan TANPA perintah ESC a sama sekali. Perintah ESC a (rata
            // kanan/tengah) pada printer murah bisa "nyangkut" ke perintah gambar
            // sehingga logo jatuh ke KANAN. Dengan raster penuh-lebar + tanpa ESC a,
            // printer menaruh gambar mulai tepi KIRI kertas -> logo PASTI di tengah.
            out.write(logoRasterFullWidth(logo, wrapWidth))
            out.write(LF)
        }
        out.write(ESC_FONT_NORMAL)                // ESC ! 0
        val lines = normalizeLines(text, wrapWidth)
        writeLines(out, lines, wrapWidth)
        out.write(ESC_FEED)                       // feed 3 baris
        if (cut) out.write(CUT_PARTIAL)
        return out.toByteArray()
    }

    /** Tulis daftar baris (UTF-8), di-word-wrap selebar [wrapWidth]. */
    private fun writeLines(out: ByteArrayOutputStream, lines: List<String>, wrapWidth: Int) {
        val width = if (wrapWidth in 24..64) wrapWidth else 32
        for (raw in lines) {
            for (w in wrap(raw, width)) {
                out.write(w.toByteArray(Charsets.UTF_8))
                out.write(LF)
            }
        }
    }

    /** Pecah teks multi-baris menjadi baris-baris siap cetak (di-wrap). */
    fun normalizeLines(text: String, wrapWidth: Int): List<String> {
        val width = if (wrapWidth in 24..64) wrapWidth else 32
        val result = ArrayList<String>()
        for (line in text.replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
            val clean = sanitize(line)
            for (w in wrap(clean, width)) result.add(w)
        }
        return result
    }

    /** Buang byte kontrol yang tidak dikenal (kecuali spasi cetak biasa). */
    private fun sanitize(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val c = ch.code
            when {
                c == 0x09 -> sb.append(' ')      // tab -> spasi
                c in 32..0xD7FF -> sb.append(ch) // karakter printable
                else -> sb.append('?')
            }
        }
        return sb.toString()
    }

    /** Word-wrap sederhana: utamakan potong di spasi terdekat. */
    private fun wrap(s: String, max: Int): List<String> {
        if (s.isEmpty()) return listOf("")
        if (s.length <= max) return listOf(s)
        val out = ArrayList<String>()
        var text = s
        while (text.length > max) {
            val chunk = text.substring(0, max)
            val cut = chunk.lastIndexOf(' ').takeIf { it >= 10 } ?: max
            out.add(text.substring(0, cut).trimEnd())
            text = text.substring(cut).trimStart()
        }
        out.add(text)
        return out
    }

    // ---------------------------------------------------------------------
    //  Encoder raster logo (GS v 0) — 1-bit hitam/putih, MSB first
    // ---------------------------------------------------------------------

    /**
     * Ubah Bitmap menjadi perintah cetak gambar ESC/POS "GS v 0".
     * Ambang [threshold] (0..255) menentukan piksel jadi hitam.
     */
    /**
     * B41.3: Bangun raster logo yang SUDAH berisi padding kiri/kanan sehingga lebar
     * gambar = lebar kertas penuh (58mm=384 px, 80mm=576 px). Logo diletakkan tepat
     * di TENGAH, sisa lebar dibiarkan PUTIH (tidak tercetak). Karena lebar gambar
     * sama dengan lebar satu baris kertas, printer akan mulai dari tepi KIRI kertas
     * -> logo otomatis berada di TENGAH tanpa bergantung pada perintah ESC a (yang
     * sering diabaikan / disalahartikan printer murah untuk perintah gambar).
     */
    private fun logoRasterFullWidth(logo: Bitmap, wrapWidth: Int): ByteArray {
        val paperPx = paperWidthPxFor(wrapWidth)
        val centered = if (logo.width < paperPx) centerOnPaper(logo, paperPx) else logo
        return encodeRaster(centered)
    }

    /**
     * Tempel logo di TENGAH kanvas berlebar penuh kertas. Sisa lebar dibiarkan
     * PUTIH (tidak tercetak).
     */
    private fun centerOnPaper(logo: Bitmap, paperWidthPx: Int): Bitmap {
        val pad = ((paperWidthPx - logo.width) / 2).coerceAtLeast(0)
        val totalW = logo.width + pad * 2
        if (totalW <= logo.width) return logo
        val out = Bitmap.createBitmap(totalW, logo.height, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(Color.WHITE)                 // latar putih (tidak tercetak)
        cv.drawBitmap(logo, pad.toFloat(), 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /** Lebar kertas (px @203dpi) dari jumlah kolom font A: 32 -> 58mm (384), 48 -> 80mm (576). */
    private fun paperWidthPxFor(wrapWidth: Int): Int = if (wrapWidth >= 40) 576 else 384

    fun encodeRaster(bitmap: Bitmap, threshold: Int = 160): ByteArray {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return ByteArray(0)
        val bytesPerRow = (w + 7) / 8
        val data = ByteArray(bytesPerRow * h)
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        for (y in 0 until h) {
            val rowBase = y * bytesPerRow
            val pixBase = y * w
            for (x in 0 until w) {
                val p = pixels[pixBase + x]
                val a = (p ushr 24) and 0xFF
                val lum: Int = if (a < 128) {
                    255 // transparan dianggap putih
                } else {
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    (r * 299 + g * 587 + b * 114) / 1000
                }
                if (lum < threshold) {
                    val bytePos = rowBase + (x shr 3)
                    data[bytePos] = (data[bytePos].toInt() or (0x80 shr (x and 7))).toByte()
                }
            }
        }
        val header = byteArrayOf(
            0x1D, 0x76, 0x30, 0x00,                          // GS v 0 m=0
            (bytesPerRow and 0xFF).toByte(), ((bytesPerRow shr 8) and 0xFF).toByte(),
            (h and 0xFF).toByte(), ((h shr 8) and 0xFF).toByte()
        )
        return header + data
    }

    // ---------------------------------------------------------------------
    //  Konstanta ESC/POS
    // ---------------------------------------------------------------------

    private val ESC_INIT = byteArrayOf(0x1B, 0x40)            // ESC @
    private val ESC_FONT_NORMAL = byteArrayOf(0x1B, 0x21, 0x00) // ESC ! 0
    private val ESC_ALIGN_LEFT = byteArrayOf(0x1B, 0x61, 0x00)   // ESC a 0
    private val ESC_ALIGN_CENTER = byteArrayOf(0x1B, 0x61, 0x01) // ESC a 1
    private val ESC_FEED = byteArrayOf(0x1B, 0x64, 0x03)        // ESC d 3
    private val CUT_PARTIAL = byteArrayOf(0x1D, 0x56, 0x42, 0x00) // GS V B 0
    private val LF = byteArrayOf(0x0A)
}
