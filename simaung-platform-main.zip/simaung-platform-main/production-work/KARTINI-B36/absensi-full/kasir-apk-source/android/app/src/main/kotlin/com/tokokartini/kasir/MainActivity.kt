package com.tokokartini.kasir

import android.content.Intent
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Activity utama + jembatan modul cetak thermal Bluetooth NATIVE (tanpa RawBT).
 *
 * Menyediakan MethodChannel "kasir/printer" untuk Flutter, yang kemudian
 * diteruskan ke halaman POS (WebView) lewat JavaScriptChannel "KasirPrinter".
 */
class MainActivity : FlutterActivity() {

    private val channelName = "kasir/printer"
    private lateinit var printer: BluetoothPrinter

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        printer = BluetoothPrinter(this)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isSupported" -> result.success(true)
                    // B41.3: laporkan versi APK yang BENAR-BENAR terpasang di tablet.
                    // Berguna untuk memastikan pengguna sudah memasang APK terbaru
                    // (perbaikan logo struk ada di sisi NATIF, jadi butuh reinstall).
                    "appVersion" -> {
                        val ver = try {
                            val pi = packageManager.getPackageInfo(packageName, 0)
                            @Suppress("DEPRECATION")
                            val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                                pi.longVersionCode
                            } else {
                                pi.versionCode.toLong()
                            }
                            mapOf("ok" to true, "version" to (pi.versionName ?: "-"), "code" to code)
                        } catch (_: Exception) {
                            mapOf("ok" to true, "version" to "-", "code" to 0L)
                        }
                        result.success(ver)
                    }
                    "hasPermission" -> result.success(printer.hasPermission())
                    "requestPermission" -> { printer.requestPermission(); result.success(true) }
                    "isEnabled" -> result.success(printer.isEnabled())
                    "isConnected" -> result.success(printer.isConnected())
                    "listPaired" -> result.success(printer.listPaired())
                    "connect" -> {
                        val address = call.argument<String>("address") ?: ""
                        printer.connect(address) { ok, msg -> result.success(mapOf("ok" to ok, "message" to msg)) }
                    }
                    "disconnect" -> { printer.disconnect(); result.success(true) }
                    "print" -> {
                        val text = call.argument<String>("text") ?: ""
                        val address = call.argument<String>("address")
                        val cut = call.argument<Boolean>("cut") ?: true
                        printer.printText(text, address, cut) { ok, msg -> result.success(mapOf("ok" to ok, "message" to msg)) }
                    }
                    "printReceipt" -> {
                        // B39.1: cetak STRUK dengan kop berlogo Kartini.
                        // Logo di-render NATIF (raster ESC/POS) oleh modul printer,
                        // bukan lagi blob base64 dari JavaScript (jalur lama yang
                        // membuat banyak printer macet/tidak mencetak).
                        val text = call.argument<String>("text") ?: ""
                        val address = call.argument<String>("address")
                        val paper = call.argument<String>("paper")
                        val logo = call.argument<Boolean>("logo") ?: true
                        val cut = call.argument<Boolean>("cut") ?: true
                        printer.printReceipt(text, address, paper, logo, cut, call.argument<String>("outletCode")) { ok, msg ->
                            result.success(mapOf("ok" to ok, "message" to msg))
                        }
                    }
                    "printRaw" -> {
                        // Kompatibilitas web LIVE versi B39: byte ESC/POS mentah
                        // (termasuk blob raster logo). Teks diekstrak lalu dicetak
                        // ulang via jalur LOGO NATIF, sehingga web B39 yang masih
                        // live pun langsung dapat logo tanpa raster bermasalah.
                        val raw = call.argument<List<Int>>("bytes")
                        val bytes = raw?.let { lst -> ByteArray(lst.size) { i -> lst[i].toByte() } }
                        val address = call.argument<String>("address")
                        val cut = call.argument<Boolean>("cut") ?: true
                        printer.printLegacyRaster(bytes, address, cut) { ok, msg ->
                            result.success(mapOf("ok" to ok, "message" to msg))
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
