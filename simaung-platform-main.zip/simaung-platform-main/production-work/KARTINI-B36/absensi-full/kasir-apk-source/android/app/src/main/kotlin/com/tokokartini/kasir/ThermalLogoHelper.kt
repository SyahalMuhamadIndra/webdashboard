package com.tokokartini.kasir

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import androidx.annotation.DrawableRes

/**
 * Helper logo untuk cetak thermal — DIADOPSI & DIPERLUAS dari modul
 * "Modul Thermal Printer Full" (ThermalLogoHelper.optimizeForThermal).
 *
 * Fungsi utama:
 *  - [optimizeForThermal]: pangkas tepi transparan + resize + grayscale +
 *    tambah kontras, lalu komposit di atas latar PUTIH (agar area transparan
 *    tidak jadi hitam).
 *  - [logoBitmap]: logo kop siap-pakai + cache memori (logo Kartini bawaan
 *    @drawable/kop_logo).
 *
 * B40.1: lebar default diperkecil (maks 192 px ~= 24 mm pada 203 dpi) agar logo
 * TIDAK lagi mendominasi struk — sama untuk semua lebar kertas (57/58/80 mm).
 *
 * B41.1: diperkecil LAGI (maks 96 px ~= 12 mm pada 203 dpi) karena hasil cetak
 * lapangan menunjukkan logo masih terlalu besar (~40% lebar kertas 57/58 mm).
 * Ukuran ini tetap KONSISTEN untuk semua lebar kertas (57/58/80 mm).
 *
 * Bitmap hasil TIDAK di-binarisasi di sini; binarisasi 1-bit dilakukan oleh
 * [BluetoothThermalPrinter.encodeRaster] memakai ambang (threshold).
 */
object ThermalLogoHelper {

    /** Lebar maksimum logo (px) untuk kepala struk — konsisten semua ukuran kertas. */
    const val DEFAULT_LOGO_WIDTH_PX = 96

    @Volatile
    private var cache: Bitmap? = null

    /** Logo kop struk siap cetak, dengan cache memori. */
    fun logoBitmap(context: Context, maxWidthPx: Int = DEFAULT_LOGO_WIDTH_PX): Bitmap? {
        cache?.let { if (it.width <= maxWidthPx && !it.isRecycled) return it }
        val bmp = optimizeForThermal(context, R.drawable.kop_logo, maxWidthPx)
        if (bmp != null) cache = bmp
        return bmp
    }

    /**
     * Pangkas tepi transparan -> resize -> grayscale + kontras, komposit di atas putih.
     * Hasil: bitmap ARGB siap dikonversi ke raster 1-bit.
     */
    fun optimizeForThermal(context: Context, @DrawableRes resId: Int, maxWidthPx: Int): Bitmap? {
        val decoded = try {
            BitmapFactory.decodeResource(context.resources, resId)
        } catch (_: Exception) {
            null
        } ?: return null

        if (decoded.width <= 0 || decoded.height <= 0) return null

        // Pangkas tepi transparan lebih dulu supaya logo tampak pas (tanpa margin kosong).
        val src = cropOpaque(decoded)
        if (src.width <= 0 || src.height <= 0) return null

        val targetW = maxWidthPx.coerceAtLeast(48)
        val scale = targetW.toFloat() / src.width.toFloat()
        val targetH = (src.height * scale).toInt().coerceAtLeast(16)
        val scaled = Bitmap.createScaledBitmap(src, targetW, targetH, true)

        val out = Bitmap.createBitmap(scaled.width, scaled.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)

        // grayscale + sedikit kontras
        val contrast = 1.15f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val cm = ColorMatrix().apply {
            setSaturation(0f)
            postConcat(
                ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, translate,
                        0f, contrast, 0f, 0f, translate,
                        0f, 0f, contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
            isFilterBitmap = true
        }

        canvas.drawColor(Color.WHITE)            // latar putih (transparan -> putih)
        canvas.drawBitmap(scaled, 0f, 0f, paint)
        if (scaled !== src) scaled.recycle()
        if (src !== decoded) src.recycle()
        return out
    }

    /** Pangkas batas piksel tidak-transparan (dengan sedikit padding), aman untuk logo latar transparan. */
    private fun cropOpaque(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= 0 || h <= 0) return src
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var left = w; var top = h; var right = -1; var bottom = -1
        val alphaMin = 16
        for (y in 0 until h) {
            val base = y * w
            for (x in 0 until w) {
                if (((px[base + x] ushr 24) and 0xFF) > alphaMin) {
                    if (x < left) left = x
                    if (x > right) right = x
                    if (y < top) top = y
                    if (y > bottom) bottom = y
                }
            }
        }
        if (right < left || bottom < top) return src // sepenuhnya transparan -> biarkan
        val pad = 2
        left = (left - pad).coerceAtLeast(0)
        top = (top - pad).coerceAtLeast(0)
        right = (right + pad).coerceAtMost(w - 1)
        bottom = (bottom + pad).coerceAtMost(h - 1)
        val cw = right - left + 1
        val ch = bottom - top + 1
        if (cw <= 0 || ch <= 0 || (cw == w && ch == h)) return src
        return try {
            Bitmap.createBitmap(src, left, top, cw, ch)
        } catch (_: Exception) {
            src
        }
    }
}
