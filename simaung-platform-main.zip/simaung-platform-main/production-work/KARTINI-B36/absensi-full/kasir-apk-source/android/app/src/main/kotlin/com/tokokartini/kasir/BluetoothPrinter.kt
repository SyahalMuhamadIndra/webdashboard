package com.tokokartini.kasir

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Modul cetak thermal Bluetooth NATIVE untuk APK Tablet Toko Kartini.
 * Menggantikan kebutuhan aplikasi pihak ketiga (RawBT).
 *
 * B39.1 (perombakan): mesin cetak kini memakai driver modul
 * [BluetoothThermalPrinter] (hasil adopsi modul thermal yang terbukti normal),
 * termasuk LOGO KOP STRUK yang dicetak sebagai gambar raster ESC/POS yang
 * dibangkitkan NATIF (bukan lagi blob base64 dari JavaScript — jalur lama ini
 * membuat banyak printer macet/tidak mencetak).
 *
 * Class ini menyediakan: izin Bluetooth, daftar printer terpasang, sambung,
 * serta cetak teks & cetak struk (dengan logo) di atas driver tersebut.
 */
class BluetoothPrinter(private val activity: Activity) {

    companion object {
        const val PERM_REQUEST = 4101
    }

    private val adapter: BluetoothAdapter? by lazy {
        (activity.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    }
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null
    private var currentAddress: String? = null
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    /** Cek izin Bluetooth (Android 12+ butuh BLUETOOTH_CONNECT/SCAN). */
    fun hasPermission(): Boolean {
        val ctx = activity
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(
                activity,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN),
                PERM_REQUEST
            )
        }
    }

    fun isEnabled(): Boolean = adapter?.isEnabled == true

    fun isConnected(): Boolean = socket?.isConnected == true

    /** Daftar printer Bluetooth yang sudah dipasangkan (bonded/paired). */
    @SuppressLint("MissingPermission")
    fun listPaired(): List<Map<String, String>> {
        val a = adapter ?: return emptyList()
        if (!hasPermission()) return emptyList()
        return try {
            a.bondedDevices.map { d ->
                mapOf(
                    "name" to (safeName(d) ?: "Tanpa nama"),
                    "address" to d.address
                )
            }
        } catch (e: SecurityException) { emptyList() }
    }

    @SuppressLint("MissingPermission")
    private fun safeName(d: BluetoothDevice): String? = try { d.name } catch (e: SecurityException) { null }

    /** Pratinjau koneksi cepat ke printer (dipakai tombol "Uji Sambung"). */
    fun connect(address: String, onDone: (Boolean, String) -> Unit) {
        val a = adapter
        if (a == null) { done(onDone, false, "Bluetooth tidak tersedia di perangkat ini."); return }
        if (!a.isEnabled) { done(onDone, false, "Bluetooth mati. Nyalakan Bluetooth lalu coba lagi."); return }
        if (!hasPermission()) { requestPermission(); done(onDone, false, "Izin Bluetooth diperlukan. Setujui izin lalu coba lagi."); return }
        io.execute {
            try {
                closeSocket()
                val dev = a.getRemoteDevice(address)
                val s = dev.createRfcommSocketToServiceRecord(BluetoothThermalPrinter.SPP_UUID)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || hasPermission()) {
                    try { a.cancelDiscovery() } catch (_: Exception) {}
                }
                s.connect()
                socket = s
                out = s.outputStream
                currentAddress = address
                done(onDone, true, "Terhubung ke ${safeName(a.getRemoteDevice(address)) ?: address}")
            } catch (e: Exception) {
                closeSocket()
                done(onDone, false, "Gagal menyambung printer: ${e.message ?: "tidak diketahui"}")
            }
        }
    }

    fun disconnect() { io.execute { closeSocket() } }

    /**
     * Cetak TEKS ESC/POS sederhana (uji cetak / fallback).
     * Menggunakan driver modul [BluetoothThermalPrinter].
     */
    fun printText(text: String, address: String?, cut: Boolean, onDone: (Boolean, String) -> Unit) {
        val addr = resolveAddressOrFail(address, onDone) ?: return
        // Hormati lebar teks yang sudah disusun di sisi JS: jangan re-wrap
        // (kalau tidak, layout 48 kolom kertas 80mm bisa terpecah).
        val maxLen = text.replace("\r\n", "\n").split('\n').maxOfOrNull { it.length } ?: 32
        val width = maxLen.coerceIn(32, 64)
        io.execute {
            val ok = BluetoothThermalPrinter.printText(
                context = activity,
                macAddress = addr,
                lines = text.replace("\r\n", "\n").split('\n'),
                wrapWidth = width,
                cut = cut
            )
            done(onDone, ok, if (ok) "Teks dikirim ke printer." else printerErrorHint())
        }
    }

    /**
     * Cetak STRUK (kop berlogo + teks 32/48 kolom + potong kertas).
     * [paper] = "80" -> 48 kolom, selain itu 32 kolom.
     * [includeLogo] = true -> sisipkan logo Kartini sebagai gambar raster.
     *
     * Bila cetak raster logo gagal (printer tertentu menolak GS v), otomatis
     * dicoba ulang TANPA logo supaya struk tetap keluar.
     */
    fun printReceipt(
        text: String,
        address: String?,
        paper: String?,
        includeLogo: Boolean,
        cut: Boolean,
        outletCode: String? = null,
        onDone: (Boolean, String) -> Unit
    ) {
        val addr = resolveAddressOrFail(address, onDone) ?: return
        val width = if (paper == "80") 48 else 32
        // B40.1: logo diperkecil (maks 192 px ~= 24 mm) agar tidak mendominasi
        // struk — konsisten untuk kertas 57/58/80 mm.
        val drawable = when (outletCode) {
            "CHERRY-BAKES-HOUSE" -> R.drawable.receipt_cherry_bakes_house
            "TK-KARTINI" -> R.drawable.receipt_tk_kartini
            "MAJA-KOFFIE" -> R.drawable.receipt_maja_koffie
            "RM-SINDANG-HURIP" -> R.drawable.receipt_rm_sindang_hurip
            "SWEET-ESCAPE" -> R.drawable.receipt_sweet_escape
            else -> null
        }
        val logo = when {
            !includeLogo -> null
            drawable != null -> ThermalLogoHelper.optimizeForThermal(activity, drawable, 176)
            else -> ThermalLogoHelper.logoBitmap(activity)
        }
        io.execute {
            var ok = BluetoothThermalPrinter.printReceipt(
                context = activity,
                macAddress = addr,
                text = text,
                wrapWidth = width,
                logo = logo,
                cut = cut
            )
            if (!ok && logo != null) {
                // Coba lagi tanpa logo (sebagian printer tidak mendukung gambar raster via BT).
                try { Thread.sleep(250) } catch (_: Exception) {}
                ok = BluetoothThermalPrinter.printReceipt(
                    context = activity,
                    macAddress = addr,
                    text = text,
                    wrapWidth = width,
                    logo = null,
                    cut = cut
                )
                if (ok) { done(onDone, true, "Struk dicetak (tanpa logo — printer menolak gambar)."); return@execute }
            }
            done(onDone, ok, if (ok) "Struk dikirim ke printer." else printerErrorHint())
        }
    }

    /**
     * KOMPATIBILITAS B39 (jalur lama): web versi B39 memanggil printRaw dengan
     * byte ESC/POS mentah berisi logo raster (GS v 0) + teks struk. Alih-alih
     * mengirim raster itu apa adanya (inilah jalur yang membuat printer macet),
     * kita EKSTRAK teksnya lalu cetak ulang memakai jalur printReceipt dengan
     * LOGO NATIF. Hasil: web B39 yang masih live pun langsung dapat logo.
     */
    fun printLegacyRaster(bytes: ByteArray?, address: String?, cut: Boolean, onDone: (Boolean, String) -> Unit) {
        val text = extractTextFromLegacy(bytes)
        if (text.isNullOrBlank()) {
            // Bukan struktur yang dikenali — jangan kirim raster; minta uji ulang.
            done(onDone, false, "Data struk tidak dikenali. Perbarui ke versi terbaru.")
            return
        }
        val width = text.split('\n').maxOfOrNull { it.length }?.coerceIn(32, 64) ?: 32
        val paper = if (width >= 48) "80" else "58"
        printReceipt(text, address, paper, true, cut, onDone = onDone)
    }

    /** Ambil teks dari payload B39: [ESC @][GS v 0 raster][LF][teks][feed][GS V B 0]. */
    private fun extractTextFromLegacy(bytes: ByteArray?): String? {
        val b = bytes ?: return null
        if (b.isEmpty()) return null
        var i = 0
        // lewati ESC @
        if (i + 1 < b.size && b[i] == 0x1B.toByte() && b[i + 1] == 0x40.toByte()) i += 2
        // lewati gambar raster GS v 0 (bila ada)
        if (i + 7 < b.size && b[i] == 0x1D.toByte() && b[i + 1] == 0x76.toByte() && b[i + 2] == 0x30.toByte()) {
            val w = (b[i + 4].toInt() and 0xFF) or ((b[i + 5].toInt() and 0xFF) shl 8)
            val h = (b[i + 6].toInt() and 0xFF) or ((b[i + 7].toInt() and 0xFF) shl 8)
            i += 8 + (w * h)
        }
        if (i >= b.size) return null
        // lewati satu LF setelah logo
        if (b[i] == 0x0A.toByte()) i += 1
        // buang feed + potong kertas di ekor (…0A,1D 56 42 00)
        var end = b.size
        if (end - 4 >= i && b[end - 4] == 0x1D.toByte() && b[end - 3] == 0x56.toByte() &&
            b[end - 2] == 0x42.toByte() && b[end - 1] == 0x00.toByte()
        ) {
            var e = end - 4
            var lf = 0
            while (e - 1 >= i && b[e - 1] == 0x0A.toByte() && lf < 8) { e--; lf++ }
            end = e
        }
        if (end <= i) return null
        return String(b, i, end - i, Charsets.UTF_8)
    }

    private fun printerErrorHint(): String =
        "Gagal mencetak. Pastikan printer menyala, terpasang (paired), dan Bluetooth aktif."

    /** Ambil alamat printer; bila kosong, laporkan lewat callback & kembalikan null. */
    private fun resolveAddressOrFail(address: String?, onDone: (Boolean, String) -> Unit): String? {
        val addr = (address ?: "").ifBlank { currentAddress ?: "" }
        if (addr.isBlank()) {
            done(onDone, false, "Alamat printer belum diatur. Pilih printer di Pengaturan.")
            return null
        }
        val a = adapter
        if (a == null || !a.isEnabled) { done(onDone, false, "Bluetooth tidak aktif."); return null }
        if (!hasPermission()) { requestPermission(); done(onDone, false, "Izin Bluetooth diperlukan."); return null }
        return addr
    }

    private fun closeSocket() {
        try { out?.flush() } catch (_: Exception) {}
        try { out?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        out = null; socket = null; currentAddress = null
    }

    private fun done(cb: (Boolean, String) -> Unit, ok: Boolean, msg: String) {
        ui.post { cb(ok, msg) }
    }
}
