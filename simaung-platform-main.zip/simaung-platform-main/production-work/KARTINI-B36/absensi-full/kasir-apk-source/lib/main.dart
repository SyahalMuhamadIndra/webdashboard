import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

/// Jembatan ke modul cetak thermal Bluetooth NATIVE (Bluetooth SPP + ESC/POS).
/// Tidak memakai aplikasi pihak ketiga (mis. RawBT).
class NativePrinter {
  static const MethodChannel _ch = MethodChannel('kasir/printer');

  static Future<Map<String, dynamic>> _call(String method,
      [Map<String, dynamic>? args]) async {
    try {
      final res = await _ch.invokeMethod(method, args);
      if (res is Map) return Map<String, dynamic>.from(res);
      return {'ok': res == true, 'message': ''};
    } catch (e) {
      return {'ok': false, 'message': 'Modul printer tidak tersedia: $e'};
    }
  }

  static Future<bool> hasPermission() async =>
      (await _call('hasPermission'))['ok'] == true;
  static Future<bool> isEnabled() async =>
      (await _call('isEnabled'))['ok'] == true;
  static Future<List<Map<String, dynamic>>> listPaired() async {
    try {
      final res = await _ch.invokeMethod('listPaired');
      if (res is List) {
        return res.map((e) => Map<String, dynamic>.from(e as Map)).toList();
      }
    } catch (_) {}
    return [];
  }

  static Future<Map<String, dynamic>> connect(String address) =>
      _call('connect', {'address': address});
  /// B41.3: versi APK yang benar-benar terpasang (untuk cek "sudah update?").
  static Future<Map<String, dynamic>> appVersion() => _call('appVersion');
  static Future<Map<String, dynamic>> print(String text, String? address,
          {bool cut = true}) =>
      _call('print', {'text': text, 'address': address, 'cut': cut});
  /// B39.1: cetak STRUK — teks 32/48 kolom + kop berlogo Kartini.
  /// Logo di-render NATIF (raster ESC/POS) di sisi Kotlin memakai modul
  /// printer yang terbukti normal; tidak lagi mengirim blob raster dari JS.
  static Future<Map<String, dynamic>> printReceipt(
          String text, String? address,
          {String? paper, bool logo = true, bool cut = true, String? outletCode}) =>
      _call('printReceipt', {
        'text': text,
        'address': address,
        'paper': paper,
        'logo': logo,
        'outletCode': outletCode,
        'cut': cut
      });
  /// Kompatibilitas web LIVE versi B39: terima byte ESC/POS mentah, lalu sisi
  /// native mengekstrak teksnya dan mencetak ulang memakai LOGO NATIF.
  static Future<Map<String, dynamic>> printRaw(List<int> bytes, String? address,
          {bool cut = true}) =>
      _call('printRaw', {'bytes': bytes, 'address': address, 'cut': cut});
  static Future<void> requestPermission() => _call('requestPermission');
}

/// Aplikasi Kasir (POS) Toko Kartini — versi tablet Android.
///
/// Aplikasi ini adalah "shell" native (APK) yang menampilkan aplikasi kasir
/// berbasis web (https://pos.simaung.com) di dalam WebView, sehingga
/// terasa seperti aplikasi Android asli: ada ikon peluncur sendiri, mode
/// layar penuh, dan tanpa kolom alamat browser.
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const KasirApp());
}

const String kKasirUrl = 'https://pos.simaung.com/';
const Color kBrand = Color(0xFF0A5A2C);

class KasirApp extends StatelessWidget {
  const KasirApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kasir Toko Kartini',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: kBrand),
        useMaterial3: true,
      ),
      home: const KasirWebView(),
    );
  }
}

class KasirWebView extends StatefulWidget {
  const KasirWebView({super.key});

  @override
  State<KasirWebView> createState() => _KasirWebViewState();
}

class _KasirWebViewState extends State<KasirWebView> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();

    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0B3D22))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (mounted) setState(() => _loading = true);
          },
          onPageFinished: (_) {
            if (mounted) setState(() { _loading = false; _hasError = false; });
            _injectNativeBridge();
          },
          onWebResourceError: (error) {
            // Hanya tampilkan layar galat untuk navigasi utama (bukan aset).
            if (error.isForMainFrame == true && mounted) {
              setState(() { _loading = false; _hasError = true; });
            }
          },
        ),
      )
      ..addJavaScriptChannel('KasirNative', onMessageReceived: _onNativeMessage);

    // WebView Android: pastikan selalu memuat versi TERBARU dari server
    // (hindari halaman basi tersimpan di cache WebView).
    if (controller.platform is AndroidWebViewController) {
      final android = controller.platform as AndroidWebViewController;
      android.setMediaPlaybackRequiresUserGesture(false);
      android.setMixedContentMode(MixedContentMode.compatibilityMode);
      // Bersihkan cache WebView agar HTML/JS POS selalu segar dari jaringan.
      android.clearCache();
    }

    controller.loadRequest(Uri.parse(kKasirUrl));
    _controller = controller;
  }

  /// Pesan dari halaman POS (WebView) -> diteruskan ke modul printer native.
  Future<void> _onNativeMessage(JavaScriptMessage message) async {
    Map<String, dynamic> req = {};
    try {
      req = Map<String, dynamic>.from(jsonDecode(message.message) as Map);
    } catch (_) {
      return;
    }
    final id = req['id'];
    final action = req['action'];
    Map<String, dynamic> res = {'ok': false, 'message': 'Aksi tidak dikenal'};
    switch (action) {
      case 'hasPermission':
        res = {'ok': await NativePrinter.hasPermission(), 'message': ''};
        break;
      case 'requestPermission':
        await NativePrinter.requestPermission();
        res = {'ok': true, 'message': 'Izin diminta'};
        break;
      case 'isEnabled':
        res = {'ok': await NativePrinter.isEnabled(), 'message': ''};
        break;
      case 'listPaired':
        final list = await NativePrinter.listPaired();
        res = {'ok': true, 'items': list};
        break;
      case 'connect':
        res = await NativePrinter.connect('${req['address'] ?? ''}');
        break;
      case 'print':
        res = await NativePrinter.print(
          '${req['text'] ?? ''}',
          req['address']?.toString(),
          cut: req['cut'] != false,
        );
        break;
      case 'printReceipt':
        res = await NativePrinter.printReceipt(
          '${req['text'] ?? ''}',
          req['address']?.toString(),
          paper: req['paper']?.toString(),
          logo: req['logo'] != false,
          outletCode: req['outletCode']?.toString(),
          cut: req['cut'] != false,
        );
        break;
      case 'printRaw':
        // Kompatibilitas web LIVE B39 (blob raster) -> dikonversi ke logo natif.
        final raw = ((req['bytes'] as List?) ?? const [])
            .map((e) => int.tryParse('$e') ?? 0)
            .toList();
        res = await NativePrinter.printRaw(
          raw,
          req['address']?.toString(),
          cut: req['cut'] != false,
        );
        break;
      case 'appVersion':
        res = await NativePrinter.appVersion();
        break;
    }
    final payload = jsonEncode({'id': id, ...res});
    final js = "window.__kasirNativeResult && window.__kasirNativeResult($payload);";
    _controller.runJavaScript(js);
  }

  /// Suntikkan jembatan JS ke halaman POS agar tombol "Uji Bluetooth"
  /// memakai printer native APK (bukan RawBT).
  void _injectNativeBridge() {
    const js = r'''
(function(){
  if (window.KasirNativePort || !window.KasirNative) return;
  var _cb = {}, _seq = 0;
  window.__kasirNativeResult = function(res){
    var f = _cb[res.id]; if (f) { delete _cb[res.id]; f(res); }
  };
  function call(action, extra){
    return new Promise(function(resolve){
      var id = 'c' + (++_seq);
      _cb[id] = resolve;
      window.KasirNative.postMessage(JSON.stringify(Object.assign({id:id, action:action}, extra||{})));
      setTimeout(function(){ if(_cb[id]){ delete _cb[id]; resolve({ok:false,message:'timeout'}); } }, 12000);
    });
  }
  window.KasirNativePort = {
    available: true,
    hasPermission: function(){ return call('hasPermission'); },
    requestPermission: function(){ return call('requestPermission'); },
    isEnabled: function(){ return call('isEnabled'); },
    listPaired: function(){ return call('listPaired'); },
    connect: function(address){ return call('connect', {address:address}); },
    print: function(text, address, cut){ return call('print', {text:text, address:address||'', cut:cut!==false}); },
    outletReceiptLogos: true,
    printReceipt: function(text, address, paper, logo, cut, outletCode){ return call('printReceipt', {text:text, address:address||'', paper:paper||'', logo:logo!==false, cut:cut!==false, outletCode:outletCode||''}); },
    /* Kompatibilitas web LIVE B39: byte mentah (blob raster) -> native memakai logo natif. */
    printRaw: function(bytes, address, cut){ return call('printRaw', {bytes:bytes||[], address:address||'', cut:cut!==false}); },
    /* B41.3: versi APK terpasang — untuk memastikan perbaikan native sudah aktif. */
    appVersion: function(){ return call('appVersion'); }
  };
})();
''';
    _controller.runJavaScript(js);
  }

  Future<bool> _handleBack() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    return true;
  }

  void _reload() {
    setState(() { _hasError = false; _loading = true; });
    final platform = _controller.platform;
    if (platform is AndroidWebViewController) {
      platform.clearCache();
    }
    _controller.loadRequest(Uri.parse(kKasirUrl));
  }

  @override
  Widget build(BuildContext context) {
    // Rahasia: klik-logo 7x -> buka menu admin (sama seperti di aplikasi web).
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final shouldExit = await _handleBack();
        if (shouldExit) {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0B3D22),
        body: SafeArea(
          child: Stack(
            children: [
              if (!_hasError)
                WebViewWidget(controller: _controller),
              if (_hasError)
                _ErrorView(onRetry: _reload),
              if (_loading && !_hasError)
                const _LoadingOverlay(),
            ],
          ),
        ),
      ),
    );
  }
}

class _LoadingOverlay extends StatelessWidget {
  const _LoadingOverlay();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF0B3D22),
      child: const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 42,
              height: 42,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF2F9C5D)),
              ),
            ),
            SizedBox(height: 18),
            Text(
              'Kasir Toko Kartini',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 4),
            Text(
              'Menyiapkan aplikasi kasir…',
              style: TextStyle(color: Colors.white70, fontSize: 12.5),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF0B3D22),
      padding: const EdgeInsets.all(28),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded, color: Colors.white70, size: 56),
            const SizedBox(height: 16),
            const Text(
              'Tidak dapat terhubung',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Pastikan tablet terhubung ke internet, lalu coba lagi.\n($kKasirUrl)',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white60, fontSize: 13, height: 1.5),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Coba Lagi'),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF2F9C5D),
                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
