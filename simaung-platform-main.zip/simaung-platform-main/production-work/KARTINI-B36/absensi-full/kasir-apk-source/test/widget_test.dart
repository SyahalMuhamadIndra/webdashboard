// Uji dasar: memastikan aplikasi Kasir Toko Kartini dapat dirender.
import 'package:flutter_test/flutter_test.dart';

import 'package:kasir_kartini/main.dart';

void main() {
  testWidgets('App dapat dibangun tanpa error', (WidgetTester tester) async {
    await tester.pumpWidget(const KasirApp());
    // Aplikasi menampilkan judul kasir pada material app.
    expect(find.text('Kasir Toko Kartini'), findsWidgets);
  });
}
