from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import hashlib
import io
import sys

ROOT = Path(__file__).resolve().parent
RES = ROOT / 'android/app/src/main/res'
APK = Path(sys.argv[1])

def pixels(image):
    # AAPT2 can clear RGB channels when alpha is zero. Those channels are invisible.
    rgba = bytearray(image.convert('RGBA').tobytes())
    for offset in range(0, len(rgba), 4):
        if rgba[offset + 3] == 0:
            rgba[offset:offset + 3] = b'\x00\x00\x00'
    return image.size, hashlib.sha256(rgba).digest()

def check(condition, message):
    if not condition:
        raise SystemExit(message)

expected = {}
for path in [*(RES / 'drawable-nodpi').glob('receipt_*.png'), RES / 'drawable/kop_logo.png']:
    with Image.open(path) as image:
        expected[pixels(image)] = path.name
check(len(expected) == 6, 'Source harus berisi lima logo outlet dan logo bawaan Simaung.')

with ZipFile(APK) as apk:
    check(apk.testzip() is None, 'APK gagal pemeriksaan CRC.')
    names = apk.namelist()
    libs = [name for name in names if name.endswith('/libapp.so')]
    check(bool(libs), 'Library Flutter release tidak ditemukan.')
    for name in libs:
        compiled = apk.read(name)
        for marker in ('https://pos.simaung.com/', 'outletReceiptLogos', 'outletCode'):
            check(marker.encode() in compiled or marker.encode('utf-16le') in compiled,
                  f'{name}: penanda hilang: {marker}')
    dex = b''.join(apk.read(name) for name in names if name.endswith('.dex'))
    check(b'TK-KARTINI' in dex, 'Kode outlet TK-KARTINI hilang dari modul native.')
    found = set()
    for name in names:
        if not name.startswith('res/') or not name.endswith('.png'):
            continue
        with Image.open(io.BytesIO(apk.read(name))) as image:
            match = expected.get(pixels(image))
        if match:
            found.add(match)
    check(found == set(expected.values()),
          'Logo tidak lengkap: ' + ', '.join(sorted(set(expected.values()) - found)))
print('APK lolos verifikasi alamat POS, bridge Flutter, routing native dan enam aset logo.')
