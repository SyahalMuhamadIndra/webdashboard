import type {Express,RequestHandler} from 'express';
import type {Pool} from 'pg';

export const ownerFinanceSchema=`
CREATE TABLE IF NOT EXISTS business_settlement_reviews (
 company_id uuid NOT NULL REFERENCES companies(id), branch_id uuid NOT NULL REFERENCES branches(id),
 pos_day date NOT NULL, method text NOT NULL, version integer NOT NULL CHECK(version>0),
 received numeric(18,2) NOT NULL CHECK(received>=0), fee numeric(18,2) NOT NULL CHECK(fee>=0),
 evidence text NOT NULL, reason text NOT NULL, actor uuid NOT NULL, updated_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(company_id,branch_id,pos_day,method,version)
);
CREATE TABLE IF NOT EXISTS business_owner_months (
 company_id uuid NOT NULL REFERENCES companies(id), month date NOT NULL, version integer NOT NULL CHECK(version>0),
 report jsonb NOT NULL, reason text NOT NULL, actor uuid NOT NULL, approved_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(company_id,month,version)
);`;
const modes=['QRIS','TRANSFER','DEBIT','CREDIT','EWALLET','E-WALLET'];
const short=(x:unknown)=>typeof x==='string'?x.trim():'';
const date=(x:string)=>/^20\d{2}-\d{2}-\d{2}$/.test(x)&&Number.isFinite(Date.parse(x))&&new Date(x+'T00:00:00Z').toISOString().slice(0,10)===x;
const day=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const uuid=/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
const money=(v:unknown)=>typeof v==='number'&&Number.isSafeInteger(v)&&v>=0&&v<=999999999999999;
const root='/api/admin/business-reports/owner-finance';

export function mountOwnerFinance(app:Express,pool:Pool,auth:RequestHandler,access:RequestHandler,ensure:()=>Promise<unknown>){
 const group:RequestHandler=(_req,res,next)=>{
  if(!['SYSTEM_ADMIN','OWNER','FINANCE'].includes(res.locals.reportAccess.role)||res.locals.reportAccess.unit!=='all')
   return res.status(403).json({message:'Fitur ini memerlukan akses keuangan seluruh unit.'});
  next();
 };
 const source=`
   SELECT s.company_id,s.branch_id,(s.created_at AT TIME ZONE 'Asia/Jakarta')::date AS pos_day,
          upper(x.key) AS method,sum((x.value #>> '{}')::numeric) AS recorded
   FROM ops_pos_sales s CROSS JOIN LATERAL jsonb_each(CASE WHEN jsonb_typeof(s.payment_methods)='object' AND s.payment_methods<>'{}'::jsonb
      THEN s.payment_methods WHEN s.payment_method IS NULL OR s.payment_method IN ('SPLIT','TEMPO')
      THEN '{}'::jsonb ELSE jsonb_build_object(s.payment_method,s.total) END) x
   WHERE s.company_id=$1 AND s.status='PAID' AND jsonb_typeof(x.value)='number'
     AND upper(x.key)=ANY($4::text[]) AND s.created_at>=($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
     AND s.created_at<($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
     AND EXISTS(SELECT 1 FROM business_report_branch_units m WHERE m.company_id=s.company_id AND m.branch_id=s.branch_id)
   GROUP BY 1,2,3,4
 `;
 app.get(root,auth,access,group,async(req,res)=>{
  const month=short(req.query.month);
  if(!date(month+'-01'))return res.status(400).json({message:'Bulan tidak valid.'});
  const first=month+'-01',end=new Date(Date.UTC(Number(month.slice(0,4)),Number(month.slice(5)),1)).toISOString().slice(0,10);
  try{
   await ensure();
   const c=req.admin.companyId;
   const [bank,versions]=await Promise.all([
    pool.query(`WITH expected AS (${source})
      SELECT m.unit,b.id AS branch_id,b.name AS branch,e.pos_day::text,e.method,e.recorded::text,
        r.received::text,r.fee::text,r.evidence,r.version,(r.received+r.fee-e.recorded)::text AS difference
      FROM expected e JOIN branches b ON b.id=e.branch_id AND b.company_id=e.company_id
      JOIN business_report_branch_units m ON m.company_id=e.company_id AND m.branch_id=e.branch_id
      LEFT JOIN LATERAL (SELECT * FROM business_settlement_reviews r WHERE
        r.company_id=e.company_id AND r.branch_id=e.branch_id AND r.pos_day=e.pos_day AND r.method=e.method
        ORDER BY version DESC LIMIT 1) r ON true
      ORDER BY e.pos_day DESC,b.name,e.method LIMIT 1001`,[c,first,end,modes]),
    pool.query(`SELECT v.month::text,v.version,v.report,v.reason,v.approved_at,COALESCE(a.name,'Akun yang tidak lagi tersedia') AS approved_by
      FROM business_owner_months v LEFT JOIN admins a ON a.id=v.actor AND a.company_id=v.company_id
      WHERE v.company_id=$1 AND v.month=$2 ORDER BY v.version DESC LIMIT 30`,[c,first])
   ]);
   res.set('Cache-Control','no-store').json({settlements:bank.rows.slice(0,1000),limited:bank.rows.length>1000,versions:versions.rows});
  }catch{res.status(503).json({message:'Rekonsiliasi belum dapat dibaca.'});}
 });
 app.post(root+'/settlement',auth,access,group,async(req,res)=>{
  const b=req.body??{},branch=short(b.branch),posDay=short(b.posDay),method=short(b.method).toUpperCase();
  const evidence=short(b.evidence),reason=short(b.reason);
  if(!uuid.test(branch)||!date(posDay)||posDay>day()||!modes.includes(method)||!money(b.received)||!money(b.fee)||
    !evidence||evidence.length>100||reason.length<5||reason.length>300)
   return res.status(400).json({message:'Periksa outlet, tanggal, nominal, referensi bukti dan alasan.'});
  const c=req.admin.companyId;
  try{
   await ensure();
   const db=await pool.connect();
   try{
    await db.query('BEGIN');
    await db.query('SELECT pg_advisory_xact_lock(hashtext($1))',[['settlement',c,branch,posDay,method].join('/')]);
    const end=new Date(Date.parse(posDay)+86400000).toISOString().slice(0,10);
    const expected=(await db.query(`SELECT recorded FROM (${source}) a WHERE branch_id=$5 AND method=$6`,[c,posDay,end,modes,branch,method])).rows[0];
    if(!expected){await db.query('ROLLBACK');return res.status(409).json({message:'Tidak ada rincian nominal POS untuk sumber tersebut.'});}
    const last=(await db.query(`SELECT version,received::text,fee::text,evidence FROM business_settlement_reviews
        WHERE company_id=$1 AND branch_id=$2 AND pos_day=$3 AND method=$4 ORDER BY version DESC LIMIT 1`,[c,branch,posDay,method])).rows[0];
    if(last&&Number(last.received)===b.received&&Number(last.fee)===b.fee&&last.evidence===evidence){
      await db.query('COMMIT');return res.json({ok:true,version:last.version});
    }
    const version=(last?.version??0)+1;
    await db.query(`INSERT INTO business_settlement_reviews
      (company_id,branch_id,pos_day,method,version,received,fee,evidence,reason,actor)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,[c,branch,posDay,method,version,b.received,b.fee,evidence,reason,req.admin.adminId]);
    await db.query('COMMIT');res.json({ok:true,version});
   }catch(e){await db.query('ROLLBACK').catch(()=>{});throw e;}finally{db.release();}
  }catch{res.status(503).json({message:'Catatan rekonsiliasi belum dapat disimpan.'});}
 });
 app.post(root+'/close',auth,access,group,async(req,res)=>{
  const g=res.locals.reportAccess,b=req.body??{},month=short(b.month),reason=short(b.reason),first=month+'-01';
  if(!['SYSTEM_ADMIN','OWNER'].includes(g.role))return res.status(403).json({message:'Hanya owner atau admin sistem dapat mengesahkan snapshot.'});
  if(!date(first)||month>=day().slice(0,7)||reason.length<5||reason.length>300||b.reviewed!==true)
    return res.status(400).json({message:'Pilih bulan yang sudah selesai, isi alasan, lalu konfirmasi telah memeriksa data.'});
  const end=new Date(Date.UTC(Number(month.slice(0,4)),Number(month.slice(5)),1)).toISOString().slice(0,10),c=req.admin.companyId;
  try{
   await ensure();const db=await pool.connect();
   try{
    await db.query('BEGIN');
    await db.query('SELECT pg_advisory_xact_lock(hashtext($1))',['report-month/'+c+'/'+month]);
    const report=(await db.query(`
      WITH units AS (SELECT unnest(ARRAY['retail','fnb','kosan','penginapan']::text[]) AS unit),
      amounts AS (
        SELECT m.unit,s.total AS amount
        FROM ops_pos_sales s JOIN business_report_branch_units m ON m.company_id=s.company_id AND m.branch_id=s.branch_id
        WHERE s.company_id=$1 AND s.status='PAID' AND s.created_at>=($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
          AND s.created_at<($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
        UNION ALL
        SELECT r.unit,r.amount FROM business_report_property_receipts r
        WHERE r.company_id=$1 AND r.voided_at IS NULL AND r.paid_on >= $2::date AND r.paid_on < $3::date
      ), summed AS (SELECT unit,sum(amount)::text AS actual,count(*)::int AS transactions FROM amounts GROUP BY unit)
      SELECT u.unit,COALESCE(s.actual,'0') AS actual,COALESCE(s.transactions,0) AS transactions,t.amount::text AS target
      FROM units u LEFT JOIN summed s ON s.unit=u.unit
      LEFT JOIN business_report_targets t ON t.company_id=$1 AND t.unit=u.unit AND t.period=$2
      ORDER BY u.unit
    `,[c,first,end])).rows;
    if(report.every(r=>r.transactions===0)){
     await db.query('ROLLBACK');return res.status(409).json({message:'Tidak ada transaksi tercatat untuk disahkan.'});
    }
    const last=(await db.query('SELECT version,report FROM business_owner_months WHERE company_id=$1 AND month=$2 ORDER BY version DESC LIMIT 1',[c,first])).rows[0];
    const stable=(rows:any[])=>JSON.stringify(rows.map(r=>[r.unit,r.actual,r.transactions,r.target]));
    if(last&&stable(last.report)===stable(report)){await db.query('COMMIT');return res.json({ok:true,version:last.version});}
    const version=(last?.version??0)+1;
    await db.query(`INSERT INTO business_owner_months(company_id,month,version,report,reason,actor)
     VALUES ($1,$2,$3,$4,$5,$6)`,[c,first,version,JSON.stringify(report),reason,req.admin.adminId]);
    await db.query('COMMIT');res.json({ok:true,version});
   }catch(e){await db.query('ROLLBACK').catch(()=>{});throw e;}finally{db.release();}
  }catch{res.status(503).json({message:'Snapshot belum dapat disahkan.'});}
 });
}
