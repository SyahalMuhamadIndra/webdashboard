export const cents = (value: unknown): bigint => {
  const text = String(value ?? '0');
  if (!/^-?\d+(?:\.\d+)?$/.test(text)) throw new Error('Invalid monetary precision');
  const negative = text.startsWith('-');
  const [whole, fraction = ''] = (negative ? text.slice(1) : text).split('.');
  if (/[^0]/.test(fraction.slice(2))) throw new Error('Invalid monetary precision');
  return (negative ? -1n : 1n) * (BigInt(whole)*100n + BigInt(fraction.padEnd(2,'0').slice(0,2)));
};
export const amount = (n: bigint): number => {
  if (n > BigInt(Number.MAX_SAFE_INTEGER) || n < BigInt(Number.MIN_SAFE_INTEGER)) throw new Error('Amount exceeds supported precision');
  return Number(n)/100;
};

/** Exact decimal text for PostgreSQL parameters; no floating-point round trip. */
export const decimal = (value: bigint): string => {
  const sign = value < 0n ? '-' : '';
  const absolute = value < 0n ? -value : value;
  return sign + String(absolute / 100n) + '.' + String(absolute % 100n).padStart(2, '0');
};
