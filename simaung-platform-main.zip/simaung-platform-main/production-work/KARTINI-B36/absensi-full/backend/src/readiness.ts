import type express from 'express';
import type { Pool } from 'pg';

/** Metadata only. Must be mounted behind the controller owner's authorization. */
export function createReadinessInspector(pool: Pool): express.RequestHandler {
  return async (_req, res) => {
    try {
      const tables = await pool.query(`SELECT t.table_schema AS schema,t.table_name AS name,
        COALESCE(s.n_live_tup,0)::bigint AS estimated_rows
        FROM information_schema.tables t LEFT JOIN pg_stat_user_tables s
          ON s.schemaname=t.table_schema AND s.relname=t.table_name
        WHERE t.table_schema IN ('public','kartini_erp') AND t.table_type='BASE TABLE'
        ORDER BY t.table_schema,t.table_name`);
      const columns = await pool.query(`SELECT table_schema AS schema,table_name AS name,
        column_name AS column,data_type AS type,is_nullable AS nullable
        FROM information_schema.columns WHERE table_schema IN ('public','kartini_erp')
        ORDER BY table_schema,table_name,ordinal_position`);
      res.set('Cache-Control', 'no-store').json({
        checkedAt: new Date().toISOString(), database: 'reachable',
        configuration: { jwtSecretConfigured: Boolean(process.env.JWT_SECRET && process.env.JWT_SECRET !== 'change-me-in-production'),
          jwtSecretAtLeast32Chars: (process.env.JWT_SECRET?.length || 0) >= 32,
          controllerLoginConfigured: Boolean(process.env.MAINTENANCE_LOGIN_SECRET), node: process.versions.node },
        tables: tables.rows, columns: columns.rows,
      });
    } catch { res.status(503).json({ code: 'INSPECTION_UNAVAILABLE', message: 'Pemeriksaan database belum tersedia.' }); }
  };
}
