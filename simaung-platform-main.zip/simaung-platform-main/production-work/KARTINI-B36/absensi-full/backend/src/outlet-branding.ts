const artwork: Record<string, string> = {
  'TK-KARTINI': 'https://pos.simaung.com/assets/receipt/tk-kartini.png',
  'MAJA-KOFFIE': 'https://pos.simaung.com/assets/receipt/maja-koffie.png',
  'SWEET-ESCAPE': 'https://pos.simaung.com/assets/receipt/sweet-escape.png',
  'CHERRY-BAKES-HOUSE': 'https://pos.simaung.com/assets/receipt/cherry-bakes-house.png',
  'RM-SINDANG-HURIP': 'https://pos.simaung.com/assets/receipt/rm-sindang-hurip.png',
  'Mitra Kost': 'https://report.simaung.com/assets/mitra-kost.png',
  'River Inn': 'https://report.simaung.com/assets/river-inn.png',
};

const palettes: Record<string, readonly [string,string,string,string]> = {
  'TK-KARTINI': ['#176136','#103A25','#A34712','#F4F8F5'],
  'MAJA-KOFFIE': ['#883328','#51201A','#88522D','#FBF5EF'],
  'SWEET-ESCAPE': ['#A62E25','#672019','#8A403F','#FDF3F1'],
  'CHERRY-BAKES-HOUSE': ['#292627','#151314','#765461','#FAF6F7'],
  'RM-SINDANG-HURIP': ['#545735','#33351F','#6B562C','#F6F7EE'],
  'Mitra Kost': ['#A7262C','#5A171C','#34373E','#FCF4F4'],
  'River Inn': ['#197441','#10442D','#416644','#F0F8F2'],
};
export function outletBranding(code: string, name: string) {
  const [primaryColor, primaryDarkColor, accentColor, bgColor] = Object.hasOwn(palettes,code)
    ? palettes[code] : ['#232935','#161B24','#486380','#F3F5F8'];
  return {
    brandName:name, displayName:name, primaryColor, primaryDarkColor, accentColor, bgColor,
    logoUrl:Object.hasOwn(artwork,code)?artwork[code]:'https://pos.simaung.com/assets/logo-kartini.png',
  };
}
