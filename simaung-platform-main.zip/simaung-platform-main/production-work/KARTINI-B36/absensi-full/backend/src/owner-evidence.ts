import type {Express,RequestHandler} from 'express';
import type {Pool} from 'pg';

const units=['retail','fnb','kosan','penginapan'];
const id=/^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
function day(v:unknown):v is string{
 if(typeof v!=='string'||!/^20\d\d-\d\d-\d\d$/.test(v))return false;
 const d=new Date(v+'T00:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===v;
}

export function mountOwnerEvidence(app:Express,pool:Pool,auth:RequestHandler,access:RequestHandler,ensure:()=>Promise<unknown>){
 app.get('/api/admin/business-reports/evidence',auth,access,async(req,res)=>{
  res.set('Cache-Control','no-store');
  const g=res.locals.reportAccess;
  if(g.role!=='OWNER')return res.status(403).json({message:'Bukti laporan hanya tersedia untuk Owner.'});
  const unit=String(req.query.unit??''),from=req.query.from,to=req.query.to;
  const location=String(req.query.location??''),page=Number(req.query.page??1),kind=String(req.query.kind??'sales'),shift=String(req.query.shift??'');
  const pos=['retail','fnb'].includes(unit),property=location.startsWith('property:')?location.slice(9):'';
  if(!units.includes(unit)||!day(from)||!day(to)||from>=to||Date.parse(to)-Date.parse(from)>366*86400000||
     !['sales','bills'].includes(kind)||(kind==='bills'&&pos)||(shift&&(!pos||!id.test(shift)))||!Number.isInteger(page)||page<1||page>1000||(location&&(pos?!id.test(location):!property||property.length>100)))
   return res.status(400).json({message:'Cakupan bukti tidak valid.'});
  if((g.unit!=='all'&&g.unit!==unit)||(g.property&&location&&property!==g.property))
   return res.status(403).json({message:'Bukti di luar unit atau properti yang ditugaskan.'});
  const selected=pos?location:(g.property||property);
  try{
   await ensure();
   const args=[req.admin.companyId,unit,from,to,selected||null,(page-1)*50,...(pos?[shift||null]:[])];
   const q=pos? `
     SELECT s.id,s.code AS reference,b.name AS location,
       to_char(s.created_at AT TIME ZONE 'Asia/Jakarta','YYYY-MM-DD HH24:MI') AS date,
       s.total::text AS amount,s.status,s.payment_method AS method,s.cashier_name AS cashier,
       COALESCE(s.cogs,0)::text AS cost,s.session_id::text AS shift_id
     FROM ops_pos_sales s JOIN branches b ON b.id=s.branch_id AND b.company_id=s.company_id
     JOIN business_report_branch_units m ON m.branch_id=b.id AND m.company_id=b.company_id AND m.unit=$2
     WHERE s.company_id=$1 AND s.created_at>=($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
       AND s.created_at<($4::date::timestamp AT TIME ZONE 'Asia/Jakarta')
       AND ($5::uuid IS NULL OR s.branch_id=$5) AND ($7::uuid IS NULL OR s.session_id=$7)
       AND s.status IN ('PAID','VOID','REFUNDED','TEMPO')
     ORDER BY s.created_at DESC,s.id DESC LIMIT 51 OFFSET $6
   `:kind==='bills'?`
     SELECT i.id,('TAGIHAN-'||upper(left(i.id::text,8))) AS reference,(r.property||' · '||r.code) AS location,
       i.period::text AS date,i.due_on::text,i.amount::text,
       CASE WHEN i.due_on < (now() AT TIME ZONE 'Asia/Jakarta')::date THEN 'OVERDUE'
        WHEN i.due_on IS NULL THEN 'UNDATED' ELSE 'UNPAID' END AS status
     FROM business_property_bills i JOIN business_property_bookings b ON b.id=i.booking_id
     JOIN business_property_rooms r ON r.id=b.room_id
     WHERE r.company_id=$1 AND r.unit=$2 AND i.period >= $3::date AND i.period < $4::date
       AND i.paid_at IS NULL AND b.status<>'CANCELLED' AND ($5::text IS NULL OR r.property=$5)
     ORDER BY i.due_on ASC NULLS LAST,i.id LIMIT 51 OFFSET $6
   `:`
     SELECT id,reference,property AS location,paid_on::text AS date,amount::text,
       CASE WHEN voided_at IS NOT NULL THEN 'VOID' ELSE 'PAID' END AS status
     FROM business_report_property_receipts WHERE company_id=$1 AND unit=$2
       AND paid_on >= $3::date AND paid_on < $4::date AND ($5::text IS NULL OR property=$5)
     ORDER BY paid_on DESC,created_at DESC,id DESC LIMIT 51 OFFSET $6
   `;
   const result=await pool.query(q,args);
   res.json({items:result.rows.slice(0,50),page,hasNext:result.rows.length>50});
  }catch{res.status(503).json({message:'Bukti laporan belum bisa dimuat.'});}
 });
}
