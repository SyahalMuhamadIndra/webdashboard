import { cents, amount } from './money.js';
import express from 'express';
import type { Pool } from 'pg';

const validId = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function date(value: unknown): string | null {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const parsed = new Date(value+'T00:00:00Z');
  return Number.isFinite(parsed.valueOf()) && parsed.toISOString().slice(0,10) === value ? value : null;
}
export function summarizeAccounts(rows: any[]) {
  let td=0n,tc=0n,revenue=0n,expenses=0n,assets=0n,liabilities=0n,equity=0n;
  const revenueRows:any[]=[],expenseRows:any[]=[],assetRows:any[]=[],liabilityRows:any[]=[],equityRows:any[]=[];
  const trial=rows.map(row=>{
    if (!['debit','credit'].includes(row.normal_balance) || !['balance_sheet','income_statement','equity'].includes(row.report_section)) throw new Error('Invalid account classification');
    const d=cents(row.debit), c=cents(row.credit); td+=d;tc+=c;
    const bal=row.normal_balance==='debit'?d-c:c-d;
    const item={code:row.code,name:row.name,amount:amount(bal)};
    if(row.report_section==='income_statement') {
      if(row.normal_balance==='credit'){revenue+=bal;revenueRows.push(item)}else{expenses+=bal;expenseRows.push(item)}
    } else if(row.report_section==='equity'){equity+=bal;equityRows.push(item)}
    else if(row.normal_balance==='debit'){assets+=bal;assetRows.push(item)}
    else{liabilities+=bal;liabilityRows.push(item)}
    return {id:row.id,code:row.code,name:row.name,typeName:row.type_name,normalBalance:row.normal_balance,debit:amount(d),credit:amount(c),balance:amount(bal)};
  });
  const income=revenue-expenses;
  return {
    trial:{rows:trial,totalDebit:amount(td),totalCredit:amount(tc),balanced:td===tc},
    income:{revenueRows,expenseRows,totalRevenue:amount(revenue),totalExpenses:amount(expenses),netIncome:amount(income)},
    balance:{assets:assetRows,liabilities:liabilityRows,equity:[...equityRows,{code:'CURRENT-RESULT',name:'Hasil usaha belum ditutup',amount:amount(income)}],totalAssets:amount(assets),totalLiabilities:amount(liabilities),totalEquity:amount(equity+income),balanced:assets===liabilities+equity+income},
  };
}
const aggregateSql = `SELECT a.id,a.code,a.name,t.name AS type_name,t.normal_balance,t.report_section,
  COALESCE(SUM(l.debit) FILTER (WHERE e.id IS NOT NULL),0)::text AS debit,
  COALESCE(SUM(l.credit) FILTER (WHERE e.id IS NOT NULL),0)::text AS credit
  FROM accounts a JOIN type_of_account t ON t.id=a.type_of_account_id AND t.company_id=a.company_id
  LEFT JOIN journal_lines l ON l.account_id=a.id AND l.company_id=a.company_id
  LEFT JOIN journal_entries e ON e.id=l.journal_entry_id AND e.company_id=a.company_id
    AND e.is_posted=true AND e.entry_date >= $2::date AND e.entry_date <= $3::date
  WHERE a.company_id=$1 AND a.is_header=false
  GROUP BY a.id,a.code,a.name,t.name,t.normal_balance,t.report_section ORDER BY a.code`;

/** Read-only financial reports. Tenant always comes from freshly verified admin auth. */
export function createAccountingReports(pool: Pool, authorize: express.RequestHandler) {
  const router=express.Router();
  router.use(authorize);
  router.use((req,res,next)=>{
    if(!['SUPERADMIN','ADMIN','ACCOUNTANT'].includes(req.admin.role))
      return res.status(403).json({message:'Akses laporan keuangan perusahaan belum diberikan.'});
    next();
  });
  router.use((_req,res,next)=>{res.set('Cache-Control','no-store');next()});
  router.get('/accounts',async(req,res)=>{
    try {
      const r=await pool.query(`SELECT a.id,a.code,a.name,t.name AS "typeName",t.normal_balance AS "normalBalance"
        FROM accounts a JOIN type_of_account t ON t.id=a.type_of_account_id AND t.company_id=a.company_id
        WHERE a.company_id=$1 AND a.is_header=false ORDER BY a.code`,[req.admin.companyId]);res.json({items:r.rows});
    }catch{res.status(503).json({code:'REPORT_UNAVAILABLE',message:'Daftar akun belum tersedia.'})}
  });
  for(const path of ['/trial-balance','/income-statement','/balance-sheet','/summary']) router.get(path,async(req,res)=>{
    const from=date(req.query.from),to=date(req.query.to);
    if(!from || !to || from>to)return res.status(400).json({message:'Rentang tanggal tidak valid.'});
    const client=await pool.connect().catch(()=>null);
    if(!client)return res.status(503).json({code:'REPORT_UNAVAILABLE'});
    try {
      await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
      const rows=(await client.query(aggregateSql,[req.admin.companyId,from,to])).rows;
      const period=summarizeAccounts(rows);
      const cumulative=(path==='/balance-sheet'||path==='/summary')?summarizeAccounts((await client.query(aggregateSql,[req.admin.companyId,'0001-01-01',to])).rows):period;
      let output:any=path==='/trial-balance'?period.trial:path==='/income-statement'?period.income:cumulative.balance;
      if(path==='/summary') {
        const count=await client.query(`SELECT count(*)::int AS count FROM journal_entries WHERE company_id=$1 AND is_posted=true AND entry_date BETWEEN $2::date AND $3::date`,[req.admin.companyId,from,to]);
        output={companyId:req.admin.companyId,range:{from,to},kpi:{revenue:period.income.totalRevenue,expenses:period.income.totalExpenses,netIncome:period.income.netIncome,assets:cumulative.balance.totalAssets,liabilities:cumulative.balance.totalLiabilities,equity:cumulative.balance.totalEquity,journalCount:count.rows[0].count,accountCount:rows.length,totalDebit:period.trial.totalDebit,totalCredit:period.trial.totalCredit,balanced:period.trial.balanced}};
      }
      await client.query('COMMIT');res.json(output);
    }catch {await client.query('ROLLBACK').catch(()=>{});res.status(503).json({code:'REPORT_UNAVAILABLE',message:'Laporan belum dapat dihitung. Tidak ada nilai pengganti yang digunakan.'})}
    finally{client.release()}
  });
  const journalSelect=`SELECT e.id,e.entry_number AS "entryNumber",e.entry_date::text AS "entryDate",e.memo,e.source,e.is_posted AS "isPosted",
    count(l.id)::int AS "lineCount",COALESCE(sum(l.debit),0)::text AS "totalDebit",COALESCE(sum(l.credit),0)::text AS "totalCredit"
    FROM journal_entries e LEFT JOIN journal_lines l ON l.journal_entry_id=e.id AND l.company_id=e.company_id`;
  const journalMoney=(r:any)=>({...r,totalDebit:amount(cents(r.totalDebit)),totalCredit:amount(cents(r.totalCredit))});
  router.get('/journal',async(req,res)=>{
    const limit=Number(req.query.limit ?? 100);
    if(!Number.isInteger(limit)||limit<1||limit>500)return res.status(400).json({message:'Limit 1 sampai 500.'});
    try{const r=await pool.query(journalSelect+` WHERE e.company_id=$1 GROUP BY e.id ORDER BY e.entry_date DESC,e.created_at DESC,e.id DESC LIMIT $2`,[req.admin.companyId,limit]);res.json({items:r.rows.map(journalMoney)})}
    catch{res.status(503).json({code:'REPORT_UNAVAILABLE'})}
  });
  router.get('/journal/:id',async(req,res)=>{
    if(typeof req.params.id!=='string'||!validId.test(req.params.id))return res.status(400).json({message:'ID tidak valid.'});
    try{
      const r=await pool.query(journalSelect+` WHERE e.company_id=$1 AND e.id=$2 GROUP BY e.id`,[req.admin.companyId,req.params.id]);
      if(!r.rows[0])return res.status(404).json({message:'Jurnal tidak ditemukan.'});
      const lines=await pool.query(`SELECT l.id,l.account_id AS "accountId",a.code AS "accountCode",a.name AS "accountName",l.debit::text,l.credit::text,l.description
        FROM journal_lines l JOIN accounts a ON a.id=l.account_id AND a.company_id=l.company_id WHERE l.company_id=$1 AND l.journal_entry_id=$2 ORDER BY l.created_at,l.id`,[req.admin.companyId,req.params.id]);
      res.json({entry:journalMoney(r.rows[0]),lines:lines.rows.map(l=>({...l,debit:amount(cents(l.debit)),credit:amount(cents(l.credit))}))});
    }catch{res.status(503).json({code:'REPORT_UNAVAILABLE'})}
  });
  router.get('/general-ledger',async(req,res)=>{
    const from=date(req.query.from),to=date(req.query.to),id=req.query.accountId;
    if(!from||!to||from>to||typeof id!=='string'||!validId.test(id))return res.status(400).json({message:'Akun dan tanggal wajib valid.'});
    const client=await pool.connect().catch(()=>null);if(!client)return res.status(503).json({code:'REPORT_UNAVAILABLE'});
    try{
      await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
      const a=(await client.query(`SELECT a.id,a.code,a.name,t.normal_balance AS "normalBalance" FROM accounts a JOIN type_of_account t ON t.id=a.type_of_account_id AND t.company_id=a.company_id WHERE a.id=$1 AND a.company_id=$2`,[id,req.admin.companyId])).rows[0];
      if(!a){await client.query('ROLLBACK');return res.status(404).json({message:'Akun tidak ditemukan.'})}
      const values=[req.admin.companyId,id,from,to];
      const opening=(await client.query(`SELECT COALESCE(sum(l.debit-l.credit),0)::text AS balance FROM journal_lines l JOIN journal_entries e ON e.id=l.journal_entry_id AND e.company_id=l.company_id WHERE l.company_id=$1 AND l.account_id=$2 AND e.is_posted=true AND e.entry_date<$3::date`,values.slice(0,3))).rows[0];
      let running=cents(opening.balance)*(a.normalBalance==='credit'?-1n:1n),td=0n,tc=0n;
      const result=await client.query(`SELECT e.entry_date::text AS date,e.entry_number AS "entryNumber",e.memo,l.debit::text,l.credit::text FROM journal_lines l JOIN journal_entries e ON e.id=l.journal_entry_id AND e.company_id=l.company_id WHERE l.company_id=$1 AND l.account_id=$2 AND e.is_posted=true AND e.entry_date BETWEEN $3::date AND $4::date ORDER BY e.entry_date,e.created_at,e.id,l.id`,values);
      const openingBalance=amount(running);
      const rows=result.rows.map(r=>{const d=cents(r.debit),c=cents(r.credit);td+=d;tc+=c;running+=(a.normalBalance==='credit'?c-d:d-c);return {...r,debit:amount(d),credit:amount(c),balance:amount(running)}});
      await client.query('COMMIT');res.json({account:a,openingBalance,closingBalance:amount(running),rows,totalDebit:amount(td),totalCredit:amount(tc)});
    }catch{await client.query('ROLLBACK').catch(()=>{});res.status(503).json({code:'REPORT_UNAVAILABLE'})}finally{client.release()}
  });
  return router;
}
