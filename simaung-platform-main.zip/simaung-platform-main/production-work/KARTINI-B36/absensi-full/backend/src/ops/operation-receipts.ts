import {createHash} from 'node:crypto';
type Client={query:(sql:string,values?:any[])=>Promise<{rows:any[]}>};
export class OperationError extends Error {status=409;}
function canonical(value:any):any{
 if(value===null||typeof value!=='object')return value;
 if(Array.isArray(value))return value.map(canonical);
 return Object.fromEntries(Object.keys(value).sort().filter(key=>key!=='operationId').map(key=>[key,canonical(value[key])]));
}
/** Call within the business transaction, before locking any business rows. */
export async function claimOperation(db:Client,company:string,actor:string,key:unknown,action:string,payload:unknown){
 if(typeof key!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(key))throw new OperationError('Muat ulang aplikasi kasir sebelum menyimpan transaksi.');
 const hash=createHash('sha256').update(JSON.stringify(canonical(payload))).digest('hex');
 await db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['kartini.ops:'+company+':'+actor+':'+key]);
 const prior=(await db.query('SELECT action,payload_hash,result FROM ops_operation_receipts WHERE company_id=$1 AND actor_id=$2 AND operation_id=$3',[company,actor,key])).rows[0];
 if(prior&&(prior.action!==action||prior.payload_hash!==hash))throw new OperationError('Kunci transaksi sudah dipakai dengan data berbeda.');
 return {replayed:!!prior,result:prior?.result,complete:async(result:unknown)=>{
  await db.query('INSERT INTO ops_operation_receipts(company_id,actor_id,operation_id,action,payload_hash,result)VALUES($1,$2,$3,$4,$5,$6)',[company,actor,key,action,hash,JSON.stringify(result)]);
 }};
}
