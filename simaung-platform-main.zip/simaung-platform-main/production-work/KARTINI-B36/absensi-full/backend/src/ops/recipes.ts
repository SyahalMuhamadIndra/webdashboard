// =====================================================================
//  B21 — BAHAN BAKU & RESEP (F&B / campuran)
//  Stok bahan baku berkurang otomatis setiap ada penjualan produk yang
//  punya resep. Meliputi: master bahan, resep per produk, mutasi stok
//  bahan (masuk/keluar/koreksi), dan laporan bahan menipis.
// =====================================================================
import express from 'express';
import {CheckoutError} from './checkout-stock.js';
import type { Pool } from 'pg';
import { ensureOpsTables, num, str, requireOpsRoleOrAdmin } from './common.js';

// Peran yang boleh melihat / mengubah data bahan baku.
const MATERIAL_READ = ['KASIR', 'KEPALA_GUDANG', 'KEPALA_TOKO', 'SUPERVISOR', 'MANAGER', 'ADMIN', 'OWNER'];
const MATERIAL_WRITE = ['KASIR', 'KEPALA_GUDANG', 'KEPALA_TOKO', 'SUPERVISOR', 'MANAGER', 'ADMIN', 'OWNER'];

const materialUnits:Record<string,[string,number]>={kg:['mass',1000],g:['mass',1],gram:['mass',1],l:['volume',1000],liter:['volume',1000],ml:['volume',1]};
function moveQuantity(qty:number,from:string,to:string){
  if(!from||from.toLowerCase()===to.toLowerCase())return qty;
  const a=materialUnits[from.toLowerCase()],b=materialUnits[to.toLowerCase()];
  return a&&b&&a[0]===b[0]?qty*a[1]/b[1]:null;
}
function mapMaterial(r: any) {
  const stock = num(r.stock);
  const minStock = num(r.min_stock);
  return {
    id: r.id, name: r.name, sku: r.sku || null, unit: r.unit || 'pcs',
    stock, minStock, cost: num(r.cost), supplier: r.supplier || null,
    active: r.active !== false, value: stock * num(r.cost),
    low: stock <= 0 || (minStock > 0 && stock <= minStock),
    empty: stock <= 0, updatedAt: r.updated_at || null,
  };
}

export function createOpsRecipesRouter(deps: { pool: Pool; auth: express.RequestHandler; adminAuth: express.RequestHandler }) {
  const { pool, auth, adminAuth } = deps;
  const router = express.Router();
  const read = requireOpsRoleOrAdmin(auth, adminAuth, pool, ...MATERIAL_READ);
  const write = requireOpsRoleOrAdmin(auth, adminAuth, pool, ...MATERIAL_WRITE);

  // ------------------------------------------------------------------
  //  BAHAN BAKU
  // ------------------------------------------------------------------
  /** GET /api/ops/materials — daftar bahan baku + ringkasan stok. */
  router.get(['/materials', '/admin/materials'], read, async (req, res) => {
    try {
      await ensureOpsTables(pool);
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const q = str(req.query.q).trim();
      const rows = (await pool.query(
        `SELECT * FROM ops_materials
          WHERE company_id=$1 AND active IS NOT FALSE
            ${q ? `AND (name ILIKE $2 OR COALESCE(sku,'') ILIKE $2)` : ''}
          ORDER BY name ASC LIMIT 500`,
        q ? [companyId, `%${q}%`] : [companyId]
      )).rows;
      const items = rows.map(mapMaterial);
      res.json({
        items,
        summary: {
          count: items.length,
          lowCount: items.filter((m: any) => m.low).length,
          emptyCount: items.filter((m: any) => m.empty).length,
          totalValue: items.reduce((a: number, m: any) => a + num(m.value), 0),
        },
      });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/materials — tambah / ubah bahan baku. */
  router.post(['/materials', '/admin/materials'], write, async (req, res) => {
    const client=await pool.connect();
    try {
      await ensureOpsTables(pool);
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const b = req.body ?? {};
      const name = str(b.name).trim();
      if (!name) return res.status(400).json({ message: 'Nama bahan wajib diisi' });
      const id = str(b.id) || null;
      const unit = str(b.unit).trim() || 'pcs';
      const minStock = Math.max(0, num(b.minStock));
      const cost = Math.max(0, num(b.cost));
      const supplier = str(b.supplier).trim() || null;
      const sku = str(b.sku).trim() || null;
      const initial = id ? 0 : Number(b.stock ?? 0);
      if(!Number.isFinite(initial)||initial<0||initial>1e12||!Number.isFinite(Number(b.minStock??0))||Number(b.minStock??0)<0)
        return res.status(400).json({message:'Stok awal dan minimum harus berupa angka nonnegatif.'});
      await client.query('BEGIN');
      let row;
      if (id) {
        const old=(await client.query('SELECT unit FROM ops_materials WHERE id=$1 AND company_id=$2 FOR UPDATE',[id,companyId])).rows[0];
        if(!old){await client.query('ROLLBACK');return res.status(404).json({message:'Bahan tidak ditemukan'});}
        if(old.unit!==unit){await client.query('ROLLBACK');return res.status(409).json({message:'Satuan dasar bahan tidak dapat diganti. Gunakan satuan input pada mutasi atau buat bahan baru.'});}
        row = (await client.query(
          `UPDATE ops_materials SET name=$3, sku=$4, unit=$5, min_stock=$6, cost=$7, supplier=$8, updated_at=now()
            WHERE id=$1 AND company_id=$2 RETURNING *`,
          [id, companyId, name, sku, unit, minStock, cost, supplier]
        )).rows[0];
        if (!row){await client.query('ROLLBACK');return res.status(404).json({ message:'Bahan tidak ditemukan' });}
      } else {
        const stock = initial;
        row = (await client.query(
          `INSERT INTO ops_materials (company_id, name, sku, unit, stock, min_stock, cost, supplier)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
          [companyId, name, sku, unit, stock, minStock, cost, supplier]
        )).rows[0];
        // Stok awal dicatat sebagai mutasi agar ada jejak.
        if (stock !== 0) {
          await client.query(
            `INSERT INTO ops_material_moves (company_id, material_id, kind, qty, ref_type, note, actor_name)
             VALUES ($1,$2,'ADJ',$3,'OPENING',$4,$5)`,
            [companyId, row.id, stock, 'stok awal', str((req as any).user?.employeeName || (req as any).user?.fullName || 'Sistem')]
          );
        }
      }
      await client.query('COMMIT');
      res.json({ material: mapMaterial(row), message: id ? 'Bahan diperbarui' : 'Bahan ditambahkan' });
    } catch (e) { await client.query('ROLLBACK').catch(()=>{}); res.status(500).json({message:'Bahan belum tersimpan.'}); } finally { client.release(); }
  });

  /** DELETE /api/ops/materials/:id — nonaktifkan bahan (riwayat tetap utuh). */
  router.delete(['/materials/:id', '/admin/materials/:id'], write, async (req,res)=>{
    const client=await pool.connect();
    try{
      const company=(req as any).user?.companyId||(req as any).admin?.companyId;
      const id=req.params.id;
      await client.query('BEGIN');
      const found=await client.query('SELECT id FROM ops_materials WHERE id=$1 AND company_id=$2 FOR UPDATE',[id,company]);
      if(!found.rows.length){await client.query('ROLLBACK');return res.status(404).json({message:'Bahan tidak ditemukan.'});}
      const inUse=await client.query('SELECT 1 FROM ops_recipes WHERE material_id=$1 AND company_id=$2 LIMIT 1',[id,company]);
      if(inUse.rowCount){await client.query('ROLLBACK');return res.status(409).json({message:'Bahan masih dipakai dalam resep. Ubah resep terkait sebelum menonaktifkan bahan.'});}
      await client.query('UPDATE ops_materials SET active=false,updated_at=now() WHERE id=$1 AND company_id=$2',[id,company]);
      await client.query('COMMIT');
      res.json({ok:true,message:'Bahan dinonaktifkan; riwayat tetap disimpan.'});
    }catch{await client.query('ROLLBACK').catch(()=>{});res.status(500).json({message:'Bahan belum dapat dinonaktifkan.'});}
    finally{client.release();}
  });

  /** POST /api/ops/materials/:id/move — stok masuk / keluar / koreksi (opname bahan). */
  router.post(['/materials/:id/move', '/admin/materials/:id/move'], write, async (req, res) => {
    const client = await pool.connect();
    try {
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const b = req.body ?? {};
      const requestKind=str(b.kind).toUpperCase();
      if(!['IN','OUT','ADJ','WASTE'].includes(requestKind))return res.status(400).json({message:'Jenis mutasi tidak valid.'});
      const kind=requestKind==='WASTE'?'OUT':requestKind;
      const waste=requestKind==='WASTE';
      if(waste&&str(b.note).trim().length<3)return res.status(400).json({message:'Isi alasan bahan terbuang.'});
      const qty = num(b.qty);
      if (!(kind==='ADJ'?qty>=0:qty>0) || b.qty===null || b.qty===undefined || b.qty==='' || !Number.isFinite(Number(b.qty))) return res.status(400).json({ message: 'Jumlah tidak valid untuk jenis mutasi ini' });
      const note = str(b.note).trim() || (kind === 'IN' ? 'stok masuk' : kind === 'OUT' ? 'stok keluar' : 'koreksi stok');
      const actor = str((req as any).user?.employeeName || (req as any).user?.fullName || 'Kasir');
      await client.query('BEGIN');
      const m = (await client.query(`SELECT id, name, unit, stock,cost FROM ops_materials WHERE id=$1 AND company_id=$2 AND active IS NOT FALSE FOR UPDATE`, [req.params.id, companyId])).rows[0];
      if (!m) { await client.query('ROLLBACK'); return res.status(404).json({ message: 'Bahan tidak ditemukan' }); }

      const converted=moveQuantity(qty,str(b.inputUnit).trim(),m.unit);
      if(converted===null||!Number.isFinite(converted)||converted>1e12){
        await client.query('ROLLBACK');return res.status(400).json({message:'Satuan input tidak sejenis dengan satuan stok atau nominal terlalu besar.'});
      }
      const moveNote=(str(b.inputUnit).trim()&&str(b.inputUnit).trim()!==m.unit)?note+' ['+qty+' '+str(b.inputUnit).trim()+' = '+converted+' '+m.unit+']':note;
      let delta: number;
      if (kind === 'IN') delta = converted;
      else if (kind === 'OUT') delta = -converted;
      else delta = converted - num(m.stock); // ADJ: qty = stok hasil hitung fisik
      const newStock = num(m.stock) + delta;
      if (newStock < 0 && kind === 'OUT') { await client.query('ROLLBACK'); return res.status(400).json({ message: `Stok ${m.name} hanya ${num(m.stock)} ${m.unit}` }); }

      await client.query(`UPDATE ops_materials SET stock=$2, updated_at=now() WHERE id=$1`, [m.id, newStock]);
      await client.query(
        `INSERT INTO ops_material_moves (company_id, material_id, kind, qty, ref_type, note, actor_name,cost)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [companyId, m.id, kind, Math.abs(delta), waste?'WASTE':kind === 'ADJ' ? 'OPNAME' : 'MANUAL', moveNote, actor,waste?num(m.cost)*converted:0]
      );
      await client.query('COMMIT');
      res.json({ id: m.id, stock: newStock, delta, baseQuantity:converted, unit:m.unit, message: `Stok ${m.name} kini ${newStock} ${m.unit}` });
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* ignore */ }
      console.error(e); res.status(500).json({ message: 'Server error' });
    } finally { client.release(); }
  });

  /** GET /api/ops/materials/:id/moves — riwayat mutasi bahan. */
  router.get(['/materials/:id/moves', '/admin/materials/:id/moves'], read, async (req, res) => {
    try {
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const rows = (await pool.query(
        `SELECT * FROM ops_material_moves WHERE company_id=$1 AND material_id=$2 ORDER BY created_at DESC LIMIT 100`,
        [companyId, req.params.id]
      )).rows;
      res.json({ items: rows.map((r: any) => ({ id: r.id, kind: r.kind, qty: num(r.qty), refType: r.ref_type, refCode: r.ref_code, note: r.note, actorName: r.actor_name, createdAt: r.created_at })) });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ------------------------------------------------------------------
  //  RESEP PER PRODUK
  // ------------------------------------------------------------------
  /** GET /api/ops/recipes — semua produk yang punya resep + perkiraan porsi tersedia. */
  router.get(['/recipes', '/admin/recipes'], read, async (req, res) => {
    try {
      await ensureOpsTables(pool);
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const rows = (await pool.query(
        `SELECT r.id, r.product_id, r.material_id, r.qty AS per_unit,
                p.name AS product_name, p.price AS product_price,
                m.name AS material_name, m.unit, m.stock, m.cost, m.active AS material_active
           FROM ops_recipes r
           JOIN ops_products p ON p.id = r.product_id
           JOIN ops_materials m ON m.id = r.material_id
          WHERE r.company_id=$1
          ORDER BY p.name ASC, m.name ASC`, [companyId]
      )).rows;
      const byProduct: Record<string, any> = {};
      for (const r of rows) {
        const k = String(r.product_id);
        if (!byProduct[k]) byProduct[k] = { productId: r.product_id, productName: r.product_name, price: num(r.product_price), items: [] };
        const perUnit = num(r.per_unit);
        const stock = num(r.stock);
        const portions = perUnit > 0 ? Math.max(0, Math.floor(stock / perUnit)) : 0;
        byProduct[k].items.push({
          id: r.id, materialId: r.material_id, materialName: r.material_name, unit: r.unit,
          qty: perUnit, stock, cost: num(r.cost), materialActive: r.material_active !== false,
          portions, materialCost: perUnit * num(r.cost),
        });
      }
      const items = Object.keys(byProduct).map((k) => {
        const g = byProduct[k];
        const portions = g.items.filter((i: any) => i.materialActive).reduce((a: number, i: any) => Math.min(a, i.portions), Number.MAX_SAFE_INTEGER);
        return {
          productId: g.productId, productName: g.productName, price: g.price,
          lines: g.items.length, items: g.items,
          portions: g.items.length ? (portions === Number.MAX_SAFE_INTEGER ? 0 : portions) : 0,
          materialCost: g.items.reduce((a: number, i: any) => a + i.materialCost, 0),
          margin: g.price - g.items.reduce((a: number, i: any) => a + i.materialCost, 0),
          hppSource: 'RESEP',
        };
      });
      res.json({ items, count: items.length });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/ops/products/:id/recipe — resep satu produk. */
  router.get(['/products/:id/recipe', '/admin/products/:id/recipe'], read, async (req, res) => {
    try {
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const rows = (await pool.query(
        `SELECT r.id, r.material_id, r.qty AS per_unit, r.note,
                m.name AS material_name, m.unit, m.stock, m.cost
           FROM ops_recipes r JOIN ops_materials m ON m.id = r.material_id
          WHERE r.company_id=$1 AND r.product_id=$2 ORDER BY m.name ASC`, [companyId, req.params.id]
      )).rows;
      const items = rows.map((r: any) => ({
        id: r.id, materialId: r.material_id, materialName: r.material_name, unit: r.unit,
        qty: num(r.per_unit), stock: num(r.stock), cost: num(r.cost), note: r.note || null,
      }));
      res.json({ productId: req.params.id, items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** PUT /api/ops/products/:id/recipe — ganti seluruh resep produk. */
  router.put(['/products/:id/recipe', '/admin/products/:id/recipe'], write, async (req, res) => {
    const client = await pool.connect();
    try {
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const b = req.body ?? {};
      if(!Array.isArray(b.items)||b.items.length>500)return res.status(400).json({message:'Resep harus berisi daftar bahan (maksimal 500 baris).'});
      const raw=b.items;
      const cleaned: any[] = [];
      const seen = new Set<string>();
      for (const it of raw) {
        const mid = str(it?.materialId).toLowerCase();
        const qty = Number(it?.qty);
        if(!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(mid)||!Number.isFinite(qty)||qty<=0||seen.has(mid))
          return res.status(400).json({message:'Bahan harus unik dan jumlah harus lebih dari nol.'});
        seen.add(mid);
        cleaned.push({ mid, qty, note: str(it.note).trim() || null });
      }
      await client.query('BEGIN');
      const prod = (await client.query(`SELECT id, name FROM public.ops_products WHERE id=$1 AND company_id=$2 FOR UPDATE`, [req.params.id, companyId])).rows[0];
      if(!prod){ await client.query('ROLLBACK');return res.status(404).json({message:'Produk tidak ditemukan'}); }
      if(cleaned.length){
        const found=await client.query(`SELECT id FROM ops_materials WHERE company_id=$1 AND id=ANY($2::uuid[])
          AND active IS NOT FALSE ORDER BY id FOR SHARE`,[companyId,cleaned.map(c=>c.mid)]);
        if(found.rows.length!==cleaned.length){await client.query('ROLLBACK');return res.status(400).json({message:'Ada bahan nonaktif atau di luar cakupan outlet; resep lama dipertahankan.'});}
      }
      await client.query(`DELETE FROM ops_recipes WHERE company_id=$1 AND product_id=$2`, [companyId, prod.id]);
      for (const c of cleaned) {
        await client.query(
          `INSERT INTO ops_recipes (company_id, product_id, material_id, qty, note) VALUES ($1,$2,$3,$4,$5)`,
          [companyId, prod.id, c.mid, c.qty, c.note]
        );
      }
      await client.query('COMMIT');
      res.json({ productId: prod.id, productName: prod.name, count: cleaned.length, message: cleaned.length ? `Resep ${prod.name} disimpan (${cleaned.length} bahan)` : `Resep ${prod.name} dikosongkan` });
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* ignore */ }
      console.error(e); res.status(500).json({ message: 'Server error' });
    } finally { client.release(); }
  });

  // ------------------------------------------------------------------
  //  LAPORAN BAHAN
  // ------------------------------------------------------------------
  /** GET /api/ops/materials-report — bahan menipis, nilai stok, pemakaian terakhir. */
  router.get(['/materials-report', '/admin/materials-report'], read, async (req, res) => {
    try {
      await ensureOpsTables(pool);
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const mats = (await pool.query(`SELECT * FROM ops_materials WHERE company_id=$1 AND active IS NOT FALSE ORDER BY name ASC`, [companyId])).rows.map(mapMaterial);
      const used = (await pool.query(
        `SELECT mv.material_id, COALESCE(SUM(mv.qty),0) AS used
           FROM ops_material_moves mv
          WHERE mv.company_id=$1 AND mv.kind='OUT' AND mv.ref_type='SALE'
            AND mv.created_at >= (now() - interval '30 days')
          GROUP BY mv.material_id`, [companyId]
      )).rows;
      const usedMap: Record<string, number> = {};
      used.forEach((u: any) => { usedMap[String(u.material_id)] = num(u.used); });
      const low = mats.filter((m: any) => m.low).map((m: any) => ({ id: m.id, name: m.name, unit: m.unit, stock: m.stock, minStock: m.minStock }));
      res.json({
        totalValue: mats.reduce((a: number, m: any) => a + num(m.value), 0),
        count: mats.length,
        low,
        usage30d: mats.map((m: any) => ({ id: m.id, name: m.name, unit: m.unit, used30d: usedMap[String(m.id)] || 0 })).filter((x: any) => x.used30d > 0).sort((a: any, b: any) => b.used30d - a.used30d),
      });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  return router;
}

/** Dipakai pos.ts: kurangi stok bahan sesuai resep produk yang terjual. */
export async function consumeMaterialsForSale(client: any, opts: {
  companyId: string; saleId: string; code: string; actorName: string;
  lines: Array<{ pid: string | null; name: string; qty: number }>;
}): Promise<{ usage: any[]; warnings: any[]; perProduct: Array<{ productId: string; used: any[] }> }> {
  const usage: any[] = [];
  const warnings: any[] = [];
  const perProduct: Array<{ productId: string; used: any[] }> = [];
  for (const l of opts.lines) {
    if (!l.pid) continue;
    const rec = (await client.query(
      `SELECT r.material_id, r.qty AS per_unit, m.name, m.unit, m.stock, m.min_stock, m.cost
         FROM ops_recipes r JOIN ops_materials m ON m.id = r.material_id
        WHERE r.product_id=$1 AND r.company_id=$2 AND m.company_id=$2 AND m.active IS NOT FALSE ORDER BY m.id`, [l.pid,opts.companyId]
    )).rows;
    if (!rec.length) continue;
    const used: any[] = [];
    for (const r of rec) {
      const take = num(r.per_unit) * num(l.qty);
      if (take <= 0) continue;
      const upd = (await client.query(
        `UPDATE ops_materials SET stock = stock - $2, updated_at=now() WHERE id=$1 AND company_id=$3 AND stock >= $2
          RETURNING stock, min_stock, unit, name, cost`, [r.material_id, take,opts.companyId]
      )).rows[0];
      if (!upd) throw new CheckoutError('Stok bahan baku tidak mencukupi.');
      await client.query(
        `INSERT INTO ops_material_moves (company_id, material_id, kind, qty, cost, ref_type, ref_id, ref_code, note, actor_name)
         VALUES ($1,$2,'OUT',$3,$4,'SALE',$5,$6,$7,$8)`,
        [opts.companyId, r.material_id, take, num(r.cost) * take, opts.saleId, opts.code, 'pemakaian resep: ' + l.name, opts.actorName]
      );
      const remaining = num(upd?.stock);
      const info = {
        materialId: r.material_id, name: upd?.name || r.name, unit: upd?.unit || r.unit,
        qty: take, remaining,
      };
      used.push(info);
      if (remaining < 0) warnings.push(Object.assign({}, info, { reason: 'stok minus' }));
      else if (num(upd?.min_stock) > 0 && remaining <= num(upd?.min_stock)) warnings.push(Object.assign({}, info, { reason: 'mencapai batas minimum', minStock: num(upd?.min_stock) }));
    }
    if (used.length) {
      usage.push({ productId: l.pid, productName: l.name, qty: num(l.qty), materials: used });
      perProduct.push({ productId: l.pid, used });
    }
  }
  return { usage, warnings, perProduct };
}
