// =====================================================================
//  MODUL OPERASIONAL (B17) — SHIFTING KASIR & PENGHASILAN (PROFESIONAL)
//
//  1. SHIFTING KASIR
//     - Sesi kasir bernomor: kode shift, nomor shift, label shift, terminal.
//     - Modal awal laci (opening float) + kas masuk/keluar selama shift.
//     - X-Report: ringkasan berjalan tanpa menutup shift.
//     - Z-Report: tutup shift — hitung uang fisik, rincian pecahan, selisih,
//       catatan selisih, serah terima kas, arsip snapshot (angka beku).
//     - Blind close + toleransi selisih + persetujuan supervisor.
//     - Riwayat shift & rekap selisih kas (shrinkage) per periode.
//  2. PENGHASILAN
//     - Omzet kotor, diskon, pajak, penjualan bersih, HPP, laba kotor, margin.
//     - Rincian per metode bayar / kasir / kategori / jam / hari.
//     - Produk terlaris & penyumbang laba, keranjang rata-rata.
//     - Perbandingan periode sebelumnya, target harian, ekspor CSV.
//  3. VOID / REFUND transaksi (stok dikembalikan, laba ikut dikoreksi).
//
//  Zona waktu: seluruh pengelompokan tanggal/jam memakai WIB (UTC+7) lewat
//  helper wibDate(). Kode lama memakai created_at::date (UTC) sehingga
//  transaksi 00:00–06:59 WIB masuk ke tanggal sebelumnya — dikoreksi di sini.
// =====================================================================
import express from 'express';
import type { Pool } from 'pg';
import { int, num, str, requireOpsRole, isoDateTz, addDays, docCode, normalizePosMethod, wibDate } from './common.js';

const POS_ROLES = ['KASIR'];

/** Rumus komponen TUNAI sebuah transaksi (dipakai konsisten di semua laporan). */
const CASH_PART = `CASE WHEN s.payment_method='CASH' THEN s.total
                        WHEN s.payment_method='SPLIT' THEN COALESCE(s.cash_received,0)
                        ELSE 0 END`;

/** Label shift otomatis dari jam buka (WIB). */
function shiftLabelFor(d: Date = new Date()): string {
  const h = new Date(d.getTime() + 7 * 3600 * 1000).getUTCHours();
  if (h >= 6 && h < 14) return 'Pagi';
  if (h >= 14 && h < 21) return 'Siang';
  return 'Malam';
}

/** Ringkasan angka satu shift — SUMBER TUNGGAL untuk X-Report & Z-Report. */
export async function shiftTotals(pool: Pick<Pool, 'query'>, sessionId: string) {
  const r = (await pool.query(
    `SELECT COUNT(*)::int AS n,
            COALESCE(SUM(subtotal),0) AS gross,
            COALESCE(SUM(discount + member_discount),0) AS discount,
            COALESCE(SUM(tax),0) AS tax,
            COALESCE(SUM(total),0) AS total,
            COALESCE(SUM(cogs),0) AS cogs,
            COALESCE(SUM(${CASH_PART}),0) AS cash_sales,
            COALESCE(SUM(CASE WHEN s.payment_method='CASH' THEN 0 ELSE s.total END),0) AS noncash_sales
       FROM ops_pos_sales s WHERE s.session_id=$1 AND s.status='PAID'`, [sessionId]
  )).rows[0];
  const it = (await pool.query(
    `SELECT COALESCE(SUM(x.qty),0) AS qty FROM ops_pos_sale_items x
       JOIN ops_pos_sales s ON s.id = x.sale_id
      WHERE s.session_id=$1 AND s.status='PAID'`, [sessionId]
  )).rows[0];
  const mv = (await pool.query(
    `SELECT COALESCE(SUM(CASE WHEN kind='IN' THEN amount ELSE 0 END),0) AS cash_in,
            COALESCE(SUM(CASE WHEN kind='OUT' THEN amount ELSE 0 END),0) AS cash_out
       FROM ops_pos_cash_movements WHERE session_id=$1`, [sessionId]
  )).rows[0];
  const byMethod = (await pool.query(
    `SELECT m.key AS method, COALESCE(SUM(m.value::numeric),0) AS amount, COUNT(DISTINCT s.id)::int AS n
       FROM ops_pos_sales s,
            jsonb_each_text(COALESCE(s.payment_methods, jsonb_build_object(s.payment_method, s.total))) m
      WHERE s.session_id=$1 AND s.status='PAID' GROUP BY 1 ORDER BY 2 DESC`, [sessionId]
  )).rows;
  const voided = (await pool.query(
    `SELECT COUNT(*)::int AS n, COALESCE(SUM(total),0) AS total
       FROM ops_pos_sales WHERE session_id=$1 AND status IN ('VOID','REFUNDED')`, [sessionId]
  )).rows[0];
  const net = num(r?.gross) - num(r?.discount);
  return {
    count: int(r?.n),
    gross: num(r?.gross),
    discount: num(r?.discount),
    tax: num(r?.tax),
    total: num(r?.total),
    netSales: net,
    cogs: num(r?.cogs),
    profit: net - num(r?.cogs),
    cashSales: num(r?.cash_sales),
    nonCashSales: num(r?.noncash_sales),
    itemsSold: int(it?.qty),
    cashIn: num(mv?.cash_in),
    cashOut: num(mv?.cash_out),
    byMethod: byMethod.map((x: any) => ({
      method: String(x.method || '').toUpperCase(), amount: num(x.amount), count: int(x.n),
    })),
    voidCount: int(voided?.n),
    voidTotal: num(voided?.total),
    avgBasket: int(r?.n) ? num(r?.total) / int(r?.n) : 0,
  };
}

/** Kas seharusnya di laci = modal awal + penjualan tunai + kas masuk − kas keluar. */
export function expectedCashOf(session: any, t: any): number {
  return num(session?.opening_cash) + num(t?.cashSales) + num(t?.cashIn) - num(t?.cashOut);
}

/** Total nilai uang fisik dari rincian pecahan { "100000": 12, ... }. */
function denominationsTotal(d: any): number {
  if (!d || typeof d !== 'object') return 0;
  let sum = 0;
  for (const k of Object.keys(d)) sum += num(k) * num((d as any)[k]);
  return sum;
}

async function sessionById(pool: Pick<Pool, 'query'>, companyId: string, id: string) {
  return (await pool.query(
    `SELECT * FROM ops_pos_sessions WHERE id=$1 AND company_id=$2`, [id, companyId]
  )).rows[0];
}

async function openSessionOf(pool: Pick<Pool, 'query'>, companyId: string, cashierId: string) {
  return (await pool.query(
    `SELECT * FROM ops_pos_sessions WHERE company_id=$1 AND cashier_id=$2 AND status IN ('OPEN','PENDING_APPROVAL')
      ORDER BY opened_at DESC LIMIT 1`, [companyId, cashierId]
  )).rows[0];
}

async function settingsOf(pool: Pick<Pool, 'query'>, companyId: string) {
  await pool.query(`INSERT INTO ops_settings (company_id) VALUES ($1) ON CONFLICT (company_id) DO NOTHING`, [companyId]);
  return (await pool.query(`SELECT * FROM ops_settings WHERE company_id=$1`, [companyId])).rows[0];
}

function mapShift(r: any, t?: any) {
  const totals = t || null;
  const expected = r.expected_cash != null ? num(r.expected_cash)
    : (totals ? expectedCashOf(r, totals) : null);
  return {
    id: r.id, code: r.code, shiftNo: r.shift_no != null ? int(r.shift_no) : null,
    shiftLabel: r.shift_label, terminal: r.terminal,
    cashierId: r.cashier_id, cashierName: r.cashier_name,
    openingCash: num(r.opening_cash), closingCash: r.closing_cash != null ? num(r.closing_cash) : null,
    expectedCash: expected, cashDiff: r.cash_diff != null ? num(r.cash_diff) : null,
    countedBreakdown: r.counted_breakdown || null, varianceNote: r.variance_note || null,
    closeSnapshot: r.close_snapshot || null,
    status: r.status, openedAt: r.opened_at, closedAt: r.closed_at,
    durationMinutes: r.opened_at
      ? Math.max(0, Math.round(((r.closed_at ? new Date(r.closed_at) : new Date()).getTime() - new Date(r.opened_at).getTime()) / 60000))
      : 0,
    note: r.note, closedBy: r.closed_by, approvedBy: r.approved_by, approvedAt: r.approved_at,
    handoverTo: r.handover_to, handoverCash: r.handover_cash != null ? num(r.handover_cash) : null,
    totals: totals ? {
      count: totals.count, gross: totals.gross, discount: totals.discount, tax: totals.tax,
      total: totals.total, netSales: totals.netSales, cogs: totals.cogs, profit: totals.profit,
      cashSales: totals.cashSales, nonCashSales: totals.nonCashSales, itemsSold: totals.itemsSold,
      cashIn: totals.cashIn, cashOut: totals.cashOut, avgBasket: Math.round(totals.avgBasket),
      byMethod: totals.byMethod, voidCount: totals.voidCount, voidTotal: totals.voidTotal,
    } : null,
  };
}

export function createOpsShiftRouter(deps: { pool: Pool; auth: express.RequestHandler; adminAuth: express.RequestHandler }) {
  const { pool, auth, adminAuth } = deps;
  const router = express.Router();

  // ==================================================================
  //  A. SHIFTING KASIR — SISI KASIR (aplikasi)
  // ==================================================================

  /** GET /api/ops/pos/shift/live — X-Report: kondisi shift berjalan saat ini. */
  router.get('/pos/shift/live', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const s = await openSessionOf(pool, companyId, me);
      if (!s) return res.json({ shift: null, xReport: null });
      const t = await shiftTotals(pool, s.id);
      const top = (await pool.query(
        `SELECT i.product_name AS name, SUM(i.qty)::int AS qty, SUM(i.total) AS total
           FROM ops_pos_sale_items i JOIN ops_pos_sales s ON s.id = i.sale_id
          WHERE s.session_id=$1 AND s.status='PAID'
          GROUP BY 1 ORDER BY 3 DESC LIMIT 5`, [s.id]
      )).rows.map((x: any) => ({ name: x.name, qty: int(x.qty), total: num(x.total) }));
      const cfg = await settingsOf(pool, companyId);
      res.json({
        shift: mapShift(s, t),
        xReport: {
          generatedAt: new Date().toISOString(),
          expectedCash: expectedCashOf(s, t),
          drawerNow: num(s.opening_cash) + t.cashSales + t.cashIn - t.cashOut,
          topProducts: top,
          blindClose: cfg.blind_close !== false,
          varianceTolerance: num(cfg.variance_tolerance),
          requireApproval: cfg.require_variance_approval === true,
          dailyTarget: num(cfg.daily_target),
        },
      });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/pos/shift/cash — kas masuk/keluar selama shift.
   *  Body: { kind:'IN'|'OUT', amount, reason, ref } */
  router.post('/pos/shift/cash', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const s = await openSessionOf(pool, companyId, me);
      if (!s) return res.status(404).json({ message: 'Tidak ada shift terbuka' });
      const kind = String(b.kind || '').toUpperCase() === 'OUT' ? 'OUT' : 'IN';
      const amount = Math.max(0, num(b.amount));
      const reason = str(b.reason).trim();
      if (amount <= 0) return res.status(400).json({ message: 'Nominal harus lebih dari 0' });
      if (!reason) return res.status(400).json({ message: 'Keterangan wajib diisi (mis. setoran bank, beli perlengkapan)' });
      const emp = (await pool.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const row = (await pool.query(
        `INSERT INTO ops_pos_cash_movements (company_id, session_id, kind, amount, reason, ref, actor_id, actor_name)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id, created_at`,
        [companyId, s.id, kind, amount, reason, str(b.ref) || null, me, emp?.full_name || 'Kasir']
      )).rows[0];
      const t = await shiftTotals(pool, s.id);
      res.json({
        id: row.id, message: kind === 'IN' ? 'Kas masuk dicatat' : 'Kas keluar dicatat',
        expectedCash: expectedCashOf(s, t),
      });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/ops/pos/shift/movements — daftar kas masuk/keluar shift berjalan. */
  router.get('/pos/shift/movements', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const s = await openSessionOf(pool, companyId, me);
      if (!s) return res.json({ items: [] });
      const items = (await pool.query(
        `SELECT * FROM ops_pos_cash_movements WHERE session_id=$1 ORDER BY created_at DESC LIMIT 100`, [s.id]
      )).rows.map(mapMovement);
      res.json({ items, movements: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/pos/shift/close — Z-Report: tutup shift secara profesional.
   *  Body: { countedCash, denominations, varianceNote, handoverTo, handoverCash, note } */
  router.post('/pos/shift/close', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const s = (await client.query("SELECT * FROM ops_pos_sessions WHERE company_id=$1 AND cashier_id=$2 AND status='OPEN' ORDER BY opened_at DESC LIMIT 1 FOR UPDATE",[companyId,me])).rows[0];
      if (!s) return res.status(404).json({ message: 'Tidak ada shift terbuka' });
      const cfg = await settingsOf(client, companyId);
      const t = await shiftTotals(client, s.id);
      const expected = expectedCashOf(s, t);
      const denoms = b.denominations && typeof b.denominations === 'object' ? b.denominations : null;
      const counted = denoms ? denominationsTotal(denoms) : Math.max(0, num(b.countedCash));
      const diff = counted - expected;
      const tolerance = num(cfg.variance_tolerance);
      const needsApproval = cfg.require_variance_approval === true && Math.abs(diff) > tolerance;
      const status = needsApproval ? 'PENDING_APPROVAL' : 'CLOSED';
      const code = s.code || docCode('SHF', undefined, isoDateTz());
      const emp = (await client.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const snapshot = {
        generatedAt: new Date().toISOString(),
        shiftCode: code, cashierName: s.cashier_name, openedAt: s.opened_at, closedAt: new Date().toISOString(),
        openingFloat: num(s.opening_cash), expectedCash: expected, countedCash: counted, cashDiff: diff,
        ...t,
      };
      await client.query(
        `UPDATE ops_pos_sessions SET status=$2, closing_cash=$3, expected_cash=$4, cash_diff=$5, closed_at=now(),
            counted_breakdown=$6, variance_note=$7, close_snapshot=$8, closed_by=$9, note=COALESCE($10,note),
            handover_to=$11, handover_cash=$12, code=COALESCE(code,$13)
          WHERE id=$1`,
        [s.id, status, counted, expected, diff, denoms ? JSON.stringify(denoms) : null,
         str(b.varianceNote) || null, JSON.stringify(snapshot), emp?.full_name || 'Kasir',
         str(b.note) || null, str(b.handoverTo) || null,
         b.handoverCash != null ? num(b.handoverCash) : null, code]
      );
      await client.query('COMMIT');
      res.json({
        ok: true, status, code, expectedCash: expected, countedCash: counted, cashDiff: diff,
        needsApproval, tolerance, totals: t, zReport: snapshot,
        message: needsApproval
          ? 'Shift ditutup — selisih melebihi toleransi, menunggu persetujuan supervisor'
          : 'Shift ditutup. Z-Report tersimpan.',
      });
    } catch (e) { await client.query('ROLLBACK').catch(()=>{}); console.error(e); res.status(500).json({ message: 'Server error' }); } finally { await client.query('ROLLBACK').catch(()=>{}); client.release(); }
  });

  /** GET /api/ops/pos/shift/history — riwayat shift kasir yang login. */
  router.get('/pos/shift/history', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const limit = Math.min(200, Math.max(1, int(req.query.limit, 30)));
      const rows = (await pool.query(
        `SELECT * FROM ops_pos_sessions WHERE company_id=$1 AND cashier_id=$2 ORDER BY opened_at DESC LIMIT $3`,
        [companyId, me, limit]
      )).rows;
      const items: any[] = [];
      for (const r of rows) {
        const t = r.close_snapshot ? null : await shiftTotals(pool, r.id);
        items.push(mapShift(r, t));
      }
      res.json({ items, shifts: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ==================================================================
  //  B. SHIFTING KASIR — SISI ADMIN
  // ==================================================================

  /** GET /api/admin/pos/shifts?from&to&status&cashier — daftar shift + rekap. */
  router.get('/admin/pos/shifts', adminAuth, async (req, res) => {
    try {
      const companyId = (req as any).admin.companyId;
      const to = str(req.query.to) || isoDateTz();
      const from = str(req.query.from) || addDays(to, -6);
      const status = str(req.query.status).trim().toUpperCase();
      const cashier = str(req.query.cashier).trim();
      const params: any[] = [companyId, from, to];
      let extra = '';
      if (status) { params.push(status); extra += ` AND ss.status=$${params.length}`; }
      if (cashier) { params.push(`%${cashier}%`); extra += ` AND ss.cashier_name ILIKE $${params.length}`; }
      const rows = (await pool.query(
        `SELECT ss.*,
                COALESCE(ag.n,0)::int AS sales_count, COALESCE(ag.total,0) AS sales_total,
                COALESCE(ag.gross,0) AS gross, COALESCE(ag.disc,0) AS discount, COALESCE(ag.tax,0) AS tax,
                COALESCE(ag.cogs,0) AS cogs, COALESCE(ag.cash_sales,0) AS cash_sales,
                COALESCE(mv.cash_in,0) AS cash_in, COALESCE(mv.cash_out,0) AS cash_out
           FROM ops_pos_sessions ss
           LEFT JOIN (SELECT session_id, COUNT(*)::int AS n, SUM(total) AS total, SUM(subtotal) AS gross,
                             SUM(discount + member_discount) AS disc, SUM(tax) AS tax, SUM(cogs) AS cogs,
                             SUM(${CASH_PART}) AS cash_sales
                        FROM ops_pos_sales s WHERE s.status='PAID' GROUP BY session_id) ag ON ag.session_id = ss.id
           LEFT JOIN (SELECT session_id,
                             SUM(CASE WHEN kind='IN' THEN amount ELSE 0 END) AS cash_in,
                             SUM(CASE WHEN kind='OUT' THEN amount ELSE 0 END) AS cash_out
                        FROM ops_pos_cash_movements GROUP BY session_id) mv ON mv.session_id = ss.id
          WHERE ss.company_id=$1 AND ${wibDate('ss.opened_at')} BETWEEN $2::date AND $3::date ${extra}
          ORDER BY ss.opened_at DESC LIMIT 300`, params
      )).rows;
      const items = rows.map((r: any) => {
        const totals = {
          count: int(r.sales_count), gross: num(r.gross), discount: num(r.discount), tax: num(r.tax),
          total: num(r.sales_total), netSales: num(r.gross) - num(r.discount), cogs: num(r.cogs),
          profit: num(r.gross) - num(r.discount) - num(r.cogs), cashSales: num(r.cash_sales),
          nonCashSales: num(r.sales_total) - num(r.cash_sales), itemsSold: 0,
          cashIn: num(r.cash_in), cashOut: num(r.cash_out), avgBasket: 0, byMethod: [], voidCount: 0, voidTotal: 0,
        };
        totals.avgBasket = totals.count ? totals.total / totals.count : 0;
        return mapShift(r, totals);
      });
      const closed = items.filter((x: any) => x.status !== 'OPEN');
      const kpi = {
        totalShifts: items.length,
        openShifts: items.filter((x: any) => x.status === 'OPEN').length,
        pendingApproval: items.filter((x: any) => x.status === 'PENDING_APPROVAL').length,
        revenue: items.reduce((a: number, x: any) => a + num(x.totals?.total), 0),
        profit: items.reduce((a: number, x: any) => a + num(x.totals?.profit), 0),
        cashVariance: closed.reduce((a: number, x: any) => a + num(x.cashDiff), 0),
        varianceShifts: closed.filter((x: any) => Math.abs(num(x.cashDiff)) >= 1).length,
        avgDurationMinutes: closed.length
          ? Math.round(closed.reduce((a: number, x: any) => a + int(x.durationMinutes), 0) / closed.length) : 0,
      };
      res.json({ from, to, items, shifts: items, kpi });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/admin/pos/shifts/:id — detail shift (Z-Report + gerakan kas + transaksi). */
  router.get('/admin/pos/shifts/:id', adminAuth, async (req, res) => {
    try {
      const companyId = (req as any).admin.companyId;
      const s = await sessionById(pool, companyId, String(req.params.id));
      if (!s) return res.status(404).json({ message: 'Shift tidak ditemukan' });
      const t = await shiftTotals(pool, s.id);
      const movements = (await pool.query(
        `SELECT * FROM ops_pos_cash_movements WHERE session_id=$1 ORDER BY created_at ASC`, [s.id]
      )).rows.map(mapMovement);
      const sales = (await pool.query(
        `SELECT id, code, total, subtotal, discount, member_discount, tax, cogs, payment_method, status,
                customer_name, cashier_name, created_at
           FROM ops_pos_sales WHERE session_id=$1 ORDER BY created_at ASC LIMIT 500`, [s.id]
      )).rows.map((r: any) => ({
        id: r.id, code: r.code, total: num(r.total), subtotal: num(r.subtotal),
        discount: num(r.discount) + num(r.member_discount), tax: num(r.tax), cogs: num(r.cogs),
        profit: num(r.subtotal) - num(r.discount) - num(r.member_discount) - num(r.cogs),
        paymentMethod: r.payment_method, status: r.status, customerName: r.customer_name,
        cashierName: r.cashier_name, createdAt: r.created_at,
      }));
      const cfg = await settingsOf(pool, companyId);
      res.json({
        shift: mapShift(s, t), movements, sales,
        store: { name: cfg.store_name, address: cfg.store_address, phone: cfg.store_phone, footer: cfg.receipt_footer },
        varianceTolerance: num(cfg.variance_tolerance),
      });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/admin/pos/shifts/:id/approve — setujui selisih kas shift. */
  router.post('/admin/pos/shifts/:id/approve', adminAuth, async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).admin.companyId;
      const adminName = (req as any).admin?.name || 'Superadmin';
      const s = await sessionById(pool, companyId, String(req.params.id));
      if (!s) return res.status(404).json({ message: 'Shift tidak ditemukan' });
      if (s.status !== 'PENDING_APPROVAL') return res.status(400).json({ message: 'Shift ini tidak menunggu persetujuan' });
      await pool.query(
        `UPDATE ops_pos_sessions SET status='CLOSED', approved_by=$2, approved_at=now(),
            variance_note=COALESCE($3, variance_note) WHERE id=$1`,
        [s.id, adminName, str(b.note) || null]
      );
      res.json({ ok: true, message: 'Selisih kas disetujui — shift ditutup final' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/admin/pos/shifts/:id/force-close — tutup paksa shift (mis. kasir lupa tutup). */
  router.post('/admin/pos/shifts/:id/force-close', adminAuth, async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).admin.companyId;
      const adminName = (req as any).admin?.name || 'Superadmin';
      const s = await sessionById(pool, companyId, String(req.params.id));
      if (!s) return res.status(404).json({ message: 'Shift tidak ditemukan' });
      if (s.status !== 'OPEN') return res.status(400).json({ message: 'Hanya shift terbuka yang bisa ditutup paksa' });
      const t = await shiftTotals(pool, s.id);
      const expected = expectedCashOf(s, t);
      const counted = b.countedCash != null ? Math.max(0, num(b.countedCash)) : expected;
      const diff = counted - expected;
      const snapshot = {
        generatedAt: new Date().toISOString(), shiftCode: s.code, cashierName: s.cashier_name,
        openedAt: s.opened_at, closedAt: new Date().toISOString(), openingFloat: num(s.opening_cash),
        expectedCash: expected, countedCash: counted, cashDiff: diff, forced: true,
        reason: str(b.note) || 'Ditutup paksa oleh admin', ...t,
      };
      await pool.query(
        `UPDATE ops_pos_sessions SET status='FORCE_CLOSED', closing_cash=$2, expected_cash=$3, cash_diff=$4,
            closed_at=now(), close_snapshot=$5, closed_by=$6, variance_note=$7 WHERE id=$1`,
        [s.id, counted, expected, diff, JSON.stringify(snapshot), adminName, str(b.note) || 'Ditutup paksa oleh admin']
      );
      res.json({ ok: true, expectedCash: expected, countedCash: counted, cashDiff: diff, message: 'Shift ditutup paksa' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ==================================================================
  //  C. PENGHASILAN (REVENUE ANALYTICS)
  // ==================================================================

  /** GET /api/admin/pos/revenue?from&to — dashboard penghasilan lengkap. */
  router.get('/admin/pos/revenue', adminAuth, async (req, res) => {
    try {
      const companyId = (req as any).admin.companyId;
      const to = str(req.query.to) || isoDateTz();
      const from = str(req.query.from) || addDays(to, -29);
      const days = Math.max(1, Math.round((new Date(to + 'T00:00:00Z').getTime() - new Date(from + 'T00:00:00Z').getTime()) / 86400000) + 1);
      const prevTo = addDays(from, -1);
      const prevFrom = addDays(from, -days);
      const range = `${wibDate('s.created_at')} BETWEEN $2::date AND $3::date`;

      const summaryOf = async (f: string, t2: string) => {
        const r = (await pool.query(
          `SELECT COUNT(*)::int AS n, COALESCE(SUM(subtotal),0) AS gross,
                  COALESCE(SUM(discount + member_discount),0) AS discount, COALESCE(SUM(tax),0) AS tax,
                  COALESCE(SUM(total),0) AS total, COALESCE(SUM(cogs),0) AS cogs
             FROM ops_pos_sales s
            WHERE s.company_id=$1 AND s.status='PAID' AND ${range}`, [companyId, f, t2]
        )).rows[0];
        const it = (await pool.query(
          `SELECT COALESCE(SUM(i.qty),0) AS qty FROM ops_pos_sale_items i
             JOIN ops_pos_sales s ON s.id = i.sale_id
            WHERE s.company_id=$1 AND s.status='PAID' AND ${range}`, [companyId, f, t2]
        )).rows[0];
        const vo = (await pool.query(
          `SELECT COUNT(*)::int AS n, COALESCE(SUM(total),0) AS total FROM ops_pos_sales s
            WHERE s.company_id=$1 AND s.status IN ('VOID','REFUNDED') AND ${range}`, [companyId, f, t2]
        )).rows[0];
        const net = num(r?.gross) - num(r?.discount);
        const n = int(r?.n);
        return {
          count: n, gross: num(r?.gross), discount: num(r?.discount), tax: num(r?.tax), total: num(r?.total),
          netSales: net, cogs: num(r?.cogs), profit: net - num(r?.cogs),
          marginPct: net > 0 ? ((net - num(r?.cogs)) / net) * 100 : 0,
          itemsSold: int(it?.qty), avgBasket: n ? num(r?.total) / n : 0,
          voidCount: int(vo?.n), voidTotal: num(vo?.total),
        };
      };

      const summary = await summaryOf(from, to);
      const previous = await summaryOf(prevFrom, prevTo);
      const growth = (a: number, b: number) => (b > 0 ? ((a - b) / b) * 100 : (a > 0 ? 100 : 0));

      const byMethod = (await pool.query(
        `SELECT m.key AS method, COALESCE(SUM(m.value::numeric),0) AS amount, COUNT(DISTINCT s.id)::int AS n
           FROM ops_pos_sales s,
                jsonb_each_text(COALESCE(s.payment_methods, jsonb_build_object(s.payment_method, s.total))) m
          WHERE s.company_id=$1 AND s.status='PAID' AND ${range}
          GROUP BY 1 ORDER BY 2 DESC`, [companyId, from, to]
      )).rows.map((x: any) => ({ method: String(x.method || '').toUpperCase(), amount: num(x.amount), count: int(x.n) }));

      const byCashier = (await pool.query(
        `SELECT COALESCE(s.cashier_name,'-') AS name, COUNT(*)::int AS n, COALESCE(SUM(s.total),0) AS total,
                COALESCE(SUM(s.subtotal - s.discount - s.member_discount - s.cogs),0) AS profit
           FROM ops_pos_sales s
          WHERE s.company_id=$1 AND s.status='PAID' AND ${range}
          GROUP BY 1 ORDER BY 3 DESC LIMIT 20`, [companyId, from, to]
      )).rows.map((x: any) => ({ name: x.name, count: int(x.n), total: num(x.total), profit: num(x.profit) }));

      const byCategory = (await pool.query(
        `SELECT COALESCE(p.category,'Tanpa kategori') AS name, COALESCE(SUM(i.total),0) AS total,
                COALESCE(SUM(i.qty),0)::int AS qty,
                COALESCE(SUM((i.price - i.cost) * i.qty),0) AS profit
           FROM ops_pos_sale_items i
           JOIN ops_pos_sales s ON s.id = i.sale_id
           LEFT JOIN ops_products p ON p.id = i.product_id
          WHERE s.company_id=$1 AND s.status='PAID' AND ${range}
          GROUP BY 1 ORDER BY 2 DESC LIMIT 20`, [companyId, from, to]
      )).rows.map((x: any) => ({ name: x.name, total: num(x.total), qty: int(x.qty), profit: num(x.profit) }));

      const byHour = (await pool.query(
        `SELECT EXTRACT(HOUR FROM (s.created_at AT TIME ZONE 'UTC') + interval '7 hours')::int AS hour,
                COUNT(*)::int AS n, COALESCE(SUM(s.total),0) AS total
           FROM ops_pos_sales s
          WHERE s.company_id=$1 AND s.status='PAID' AND ${range}
          GROUP BY 1 ORDER BY 1`, [companyId, from, to]
      )).rows.map((x: any) => ({ hour: int(x.hour), count: int(x.n), total: num(x.total) }));

      const byDay = (await pool.query(
        `SELECT ${wibDate('s.created_at')}::text AS date, COUNT(*)::int AS n, COALESCE(SUM(s.total),0) AS total,
                COALESCE(SUM(s.subtotal - s.discount - s.member_discount - s.cogs),0) AS profit
           FROM ops_pos_sales s
          WHERE s.company_id=$1 AND s.status='PAID' AND ${range}
          GROUP BY 1 ORDER BY 1`, [companyId, from, to]
      )).rows.map((x: any) => ({ date: x.date, count: int(x.n), total: num(x.total), profit: num(x.profit) }));

      const topProducts = (await pool.query(
        `SELECT i.product_name AS name, i.sku, COALESCE(SUM(i.qty),0)::int AS qty, COALESCE(SUM(i.total),0) AS total,
                COALESCE(SUM((i.price - i.cost) * i.qty),0) AS profit
           FROM ops_pos_sale_items i JOIN ops_pos_sales s ON s.id = i.sale_id
          WHERE s.company_id=$1 AND s.status='PAID' AND ${range}
          GROUP BY 1, 2 ORDER BY 4 DESC LIMIT 15`, [companyId, from, to]
      )).rows.map((x: any) => ({ name: x.name, sku: x.sku, qty: int(x.qty), total: num(x.total), profit: num(x.profit) }));

      const shifts = (await pool.query(
        `SELECT ss.id, ss.code, ss.cashier_name, ss.status, ss.opened_at, ss.closed_at, ss.cash_diff,
                COUNT(s.id)::int AS n, COALESCE(SUM(s.total),0) AS total
           FROM ops_pos_sessions ss
           LEFT JOIN ops_pos_sales s ON s.session_id = ss.id AND s.status='PAID'
          WHERE ss.company_id=$1 AND ${wibDate('ss.opened_at')} BETWEEN $2::date AND $3::date
          GROUP BY 1,2,3,4,5,6,7 ORDER BY ss.opened_at DESC LIMIT 60`, [companyId, from, to]
      )).rows.map((x: any) => ({
        id: x.id, code: x.code, cashierName: x.cashier_name, status: x.status,
        openedAt: x.opened_at, closedAt: x.closed_at, cashDiff: x.cash_diff != null ? num(x.cash_diff) : null,
        count: int(x.n), total: num(x.total),
      }));

      const cfg = await settingsOf(pool, companyId);
      const today = isoDateTz();
      const todayRow = byDay.find((d: any) => d.date === today);
      const dailyTarget = num(cfg.daily_target);

      res.json({
        from, to, days,
        summary,
        comparison: {
          from: prevFrom, to: prevTo, summary: previous,
          growth: {
            total: growth(summary.total, previous.total),
            profit: growth(summary.profit, previous.profit),
            count: growth(summary.count, previous.count),
            avgBasket: growth(summary.avgBasket, previous.avgBasket),
            marginPct: summary.marginPct - previous.marginPct,
          },
        },
        byMethod, byCashier, byCategory, byHour, byDay, topProducts, shifts,
        target: {
          daily: dailyTarget,
          todayTotal: todayRow ? todayRow.total : 0,
          todayCount: todayRow ? todayRow.count : 0,
          achievementPct: dailyTarget > 0 ? ((todayRow ? todayRow.total : 0) / dailyTarget) * 100 : 0,
        },
      });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/admin/pos/revenue/daily?from&to — seri harian untuk grafik + target. */
  router.get('/admin/pos/revenue/daily', adminAuth, async (req, res) => {
    try {
      const companyId = (req as any).admin.companyId;
      const to = str(req.query.to) || isoDateTz();
      const from = str(req.query.from) || addDays(to, -13);
      const rows = (await pool.query(
        `SELECT ${wibDate('s.created_at')}::text AS date, COUNT(*)::int AS n, COALESCE(SUM(s.total),0) AS total,
                COALESCE(SUM(s.subtotal - s.discount - s.member_discount - s.cogs),0) AS profit
           FROM ops_pos_sales s
          WHERE s.company_id=$1 AND s.status='PAID'
            AND ${wibDate('s.created_at')} BETWEEN $2::date AND $3::date
          GROUP BY 1 ORDER BY 1`, [companyId, from, to]
      )).rows.map((x: any) => ({ date: x.date, count: int(x.n), total: num(x.total), profit: num(x.profit) }));
      const cfg = await settingsOf(pool, companyId);
      const target = num(cfg.daily_target);
      const series: any[] = [];
      const days = Math.max(1, Math.round((new Date(to + 'T00:00:00Z').getTime() - new Date(from + 'T00:00:00Z').getTime()) / 86400000) + 1);
      for (let i = 0; i < days; i++) {
        const d = addDays(from, i);
        const hit = rows.find((r: any) => r.date === d);
        series.push({ date: d, count: hit ? hit.count : 0, total: hit ? hit.total : 0, profit: hit ? hit.profit : 0, target });
      }
      res.json({ from, to, series, target });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/admin/pos/revenue/export.csv?from&to — ekspor pembukuan (CSV). */
  router.get('/admin/pos/revenue/export.csv', adminAuth, async (req, res) => {
    try {
      const companyId = (req as any).admin.companyId;
      const to = str(req.query.to) || isoDateTz();
      const from = str(req.query.from) || addDays(to, -29);
      const rows = (await pool.query(
        `SELECT s.code, s.created_at, s.cashier_name, ss.code AS shift_code, s.customer_name,
                s.subtotal, s.discount, s.member_discount, s.tax, s.total, s.cogs,
                s.payment_method, s.payment_methods, s.status,
                COALESCE((SELECT string_agg(i.product_name || ' x' || i.qty, '; ')
                            FROM ops_pos_sale_items i WHERE i.sale_id = s.id), '') AS items
           FROM ops_pos_sales s
           LEFT JOIN ops_pos_sessions ss ON ss.id = s.session_id
          WHERE s.company_id=$1 AND ${wibDate('s.created_at')} BETWEEN $2::date AND $3::date
          ORDER BY s.created_at ASC LIMIT 5000`, [companyId, from, to]
      )).rows;
      const esc = (v: any) => `"${String(v == null ? '' : v).replace(/"/g, '""')}"`;
      const head = ['Kode', 'Tanggal (WIB)', 'Jam (WIB)', 'Kasir', 'Kode Shift', 'Pelanggan', 'Subtotal',
        'Diskon', 'Diskon Member', 'Pajak', 'Total', 'HPP', 'Laba Kotor', 'Metode', 'Rincian Metode', 'Status', 'Item'];
      const lines = [head.map(esc).join(',')];
      for (const r of rows) {
        const wib = new Date(new Date(r.created_at).getTime() + 7 * 3600 * 1000).toISOString();
        const net = num(r.subtotal) - num(r.discount) - num(r.member_discount);
        lines.push([
          r.code, wib.slice(0, 10), wib.slice(11, 16), r.cashier_name, r.shift_code, r.customer_name,
          num(r.subtotal), num(r.discount), num(r.member_discount), num(r.tax), num(r.total), num(r.cogs),
          net - num(r.cogs), r.payment_method,
          r.payment_methods ? JSON.stringify(r.payment_methods) : '', r.status, r.items,
        ].map(esc).join(','));
      }
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="penghasilan-pos-${from}-${to}.csv"`);
      res.send('\uFEFF' + lines.join('\n'));
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/admin/pos/sales/:id/void — batalkan/refund transaksi + kembalikan stok. */
  router.post('/admin/pos/sales/:id/void', adminAuth, async (req, res) => {
    const client = await pool.connect();
    try {
      const b = req.body ?? {};
      const companyId = (req as any).admin.companyId;
      const adminName = (req as any).admin?.name || 'Superadmin';
      const reason = str(b.reason).trim();
      if (!reason) return res.status(400).json({ message: 'Alasan void/refund wajib diisi' });
      const sale = (await client.query(
        `SELECT * FROM ops_pos_sales WHERE id=$1 AND company_id=$2`, [req.params.id, companyId]
      )).rows[0];
      if (!sale) return res.status(404).json({ message: 'Transaksi tidak ditemukan' });
      if (sale.status !== 'PAID') return res.status(400).json({ message: 'Hanya transaksi LUNAS yang dapat di-void' });
      const items = (await client.query(
        `SELECT product_id, qty FROM ops_pos_sale_items WHERE sale_id=$1`, [sale.id]
      )).rows;
      const newStatus = b.refund === true ? 'REFUNDED' : 'VOID';
      await client.query('BEGIN');
      for (const it of items) {
        if (it.product_id) {
          await client.query(
            `UPDATE ops_products SET stock = stock + $2, updated_at=now() WHERE id=$1`, [it.product_id, int(it.qty)]
          );
        }
      }
      await client.query(
        `UPDATE ops_pos_sales SET status=$2, voided_at=now(), void_reason=$3, void_by=$4 WHERE id=$1`,
        [sale.id, newStatus, reason, adminName]
      );
      await client.query('COMMIT');
      res.json({ ok: true, status: newStatus, message: newStatus === 'REFUNDED' ? 'Transaksi di-refund & stok dikembalikan' : 'Transaksi di-void & stok dikembalikan' });
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* ignore */ }
      console.error(e); res.status(500).json({ message: 'Server error' });
    } finally { client.release(); }
  });

  /** GET /api/admin/pos/target — pengaturan shifting & target penghasilan. */
  router.get('/admin/pos/target', adminAuth, async (req, res) => {
    try {
      const cfg = await settingsOf(pool, (req as any).admin.companyId);
      res.json({ settings: mapShiftSettings(cfg) });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** PUT /api/admin/pos/target — ubah target, toleransi selisih, blind close, struk. */
  router.put('/admin/pos/target', adminAuth, async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).admin.companyId;
      await settingsOf(pool, companyId);
      const row = (await pool.query(
        `UPDATE ops_settings SET
            daily_target = COALESCE($2, daily_target),
            variance_tolerance = COALESCE($3, variance_tolerance),
            require_variance_approval = COALESCE($4, require_variance_approval),
            blind_close = COALESCE($5, blind_close),
            receipt_footer = COALESCE($6, receipt_footer),
            store_address = COALESCE($7, store_address),
            store_phone = COALESCE($8, store_phone),
            updated_at = now()
          WHERE company_id=$1 RETURNING *`,
        [companyId,
         b.dailyTarget != null ? Math.max(0, num(b.dailyTarget)) : null,
         b.varianceTolerance != null ? Math.max(0, num(b.varianceTolerance)) : null,
         typeof b.requireVarianceApproval === 'boolean' ? b.requireVarianceApproval : null,
         typeof b.blindClose === 'boolean' ? b.blindClose : null,
         b.receiptFooter != null ? str(b.receiptFooter) : null,
         b.storeAddress != null ? str(b.storeAddress) : null,
         b.storePhone != null ? str(b.storePhone) : null]
      )).rows[0];
      res.json({ settings: mapShiftSettings(row), message: 'Pengaturan shifting & target disimpan' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  return router;
}

function mapMovement(r: any) {
  return {
    id: r.id, kind: String(r.kind || 'IN').toUpperCase(), amount: num(r.amount),
    reason: r.reason, ref: r.ref, actorName: r.actor_name, createdAt: r.created_at,
  };
}

function mapShiftSettings(r: any) {
  return {
    dailyTarget: r ? num(r.daily_target) : 0,
    varianceTolerance: r ? num(r.variance_tolerance) : 0,
    requireVarianceApproval: r ? r.require_variance_approval === true : false,
    blindClose: r ? r.blind_close !== false : true,
    receiptFooter: r ? r.receipt_footer : null,
    storeAddress: r ? r.store_address : null,
    storePhone: r ? r.store_phone : null,
  };
}
