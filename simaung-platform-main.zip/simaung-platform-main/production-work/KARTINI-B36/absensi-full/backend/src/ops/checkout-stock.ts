type Client={query:(sql:string,values?:any[])=>Promise<{rows:any[];rowCount?:number|null}>};
export class CheckoutError extends Error {status=409;}
/** Must run inside the sale transaction. Conditional updates serialize concurrent stock claims. */
export async function reserveCheckoutStock(client:Client,companyId:string,lines:Array<{pid:string;variantId?:string|null;qty:number}>){
 for(const line of [...lines].sort((a,b)=>a.pid.localeCompare(b.pid)||String(a.variantId||'').localeCompare(String(b.variantId||'')))){
  if(!Number.isSafeInteger(line.qty)||line.qty<=0)throw new CheckoutError('Jumlah produk tidak valid.');
  const product=await client.query(`UPDATE ops_products SET stock=stock-$3,updated_at=now() WHERE id=$1 AND company_id=$2 AND active=true AND stock >= $3 RETURNING id`,[line.pid,companyId,line.qty]);
  if(!product.rows.length)throw new CheckoutError('Produk tidak aktif atau stok tidak mencukupi.');
  if(line.variantId){
   const variant=await client.query(`UPDATE ops_product_variants SET stock=stock-$3 WHERE id=$1 AND product_id=$2 AND active=true AND stock >= $3 RETURNING id`,[line.variantId,line.pid,line.qty]);
   if(!variant.rows.length)throw new CheckoutError('Varian tidak aktif atau stok tidak mencukupi.');
  }
 }
}
