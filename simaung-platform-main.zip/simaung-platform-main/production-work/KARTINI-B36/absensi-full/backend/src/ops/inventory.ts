// =====================================================================
//  MODUL OPERASIONAL (B11) — Gudang & Stock Opname.
//  - Produk: master barang milik perusahaan.
//  - Opname: PRAMUNIAGA (per-area) & KEPALA_GUDANG (full) + crosscek hasil.
// =====================================================================
import express from 'express';
import type { Pool } from 'pg';
import { ensureOpsTables, int, num, str, requireOpsRole, isoDateTz } from './common.js';

const OPS_ROLES = ['PRAMUNIAGA', 'KEPALA_GUDANG', 'KASIR'];

// Batas panjang foto produk (data-URL base64). Body JSON server = 8mb,
// jadi 4.000.000 karakter aman (~2,9 MB gambar setelah base64).
const IMAGE_MAX_LEN = 4_000_000;
/** Normalkan input foto: '' / null = hapus, teks panjang = simpan, undefined = jangan ubah. */
function normImage(v: any): { set: boolean; value: string | null } {
  if (v === undefined) return { set: false, value: null };
  const s = str(v).trim();
  return { set: true, value: s === '' ? null : s.slice(0, IMAGE_MAX_LEN) };
}

export function createOpsInventoryRouter(deps: { pool: Pool; auth: express.RequestHandler; adminAuth: express.RequestHandler }) {
  const { pool, auth, adminAuth } = deps;
  const router = express.Router();

  // ------------------------------------------------------------------
  //  PRODUK — Master barang (dipakai bersama oleh POS & Stock Opname).
  //  Dua pintu masuk dengan logika identik:
  //   - /admin/products   -> panel web admin (token admin).
  //   - /catalog          -> aplikasi, khusus jabatan KEPALA_GUDANG.
  // ------------------------------------------------------------------
  const CATALOG_ROLES = ['KEPALA_GUDANG'];

  function productHandlers(companyIdOf: (req: any) => string) {
    const list = async (req: any, res: any) => {
      try {
        await ensureOpsTables(pool);
        const rows = (await pool.query(
          `SELECT id, sku, barcode, name, category, unit, price, cost, stock, min_stock, active, image
             FROM ops_products WHERE company_id=$1 ORDER BY name ASC LIMIT 5000`, [companyIdOf(req)]
        )).rows;
        const items = rows.map(mapProduct);
        res.json({ items, products: items });
      } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
    };
    const create = async (req: any, res: any) => {
      try {
        await ensureOpsTables(pool);
        const b = req.body ?? {};
        const name = str(b.name).trim();
        if (!name) return res.status(400).json({ message: 'Nama barang wajib diisi' });
        const img = normImage(b.image);
        const row = (await pool.query(
          `INSERT INTO ops_products (company_id, sku, barcode, name, category, unit, price, cost, stock, min_stock, active, image)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
          [companyIdOf(req), str(b.sku) || null, str(b.barcode) || null, name, str(b.category) || null, str(b.unit) || 'pcs',
           num(b.price), num(b.cost), int(b.stock), int(b.minStock), b.active !== false, img.set ? img.value : null]
        )).rows[0];
        res.json({ id: row.id, message: 'Barang ditambahkan' });
      } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
    };
    const update = async (req: any, res: any) => {
      try {
        await ensureOpsTables(pool);
        const b = req.body ?? {};
        const img = normImage(b.image);
        const row = (await pool.query(
          `UPDATE ops_products SET
             sku=COALESCE($3,sku), barcode=COALESCE($4,barcode), name=COALESCE($5,name), category=COALESCE($6,category),
             unit=COALESCE($7,unit), price=COALESCE($8,price), cost=COALESCE($9,cost),
             stock=COALESCE($10,stock), min_stock=COALESCE($11,min_stock),
             active=COALESCE($12,active), image=COALESCE($13,image), updated_at=now()
           WHERE id=$1 AND company_id=$2 RETURNING id`,
          [req.params.id, companyIdOf(req),
           b.sku != null ? str(b.sku) : null, b.barcode != null ? str(b.barcode) : null,
           b.name != null ? str(b.name) : null,
           b.category != null ? str(b.category) : null, b.unit != null ? str(b.unit) : null,
           b.price != null ? num(b.price) : null, b.cost != null ? num(b.cost) : null,
           b.stock != null ? int(b.stock) : null, b.minStock != null ? int(b.minStock) : null,
           typeof b.active === 'boolean' ? b.active : null,
           img.set ? img.value : null]
        )).rows[0];
        if (!row) return res.status(404).json({ message: 'Barang tidak ditemukan' });
        res.json({ message: 'Barang diperbarui' });
      } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
    };
    const remove = async (req: any, res: any) => {
      try {
        await ensureOpsTables(pool);
        const row = (await pool.query(
          `UPDATE ops_products SET active=false,updated_at=now() WHERE id=$1 AND company_id=$2 RETURNING id`,
          [req.params.id, companyIdOf(req)]
        )).rows[0];
        if (!row) return res.status(404).json({ message: 'Barang tidak ditemukan' });
        res.json({ message: 'Barang diarsipkan; riwayat transaksi tetap tersimpan' });
      } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
    };
    return { list, create, update, remove };
  }

  // Panel web admin.
  const adminProducts = productHandlers((req) => (req as any).admin.companyId);
  router.get('/admin/products', adminAuth, adminProducts.list);
  router.post('/admin/products', adminAuth, adminProducts.create);
  router.put('/admin/products/:id', adminAuth, adminProducts.update);
  router.delete('/admin/products/:id', adminAuth, adminProducts.remove);

  // Aplikasi — Kepala Gudang mengelola katalog dari dalam app.
  const catalog = productHandlers((req) => (req as any).user.companyId);
  router.get('/catalog', auth, requireOpsRole(pool, ...CATALOG_ROLES), catalog.list);
  router.post('/catalog', auth, requireOpsRole(pool, ...CATALOG_ROLES), catalog.create);
  router.put('/catalog/:id', auth, requireOpsRole(pool, ...CATALOG_ROLES), catalog.update);
  router.delete('/catalog/:id', auth, requireOpsRole(pool, ...CATALOG_ROLES), catalog.remove);

  /** GET /api/ops/products — daftar barang untuk karyawan operasional
      (dipakai katalog POS & pilihan barang pada Stock Opname). */
  router.get('/products', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const q = str(req.query.q).trim();
      const rows = (await pool.query(
        `SELECT id, sku, barcode, name, category, unit, price, cost, stock, min_stock, active, image
           FROM ops_products WHERE company_id=$1 ${q ? 'AND (name ILIKE $2 OR sku ILIKE $2 OR barcode ILIKE $2)' : ''}
           ORDER BY name ASC LIMIT 5000`,
        q ? [companyId, `%${q}%`] : [companyId]
      )).rows;
      const items = rows.map(mapProduct);
      res.json({ items, products: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/ops/products/lookup?code= — cari produk via barcode/SKU (untuk scan). */
  router.get('/products/lookup', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const code = str(req.query.code).trim();
      if (!code) return res.status(400).json({ message: 'Kode kosong' });
      const row = (await pool.query(
        `SELECT id, sku, barcode, name, category, unit, price, cost, stock, min_stock, active, image
           FROM ops_products WHERE company_id=$1 AND (barcode=$2 OR sku=$2 OR name ILIKE $3)
           ORDER BY (barcode=$2) DESC, (sku=$2) DESC LIMIT 1`,
        [companyId, code, `%${code}%`]
      )).rows[0];
      if (!row) return res.status(404).json({ message: 'Produk tidak ditemukan' });
      res.json({ product: mapProduct(row) });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/ops/products/:id/variants — daftar varian produk. */
  router.get('/products/:id/variants', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    try {
      const rows = (await pool.query(
        `SELECT v.id, v.product_id, v.name, v.price, v.stock, v.sku, v.active
           FROM ops_product_variants v JOIN ops_products p ON p.id = v.product_id
          WHERE v.product_id=$1 AND p.company_id=$2 ORDER BY v.name`,
        [req.params.id, (req as any).user.companyId]
      )).rows;
      res.json({ items: rows.map(mapVariant), variants: rows.map(mapVariant) });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/products/:id/variants — tambah varian. */
  router.post('/products/:id/variants', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const owner = (await pool.query(`SELECT id FROM ops_products WHERE id=$1 AND company_id=$2`, [req.params.id, companyId])).rows[0];
      if (!owner) return res.status(404).json({ message: 'Produk tidak ditemukan' });
      const row = (await pool.query(
        `INSERT INTO ops_product_variants (product_id, name, price, stock, sku, active)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
        [req.params.id, str(b.name).trim() || 'Varian', num(b.price), int(b.stock), str(b.sku) || null, b.active !== false]
      )).rows[0];
      res.json({ id: row.id, message: 'Varian ditambahkan' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** PUT /api/ops/variants/:vid — ubah varian. */
  router.put('/variants/:vid', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const row = (await pool.query(
        `UPDATE ops_product_variants v SET
           name=COALESCE($3,v.name), price=COALESCE($4,v.price), stock=COALESCE($5,v.stock),
           sku=COALESCE($6,v.sku), active=COALESCE($7,v.active)
         FROM ops_products p
         WHERE v.id=$1 AND v.product_id=p.id AND p.company_id=$2 RETURNING v.id`,
        [req.params.vid, companyId,
         b.name != null ? str(b.name) : null, b.price != null ? num(b.price) : null,
         b.stock != null ? int(b.stock) : null, b.sku != null ? str(b.sku) : null,
         typeof b.active === 'boolean' ? b.active : null]
      )).rows[0];
      if (!row) return res.status(404).json({ message: 'Varian tidak ditemukan' });
      res.json({ message: 'Varian diperbarui' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** DELETE /api/ops/variants/:vid — hapus varian. */
  router.delete('/variants/:vid', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const row = (await pool.query(
        `DELETE FROM ops_product_variants v USING ops_products p
          WHERE v.id=$1 AND v.product_id=p.id AND p.company_id=$2 RETURNING v.id`,
        [req.params.vid, companyId]
      )).rows[0];
      if (!row) return res.status(404).json({ message: 'Varian tidak ditemukan' });
      res.json({ message: 'Varian dihapus' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ------------------------------------------------------------------
  //  STOCK OPNAME
  // ------------------------------------------------------------------

  /**
   * GET /api/ops/opnames — daftar sesi opname.
   * Query: ?status= , ?mine=1 (hanya milik sendiri).
   */
  router.get('/opnames', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    try {
      const me = (req as any).user.employeeId;
      const companyId = (req as any).user.companyId;
      const mine = str(req.query.mine) === '1';
      const rows = (await pool.query(
        `SELECT o.*, e.full_name AS emp_name FROM ops_stock_opnames o
           LEFT JOIN employees e ON e.id = o.employee_id
          WHERE o.company_id=$1 ${mine ? 'AND o.employee_id=$2' : ''}
          ORDER BY o.created_at DESC LIMIT 200`,
        mine ? [companyId, me] : [companyId]
      )).rows;
      const items = rows.map(mapOpname);
      res.json({ items, opnames: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /**
   * GET /api/ops/opnames/log — rekap mutasi harian (flat) ala Allstock.
   * Query: ?date=YYYY-MM-DD (default hari ini), ?mine=1 (hanya sesi sendiri).
   */
  router.get('/opnames/log', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const date = str(req.query.date) || isoDateTz();
      const mine = str(req.query.mine) === '1';
      const rows = (await pool.query(
        `SELECT i.id, i.product_name, i.sku, i.qty_in, i.qty_out, i.qty_reject, i.note,
                o.id AS opname_id, o.employee_name, o.kind, o.area, o.status, o.created_at
           FROM ops_stock_opname_items i
           JOIN ops_stock_opnames o ON o.id = i.opname_id
          WHERE o.company_id=$1 AND o.created_at::date=$2::date ${mine ? 'AND o.employee_id=$3' : ''}
          ORDER BY o.created_at DESC`,
        mine ? [companyId, date, me] : [companyId, date]
      )).rows;
      const items = rows.map((r: any) => ({
        id: r.id, opnameId: r.opname_id, productName: r.product_name, sku: r.sku,
        qtyIn: int(r.qty_in), qtyOut: int(r.qty_out), qtyReject: int(r.qty_reject), note: r.note,
        employeeName: r.employee_name, kind: r.kind, area: r.area, status: r.status, createdAt: r.created_at,
      }));
      const totals = items.reduce((a: any, x: any) => {
        a.in += x.qtyIn; a.out += x.qtyOut; a.reject += x.qtyReject; return a;
      }, { in: 0, out: 0, reject: 0 });
      res.json({ date, items, totals });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/ops/opnames/:id — detail sesi + item. */
  router.get('/opnames/:id', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    try {
      const head = (await pool.query(
        `SELECT o.*, e.full_name AS emp_name FROM ops_stock_opnames o
           LEFT JOIN employees e ON e.id = o.employee_id
          WHERE o.id=$1 AND o.company_id=$2`, [req.params.id, (req as any).user.companyId]
      )).rows[0];
      if (!head) return res.status(404).json({ message: 'Sesi opname tidak ditemukan' });
      const items = (await pool.query(
        `SELECT id, product_id, product_name, sku, system_stock, counted_stock, diff, note, qty_in, qty_out, qty_reject
           FROM ops_stock_opname_items WHERE opname_id=$1 ORDER BY product_name`, [req.params.id]
      )).rows.map((r: any) => ({
        id: r.id, productId: r.product_id, productName: r.product_name, sku: r.sku,
        systemStock: int(r.system_stock), countedStock: int(r.counted_stock), diff: int(r.diff), note: r.note,
        qtyIn: int(r.qty_in), qtyOut: int(r.qty_out), qtyReject: int(r.qty_reject),
      }));
      res.json({ opname: mapOpname(head), items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /**
   * POST /api/ops/opnames — simpan sesi opname baru.
   * Body: { area, note, items:[{productId, countedStock, note}] }.
   * system_stock diambil dari master produk saat penyimpanan.
   */
  router.post('/opnames', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    const client = await pool.connect();
    try {
      const b = req.body ?? {};
      const me = (req as any).user.employeeId;
      const companyId = (req as any).user.companyId;
      const input = Array.isArray(b.items) ? b.items : [];
      if (!input.length) return res.status(400).json({ message: 'Tidak ada item opname' });
      const roles = (req as any).employeeRoles || [];
      const kind = roles.includes('KEPALA_GUDANG') && !roles.includes('PRAMUNIAGA')
        ? 'KEPALA_GUDANG'
        : (b.kind === 'FULL' ? 'KEPALA_GUDANG' : 'PRAMUNIAGA');

      const empRow = (await client.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const empName = empRow?.full_name || 'Karyawan';

      await client.query('BEGIN');
      let totalDiff = 0;
      const rows: any[] = [];
      for (const it of input) {
        const pid = str(it.productId) || null;
        let name = str(it.productName) || '';
        let sku = str(it.sku) || null;
        let sysStock = int(it.systemStock);
        if (pid) {
          const p = (await client.query(`SELECT name, sku, stock FROM ops_products WHERE id=$1 AND company_id=$2`, [pid, companyId])).rows[0];
          if (p) { name = p.name; sku = p.sku; sysStock = int(p.stock); }
        }
        const qtyIn = int(it.qtyIn);
        const qtyOut = int(it.qtyOut);
        const qtyReject = int(it.qtyReject);
        const hasMutation = qtyIn || qtyOut || qtyReject;
        // Bila ada mutasi (masuk/keluar/reject): stok fisik = sistem + masuk - keluar - reject.
        // Bila tidak: pakai countedStock yang diisi petugas.
        const counted = hasMutation
          ? sysStock + qtyIn - qtyOut - qtyReject
          : int(it.countedStock);
        const diff = counted - sysStock;
        totalDiff += Math.abs(diff);
        rows.push([pid, name, sku, sysStock, counted, diff, str(it.note) || null, qtyIn, qtyOut, qtyReject]);
        // Terapkan mutasi ke stok master secara realtime.
        if (pid && hasMutation) {
          await client.query(`UPDATE ops_products SET stock = stock + $3 - $4 - $5, updated_at=now() WHERE id=$1 AND company_id=$2`,
            [pid, companyId, qtyIn, qtyOut, qtyReject]);
        }
      }
      const head = (await client.query(
        `INSERT INTO ops_stock_opnames (company_id, employee_id, employee_name, kind, area, note, total_items, total_diff, status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, created_at`,
        [companyId, me, empName, kind, str(b.area) || null, str(b.note) || null, rows.length, totalDiff,
         kind === 'KEPALA_GUDANG' ? 'FINAL' : 'SUBMITTED']
      )).rows[0];
      for (const r of rows) {
        await client.query(
          `INSERT INTO ops_stock_opname_items (opname_id, product_id, product_name, sku, system_stock, counted_stock, diff, note, qty_in, qty_out, qty_reject)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
          [head.id, ...r]
        );
      }
      await client.query('COMMIT');
      res.json({ id: head.id, message: 'Opname tersimpan', totalItems: rows.length, totalDiff });
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* ignore */ }
      console.error(e); res.status(500).json({ message: 'Server error' });
    } finally { client.release(); }
  });

  /**
   * POST /api/ops/opnames/:id/review — KEPALA_GUDANG meng-crosscek hasil opname
   * pramuniaga. Body: { decision: 'APPROVED'|'REJECTED', note? }.
   */
  router.post('/opnames/:id/review', auth, requireOpsRole(pool, 'KEPALA_GUDANG'), async (req, res) => {
    try {
      const b = req.body ?? {};
      const decision = String(b.decision || '').toUpperCase() === 'REJECTED' ? 'REJECTED' : 'APPROVED';
      const me = (req as any).user.employeeId;
      const emp = (await pool.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const row = (await pool.query(
        `UPDATE ops_stock_opnames SET status=$3, reviewed_by=$4, reviewed_at=now(), review_note=$5
          WHERE id=$1 AND company_id=$2 RETURNING id, status`,
        [req.params.id, (req as any).user.companyId, decision, emp?.full_name || 'Kepala Gudang', str(b.note) || null]
      )).rows[0];
      if (!row) return res.status(404).json({ message: 'Sesi opname tidak ditemukan' });
      res.json({ ok: true, status: row.status, message: decision === 'APPROVED' ? 'Opname disetujui' : 'Opname ditolak' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /**
   * DELETE /api/ops/opnames/:id — hapus sesi opname + ROLLBACK mutasi stok.
   * Rumus rollback: stok -= qty_in - qty_out - qty_reject (kebalikan saat menyimpan).
   * Boleh oleh pemilik sesi atau KEPALA_GUDANG.
   */
  router.delete('/opnames/:id', auth, requireOpsRole(pool, ...OPS_ROLES), async (req, res) => {
    const client = await pool.connect();
    try {
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const roles = (req as any).employeeRoles || [];
      const head = (await client.query(
        `SELECT id, employee_id FROM ops_stock_opnames WHERE id=$1 AND company_id=$2`, [req.params.id, companyId]
      )).rows[0];
      if (!head) return res.status(404).json({ message: 'Sesi opname tidak ditemukan' });
      const isOwner = head.employee_id === me;
      if (!isOwner && !roles.includes('KEPALA_GUDANG')) {
        return res.status(403).json({ message: 'Hanya pemilik sesi atau Kepala Gudang yang dapat menghapus.' });
      }
      await client.query('BEGIN');
      const items = (await client.query(
        `SELECT product_id, qty_in, qty_out, qty_reject FROM ops_stock_opname_items WHERE opname_id=$1`, [req.params.id]
      )).rows;
      let rolled = 0;
      for (const it of items) {
        const qin = int(it.qty_in), qout = int(it.qty_out), qrej = int(it.qty_reject);
        if (it.product_id && (qin || qout || qrej)) {
          await client.query(
            `UPDATE ops_products SET stock = stock - $3 + $4 + $5, updated_at=now() WHERE id=$1 AND company_id=$2`,
            [it.product_id, companyId, qin, qout, qrej]
          );
          rolled += 1;
        }
      }
      await client.query(`DELETE FROM ops_stock_opnames WHERE id=$1 AND company_id=$2`, [req.params.id, companyId]);
      await client.query('COMMIT');
      res.json({ ok: true, message: 'Sesi opname dihapus & mutasi stok dikembalikan.', rolledBackItems: rolled });
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* ignore */ }
      console.error(e); res.status(500).json({ message: 'Server error' });
    } finally { client.release(); }
  });

  return router;
}

// ------------------------------------------------------------------
//  ADMIN — daftar & detail opname (dipakai panel superadmin).
//  Ditambahkan sebagai fungsi terpisah agar tidak mengganggu routing.
// ------------------------------------------------------------------
export function attachAdminOpnameRoutes(router: express.Router, deps: { pool: Pool; adminAuth: express.RequestHandler }) {
  const { pool, adminAuth } = deps;
  router.get('/admin/opnames', adminAuth, async (req, res) => {
    try {
      const rows = (await pool.query(
        `SELECT o.*, e.full_name AS emp_name FROM ops_stock_opnames o
           LEFT JOIN employees e ON e.id = o.employee_id
          WHERE o.company_id=$1 ORDER BY o.created_at DESC LIMIT 200`, [(req as any).admin.companyId]
      )).rows;
      const items = rows.map(mapOpname);
      res.json({ items, opnames: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });
  router.get('/admin/opnames/:id', adminAuth, async (req, res) => {
    try {
      const head = (await pool.query(
        `SELECT o.*, e.full_name AS emp_name FROM ops_stock_opnames o
           LEFT JOIN employees e ON e.id = o.employee_id
          WHERE o.id=$1 AND o.company_id=$2`, [req.params.id, (req as any).admin.companyId]
      )).rows[0];
      if (!head) return res.status(404).json({ message: 'Sesi opname tidak ditemukan' });
      const items = (await pool.query(
        `SELECT id, product_id, product_name, sku, system_stock, counted_stock, diff, note, qty_in, qty_out, qty_reject
           FROM ops_stock_opname_items WHERE opname_id=$1 ORDER BY product_name`, [req.params.id]
      )).rows.map((r: any) => ({
        id: r.id, productId: r.product_id, productName: r.product_name, sku: r.sku,
        systemStock: int(r.system_stock), countedStock: int(r.counted_stock), diff: int(r.diff), note: r.note,
        qtyIn: int(r.qty_in), qtyOut: int(r.qty_out), qtyReject: int(r.qty_reject),
      }));
      res.json({ opname: mapOpname(head), items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });
}

function mapVariant(r: any) {
  return {
    id: r.id, productId: r.product_id, name: r.name,
    price: num(r.price), stock: int(r.stock), sku: r.sku, active: r.active !== false,
  };
}

function mapProduct(r: any) {
  return {
    id: r.id, sku: r.sku, barcode: r.barcode, name: r.name, category: r.category, unit: r.unit,
    price: num(r.price), cost: num(r.cost), stock: int(r.stock), minStock: int(r.min_stock),
    active: r.active !== false, low: int(r.stock) <= int(r.min_stock),
    image: r.image || null,
  };
}

function mapOpname(r: any) {
  return {
    id: r.id, employeeId: r.employee_id, employeeName: r.emp_name || r.employee_name,
    kind: r.kind, area: r.area, note: r.note,
    totalItems: int(r.total_items), totalDiff: int(r.total_diff), status: r.status,
    reviewedBy: r.reviewed_by, reviewedAt: r.reviewed_at, reviewNote: r.review_note,
    createdAt: r.created_at,
  };
}
