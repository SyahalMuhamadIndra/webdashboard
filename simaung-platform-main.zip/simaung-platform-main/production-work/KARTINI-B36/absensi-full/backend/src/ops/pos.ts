import { createPackageScan } from './package-scan.js';
import { completeRestaurantCheckout, mountRestaurantPos, restaurantCheckout } from './restaurant.js';
import { receiveReceivablePayment, PaymentError } from './receivable-payments.js';
import {reserveCheckoutStock,CheckoutError} from './checkout-stock.js';
import {claimOperation,OperationError} from './operation-receipts.js';
// =====================================================================
//  MODUL OPERASIONAL (B11) — Kasir / POS.
//  Sesi kasir (buka/tutup + selisih kas), transaksi penjualan
//  (keranjang, diskon, pembayaran, kembalian), potong stok, ringkasan.
// =====================================================================
import express from 'express';
import { consumeMaterialsForSale } from './recipes.js';
import type { Pool } from 'pg';
import { int, num, str, requireOpsRole, requireOpsRoleOrAdmin, dualAuth, isoDateTz, docCode, wibDate, normalizePosMethod } from './common.js';
import { shiftTotals, expectedCashOf } from './shift.js';

const POS_ROLES = ['KASIR'];

export function createOpsPosRouter(deps: { pool: Pool; auth: express.RequestHandler; adminAuth: express.RequestHandler; rawPool?: Pool }) {
  const { pool, auth, adminAuth } = deps;
  const router = express.Router();
  if (deps.rawPool) router.post('/pos/package-scan', requireOpsRoleOrAdmin(auth, adminAuth, pool, ...POS_ROLES), createPackageScan(deps.rawPool));
  if(deps.rawPool)mountRestaurantPos(router,deps.rawPool,auth,requireOpsRole(pool,...POS_ROLES));

  async function cashierOpenSession(companyId: string, cashierId: string) {
    return (await pool.query(
      `SELECT * FROM ops_pos_sessions WHERE company_id=$1 AND cashier_id=$2 AND status='OPEN' ORDER BY opened_at DESC LIMIT 1`,
      [companyId, cashierId]
    )).rows[0];
  }

  async function salesTotalFor(sessionId: string) {
    const r = (await pool.query(
      `SELECT COALESCE(SUM(total),0) AS total, COUNT(*)::int AS n FROM ops_pos_sales WHERE session_id=$1 AND status='PAID'`, [sessionId]
    )).rows[0];
    return { total: num(r?.total), count: int(r?.n) };
  }

  /** GET /api/ops/pos/session — sesi kasir yang sedang terbuka (milik sendiri). */
  router.get('/pos/session', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const s = await cashierOpenSession((req as any).user.companyId, (req as any).user.employeeId);
      if (!s) return res.json({ session: null });
      const sum = await salesTotalFor(s.id);
      res.json({ session: { ...mapSession(s), salesTotal: sum.total, salesCount: sum.count } });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/pos/session/open — buka sesi. Body: { openingCash }. */
  router.post('/pos/session/open', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    const client=await pool.connect();
    try {
      await client.query('BEGIN');
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['kartini.shift.open:'+companyId+':'+String((req as any).opsBranchId||'legacy')]);
      const existing=(await client.query("SELECT id FROM ops_pos_sessions WHERE company_id=$1 AND cashier_id=$2 AND status IN ('OPEN','PENDING_APPROVAL') LIMIT 1",[companyId,me])).rows[0];
      if (existing) return res.status(409).json({ message: 'Masih ada sesi kasir yang terbuka' });
      const emp = (await client.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const seqRow = (await client.query(
        `SELECT COUNT(*)::int AS n FROM ops_pos_sessions WHERE company_id=$1 AND ${wibDate('opened_at')}=$2::date`,
        [companyId, isoDateTz()]
      )).rows[0];
      const seq = int(seqRow?.n) + 1;
      const hWib = new Date(Date.now() + 7 * 3600 * 1000).getUTCHours();
      const shiftLabel = hWib >= 6 && hWib < 14 ? 'Pagi' : (hWib >= 14 && hWib < 21 ? 'Siang' : 'Malam');
      const row = (await client.query(
        `INSERT INTO ops_pos_sessions (company_id, cashier_id, cashier_name, opening_cash, status, code, shift_no, shift_label, terminal)
         VALUES ($1,$2,$3,$4,'OPEN',$5,$6,$7,$8) RETURNING id, code, shift_no, shift_label`,
        [companyId, me, emp?.full_name || 'Kasir', num(b.openingCash),
         docCode('SHF', seq, isoDateTz()), seq, shiftLabel, str(b.terminal) || 'Kasir 1']
      )).rows[0];
      await client.query('COMMIT');
      res.json({
        id: row.id, code: row.code, shiftNo: int(row.shift_no), shiftLabel: row.shift_label,
        openingCash: num(b.openingCash),
        message: 'Shift kasir dibuka — ' + String(row.shift_label || shiftLabel) + ' (' + String(row.code || '') + ')',
      });
    } catch (e) { await client.query('ROLLBACK').catch(()=>{}); console.error(e); res.status(500).json({ message: 'Server error' }); } finally {await client.query('ROLLBACK').catch(()=>{});client.release();}
  });

  /** POST /api/ops/pos/session/close — tutup sesi. Body: { closingCash, note }. */
  router.post('/pos/session/close', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const s = (await client.query("SELECT * FROM ops_pos_sessions WHERE company_id=$1 AND cashier_id=$2 AND status='OPEN' ORDER BY opened_at DESC LIMIT 1 FOR UPDATE",[companyId,me])).rows[0];
      if (!s) return res.status(404).json({ message: 'Tidak ada sesi kasir yang terbuka' });
      const totals = await shiftTotals(client, s.id);
      const expected = expectedCashOf(s, totals);
      const denoms = b.denominations && typeof b.denominations === 'object' ? b.denominations : null;
      let countedFromDenoms = 0;
      if (denoms) for (const k of Object.keys(denoms)) countedFromDenoms += num(k) * num((denoms as any)[k]);
      const closing = denoms ? countedFromDenoms : num(b.closingCash);
      const diff = closing - expected;
      const empName = (await client.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0]?.full_name || 'Kasir';
      const snapshot = {
        generatedAt: new Date().toISOString(), shiftCode: s.code, cashierName: s.cashier_name,
        openedAt: s.opened_at, closedAt: new Date().toISOString(), openingFloat: num(s.opening_cash),
        expectedCash: expected, countedCash: closing, cashDiff: diff, ...totals,
      };
      await client.query(
        `UPDATE ops_pos_sessions SET status='CLOSED', closing_cash=$2, expected_cash=$3, cash_diff=$4, closed_at=now(),
            note=$5, counted_breakdown=$6, variance_note=$7, close_snapshot=$8, closed_by=$9
          WHERE id=$1`,
        [s.id, closing, expected, diff, str(b.note) || null,
         denoms ? JSON.stringify(denoms) : null, str(b.varianceNote) || null,
         JSON.stringify(snapshot), empName]
      );
      await client.query('COMMIT');
      res.json({
        ok: true, expected, closing, cashDiff: diff, salesTotal: totals.total, salesCount: totals.count,
        totals, zReport: snapshot, message: 'Shift kasir ditutup (Z-Report tersimpan)',
      });
    } catch (e) { await client.query('ROLLBACK').catch(()=>{}); console.error(e); res.status(500).json({ message: 'Server error' }); } finally { await client.query('ROLLBACK').catch(()=>{}); client.release(); }
  });

  /** GET /api/ops/pos/sales — daftar transaksi (query: sessionId, date, mine). */
  router.get('/pos/sales', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const mine = str(req.query.mine ?? '1') !== '0';
      const date = str(req.query.date) || isoDateTz();
      const sessionId = str(req.query.sessionId);
      const values: any[] = [companyId];
      const where: string[] = ['company_id=$1'];
      if (mine) { values.push(me); where.push(`cashier_id=$${values.length}`); }
      values.push(sessionId || date);
      where.push(sessionId ? `session_id=$${values.length}::uuid` : `${wibDate('created_at')}=$${values.length}::date`);
      const rows = (await pool.query(
        `SELECT * FROM ops_pos_sales
          WHERE ${where.join(' AND ')}
          ORDER BY created_at DESC LIMIT 200`,
        values
      )).rows;
      const items = rows.map(mapSale);
      res.json({ items, sales: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/pos/sales — proses transaksi.
   *  Body: { items:[{productId, variantId, productName, sku, price, qty}], discount,
   *          memberDiscount, tax, customerId, note, paymentMethod, cashReceived,
   *          splitPayments:[{method, amount}] }.
   *  Mendukung: pajak, diskon member, pelanggan, catatan, dan split payment. */
  router.post('/pos/sales', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    const client = await pool.connect();
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const emp = (await client.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const input = Array.isArray(b.items) ? b.items : [];
      if (!input.length) return res.status(400).json({ message: 'Keranjang kosong' });
      await client.query('BEGIN');
      const operation=await claimOperation(client,companyId,me,b.operationId,'pos.sale',{...b,branchId:(req as any).opsBranchId||null});
      if(operation.replayed){await client.query('COMMIT');return res.json(operation.result);}
      const restaurant=b.restaurantTicketId?await restaurantCheckout(client,companyId,(req as any).opsBranchId,b.restaurantTicketId,input,b.restaurantSplit===true):null;
      const session = (await client.query(`SELECT * FROM ops_pos_sessions WHERE company_id=$1 AND cashier_id=$2 AND status='OPEN' ORDER BY opened_at DESC LIMIT 1 FOR UPDATE`,[companyId,me])).rows[0];
      if (!session) throw new CheckoutError('Buka shift kasir sebelum melakukan penjualan.');

      // B22 — HPP OTOMATIS DARI RESEP: bila produk punya resep, modal baris diambil dari
      // harga bahan x jumlah pakai per porsi (bukan harga beli produk), sehingga laba laporan akurat.
      const hppMap: Record<string, number> = {};
      try {
        const hppRows = (await client.query(
          `SELECT r.product_id AS pid, SUM(r.qty * m.cost) AS hpp
             FROM ops_recipes r JOIN ops_materials m ON m.id = r.material_id
            WHERE r.company_id=$1 AND COALESCE(m.active, true) = true
            GROUP BY r.product_id`, [companyId]
        )).rows;
        hppRows.forEach((r: any) => { hppMap[String(r.pid)] = num(r.hpp); });
      } catch (e) { throw e; }

      // Nilai baris berdasarkan harga master (otoritatif) + validasi stok.
      const lines: any[] = [];
      let subtotal = 0;
      for (const it of input) {
        const pid = str(it.productId) || null;
        let name = str(it.productName);
        let sku = str(it.sku) || null;
        let price = num(it.price);
        let cost = num(it.cost);
        let costSource = 'PRODUK';
        const variantId = str(it.variantId) || null;
        if (pid) {
          const p = (await client.query(`SELECT name, sku, price, stock, cost FROM ops_products WHERE id=$1 AND company_id=$2 AND active=true`, [pid, companyId])).rows[0];
          if (!p) throw new CheckoutError('Produk tidak ditemukan atau tidak aktif.');
          if (p) { name = p.name; sku = p.sku; cost = num(p.cost); }
          if (pid && num(hppMap[String(pid)]) > 0) { cost = num(hppMap[String(pid)]); costSource = 'RESEP'; }
          if (variantId) {
            const v = (await client.query(`SELECT name, price, stock FROM ops_product_variants WHERE id=$1 AND product_id=$2 AND active=true`, [variantId, pid])).rows[0];
            if (!v) throw new CheckoutError('Varian tidak ditemukan atau tidak aktif.');
            if (v) { name = `${name} (${v.name})`; price = num(v.price); sku = sku; }
          } else if (p) { price = num(p.price); }
        }
        if (!pid) throw new CheckoutError('Pilih produk dari katalog.');
        const qty = Number(it.qty);
        if (!Number.isSafeInteger(qty) || qty <= 0) throw new CheckoutError('Jumlah produk harus bilangan bulat positif.');
        const gross = price * qty;
        // B20: diskon per item (ala Olsera) — dipotong dari nilai baris, bukan dari harga satuan.
        const lineDiscount = Math.min(gross, Math.max(0, num(it.discount)));
        const total = gross - lineDiscount;
        subtotal += gross;
        lines.push({ pid, variantId, name, sku, price, cost, qty, total, lineDiscount, costSource });
      }
      // HPP dibekukan per transaksi (dasar perhitungan laba kotor pada laporan penghasilan).
      const cogs = lines.reduce((a: number, l: any) => a + num(l.cost) * num(l.qty), 0);
      const lineDiscount = lines.reduce((a: number, l: any) => a + num(l.lineDiscount), 0);
      const discount = Math.max(0, num(b.discount)) + lineDiscount;
      const memberDiscount = Math.max(0, num(b.memberDiscount));
      const tax = Math.max(0, num(b.tax));
      // B20: pembulatan total (mis. ke bawah 100/500/1000), dibatasi agar aman.
      const rounding = Math.max(-2000, Math.min(2000, num(b.rounding)));
      const total = Math.max(0, subtotal - discount - memberDiscount + tax + rounding);

      // Split payment: gabungkan metode & nilai.
      const rawSplit = Array.isArray(b.splitPayments) ? b.splitPayments : [];
      // B20: rincian bank / e-wallet / kartu + no. referensi ikut tersimpan per metode.
      const split = rawSplit
        .map((s: any) => ({
          method: normalizePosMethod(s.method || 'CASH'), amount: Math.max(0, num(s.amount)),
          reference: str(s.reference) || null, bank: str(s.bank) || null, wallet: str(s.wallet) || null,
          cardType: str(s.cardType) || null, cardLast4: str(s.cardLast4) || null, approval: str(s.approval) || null,
        }))
        .filter((s: any) => s.amount > 0);
      const isSplit = split.length > 1 || (split.length === 1 && str(b.paymentMethod).toUpperCase() === 'SPLIT');

      let method: string;
      let paid: number;
      let change = 0;
      let cashReceived = 0;
      if (isSplit) {
        const paidSum = split.reduce((a: number, s: any) => a + s.amount, 0);
        if (paidSum + 0.001 < total) return res.status(400).json({ message: 'Total pembayaran split kurang dari total' });
        method = 'SPLIT';
        paid = total;
        cashReceived = split.filter((s: any) => s.method === 'CASH').reduce((a: number, s: any) => a + s.amount, 0);
      } else {
        method = normalizePosMethod(b.paymentMethod || 'CASH');
        if (method === 'CASH') {
          cashReceived = num(b.cashReceived) || num(b.paid);
          if (cashReceived + 0.001 < total) return res.status(400).json({ message: 'Pembayaran kurang dari total' });
          change = cashReceived - total;
          paid = cashReceived;
        } else { paid = total; }
      }

      // B30 — TEMPO / HUTANG: pembayaran ditangguhkan. Nota langsung lunas tercatat,
      // tetapi nominal ditagihkan sebagai PIUTANG pelanggan (opsional dengan uang muka).
      const isTempo = (str(b.paymentMethod).toUpperCase() === 'TEMPO') || b.tempo === true;
      let tempoMeta: { receivableId: string | null; recvCode: string | null; dueDate: string | null; paidNow: number; outstanding: number; customerName: string | null } = {
        receivableId: null, recvCode: null, dueDate: null, paidNow: 0, outstanding: 0, customerName: null,
      };

      // Pelanggan (opsional).
      let customerId = str(b.customerId) || null;
      let customerName = null;
      if (customerId) {
        const c = (await client.query(`SELECT name FROM ops_customers WHERE id=$1 AND company_id=$2`, [customerId, companyId])).rows[0];
        if (c) customerName = c.name; else customerId = null;
      }

      // Rincian metode bayar (dasar laporan penghasilan per metode).
      const methodMap: Record<string, number> = {};
      if (isTempo) {
        // Tempo: uang muka (mis. tunai) masuk laci; sisanya menjadi piutang (TEMPO).
        const dp = Math.max(0, Math.min(total, num(b.downPayment)));
        const out = Math.max(0, total - dp);
        if (dp > 0) methodMap['CASH'] = dp;
        if (out > 0) methodMap['TEMPO'] = out;
        if (!Object.keys(methodMap).length) methodMap['TEMPO'] = total;
        cashReceived = dp;
        paid = dp;
        change = 0;
      } else if (isSplit) {
        for (const sp of split) methodMap[sp.method] = num(methodMap[sp.method]) + num(sp.amount);
      } else {
        methodMap[method] = total;
      }

      // B30 — buat nomor piutang sebelum transaksi (dipakai di dalam & luar blok transaksi).
      const recvCode = isTempo ? docCode('RCV', undefined) : null;
      const dueDate = isTempo ? (str(b.dueDate) || null) : null;

      // B20: rincian pembayaran untuk struk & laporan (bank/e-wallet/kartu/referensi/pembulatan).
      const rawDetail = (b.paymentDetail && typeof b.paymentDetail === 'object') ? b.paymentDetail : {};
      const paymentDetail: Record<string, any> = Object.assign({}, rawDetail, { rounding });
      delete paymentDetail.split;
      if (isSplit) paymentDetail.split = split;

      const code = docCode('INV', undefined);
      const saleStatus = isTempo ? 'TEMPO' : 'PAID';
      const downPayment = isTempo ? Math.max(0, Math.min(total, num(b.downPayment))) : 0;
      const sale = (await client.query(
        `INSERT INTO ops_pos_sales
           (company_id, session_id, cashier_id, cashier_name, code, subtotal, discount, tax, member_discount,
            customer_id, customer_name, note, cash_received, split_payments, total, paid, change, payment_method,
            cogs, payment_methods, status, due_date, down_payment)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23) RETURNING id, created_at`,
        [companyId, session?.id || null, me, emp?.full_name || 'Kasir', code, subtotal, discount, tax, memberDiscount,
         customerId, customerName, str(b.note) || null, cashReceived,
         isSplit ? JSON.stringify(split) : null, total, paid, change, method, cogs, JSON.stringify(methodMap),
         saleStatus, isTempo ? (dueDate || null) : null, downPayment]
      )).rows[0];
      // B30 — catat piutang tempo bila ada sisa tagihan.
      if (isTempo && total - downPayment > 0.001) {
        const recvName = customerName || str(b.customerName) || 'Pelanggan Tempo';
        const outstanding = total - downPayment;
        const rStatus = downPayment > 0.001 ? 'PARTIAL' : 'UNPAID';
        const recv = (await client.query(
          `INSERT INTO ops_receivables
             (company_id, sale_id, code, customer_id, customer_name, customer_phone, total, paid_amount, due_date, status, note, created_by)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
          [companyId, sale.id, recvCode, customerId, recvName, str(b.customerPhone) || null,
           total, downPayment, dueDate || null, rStatus, str(b.note) || null, emp?.full_name || 'Kasir']
        )).rows[0];
        tempoMeta = { receivableId: recv.id, recvCode, dueDate: dueDate || null, paidNow: downPayment, outstanding, customerName: recvName };
        Object.assign(paymentDetail, { tempo: true, receivableId: recv.id, receivableCode: recvCode, downPayment, outstanding, dueDate: dueDate || null });
      } else if (isTempo) {
        tempoMeta = { receivableId: null, recvCode, dueDate: dueDate || null, paidNow: downPayment, outstanding: 0, customerName: customerName || null };
      }
      await reserveCheckoutStock(client,companyId,lines);
      for (const l of lines) {
        await client.query(
          `INSERT INTO ops_pos_sale_items (sale_id, product_id, product_name, sku, price, cost, qty, total)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`, [sale.id, l.pid, l.name, l.sku, l.price, num(l.cost), l.qty, l.total]
        );
      }
      // B21 — RESEP/BAHAN BAKU: stok bahan berkurang otomatis sesuai resep produk yang terjual.
      // Dijalankan di dalam transaksi yang sama agar penjualan & pemakaian bahan tidak terpisah.
      let matResult: { usage: any[]; warnings: any[]; perProduct: Array<{ productId: string; used: any[] }> } = { usage: [], warnings: [], perProduct: [] };
      try {
        matResult = await consumeMaterialsForSale(client, {
          companyId, saleId: sale.id, code, actorName: emp?.full_name || 'Kasir',
          lines: lines.map((l: any) => ({ pid: l.pid, name: l.name, qty: num(l.qty) })),
        });
      } catch (e) { throw e; }
      await client.query(`UPDATE ops_pos_sales SET payment_detail=$2 WHERE id=$1`, [sale.id, JSON.stringify(paymentDetail)]);
      for (const pp of matResult.perProduct) {
        await client.query(`UPDATE ops_pos_sale_items SET recipe_usage=$2 WHERE sale_id=$1 AND product_id=$3`, [sale.id, JSON.stringify(pp.used), pp.productId]);
      }
      const response={
        id: sale.id, code, subtotal, discount, memberDiscount, tax, total, paid, change,
        paymentMethod: method, customerName, message: 'Transaksi berhasil',
        cogs, hppFromRecipe: lines.some((l: any) => l.costSource === 'RESEP'),
        materialUsage: matResult.usage, materialWarnings: matResult.warnings,
        tempo: isTempo ? { receivableId: tempoMeta.receivableId, receivableCode: tempoMeta.recvCode, dueDate: tempoMeta.dueDate, downPayment: downPayment, outstanding: tempoMeta.outstanding, customerName: tempoMeta.customerName } : null,
      };
      if(restaurant)await completeRestaurantCheckout(client,restaurant,sale.id);
      await operation.complete(response);
      await client.query('COMMIT');
      res.json(response);
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* sudah COMMIT: abaikan */ }
      console.error(e); res.status(e instanceof CheckoutError || e instanceof OperationError ? e.status : 500).json({ message: e instanceof CheckoutError || e instanceof OperationError ? e.message : 'Server error' });
    } finally { await client.query('ROLLBACK').catch(()=>{}); client.release(); }
  });

  /** POST /api/ops/pos/sales/:id/void — batalkan/refund nota dari kasir.
   *  Mengembalikan stok produk DAN stok bahan baku sesuai resep, mencatat alasan & pelakunya. */
  router.post('/pos/sales/:id/void', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    const client = await pool.connect();
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const emp = (await client.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const actor = emp?.full_name || 'Kasir';
      const reason = str(b.reason).trim();
      if (!reason) return res.status(400).json({ message: 'Alasan pembatalan wajib diisi' });
      const sale = (await client.query(
        `SELECT * FROM ops_pos_sales WHERE id=$1 AND company_id=$2`, [req.params.id, companyId]
      )).rows[0];
      if (!sale) return res.status(404).json({ message: 'Transaksi tidak ditemukan' });
      if (sale.status !== 'PAID') return res.status(400).json({ message: 'Nota ini sudah dibatalkan/di-refund sebelumnya' });
      // Pengaman: dari kasir hanya nota pada shift yang masih terbuka (hari berjalan).
      if (sale.session_id) {
        const ses = (await client.query(`SELECT status FROM ops_pos_sessions WHERE id=$1`, [sale.session_id])).rows[0];
        if (!ses || ses.status !== 'OPEN') {
          return res.status(400).json({ message: 'Shift nota ini sudah ditutup — pembatalan hanya bisa lewat backoffice' });
        }
      }
      const items = (await client.query(
        `SELECT id, product_id, qty FROM ops_pos_sale_items WHERE sale_id=$1`, [sale.id]
      )).rows;
      const newStatus = b.refund === true ? 'REFUNDED' : 'VOID';
      const restored: any[] = [];
      await client.query('BEGIN');
      for (const it of items) {
        if (it.product_id) {
          await client.query(
            `UPDATE ops_products SET stock = stock + $2, updated_at=now() WHERE id=$1`, [it.product_id, int(it.qty)]
          );
          // Bahan baku dikembalikan sesuai resep produk yang dibatalkan (savepoint agar aman).
          await client.query('SAVEPOINT voidmat');
          try {
            const rr = (await client.query(
              `SELECT r.material_id, r.qty AS per_unit, m.name, m.unit
                 FROM ops_recipes r JOIN ops_materials m ON m.id = r.material_id
                WHERE r.company_id=$1 AND r.product_id=$2`, [companyId, it.product_id]
            )).rows;
            for (const r of rr) {
              const back = num(r.per_unit) * int(it.qty);
              if (back <= 0) continue;
              const upd = (await client.query(
                `UPDATE ops_materials SET stock = stock + $2, updated_at=now() WHERE id=$1 RETURNING stock`, [r.material_id, back]
              )).rows[0];
              await client.query(
                `INSERT INTO ops_material_moves (company_id, material_id, kind, qty, ref_type, ref_id, ref_code, note, actor_name)
                 VALUES ($1,$2,'RETURN',$3,'SALE_VOID',$4,$5,$6,$7)`,
                [companyId, r.material_id, back, sale.id, sale.code || '', 'pembatalan nota: ' + reason.slice(0, 120), actor]
              );
              restored.push({ materialId: r.material_id, name: r.name, unit: r.unit, qty: back, stock: num(upd?.stock) });
            }
            await client.query('RELEASE SAVEPOINT voidmat');
          } catch (e) {
            await client.query('ROLLBACK TO SAVEPOINT voidmat');
            console.error('void bahan:', e);
          }
        }
      }
      await client.query(
        `UPDATE ops_pos_sales SET status=$2, voided_at=now(), void_reason=$3, void_by=$4 WHERE id=$1`,
        [sale.id, newStatus, reason, actor]
      );
      await client.query('COMMIT');
      // Jejak pembatalan pada rincian pembayaran (kolom opsional, tulis setelah commit).
      try {
        const pd = Object.assign({}, sale.payment_detail || {}, {
          void: { status: newStatus, reason, by: actor, at: new Date().toISOString() },
        });
        await client.query(`UPDATE ops_pos_sales SET payment_detail=$2 WHERE id=$1`, [sale.id, JSON.stringify(pd)]);
      } catch (e) { /* diabaikan */ }
      res.json({
        ok: true, status: newStatus, code: sale.code, total: num(sale.total), materials: restored,
        message: newStatus === 'REFUNDED'
          ? 'Nota di-refund — stok produk & bahan dikembalikan'
          : 'Nota dibatalkan — stok produk & bahan dikembalikan',
      });
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* sudah COMMIT: abaikan */ }
      console.error(e); res.status(500).json({ message: 'Server error' });
    } finally { client.release(); }
  });

  /** GET /api/ops/pos/sales/:id — detail transaksi + item. */
  router.get(['/pos/sales/:id', '/admin/pos/sales/:id'], dualAuth(auth, adminAuth), async (req, res) => {
    try {
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const head = (await pool.query(`SELECT * FROM ops_pos_sales WHERE id=$1 AND company_id=$2`, [req.params.id, companyId])).rows[0];
      if (!head) return res.status(404).json({ message: 'Transaksi tidak ditemukan' });
      const items = (await pool.query(
        `SELECT id, product_id, product_name, sku, price, qty, total FROM ops_pos_sale_items WHERE sale_id=$1 ORDER BY product_name`, [req.params.id]
      )).rows.map((r: any) => ({ id: r.id, productId: r.product_id, productName: r.product_name, sku: r.sku, price: num(r.price), qty: int(r.qty), total: num(r.total) }));
      res.json({ sale: mapSale(head), items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/ops/pos/summary — ringkasan kasir hari ini. */
  router.get('/pos/summary', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const date = str(req.query.date) || isoDateTz();
      const r = (await pool.query(
        `SELECT COUNT(*)::int AS n, COALESCE(SUM(total),0) AS total, COALESCE(SUM(discount),0) AS disc,
                COALESCE(SUM(discount + member_discount),0) AS all_disc,
                COALESCE(SUM(cogs),0) AS cogs,
                COALESCE(SUM(CASE WHEN payment_method='CASH' THEN total ELSE 0 END),0) AS cash,
                COALESCE(SUM(CASE WHEN payment_method='CASH' THEN 0 ELSE total END),0) AS noncash
           FROM ops_pos_sales WHERE company_id=$1 AND cashier_id=$2 AND status='PAID' AND ${wibDate('created_at')}=$3::date`,
        [companyId, me, date]
      )).rows[0];
      const grossNet = num(r?.total) - num(r?.all_disc);
      res.json({
        date, count: int(r?.n), total: num(r?.total), discount: num(r?.all_disc),
        cash: num(r?.cash), nonCash: num(r?.noncash),
        cogs: num(r?.cogs), profit: grossNet - num(r?.cogs),
        avgBasket: int(r?.n) ? num(r?.total) / int(r?.n) : 0,
      });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ------------------------------------------------------------------
  //  ADMIN — pantau POS
  // ------------------------------------------------------------------
  router.get('/admin/pos/sales', adminAuth, async (req, res) => {
    try {
      const companyId = (req as any).admin.companyId;
      const date = str(req.query.date) || isoDateTz();
      const rows = (await pool.query(
        `SELECT * FROM ops_pos_sales WHERE company_id=$1 AND ${wibDate('created_at')}=$2::date ORDER BY created_at DESC LIMIT 500`,
        [companyId, date]
      )).rows;
      const items = rows.map(mapSale);
      const total = items.reduce((a, b) => a + b.total, 0);
      res.json({ items, sales: items, date, total });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  router.get('/admin/pos/sessions', adminAuth, async (req, res) => {
    try {
      const rows = (await pool.query(
        `SELECT * FROM ops_pos_sessions WHERE company_id=$1 ORDER BY opened_at DESC LIMIT 200`, [(req as any).admin.companyId]
      )).rows.map(mapSession);
      res.json({ items: rows, sessions: rows });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  router.get('/admin/pos/summary', adminAuth, async (req, res) => {
    try {
      const companyId = (req as any).admin.companyId;
      const date = str(req.query.date) || isoDateTz();
      const r = (await pool.query(
        `SELECT COUNT(*)::int AS n, COALESCE(SUM(total),0) AS total, COALESCE(SUM(cogs),0) AS cogs,
                COALESCE(SUM(discount + member_discount),0) AS disc,
                COALESCE(SUM(CASE WHEN payment_method='CASH' THEN total ELSE 0 END),0) AS cash,
                COALESCE(SUM(CASE WHEN payment_method='CASH' THEN 0 ELSE total END),0) AS noncash
           FROM ops_pos_sales WHERE company_id=$1 AND status='PAID' AND ${wibDate('created_at')}=$2::date`,
        [companyId, date]
      )).rows[0];
      const openSessions = (await pool.query(
        `SELECT COUNT(*)::int AS n FROM ops_pos_sessions WHERE company_id=$1 AND status IN ('OPEN','PENDING_APPROVAL')`, [companyId]
      )).rows[0];
      const net = num(r?.total) - num(r?.disc);
      res.json({
        date, count: int(r?.n), total: num(r?.total), cash: num(r?.cash), nonCash: num(r?.noncash),
        discount: num(r?.disc), cogs: num(r?.cogs), profit: net - num(r?.cogs),
        avgBasket: int(r?.n) ? num(r?.total) / int(r?.n) : 0,
        openSessions: int(openSessions?.n),
      });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ------------------------------------------------------------------
  //  PENGATURAN POS (pajak, split, stok rendah)
  // ------------------------------------------------------------------
  async function settingsOf(companyId: string) {
    await pool.query(`INSERT INTO ops_settings (company_id) VALUES ($1) ON CONFLICT (company_id) DO NOTHING`, [companyId]);
    return (await pool.query(`SELECT * FROM ops_settings WHERE company_id=$1`, [companyId])).rows[0];
  }

  /** GET /api/ops/pos/settings — dan alias admin /admin/pos/settings (token admin). */
  router.get(['/pos/settings', '/admin/pos/settings'], requireOpsRoleOrAdmin(auth, adminAuth, pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      res.json({ settings: mapSettings(await settingsOf(companyId)) });
    }
    catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** PUT /api/ops/pos/settings — ubah pengaturan (kasir/kepala). */
  router.put(['/pos/settings', '/admin/pos/settings'], adminAuth, async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).admin?.companyId || (req as any).user?.companyId;
      await settingsOf(companyId);
      const row = (await pool.query(
        `UPDATE ops_settings SET
           tax_rate=COALESCE($2,tax_rate), tax_enabled=COALESCE($3,tax_enabled),
           split_payment_enabled=COALESCE($4,split_payment_enabled),
           low_stock_threshold=COALESCE($5,low_stock_threshold),
           store_name=COALESCE($6,store_name),
           daily_target=COALESCE($7,daily_target),
           variance_tolerance=COALESCE($8,variance_tolerance),
           require_variance_approval=COALESCE($9,require_variance_approval),
           blind_close=COALESCE($10,blind_close),
           receipt_footer=COALESCE($11,receipt_footer),
           store_address=COALESCE($12,store_address),
           store_phone=COALESCE($13,store_phone),
           updated_at=now()
         WHERE company_id=$1 RETURNING *`,
        [companyId,
         b.taxRate != null ? num(b.taxRate) : null,
         typeof b.taxEnabled === 'boolean' ? b.taxEnabled : null,
         typeof b.splitPaymentEnabled === 'boolean' ? b.splitPaymentEnabled : null,
         b.lowStockThreshold != null ? int(b.lowStockThreshold) : null,
         b.storeName != null ? str(b.storeName) : null,
         b.dailyTarget != null ? Math.max(0, num(b.dailyTarget)) : null,
         b.varianceTolerance != null ? Math.max(0, num(b.varianceTolerance)) : null,
         typeof b.requireVarianceApproval === 'boolean' ? b.requireVarianceApproval : null,
         typeof b.blindClose === 'boolean' ? b.blindClose : null,
         b.receiptFooter != null ? str(b.receiptFooter) : null,
         b.storeAddress != null ? str(b.storeAddress) : null,
         b.storePhone != null ? str(b.storePhone) : null]
      )).rows[0];
      res.json({ settings: mapSettings(row), message: 'Pengaturan disimpan' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ------------------------------------------------------------------
  //  PELANGGAN / MEMBER
  // ------------------------------------------------------------------
  /** GET /api/ops/customers — daftar pelanggan. */
  router.get(['/customers', '/admin/customers'], dualAuth(auth, adminAuth), async (req, res) => {
    try {
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const q = str(req.query.q).trim();
      const rows = (await pool.query(
        `SELECT * FROM ops_customers WHERE company_id=$1 AND active=true ${q ? 'AND (name ILIKE $2 OR phone ILIKE $2)' : ''}
          ORDER BY name ASC LIMIT 300`,
        q ? [companyId, `%${q}%`] : [companyId]
      )).rows;
      const items = rows.map(mapCustomer);
      res.json({ items, customers: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/customers — tambah pelanggan. Body: { name, phone, tier, discountPercent }. */
  router.post(['/customers', '/admin/customers'], dualAuth(auth, adminAuth), async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const name = str(b.name).trim();
      if (!name) return res.status(400).json({ message: 'Nama pelanggan wajib diisi' });
      const row = (await pool.query(
        `INSERT INTO ops_customers (company_id, name, phone, tier, discount_percent)
         VALUES ($1,$2,$3,$4,$5) RETURNING *`,
        [companyId, name, str(b.phone) || null, str(b.tier) || 'regular', Math.max(0, num(b.discountPercent))]
      )).rows[0];
      res.json({ customer: mapCustomer(row), id: row.id, message: 'Pelanggan ditambahkan' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** PUT /api/ops/customers/:id — ubah pelanggan. */
  router.put(['/customers/:id', '/admin/customers/:id'], dualAuth(auth, adminAuth), async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const row = (await pool.query(
        `UPDATE ops_customers SET
           name=COALESCE($3,name), phone=COALESCE($4,phone), tier=COALESCE($5,tier),
           discount_percent=COALESCE($6,discount_percent), active=COALESCE($7,active)
         WHERE id=$1 AND company_id=$2 RETURNING *`,
        [req.params.id, companyId,
         b.name != null ? str(b.name) : null, b.phone != null ? str(b.phone) : null,
         b.tier != null ? str(b.tier) : null, b.discountPercent != null ? Math.max(0, num(b.discountPercent)) : null,
         typeof b.active === 'boolean' ? b.active : null]
      )).rows[0];
      if (!row) return res.status(404).json({ message: 'Pelanggan tidak ditemukan' });
      res.json({ customer: mapCustomer(row), message: 'Pelanggan diperbarui' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** DELETE /api/ops/customers/:id — nonaktifkan pelanggan. */
  router.delete(['/customers/:id', '/admin/customers/:id'], dualAuth(auth, adminAuth), async (req, res) => {
    try {
      const companyId = (req as any).user?.companyId || (req as any).admin?.companyId;
      const row = (await pool.query(
        `UPDATE ops_customers SET active=false WHERE id=$1 AND company_id=$2 RETURNING id`,
        [req.params.id, companyId]
      )).rows[0];
      if (!row) return res.status(404).json({ message: 'Pelanggan tidak ditemukan' });
      res.json({ message: 'Pelanggan dinonaktifkan' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ------------------------------------------------------------------
  //  TAHAN PESANAN (HOLD / PARK ORDER)
  // ------------------------------------------------------------------
  /** GET /api/ops/pos/holds — daftar pesanan yang ditahan. */
  router.get('/pos/holds', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const rows = (await pool.query(
        `SELECT * FROM ops_pos_holds WHERE company_id=$1 AND (cashier_id=$2 OR cashier_id IS NULL) ORDER BY created_at DESC LIMIT 50`,
        [companyId, me]
      )).rows;
      const items = rows.map(mapHold);
      res.json({ items, holds: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/pos/holds — tahan pesanan. Body: { label, payload }. */
  router.post('/pos/holds', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const emp = (await pool.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const row = (await pool.query(
        `INSERT INTO ops_pos_holds (company_id, cashier_id, cashier_name, label, payload)
         VALUES ($1,$2,$3,$4,$5) RETURNING id`,
        [companyId, me, emp?.full_name || 'Kasir', str(b.label) || 'Pesanan ditahan',
         JSON.stringify(b.payload ?? {})]
      )).rows[0];
      res.json({ id: row.id, message: 'Pesanan ditahan' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/pos/holds/join — gabungkan beberapa tahanan jadi 1 tagihan.
   *  Body: { ids: [...], keep?: boolean }. keep=true → hasil gabungan tetap ditahan;
   *  keep=false → tahanan sumber dihapus dan payload gabungan dikembalikan ke kasir. */
  router.post('/pos/holds/join', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    const client = await pool.connect();
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const ids = (Array.isArray(b.ids) ? b.ids : []).map((x: any) => str(x)).filter(Boolean);
      if (ids.length < 2) return res.status(400).json({ message: 'Pilih minimal 2 pesanan untuk digabung' });
      const rows = (await client.query(
        `SELECT * FROM ops_pos_holds WHERE company_id=$1 AND id = ANY($2::uuid[]) ORDER BY created_at ASC`,
        [companyId, ids]
      )).rows;
      if (rows.length < 2) return res.status(400).json({ message: 'Pesanan yang dipilih tidak ditemukan (minimal 2)' });
      const items: any[] = [];
      const labels: string[] = [];
      let disc = 0;
      let cust: any = null;
      const notes: string[] = [];
      for (const h of rows) {
        const pl = h.payload || {};
        labels.push(h.label || 'Tahanan');
        if (pl.note) notes.push(String(pl.note));
        (Array.isArray(pl.items) ? pl.items : []).forEach((l: any) => {
          const ex = items.find((c: any) => String(c.id) === String(l.id));
          if (ex) ex.qty = num(ex.qty) + num(l.qty);
          else items.push(Object.assign({}, l));
        });
        disc += num(pl.disc);
        if (!cust && pl.cust) cust = pl.cust;
      }
      const label = labels.join(' + ');
      const joinedNote = notes.join(' · ') || null;
      if (items.length > 1) items.sort((a: any, c: any) => String(a.name).localeCompare(String(c.name)));
      const payload = { items, disc, cust, note: joinedNote, joinedFrom: labels, joinedAt: new Date().toISOString() };
      const me = (req as any).user.employeeId;
      const emp = (await client.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      let newId: string | null = null;
      await client.query('BEGIN');
      if (b.keep === true) {
        newId = (await client.query(
          `INSERT INTO ops_pos_holds (company_id, cashier_id, cashier_name, label, payload)
           VALUES ($1,$2,$3,$4,$5) RETURNING id`,
          [companyId, me, emp?.full_name || 'Kasir', label, JSON.stringify(payload)]
        )).rows[0].id;
      }
      await client.query(`DELETE FROM ops_pos_holds WHERE company_id=$1 AND id = ANY($2::uuid[])`, [companyId, ids]);
      await client.query('COMMIT');
      res.json({
        id: newId, label, payload, joined: rows.length, keep: b.keep === true,
        itemCount: items.reduce((a: number, l: any) => a + num(l.qty), 0),
        total: items.reduce((a: number, l: any) => a + num(l.price) * num(l.qty), 0) - disc,
        message: b.keep === true ? 'Pesanan digabung & tetap ditahan' : 'Pesanan digabung ke keranjang',
      });
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* sudah COMMIT: abaikan */ }
      console.error(e); res.status(500).json({ message: 'Server error' });
    } finally { client.release(); }
  });

  /** DELETE /api/ops/pos/holds/:id — ambil/hapus pesanan yang ditahan. */
  router.delete('/pos/holds/:id', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const row = (await pool.query(
        `DELETE FROM ops_pos_holds WHERE id=$1 AND company_id=$2 RETURNING id`, [req.params.id, companyId]
      )).rows[0];
      if (!row) return res.status(404).json({ message: 'Pesanan tidak ditemukan' });
      res.json({ message: 'Pesanan diambil' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ===================== B30: TEMPO / HUTANG (PIUTANG) =====================

  /** GET /api/ops/pos/receivables — daftar piutang pelanggan (tempo).
   *  Query: ?q= (nama/telepon), ?status=UNPAID|PARTIAL|PAID, ?overdue=1, ?all=1 (termasuk lunas). */
  router.get('/pos/receivables', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const q = str((req.query as any).q).trim();
      const status = str((req.query as any).status).trim().toUpperCase();
      const overdue = str((req.query as any).overdue) === '1';
      const all = str((req.query as any).all) === '1';
      const params: any[] = [companyId];
      const where: string[] = ['company_id=$1'];
      if (q) { params.push('%' + q + '%'); where.push(`(customer_name ILIKE $${params.length} OR customer_phone ILIKE $${params.length})`); }
      if (status) { params.push(status); where.push(`status=$${params.length}`); }
      else if (!all) { where.push(`status IN ('UNPAID','PARTIAL')`); }
      if (overdue) { where.push(`due_date IS NOT NULL AND due_date < CURRENT_DATE AND status IN ('UNPAID','PARTIAL')`); }
      const rows = (await pool.query(
        `SELECT * FROM ops_receivables WHERE ${where.join(' AND ')} ORDER BY (due_date IS NULL), due_date ASC, created_at DESC LIMIT 300`,
        params
      )).rows;
      const items = rows.map(mapReceivable);
      const summary = {
        count: items.length,
        outstanding: items.reduce((a: number, r: any) => a + r.outstanding, 0),
        overdueCount: items.filter((r: any) => r.overdue).length,
      };
      res.json({ items, receivables: items, summary });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/ops/pos/receivables/summary — ringkasan total piutang belum lunas. */
  router.get('/pos/receivables/summary', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const r = (await pool.query(
        `SELECT COUNT(*)::int AS count,
                COALESCE(SUM(total - paid_amount),0) AS outstanding,
                COALESCE(SUM(CASE WHEN due_date IS NOT NULL AND due_date < CURRENT_DATE THEN total - paid_amount ELSE 0 END),0) AS overdue
           FROM ops_receivables WHERE company_id=$1 AND status IN ('UNPAID','PARTIAL')`, [companyId]
      )).rows[0];
      res.json({ count: int(r?.count), outstanding: num(r?.outstanding), overdueOutstanding: num(r?.overdue) });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/ops/pos/receivables/:id — rincian piutang + nota + riwayat cicilan. */
  router.get('/pos/receivables/:id', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const row = (await pool.query(`SELECT * FROM ops_receivables WHERE id=$1 AND company_id=$2`, [req.params.id, companyId])).rows[0];
      if (!row) return res.status(404).json({ message: 'Piutang tidak ditemukan' });
      const payments = (await pool.query(
        `SELECT id, amount, method, note, actor_name, created_at FROM ops_receivable_payments
          WHERE receivable_id=$1 AND company_id=$2 ORDER BY created_at ASC`, [req.params.id, companyId]
      )).rows.map((p: any) => ({ id: p.id, amount: num(p.amount), method: p.method, note: p.note, actorName: p.actor_name, at: p.created_at }));
      let sale = null;
      if (row.sale_id) {
        sale = (await pool.query(
          `SELECT id, code, subtotal, discount, tax, total, paid, change, payment_method, customer_name, created_at, status
             FROM ops_pos_sales WHERE id=$1 AND company_id=$2`, [row.sale_id, companyId]
        )).rows[0] || null;
      }
      res.json({ receivable: mapReceivable(row), payments, sale });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/pos/receivables/:id/pay — terima cicilan / pelunasan.
   *  Body: { amount, method, note }. Bila lunas → status PAID & nota PENJUALAN jadi PAID. */
  router.post('/pos/receivables/:id/pay', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const body = req.body ?? {};
      const id = String(req.params.id);
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) return res.status(400).json({ message: 'ID piutang tidak valid.' });
      const result = await receiveReceivablePayment(pool, {
        companyId: req.user.companyId, employeeId: req.user.employeeId, receivableId: id,
        amount: body.amount, method: normalizePosMethod(body.method || 'CASH'), note: str(body.note).slice(0,2000) || null,
      });
      res.json(result);
    } catch (error) {
      if (error instanceof PaymentError) return res.status(error.status).json({ message: error.message });
      console.error('Receivable payment failed');
      res.status(503).json({ message: 'Pembayaran belum dapat diproses. Periksa riwayat pembayaran sebelum mencoba kembali.' });
    }
  });

  /** POST /api/ops/pos/receivables — catat piutang tempo manual (tanpa nota baru). */
  router.post('/pos/receivables', auth, requireOpsRole(pool, ...POS_ROLES), async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const emp = (await pool.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const total = Math.max(0, num(b.total));
      if (!(total > 0)) return res.status(400).json({ message: 'Nominal piutang wajib diisi' });
      const name = str(b.customerName).trim();
      if (!name) return res.status(400).json({ message: 'Nama pelanggan wajib diisi' });
      const row = (await pool.query(
        `INSERT INTO ops_receivables (company_id, code, customer_id, customer_name, customer_phone, total, paid_amount, due_date, status, note, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,0,$7,'UNPAID',$8,$9) RETURNING id`,
        [companyId, docCode('RCV', undefined), str(b.customerId) || null, name, str(b.customerPhone) || null,
         total, str(b.dueDate) || null, str(b.note) || null, emp?.full_name || 'Kasir']
      )).rows[0];
      res.json({ id: row.id, message: 'Piutang dicatat' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  return router;
}

/** Bentuk piutang untuk aplikasi web. */
function mapReceivable(r: any) {
  const total = num(r.total), paid = num(r.paid_amount);
  const outstanding = Math.max(0, total - paid);
  const due = r.due_date || null;
  let overdue = false;
  if (due && (r.status === 'UNPAID' || r.status === 'PARTIAL')) {
    try { overdue = new Date(String(due).slice(0, 10) + 'T23:59:59') < new Date(); } catch { /* ignore */ }
  }
  return {
    id: r.id, code: r.code || null, saleId: r.sale_id || null,
    customerId: r.customer_id || null, customerName: r.customer_name, customerPhone: r.customer_phone || null,
    total, paidAmount: paid, outstanding, dueDate: due, status: r.status, note: r.note || null,
    overdue, createdBy: r.created_by || null, createdAt: r.created_at, settledAt: r.settled_at || null,
  };
}

function mapSession(r: any) {
  return {
    id: r.id, code: r.code || null, shiftNo: r.shift_no != null ? int(r.shift_no) : null,
    shiftLabel: r.shift_label || null, terminal: r.terminal || null,
    cashierId: r.cashier_id, cashierName: r.cashier_name,
    openingCash: num(r.opening_cash), closingCash: r.closing_cash != null ? num(r.closing_cash) : null,
    expectedCash: r.expected_cash != null ? num(r.expected_cash) : null, cashDiff: r.cash_diff != null ? num(r.cash_diff) : null,
    countedBreakdown: r.counted_breakdown || null, varianceNote: r.variance_note || null,
    closedBy: r.closed_by || null, approvedBy: r.approved_by || null,
    status: r.status, openedAt: r.opened_at, closedAt: r.closed_at, note: r.note,
  };
}
function mapSale(r: any) {
  return {
    id: r.id, sessionId: r.session_id, cashierId: r.cashier_id, cashierName: r.cashier_name, code: r.code,
    subtotal: num(r.subtotal), discount: num(r.discount), total: num(r.total), paid: num(r.paid), change: num(r.change),
    tax: num(r.tax), memberDiscount: num(r.member_discount), cogs: num(r.cogs),
    profit: num(r.subtotal) - num(r.discount) - num(r.member_discount) - num(r.cogs),
    customerId: r.customer_id, customerName: r.customer_name, note: r.note,
    cashReceived: num(r.cash_received), splitPayments: r.split_payments || null,
    paymentMethods: r.payment_methods || null,
    paymentDetail: r.payment_detail || null,
    voidedAt: r.voided_at || null, voidReason: r.void_reason || null, voidBy: r.void_by || null,
    paymentMethod: r.payment_method, status: r.status, createdAt: r.created_at,
  };
}
function mapCustomer(r: any) {
  return {
    id: r.id, name: r.name, phone: r.phone, tier: r.tier,
    discountPercent: num(r.discount_percent), points: int(r.points), active: r.active !== false,
    createdAt: r.created_at,
  };
}
function mapHold(r: any) {
  return { id: r.id, label: r.label, cashierName: r.cashier_name, payload: r.payload || {}, createdAt: r.created_at };
}
function mapSettings(r: any) {
  return {
    taxRate: r ? num(r.tax_rate) : 0,
    taxEnabled: r ? r.tax_enabled !== false : false,
    splitPaymentEnabled: r ? r.split_payment_enabled !== false : true,
    lowStockThreshold: r ? int(r.low_stock_threshold) : 5,
    storeName: r ? r.store_name : null,
    dailyTarget: r ? num(r.daily_target) : 0,
    varianceTolerance: r ? num(r.variance_tolerance) : 0,
    requireVarianceApproval: r ? r.require_variance_approval === true : false,
    blindClose: r ? r.blind_close !== false : true,
    receiptFooter: r ? r.receipt_footer : null,
    storeAddress: r ? r.store_address : null,
    storePhone: r ? r.store_phone : null,
  };
}
