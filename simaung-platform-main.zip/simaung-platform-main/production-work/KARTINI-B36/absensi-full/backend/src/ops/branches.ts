import { outletBranding } from '../outlet-branding.js';
import express from 'express';
import type {Pool} from 'pg';
import {dualAuth} from './common.js';
import {createBranchPool} from './branch-pool.js';
export function createBranchGateway(owner:Pool,auth:express.RequestHandler,adminAuth:express.RequestHandler){
 const scoped=createBranchPool(owner),router=express.Router();
 router.use(dualAuth(auth,adminAuth));
 const identity=(req:any)=>({company:req.admin?.companyId||req.user?.companyId,actor:req.admin?.adminId||req.user?.employeeId,central:['SUPERADMIN','DEV'].includes(String(req.admin?.role||'').toUpperCase())});
 async function permitted(req:any){const u=identity(req);if(!u.company||!u.actor)throw Error('Unauthorized');return (await owner.query(`SELECT b.id,b.code,b.name,c.warehouse_id FROM branches b JOIN ops_branch_config c ON c.branch_id=b.id WHERE b.company_id=$1 AND b.is_active=true AND ($3::boolean OR EXISTS(SELECT 1 FROM ops_branch_access a WHERE a.branch_id=b.id AND a.company_id=$1 AND a.actor_id=$2)) ORDER BY c.legacy DESC,b.code`,[u.company,u.actor,u.central])).rows;}
 router.get('/branches',async(req,res)=>{try{res.json({items:(await permitted(req)).map(branch=>({...branch,branding:outletBranding(branch.code,branch.name)})),canManage:identity(req).central})}catch{res.status(503).json({message:'Daftar cabang belum tersedia.'})}});
 router.get('/admin/branch-members',async(req,res)=>{
  const u=identity(req);if(!u.central)return res.sendStatus(403);
  try{const rows=(await owner.query("SELECT id,name,'Admin' AS kind FROM admins WHERE company_id=$1 AND active=true UNION ALL SELECT id,full_name AS name,'Karyawan' AS kind FROM employees WHERE company_id=$1 ORDER BY name",[u.company])).rows;res.json({items:rows})}catch{res.status(503).json({message:'Daftar akun tidak tersedia.'})}
 });
 router.post('/admin/branches',async(req,res)=>{
  const u=identity(req);if(!u.central)return res.sendStatus(403);
  const code=String(req.body?.code||'').trim().toUpperCase(),name=String(req.body?.name||'').trim();
  if(!/^[A-Z0-9_-]{1,24}$/.test(code)||!name||name.length>120)return res.status(400).json({message:'Kode atau nama cabang tidak valid.'});
  const db=await owner.connect();try{
   await db.query('BEGIN');
   const b=(await db.query('INSERT INTO branches(company_id,code,name)VALUES($1,$2,$3)RETURNING id,code,name',[u.company,code,name])).rows[0];
   const w=(await db.query("INSERT INTO warehouses(company_id,branch_id,code,name)VALUES($1,$2,$3,$4)RETURNING id",[u.company,b.id,code+'-MAIN','Gudang '+name])).rows[0];
   await db.query('INSERT INTO ops_branch_config(company_id,branch_id,warehouse_id)VALUES($1,$2,$3)',[u.company,b.id,w.id]);
   await db.query('COMMIT');res.status(201).json({branch:b,warehouseId:w.id});
  }catch{await db.query('ROLLBACK');res.status(409).json({message:'Cabang tidak dapat dibuat; periksa kode yang sudah dipakai.'})}finally{db.release()}
 });
 router.post('/admin/branches/:id/access',async(req,res)=>{
  const u=identity(req);if(!u.central)return res.sendStatus(403);
  const actor=String(req.body?.actorId||'');if(!/^[0-9a-f-]{36}$/i.test(actor))return res.sendStatus(400);
  const db=await owner.connect();try{
   await db.query('BEGIN');
   const branch=(await db.query('SELECT id FROM branches WHERE id=$1 AND company_id=$2',[req.params.id,u.company])).rows[0];
   const admin=(await db.query('SELECT id,email,name FROM admins WHERE id=$1 AND company_id=$2 AND active=true',[actor,u.company])).rows[0];
   const employee=(await db.query('SELECT id FROM employees WHERE id=$1 AND company_id=$2',[actor,u.company])).rows[0];
   if(!branch||(!admin&&!employee))throw Error('Not found');
   if(req.body?.enabled===false){await db.query('DELETE FROM ops_branch_access WHERE branch_id=$1 AND actor_id=$2 AND company_id=$3',[branch.id,actor,u.company]);if(admin)await db.query('DELETE FROM user_scopes WHERE user_id=$1 AND company_id=$2 AND branch_id=$3',[actor,u.company,branch.id]);}
   else{
    await db.query('INSERT INTO ops_branch_access(company_id,actor_id,branch_id)VALUES($1,$2,$3)ON CONFLICT DO NOTHING',[u.company,actor,branch.id]);
    if(admin){await db.query('INSERT INTO profiles(id,email,full_name)VALUES($1,$2,$3)ON CONFLICT(id)DO NOTHING',[actor,admin.email,admin.name]);await db.query('INSERT INTO user_scopes(user_id,company_id,branch_id)SELECT $1,$2,$3 WHERE NOT EXISTS(SELECT 1 FROM user_scopes WHERE user_id=$1 AND company_id=$2 AND branch_id=$3)',[actor,u.company,branch.id]);}
   }
   await db.query('COMMIT');res.json({ok:true});
  }catch{await db.query('ROLLBACK');res.status(400).json({message:'Penugasan cabang tidak dapat disimpan.'})}finally{db.release()}
 });
 router.use(async(req,res,next)=>{
  try{
   const u=identity(req),branches=await permitted(req);
   const requested=String(req.header('x-branch-id')||'');
   const branch=requested?branches.find(b=>b.id===requested):branches.length===1?branches[0]:null;
   if(!branch)return res.status(requested?403:409).json({message:requested?'Cabang tidak diizinkan.':'Pilih cabang sebelum menjalankan layanan.',branches});
   res.setHeader('X-Kartini-Branch',branch.id);(req as any).opsBranchId=branch.id;
   scoped.run({companyId:u.company,branchId:branch.id,actorId:u.actor},()=>next());
  }catch{res.status(503).json({message:'Cakupan cabang tidak dapat diverifikasi.'})}
 });
 return {router,pool:scoped.pool};
}
