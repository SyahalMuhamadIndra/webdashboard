import type {Pool} from 'pg';
import {cents,amount,decimal} from '../money.js';

export class PaymentError extends Error {
  constructor(readonly status:number,message:string){super(message)}
}

/** One locked transaction covers receipt, balance and linked sale. */
export async function receiveReceivablePayment(pool:Pool,input:{companyId:string;employeeId:string;receivableId:string;amount:unknown;method:string;note:string|null}) {
  let received:bigint;
  try{received=cents(input.amount)}catch{throw new PaymentError(400,'Nominal pembayaran harus berupa angka dengan maksimal dua angka desimal.')}
  if(received<=0n)throw new PaymentError(400,'Nominal pembayaran harus lebih dari nol.');
  amount(received); // Bound JSON numbers to exact supported monetary precision.
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const row=(await client.query('SELECT * FROM ops_receivables WHERE id=$1 AND company_id=$2 FOR UPDATE',[input.receivableId,input.companyId])).rows[0];
    if(!row)throw new PaymentError(404,'Piutang tidak ditemukan.');
    if(!['UNPAID','PARTIAL'].includes(row.status))throw new PaymentError(400,'Piutang tidak terbuka untuk pembayaran.');
    const total=cents(row.total),paid=cents(row.paid_amount),outstanding=total-paid;
    if(received>outstanding)throw new PaymentError(400,'Nominal pembayaran melebihi sisa piutang.');
    const actor=(await client.query('SELECT full_name FROM employees WHERE id=$1 AND company_id=$2',[input.employeeId,input.companyId])).rows[0];
    if(!actor)throw new PaymentError(401,'Akun kasir tidak ditemukan.');
    const newPaid=paid+received,status=newPaid===total?'PAID':'PARTIAL';
    await client.query(`INSERT INTO ops_receivable_payments(company_id,receivable_id,amount,method,note,actor_name)
      VALUES($1,$2,$3,$4,$5,$6)`,[input.companyId,input.receivableId,decimal(received),input.method,input.note,actor.full_name]);
    await client.query(`UPDATE ops_receivables SET paid_amount=$3,status=$4,settled_at=CASE WHEN $4='PAID' THEN now() ELSE NULL END,updated_at=now()
      WHERE id=$1 AND company_id=$2`,[input.receivableId,input.companyId,decimal(newPaid),status]);
    if(row.sale_id){
      // paid_amount already includes the down payment; never add it twice.
      const sale=await client.query(`UPDATE ops_pos_sales SET paid=$3,change=GREATEST(0,$3::numeric-total),status=$4
        WHERE id=$1 AND company_id=$2`,[row.sale_id,input.companyId,decimal(newPaid),status==='PAID'?'PAID':'TEMPO']);
      if(sale.rowCount!==1)throw new Error('Linked sale unavailable');
    }
    await client.query('COMMIT');
    return {message:status==='PAID'?'Piutang LUNAS':'Pembayaran diterima',paidAmount:amount(newPaid),outstanding:amount(total-newPaid),status,method:input.method};
  }catch(error){await client.query('ROLLBACK').catch(()=>{});throw error}finally{client.release()}
}
