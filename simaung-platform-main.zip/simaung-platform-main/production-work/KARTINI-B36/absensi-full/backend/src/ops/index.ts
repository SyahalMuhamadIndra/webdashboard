import { createOlseraImport } from './olsera-import.js';
// =====================================================================
//  MODUL OPERASIONAL (B11) — Agregator router.
//  Menggabungkan sub-router: Gudang/Opname, Driver, POS; plus ringkasan
//  admin per perusahaan (dipakai kartu "Operasional" di panel superadmin).
// =====================================================================
import express from 'express';
import type { Pool } from 'pg';
import { ensureOpsTables, int, num, str, isoDateTz } from './common.js';
import { createOpsInventoryRouter, attachAdminOpnameRoutes } from './inventory.js';
import { createOpsDriverRouter } from './driver.js';
import { createOpsPosRouter } from './pos.js';
import { createOpsShiftRouter } from './shift.js';
import { createOpsRecipesRouter } from './recipes.js';
import {createBranchGateway} from './branches.js';

export function createOpsRouter(deps: { pool: Pool; auth: express.RequestHandler; adminAuth: express.RequestHandler }) {
  const { pool:owner, auth, adminAuth } = deps;
  const router = express.Router();
  const gateway=createBranchGateway(owner,auth,adminAuth),pool=gateway.pool;
  router.use(gateway.router);
  deps={...deps,pool};
  const manageImport: express.RequestHandler = (req, res, next) => {
    if (!['SUPERADMIN','DEV'].includes(req.admin?.role)) {
      res.status(403).json({message:'Impor Olsera hanya untuk admin pusat.'});
      return;
    }
    next();
  };
  router.post('/admin/olsera-import/preview', manageImport, createOlseraImport(pool, false));
  router.post('/admin/olsera-import/commit', manageImport, createOlseraImport(pool, true));


  router.use(createOpsDriverRouter(deps));
  router.use(createOpsInventoryRouter(deps));
  router.use(createOpsPosRouter({...deps,rawPool:owner}));
  // B17 — Shifting kasir profesional (X/Z-Report, kas masuk-keluar, selisih kas)
  // dan analitik penghasilan (omzet, HPP, laba, margin, target, ekspor CSV).
  router.use(createOpsShiftRouter(deps));
  // B21 — Bahan baku & resep: stok bahan turun otomatis setiap penjualan produk beresep.
  router.use(createOpsRecipesRouter(deps));
  // Endpoint admin opname (didaftarkan di router yang sama agar path /admin/... konsisten).
  attachAdminOpnameRoutes(router, { pool, adminAuth });

  /**
   * GET /api/admin/ops/overview — ringkasan operasional perusahaan.
   * Digunakan panel superadmin untuk menampilkan metrik Driver/Opname/POS.
   */
  router.get('/admin/ops/overview', adminAuth, async (req, res) => {
    try {
      await ensureOpsTables(pool);
      const companyId = (req as any).admin.companyId;
      const date = str(req.query.date) || isoDateTz();

      const trips = (await pool.query(
        `SELECT COUNT(*)::int AS total,
                COUNT(*) FILTER (WHERE status IN ('ASSIGNED','ON_THE_WAY','ARRIVED'))::int AS active,
                COUNT(*) FILTER (WHERE status='COMPLETED')::int AS completed
           FROM ops_trips WHERE company_id=$1`, [companyId]
      )).rows[0];
      const notes = (await pool.query(
        `SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE status='DELIVERED')::int AS delivered
           FROM ops_delivery_notes WHERE company_id=$1`, [companyId]
      )).rows[0];
      const opnames = (await pool.query(
        `SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE status='SUBMITTED')::int AS pending,
                COUNT(*) FILTER (WHERE status='APPROVED')::int AS approved,
                COUNT(*) FILTER (WHERE status='REJECTED')::int AS rejected
           FROM ops_stock_opnames WHERE company_id=$1 AND created_at::date=$2::date`, [companyId, date]
      )).rows[0];
      const pos = (await pool.query(
        `SELECT COUNT(*)::int AS n, COALESCE(SUM(total),0) AS total,
                COALESCE(SUM(CASE WHEN payment_method='CASH' THEN total ELSE 0 END),0) AS cash
           FROM ops_pos_sales WHERE company_id=$1 AND status='PAID' AND created_at::date=$2::date`, [companyId, date]
      )).rows[0];
      const products = (await pool.query(
        `SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE stock <= min_stock)::int AS low
           FROM ops_products WHERE company_id=$1 AND active=true`, [companyId]
      )).rows[0];
      const openSessions = (await pool.query(
        `SELECT COUNT(*)::int AS n FROM ops_pos_sessions WHERE company_id=$1 AND status='OPEN'`, [companyId]
      )).rows[0];

      res.json({
        date,
        trips: { total: int(trips?.total), active: int(trips?.active), completed: int(trips?.completed) },
        deliveryNotes: { total: int(notes?.total), delivered: int(notes?.delivered) },
        opnames: { total: int(opnames?.total), pending: int(opnames?.pending), approved: int(opnames?.approved), rejected: int(opnames?.rejected) },
        pos: { count: int(pos?.n), total: num(pos?.total), cash: num(pos?.cash), openSessions: int(openSessions?.n) },
        products: { total: int(products?.total), low: int(products?.low) },
      });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  return router;
}
