import { createHash } from 'node:crypto';
import type { RequestHandler } from 'express';
import type { Pool } from 'pg';

type Kind = 'products' | 'materials' | 'recipes';
type Item = {id:string; sku:string|null; barcode?:string|null; name?:string; price?:string; unit:string; active:boolean};
type Row = Record<string, unknown>;

function text(value: unknown, max = 160) {
  if (typeof value !== 'string' || value.length > max) throw new Error('Kolom teks tidak valid atau terlalu panjang.');
  return value.trim();
}

function number(value: unknown, required = false) {
  if (value === '' && !required) return 0;
  const raw = text(value, 24);
  if (!/^\d{1,12}(?:[.,]\d{1,6})?$/.test(raw)) throw new Error('Angka harus tanpa pemisah ribuan atau simbol mata uang.');
  return Number(raw.replace(',', '.'));
}

export function createOlseraImport(pool: Pool, commit: boolean): RequestHandler {
  return async (req, res) => {
    res.set('Cache-Control', 'no-store');
    const kind = req.body?.kind as Kind;
    const rows = req.body?.rows;
    if (!['products','materials','recipes'].includes(kind) || !Array.isArray(rows) || !rows.length || rows.length > 200)
      return void res.status(400).json({message:'Pilih jenis data dan masukkan 1–200 baris per impor.'});
    const branch = res.getHeader('X-Kartini-Branch');
    if (typeof branch !== 'string' || (commit && req.body.branch !== branch))
      return void res.status(409).json({message:'Cabang berubah. Buat pratinjau ulang.'});
    const company = req.admin.companyId;
    const db = await pool.connect().catch(() => null);
    if (!db) return void res.status(503).json({message:'Database impor tidak tersedia.'});
    try {
      await db.query('BEGIN');
      if (commit) await db.query('SELECT pg_advisory_xact_lock(hashtext($1))', ['olsera-import/'+company]);
      const location = (await db.query('SELECT c.warehouse_id,b.name FROM public.ops_branch_config c JOIN public.branches b ON b.id=c.branch_id AND b.company_id=c.company_id WHERE c.company_id=$1 AND c.branch_id=$2 AND b.is_active IS TRUE',[company,branch])).rows[0];
      if (!location) throw new Error('Missing branch warehouse');

      const products: Item[] = kind === 'materials' ? [] : (await db.query('SELECT id,sku,barcode,name,price,unit,active FROM ops_products WHERE company_id=$1',[company])).rows;
      const materials: Item[] = kind === 'products' ? [] : (await db.query('SELECT id,sku,name,unit,active FROM ops_materials WHERE company_id=$1',[company])).rows;
      const balances = kind === 'products' ? new Set<string>((await db.query('SELECT product_id FROM public.stock_balances WHERE company_id=$1 AND warehouse_id=$2',[company,location.warehouse_id])).rows.map(x=>x.product_id)) : new Set<string>();
      const recipes = kind === 'recipes' ? new Set<string>((await db.query('SELECT product_id,material_id FROM ops_recipes WHERE company_id=$1',[company])).rows.map(x=>x.product_id+'/'+x.material_id)) : new Set<string>();
      const key = (value: string | null | undefined) => (value ?? '').trim().toLowerCase();
      const seen = new Set<string>(), seenBarcode = new Set<string>();
      const actions: {sql:string; args:unknown[]}[] = [];
      const plan = rows.map((row:Row, i:number) => {
        let label = '-';
        try {
          if (!row || typeof row !== 'object' || Array.isArray(row)) throw new Error('Baris tidak valid.');
          const sku = text(row.sku, 80);
          label = sku;
          if (!sku) throw new Error('SKU wajib diisi.');
          const materialSku = kind === 'recipes' ? text(row.materialSku,80) : '';
          const identity = JSON.stringify([key(sku),key(materialSku)]);
          if (seen.has(identity)) throw new Error('SKU atau pasangan resep duplikat dalam file.');
          seen.add(identity);
          const matches = (kind === 'materials' ? materials : products).filter(p=>key(p.sku)===key(sku));
          if (matches.length > 1) throw new Error('SKU ambigu di katalog.');
          const existing = matches[0];
          const skip = (message:string) => ({line:i+2,label,status:'skip',message});
          const add = (message:string) => ({line:i+2,label,status:'add',message});
          if (kind === 'recipes') {
            const ingredients = materials.filter(p=>key(p.sku)===key(materialSku));
            if (!materialSku || ingredients.length !== 1 || !ingredients[0].active || !existing?.active)
              throw new Error('SKU produk dan SKU bahan aktif harus sudah tersedia.');
            const ingredient = ingredients[0];
            const qty = number(row.qty,true);
            if (qty <= 0 || key(text(row.unit,30)) !== key(ingredient.unit)) throw new Error('Qty harus positif dan satuannya harus sama dengan satuan dasar bahan.');
            label += ' / ' + materialSku;
            if (recipes.has(existing.id+'/'+ingredient.id)) return skip('Komponen resep sudah ada.');
            actions.push({sql:'INSERT INTO ops_recipes(company_id,product_id,material_id,qty) VALUES($1,$2,$3,$4)',args:[company,existing.id,ingredient.id,qty]});
            return add('Komponen resep baru.');
          }
          const name = text(row.name), unit = text(row.unit,30);
          if (!name || !unit) throw new Error('Nama dan satuan wajib diisi.');
          const stock = number(row.stock), cost = number(row.cost), minStock = number(row.minStock);
          if (kind === 'materials') {
            if (existing) {
              if (!existing.active || key(unit)!==key(existing.unit) || key(name)!==key(existing.name))
                throw new Error('SKU bahan sudah dipakai oleh bahan, satuan, atau status berbeda di cabang.');
              return skip('Bahan sudah ada di cabang.');
            }
            actions.push({sql:'INSERT INTO ops_materials(company_id,sku,name,unit,stock,min_stock,cost) VALUES($1,$2,$3,$4,$5,$6,$7)',args:[company,sku,name,unit,stock,minStock,cost]});
            return add('Bahan baru, stok awal '+stock+' '+unit+'.');
          }
          const price = number(row.price,true), barcode = text(row.barcode,100), category = text(row.category);
          if (barcode && (seenBarcode.has(key(barcode)) || products.some(p=>key(p.barcode)===key(barcode)&&p.id!==existing?.id)))
            throw new Error('Barcode sudah dipakai SKU lain.');
          if (barcode) seenBarcode.add(key(barcode));
          if (existing) {
            if (!existing.active) throw new Error('Produk dengan SKU ini diarsipkan.');
            if (key(name)!==key(existing.name) || key(unit)!==key(existing.unit) ||
                price!==Number(existing.price) || (barcode && key(barcode)!==key(existing.barcode)))
              throw new Error('SKU sudah ada dengan nama, satuan, harga, atau barcode berbeda di katalog bersama. Selaraskan data terlebih dahulu.');
            if (balances.has(existing.id) || row.stock === '') return skip('Produk sudah ada. Katalog dan saldo yang ada dipertahankan.');
            if (key(unit)!==key(existing.unit)) throw new Error('Satuan produk berbeda dari katalog.');
            actions.push({sql:'INSERT INTO public.stock_balances(company_id,warehouse_id,product_id,quantity,avg_cost) VALUES($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING',args:[company,location.warehouse_id,existing.id,stock,cost]});
            return add('Saldo awal cabang '+stock+' '+unit+'; katalog bersama dipertahankan.');
          }
          actions.push({sql:'INSERT INTO ops_products(company_id,sku,name,barcode,category,unit,price,cost,stock,min_stock) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',args:[company,sku,name,barcode||null,category||null,unit,price,cost,stock,minStock]});
          return add('Produk baru, stok awal '+stock+' '+unit+'.');
        } catch (error) {
          return {line:i+2,label,status:'error',message:error instanceof Error ? error.message : 'Baris tidak valid.'};
        }
      });
      const fingerprint = createHash('sha256').update(JSON.stringify([company,branch,kind,rows,plan,actions])).digest('hex');
      if (commit) {
        if (req.body.fingerprint !== fingerprint || plan.some(x=>x.status==='error')) {
          await db.query('ROLLBACK');
          return void res.status(409).json({message:'Data berubah atau masih memiliki baris bermasalah. Buat pratinjau ulang.'});
        }
        for (const action of actions) {
          const result = await db.query(action.sql,action.args);
          if (result.rowCount !== 1) throw new Error('Concurrent change');
        }
        await db.query('COMMIT');
      } else await db.query('ROLLBACK');
      res.json({branch,branchName:location.name,kind,plan,fingerprint,added:commit ? actions.length : 0});
    } catch {
      await db.query('ROLLBACK').catch(()=>{});
      res.status(409).json({message:'Impor tidak dapat diproses. Periksa cabang dan data, lalu buat pratinjau ulang.'});
    } finally { db.release(); }
  };
}
