// =====================================================================
//  MODUL OPERASIONAL (B11) — Driver.
//  - Tracking perjalanan (status + posisi terakhir + riwayat event).
//  - Surat jalan (dibuat driver, dapat dipantau & dicetak admin).
// =====================================================================
import express from 'express';
import type { Pool } from 'pg';
import { ensureOpsTables, int, num, str, requireOpsRole, docCode } from './common.js';

const TRIP_STATUS = ['ASSIGNED', 'ON_THE_WAY', 'ARRIVED', 'COMPLETED', 'CANCELLED'];

export function createOpsDriverRouter(deps: { pool: Pool; auth: express.RequestHandler; adminAuth: express.RequestHandler }) {
  const { pool, auth, adminAuth } = deps;
  const router = express.Router();

  async function nextSeq(table: string, companyId: string): Promise<number> {
    const r = (await pool.query(
      `SELECT COUNT(*)::int AS n FROM ${table} WHERE company_id=$1 AND created_at::date = (now() AT TIME ZONE 'UTC' + interval '7 hours')::date`,
      [companyId]
    )).rows[0];
    return int(r?.n) + 1;
  }

  // ------------------------------------------------------------------
  //  DRIVER — perjalanan
  // ------------------------------------------------------------------

  /** GET /api/ops/trips — daftar perjalanan (query: mine=1, status). */
  router.get(['/trips', '/driver/trips'], auth, requireOpsRole(pool, 'DRIVER'), async (req, res) => {
    try {
      const me = (req as any).user.employeeId;
      const companyId = (req as any).user.companyId;
      const mine = str(req.query.mine ?? '1') !== '0';
      const st = str(req.query.status).toUpperCase();
      const rows = (await pool.query(
        `SELECT t.*, (SELECT COUNT(*)::int FROM ops_delivery_notes n WHERE n.trip_id=t.id) AS note_count
           FROM ops_trips t
          WHERE t.company_id=$1 ${mine ? 'AND t.driver_id=$2' : ''} ${st ? `AND t.status='${st.replace(/'/g, '')}'` : ''}
          ORDER BY t.created_at DESC LIMIT 200`,
        mine ? [companyId, me] : [companyId]
      )).rows;
      const items = rows.map(mapTrip);
      res.json({ items, trips: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/trips — driver membuat perjalanan baru. */
  router.post(['/trips', '/driver/trips'], auth, requireOpsRole(pool, 'DRIVER'), async (req, res) => {
    try {
      const b = req.body ?? {};
      const me = (req as any).user.employeeId;
      const companyId = (req as any).user.companyId;
      const dest = str(b.destination).trim();
      if (!dest) return res.status(400).json({ message: 'Tujuan perjalanan wajib diisi' });
      const emp = (await pool.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const code = docCode('TRP', await nextSeq('ops_trips', companyId));
      const row = (await pool.query(
        `INSERT INTO ops_trips (company_id, code, driver_id, driver_name, vehicle, destination, note, status, planned_at, started_at, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,'ON_THE_WAY', COALESCE($8, now()), now(), $9) RETURNING id, code`,
        [companyId, code, me, emp?.full_name || 'Driver', str(b.vehicle) || null, dest, str(b.note) || null,
         b.plannedAt || null, emp?.full_name || 'Driver']
      )).rows[0];
      await pool.query(
        `INSERT INTO ops_trip_events (trip_id, status, note, actor_name) VALUES ($1,'ON_THE_WAY',$2,$3)`,
        [row.id, str(b.note) || 'Perjalanan dimulai', emp?.full_name || 'Driver']
      );
      res.json({ id: row.id, code: row.code, message: 'Perjalanan dibuat' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/ops/trips/:id — detail perjalanan + event + surat jalan. */
  router.get(['/trips/:id', '/driver/trips/:id'], auth, requireOpsRole(pool, 'DRIVER'), async (req, res) => {
    try {
      const companyId = (req as any).user.companyId;
      const head = (await pool.query(`SELECT * FROM ops_trips WHERE id=$1 AND company_id=$2`, [req.params.id, companyId])).rows[0];
      if (!head) return res.status(404).json({ message: 'Perjalanan tidak ditemukan' });
      const events = (await pool.query(
        `SELECT id, status, note, lat, lng, actor_name, created_at FROM ops_trip_events WHERE trip_id=$1 ORDER BY created_at ASC`, [req.params.id]
      )).rows.map((r: any) => ({
        id: r.id, status: r.status, note: r.note, lat: r.lat != null ? num(r.lat) : null,
        lng: r.lng != null ? num(r.lng) : null, actorName: r.actor_name, createdAt: r.created_at,
      }));
      const notes = (await pool.query(
        `SELECT id, code, recipient_name, address, status, total_items, created_at FROM ops_delivery_notes WHERE trip_id=$1 ORDER BY created_at DESC`, [req.params.id]
      )).rows.map(mapNoteHead);
      res.json({ trip: mapTrip(head), events, notes });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/trips/:id/event — ubah status (ARRIVED/COMPLETED/CANCELLED). */
  router.post(['/trips/:id/event', '/driver/trips/:id/event'], auth, requireOpsRole(pool, 'DRIVER'), async (req, res) => {
    try {
      const b = req.body ?? {};
      const status = String(b.status || '').toUpperCase();
      if (!TRIP_STATUS.includes(status)) return res.status(400).json({ message: 'Status tidak valid' });
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const head = (await pool.query(`SELECT id, driver_id FROM ops_trips WHERE id=$1 AND company_id=$2`, [req.params.id, companyId])).rows[0];
      if (!head) return res.status(404).json({ message: 'Perjalanan tidak ditemukan' });
      if (head.driver_id && head.driver_id !== me) return res.status(403).json({ message: 'Bukan perjalanan Anda' });
      const emp = (await pool.query(`SELECT full_name FROM employees WHERE id=$1`, [me])).rows[0];
      const lat = b.lat != null ? num(b.lat) : null;
      const lng = b.lng != null ? num(b.lng) : null;
      const finished = status === 'COMPLETED' || status === 'CANCELLED';
      await pool.query(
        `UPDATE ops_trips SET status=$2,
             last_lat=COALESCE($3,last_lat), last_lng=COALESCE($4,last_lng),
             finished_at=CASE WHEN $5 THEN now() ELSE finished_at END, updated_at=now()
          WHERE id=$1`,
        [req.params.id, status, lat, lng, finished]
      );
      await pool.query(
        `INSERT INTO ops_trip_events (trip_id, status, note, lat, lng, actor_name) VALUES ($1,$2,$3,$4,$5,$6)`,
        [req.params.id, status, str(b.note) || null, lat, lng, emp?.full_name || 'Driver']
      );
      res.json({ ok: true, status, message: 'Status perjalanan diperbarui' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/trips/:id/location — kirim titik posisi terakhir. */
  router.post(['/trips/:id/location', '/driver/trips/:id/location'], auth, requireOpsRole(pool, 'DRIVER'), async (req, res) => {
    try {
      const b = req.body ?? {};
      const lat = num(b.lat, NaN);
      const lng = num(b.lng, NaN);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) return res.status(400).json({ message: 'Koordinat tidak valid' });
      const companyId = (req as any).user.companyId;
      const head = (await pool.query(`SELECT id FROM ops_trips WHERE id=$1 AND company_id=$2`, [req.params.id, companyId])).rows[0];
      if (!head) return res.status(404).json({ message: 'Perjalanan tidak ditemukan' });
      await pool.query(`UPDATE ops_trips SET last_lat=$2, last_lng=$3, updated_at=now() WHERE id=$1`, [req.params.id, lat, lng]);
      res.json({ ok: true });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ------------------------------------------------------------------
  //  DRIVER — surat jalan
  // ------------------------------------------------------------------

  /** GET /api/ops/trips/:id/notes — surat jalan milik perjalanan. */
  router.get(['/trips/:id/notes', '/driver/trips/:id/notes'], auth, requireOpsRole(pool, 'DRIVER'), async (req, res) => {
    try {
      const rows = (await pool.query(
        `SELECT id, code, recipient_name, address, status, total_items, created_at
           FROM ops_delivery_notes WHERE trip_id=$1 AND company_id=$2 ORDER BY created_at DESC`,
        [req.params.id, (req as any).user.companyId]
      )).rows.map(mapNoteHead);
      res.json({ items: rows, notes: rows });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/trips/:id/notes — driver membuat surat jalan. */
  router.post(['/trips/:id/notes', '/driver/trips/:id/notes'], auth, requireOpsRole(pool, 'DRIVER'), async (req, res) => {
    const client = await pool.connect();
    try {
      const b = req.body ?? {};
      const companyId = (req as any).user.companyId;
      const me = (req as any).user.employeeId;
      const trip = (await client.query(`SELECT id, driver_name FROM ops_trips WHERE id=$1 AND company_id=$2`, [req.params.id, companyId])).rows[0];
      if (!trip) return res.status(404).json({ message: 'Perjalanan tidak ditemukan' });
      const items = Array.isArray(b.items) ? b.items.filter((x: any) => str(x.productName).trim()) : [];
      const code = docCode('SJ', await nextSeq('ops_delivery_notes', companyId));
      await client.query('BEGIN');
      const head = (await client.query(
        `INSERT INTO ops_delivery_notes (company_id, code, trip_id, driver_id, driver_name, recipient_name, address, note, status, total_items, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'ISSUED',$9,$10) RETURNING id, code, created_at`,
        [companyId, code, trip.id, me, trip.driver_name || 'Driver', str(b.recipientName) || null,
         str(b.address) || null, str(b.note) || null, items.length, trip.driver_name || 'Driver']
      )).rows[0];
      for (const it of items) {
        await client.query(
          `INSERT INTO ops_delivery_note_items (note_id, product_id, product_name, sku, qty, unit)
           VALUES ($1,$2,$3,$4,$5,$6)`,
          [head.id, str(it.productId) || null, str(it.productName), str(it.sku) || null, int(it.qty), str(it.unit) || 'pcs']
        );
      }
      await client.query('COMMIT');
      res.json({ id: head.id, code: head.code, message: 'Surat jalan dibuat' });
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* ignore */ }
      console.error(e); res.status(500).json({ message: 'Server error' });
    } finally { client.release(); }
  });

  /** GET /api/ops/delivery-notes/:id — detail surat jalan (driver). */
  router.get('/delivery-notes/:id', auth, requireOpsRole(pool, 'DRIVER', 'KEPALA_GUDANG', 'KASIR'), async (req, res) => {
    try { await respondNoteDetail(pool, req, res); } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/admin/delivery-notes/:id — detail surat jalan (admin, untuk cetak). */
  router.get('/admin/delivery-notes/:id', adminAuth, async (req, res) => {
    try { await respondNoteDetail(pool, req, res, (req as any).admin.companyId); } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/ops/delivery-notes/:id/deliver — tandai sudah dikirim ke penerima. */
  router.post(['/delivery-notes/:id/deliver', '/driver/delivery-notes/:id/deliver'], auth, requireOpsRole(pool, 'DRIVER'), async (req, res) => {
    try {
      const row = (await pool.query(
        `UPDATE ops_delivery_notes SET status='DELIVERED', delivered_at=now(), updated_at=now()
          WHERE id=$1 AND company_id=$2 RETURNING id`, [req.params.id, (req as any).user.companyId]
      )).rows[0];
      if (!row) return res.status(404).json({ message: 'Surat jalan tidak ditemukan' });
      res.json({ ok: true, message: 'Surat jalan ditandai terkirim' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  // ------------------------------------------------------------------
  //  ADMIN — pantau perjalanan & surat jalan
  // ------------------------------------------------------------------

  /** GET /api/admin/trips — pantau seluruh perjalanan perusahaan. */
  router.get('/admin/trips', adminAuth, async (req, res) => {
    try {
      const companyId = (req as any).admin.companyId;
      const st = str(req.query.status).toUpperCase();
      const rows = (await pool.query(
        `SELECT t.*, (SELECT COUNT(*)::int FROM ops_delivery_notes n WHERE n.trip_id=t.id) AS note_count
           FROM ops_trips t WHERE t.company_id=$1 ${st ? `AND t.status='${st.replace(/'/g, '')}'` : ''}
          ORDER BY t.created_at DESC LIMIT 300`, [companyId]
      )).rows;
      const items = rows.map(mapTrip);
      res.json({ items, trips: items });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** POST /api/admin/trips — admin menugaskan perjalanan ke driver. */
  router.post('/admin/trips', adminAuth, async (req, res) => {
    try {
      const b = req.body ?? {};
      const companyId = (req as any).admin.companyId;
      const dest = str(b.destination).trim();
      if (!dest) return res.status(400).json({ message: 'Tujuan perjalanan wajib diisi' });
      let driverName: string | null = null;
      const driverId = str(b.driverId) || null;
      if (driverId) {
        const d = (await pool.query(`SELECT full_name FROM employees WHERE id=$1 AND company_id=$2`, [driverId, companyId])).rows[0];
        driverName = d?.full_name || null;
      }
      const code = docCode('TRP', await nextSeq('ops_trips', companyId));
      const row = (await pool.query(
        `INSERT INTO ops_trips (company_id, code, driver_id, driver_name, vehicle, destination, note, status, planned_at, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,'ASSIGNED',$8,$9) RETURNING id, code`,
        [companyId, code, driverId, driverName, str(b.vehicle) || null, dest, str(b.note) || null,
         b.plannedAt || null, (req as any).admin.adminName || 'Admin']
      )).rows[0];
      await pool.query(`INSERT INTO ops_trip_events (trip_id, status, note, actor_name) VALUES ($1,'ASSIGNED',$2,$3)`,
        [row.id, 'Perjalanan ditugaskan', (req as any).admin.adminName || 'Admin']);
      res.json({ id: row.id, code: row.code, message: 'Perjalanan ditugaskan' });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  /** GET /api/admin/delivery-notes — daftar seluruh surat jalan. */
  router.get('/admin/delivery-notes', adminAuth, async (req, res) => {
    try {
      const rows = (await pool.query(
        `SELECT id, code, trip_id, driver_name, recipient_name, address, status, total_items, created_at
           FROM ops_delivery_notes WHERE company_id=$1 ORDER BY created_at DESC LIMIT 300`, [(req as any).admin.companyId]
      )).rows.map(mapNoteHead);
      res.json({ items: rows, notes: rows });
    } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
  });

  return router;
}

async function respondNoteDetail(pool: Pool, req: express.Request, res: express.Response, forcedCompany?: string) {
  const companyId = forcedCompany || (req as any).user?.companyId;
  const head = (await pool.query(
    `SELECT n.*, t.code AS trip_code, t.destination, t.vehicle FROM ops_delivery_notes n
       LEFT JOIN ops_trips t ON t.id = n.trip_id
      WHERE n.id=$1 AND n.company_id=$2`, [req.params.id, companyId]
  )).rows[0];
  if (!head) return res.status(404).json({ message: 'Surat jalan tidak ditemukan' });
  const items = (await pool.query(
    `SELECT id, product_id, product_name, sku, qty, unit FROM ops_delivery_note_items WHERE note_id=$1 ORDER BY product_name`, [req.params.id]
  )).rows.map((r: any) => ({ id: r.id, productId: r.product_id, productName: r.product_name, sku: r.sku, qty: int(r.qty), unit: r.unit }));
  res.json({ note: { ...mapNoteHead(head), tripCode: head.trip_code, destination: head.destination, vehicle: head.vehicle, note: head.note }, items, items2: items });
}

function mapTrip(r: any) {
  return {
    id: r.id, code: r.code, driverId: r.driver_id, driverName: r.driver_name, vehicle: r.vehicle,
    destination: r.destination, note: r.note, status: r.status,
    plannedAt: r.planned_at, startedAt: r.started_at, finishedAt: r.finished_at,
    lastLat: r.last_lat != null ? num(r.last_lat) : null, lastLng: r.last_lng != null ? num(r.last_lng) : null,
    noteCount: r.note_count != null ? int(r.note_count) : undefined,
    createdAt: r.created_at,
  };
}
function mapNoteHead(r: any) {
  return {
    id: r.id, code: r.code, tripId: r.trip_id, driverName: r.driver_name,
    recipientName: r.recipient_name, address: r.address, status: r.status,
    totalItems: int(r.total_items), createdAt: r.created_at,
  };
}
