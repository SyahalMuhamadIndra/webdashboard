// =====================================================================
//  MODUL OPERASIONAL (B11) — Helper bersama.
//
//  Fitur per-jabatan (role) karyawan:
//    - DRIVER        : tracking perjalanan + surat jalan
//    - PRAMUNIAGA    : sistem stock opname
//    - KEPALA_GUDANG : opname full + crosscek hasil opname pramuniaga
//    - KASIR         : sistem POS (kasir) lengkap
//  Seorang karyawan dapat memiliki BEBERAPA role (jabatan rangkap) dan
//  seluruh fasilitas dari setiap role-nya aktif bersamaan.
// =====================================================================
import express from 'express';
import {randomUUID} from 'node:crypto';
import type { Pool } from 'pg';

/** Offset zona waktu operasional (WIB = UTC+7) dalam menit. */
export const TZ_OFFSET_MIN = 7 * 60;

/** Tanggal (YYYY-MM-DD) menurut WIB. */
export function isoDateTz(d: Date = new Date()): string {
  return new Date(d.getTime() + TZ_OFFSET_MIN * 60000).toISOString().slice(0, 10);
}

/** Tambah [n] hari pada tanggal ISO (YYYY-MM-DD). */
export function addDays(iso: string, n: number): string {
  const d = new Date(iso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export const num = (v: any, def = 0): number => {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
};
export const int = (v: any, def = 0): number => Math.round(num(v, def));
export const str = (v: any): string => (v == null ? '' : String(v));
export const bool = (v: any, def = false): boolean =>
  typeof v === 'boolean' ? v : v === 'true' ? true : v === 'false' ? false : def;

/**
 * Ekspresi SQL untuk TANGGAL menurut zona waktu operasional (WIB).
 * Dipakai agar transaksi pukul 00:00–06:59 WIB tidak terhitung pada
 * tanggal sebelumnya (kesalahan umum pada created_at::date = UTC).
 */
export function wibDate(expr = 'created_at'): string {
  return `((((${expr}) AT TIME ZONE 'UTC') + interval '7 hours')::date)`;
}

/** Metode pembayaran POS yang dikenali (pelaporan penghasilan per metode). */
export const POS_METHODS = ['CASH', 'QRIS', 'DEBIT', 'CREDIT', 'TRANSFER', 'EWALLET', 'NON_CASH', 'TEMPO'];

/** Normalisasi metode pembayaran dari aplikasi/web ke himpunan standar POS. */
export function normalizePosMethod(v: any): string {
  const s = String(v == null ? '' : v).trim().toUpperCase().replace(/[\s-]+/g, '_');
  if (['CASH', 'TUNAI', 'CASH_'].includes(s)) return 'CASH';
  if (['QRIS', 'QR', 'QR_CODE'].includes(s)) return 'QRIS';
  if (['DEBIT', 'KARTU_DEBIT', 'DEBIT_CARD', 'KARTU'].includes(s)) return 'DEBIT';
  if (['CREDIT', 'KREDIT', 'CREDIT_CARD', 'KARTU_KREDIT'].includes(s)) return 'CREDIT';
  if (['TRANSFER', 'BANK_TRANSFER', 'TRF', 'VA', 'VIRTUAL_ACCOUNT'].includes(s)) return 'TRANSFER';
  if (['EWALLET', 'E_WALLET', 'OVO', 'GOPAY', 'DANA', 'SHOPEEPAY', 'LINKAJA'].includes(s)) return 'EWALLET';
  if (['TEMPO', 'HUTANG', 'UTANG', 'CREDIT_TERM', 'KASBON', 'PIUTANG'].includes(s)) return 'TEMPO';
  return 'NON_CASH';
}

/** true bila metode termasuk uang fisik (masuk ke laci kas). */
export function isCashMethod(m: string): boolean {
  return normalizePosMethod(m) === 'CASH';
}

let opsReady: Promise<any> | null = null;

/**
 * Pastikan seluruh tabel modul operasional tersedia (idempotent, aman
 * dijalankan berkali-kali). Termasuk tabel `employee_roles` (peran jabatan).
 */
export function ensureOpsTables(pool: Pool): Promise<any> {
  pool=(pool as any).setupPool||pool;
  if (!opsReady) {
    opsReady = pool.query(`
      -- Peran jabatan karyawan (multi-role / jabatan rangkap).
      CREATE TABLE IF NOT EXISTS employee_roles (
        employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
        role text NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now(),
        PRIMARY KEY (employee_id, role)
      );
      CREATE INDEX IF NOT EXISTS idx_employee_roles_emp ON employee_roles (employee_id);
      CREATE TABLE IF NOT EXISTS ops_operation_receipts (
        company_id uuid NOT NULL, actor_id uuid NOT NULL, operation_id uuid NOT NULL,
        action text NOT NULL, payload_hash text NOT NULL, result jsonb NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now(),
        PRIMARY KEY(company_id,actor_id,operation_id)
      );

      -- Master barang (dipakai stok opname gudang & katalog POS kasir).
      CREATE TABLE IF NOT EXISTS ops_products (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        sku text,
        name text NOT NULL,
        category text,
        unit text DEFAULT 'pcs',
        price numeric NOT NULL DEFAULT 0,
        cost numeric NOT NULL DEFAULT 0,
        stock integer NOT NULL DEFAULT 0,
        min_stock integer NOT NULL DEFAULT 0,
        active boolean NOT NULL DEFAULT true,
        image text,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_products_company ON ops_products(company_id, name);

      -- Sesi stok opname (pramuniaga area / kepala gudang full).
      CREATE TABLE IF NOT EXISTS ops_stock_opnames (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        employee_id uuid,
        employee_name text,
        kind text NOT NULL DEFAULT 'PRAMUNIAGA',
        area text,
        note text,
        total_items integer NOT NULL DEFAULT 0,
        total_diff integer NOT NULL DEFAULT 0,
        status text NOT NULL DEFAULT 'SUBMITTED',
        reviewed_by text,
        reviewed_at timestamptz,
        review_note text,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_opnames_company ON ops_stock_opnames(company_id, created_at DESC);

      CREATE TABLE IF NOT EXISTS ops_stock_opname_items (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        opname_id uuid NOT NULL REFERENCES ops_stock_opnames(id) ON DELETE CASCADE,
        product_id uuid,
        product_name text,
        sku text,
        system_stock integer NOT NULL DEFAULT 0,
        counted_stock integer NOT NULL DEFAULT 0,
        diff integer NOT NULL DEFAULT 0,
        note text,
        qty_in integer NOT NULL DEFAULT 0,
        qty_out integer NOT NULL DEFAULT 0,
        qty_reject integer NOT NULL DEFAULT 0
      );
      -- Mutasi stok (masuk/keluar/reject) untuk opname ala Allstock.
      ALTER TABLE ops_stock_opname_items ADD COLUMN IF NOT EXISTS qty_in integer NOT NULL DEFAULT 0;
      ALTER TABLE ops_stock_opname_items ADD COLUMN IF NOT EXISTS qty_out integer NOT NULL DEFAULT 0;
      ALTER TABLE ops_stock_opname_items ADD COLUMN IF NOT EXISTS qty_reject integer NOT NULL DEFAULT 0;

      -- Perjalanan (tracking driver).
      CREATE TABLE IF NOT EXISTS ops_trips (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        code text,
        driver_id uuid,
        driver_name text,
        vehicle text,
        destination text,
        note text,
        status text NOT NULL DEFAULT 'ASSIGNED',
        planned_at timestamptz,
        started_at timestamptz,
        finished_at timestamptz,
        last_lat double precision,
        last_lng double precision,
        created_by text,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_trips_company ON ops_trips(company_id, created_at DESC);

      CREATE TABLE IF NOT EXISTS ops_trip_events (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        trip_id uuid NOT NULL REFERENCES ops_trips(id) ON DELETE CASCADE,
        status text,
        note text,
        lat double precision,
        lng double precision,
        actor_name text,
        created_at timestamptz NOT NULL DEFAULT now()
      );

      -- Surat jalan.
      CREATE TABLE IF NOT EXISTS ops_delivery_notes (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        code text,
        trip_id uuid,
        driver_id uuid,
        driver_name text,
        recipient_name text,
        address text,
        note text,
        status text NOT NULL DEFAULT 'ISSUED',
        total_items integer NOT NULL DEFAULT 0,
        delivered_at timestamptz,
        created_by text,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_notes_company ON ops_delivery_notes(company_id, created_at DESC);

      CREATE TABLE IF NOT EXISTS ops_delivery_note_items (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        note_id uuid NOT NULL REFERENCES ops_delivery_notes(id) ON DELETE CASCADE,
        product_id uuid,
        product_name text,
        sku text,
        qty integer NOT NULL DEFAULT 0,
        unit text
      );

      -- Sesi kasir (POS).
      CREATE TABLE IF NOT EXISTS ops_pos_sessions (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        cashier_id uuid,
        cashier_name text,
        opening_cash numeric NOT NULL DEFAULT 0,
        closing_cash numeric,
        expected_cash numeric,
        cash_diff numeric,
        status text NOT NULL DEFAULT 'OPEN',
        opened_at timestamptz NOT NULL DEFAULT now(),
        closed_at timestamptz,
        note text
      );
      CREATE INDEX IF NOT EXISTS idx_ops_pos_sessions_company ON ops_pos_sessions(company_id, opened_at DESC);

      -- Penjualan POS.
      CREATE TABLE IF NOT EXISTS ops_pos_sales (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        session_id uuid,
        cashier_id uuid,
        cashier_name text,
        code text,
        subtotal numeric NOT NULL DEFAULT 0,
        discount numeric NOT NULL DEFAULT 0,
        total numeric NOT NULL DEFAULT 0,
        paid numeric NOT NULL DEFAULT 0,
        change numeric NOT NULL DEFAULT 0,
        payment_method text NOT NULL DEFAULT 'CASH',
        status text NOT NULL DEFAULT 'PAID',
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_sales_company ON ops_pos_sales(company_id, created_at DESC);

      CREATE TABLE IF NOT EXISTS ops_pos_sale_items (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        sale_id uuid NOT NULL REFERENCES ops_pos_sales(id) ON DELETE CASCADE,
        product_id uuid,
        product_name text,
        sku text,
        price numeric NOT NULL DEFAULT 0,
        qty integer NOT NULL DEFAULT 0,
        total numeric NOT NULL DEFAULT 0
      );

      -- ===== Migrasi POS lanjutan (ala referensi Kasir Pro) =====
      -- barcode produk (untuk scan / input cepat).
      ALTER TABLE ops_products ADD COLUMN IF NOT EXISTS barcode text;
      CREATE INDEX IF NOT EXISTS idx_ops_products_barcode ON ops_products(company_id, barcode);
      -- FOTO PRODUK (data-URL base64 / URL) untuk katalog POS.
      ALTER TABLE ops_products ADD COLUMN IF NOT EXISTS image text;

      -- pajak, diskon member, pelanggan, catatan, split payment, uang diterima.
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS tax numeric NOT NULL DEFAULT 0;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS member_discount numeric NOT NULL DEFAULT 0;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS customer_id uuid;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS customer_name text;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS note text;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS cash_received numeric NOT NULL DEFAULT 0;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS split_payments jsonb;

      -- Pengaturan POS (pajak, split, ambang stok rendah).
      CREATE TABLE IF NOT EXISTS ops_settings (
        company_id uuid PRIMARY KEY,
        tax_rate numeric NOT NULL DEFAULT 0,
        tax_enabled boolean NOT NULL DEFAULT false,
        split_payment_enabled boolean NOT NULL DEFAULT true,
        low_stock_threshold integer NOT NULL DEFAULT 5,
        store_name text,
        updated_at timestamptz NOT NULL DEFAULT now()
      );

      -- Pelanggan / member (tier + diskon member).
      CREATE TABLE IF NOT EXISTS ops_customers (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        name text NOT NULL,
        phone text,
        tier text NOT NULL DEFAULT 'regular',
        discount_percent numeric NOT NULL DEFAULT 0,
        points integer NOT NULL DEFAULT 0,
        active boolean NOT NULL DEFAULT true,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_customers_company ON ops_customers(company_id, name);

      -- Varian produk.
      CREATE TABLE IF NOT EXISTS ops_product_variants (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        product_id uuid NOT NULL REFERENCES ops_products(id) ON DELETE CASCADE,
        name text NOT NULL,
        price numeric NOT NULL DEFAULT 0,
        stock integer NOT NULL DEFAULT 0,
        sku text,
        active boolean NOT NULL DEFAULT true
      );
      CREATE INDEX IF NOT EXISTS idx_ops_variants_product ON ops_product_variants(product_id);

      -- Pesanan ditahan (hold order).
      CREATE TABLE IF NOT EXISTS ops_pos_holds (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        cashier_id uuid,
        cashier_name text,
        label text,
        payload jsonb NOT NULL DEFAULT '{}'::jsonb,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_pos_holds_company ON ops_pos_holds(company_id, created_at DESC);

      -- ===== Migrasi B17: SHIFTING KASIR PROFESIONAL & ANALITIK PENGHASILAN =====
      -- Identitas shift (kode, nomor, label, terminal) + hitung fisik & arsip Z-Report.
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS code text;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS shift_no integer;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS shift_label text;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS terminal text;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS counted_breakdown jsonb;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS variance_note text;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS close_snapshot jsonb;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS closed_by text;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS approved_by text;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS approved_at timestamptz;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS handover_to text;
      ALTER TABLE ops_pos_sessions ADD COLUMN IF NOT EXISTS handover_cash numeric;
      CREATE INDEX IF NOT EXISTS idx_ops_pos_sessions_status ON ops_pos_sessions(company_id, status, opened_at DESC);

      -- Laba kotor per transaksi (HPP dibekukan saat transaksi) + rincian metode bayar.
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS cogs numeric NOT NULL DEFAULT 0;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS payment_methods jsonb;
      -- B20: rincian metode bayar (bank / e-wallet / kartu / no. referensi / pembulatan).
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS payment_detail jsonb;

      -- ===== B21: Bahan baku & resep (stok bahan turun otomatis saat penjualan) =====
      CREATE TABLE IF NOT EXISTS ops_materials (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        name text NOT NULL,
        sku text,
        unit text NOT NULL DEFAULT 'pcs',
        stock numeric NOT NULL DEFAULT 0,
        min_stock numeric NOT NULL DEFAULT 0,
        cost numeric NOT NULL DEFAULT 0,
        supplier text,
        active boolean NOT NULL DEFAULT true,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_materials_company ON ops_materials(company_id, name);

      CREATE TABLE IF NOT EXISTS ops_recipes (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        product_id uuid NOT NULL,
        material_id uuid NOT NULL,
        qty numeric NOT NULL DEFAULT 1,
        note text,
        created_at timestamptz NOT NULL DEFAULT now(),
        UNIQUE (product_id, material_id)
      );
      CREATE INDEX IF NOT EXISTS idx_ops_recipes_product ON ops_recipes(company_id, product_id);
      CREATE INDEX IF NOT EXISTS idx_ops_recipes_material ON ops_recipes(company_id, material_id);

      CREATE TABLE IF NOT EXISTS ops_material_moves (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        material_id uuid NOT NULL,
        kind text NOT NULL,
        qty numeric NOT NULL DEFAULT 0,
        cost numeric NOT NULL DEFAULT 0,
        ref_type text,
        ref_id uuid,
        ref_code text,
        note text,
        actor_name text,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_material_moves ON ops_material_moves(company_id, material_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_ops_material_moves_ref ON ops_material_moves(company_id, ref_id);
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS voided_at timestamptz;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS void_reason text;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS void_by text;
      ALTER TABLE ops_pos_sale_items ADD COLUMN IF NOT EXISTS cost numeric NOT NULL DEFAULT 0;
      -- B21: pemakaian bahan baku per baris penjualan (jejak audit resep).
      ALTER TABLE ops_pos_sale_items ADD COLUMN IF NOT EXISTS recipe_usage jsonb;
      CREATE INDEX IF NOT EXISTS idx_ops_sales_status ON ops_pos_sales(company_id, status, created_at DESC);

      -- Buku kas shift: kas masuk / kas keluar (setoran, beli perlengkapan, dll).
      CREATE TABLE IF NOT EXISTS ops_pos_cash_movements (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        session_id uuid NOT NULL REFERENCES ops_pos_sessions(id) ON DELETE CASCADE,
        kind text NOT NULL DEFAULT 'IN',
        amount numeric NOT NULL DEFAULT 0,
        reason text,
        ref text,
        actor_id uuid,
        actor_name text,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_pos_cash_mv_session ON ops_pos_cash_movements(session_id, created_at);
      CREATE INDEX IF NOT EXISTS idx_ops_pos_cash_mv_company ON ops_pos_cash_movements(company_id, created_at DESC);

      -- Pengaturan shifting & target penghasilan + identitas struk.
      ALTER TABLE ops_settings ADD COLUMN IF NOT EXISTS daily_target numeric NOT NULL DEFAULT 0;
      ALTER TABLE ops_settings ADD COLUMN IF NOT EXISTS variance_tolerance numeric NOT NULL DEFAULT 0;
      ALTER TABLE ops_settings ADD COLUMN IF NOT EXISTS require_variance_approval boolean NOT NULL DEFAULT false;
      ALTER TABLE ops_settings ADD COLUMN IF NOT EXISTS blind_close boolean NOT NULL DEFAULT true;
      ALTER TABLE ops_settings ADD COLUMN IF NOT EXISTS receipt_footer text;
      ALTER TABLE ops_settings ADD COLUMN IF NOT EXISTS store_address text;
      ALTER TABLE ops_settings ADD COLUMN IF NOT EXISTS store_phone text;

      -- ===== B30: PEMBAYARAN TEMPO / HUTANG (PIUTANG PELANGGAN) =====
      -- Nota yang dibayar tempo dicatat sebagai piutang, dapat dicicil, dan
      -- diselesaikan (lunas) dari kasir. Terhubung ke pelanggan & nota penjualan.
      CREATE TABLE IF NOT EXISTS ops_receivables (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        sale_id uuid,
        code text,
        customer_id uuid,
        customer_name text NOT NULL,
        customer_phone text,
        total numeric NOT NULL DEFAULT 0,
        paid_amount numeric NOT NULL DEFAULT 0,
        due_date date,
        status text NOT NULL DEFAULT 'UNPAID',
        note text,
        created_by text,
        settled_at timestamptz,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_receivables_company ON ops_receivables(company_id, status, due_date);
      CREATE INDEX IF NOT EXISTS idx_ops_receivables_customer ON ops_receivables(company_id, customer_id);

      CREATE TABLE IF NOT EXISTS ops_receivable_payments (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL,
        receivable_id uuid NOT NULL REFERENCES ops_receivables(id) ON DELETE CASCADE,
        amount numeric NOT NULL DEFAULT 0,
        method text NOT NULL DEFAULT 'CASH',
        note text,
        actor_name text,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ops_recv_pay_recv ON ops_receivable_payments(receivable_id, created_at);
      -- Penanda tempo pada nota penjualan (jatuh tempo + uang muka).
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS due_date date;
      ALTER TABLE ops_pos_sales ADD COLUMN IF NOT EXISTS down_payment numeric NOT NULL DEFAULT 0;
    `);
  }
  return opsReady;
}

/** Himpunan role milik seorang karyawan (UPPERCASE). */
export async function employeeRolesOf(pool: Pool, employeeId: string): Promise<Set<string>> {
  try {
    const rows = (await pool.query(`SELECT role FROM employee_roles WHERE employee_id=$1`, [employeeId])).rows;
    return new Set(rows.map((r: any) => String(r.role || '').toUpperCase()));
  } catch {
    return new Set();
  }
}

/**
 * Middleware: batasi akses ke karyawan yang memiliki SALAH SATU role tertentu
 * (jabatan rangkap otomatis lolos bila punya salah satu role yang diminta).
 */
export function requireOpsRole(pool: Pool, ...allowed: string[]) {
  const allowSet = new Set(allowed.map((x) => x.toUpperCase()));
  return async (req: express.Request, res: express.Response, next: express.NextFunction) => {
    try {
      const employeeId = (req as any).user?.employeeId;
      if (!employeeId) return res.status(401).json({ message: 'Sesi tidak valid' });
      await ensureOpsTables(pool);
      const roles = await employeeRolesOf(pool, employeeId);
      const ok = [...allowSet].some((r) => roles.has(r));
      if (!ok) {
        return res.status(403).json({
          message: 'Akses ditolak — fitur ini memerlukan jabatan ' + allowed.join(' / ') + '.',
          needed: allowed,
          roles: [...roles],
        });
      }
      (req as any).employeeRoles = [...roles];
      next();
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  };
}

/** Nomor urut dokumen sederhana: PREFIX-YYYYMMDD-XXXX. */
export function docCode(prefix: string, seq?: number, when: string = isoDateTz()): string {
  const ymd = when.replace(/-/g, '');
  const suffix = seq == null ? randomUUID().replace(/-/g,'') : String(seq).padStart(4, '0');
  return `${prefix}-${ymd}-${suffix}`;
}

/**
 * Pilih middleware otorisasi sesuai jenis token:
 *  - token ADMIN (payload berisi adminId)      -> adminAuth
 *  - token KARYAWAN (payload berisi sub)        -> auth
 * Dipakai pada endpoint yang diakses DARI DUA SISI, mis. "/admin/customers"
 * (panel superadmin memakai token admin) sekaligus "/customers" (kasir memakai
 * token karyawan — sebenarnya path-nya berbeda, tapi untuk amannya).
 *
 * CATATAN PENTING: jangan memakai `auth` untuk route yang khusus admin,
 * karena token admin TIDAK punya klaim karyawan -> akan ditolak 401 dan
 * memicu logout paksa di panel superadmin.
 */
export function pickAuth(
  req: express.Request,
  auth: express.RequestHandler,
  adminAuth: express.RequestHandler,
): express.RequestHandler {
  const header = req.header('authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  try {
    const payload: any = JSON.parse(Buffer.from(token.split('.')[1] || '', 'base64').toString('utf8'));
    if (payload && payload.adminId) return adminAuth;
  } catch { /* token tidak terbaca -> fallback di bawah */ }
  return auth;
}

/**
 * Middleware gabungan: menerima token ADMIN maupun token KARYAWAN.
 * Dipakai untuk route yang punya alias "/admin/..." (panel superadmin) dan
 * path karyawan (kasir). Tanpa ini, token admin ditolak 401 oleh `auth`
 * sehingga panel superadmin ter-logout paksa.
 */
export function dualAuth(
  auth: express.RequestHandler,
  adminAuth: express.RequestHandler,
): express.RequestHandler {
  return (req, res, next) => pickAuth(req, auth, adminAuth)(req, res, next);
}

/**
 * Middleware OPS role yang juga menerima token ADMIN (superadmin).
 * - Token karyawan -> cek jabatan seperti requireOpsRole biasa.
 * - Token admin     -> lolos langsung (admin punya akses penuh).
 */
export function requireOpsRoleOrAdmin(
  auth: express.RequestHandler,
  adminAuth: express.RequestHandler,
  pool: Pool,
  ...allowed: string[]
) {
  const roleGate = requireOpsRole(pool, ...allowed);
  const both = dualAuth(auth, adminAuth);
  return async (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const chosen = pickAuth(req, auth, adminAuth);
    // Token admin -> cukup adminAuth saja.
    if (chosen === adminAuth) return adminAuth(req, res, next);
    // Token karyawan -> verifikasi token lalu cek jabatan.
    (both as any)(req, res, (err?: any) => {
      if (err) return next(err);
      return (roleGate as any)(req, res, next);
    });
  };
}
