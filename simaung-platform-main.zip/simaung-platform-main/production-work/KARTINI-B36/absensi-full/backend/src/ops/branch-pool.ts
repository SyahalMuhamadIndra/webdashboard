import {AsyncLocalStorage} from 'node:async_hooks';
import type {Pool,PoolClient} from 'pg';
export type BranchContext={companyId:string;branchId:string;actorId:string};
export function createBranchPool(owner:Pool){
 const contexts=new AsyncLocalStorage<BranchContext>();
 async function connect(){
  const context=contexts.getStore();if(!context)throw Error('Branch context required');
  const db=await owner.connect();let active=false;
  const configure=async()=>{
   await db.query("SELECT set_config('kartini.company_id',$1,true),set_config('kartini.branch_id',$2,true),set_config('kartini.origin','POS',true)",[context.companyId,context.branchId]);
   await db.query('SET LOCAL search_path=kartini_ops,public');
  };
  const query=async(text:any,values?:any)=>{
   if(typeof text!=='string')throw Error('Unsupported query');
   const command=text.trim().toUpperCase();
   if(command==='BEGIN'){if(active)throw Error('Transaction already active');await db.query('BEGIN');active=true;await configure();return {rows:[],rowCount:0,command:'BEGIN'};}
   if(command==='COMMIT'||command==='ROLLBACK'){const result=await db.query(command);active=false;if(command==='COMMIT'&&result.command!=='COMMIT')throw Error('Transaction did not commit');return result;}
   if(active)return db.query(text,values);
   try{await db.query('BEGIN');active=true;await configure();const result=await db.query(text,values);await db.query('COMMIT');active=false;return result;}
   catch(error){await db.query('ROLLBACK').catch(()=>{});active=false;throw error;}
  };
  return {query,release:()=>{if(active){active=false;void db.query('ROLLBACK').finally(()=>db.release());}else db.release();}};
 }
 const scoped={setupPool:owner,connect,query:async(text:any,values?:any)=>{const db=await connect();try{return await db.query(text,values)}finally{db.release()}}} as unknown as Pool;
 return {pool:scoped,run:<T>(context:BranchContext,work:()=>T)=>contexts.run(context,work)};
}
