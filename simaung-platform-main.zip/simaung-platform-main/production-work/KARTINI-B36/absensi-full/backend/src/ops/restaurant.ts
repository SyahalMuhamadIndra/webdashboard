import type {RequestHandler,Router} from 'express';
import type {Pool, PoolClient} from 'pg';
import {CheckoutError} from './checkout-stock.js';

export const restaurantSchema=`
CREATE TABLE IF NOT EXISTS business_report_branch_units (
 company_id uuid NOT NULL REFERENCES companies(id), branch_id uuid NOT NULL REFERENCES branches(id),
 unit text NOT NULL CHECK (unit IN ('retail','fnb')), PRIMARY KEY(company_id,branch_id));
CREATE TABLE IF NOT EXISTS business_fnb_tickets (
 id uuid PRIMARY KEY, company_id uuid NOT NULL REFERENCES companies(id),
 branch_id uuid NOT NULL REFERENCES branches(id), cashier_id uuid NOT NULL,
 kind text NOT NULL CHECK(kind IN ('DINE_IN','TAKEAWAY')), table_code text,
 items jsonb NOT NULL, status text NOT NULL DEFAULT 'NEW' CHECK(status IN ('NEW','PREPARING','READY','SERVED','CANCELLED')),
 sale_id uuid UNIQUE REFERENCES ops_pos_sales(id), created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 CHECK((kind='DINE_IN' AND table_code IS NOT NULL) OR (kind='TAKEAWAY' AND table_code IS NULL))
);
ALTER TABLE business_fnb_tickets ADD COLUMN IF NOT EXISTS ready_at timestamptz;
ALTER TABLE business_fnb_tickets ADD COLUMN IF NOT EXISTS paid_items jsonb NOT NULL DEFAULT '[]'::jsonb;
CREATE TABLE IF NOT EXISTS business_fnb_ticket_sales (
 sale_id uuid PRIMARY KEY REFERENCES ops_pos_sales(id), ticket_id uuid NOT NULL REFERENCES business_fnb_tickets(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS business_fnb_open_table ON business_fnb_tickets(company_id,branch_id,table_code)
 WHERE sale_id IS NULL AND status<>'CANCELLED' AND table_code IS NOT NULL;
CREATE INDEX IF NOT EXISTS business_fnb_branch_date ON business_fnb_tickets(company_id,branch_id,created_at DESC);`;

type Item={id:string;variantId:string|null;qty:number};
export const restaurantId=(x:unknown):x is string=>typeof x==='string'&&/^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(x);
export function restaurantItems(raw:unknown): Item[]{
 if(!Array.isArray(raw)||raw.length===0||raw.length>100)throw new CheckoutError('Pesanan dapur harus berisi 1–100 baris produk.');
 const merged=new Map<string,Item>();
 for(const item of raw){
  const id=item?.productId??item?.id, variantId=item?.variantId||null, qty=Number(item?.qty);
  if(!restaurantId(id)||(variantId!==null&&!restaurantId(variantId))||!Number.isSafeInteger(qty)||qty<1||qty>999)
   throw new CheckoutError('Produk, varian, atau jumlah pesanan tidak valid.');
  const key=id.toLowerCase()+'|'+(variantId?.toLowerCase()||'');
  const total=qty+(merged.get(key)?.qty||0);
  if(total>999)throw new CheckoutError('Jumlah produk terlalu banyak.');
  merged.set(key,{id:id.toLowerCase(),variantId:variantId?.toLowerCase()??null,qty:total});
 }
 return [...merged].sort(([a],[b])=>a.localeCompare(b)).map(([,v])=>v);
}
const itemKey=(i:Item)=>i.id+'|'+(i.variantId||'');
function quantities(raw:unknown):Map<string,number>{
 return new Map((Array.isArray(raw)&&!raw.length?[]:restaurantItems(raw)).map(i=>[itemKey(i),i.qty]));
}
function remaining(snapshot:any[],paid:unknown){
 const paidQty=quantities(paid);
 return snapshot.map(i=>({...i,qty:i.qty-(paidQty.get(itemKey(i))??0)})).filter(i=>i.qty>0);
}
export async function restaurantCheckout(db:PoolClient,company:string,branch:string,ticket:unknown,items:unknown,allowSplit=false){
 if(!restaurantId(ticket)||!restaurantId(branch))throw new CheckoutError('Pesanan dapur atau cabang tidak valid.');
 const row=(await db.query(`SELECT items,paid_items,status,sale_id FROM business_fnb_tickets
  WHERE id=$1 AND company_id=$2 AND branch_id=$3 FOR UPDATE`,[ticket,company,branch])).rows[0];
 if(!row||row.status==='CANCELLED'||row.sale_id)throw new CheckoutError('Pesanan dapur sudah dibayar, dibatalkan, atau di luar cabang.');
 const selection=restaurantItems(items), balance=quantities(remaining(row.items,row.paid_items));
 if(selection.some(i=>i.qty>(balance.get(itemKey(i))||0)))
   throw new CheckoutError('Isi keranjang berbeda dari sisa tiket dapur. Muat ulang tiket untuk membayar.');
 const complete=selection.length===balance.size&&selection.every(i=>i.qty===balance.get(itemKey(i)));
 if(!complete&&!allowSplit)throw new CheckoutError('Isi keranjang berbeda dari tiket dapur. Gunakan Pisah Tagihan atau muat ulang tiket.');
 const paidQty=quantities(row.paid_items);
 for(const i of selection)paidQty.set(itemKey(i),(paidQty.get(itemKey(i))||0)+i.qty);
 const paid=restaurantItems(row.items).map(i=>({...i,qty:paidQty.get(itemKey(i))??0})).filter(i=>i.qty>0);
 return {ticket,complete,paid};
}
export async function completeRestaurantCheckout(db:PoolClient,state:{ticket:string;complete:boolean;paid:Item[]},saleId:string){
 await db.query('INSERT INTO business_fnb_ticket_sales(sale_id,ticket_id) VALUES ($1,$2)',[saleId,state.ticket]);
 await db.query(`UPDATE business_fnb_tickets SET paid_items=$2,sale_id=$3,updated_at=now() WHERE id=$1`,
   [state.ticket,JSON.stringify(state.paid),state.complete?saleId:null]);
}
export function mountRestaurantPos(router:Router,raw:Pool,cashier:RequestHandler,allowed:RequestHandler){
 let ready:Promise<unknown>|undefined;
 const ensure=()=>ready??=raw.query("SELECT pg_advisory_xact_lock(218761449);"+restaurantSchema).catch(e=>{ready=undefined;throw e;});
 async function scope(req:any){
  await ensure();
  const c=String(req.user.companyId), branch=String(req.opsBranchId||''), actor=String(req.user.employeeId);
  if(!restaurantId(branch))throw new CheckoutError('Pilih outlet terlebih dahulu.');
  const mapped=await raw.query("SELECT 1 FROM business_report_branch_units WHERE company_id=$1 AND branch_id=$2 AND unit='fnb'",[c,branch]);
  if(!mapped.rowCount)throw new CheckoutError('Outlet harus dipetakan ke F&B di Operasional Unit.');
  return {c,branch,actor};
 }
 router.get('/pos/restaurant/tickets',cashier,allowed,async(req,res)=>{
  try{
   const {c,branch}=await scope(req);
   const rows=await raw.query(`SELECT id,kind,table_code,items,paid_items,status,created_at FROM business_fnb_tickets
    WHERE company_id=$1 AND branch_id=$2 AND sale_id IS NULL AND status<>'CANCELLED' ORDER BY created_at DESC LIMIT 100`,[c,branch]);
   res.set('Cache-Control','no-store');res.json({items:rows.rows.map(({paid_items,items,...row})=>({...row,partPaid:Array.isArray(paid_items)&&paid_items.length>0,items:remaining(items,paid_items)}))});
  }catch(e){res.status(e instanceof CheckoutError?e.status:500).json({message:e instanceof CheckoutError?e.message:'Antrean belum tersedia.'});}
 });
 router.post('/pos/restaurant/tickets',cashier,allowed,async(req,res)=>{
  try{
   const {c,branch,actor}=await scope(req);
   const b=req.body??{}, kind=b.kind, table=kind==='DINE_IN'?String(b.table??'').trim().toUpperCase():null;
   if(!restaurantId(b.id)||!['DINE_IN','TAKEAWAY'].includes(kind)||(kind==='DINE_IN'&&(!table||!/^[A-Z0-9][A-Z0-9 ._-]{0,19}$/.test(table))))
    throw new CheckoutError('Pilih jenis pesanan dan isi kode meja yang valid.');
   const items=restaurantItems(b.items);
   const products=(await raw.query(`SELECT id,name,sku,price FROM ops_products
    WHERE company_id=$1 AND active=true AND id=ANY($2::uuid[])`,[c,items.map(i=>i.id)])).rows;
   const variants=(await raw.query(`SELECT id,product_id,name,price FROM ops_product_variants
    WHERE active=true AND id=ANY($1::uuid[]) AND product_id=ANY($2::uuid[])`,[items.flatMap(i=>i.variantId?[i.variantId]:[]),items.map(i=>i.id)])).rows;
   const snapshot=items.map(i=>{
    const p=products.find(x=>x.id===i.id),v=i.variantId?variants.find(x=>x.id===i.variantId&&x.product_id===i.id):null;
    if(!p||(i.variantId&&!v))throw new CheckoutError('Produk atau varian tidak tersedia.');
    return {...i,name:v?p.name+' ('+v.name+')':p.name,sku:p.sku||'',price:Number(v?.price??p.price)};
   });
   const written=await raw.query(`INSERT INTO business_fnb_tickets(id,company_id,branch_id,cashier_id,kind,table_code,items)
    VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(id) DO NOTHING RETURNING id`,[b.id,c,branch,actor,kind,table,JSON.stringify(snapshot)]);
   if(!written.rowCount){
    const prior=(await raw.query(`SELECT kind,table_code,items,status,sale_id FROM business_fnb_tickets
      WHERE id=$1 AND company_id=$2 AND branch_id=$3 AND cashier_id=$4`,[b.id,c,branch,actor])).rows[0];
    if(!prior||prior.sale_id||prior.status==='CANCELLED'||prior.kind!==kind||prior.table_code!==table||
      JSON.stringify(restaurantItems(prior.items))!==JSON.stringify(items))throw new CheckoutError('Nomor tiket sudah digunakan. Buka daftar pesanan.');
   }
   res.json({id:b.id});
  }catch(e){
   const unique=(e as {code?:string})?.code==='23505';
   res.status(unique?409:e instanceof CheckoutError?e.status:500).json({message:unique?'Meja masih memiliki tiket terbuka. Lanjutkan tiket tersebut.':e instanceof CheckoutError?e.message:'Tiket belum tersimpan.'});
  }
 });
 router.post('/pos/restaurant/tickets/:id/cancel',cashier,allowed,async(req,res)=>{
  try{
   const {c,branch}=await scope(req);
   if(!restaurantId(req.params.id))throw new CheckoutError('ID tiket tidak valid.');
   const saved=await raw.query(`UPDATE business_fnb_tickets SET status='CANCELLED',updated_at=now()
     WHERE id=$1 AND company_id=$2 AND branch_id=$3 AND sale_id IS NULL AND paid_items='[]'::jsonb AND status='NEW' RETURNING id`,[req.params.id,c,branch]);
   if(!saved.rowCount)throw new CheckoutError('Tiket sudah diproses dapur, dibayar, atau berada di outlet lain.');
   res.json({ok:true});
  }catch(e){res.status(e instanceof CheckoutError?e.status:500).json({message:e instanceof CheckoutError?e.message:'Tiket belum dibatalkan.'});}
 });
}
