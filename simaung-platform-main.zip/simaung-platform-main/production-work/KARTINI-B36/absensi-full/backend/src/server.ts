import { outletBranding } from './outlet-branding.js';
import { createLoginLimit } from './security/login-limit.js';
import { mountBusinessReports } from './business-reports.js';
import { createAccountingReports } from './accounting-reports.js';
import { createEmployeeAuth, createAdminAuth } from './security/auth.js';
import { createReadinessInspector } from './readiness.js';
import { createMaintenance, PostgresMaintenanceStore, maintenanceOwnerAuth, maintenanceOwnerLogin } from './maintenance.js';
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Pool } from 'pg';
import crypto from 'node:crypto';
import { createFaceRouter } from './face/face.js';
import { createOpsRouter } from './ops/index.js';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user: { employeeId: string; companyId: string; deviceId: string };
      admin: { adminId: string; companyId: string; role: string };
    }
  }
}

const app = express();
const port = Number(process.env.PORT ?? 3000);
const jwtSecret = process.env.JWT_SECRET ?? '';
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 5 });
const employeeAuthentication = createEmployeeAuth(pool, jwtSecret);
const adminAuthentication = createAdminAuth(pool, jwtSecret);

const browserOrigins = new Set([
  ...['simaung.com', 'tokokartini.com'].flatMap(domain =>
    ['', 'www.', 'admin.', 'api.', 'pos.', 'report.', 'opname.', 'jurnal.', 'unduh.']
      .map(prefix => 'https://' + prefix + domain)),
  'https://absensiku-apk.vercel.app',
  'https://admin-tokokartini-download.vercel.app',
  'https://kasir-tokokartini-download.vercel.app',
  ...(process.env.CORS_ORIGIN ?? '').split(',').map(value => value.trim())
]);
app.use(cors({
  origin: (origin, callback) => callback(null, !!origin && origin !== '*' && browserOrigins.has(origin)),
  exposedHeaders: ['Content-Disposition', 'X-Kartini-Branch']
}));
app.use(express.json({ limit: '8mb' }));

// Control plane remains reachable while the business API is in maintenance.
const maintenance = createMaintenance({
  store: new PostgresMaintenanceStore(pool),
  authorize: maintenanceOwnerAuth(pool),
  ownerLogin: maintenanceOwnerLogin(pool),
  inspect: createReadinessInspector(pool),
});
app.use(maintenance.router);
app.use(maintenance.gate);
app.use('/api/accounting', createAccountingReports(pool, adminAuthentication));
mountBusinessReports(app, pool, adminAuthentication);


// ==================== PUBLIC API ====================

app.get('/api/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ ok: true, service: 'absensiku-api', time: new Date().toISOString() });
  } catch {
    res.status(503).json({ ok: false, message: 'Database unavailable' });
  }
});

// ==================== KELUHAN / SARAN KARYAWAN ====================
// Keluhan publik tidak memerlukan login. Nama hanya disimpan jika dipilih.
let complaintTableReady: Promise<any> | null = null;
function ensureComplaintTable() {
  if (!complaintTableReady) {
    complaintTableReady = pool.query(`
      CREATE TABLE IF NOT EXISTS complaints (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid,
        category text NOT NULL DEFAULT 'LAINNYA',
        subject text,
        message text NOT NULL,
        status text NOT NULL DEFAULT 'BARU',
        admin_note text,
        handled_by text,
        handled_at timestamptz,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      ALTER TABLE complaints ADD COLUMN IF NOT EXISTS sender_name varchar(120);
      CREATE INDEX IF NOT EXISTS idx_complaints_company_created
        ON complaints (company_id, created_at DESC);
    `).catch((e) => { complaintTableReady = null; throw e; });
  }
  return complaintTableReady;
}

const COMPLAINT_CATEGORIES = ['GAJI', 'JADWAL', 'LINGKUNGAN', 'REKAN_KERJA', 'ATASAN', 'FASILITAS', 'LAINNYA'];
const COMPLAINT_STATUSES = ['BARU', 'DIBACA', 'DITINDAKLANJUTI', 'SELESAI'];

/** Ambil company_id default (perusahaan pertama) untuk keluhan publik. */
async function defaultCompanyId(): Promise<string | null> {
  try {
    const r = await pool.query(`SELECT id FROM companies ORDER BY created_at ASC LIMIT 1`);
    return r.rows[0]?.id ?? null;
  } catch { return null; }
}

// POST publik: pengiriman tanpa mode dianggap anonim (kompatibilitas lama).
app.post('/api/public/complaints', async (req, res) => {
  try {
    await ensureComplaintTable();
    const b = req.body ?? {};
    const message = String(b.message ?? '').trim();
    const subject = String(b.subject ?? '').trim().slice(0, 160) || null;
    let category = String(b.category ?? 'LAINNYA').trim().toUpperCase().replace(/\s+/g, '_');
    if (!COMPLAINT_CATEGORIES.includes(category)) category = 'LAINNYA';
    if (message.length < 5) return res.status(400).json({ message: 'Isi keluhan minimal 5 karakter' });
    if (message.length > 5000) return res.status(400).json({ message: 'Isi keluhan maksimal 5000 karakter' });
    const mode = b.senderMode ?? 'anonymous';
    if (mode !== 'anonymous' && mode !== 'named') return res.status(400).json({ message: 'Pilihan pengirim tidak valid' });
    const senderName = mode === 'named' && typeof b.senderName === 'string' ? b.senderName.trim() : null;
    if (mode === 'named' && (!senderName || senderName.length > 120)) {
      return res.status(400).json({ message: 'Nama pengirim wajib diisi, maksimal 120 karakter' });
    }
    const companyId = await defaultCompanyId();
    await pool.query(
      `INSERT INTO complaints (company_id, category, subject, message, sender_name) VALUES ($1,$2,$3,$4,$5)`,
      [companyId, category, subject, message, senderName]
    );
    // Balasan TANPA data apa pun yang bisa mengidentifikasi pengirim.
    res.json({ ok: true, message: senderName ? 'Keluhan dengan nama terkirim. Terima kasih atas masukannya.' : 'Keluhan terkirim secara anonim. Terima kasih atas masukannya.' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/auth/login', createLoginLimit(pool, jwtSecret, 'employee', 'employeeCode'), async (req, res) => {
  try {
    const employeeCode = String(req.body?.employeeCode ?? '').trim();
    // Kompatibilitas: terima field `password` (baru) maupun `pin` (lama).
    const pin = String(req.body?.password ?? req.body?.pin ?? '');
    const deviceKey = String(req.body?.deviceId ?? '').trim();
    if (!employeeCode || !pin || !deviceKey) return res.status(400).json({ message: 'employeeCode, password, deviceId wajib diisi' });

    const result = await pool.query(
      `SELECT e.id, e.company_id, e.employee_code, e.full_name, e.pin_hash, c.name AS company_name
       FROM employees e JOIN companies c ON c.id = e.company_id
       WHERE e.employee_code = $1 AND e.active = true LIMIT 1`,
      [employeeCode]
    );
    const employee = result.rows[0];
    if (!employee || !(await bcrypt.compare(pin, employee.pin_hash))) return res.status(401).json({ message: 'Kode karyawan atau password salah' });

    await ensureDevToolTables();
    const versionCode = Number(req.body?.versionCode ?? 0) || null;
    const device = await pool.query(
      `INSERT INTO devices (employee_id, device_key, platform, last_login_at, last_seen_at, app_version_code)
       VALUES ($1,$2,'android',now(),now(),$3)
       ON CONFLICT (employee_id, device_key)
       DO UPDATE SET last_login_at = now(), last_seen_at = now(), updated_at = now(), app_version_code = COALESCE($3, devices.app_version_code)
       RETURNING id, revoked_at`,
      [employee.id, deviceKey, versionCode]
    );
    // Perangkat yang dicabut (revoke) oleh developer tidak boleh login kembali.
    if (device.rows[0]?.revoked_at) {
      return res.status(403).json({ message: 'Akses perangkat ini telah dicabut oleh admin. Hubungi pengelola.' });
    }

    const token = jwt.sign({ sub: employee.id, companyId: employee.company_id, deviceId: device.rows[0].id }, jwtSecret, { expiresIn: '30d' });
    res.json({
      token,
      employeeId: employee.id,
      employeeCode: employee.employee_code,
      employeeName: employee.full_name,
      companyId: employee.company_id,
      companyName: employee.company_name
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/me', auth, async (req, res) => {
  try {
    await ensureScheduleTable();
    const row = (await pool.query(
      `SELECT e.id, e.employee_code, e.full_name, e.position, e.phone, e.shift_id, e.photo_base64,
              s.name AS shift_name, s.start_time, s.end_time, c.name AS company_name
       FROM employees e
       JOIN companies c ON c.id = e.company_id
       LEFT JOIN shifts s ON s.id = e.shift_id
       WHERE e.id = $1 LIMIT 1`, [req.user.employeeId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Karyawan tidak ditemukan' });

    // Shift EFEKTIF hari ini (mengikuti jadwal mingguan bila ada, jika tidak shift default).
    const today = isoDateTz();
    const shiftToday = await resolveShiftForDate(req.user.employeeId, today);

    res.json({
      employeeId: row.id,
      employeeCode: row.employee_code,
      fullName: row.full_name,
      companyName: row.company_name,
      position: row.position ?? 'Karyawan',
      phone: row.phone,
      // Shift efektif HARI INI (dipakai layar Absen & Profil).
      shiftName: shiftToday.name ?? row.shift_name,
      shiftStart: shiftToday.startTime ?? toTimeStr(row.start_time) ?? null,
      shiftEnd: shiftToday.endTime ?? toTimeStr(row.end_time) ?? null,
      // Shift default (acuan) + info jadwal hari ini.
      defaultShiftName: row.shift_name ?? null,
      isOffToday: !!shiftToday.off,
      scheduleDate: today,
      leaveQuota: null,
      // Foto profil karyawan (base64 JPEG tanpa prefix) — untuk avatar di layar Profil.
      photoBase64: row.photo_base64 ?? null,
      // Peran karyawan berbasis jabatan (B10) — menentukan modul operasional
      // yang tersedia di aplikasi (mis. Kasir -> POS, Driver -> surat jalan).
      roles: await getEmployeeRoles(req.user.employeeId),
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Simpan FOTO PROFIL karyawan (base64 JPEG tanpa prefix). Body: { photoBase64 }.
// Kirim photoBase64 = "" (kosong) untuk menghapus foto.
app.put('/api/me/photo', auth, async (req, res) => {
  try {
    const raw = req.body?.photoBase64;
    if (raw != null && typeof raw !== 'string') return res.status(400).json({ message: 'photoBase64 harus berupa teks.' });
    const photo = (raw ?? '').trim();
    if (photo.length > 3_000_000) return res.status(413).json({ message: 'Foto terlalu besar. Gunakan ukuran lebih kecil.' });
    await pool.query(`UPDATE employees SET photo_base64 = $1, updated_at = now() WHERE id = $2`, [
      photo === '' ? null : photo,
      req.user.employeeId,
    ]);
    res.json({ ok: true, hasPhoto: photo !== '' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// ==================== GANTI PASSWORD (self-service) ====================
// Karyawan mengganti password sendiri dari tab Profil. Kolom DB tetap
// `pin_hash` (kompatibel mundur); secara UI di aplikasi disebut "Password".
// Aturan: password baru 6-20 karakter, alfanumerik (huruf + angka), berbeda
// dari password lama.
function validateEmployeePassword(pw: string): string | null {
  if (!pw) return 'Password wajib diisi.';
  if (pw.length < 6 || pw.length > 20) return 'Password harus 6-20 karakter.';
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Password harus memuat huruf dan angka.';
  return null;
}

// Password default untuk reset & deteksi (dapat diganti karyawan sendiri).
// Nilai kini DISIMPAN di tabel app_settings (per-company) agar tahan restart /
// cold-start serverless Vercel (sebelumnya variabel memori yang hilang).
const FALLBACK_DEFAULT_PASSWORD = 'abc123456';
let appSettingsReady: Promise<any> | null = null;
function ensureAppSettings() {
  if (!appSettingsReady) {
    appSettingsReady = pool.query(`
      CREATE TABLE IF NOT EXISTS app_settings (
        company_id uuid PRIMARY KEY,
        employee_default_password text NOT NULL DEFAULT 'abc123456',
        updated_at timestamptz NOT NULL DEFAULT now()
      );
    `);
  }
  return appSettingsReady;
}
const _defaultPwCache: { [k: string]: { v: string; t: number } } = {};
async function getEmployeeDefaultPassword(companyId: string): Promise<string> {
  try {
    const c = _defaultPwCache[companyId];
    if (c && Date.now() - c.t < 60000) return c.v;
    await ensureAppSettings();
    const r = await pool.query(`SELECT employee_default_password FROM app_settings WHERE company_id=$1`, [companyId]);
    const v = String(r.rows[0]?.employee_default_password || FALLBACK_DEFAULT_PASSWORD);
    _defaultPwCache[companyId] = { v, t: Date.now() };
    return v;
  } catch {
    return FALLBACK_DEFAULT_PASSWORD;
  }
}
async function setEmployeeDefaultPassword(companyId: string, pw: string): Promise<string> {
  await ensureAppSettings();
  const r = await pool.query(
    `INSERT INTO app_settings (company_id, employee_default_password, updated_at)
     VALUES ($1,$2,now())
     ON CONFLICT (company_id) DO UPDATE SET employee_default_password = EXCLUDED.employee_default_password, updated_at = now()
     RETURNING employee_default_password`,
    [companyId, pw]
  );
  const v = String(r.rows[0]?.employee_default_password || pw);
  _defaultPwCache[companyId] = { v, t: Date.now() };
  return v;
}

// Cek apakah karyawan WAJIB ganti password (masih password default).
// Dipakai app untuk menampilkan reminder halus di Profil.
app.get('/api/me/password-status', auth, async (req, res) => {
  try {
    const row = (await pool.query(`SELECT pin_hash FROM employees WHERE id = $1 LIMIT 1`, [req.user.employeeId])).rows[0];
    if (!row) return res.status(404).json({ message: 'Karyawan tidak ditemukan' });
    const pw = await getEmployeeDefaultPassword(req.user.companyId);
    const isDefault = await bcrypt.compare(pw, row.pin_hash);
    res.json({ isDefault, passwordChanged: !isDefault });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Ganti password sendiri. Body: { currentPassword, newPassword }.
app.put('/api/me/password', auth, async (req, res) => {
  try {
    const current = String(req.body?.currentPassword ?? '');
    const next = String(req.body?.newPassword ?? '');
    if (!current) return res.status(400).json({ message: 'Password saat ini wajib diisi.' });
    const ruleErr = validateEmployeePassword(next);
    if (ruleErr) return res.status(400).json({ message: ruleErr });

    const row = (await pool.query(`SELECT pin_hash FROM employees WHERE id = $1 LIMIT 1`, [req.user.employeeId])).rows[0];
    if (!row) return res.status(404).json({ message: 'Karyawan tidak ditemukan' });

    const ok = await bcrypt.compare(current, row.pin_hash);
    if (!ok) return res.status(401).json({ message: 'Password saat ini salah.' });
    if (await bcrypt.compare(next, row.pin_hash)) return res.status(400).json({ message: 'Password baru harus berbeda dari password lama.' });

    const newHash = await bcrypt.hash(next, 12);
    await pool.query(`UPDATE employees SET pin_hash = $1, updated_at = now() WHERE id = $2`, [newHash, req.user.employeeId]);
    res.json({ ok: true, message: 'Password berhasil diperbarui.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Reset password karyawan oleh ADMIN (superadmin) — kembali ke default atau
// password baru. Body: { password } (opsional; kosong -> default perusahaan).
app.put('/api/admin/employees/:id/reset-password', adminAuth, async (req, res) => {
  try {
    const requested = String(req.body?.password ?? '').trim();
    const password = requested || (await getEmployeeDefaultPassword(req.admin.companyId));
    const ruleErr = validateEmployeePassword(password);
    if (ruleErr) return res.status(400).json({ message: ruleErr });
    const hash = await bcrypt.hash(password, 12);
    const row = (await pool.query(
      `UPDATE employees SET pin_hash = $1, updated_at = now() WHERE id = $2 AND company_id = $3 RETURNING id`,
      [hash, req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Karyawan tidak ditemukan' });
    res.json({ ok: true, message: 'Password karyawan direset.', defaultPassword: requested ? null : password });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/config', auth, async (req, res) => {
  try {
    await ensureCompanySettings();
    await ensureGeoTolerantColumns();
    await ensureOfficeLocations();
    const row = (await pool.query(
      `SELECT c.name AS company_name, c.office_name, c.address, c.office_latitude, c.office_longitude,
              c.office_radius_meters, c.minimum_location_accuracy_meters, c.late_grace_minutes, c.timezone,
              c.gps_drift_tolerance_meters
       FROM companies c WHERE c.id = $1`, [req.user.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Company tidak ditemukan' });
    // Lokasi EFEKTIF untuk karyawan ini (multi lokasi kantor, B64).
    // Prioritas: lokasi yang ditugaskan ke karyawan -> lokasi Default -> kolom lama companies.
    const loc = await resolveEmployeeOfficeLocation(req.user.companyId, req.user.employeeId);
    const officeLat = loc ? loc.latitude : row.office_latitude;
    const officeLng = loc ? loc.longitude : row.office_longitude;
    const officeRadius = loc ? loc.radius_meters : row.office_radius_meters;
    const officeAcc = loc ? loc.minimum_accuracy_meters : row.minimum_location_accuracy_meters;
    // Daftar lokasi kantor perusahaan (untuk klien yang mendukung multi lokasi).
    const locs = (await pool.query(
      `SELECT id, name, address, latitude, longitude, radius_meters, minimum_accuracy_meters, is_default
       FROM office_locations WHERE company_id=$1 ORDER BY is_default DESC, created_at`, [req.user.companyId]
    )).rows.map((l: any) => ({
      id: l.id, name: l.name, address: l.address ?? null,
      latitude: Number(l.latitude), longitude: Number(l.longitude),
      radiusMeters: Math.round(Number(l.radius_meters) || 100),
      minimumLocationAccuracyMeters: Math.round(Number(l.minimum_accuracy_meters) || 80),
      isDefault: !!l.is_default,
    }));
    // Feature flags (Remote Config) — dikirim ke aplikasi agar fitur dapat
    // dinyalakan/dimatikan tanpa perlu merilis APK baru.
    const features = await getFlags(req.user.companyId);
    // Desain aplikasi (B67) — Level 1 (warna/logo/nama) + Level 2 (gambar).
    // Ditentukan per lokasi EFEKTIF karyawan, sehingga tiap cabang bisa
    // berbeda tampilan tanpa update APK.
    let theme: any = null;
    try {
      theme = await resolveBranding(req.user.companyId, loc ? loc.id : null);
      const outlets = (await pool.query(`SELECT b.code,b.name FROM ops_branch_access a
        JOIN branches b ON b.id=a.branch_id AND b.company_id=a.company_id
        WHERE a.company_id=$1 AND a.actor_id=$2 AND b.is_active IS TRUE
        ORDER BY b.code`, [req.user.companyId, req.user.employeeId])).rows;
      const outlet = outlets.length===1 ? outlets[0] : outlets.find(b=>b.name===loc?.name);
      const property = loc?.name==='Mitra Kost' || loc?.name==='River Inn' ? loc.name : null;
      const key = property ?? outlet?.code;
      const name = property==='River Inn' ? 'Puteri River Inn' : property ?? (outlet?.code==='MAIN' ? null : outlet?.name);
      if(key&&name){
        const brand=outletBranding(key,name);
        theme={...theme,...brand,logoBase64:null,logoWhiteUrl:brand.logoUrl,logoWhiteBase64:null,
          surfaceColor:'#FFFFFF',textColor:'#18202C',mutedColor:'#586473'};
      }
    }
    catch (e) { console.error('[config] branding gagal:', e); }
    // B75 — pengaturan PER LOKASI (toleransi telat, zona waktu, drift GPS, akurasi).
    let locSet: any = null;
    try { locSet = await resolveLocationSettings(req.user.companyId, loc ? loc.id : null); }
    catch (e) { console.error('[config] location settings gagal:', e); }
    // B75 — shift HARI INI (mengikuti lokasi kantor karyawan).
    let shiftToday: any = null;
    try { shiftToday = await resolveShiftForDate(req.user.employeeId, isoDateTz()); }
    catch (e) { console.error('[config] shift gagal:', e); }
    const graceEff = locSet ? locSet.lateGraceMinutes : row.late_grace_minutes;
    const tzEff = (locSet && locSet.timezone) || row.timezone;
    const driftEff = locSet ? locSet.gpsDriftToleranceMeters : row.gps_drift_tolerance_meters;
    const accEff = (locSet && locSet.overrides && locSet.overrides.minimumAccuracyMeters) ? locSet.minimumAccuracyMeters : officeAcc;
    res.json({
      companyName: row.company_name,
      officeName: loc ? (loc.name || row.office_name) : row.office_name,
      address: loc ? (loc.address ?? row.address) : row.address,
      officeLatitude: officeLat,
      officeLongitude: officeLng,
      officeRadiusMeters: officeRadius,
      minimumLocationAccuracyMeters: accEff,
      lateGraceMinutes: graceEff,
      timezone: tzEff,
      // Info multi lokasi (B64).
      officeLocationId: loc ? loc.id : null,
      officeLocationName: loc ? loc.name : null,
      officeLocationSource: loc ? loc.source : 'legacy',
      officeLocations: locs,
      // Toleransi drift dikirim dalam bentuk SUDAH DIBATASI (sama seperti yang
      // dipakai saat validasi absensi) supaya aplikasi dan server memakai batas
      // yang PERSIS sama. Tanpa ini, aplikasi bisa menampilkan "di dalam area"
      // padahal server menolak — membingungkan karyawan.
      gpsDriftToleranceMeters: cappedDriftTolerance(officeRadius, driftEff),
      effectiveRadiusMeters: effectiveRadiusOf(officeRadius, driftEff),
      // B75 — shift HARI INI (mengikuti lokasi kantor) supaya aplikasi benar
      // sejak awal, tanpa menunggu permintaan /attendance/today.
      shiftName: shiftToday ? shiftToday.name : null,
      shiftStart: shiftToday ? shiftToday.startTime : null,
      shiftEnd: shiftToday ? shiftToday.endTime : null,
      isOffToday: shiftToday ? !!shiftToday.off : false,
      shiftOfficeLocationId: shiftToday ? shiftToday.officeLocationId : null,
      shiftOfficeLocationName: shiftToday ? shiftToday.officeLocationName : null,
      features,
      // Desain per lokasi (B67). Null bila belum tersedia -> aplikasi memakai
      // palet bawaan. Bentuk lengkap (warna selalu terisi) saat tersedia.
      theme,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/attendance/today', auth, async (req, res) => {
  // Data yang dibalas SELALU berbentuk lengkap. Bila kolom baru (geo_status dll.)
  // ternyata belum ada, kita tetap membalas data dasar — JANGAN 500 — supaya
  // halaman Absen karyawan tidak gagal dan tidak jatuh ke path cadangan (404).
  let rows: any[] = [];
  let shift: any = { name: null, startTime: null, endTime: null, off: false };
  try {
    // B58: rute ini MEMBACA geo_status/verification_status/offline_sync, jadi
    // WAJIB memastikan kolom & tabelnya ada. Tanpa ini, database baru belum
    // punya kolom tersebut -> 500 -> aplikasi jatuh ke path cadangan (404).
    await ensureAttendanceColumnsAll();
    rows = (await pool.query(
      `SELECT type, server_timestamp, client_timestamp, distance_meters, status, geo_status, verification_status, offline_sync
       FROM attendance
       WHERE employee_id = $1
         AND (server_timestamp AT TIME ZONE 'Asia/Jakarta')::date = (now() AT TIME ZONE 'Asia/Jakarta')::date
       ORDER BY server_timestamp ASC`, [req.user.employeeId]
    )).rows;
  } catch (error: any) {
    // Khusus "column ... does not exist": ambil versi minimal TANPA kolom baru.
    if (String(error?.message ?? '').includes('does not exist')) {
      try {
        rows = (await pool.query(
          `SELECT type, server_timestamp, client_timestamp, distance_meters, status
           FROM attendance
           WHERE employee_id = $1
             AND (server_timestamp AT TIME ZONE 'Asia/Jakarta')::date = (now() AT TIME ZONE 'Asia/Jakarta')::date
           ORDER BY server_timestamp ASC`, [req.user.employeeId]
        )).rows;
      } catch { rows = []; }
    } else {
      console.error('[attendance/today] gagal ambil baris:', error);
      rows = [];
    }
  }
  try {
    const checkIn = rows.find((r) => r.type === 'CHECK_IN');
    const checkOut = [...rows].reverse().find((r) => r.type === 'CHECK_OUT');
    const today = isoDateTz();
    shift = await resolveShiftForDate(req.user.employeeId, today);
    // Late minutes dihitung dari WAKTU SCAN (client_timestamp) — bukan waktu
    // server memproses — agar backend yang sempat down tidak membuat telat palsu.
    let lateMinutes = 0;
    if (checkIn && shift.startTime) {
      const grace = await getLateGrace(req.user.companyId);
      const tzOff = await getTzOffset(req.user.companyId);
      const scanAt = new Date(checkIn.client_timestamp ?? checkIn.server_timestamp);
      lateMinutes = computeLateStatusAtOffset(scanAt, shift.startTime, tzOff, grace).lateMinutes;
    }
    res.json({
      checkInAt: checkIn?.server_timestamp?.toISOString?.() ?? null,
      checkOutAt: checkOut?.server_timestamp?.toISOString?.() ?? null,
      checkInDistanceMeters: checkIn?.distance_meters ?? null,
      checkOutDistanceMeters: checkOut?.distance_meters ?? null,
      status: checkIn?.status ?? null,               // APPROVED / ON_TIME / TERLAMBAT
      geoStatus: checkIn?.geo_status ?? null,
      verificationStatus: checkIn?.verification_status ?? null,
      offlineSync: !!checkIn?.offline_sync,
      lateMinutes,
      shiftName: shift.name,
      shiftStart: shift.startTime,
      shiftEnd: shift.endTime,
      isOffToday: !!shift.off,
    });
  } catch (error) {
    // Jaring pengaman terakhir: balas bentuk data yang sama walau ada gangguan,
    // supaya aplikasi karyawan tetap mendapat respons yang bisa dibaca.
    console.error('[attendance/today] error tak terduga:', error);
    res.json({
      checkInAt: null, checkOutAt: null,
      checkInDistanceMeters: null, checkOutDistanceMeters: null,
      status: null, geoStatus: null, verificationStatus: null, offlineSync: false,
      lateMinutes: 0,
      shiftName: null, shiftStart: null, shiftEnd: null, isOffToday: false,
      degraded: true,
    });
  }
});

app.get('/api/attendance/history', auth, async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit ?? 60), 200);
    const rows = (await pool.query(
      `SELECT type, server_timestamp, distance_meters, status, face_detected, face_score
       FROM attendance WHERE employee_id = $1
       ORDER BY server_timestamp DESC LIMIT $2`, [req.user.employeeId, limit]
    )).rows;
    const flat = rows.map((r) => ({
      type: r.type,
      serverTimestamp: r.server_timestamp.toISOString(),
      distanceMeters: r.distance_meters,
      status: r.status,
      faceDetected: r.face_detected,
      faceScore: r.face_score
    }));
    res.json({ items: flat, days: flat, history: flat });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Jadwal mingguan MILIK karyawan (dipakai APK untuk tahu shift mereka).
app.get('/api/schedule', auth, async (req, res) => {
  try {
    await ensureScheduleTable();
    const weekStart = normalizeWeekStart(String(req.query.weekStart ?? ''));
    const weekEnd = addDays(weekStart, 6);
    const emp = (await pool.query(
      `SELECT e.shift_id, (SELECT name FROM shifts WHERE id = e.shift_id) AS def_name,
              (SELECT start_time FROM shifts WHERE id = e.shift_id) AS def_start,
              (SELECT end_time FROM shifts WHERE id = e.shift_id) AS def_end,
              e.office_location_id, ol.name AS office_name
       FROM employees e LEFT JOIN office_locations ol ON ol.id = e.office_location_id
       WHERE e.id = $1 LIMIT 1`, [req.user.employeeId]
    )).rows[0];
    const rows = (await pool.query(
      `SELECT to_char(sc.date,'YYYY-MM-DD') AS d, sc.note, sc.shift_id, s.name, s.start_time, s.end_time
       FROM employee_schedules sc LEFT JOIN shifts s ON s.id = sc.shift_id
       WHERE sc.employee_id = $1 AND sc.date BETWEEN $2::date AND $3::date`,
      [req.user.employeeId, weekStart, weekEnd]
    )).rows;
    const byDate: Record<string, any> = {};
    for (const r of rows) byDate[r.d] = r;
    const locName = emp?.office_name ?? null;
    const days = [];
    for (let i = 0; i < 7; i++) {
      const d = addDays(weekStart, i);
      const r = byDate[d];
      if (r?.note === 'OFF') {
        days.push({ date: d, off: true, shiftName: 'Libur', startTime: null, endTime: null, officeLocationName: locName });
      } else if (r?.shift_id && r?.name) {
        days.push({ date: d, off: false, shiftName: r.name, startTime: toTimeStr(r.start_time), endTime: toTimeStr(r.end_time), officeLocationName: locName });
      } else if (emp?.def_name) {
        days.push({ date: d, off: false, shiftName: emp.def_name, startTime: toTimeStr(emp.def_start), endTime: toTimeStr(emp.def_end), officeLocationName: locName });
      } else {
        days.push({ date: d, off: false, shiftName: null, startTime: null, endTime: null, officeLocationName: locName });
      }
    }
    res.json({ weekStart, weekEnd, days, officeLocationId: emp?.office_location_id ?? null, officeLocationName: emp?.office_name ?? null });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/attendance', auth, async (req, res) => {
  const employeeId = req.user.employeeId;
  const client = await pool.connect();
  try {
    const type = String(req.body?.type ?? '');
    const latitude = Number(req.body?.latitude);
    const longitude = Number(req.body?.longitude);
    const accuracy = Number(req.body?.accuracyMeters);
    const mockLocation = Boolean(req.body?.mockLocation ?? req.body?.isMockLocation);
    const faceDetected = Boolean(req.body?.faceDetected);
    const livenessPassed = Boolean(req.body?.livenessPassed);
    const faceScore = Number.isFinite(Number(req.body?.faceScore)) ? Number(req.body.faceScore) : 85;
    const clientTs = saneClientTime(req.body?.clientTimestamp);
    const clientTimestamp = clientTs.at;
    const deviceKey = String(req.body?.deviceId ?? '').trim();
    const idempotencyKey = crypto.createHash('sha256').update(JSON.stringify({ employeeId, type, deviceKey, clientTimestamp: clientTimestamp.toISOString() })).digest('hex');

    const offlineSync = Boolean(req.body?.offlineSync ?? req.body?.offline ?? false);
    if (!['CHECK_IN', 'CHECK_OUT'].includes(type)) return res.status(400).json({ message: 'Tipe absensi tidak valid' });
    if (![latitude, longitude].every(Number.isFinite)) return res.status(400).json({ message: 'Lokasi tidak valid' });
    if (mockLocation) return res.status(403).json({ message: 'Lokasi mock terdeteksi' });
    if (!faceDetected || !livenessPassed) return res.status(403).json({ message: 'Scan wajah/liveness belum lolos' });
    // PENTING (perbaikan keluhan karyawan): akurasi GPS buruk TIDAK lagi menolak
    // absensi. Karyawan yang SUDAH berada di kantor sering gagal mendapat fix
    // presisi (di dalam gedung, cuaca, HP murah). Dulu ini berujung 403 →
    // kehadirannya hilang dan ia baru bisa absen saat sinyal bagus = tercatat
    // TERLAMBAT padahal datang tepat waktu. Sekarang absensi TETAP TERCATAT,
    // hanya ditandai (verification_status = NEEDED) untuk ditinjau admin.

    await client.query('BEGIN');
    // Pastikan kolom late_minutes ada (untuk total keterlambatan di laporan).
    await ensureLateColumn();
    await ensureGeoTolerantColumns();
    // Toleransi drift GPS harus ada sebelum dibaca di SELECT companies di bawah.
    await ensureCompanySettings();
    const employee = (await client.query(
      `SELECT e.company_id FROM employees e WHERE e.id = $1 AND e.active = true FOR SHARE`, [employeeId]
    )).rows[0];
    if (!employee) throw new HttpError(404, 'Karyawan tidak aktif');

    // Lokasi kantor EFEKTIF (multi lokasi, B64). Bila karyawan ditugaskan ke
    // sebuah lokasi, geofence memakai lokasi tsb; jika tidak, lokasi Default.
    const tzRow = (await client.query(
      `SELECT gps_drift_tolerance_meters FROM companies WHERE id = $1 FOR SHARE`, [employee.company_id]
    )).rows[0];
    const configuredDrift = tzRow?.gps_drift_tolerance_meters;
    const loc = await resolveEmployeeOfficeLocation(employee.company_id, employeeId);
    if (!loc) throw new HttpError(404, 'Konfigurasi lokasi tidak ditemukan');

    const distance = haversine(latitude, longitude, loc.latitude, loc.longitude);
    // --- Penilaian geografis (TIDAK memblokir absensi, hanya menandai) ---
    // Toleransi drift: GPS di dalam gedung bisa meleset ratusan meter. Selama
    // masih dalam radius + toleransi, absensi dianggap wajar (perlu ditinjau).
    // Toleransi drift = selisih antara radius EFEKTIF dan radius kantor. Radius
    // efektif dibatasi HANYA boleh sedikit lebih besar dari radius kantor
    // (maks +150 m atau 1,5x radius) — supaya setelan yang keliru/terlalu longgar
    // tidak pernah membuat absen bisa dilakukan dari jauh.
    const driftTolerance = cappedDriftTolerance(loc.radius_meters, configuredDrift);
    const effectiveRadius = effectiveRadiusOf(loc.radius_meters, configuredDrift);
    const weakAccuracy = !(accuracy > 0) || accuracy > Number(loc.minimum_accuracy_meters);
    const outsideRadius = distance > Number(loc.radius_meters);
    const geoStatus = !outsideRadius
      ? (weakAccuracy ? 'LOW_ACCURACY' : 'OK')
      : (distance <= effectiveRadius ? 'OUTSIDE_RADIUS' : 'OUTSIDE_RADIUS_FAR');
    // Perlu verifikasi admin bila GPS lemah atau titik di luar radius.
    const verificationStatus = (weakAccuracy || outsideRadius) ? 'NEEDED' : 'NONE';

    // --- KUNCI LOKASI (anti-absen dari jauh) ---
    // Absen yang jelas di luar jangkauan wajar DITOLAK di server. Ini menutup
    // celah "absen bebas dari mana saja": penolakan TIDAK boleh terjadi hanya di
    // perangkat (APK bisa dimodifikasi), jadi server wajib menolak sendiri.
    // Yang masih diterima hanya pergeseran GPS kecil di tepi area kantor, dan
    // absensi itu ditandai `verification_status = 'NEEDED'` untuk ditinjau admin.
    if (Number.isFinite(distance) && distance > effectiveRadius) {
      throw new HttpError(
        403,
        `Di luar jangkauan kantor (${Math.round(distance)} m; batas ${Math.round(effectiveRadius)} m). ` +
        'Lokasi absen hanya boleh di sekitar kantor.'
      );
    }

    const device = (await client.query(
      `SELECT id FROM devices WHERE employee_id = $1 AND device_key = $2`, [employeeId, deviceKey]
    )).rows[0];
    if (!device) throw new HttpError(403, 'Perangkat belum terdaftar');

    const existing = (await client.query(
      `SELECT type FROM attendance WHERE employee_id = $1
         AND (server_timestamp AT TIME ZONE 'Asia/Jakarta')::date = (now() AT TIME ZONE 'Asia/Jakarta')::date
       ORDER BY server_timestamp`, [employeeId]
    )).rows;
    const hasCheckIn = existing.some((r) => r.type === 'CHECK_IN');
    const hasCheckOut = existing.some((r) => r.type === 'CHECK_OUT');
    if (type === 'CHECK_IN' && hasCheckIn) throw new HttpError(409, 'Check-in hari ini sudah ada');
    if (type === 'CHECK_OUT' && !hasCheckIn) throw new HttpError(409, 'Belum ada check-in hari ini');
    if (type === 'CHECK_OUT' && hasCheckOut) throw new HttpError(409, 'Check-out hari ini sudah ada');

    // --- Tentukan status dari JADWAL SHIFT yang diatur superadmin ---
    // CHECK_IN  : ON_TIME atau TERLAMBAT (berdasar jam mulai shift + toleransi 5 menit)
    // CHECK_OUT : APPROVED (biasa)
    let status = 'APPROVED';
    let lateMinutes = 0;
    let shiftName: string | null = null;
    let shiftStart: string | null = null;
    if (type === 'CHECK_IN') {
      const tzOff = await getTzOffset(req.user.companyId);
      // Tanggal kerja mengikuti waktu scan (perangkat), sesuai zona perusahaan.
      const today = isoDateAtOffset(clientTimestamp, tzOff);
      const shift = await resolveShiftForDate(employeeId, today);
      shiftName = shift.name;
      shiftStart = shift.startTime;
      const grace = await getLateGrace(req.user.companyId);
      // Keterlambatan dihitung dari WAKTU SCAN sebenarnya (bukan waktu server).
      const late = computeLateStatusAtOffset(clientTimestamp, shift.startTime, tzOff, grace);
      // Bila server meng-clamp waktu (jam perangkat salah), jangan menuduh telat.
      if (late.status === 'TERLAMBAT' && !clientTs.clamped) {
        status = 'TERLAMBAT';
        lateMinutes = late.lateMinutes;
      }
    }

    const inserted = await client.query(
      `INSERT INTO attendance (
        company_id, employee_id, device_id, type, latitude, longitude, accuracy_meters, distance_meters,
        mock_location, face_detected, liveness_passed, face_match, face_score, client_timestamp, status, late_minutes, idempotency_key,
        geo_status, verification_status, offline_sync
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,false,$12,$13,$14,$15,$16,$17,$18,$19)
       ON CONFLICT (idempotency_key) DO NOTHING
       RETURNING id, type, server_timestamp, distance_meters, status, geo_status, verification_status`,
      [employee.company_id, employeeId, device.id, type, latitude, longitude, accuracy, distance, mockLocation, faceDetected, livenessPassed, faceScore, clientTimestamp, status, lateMinutes, idempotencyKey, geoStatus, verificationStatus, offlineSync]
    );
    await client.query('COMMIT');

    const row = inserted.rows[0];
    if (!row) return res.status(200).json({ attendanceId: idempotencyKey, type, serverTimestamp: new Date().toISOString(), distanceMeters: distance, status: 'APPROVED_DUPLICATE', geoStatus, verificationStatus });
    res.json({
      attendanceId: row.id, type: row.type, serverTimestamp: row.server_timestamp.toISOString(),
      distanceMeters: row.distance_meters, status: row.status,
      lateMinutes, shift: shiftName, shiftStart,
      geoStatus: row.geo_status, verificationStatus: row.verification_status,
      offlineSync,
      // Keterangan siap-tampil untuk aplikasi (agar pesan konsisten di semua klien).
      note: verificationStatus === 'NEEDED'
        ? (outsideRadius
            ? `Tercatat pada ${Math.round(distance)} m dari kantor (toleransi drift ${driftTolerance} m). Menunggu verifikasi admin.`
            : `Tercatat dengan akurasi GPS lemah (±${Math.round(accuracy)} m). Kehadiran Anda tetap sah, menunggu verifikasi admin.`)
        : null,
    });
  } catch (error) {
    await client.query('ROLLBACK');
    if (error instanceof HttpError) return res.status(error.status).json({ message: error.message });
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  } finally {
    client.release();
  }
});

/**
 * POST /api/attendance/sync  — sinkronisasi ANTRIAN OFFLINE (batch).
 *
 * Latar belakang (keluhan karyawan): absensi bergantung pada internet + GPS.
 * Saat sinyal jelek, karyawan tidak bisa absen dan baru berhasil ketika sinyal
 * membaik — akibatnya tercatat TERLAMBAT padahal ia sudah tiba tepat waktu.
 *
 * Solusi: aplikasi menyimpan absensi secara LOKAL beserta WAKTU SCAN ASLI dan
 * lokasi terbaik yang sempat didapat. Begitu ada koneksi (walau hanya sesaat),
 * seluruh antrian dikirim ke endpoint ini. Karena keterlambatan dihitung dari
 * `clientTimestamp` (waktu scan, bukan waktu terkirim), absensi tetap tercatat
 * TEPAT WAKTU.
 *
 * Sifat: idempoten per-item (memakai idempotency_key yang sama seperti
 * POST /api/attendance), sehingga aman dikirim berulang.
 * Body: { items: [ { clientId, type, latitude, longitude, accuracyMeters,
 *                    isMockLocation, faceDetected, livenessPassed, faceScore,
 *                    clientTimestamp, scannedAt? } ] }
 * Balasan: { results: [ { clientId, ok, duplicate?, message?, status?, lateMinutes? } ] }
 */
app.post('/api/attendance/sync', auth, async (req, res) => {
  const employeeId = req.user.employeeId;
  const items: any[] = Array.isArray(req.body?.items) ? req.body.items : [];
  if (!items.length) return res.json({ results: [] });
  // Batasi ukuran batch agar satu request tidak terlalu berat.
  const batch = items.slice(0, 50);
  const results: any[] = [];

  const client = await pool.connect();
  try {
    await ensureLateColumn();
    await ensureGeoTolerantColumns();
    await ensureCompanySettings();

    const employee = (await client.query(
      `SELECT e.company_id FROM employees e WHERE e.id = $1 AND e.active = true`, [employeeId]
    )).rows[0];
    if (!employee) return res.status(404).json({ message: 'Karyawan tidak aktif' });

    const company = (await client.query(
      `SELECT gps_drift_tolerance_meters AS configured_drift
       FROM companies WHERE id = $1`, [employee.company_id]
    )).rows[0];
    if (!company) return res.status(404).json({ message: 'Konfigurasi lokasi tidak ditemukan' });

    // Lokasi kantor EFEKTIF (multi lokasi, B64) — sama seperti POST /api/attendance.
    const loc = await resolveEmployeeOfficeLocation(employee.company_id, employeeId);
    if (!loc) return res.status(404).json({ message: 'Konfigurasi lokasi tidak ditemukan' });
    const configuredDrift = company.configured_drift;

    const tzOff = await getTzOffset(req.user.companyId);
    const grace = await getLateGrace(req.user.companyId);
    const driftTolerance = cappedDriftTolerance(loc.radius_meters, configuredDrift);

    // Proses berurutan & terurut waktu scan, supaya urutan CHECK_IN lalu
    // CHECK_OUT tetap benar dan aturan "sudah check-in" terpenuhi.
    const ordered = [...batch].sort(
      (a, b) => Number(a?.clientTimestamp ?? 0) - Number(b?.clientTimestamp ?? 0)
    );

    for (const item of ordered) {
      const clientId = String(item?.clientId ?? '');
      try {
        const type = String(item?.type ?? '');
        if (!['CHECK_IN', 'CHECK_OUT'].includes(type)) {
          results.push({ clientId, ok: false, message: 'Tipe absensi tidak valid' });
          continue;
        }
        const latitude = Number(item?.latitude);
        const longitude = Number(item?.longitude);
        const accuracy = Number(item?.accuracyMeters);
        if (![latitude, longitude].every(Number.isFinite)) {
          results.push({ clientId, ok: false, message: 'Lokasi tidak valid' });
          continue;
        }
        if (Boolean(item?.isMockLocation ?? item?.mockLocation)) {
          results.push({ clientId, ok: false, message: 'Lokasi mock terdeteksi' });
          continue;
        }
        if (!item?.faceDetected || !item?.livenessPassed) {
          results.push({ clientId, ok: false, message: 'Scan wajah/liveness belum lolos' });
          continue;
        }

        // Waktu scan ASLI: dipakai menghitung keterlambatan. saneClientTime masih
        // dipakai sebagai pengaman (jam perangkat salah / antrian basi).
        const clientTs = saneClientTime(item?.clientTimestamp);
        const clientTimestamp = clientTs.at;
        const deviceKey = String(item?.deviceId ?? req.body?.deviceId ?? '').trim();
        const idempotencyKey = crypto.createHash('sha256')
          .update(JSON.stringify({ employeeId, type, deviceKey, clientTimestamp: clientTimestamp.toISOString() }))
          .digest('hex');

        // Perangkat: daftarkan otomatis (offline-first) agar absensi hasil
        // sinkron tidak tertolak hanya karena perangkat belum terdaftar.
        let deviceId: string | null = null;
        if (deviceKey) {
          const dev = (await client.query(
            `SELECT id FROM devices WHERE employee_id = $1 AND device_key = $2`, [employeeId, deviceKey]
          )).rows[0];
          if (dev) deviceId = dev.id;
          else {
            const ins = (await client.query(
              `INSERT INTO devices (employee_id, device_key) VALUES ($1,$2) ON CONFLICT DO NOTHING RETURNING id`,
              [employeeId, deviceKey]
            )).rows[0];
            deviceId = ins?.id ?? null;
          }
        }

        const distance = haversine(latitude, longitude, loc.latitude, loc.longitude);
        const effectiveRadius = effectiveRadiusOf(loc.radius_meters, configuredDrift);
        const weakAccuracy = !(accuracy > 0) || accuracy > Number(loc.minimum_accuracy_meters);
        const outsideRadius = distance > Number(loc.radius_meters);
        const geoStatus = !outsideRadius
          ? (weakAccuracy ? 'LOW_ACCURACY' : 'OK')
          : (distance <= effectiveRadius ? 'OUTSIDE_RADIUS' : 'OUTSIDE_RADIUS_FAR');
        const verificationStatus = (weakAccuracy || outsideRadius) ? 'NEEDED' : 'NONE';

        // --- KUNCI LOKASI (berlaku juga untuk absensi dari antrian offline) ---
        // Tanpa pemeriksaan ini, antrian offline menjadi celah untuk menyelundupkan
        // absensi dari lokasi mana pun. Absensi yang jelas di luar jangkauan dibuang
        // dan TIDAK dikembalikan ke antrian (karena akan selalu ditolak).
        if (Number.isFinite(distance) && distance > effectiveRadius) {
          results.push({
            clientId,
            ok: false,
            rejectedOutOfRange: true,
            message:
              `Di luar jangkauan kantor (${Math.round(distance)} m; batas ${Math.round(effectiveRadius)} m). ` +
              'Lokasi absen hanya boleh di sekitar kantor.',
          });
          continue;
        }

        // Keterlambatan dari WAKTU SCAN (bukan waktu sinkron).
        let status = 'APPROVED';
        let lateMinutes = 0;
        let shiftName: string | null = null;
        let shiftStart: string | null = null;
        if (type === 'CHECK_IN') {
          const today = isoDateAtOffset(clientTimestamp, tzOff);
          const shift = await resolveShiftForDate(employeeId, today);
          shiftName = shift.name;
          shiftStart = shift.startTime;
          const late = computeLateStatusAtOffset(clientTimestamp, shift.startTime, tzOff, grace);
          if (late.status === 'TERLAMBAT' && !clientTs.clamped) {
            status = 'TERLAMBAT';
            lateMinutes = late.lateMinutes;
          }
        }

        await client.query('BEGIN');
        try {
          const inserted = await client.query(
            `INSERT INTO attendance (
              company_id, employee_id, device_id, type, latitude, longitude, accuracy_meters, distance_meters,
              mock_location, face_detected, liveness_passed, face_match, face_score, client_timestamp, status, late_minutes, idempotency_key,
              geo_status, verification_status, offline_sync
             ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,false,$12,$13,$14,$15,$16,$17,$18,true)
             ON CONFLICT (idempotency_key) DO NOTHING
             RETURNING id, status, late_minutes`,
            [employee.company_id, employeeId, deviceId, type, latitude, longitude, accuracy, distance,
             false, true, true,
             Number.isFinite(Number(item?.faceScore)) ? Number(item.faceScore) : 85,
             clientTimestamp, status, lateMinutes, idempotencyKey, geoStatus, verificationStatus]
          );
          await client.query('COMMIT');
          const row = inserted.rows[0];
          if (!row) {
            results.push({ clientId, ok: true, duplicate: true, message: 'Sudah tercatat sebelumnya' });
          } else {
            results.push({
              clientId, ok: true, status: row.status, lateMinutes: row.late_minutes,
              geoStatus, verificationStatus, offlineSync: true,
              message: verificationStatus === 'NEEDED'
                ? 'Tersinkron. Kehadiran sah, menunggu verifikasi admin (GPS lemah / di luar radius).'
                : 'Tersinkron.',
            });
          }
        } catch (innerErr) {
          await client.query('ROLLBACK');
          throw innerErr;
        }
      } catch (itemErr) {
        const msg = itemErr instanceof HttpError ? itemErr.message : 'Gagal menyimpan item';
        results.push({ clientId, ok: false, message: msg });
      }
    }

    res.json({ results, syncedAt: new Date().toISOString() });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  } finally {
    client.release();
  }
});

app.get('/api/leaves', auth, async (req, res) => {
  try {
    const rows = (await pool.query(
      `SELECT id, category, start_date, end_date, reason, status,
              (attachment_base64 IS NOT NULL) AS has_attachment
       FROM leaves WHERE employee_id = $1 ORDER BY created_at DESC LIMIT 100`,
      [req.user.employeeId]
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, category: r.category, startDate: toDateStr(r.start_date), endDate: toDateStr(r.end_date),
      reason: r.reason, status: r.status, hasAttachment: r.has_attachment
    }));
    res.json({ items, leaves: items });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/leaves', auth, async (req, res) => {
  try {
    const category = String(req.body?.category ?? '').toUpperCase();
    const startDate = String(req.body?.startDate ?? '');
    const endDate = String(req.body?.endDate ?? startDate);
    const reason = req.body?.reason ? String(req.body.reason) : null;
    const attachmentBase64 = req.body?.attachmentBase64 ? String(req.body.attachmentBase64) : null;
    const attachmentType = req.body?.attachmentType ? String(req.body.attachmentType) : null;

    if (!['SAKIT', 'IZIN'].includes(category)) return res.status(400).json({ message: 'Kategori izin tidak valid' });
    if (category === 'SAKIT' && !attachmentBase64) return res.status(400).json({ message: 'Izin sakit wajib melampirkan foto surat/keterangan sakit' });
    if (!startDate) return res.status(400).json({ message: 'Tanggal mulai wajib diisi' });

    const row = (await pool.query(
      `INSERT INTO leaves (company_id, employee_id, category, start_date, end_date, reason, status, attachment_base64, attachment_type)
       VALUES ($1,$2,$3,$4,$5,$6,'PENDING',$7,$8) RETURNING id`,
      [req.user.companyId, req.user.employeeId, category, startDate, endDate, reason, attachmentBase64, attachmentType]
    )).rows[0];
    res.json({ id: row.id, status: 'PENDING', message: 'Pengajuan izin terkirim' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/overtime', auth, async (req, res) => {
  try {
    const rows = (await pool.query(
      `SELECT id, date, start_time, end_time, duration_minutes, reason, status
       FROM overtimes WHERE employee_id = $1 ORDER BY created_at DESC LIMIT 100`,
      [req.user.employeeId]
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, date: toDateStr(r.date), startTime: toTimeStr(r.start_time), endTime: toTimeStr(r.end_time),
      durationMinutes: r.duration_minutes, reason: r.reason, status: r.status
    }));
    res.json({ items, overtimes: items });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/overtime', auth, async (req, res) => {
  try {
    const date = String(req.body?.date ?? '');
    const startTime = String(req.body?.startTime ?? '');
    const endTime = String(req.body?.endTime ?? '');
    const reason = req.body?.reason ? String(req.body.reason) : null;
    if (!date || !startTime || !endTime) return res.status(400).json({ message: 'Tanggal dan jam wajib diisi' });
    const minutes = diffMinutes(startTime, endTime);
    if (minutes <= 0) return res.status(400).json({ message: 'Jam selesai harus setelah jam mulai' });
    const row = (await pool.query(
      `INSERT INTO overtimes (company_id, employee_id, date, start_time, end_time, duration_minutes, reason, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'PENDING') RETURNING id`,
      [req.user.companyId, req.user.employeeId, date, startTime, endTime, minutes, reason]
    )).rows[0];
    res.json({ id: row.id, durationMinutes: minutes, status: 'PENDING', message: 'Pengajuan lembur terkirim' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});


// === PEMBARUAN APLIKASI (server-push) ===

app.get('/api/app/latest', async (req, res) => {
  try {
    await ensureReleaseTable();
    const clientCode = Number(req.query.versionCode ?? 0) || 0;
    const rows = (await pool.query(
      `SELECT version_name, version_code, apk_url, mandatory, notes, created_at
       FROM app_releases WHERE active = true ORDER BY version_code DESC LIMIT 1`
    )).rows;
    const rel = rows[0];
    if (!rel || rel.version_code <= clientCode) return res.json({ updateAvailable: false });
    res.json({
      updateAvailable: true,
      latestVersionName: rel.version_name,
      latestVersionCode: rel.version_code,
      apkUrl: rel.apk_url,
      mandatory: !!rel.mandatory,
      notes: rel.notes,
      publishedAt: rel.created_at?.toISOString?.() ?? null,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/notifications', auth, async (req, res) => {
  try {
    // upsertReadCol dijalankan lewat ensureReadCol() (dipanggil lazily di bawah)
    // agar kolom read_by dapat menampung daftar karyawan yang sudah membaca
    // notifikasi broadcast (employee_id IS NULL).
    await ensureReadCol();
    const rows = (await pool.query(
      `SELECT id, title, body, kind, read, created_at, employee_id, read_by
       FROM notifications
       WHERE company_id = $2::uuid
         AND (
           employee_id = $1::uuid
           OR (employee_id IS NULL AND NOT ($1::text = ANY(COALESCE(read_by, '{}'))))
         )
       ORDER BY created_at DESC LIMIT 50`,
      [req.user.employeeId, req.user.companyId]
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, title: r.title, body: r.body, kind: r.kind, read: r.read,
      createdAt: r.created_at?.toISOString?.() ?? null,
    }));
    res.json({ items, notifications: items });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Tandai SATU notifikasi sudah dibaca/dihapus oleh karyawan ini supaya tidak
// muncul lagi. Untuk notifikasi broadcast (employee_id IS NULL) pencatatan
// memakai array read_by agar tidak mengganggu karyawan lain.
app.post('/api/notifications/:id/read', auth, async (req, res) => {
  try {
    await ensureReadCol();
    const id = String(req.params.id ?? '').trim();
    if (!id) return res.status(400).json({ message: 'id wajib diisi' });
    const r = (await pool.query(
      `UPDATE notifications
         SET read_by = (
              SELECT ARRAY(SELECT DISTINCT unnest(COALESCE(read_by, '{}') || ARRAY[$2::text]))
            )
       WHERE id = $1 AND employee_id IS NULL
       RETURNING id`,
      [id, req.user.employeeId]
    ));
    if (r.rowCount === 0) {
      // Bukan broadcast (personal) -> tandai read bila memang milik karyawan ini.
      await pool.query(
        `UPDATE notifications SET read = true WHERE id = $1 AND employee_id = $2`,
        [id, req.user.employeeId]
      );
    }
    res.json({ ok: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/device-token', auth, async (req, res) => {
  try {
    const token = String(req.body?.token ?? '').trim();
    if (!token) return res.status(400).json({ message: 'token wajib diisi' });
    const platform = String(req.body?.platform ?? 'android');
    await pool.query(
      `INSERT INTO device_tokens (employee_id, token, platform, updated_at)
       VALUES ($1,$2,$3,now())
       ON CONFLICT (token) DO UPDATE SET employee_id = EXCLUDED.employee_id, platform = EXCLUDED.platform, updated_at = now()`,
      [req.user.employeeId, token, platform]
    );
    res.json({ ok: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// === ADMIN ROUTES ===


app.post(['/api/admin/login','/api/admin/business-reports/login'], createLoginLimit(pool, jwtSecret, 'admin', 'email'), async (req, res) => {
  try {
    await ensureAdminApproval(pool);
    const email = String(req.body?.email ?? '').trim().toLowerCase();
    const password = String(req.body?.password ?? '');
    if (!email || !password) return res.status(400).json({ message: 'Email dan password wajib diisi' });
    const row = (await pool.query(
      `SELECT id, company_id, name, email, password_hash, role, active, approved FROM admins WHERE email = $1 LIMIT 1`, [email]
    )).rows[0];
    if (!row || !(await bcrypt.compare(password, row.password_hash))) return res.status(401).json({ message: 'Email atau password salah' });
    // Akun hasil "Daftar" harus disetujui SUPERADMIN dulu sebelum bisa masuk.
    if (row.approved === false) {
      return res.status(403).json({
        message: 'Akun Anda sedang menunggu persetujuan Superadmin. Silakan hubungi admin untuk mengaktifkan.',
        pending: true,
      });
    }
    if (row.active === false) return res.status(403).json({ message: 'Akun dinonaktifkan. Hubungi Superadmin.' });
    if (row.role==='REPORT_USER'&&req.path!=='/api/admin/business-reports/login')
      return res.status(403).json({message:'Akun ini hanya dapat masuk melalui Pusat Laporan.'});
    const token = jwt.sign({ adminId: row.id, companyId: row.company_id, role: row.role }, jwtSecret, { expiresIn: '12h' });
    res.json({ token, name: row.name, email: row.email, role: row.role, companyId: row.company_id });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Registrasi akun admin baru (self-service) — dipakai halaman "Daftar" di
// Jurnal. Akun BARU dibuat dengan peran MANAGER (hak operasional terbatas,
// tanpa fungsi developer/kelola pengguna) dan otomatis tergabung ke company
// yang sama (SATU backend & satu database untuk semua project Kartini).
app.post('/api/admin/register', async (req, res) => {
  try {
    await ensureAdminApproval(pool);
    const name = String(req.body?.name ?? '').trim();
    const email = String(req.body?.email ?? '').trim().toLowerCase();
    const password = String(req.body?.password ?? '');
    if (!name || !email || !password) return res.status(400).json({ message: 'Nama, email, dan kata sandi wajib diisi' });
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ message: 'Format email tidak valid' });
    if (password.length < 6) return res.status(400).json({ message: 'Kata sandi minimal 6 karakter' });

    const dupe = (await pool.query(`SELECT 1 FROM admins WHERE email=$1`, [email])).rowCount;
    if (dupe) return res.status(409).json({ message: 'Email sudah terdaftar. Silakan masuk.' });

    // Semua akun memakai company yang sama (Kartini): satu server backend.
    const company = (await pool.query(`SELECT id FROM companies ORDER BY created_at ASC LIMIT 1`)).rows[0];
    if (!company) return res.status(500).json({ message: 'Perusahaan belum dikonfigurasi.' });

    // Peran default MANAGER; akun PENDING (approved=false) menunggu persetujuan SUPERADMIN.
    const role = 'MANAGER';
    const hash = await bcrypt.hash(password, 12);
    await pool.query(
      `INSERT INTO admins (company_id, name, email, password_hash, role, active, approved)
       VALUES ($1,$2,$3,$4,$5,true,false)`,
      [company.id, name, email, hash, role]
    );
    // Tidak mengembalikan token: akun belum bisa login sampai disetujui.
    res.json({
      pending: true,
      name,
      email,
      role,
      message: 'Pendaftaran berhasil. Akun menunggu persetujuan Superadmin.',
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/admin/me', adminAuth, async (req, res) => {
  try {
    const row = (await pool.query(`SELECT id, name, email, role, company_id FROM admins WHERE id=$1`, [req.admin.adminId])).rows[0];
    if (!row) return res.status(404).json({ message: 'Admin tidak ditemukan' });
    const company = (await pool.query(`SELECT name, office_name FROM companies WHERE id=$1`, [row.company_id])).rows[0];
    res.json({ adminId: row.id, companyId: row.company_id, name: row.name, email: row.email, role: row.role, companyName: company?.name, officeName: company?.office_name });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Tab 1: Lokasi Kantor ---
app.get('/api/admin/company', adminAuth, async (req, res) => {
  try {
    await ensureCompanySettings();
    const row = (await pool.query(
      `SELECT name, office_name, address, phone, office_latitude, office_longitude, office_radius_meters,
              minimum_location_accuracy_meters, late_grace_minutes, timezone, logo_base64, gps_drift_tolerance_meters
       FROM companies WHERE id=$1`, [req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Company tidak ditemukan' });
    // Daftar lokasi kantor (multi lokasi, B64) untuk tab Lokasi Kantor.
    await ensureOfficeLocations();
    await seedDefaultOfficeLocation(req.admin.companyId);
    const locs = (await pool.query(
      `SELECT ol.*, (SELECT count(*) FROM employees e WHERE e.office_location_id = ol.id) AS employee_count
       FROM office_locations ol WHERE ol.company_id=$1 ORDER BY ol.is_default DESC, ol.created_at`, [req.admin.companyId]
    )).rows.map(mapOfficeLocation);
    res.json({
      name: row.name, officeName: row.office_name, address: row.address, phone: row.phone,
      officeLatitude: row.office_latitude, officeLongitude: row.office_longitude,
      officeRadiusMeters: row.office_radius_meters, minimumLocationAccuracyMeters: row.minimum_location_accuracy_meters,
      lateGraceMinutes: row.late_grace_minutes, timezone: row.timezone, logoBase64: row.logo_base64,
      gpsDriftToleranceMeters: row.gps_drift_tolerance_meters,
      officeLocations: locs, locations: locs,
    });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.put('/api/admin/company', adminAuth, async (req, res) => {
  try {
    await ensureCompanySettings();
    const b = req.body ?? {};
    // Logo: null/kosong = jangan ubah (biar tak sengaja terhapus), kecuali
    // klien meminta hapus eksplisit via clearLogo=true.
    const clearLogo = b.clearLogo === true;
    const logoParam = clearLogo ? null : (b.logoBase64 ?? null);
    const row = (await pool.query(
      `UPDATE companies SET
        name = COALESCE($2, name),
        office_name = COALESCE($3, office_name),
        address = COALESCE($4, address),
        phone = COALESCE($5, phone),
        office_latitude = COALESCE($6, office_latitude),
        office_longitude = COALESCE($7, office_longitude),
        office_radius_meters = COALESCE($8, office_radius_meters),
        minimum_location_accuracy_meters = COALESCE($9, minimum_location_accuracy_meters),
        late_grace_minutes = COALESCE($10, late_grace_minutes),
        timezone = COALESCE($11, timezone),
        logo_base64 = CASE WHEN $13::boolean THEN NULL ELSE COALESCE($12, logo_base64) END,
        gps_drift_tolerance_meters = COALESCE($14, gps_drift_tolerance_meters),
        updated_at = now()
       WHERE id = $1
       RETURNING name, office_name, office_latitude, office_longitude, office_radius_meters, minimum_location_accuracy_meters, late_grace_minutes, timezone, logo_base64, gps_drift_tolerance_meters`,
      [req.admin.companyId, b.name ?? null, b.officeName ?? null, b.address ?? null, b.phone ?? null,
       b.officeLatitude ?? null, b.officeLongitude ?? null, b.officeRadiusMeters ?? null, b.minimumLocationAccuracyMeters ?? null,
       (b.lateGraceMinutes === undefined || b.lateGraceMinutes === null) ? null : Math.max(0, Math.round(Number(b.lateGraceMinutes) || 0)),
       b.timezone ?? null, logoParam, clearLogo,
       (b.gpsDriftToleranceMeters === undefined || b.gpsDriftToleranceMeters === null) ? null : Math.max(0, Math.round(Number(b.gpsDriftToleranceMeters) || 0))]
    )).rows[0];
    // Zona waktu/toleransi berubah -> bersihkan cache agar langsung berlaku.
    delete _tzCache[req.admin.companyId];
    delete _graceCache[req.admin.companyId];
    // Sinkronkan lokasi Default (multi lokasi, B64): bila perusahaan belum punya
    // lokasi sama sekali buat dari kolom di atas, dan bila nama/alamat kantor
    // diubah, teruskan ke lokasi Default agar konsisten di seluruh aplikasi.
    try {
      await ensureOfficeLocations();
      await seedDefaultOfficeLocation(req.admin.companyId);
      if (b.officeName != null || b.address != null) {
        await pool.query(
          `UPDATE office_locations SET
             name = COALESCE($3, name),
             address = COALESCE($4, address),
             updated_at = now()
           WHERE company_id=$1 AND is_default=true`,
          [req.admin.companyId, null,
           b.officeName != null ? String(b.officeName) : null,
           b.address != null ? String(b.address) : null]
        );
      }
    } catch (e) { console.error('[company] sync office_locations gagal:', e); }
    res.json({ message: 'Pengaturan perusahaan tersimpan', data: row });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// GET /api/admin/settings — pengaturan umum (B7).
app.get('/api/admin/settings', adminAuth, async (req, res) => {
  try {
    const pw = await getEmployeeDefaultPassword(req.admin.companyId);
    res.json({ employeeDefaultPassword: pw });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// PUT /api/admin/settings — ubah kata sandi default karyawan baru.
// Body: { employeeDefaultPassword }. Diterapkan ke karyawan yang dibuat setelah ini.
app.put('/api/admin/settings', adminAuth, async (req, res) => {
  try {
    const p = String((req.body ?? {}).employeeDefaultPassword ?? '');
    if (p.length < 6) return res.status(400).json({ message: 'Kata sandi minimal 6 karakter' });
    if (p.length > 20) return res.status(400).json({ message: 'Kata sandi maksimal 20 karakter' });
    const saved = await setEmployeeDefaultPassword(req.admin.companyId, p);
    res.json({ ok: true, message: 'Kata sandi default karyawan diperbarui', employeeDefaultPassword: saved });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Tab 2: Karyawan ---
// Peran karyawan berbasis jabatan (B10). Karyawan dapat memiliki BEBERAPA role
// sekaligus (jabatan rangkap). Role menentukan modul operasional yang tersedia.
const EMPLOYEE_ROLE_CATALOG = [
  { key: 'DRIVER', label: 'Driver', desc: 'Tracking perjalanan & surat jalan' },
  { key: 'PRAMUNIAGA', label: 'Pramuniaga', desc: 'Sistem stock opname' },
  { key: 'KEPALA_GUDANG', label: 'Kepala Gudang', desc: 'Opname full & crosscek hasil opname' },
  { key: 'KASIR', label: 'Kasir', desc: 'Sistem POS (kasir)' },
  { key: 'PENJAGA', label: 'Penjaga', desc: 'Jaga lokasi/toko & pantau keamanan' },
];
const EMPLOYEE_ROLE_KEYS = EMPLOYEE_ROLE_CATALOG.map((r) => r.key);
let empRolesReady: Promise<any> | null = null;
function ensureEmployeeRoles() {
  if (!empRolesReady) {
    empRolesReady = pool.query(`
      CREATE TABLE IF NOT EXISTS employee_roles (
        employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
        role text NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now(),
        PRIMARY KEY (employee_id, role)
      );
      CREATE INDEX IF NOT EXISTS idx_employee_roles_emp ON employee_roles (employee_id);
    `);
  }
  return empRolesReady;
}
/** Peta employeeId -> [role] untuk seluruh karyawan satu perusahaan. */
async function employeeRolesMap(companyId: string): Promise<{ [id: string]: string[] }> {
  await ensureEmployeeRoles();
  const rows = (await pool.query(
    `SELECT er.employee_id, er.role FROM employee_roles er
     JOIN employees e ON e.id = er.employee_id WHERE e.company_id=$1`, [companyId]
  )).rows;
  const map: { [id: string]: string[] } = {};
  for (const r of rows) (map[r.employee_id] ||= []).push(r.role);
  return map;
}
/** Normalkan input roles (array) -> hanya key valid, unik. */
function normalizeRoles(input: any): string[] {
  if (!Array.isArray(input)) return [];
  const set = new Set<string>();
  for (const r of input) { const k = String(r || '').toUpperCase(); if (EMPLOYEE_ROLE_KEYS.includes(k)) set.add(k); }
  return [...set];
}
/** Ganti seluruh role seorang karyawan. */
async function setEmployeeRoles(companyId: string, employeeId: string, roles: string[]) {
  await ensureEmployeeRoles();
  await pool.query(`DELETE FROM employee_roles WHERE employee_id=$1`, [employeeId]);
  for (const r of normalizeRoles(roles)) {
    await pool.query(`INSERT INTO employee_roles (employee_id, role) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [employeeId, r]);
  }
}
/** Role milik satu karyawan. */
async function getEmployeeRoles(employeeId: string): Promise<string[]> {
  await ensureEmployeeRoles();
  const rows = (await pool.query(`SELECT role FROM employee_roles WHERE employee_id=$1`, [employeeId])).rows;
  return rows.map((r) => r.role);
}

// Katalog role (untuk UI pemilihan di modal karyawan).
app.get('/api/admin/employee-roles', adminAuth, async (_req, res) => {
  res.json({ items: EMPLOYEE_ROLE_CATALOG, roles: EMPLOYEE_ROLE_CATALOG });
});

// --- Desain APK per lokasi kantor (B67) — Level 1 & 2 ---
/**
 * Palet DEFAULT (sama dengan KartiniColors di APK). Dipakai bila lokasi belum
 * diatur desainnya, sehingga aplikasi selalu punya warna yang aman.
 */
const DEFAULT_THEME = {
  brandName: 'Simaung Corporation',
  displayName: 'Simaung Corporation',
  tagline: 'Absensi Karyawan',
  primaryColor: '#036D19',
  primaryDarkColor: '#0A3D14',
  accentColor: '#F85800',
  bgColor: '#FBF7F1',
  surfaceColor: '#FFFDF9',
  textColor: '#1A1A1A',
  mutedColor: '#6C6C6C',
  logoUrl: null as string | null,
  logoBase64: null as string | null,
  logoWhiteUrl: null as string | null,
  logoWhiteBase64: null as string | null,
  headerImageUrl: null as string | null,
  splashImageUrl: null as string | null,
  loginImageUrl: null as string | null,
};

const HEX_RE = /^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/;
/** Normalisasi warna dari admin: hanya hex yang valid, selain itu null. */
function normHex(v: any): string | null {
  if (v == null) return null;
  const s = String(v).trim();
  if (!s) return null;
  const withHash = s.startsWith('#') ? s : `#${s}`;
  return HEX_RE.test(withHash) ? withHash.toUpperCase() : null;
}
/** URL gambar: hanya http/https (blokir skema aneh). Null bila kosong. */
function normUrl(v: any): string | null {
  if (v == null) return null;
  const s = String(v).trim();
  if (!s) return null;
  if (s.startsWith('data:image/')) return s;   // data URI (dari unggahan admin)
  if (/^https?:\/\//i.test(s)) return s;
  return null;
}
/** Batas ukuran base64 gambar (≈1,4 MB teks) agar payload tetap wajar. */
function normImage(v: any): string | null {
  if (v == null) return null;
  const s = String(v).trim();
  if (!s) return null;
  if (!s.startsWith('data:image/')) return null;
  if (s.length > 1_500_000) return null;
  return s;
}
function strOrNull(v: any, max = 120): string | null {
  if (v == null) return null;
  const s = String(v).trim();
  if (!s) return null;
  return s.slice(0, max);
}

/** Baris app_branding -> objek yang dipakai admin & API config. */
function mapBrandingRow(r: any) {
  if (!r) return null;
  return {
    locationId: r.location_id,
    brandName: r.brand_name ?? null,
    displayName: r.display_name ?? null,
    tagline: r.tagline ?? null,
    primaryColor: r.primary_color ?? null,
    primaryDarkColor: r.primary_dark_color ?? null,
    accentColor: r.accent_color ?? null,
    bgColor: r.bg_color ?? null,
    surfaceColor: r.surface_color ?? null,
    textColor: r.text_color ?? null,
    mutedColor: r.muted_color ?? null,
    logoUrl: r.logo_base64 ? null : (r.logo_url ?? null),
    logoBase64: r.logo_base64 ?? null,
    logoWhiteUrl: r.logo_white_base64 ? null : (r.logo_white_url ?? null),
    logoWhiteBase64: r.logo_white_base64 ?? null,
    headerImageUrl: r.header_image_url ?? null,
    splashImageUrl: r.splash_image_url ?? null,
    loginImageUrl: r.login_image_url ?? null,
    updatedBy: r.updated_by ?? null,
    updatedAt: r.updated_at?.toISOString?.() ?? null,
  };
}

/**
 * Ambil branding untuk satu lokasi. Bila lokasi belum punya baris sendiri,
 * ambil milik lokasi DEFAULT perusahaan; bila itu pun tidak ada -> DEFAULT_THEME.
 * Selalu mengembalikan objek LENGKAP (tidak ada nilai null pada warna),
 * sehingga APK tidak perlu menebak.
 */
async function resolveBranding(companyId: string, locationId: string | null): Promise<any> {
  await ensureOfficeLocations();
  let row: any = null;
  if (locationId) {
    row = (await pool.query(`SELECT * FROM app_branding WHERE location_id=$1`, [locationId])).rows[0] ?? null;
  }
  if (!row) {
    row = (await pool.query(
      `SELECT b.* FROM app_branding b
       JOIN office_locations ol ON ol.id = b.location_id
       WHERE b.company_id=$1 AND ol.is_default=true LIMIT 1`, [companyId]
    )).rows[0] ?? null;
  }
  const m = mapBrandingRow(row) ?? ({} as any);
  return {
    brandName: m.brandName ?? DEFAULT_THEME.brandName,
    displayName: m.displayName ?? m.brandName ?? DEFAULT_THEME.displayName,
    tagline: m.tagline ?? DEFAULT_THEME.tagline,
    primaryColor: m.primaryColor ?? DEFAULT_THEME.primaryColor,
    primaryDarkColor: m.primaryDarkColor ?? DEFAULT_THEME.primaryDarkColor,
    accentColor: m.accentColor ?? DEFAULT_THEME.accentColor,
    bgColor: m.bgColor ?? DEFAULT_THEME.bgColor,
    surfaceColor: m.surfaceColor ?? DEFAULT_THEME.surfaceColor,
    textColor: m.textColor ?? DEFAULT_THEME.textColor,
    mutedColor: m.mutedColor ?? DEFAULT_THEME.mutedColor,
    logoUrl: m.logoUrl ?? null,
    logoBase64: m.logoBase64 ?? null,
    logoWhiteUrl: m.logoWhiteUrl ?? null,
    logoWhiteBase64: m.logoWhiteBase64 ?? null,
    headerImageUrl: m.headerImageUrl ?? null,
    splashImageUrl: m.splashImageUrl ?? null,
    loginImageUrl: m.loginImageUrl ?? null,
  };
}

// GET /api/admin/branding — daftar desain tiap lokasi + default perusahaan.
app.get('/api/admin/branding', adminAuth, async (req, res) => {
  try {
    await ensureOfficeLocations();
    await seedDefaultOfficeLocation(req.admin.companyId);
    const locs = (await pool.query(
      `SELECT id, name, address, is_default FROM office_locations WHERE company_id=$1
       ORDER BY is_default DESC, created_at`, [req.admin.companyId]
    )).rows;
    const rows = (await pool.query(`SELECT * FROM app_branding WHERE company_id=$1`, [req.admin.companyId])).rows;
    const byLoc: Record<string, any> = {};
    for (const r of rows) byLoc[r.location_id] = mapBrandingRow(r);
    const items = locs.map((l) => ({
      locationId: l.id, locationName: l.name, address: l.address ?? null, isDefault: !!l.is_default,
      branding: byLoc[l.id] ?? null,
      effective: null, // diisi di bawah
    }));
    for (const it of items) it.effective = await resolveBranding(req.admin.companyId, it.locationId);
    res.json({ items, locations: items, defaults: DEFAULT_THEME });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// PUT /api/admin/branding/:locationId — simpan desain untuk satu lokasi.
app.put('/api/admin/branding/:locationId', adminAuth, async (req, res) => {
  try {
    await ensureOfficeLocations();
    const loc = (await pool.query(
      `SELECT id FROM office_locations WHERE id=$1 AND company_id=$2`, [req.params.locationId, req.admin.companyId]
    )).rows[0];
    if (!loc) return res.status(404).json({ message: 'Lokasi kantor tidak ditemukan' });
    const b = req.body ?? {};
    const a: any = (req as any).admin ?? {};
    const row = (await pool.query(
      `INSERT INTO app_branding (
         location_id, company_id, brand_name, display_name, tagline,
         primary_color, primary_dark_color, accent_color, bg_color, surface_color, text_color, muted_color,
         logo_url, logo_base64, logo_white_url, logo_white_base64,
         header_image_url, splash_image_url, login_image_url, updated_by, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20, now())
       ON CONFLICT (location_id) DO UPDATE SET
         brand_name = COALESCE(EXCLUDED.brand_name, app_branding.brand_name),
         display_name = COALESCE(EXCLUDED.display_name, app_branding.display_name),
         tagline = COALESCE(EXCLUDED.tagline, app_branding.tagline),
         primary_color = COALESCE(EXCLUDED.primary_color, app_branding.primary_color),
         primary_dark_color = COALESCE(EXCLUDED.primary_dark_color, app_branding.primary_dark_color),
         accent_color = COALESCE(EXCLUDED.accent_color, app_branding.accent_color),
         bg_color = COALESCE(EXCLUDED.bg_color, app_branding.bg_color),
         surface_color = COALESCE(EXCLUDED.surface_color, app_branding.surface_color),
         text_color = COALESCE(EXCLUDED.text_color, app_branding.text_color),
         muted_color = COALESCE(EXCLUDED.muted_color, app_branding.muted_color),
         logo_url = COALESCE(EXCLUDED.logo_url, app_branding.logo_url),
         logo_base64 = COALESCE(EXCLUDED.logo_base64, app_branding.logo_base64),
         logo_white_url = COALESCE(EXCLUDED.logo_white_url, app_branding.logo_white_url),
         logo_white_base64 = COALESCE(EXCLUDED.logo_white_base64, app_branding.logo_white_base64),
         header_image_url = COALESCE(EXCLUDED.header_image_url, app_branding.header_image_url),
         splash_image_url = COALESCE(EXCLUDED.splash_image_url, app_branding.splash_image_url),
         login_image_url = COALESCE(EXCLUDED.login_image_url, app_branding.login_image_url),
         updated_by = EXCLUDED.updated_by,
         updated_at = now()
       RETURNING *`,
      [req.params.locationId, req.admin.companyId,
       strOrNull(b.brandName), strOrNull(b.displayName), strOrNull(b.tagline, 160),
       normHex(b.primaryColor), normHex(b.primaryDarkColor), normHex(b.accentColor),
       normHex(b.bgColor), normHex(b.surfaceColor), normHex(b.textColor), normHex(b.mutedColor),
       normUrl(b.logoUrl), normImage(b.logoBase64), normUrl(b.logoWhiteUrl), normImage(b.logoWhiteBase64),
       normUrl(b.headerImageUrl), normUrl(b.splashImageUrl), normUrl(b.loginImageUrl),
       a.adminName ?? a.email ?? null]
    )).rows[0];
    await audit(req, 'BRANDING_UPDATE', { detail: `lokasi ${req.params.locationId}` });
    res.json({ ok: true, message: 'Desain aplikasi disimpan', data: mapBrandingRow(row) });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// DELETE /api/admin/branding/:locationId/:field — kosongkan satu gambar
// (logo, logoWhite, header, splash, login) tanpa menghapus warna/nama.
app.delete('/api/admin/branding/:locationId/:field', adminAuth, async (req, res) => {
  const COLS: Record<string, [string, string]> = {
    logo: ['logo_url', 'logo_base64'],
    logoWhite: ['logo_white_url', 'logo_white_base64'],
    header: ['header_image_url', 'header_image_url'],
    splash: ['splash_image_url', 'splash_image_url'],
    login: ['login_image_url', 'login_image_url'],
  };
  const cols = COLS[String(req.params.field)];
  if (!cols) return res.status(400).json({ message: 'Field tidak dikenal' });
  try {
    await ensureOfficeLocations();
    const locId = String(req.params.locationId);
    const loc = (await pool.query(
      `SELECT id FROM office_locations WHERE id=$1 AND company_id=$2`, [locId, req.admin.companyId]
    )).rows[0];
    if (!loc) return res.status(404).json({ message: 'Lokasi kantor tidak ditemukan' });
    await pool.query(
      `UPDATE app_branding SET ${cols[0]}=NULL, ${cols[1]}=NULL, updated_at=now() WHERE location_id=$1`,
      [locId]
    );
    await audit(req, 'BRANDING_UPDATE', { detail: `hapus ${req.params.field} lokasi ${req.params.locationId}` });
    res.json({ ok: true, message: 'Gambar dihapus' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// GET /api/admin/branding/:locationId/preview — publik-ish untuk pratinjau
// (memakai adminAuth) — sama dengan `effective` pada endpoint daftar.
app.get('/api/admin/branding/:locationId', adminAuth, async (req, res) => {
  try {
    await ensureOfficeLocations();
    const loc = (await pool.query(
      `SELECT id FROM office_locations WHERE id=$1 AND company_id=$2`, [req.params.locationId, req.admin.companyId]
    )).rows[0];
    if (!loc) return res.status(404).json({ message: 'Lokasi kantor tidak ditemukan' });
    const effective = await resolveBranding(req.admin.companyId, String(req.params.locationId));
    res.json({ locationId: String(req.params.locationId), effective, data: effective });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Multi Lokasi Kantor (B64) ---
function mapOfficeLocation(r: any) {
  return {
    id: r.id, name: r.name, address: r.address ?? null,
    latitude: Number(r.latitude), longitude: Number(r.longitude),
    radiusMeters: Math.round(Number(r.radius_meters) || 100),
    minimumLocationAccuracyMeters: Math.round(Number(r.minimum_accuracy_meters) || 80),
    isDefault: !!r.is_default, active: r.active !== false,
    employeeCount: r.employee_count != null ? Number(r.employee_count) : undefined,
  };
}

// GET /api/admin/office-locations — daftar lokasi kantor perusahaan.
app.get('/api/admin/office-locations', adminAuth, async (req, res) => {
  try {
    await ensureOfficeLocations();
    await seedDefaultOfficeLocation(req.admin.companyId);
    const rows = (await pool.query(
      `SELECT ol.*, (SELECT count(*) FROM employees e WHERE e.office_location_id = ol.id) AS employee_count
       FROM office_locations ol WHERE ol.company_id=$1
       ORDER BY ol.is_default DESC, ol.created_at`, [req.admin.companyId]
    )).rows;
    const items = rows.map(mapOfficeLocation);
    res.json({ items, locations: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// POST /api/admin/office-locations — tambah lokasi baru.
app.post('/api/admin/office-locations', adminAuth, async (req, res) => {
  try {
    await ensureOfficeLocations();
    const b = req.body ?? {};
    const name = String(b.name ?? '').trim();
    const latitude = Number(b.latitude);
    const longitude = Number(b.longitude);
    if (!name) return res.status(400).json({ message: 'Nama lokasi wajib diisi' });
    if (![latitude, longitude].every(Number.isFinite)) return res.status(400).json({ message: 'Koordinat tidak valid' });
    const radius = Math.max(10, Math.round(Number(b.radiusMeters) || 100));
    const acc = Math.max(10, Math.round(Number(b.minimumLocationAccuracyMeters) || 80));
    const makeDefault = b.isDefault === true;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      if (makeDefault) await client.query(`UPDATE office_locations SET is_default=false WHERE company_id=$1`, [req.admin.companyId]);
      const row = (await client.query(
        `INSERT INTO office_locations (company_id, name, address, latitude, longitude, radius_meters, minimum_accuracy_meters, is_default)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
        [req.admin.companyId, name, b.address ?? null, latitude, longitude, radius, acc, makeDefault]
      )).rows[0];
      await client.query('COMMIT');
      res.json({ message: 'Lokasi kantor ditambahkan', data: mapOfficeLocation(row), item: mapOfficeLocation(row) });
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// PUT /api/admin/office-locations/:id — ubah lokasi.
app.put('/api/admin/office-locations/:id', adminAuth, async (req, res) => {
  try {
    await ensureOfficeLocations();
    const b = req.body ?? {};
    const own = (await pool.query(`SELECT id FROM office_locations WHERE id=$1 AND company_id=$2`, [req.params.id, req.admin.companyId])).rows[0];
    if (!own) return res.status(404).json({ message: 'Lokasi tidak ditemukan' });
    const makeDefault = b.isDefault === true;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      if (makeDefault) await client.query(`UPDATE office_locations SET is_default=false WHERE company_id=$1`, [req.admin.companyId]);
      const row = (await client.query(
        `UPDATE office_locations SET
          name = COALESCE($3, name),
          address = COALESCE($4, address),
          latitude = COALESCE($5, latitude),
          longitude = COALESCE($6, longitude),
          radius_meters = COALESCE($7, radius_meters),
          minimum_accuracy_meters = COALESCE($8, minimum_accuracy_meters),
          is_default = CASE WHEN $9::boolean THEN true ELSE is_default END,
          active = COALESCE($10, active),
          updated_at = now()
         WHERE id=$1 AND company_id=$2 RETURNING *`,
        [req.params.id, req.admin.companyId,
         b.name != null ? String(b.name).trim() || null : null,
         b.address != null ? String(b.address) : null,
         Number.isFinite(Number(b.latitude)) ? Number(b.latitude) : null,
         Number.isFinite(Number(b.longitude)) ? Number(b.longitude) : null,
         Number.isFinite(Number(b.radiusMeters)) ? Math.max(10, Math.round(Number(b.radiusMeters))) : null,
         Number.isFinite(Number(b.minimumLocationAccuracyMeters)) ? Math.max(10, Math.round(Number(b.minimumLocationAccuracyMeters))) : null,
         makeDefault,
         typeof b.active === 'boolean' ? b.active : null]
      )).rows[0];
      await client.query('COMMIT');
      res.json({ message: 'Lokasi kantor diperbarui', data: mapOfficeLocation(row), item: mapOfficeLocation(row) });
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// DELETE /api/admin/office-locations/:id — hapus lokasi (minimal satu harus tersisa).
app.delete('/api/admin/office-locations/:id', adminAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    await ensureOfficeLocations();
    await client.query('BEGIN');
    const row = (await client.query(
      `SELECT id, is_default FROM office_locations WHERE id=$1 AND company_id=$2 FOR UPDATE`, [req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) { await client.query('ROLLBACK'); return res.status(404).json({ message: 'Lokasi tidak ditemukan' }); }
    const cnt = (await client.query(`SELECT count(*)::int AS n FROM office_locations WHERE company_id=$1`, [req.admin.companyId])).rows[0].n;
    if (cnt <= 1) { await client.query('ROLLBACK'); return res.status(400).json({ message: 'Minimal harus ada satu lokasi kantor' }); }
    // Karyawan yang memakai lokasi ini dikembalikan ke Default (NULL).
    await client.query(`UPDATE employees SET office_location_id=NULL WHERE office_location_id=$1`, [req.params.id]);
    await client.query(`DELETE FROM office_locations WHERE id=$1`, [req.params.id]);
    // Bila yang dihapus adalah Default, promosikan lokasi lain jadi Default.
    if (row.is_default) {
      await client.query(
        `UPDATE office_locations SET is_default=true WHERE id = (
           SELECT id FROM office_locations WHERE company_id=$1 ORDER BY created_at LIMIT 1
         )`, [req.admin.companyId]
      );
    }
    await client.query('COMMIT');
    res.json({ message: 'Lokasi kantor dihapus' });
  } catch (error) { await client.query('ROLLBACK'); console.error(error); res.status(500).json({ message: 'Server error' }); }
  finally { client.release(); }
});

// PUT /api/admin/employees/:id/office — tetapkan lokasi kantor karyawan.
// Body: { officeLocationId }  (null / kosong = ikuti lokasi Default perusahaan)
app.put('/api/admin/employees/:id/office', adminAuth, async (req, res) => {
  try {
    await ensureOfficeLocations();
    const locId = (req.body ?? {}).officeLocationId ?? null;
    const emp = (await pool.query(`SELECT id FROM employees WHERE id=$1 AND company_id=$2`, [req.params.id, req.admin.companyId])).rows[0];
    if (!emp) return res.status(404).json({ message: 'Karyawan tidak ditemukan' });
    if (locId) {
      const loc = (await pool.query(`SELECT id FROM office_locations WHERE id=$1 AND company_id=$2`, [locId, req.admin.companyId])).rows[0];
      if (!loc) return res.status(400).json({ message: 'Lokasi kantor tidak valid' });
    }
    await pool.query(`UPDATE employees SET office_location_id=$3, updated_at=now() WHERE id=$1 AND company_id=$2`,
      [req.params.id, req.admin.companyId, locId]);
    res.json({ message: 'Lokasi kantor karyawan diperbarui', officeLocationId: locId });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.get('/api/admin/employees', adminAuth, async (req, res) => {
  try {
    await ensureOfficeLocations();
    const rows = (await pool.query(
      `SELECT e.id, e.employee_code, e.full_name, e.position, e.phone, e.active, e.shift_id, e.avatar_color, e.photo_base64,
              e.office_location_id, ol.name AS office_name,
              (SELECT name FROM office_locations WHERE company_id = e.company_id AND is_default=true LIMIT 1) AS default_office_name,
              s.name AS shift_name, s.start_time, s.end_time
       FROM employees e
       LEFT JOIN shifts s ON s.id = e.shift_id
       LEFT JOIN office_locations ol ON ol.id = e.office_location_id
       WHERE e.company_id = $1 ORDER BY e.employee_code`, [req.admin.companyId]
    )).rows;
    const items: any[] = rows.map((r) => ({
      id: r.id, employeeCode: r.employee_code, fullName: r.full_name, position: r.position, phone: r.phone,
      active: r.active, shiftId: r.shift_id, shiftName: r.shift_name, avatarColor: r.avatar_color,
      photoBase64: r.photo_base64 ?? null,
      shiftStart: toTimeStr(r.start_time) || null, shiftEnd: toTimeStr(r.end_time) || null,
      officeLocationId: r.office_location_id ?? null,
      officeName: r.office_name ?? r.default_office_name ?? null,
      officeIsDefault: !r.office_location_id,
    }));
    const roleMap = await employeeRolesMap(req.admin.companyId);
    for (const it of items) it.roles = roleMap[it.id] || [];
    res.json({ items, employees: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/admin/employees', adminAuth, async (req, res) => {
  try {
    const b = req.body ?? {};
    const employeeCode = String(b.employeeCode ?? '').trim();
    const fullName = String(b.fullName ?? '').trim();
    const pin = String(b.pin ?? '');
    if (!employeeCode || !fullName || !pin) return res.status(400).json({ message: 'Kode, nama, dan password wajib diisi' });
    if (!/^(\d{4,6}|(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,20})$/.test(pin)) return res.status(400).json({ message: 'Password harus 6-20 karakter (huruf + angka), atau PIN 4-6 digit.' });

    const dupe = await pool.query(`SELECT 1 FROM employees WHERE company_id=$1 AND employee_code=$2`, [req.admin.companyId, employeeCode]);
    if (dupe.rowCount) return res.status(409).json({ message: 'Kode karyawan sudah dipakai' });

    // Validasi lokasi kantor (bila diberikan) milik perusahaan ini.
    await ensureOfficeLocations();
    let officeLocationId: string | null = null;
    if (b.officeLocationId) {
      const loc = (await pool.query(`SELECT id FROM office_locations WHERE id=$1 AND company_id=$2`, [b.officeLocationId, req.admin.companyId])).rows[0];
      if (loc) officeLocationId = loc.id;
    }

    const pinHash = await bcrypt.hash(pin, 12);
    const color = b.avatarColor ?? pickColor();
    const row = (await pool.query(
      `INSERT INTO employees (company_id, employee_code, full_name, position, phone, pin_hash, shift_id, avatar_color, active, office_location_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,true,$9) RETURNING id`,
      [req.admin.companyId, employeeCode, fullName, b.position ?? 'Karyawan', b.phone ?? null, pinHash, b.shiftId ?? null, color, officeLocationId]
    )).rows[0];
    await setEmployeeRoles(req.admin.companyId, row.id, b.roles ?? []);
    res.json({ id: row.id, message: 'Karyawan ditambahkan' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.put('/api/admin/employees/:id', adminAuth, async (req, res) => {
  try {
    const b = req.body ?? {};
    let pinHash: string | null = null;
    if (b.pin != null && String(b.pin).length > 0) {
      if (!/^(\d{4,6}|(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,20})$/.test(String(b.pin))) return res.status(400).json({ message: 'Password harus 6-20 karakter (huruf + angka), atau PIN 4-6 digit.' });
      pinHash = await bcrypt.hash(String(b.pin), 12);
    }
    const row = (await pool.query(
      `UPDATE employees SET
        full_name = COALESCE($3, full_name),
        position = COALESCE($4, position),
        phone = COALESCE($5, phone),
        active = COALESCE($6, active),
        shift_id = COALESCE($7, shift_id),
        pin_hash = COALESCE($8, pin_hash),
        updated_at = now()
       WHERE id = $1 AND company_id = $2 RETURNING id`,
      [req.params.id, req.admin.companyId, b.fullName ?? null, b.position ?? null, b.phone ?? null,
       typeof b.active === 'boolean' ? b.active : null, b.shiftId ?? null, pinHash]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Karyawan tidak ditemukan' });
    // Lokasi kantor: hanya diubah bila properti dikirim (null = kembali ke Default).
    if (Object.prototype.hasOwnProperty.call(b, 'officeLocationId')) {
      await ensureOfficeLocations();
      let locId: string | null = null;
      if (b.officeLocationId) {
        const loc = (await pool.query(`SELECT id FROM office_locations WHERE id=$1 AND company_id=$2`, [b.officeLocationId, req.admin.companyId])).rows[0];
        if (loc) locId = loc.id;
      }
      await pool.query(`UPDATE employees SET office_location_id=$3, updated_at=now() WHERE id=$1 AND company_id=$2`,
        [req.params.id, req.admin.companyId, locId]);
    }
    if (b.roles !== undefined) await setEmployeeRoles(req.admin.companyId, String(req.params.id), b.roles);
    res.json({ message: 'Data karyawan diperbarui' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.delete('/api/admin/employees/:id', adminAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    // Hard delete: hapus permanen dari database.
    // Query param ?mode=soft untuk perilaku lama (nonaktifkan saja).
    const soft = String(req.query.mode ?? '').toLowerCase() === 'soft';

    await client.query('BEGIN');

    const row = (await client.query(
      `SELECT id, employee_code, full_name FROM employees WHERE id=$1 AND company_id=$2 FOR UPDATE`,
      [req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) {
      await client.query('ROLLBACK');
      return res.status(404).json({ message: 'Karyawan tidak ditemukan' });
    }

    if (soft) {
      await client.query(`UPDATE employees SET active=false, updated_at=now() WHERE id=$1`, [row.id]);
      await client.query('COMMIT');
      return res.json({ message: 'Karyawan dinonaktifkan', soft: true });
    }

    // Hapus data turunan lebih dulu agar tidak gagal karena foreign key
    // (walau sebagian sudah ON DELETE CASCADE, ini menjamin kebersihan data).
    const deleted: Record<string, number> = {};
    for (const table of ['attendance', 'devices', 'leaves', 'overtimes']) {
      try {
        const r = await client.query(`DELETE FROM ${table} WHERE employee_id=$1`, [row.id]);
        deleted[table] = r.rowCount ?? 0;
      } catch (e: any) {
        // Tabel mungkin tidak ada / nama berbeda — lewati saja.
        if (e?.code !== '42P01' && e?.code !== '42703') throw e;
      }
    }
    const delEmp = await client.query(`DELETE FROM employees WHERE id=$1`, [row.id]);
    if (delEmp.rowCount === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ message: 'Karyawan tidak ditemukan' });
    }

    await client.query('COMMIT');
    res.json({ message: 'Karyawan dihapus permanen', hard: true, deleted, employeeCode: row.employee_code, fullName: row.full_name });
  } catch (error) {
    try { await client.query('ROLLBACK'); } catch { /* ignore */ }
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  } finally {
    client.release();
  }
});

// --- Tab 3: Dashboard (absensi harian) ---
app.get('/api/admin/attendance', adminAuth, async (req, res) => {
  try {
    await ensureAttendanceColumnsAll();
    const date = String(req.query.date ?? isoDateTz());
    const rows = (await pool.query(
      `SELECT e.id AS employee_id, e.employee_code, e.full_name, e.position, e.photo_base64,
              MIN(CASE WHEN a.type='CHECK_IN' THEN a.server_timestamp END) AS check_in,
              MIN(CASE WHEN a.type='CHECK_IN' THEN a.client_timestamp END) AS check_in_client,
              MIN(CASE WHEN a.type='CHECK_IN' THEN a.status END) AS in_status,
              MIN(CASE WHEN a.type='CHECK_IN' THEN a.late_minutes END) AS in_late,
              BOOL_OR(CASE WHEN a.type='CHECK_IN' THEN a.late_overridden END) AS in_overridden,
              MAX(CASE WHEN a.type='CHECK_OUT' THEN a.server_timestamp END) AS check_out,
              MAX(CASE WHEN a.type='CHECK_IN' THEN a.distance_meters END) AS in_dist,
              MAX(CASE WHEN a.type='CHECK_OUT' THEN a.distance_meters END) AS out_dist,
              MAX(a.face_score) AS face_score,
              MIN(CASE WHEN a.type='CHECK_IN' THEN a.accuracy_meters END) AS in_accuracy,
              MIN(CASE WHEN a.type='CHECK_IN' THEN a.geo_status END) AS in_geo,
              MIN(CASE WHEN a.type='CHECK_IN' THEN a.verification_status END) AS in_verify,
              BOOL_OR(a.offline_sync) AS any_offline
       FROM employees e
       LEFT JOIN attendance a ON a.employee_id = e.id AND (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date = $2::date
       WHERE e.company_id = $1 AND e.active = true
       GROUP BY e.id, e.employee_code, e.full_name, e.position, e.photo_base64
       ORDER BY e.employee_code`, [req.admin.companyId, date]
    )).rows;
    // Jadwal efektif karyawan pada tanggal ini (shift harian > shift default).
    const schedRows = (await pool.query(
      `SELECT e.id AS employee_id,
              COALESCE(sc.shift_id, e.shift_id) AS shift_id,
              sc.note AS day_note,
              COALESCE(ss.name, ds.name) AS shift_name,
              COALESCE(ss.start_time, ds.start_time) AS start_time,
              COALESCE(ss.end_time, ds.end_time) AS end_time
       FROM employees e
       LEFT JOIN employee_schedules sc ON sc.employee_id = e.id AND sc.date = $2::date
       LEFT JOIN shifts ss ON ss.id = sc.shift_id
       LEFT JOIN shifts ds ON ds.id = e.shift_id
       WHERE e.company_id = $1 AND e.active = true`, [req.admin.companyId, date]
    )).rows;
    const schedByEmp: Record<string, any> = {};
    for (const r of schedRows) schedByEmp[r.employee_id] = r;

    // Lembur pada tanggal ini (agregat per karyawan).
    const otRows = (await pool.query(
      `SELECT o.employee_id,
              COUNT(*) FILTER (WHERE o.status='APPROVED') AS approved_count,
              COALESCE(SUM(o.duration_minutes) FILTER (WHERE o.status='APPROVED'), 0) AS approved_minutes,
              COUNT(*) FILTER (WHERE o.status='PENDING') AS pending_count
       FROM overtimes o JOIN employees e ON e.id = o.employee_id
       WHERE e.company_id = $1 AND o.date = $2::date
       GROUP BY o.employee_id`, [req.admin.companyId, date]
    )).rows;
    const otByEmp: Record<string, any> = {};
    for (const r of otRows) otByEmp[r.employee_id] = r;

    const rosterGrace = await getLateGrace(req.admin.companyId);
    const rosterTzOff = await getTzOffset(req.admin.companyId);
    const items = rows.map((r) => {
      const hasIn = !!r.check_in, hasOut = !!r.check_out;
      const sc = schedByEmp[r.employee_id] || {};
      const startTime = toTimeStr(sc.start_time) || null;
      const isOff = sc.day_note === 'OFF';
      // Hitung keterlambatan dari WAKTU SCAN (client_timestamp bila ada) —
      // bukan waktu server memproses — agar downtime backend tak bikin telat palsu.
      // NAMUN bila admin sudah mengoreksi manual (late_overridden), nilai yang
      // tersimpan dipakai apa adanya agar koreksi tidak tertimpa hitungan ulang.
      let lateMinutes = 0;
      if (hasIn && r.in_overridden) {
        lateMinutes = Number(r.in_late ?? 0) || 0;
      } else if (hasIn && startTime) {
        const scanAt = new Date(r.check_in_client ?? r.check_in);
        lateMinutes = computeLateStatusAtOffset(scanAt, startTime, rosterTzOff, rosterGrace).lateMinutes;
      }
      let status: string;
      if (hasIn && hasOut) status = lateMinutes > 0 ? 'TERLAMBAT' : 'HADIR';
      else if (hasIn) status = lateMinutes > 0 ? 'TERLAMBAT_BELUM_CHECKOUT' : 'BELUM_CHECKOUT';
      else if (isOff) status = 'LIBUR';
      else status = 'ALFA';
      const ot = otByEmp[r.employee_id] || {};
      return {
        employeeId: r.employee_id, employeeCode: r.employee_code, fullName: r.full_name, position: r.position,
        photoBase64: r.photo_base64 ?? null,
        checkInAt: r.check_in ? r.check_in.toISOString() : null,
        checkOutAt: r.check_out ? r.check_out.toISOString() : null,
        checkInDistanceMeters: r.in_dist, checkOutDistanceMeters: r.out_dist,
        faceScore: r.face_score,
        shiftName: sc.shift_name || null, shiftStart: startTime, shiftEnd: toTimeStr(sc.end_time) || null,
        lateMinutes,
        status,
        overtimeApprovedMinutes: Number(ot.approved_minutes ?? 0),
        overtimePendingCount: Number(ot.pending_count ?? 0),
        workMinutes: hasIn && hasOut ? Math.max(0, Math.round((new Date(r.check_out).getTime() - new Date(r.check_in).getTime()) / 60000)) : null
      };
    });
    const summary = {
      date,
      total: items.length,
      hadir: items.filter((i) => i.status === 'HADIR' || i.status === 'BELUM_CHECKOUT').length,
      terlambat: items.filter((i) => i.status.startsWith('TERLAMBAT')).length,
      belumCheckout: items.filter((i) => i.status.endsWith('BELUM_CHECKOUT')).length,
      alfa: items.filter((i) => i.status === 'ALFA').length,
      libur: items.filter((i) => i.status === 'LIBUR').length,
      lemburCount: items.filter((i) => i.overtimeApprovedMinutes > 0 || i.overtimePendingCount > 0).length,
      lemburMenit: items.reduce((a, i) => a + i.overtimeApprovedMinutes, 0),
      lemburPending: items.reduce((a, i) => a + i.overtimePendingCount, 0)
    };
    res.json({ date, summary, items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// ==================== PERBAIKAN DATA ABSENSI (tahan-banting) ====================
// Dua mode perbaikan keterlambatan PALSU (mis. akibat downtime backend / retry):
//   1) Recompute dari WAKTU SCAN perangkat (client_timestamp) — paling akurat.
//   2) Override manual (status/lateMinutes) bila admin tahu jam seharusnya.
// Semua perubahan dicatat ke audit_log dan memerlukan password SUPERADMIN.
async function verifySuperadminPassword(adminId: string, password: string): Promise<boolean> {
  if (!password) return false;
  const row = (await pool.query(`SELECT password_hash FROM admins WHERE id=$1`, [adminId])).rows[0];
  if (!row) return false;
  return bcrypt.compare(password, row.password_hash);
}

// GET /api/admin/attendance/flagged
// Daftar absensi yang PERLU DIVERIFIKASI admin: GPS lemah atau di luar radius
// (termasuk hasil sinkron antrian offline). Endpoint ini melengkapi kebijakan
// baru "absensi tidak boleh gagal karena sinyal" — absensi tetap tercatat,
// admin yang memutuskan sah/tidak.
app.get('/api/admin/attendance/flagged', adminAuth, async (req, res) => {
  try {
    await ensureAttendanceColumnsAll();
    const days = Math.min(90, Math.max(1, Math.round(Number(req.query.days ?? 14) || 14)));
    const limit = Math.min(300, Math.max(1, Math.round(Number(req.query.limit ?? 100) || 100)));
    const rows = (await pool.query(
      `SELECT a.id, a.type, a.status, a.late_minutes, a.distance_meters, a.accuracy_meters,
              a.geo_status, a.verification_status, a.offline_sync,
              a.client_timestamp, a.server_timestamp,
              e.id AS employee_id, e.employee_code, e.full_name, e.position
         FROM attendance a
         JOIN employees e ON e.id = a.employee_id
        WHERE e.company_id = $1
          AND a.verification_status IN ('NEEDED','REJECTED')
          AND a.server_timestamp >= now() - ($2 || ' days')::interval
        ORDER BY a.server_timestamp DESC
        LIMIT $3`, [req.admin.companyId, String(days), limit]
    )).rows;
    res.json({
      items: rows.map((r) => ({
        id: r.id, type: r.type, status: r.status, lateMinutes: r.late_minutes,
        distanceMeters: r.distance_meters, accuracyMeters: r.accuracy_meters,
        geoStatus: r.geo_status, verificationStatus: r.verification_status, offlineSync: r.offline_sync,
        clientTimestamp: r.client_timestamp?.toISOString?.() ?? null,
        serverTimestamp: r.server_timestamp?.toISOString?.() ?? null,
        employeeId: r.employee_id, employeeCode: r.employee_code, fullName: r.full_name, position: r.position,
      })),
      count: rows.length,
      days,
    });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// POST /api/admin/attendance/verify
// Body: { id, action:'approve'|'reject', note?, password? }
// Admin meninjau absensi yang ditandai (GPS lemah / luar radius / hasil offline).
app.post('/api/admin/attendance/verify', adminAuth, async (req, res) => {
  try {
    await ensureAttendanceColumnsAll();
    const b = req.body ?? {};
    const id = String(b.id ?? '');
    const action = String(b.action ?? '').toLowerCase();
    if (!id) return res.status(400).json({ message: 'id wajib' });
    if (!['approve', 'reject'].includes(action)) return res.status(400).json({ message: "action harus 'approve' / 'reject'" });
    const next = action === 'approve' ? 'VERIFIED' : 'REJECTED';
    const upd = await pool.query(
      `UPDATE attendance a SET verification_status = $3
         FROM employees e
        WHERE a.employee_id = e.id AND e.company_id = $1 AND a.id = $2
        RETURNING a.id, a.verification_status, a.type, a.status, a.late_minutes`,
      [req.admin.companyId, id, next]
    );
    const row = upd.rows[0];
    if (!row) return res.status(404).json({ message: 'Data absensi tidak ditemukan' });
    await audit(req, 'ATTENDANCE_VERIFY', {
      target: id,
      detail: `${next}${b.note ? ' — ' + String(b.note).slice(0, 200) : ''}`,
    });
    res.json({ ok: true, id: row.id, verificationStatus: row.verification_status });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// POST /api/admin/attendance/repair
// Body: { employeeId, date, mode:'recompute'|'override', status?, lateMinutes?, password?, all?, days? }
app.post('/api/admin/attendance/repair', adminAuth, async (req, res) => {
  try {
    await ensureAttendanceColumnsAll();
    const b = req.body ?? {};
    const password = String(b.password ?? '');
    if (!(await verifySuperadminPassword(req.admin.adminId, password))) {
      return res.status(403).json({ message: 'Password tidak valid. Aksi ini memerlukan konfirmasi.' });
    }
    const tzOff = await getTzOffset(req.admin.companyId);
    const grace = await getLateGrace(req.admin.companyId);

    // --- Mode 2: override manual ---
    if (String(b.mode ?? '') === 'override') {
      const employeeId = String(b.employeeId ?? '');
      const date = String(b.date ?? '');
      const status = String(b.status ?? '').toUpperCase();
      const lateMinutes = Math.max(0, Math.round(Number(b.lateMinutes ?? 0) || 0));
      if (!employeeId || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return res.status(400).json({ message: 'employeeId & date wajib' });
      if (!['APPROVED', 'ON_TIME', 'TERLAMBAT'].includes(status)) return res.status(400).json({ message: 'status tidak valid' });
      const upd = await pool.query(
        `UPDATE attendance a SET status=$3, late_minutes=$4, late_overridden=true
           FROM employees e
          WHERE a.employee_id = e.id AND e.company_id=$1
            AND a.employee_id=$2 AND a.type='CHECK_IN'
            AND (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date = $5::date`,
        [req.admin.companyId, employeeId, status, lateMinutes, date]
      );
      await audit(req, 'ATTENDANCE_OVERRIDE', { target: employeeId, detail: `Koreksi keterlambatan (${date}) -> ${status} ${lateMinutes}m` });
      return res.json({ ok: true, mode: 'override', updated: upd.rowCount, status, lateMinutes });
    }

    // --- Mode 1: recompute dari waktu scan (default) ---
    let empIds: string[];
    const days = Math.min(Math.max(Number(b.days ?? 60) || 60, 1), 400);
    if (b.all === true) {
      empIds = (await pool.query(`SELECT id FROM employees WHERE company_id=$1 AND active=true`, [req.admin.companyId])).rows.map((r: any) => r.id);
    } else {
      const employeeId = String(b.employeeId ?? '');
      if (!employeeId) return res.status(400).json({ message: 'employeeId atau all=true wajib' });
      empIds = [employeeId];
    }

    let checked = 0;
    let fixed = 0;
    // clearOverrides=true -> hitung ulang SEMUA termasuk yang sudah dikoreksi manual.
    // Default: lewati baris yang ditandai late_overridden agar koreksi admin aman.
    const clearOverrides = b.clearOverrides === true;
    for (const emp of empIds) {
      const rows = (await pool.query(
        `SELECT a.id, a.client_timestamp, a.server_timestamp, a.status, a.late_minutes, a.late_overridden,
                (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date AS day
           FROM attendance a
           JOIN employees e ON e.id = a.employee_id
          WHERE a.employee_id=$1 AND e.company_id=$2 AND a.type='CHECK_IN'
            AND a.server_timestamp >= now() - ($3::int || ' days')::interval
          ORDER BY a.server_timestamp`,
        [emp, req.admin.companyId, days]
      )).rows;
      for (const row of rows) {
        if (b.date && toDateStr(row.day) !== String(b.date)) continue;
        // Hormati koreksi manual kecuali diminta menimpanya.
        if (row.late_overridden && !clearOverrides) { continue; }
        checked++;
        const shift = await resolveShiftForDate(emp, toDateStr(row.day));
        const scanAt = new Date(row.client_timestamp ?? row.server_timestamp);
        const late = computeLateStatusAtOffset(scanAt, shift.startTime, tzOff, grace);
        const newStatus = late.status === 'TERLAMBAT' ? 'TERLAMBAT' : 'APPROVED';
        const newLate = late.lateMinutes;
        if (newStatus !== row.status || Number(row.late_minutes) !== newLate || row.late_overridden) {
          await pool.query(`UPDATE attendance SET status=$2, late_minutes=$3, late_overridden=false WHERE id=$1`, [row.id, newStatus, newLate]);
          fixed++;
        }
      }
    }
    await audit(req, 'ATTENDANCE_REPAIR', { target: b.all ? 'ALL' : String(b.employeeId ?? ''), detail: `Recompute keterlambatan: ${checked} diperiksa, ${fixed} diperbaiki (${days} hari)` });
    res.json({ ok: true, mode: 'recompute', checked, fixed, days });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Tab 4: Laporan per karyawan ---
app.get('/api/admin/report', adminAuth, async (req, res) => {
  try {
    const from = String(req.query.from ?? isoDateTz(new Date(Date.now() - 29 * 864e5)));
    const to = String(req.query.to ?? isoDateTz());
    await ensureLateColumn();
    const rows = (await pool.query(
      `SELECT e.id, e.employee_code, e.full_name, e.position, e.photo_base64,
              COUNT(DISTINCT (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date) FILTER (WHERE a.type='CHECK_IN') AS days_present,
              COUNT(*) FILTER (WHERE a.type='CHECK_IN') AS check_ins,
              AVG(a.distance_meters) FILTER (WHERE a.type='CHECK_IN') AS avg_distance,
              AVG(a.face_score) AS avg_face,
              COALESCE(SUM(a.late_minutes) FILTER (WHERE a.type='CHECK_IN'), 0) AS total_late,
              COUNT(*) FILTER (WHERE a.type='CHECK_IN' AND a.late_minutes > 0) AS late_count
       FROM employees e
       LEFT JOIN attendance a ON a.employee_id = e.id AND (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date BETWEEN $2::date AND $3::date
       WHERE e.company_id = $1 AND e.active = true
       GROUP BY e.id, e.employee_code, e.full_name, e.position, e.photo_base64
       ORDER BY days_present DESC, e.employee_code`, [req.admin.companyId, from, to]
    )).rows;
    // Lembur (disetujui) per karyawan pada rentang tanggal.
    const otRows = (await pool.query(
      `SELECT o.employee_id,
              COUNT(*) FILTER (WHERE o.status='APPROVED') AS approved_count,
              COALESCE(SUM(o.duration_minutes) FILTER (WHERE o.status='APPROVED'), 0) AS approved_minutes,
              COUNT(*) FILTER (WHERE o.status='PENDING') AS pending_count
       FROM overtimes o JOIN employees e ON e.id = o.employee_id
       WHERE e.company_id = $1 AND o.date BETWEEN $2::date AND $3::date
       GROUP BY o.employee_id`, [req.admin.companyId, from, to]
    )).rows;
    const otByEmp: Record<string, any> = {};
    for (const r of otRows) otByEmp[r.employee_id] = r;
    // Izin/cuti per karyawan pada rentang (total hari izin disetujui).
    const leaveRows = (await pool.query(
      `SELECT l.employee_id,
              COALESCE(SUM((l.end_date - l.start_date) + 1) FILTER (WHERE l.status='APPROVED'), 0) AS approved_days,
              COUNT(*) FILTER (WHERE l.status='PENDING') AS pending_count,
              COUNT(*) FILTER (WHERE l.status='APPROVED') AS approved_count
       FROM leaves l JOIN employees e ON e.id = l.employee_id
       WHERE e.company_id = $1 AND l.status <> 'REJECTED'
         AND (l.end_date >= $2::date AND l.start_date <= $3::date)
       GROUP BY l.employee_id`, [req.admin.companyId, from, to]
    )).rows;
    const lvByEmp: Record<string, any> = {};
    for (const r of leaveRows) lvByEmp[r.employee_id] = r;
    const items = rows.map((r) => {
      const ot = otByEmp[r.id] || {};
      const lv = lvByEmp[r.id] || {};
      return {
        employeeId: r.id, employeeCode: r.employee_code, fullName: r.full_name, position: r.position,
        photoBase64: r.photo_base64 ?? null,
        daysPresent: Number(r.days_present), checkIns: Number(r.check_ins),
        avgDistance: r.avg_distance != null ? Math.round(Number(r.avg_distance)) : null,
        avgFaceScore: r.avg_face != null ? Math.round(Number(r.avg_face)) : null,
        overtimeApprovedMinutes: Number(ot.approved_minutes ?? 0),
        overtimeApprovedCount: Number(ot.approved_count ?? 0),
        overtimePendingCount: Number(ot.pending_count ?? 0),
        leaveApprovedDays: Number(lv.approved_days ?? 0),
        leaveApprovedCount: Number(lv.approved_count ?? 0),
        leavePendingCount: Number(lv.pending_count ?? 0),
        totalLateMinutes: Number(r.total_late ?? 0),
        lateCount: Number(r.late_count ?? 0)
      };
    });
    res.json({ from, to, items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Notifikasi realtime: jumlah pengajuan yang menunggu persetujuan ---
app.get('/api/admin/pending-counts', adminAuth, async (req, res) => {
  try {
    await ensureComplaintTable();
    const r = (await pool.query(
      `SELECT
         (SELECT COUNT(*) FROM leaves   WHERE company_id=$1 AND status='PENDING') AS leaves,
         (SELECT COUNT(*) FROM overtimes WHERE company_id=$1 AND status='PENDING') AS overtimes,
         (SELECT COUNT(*) FROM complaints WHERE (company_id=$1 OR company_id IS NULL) AND status='BARU') AS complaints`,
      [req.admin.companyId]
    )).rows[0];
    res.json({
      leaves: Number(r?.leaves ?? 0),
      overtimes: Number(r?.overtimes ?? 0),
      complaints: Number(r?.complaints ?? 0),
      total: Number(r?.leaves ?? 0) + Number(r?.overtimes ?? 0),
      ts: new Date().toISOString(),
    });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// ========================================================================
// B1: DASHBOARD HR — ringkasan operasional harian untuk tim HR/superadmin.
// Menyajikan KPI kehadiran hari ini, jumlah pengajuan yang menunggu, jam
// lembur (menunggu & disetujui), serta TREN 30 hari (hadir/terlambat/alfa).
// Semua perhitungan memakai zona WIB (Asia/Jakarta) seperti tab lain.
// ========================================================================
app.get('/api/admin/hr-dashboard', adminAuth, async (req, res) => {
  try {
    await ensureScheduleTable();
    await ensureLateColumn();
    const company = req.admin.companyId;
    // Dapat menerima ?date=YYYY-MM-DD agar Dashboard (KPI + tren) mengikuti
    // tanggal yang dipilih. Default: hari ini (WIB).
    const qDate = String(req.query.date ?? '');
    const today = /^\d{4}-\d{2}-\d{2}$/.test(qDate) ? qDate : isoDateTz();
    const from30 = addDays(today, -29);

    // 1) Karyawan aktif
    const emp = (await pool.query(
      `SELECT COUNT(*)::int AS total FROM employees WHERE company_id=$1 AND active=true`, [company]
    )).rows[0] || { total: 0 };

    // 2) Kehadiran HARI INI (per karyawan: pakai check-in & check-out terakhir)
    const dayRows = (await pool.query(
      `SELECT a.employee_id,
              MAX(a.type) AS _t,
              (ARRAY_AGG(a.type ORDER BY a.server_timestamp))[1] AS first_type,
              MIN(CASE WHEN a.type='CHECK_IN' THEN a.server_timestamp END) AS check_in,
              MIN(CASE WHEN a.type='CHECK_IN' THEN a.client_timestamp END) AS check_in_client,
              MAX(CASE WHEN a.type='CHECK_OUT' THEN a.server_timestamp END) AS check_out,
              MAX(CASE WHEN a.type='CHECK_IN' THEN a.late_minutes END) AS late_minutes
       FROM attendance a
       WHERE a.company_id=$1 AND (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date = $2::date
       GROUP BY a.employee_id`, [company, today]
    )).rows;
    const presentSet = new Set(dayRows.map((r: any) => r.employee_id));
    const lateRows = dayRows.filter((r: any) => Number(r.late_minutes ?? 0) > 0);
    const totalLateMinutes = lateRows.reduce((a: number, r: any) => a + Number(r.late_minutes ?? 0), 0);

    // 3) Karyawan yang hari ini DIJADWALKAN LIBUR (note 'OFF')
    const offRows = (await pool.query(
      `SELECT COUNT(*)::int AS off FROM employee_schedules sc
       JOIN employees e ON e.id = sc.employee_id
       WHERE e.company_id=$1 AND e.active=true AND sc.date=$2::date AND sc.note='OFF'`,
      [company, today]
    )).rows[0] || { off: 0 };

    const total = Number(emp.total || 0);
    const hadir = presentSet.size;
    const off = Number(offRows.off || 0);
    // Alfa = karyawan aktif yang tidak hadir dan tidak dijadwalkan libur.
    const alfa = Math.max(0, total - hadir - off);

    // 4) Pengajuan menunggu persetujuan
    const pending = (await pool.query(
      `SELECT
         (SELECT COUNT(*)::int FROM leaves   WHERE company_id=$1 AND status='PENDING') AS leaves,
         (SELECT COUNT(*)::int FROM overtimes WHERE company_id=$1 AND status='PENDING') AS overtimes`,
      [company]
    )).rows[0] || { leaves: 0, overtimes: 0 };

    // 5) Lembur: menunggu & disetujui, rentang 30 hari
    const ot = (await pool.query(
      `SELECT
         COALESCE(SUM(duration_minutes) FILTER (WHERE status='APPROVED'),0)::int AS approved_minutes,
         COALESCE(SUM(duration_minutes) FILTER (WHERE status='PENDING'),0)::int  AS pending_minutes,
         COUNT(*) FILTER (WHERE status='APPROVED')::int AS approved_count,
         COUNT(*) FILTER (WHERE status='PENDING')::int  AS pending_count
       FROM overtimes WHERE company_id=$1 AND date BETWEEN $2::date AND $3::date`,
      [company, from30, today]
    )).rows[0] || {};

    // 6) Izin disetujui (hari) 30 hari
    const lv = (await pool.query(
      `SELECT COALESCE(SUM((end_date - start_date) + 1) FILTER (WHERE status='APPROVED'),0)::int AS approved_days
       FROM leaves WHERE company_id=$1 AND end_date >= $2::date AND start_date <= $3::date`,
      [company, from30, today]
    )).rows[0] || {};

    // 7) Tren 30 hari — hadir / terlambat per hari
    const trendRows = (await pool.query(
      `SELECT (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date AS d,
              COUNT(DISTINCT a.employee_id) FILTER (WHERE a.type='CHECK_IN') AS present,
              COUNT(DISTINCT a.employee_id) FILTER (WHERE a.type='CHECK_IN' AND a.late_minutes > 0) AS late
       FROM attendance a
       WHERE a.company_id=$1 AND (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date BETWEEN $2::date AND $3::date
       GROUP BY 1 ORDER BY 1`,
      [company, from30, today]
    )).rows;
    const trendMap: Record<string, any> = {};
    for (const r of trendRows) trendMap[toDateStr(r.d)] = r;
    const trend: any[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = addDays(today, -i);
      const r = trendMap[d];
      const p = Number(r?.present ?? 0);
      const l = Number(r?.late ?? 0);
      trend.push({
        date: d,
        present: p,
        late: l,
        // alfa dihitung kasar: total karyawan - hadir - libur (per hari ini saja akurat)
        absent: Math.max(0, total - p),
      });
    }

    // Rata-rata kehadiran 30 hari (%)
    const sumPresent = trend.reduce((a, x) => a + x.present, 0);
    const avgPresent = total > 0 ? Math.round((sumPresent / (total * 30)) * 100) : 0;

    // 8) Perlu Perhatian: karyawan dengan total menit terlambat TERBANYAK (30 hari)
    const lateAgg = (await pool.query(
      `SELECT e.id AS employee_id, e.employee_code, e.full_name, e.position, e.avatar_color,
              COALESCE(SUM(a.late_minutes) FILTER (WHERE a.type='CHECK_IN'),0)::int AS late_minutes,
              COUNT(*) FILTER (WHERE a.type='CHECK_IN' AND a.late_minutes > 0)::int AS late_count
       FROM employees e
       JOIN attendance a ON a.employee_id = e.id
         AND (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date BETWEEN $2::date AND $3::date
       WHERE e.company_id=$1 AND e.active=true
       GROUP BY e.id, e.employee_code, e.full_name, e.position, e.avatar_color
       HAVING COALESCE(SUM(a.late_minutes) FILTER (WHERE a.type='CHECK_IN'),0) > 0
       ORDER BY late_minutes DESC, e.employee_code LIMIT 5`,
      [company, from30, today]
    )).rows;

    // 9) Pengajuan menunggu terbaru (gabungan izin + lembur) untuk aksi cepat
    const pendLeaves = (await pool.query(
      `SELECT l.id, 'LEAVE' AS kind, l.category, l.start_date AS d1, l.end_date AS d2, l.reason, l.created_at,
              e.full_name, e.employee_code, e.avatar_color
       FROM leaves l JOIN employees e ON e.id = l.employee_id
       WHERE l.company_id=$1 AND l.status='PENDING' ORDER BY l.created_at DESC LIMIT 5`,
      [company]
    )).rows;
    const pendOt = (await pool.query(
      `SELECT o.id, 'OVERTIME' AS kind, o.duration_minutes, o.date AS d1, o.start_time, o.end_time, o.reason, o.created_at,
              e.full_name, e.employee_code, e.avatar_color
       FROM overtimes o JOIN employees e ON e.id = o.employee_id
       WHERE o.company_id=$1 AND o.status='PENDING' ORDER BY o.created_at DESC LIMIT 5`,
      [company]
    )).rows;
    const pendingItems = [
      ...pendLeaves.map((r: any) => ({
        id: r.id, kind: 'LEAVE', fullName: r.full_name, employeeCode: r.employee_code, avatarColor: r.avatar_color,
        label: r.category, startDate: toDateStr(r.d1), endDate: toDateStr(r.d2), reason: r.reason,
        createdAt: r.created_at?.toISOString?.() ?? null,
      })),
      ...pendOt.map((r: any) => ({
        id: r.id, kind: 'OVERTIME', fullName: r.full_name, employeeCode: r.employee_code, avatarColor: r.avatar_color,
        label: `${durLabelBackend(r.duration_minutes)}${r.start_time ? ' • ' + toTimeStr(r.start_time) + '→' + toTimeStr(r.end_time) : ''}`,
        startDate: toDateStr(r.d1), endDate: toDateStr(r.d1), reason: r.reason,
        createdAt: r.created_at?.toISOString?.() ?? null,
      })),
    ].sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))).slice(0, 8);

    const topLate = lateAgg.map((r: any) => ({
      employeeId: r.employee_id, employeeCode: r.employee_code, fullName: r.full_name,
      position: r.position, avatarColor: r.avatar_color,
      lateMinutes: Number(r.late_minutes || 0), lateCount: Number(r.late_count || 0),
    }));

    res.json({
      date: today,
      range: { from: from30, to: today },
      kpi: {
        totalEmployees: total,
        hadir,
        terlambat: lateRows.length,
        totalLateMinutes,
        alfa,
        libur: off,
        absentRate: total > 0 ? Math.round((hadir / total) * 100) : 0,
      },
      pending: { leaves: Number(pending.leaves || 0), overtimes: Number(pending.overtimes || 0), total: Number(pending.leaves || 0) + Number(pending.overtimes || 0) },
      overtime: {
        approvedMinutes: Number(ot.approved_minutes || 0),
        pendingMinutes: Number(ot.pending_minutes || 0),
        approvedCount: Number(ot.approved_count || 0),
        pendingCount: Number(ot.pending_count || 0),
      },
      leave: { approvedDays: Number(lv.approved_days || 0) },
      avgPresent30: avgPresent,
      trend,
      pendingItems,
      topLate,
    });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Tab: Persetujuan Izin (pengajuan karyawan -> approve superadmin) ---
app.get('/api/admin/leaves', adminAuth, async (req, res) => {
  try {
    const status = String(req.query.status ?? '').toUpperCase();
    const params: any[] = [req.admin.companyId];
    let where = `l.company_id = $1`;
    if (['PENDING', 'APPROVED', 'REJECTED'].includes(status)) { params.push(status); where += ` AND l.status = $2`; }
    const rows = (await pool.query(
      `SELECT l.id, l.category, l.start_date, l.end_date, l.reason, l.status,
              l.decision_note, l.decided_at, l.created_at,
              l.attachment_base64 IS NOT NULL AS has_attachment,
              l.attachment_type,
              e.id AS employee_id, e.employee_code, e.full_name, e.position
       FROM leaves l JOIN employees e ON e.id = l.employee_id
       WHERE ${where} ORDER BY (l.status = 'PENDING') DESC, l.created_at DESC LIMIT 200`,
      params
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, employeeId: r.employee_id, employeeCode: r.employee_code, fullName: r.full_name,
      position: r.position, category: r.category,
      startDate: toDateStr(r.start_date), endDate: toDateStr(r.end_date),
      reason: r.reason, status: r.status, decisionNote: r.decision_note,
      decidedAt: r.decided_at?.toISOString?.() ?? null,
      createdAt: r.created_at?.toISOString?.() ?? null,
      hasAttachment: r.has_attachment,
      hasAttachmentImage: r.has_attachment && String(r.attachment_type ?? '').startsWith('image/'),
    }));
    res.json({ items, leaves: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.get('/api/admin/leaves/:id/attachment', adminAuth, async (req, res) => {
  try {
    const row = (await pool.query(
      `SELECT attachment_base64, attachment_type FROM leaves WHERE id=$1 AND company_id=$2`,
      [req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row || !row.attachment_base64) return res.status(404).json({ message: 'Lampiran tidak ditemukan' });
    res.json({ attachmentBase64: row.attachment_base64, attachmentType: row.attachment_type });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.put('/api/admin/leaves/:id', adminAuth, async (req, res) => {
  try {
    const status = String(req.body?.status ?? '').toUpperCase();
    if (!['APPROVED', 'REJECTED'].includes(status)) return res.status(400).json({ message: 'Status harus APPROVED atau REJECTED' });
    const note = req.body?.note ? String(req.body.note) : null;
    const row = (await pool.query(
      `UPDATE leaves SET status=$1, decision_note=$2, decided_at=now(), decided_by=$3
       WHERE id=$4 AND company_id=$5 RETURNING id, employee_id, category, status`,
      [status, note, req.admin.adminId, req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Pengajuan tidak ditemukan' });
    const label = status === 'APPROVED' ? 'disetujui' : 'ditolak';
    await pushNotification(
      req.admin.companyId, row.employee_id,
      `Pengajuan izin ${label}`,
      `Pengajuan ${label} oleh superadmin.${note ? ' Catatan: ' + note : ''}`,
      'LEAVE'
    );
    res.json({ ok: true, id: row.id, status: row.status, message: `Pengajuan izin ${label}` });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Tab: Persetujuan Lembur ---
app.get('/api/admin/overtimes', adminAuth, async (req, res) => {
  try {
    const status = String(req.query.status ?? '').toUpperCase();
    const params: any[] = [req.admin.companyId];
    let where = `o.company_id = $1`;
    if (['PENDING', 'APPROVED', 'REJECTED'].includes(status)) { params.push(status); where += ` AND o.status = $2`; }
    const rows = (await pool.query(
      `SELECT o.id, o.date, o.start_time, o.end_time, o.duration_minutes, o.reason, o.status,
              o.decision_note, o.decided_at, o.created_at,
              e.id AS employee_id, e.employee_code, e.full_name, e.position
       FROM overtimes o JOIN employees e ON e.id = o.employee_id
       WHERE ${where} ORDER BY (o.status = 'PENDING') DESC, o.created_at DESC LIMIT 200`,
      params
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, employeeId: r.employee_id, employeeCode: r.employee_code, fullName: r.full_name,
      position: r.position, date: toDateStr(r.date),
      startTime: toTimeStr(r.start_time), endTime: toTimeStr(r.end_time),
      durationMinutes: r.duration_minutes, reason: r.reason, status: r.status,
      decisionNote: r.decision_note, decidedAt: r.decided_at?.toISOString?.() ?? null,
      createdAt: r.created_at?.toISOString?.() ?? null,
    }));
    res.json({ items, overtimes: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.put('/api/admin/overtimes/:id', adminAuth, async (req, res) => {
  try {
    const status = String(req.body?.status ?? '').toUpperCase();
    if (!['APPROVED', 'REJECTED'].includes(status)) return res.status(400).json({ message: 'Status harus APPROVED atau REJECTED' });
    const note = req.body?.note ? String(req.body.note) : null;
    const row = (await pool.query(
      `UPDATE overtimes SET status=$1, decision_note=$2, decided_at=now(), decided_by=$3
       WHERE id=$4 AND company_id=$5 RETURNING id, employee_id, status`,
      [status, note, req.admin.adminId, req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Pengajuan tidak ditemukan' });
    const label = status === 'APPROVED' ? 'disetujui' : 'ditolak';
    await pushNotification(req.admin.companyId, row.employee_id, `Pengajuan lembur ${label}`,
      `Pengajuan lembur ${label} oleh superadmin.`, 'OVERTIME');
    res.json({ ok: true, id: row.id, status: row.status, message: `Pengajuan lembur ${label}` });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Tab: Rilis / Update Aplikasi ---
app.get('/api/admin/releases', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureReleaseTable();
    const rows = (await pool.query(
      `SELECT id, version_name, version_code, apk_url, mandatory, notes, active, download_count, created_at
       FROM app_releases WHERE company_id = $1 OR company_id IS NULL
       ORDER BY version_code DESC, created_at DESC LIMIT 100`, [req.admin.companyId]
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, versionName: r.version_name, versionCode: r.version_code, apkUrl: r.apk_url,
      mandatory: r.mandatory, notes: r.notes, active: r.active,
      downloadCount: r.download_count, createdAt: r.created_at?.toISOString?.() ?? null,
    }));
    res.json({ items, releases: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/admin/releases', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureReleaseTable();
    const versionName = String(req.body?.versionName ?? '').trim();
    const versionCode = Number(req.body?.versionCode ?? 0);
    const apkUrl = String(req.body?.apkUrl ?? '').trim();
    const mandatory = !!req.body?.mandatory;
    const notes = req.body?.notes ? String(req.body.notes) : null;
    if (!versionName || !versionCode || !apkUrl) return res.status(400).json({ message: 'versionName, versionCode, dan apkUrl wajib diisi' });
    await pool.query(
      `UPDATE app_releases SET active = false WHERE active = true AND (company_id = $1 OR company_id IS NULL)`,
      [req.admin.companyId]
    );
    const row = (await pool.query(
      `INSERT INTO app_releases (company_id, version_name, version_code, apk_url, mandatory, notes, active)
       VALUES ($1,$2,$3,$4,$5,$6,true) RETURNING id`,
      [req.admin.companyId, versionName, versionCode, apkUrl, mandatory, notes]
    )).rows[0];
    await pool.query(
      `INSERT INTO notifications (company_id, employee_id, title, body, kind)
       SELECT $1, e.id, 'Update aplikasi tersedia', $2, 'UPDATE'
       FROM employees e WHERE e.company_id = $1 AND e.active = true`,
      [req.admin.companyId, `Versi ${versionName} tersedia. Buka aplikasi untuk memperbarui.`]
    );
    res.json({ ok: true, id: row.id, message: 'Rilis aplikasi dipublikasikan' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.delete('/api/admin/releases/:id', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureReleaseTable();
    const row = (await pool.query(
      `DELETE FROM app_releases WHERE id=$1 AND company_id=$2 RETURNING id`,
      [req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Rilis tidak ditemukan' });
    res.json({ ok: true, message: 'Rilis dihapus' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// ==================== PAKET B + C11 : ALAT DEVELOPER ====================
// Semua endpoint di bawah ini khusus role DEV (devOnly) — dipakai oleh tab
// "Alat Developer" di panel superadmin. Fitur: Dashboard Sistem (B6),
// Log Aktivitas/Audit (B7), Broadcast Pengumuman (B8), Manajemen Perangkat (B9),
// dan Feature Flags / Remote Config (C11).

// --- Tabel pendukung (auto-migrate) ---
let devToolTablesReady: Promise<any> | null = null;
function ensureDevToolTables() {
  if (!devToolTablesReady) {
    devToolTablesReady = pool.query(`
      CREATE TABLE IF NOT EXISTS audit_log (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid,
        actor_type text NOT NULL DEFAULT 'ADMIN',
        actor_id text,
        actor_name text,
        actor_role text,
        action text NOT NULL,
        target text,
        detail text,
        ip text,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_audit_log_company_created ON audit_log (company_id, created_at DESC);

      CREATE TABLE IF NOT EXISTS feature_flags (
        company_id uuid NOT NULL,
        key text NOT NULL,
        label text,
        description text,
        enabled boolean NOT NULL DEFAULT true,
        updated_by text,
        updated_at timestamptz NOT NULL DEFAULT now(),
        PRIMARY KEY (company_id, key)
      );

      ALTER TABLE devices ADD COLUMN IF NOT EXISTS revoked_at timestamptz;
      ALTER TABLE devices ADD COLUMN IF NOT EXISTS last_seen_at timestamptz;
      ALTER TABLE devices ADD COLUMN IF NOT EXISTS app_version_code integer;
    `);
  }
  return devToolTablesReady;
}

// Catat satu baris audit. Sengaja "best effort" — kegagalan mencatat tidak boleh
// menggagalkan aksi utama.
async function audit(req: express.Request, action: string, opts?: { target?: string; detail?: string; companyId?: string }) {
  try {
    await ensureDevToolTables();
    const a: any = (req as any).admin ?? {};
    const ip = (req.header('x-forwarded-for') || req.ip || '').toString().split(',')[0].trim() || null;
    await pool.query(
      `INSERT INTO audit_log (company_id, actor_type, actor_id, actor_name, actor_role, action, target, detail, ip)
       VALUES ($1,'ADMIN',$2,$3,$4,$5,$6,$7,$8)`,
      [opts?.companyId ?? a.companyId ?? null, a.adminId ?? null, a.adminName ?? null, a.role ?? null,
        action, opts?.target ?? null, opts?.detail ?? null, ip]
    );
  } catch (e) {
    console.error('audit gagal:', e);
  }
}

function clientIp(req: express.Request): string | null {
  const ip = (req.header('x-forwarded-for') || req.ip || '').toString().split(',')[0].trim();
  return ip || null;
}

// ==================== B9: DEVELOPER CONSOLE ====================
// (M) Tabel sesi impersonation + perbaikan data (recompute absensi & backfill jadwal).
let b9TablesReady: Promise<any> | null = null;
function ensureB9Tables() {
  if (!b9TablesReady) {
    b9TablesReady = pool.query(`
      CREATE TABLE IF NOT EXISTS impersonation_tokens (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        token text NOT NULL UNIQUE,
        company_id uuid NOT NULL,
        employee_id uuid NOT NULL,
        admin_id text,
        admin_name text,
        admin_role text,
        note text,
        created_at timestamptz NOT NULL DEFAULT now(),
        expires_at timestamptz NOT NULL,
        revoked_at timestamptz
      );
      CREATE INDEX IF NOT EXISTS idx_impersonation_company ON impersonation_tokens (company_id, created_at DESC);
    `);
  }
  return b9TablesReady;
}

const B9_IMP_BODY_CONTENT = `<!doctype html><html lang="id"><head><meta charset="utf-8"><title>Mode Dukungan — AbsensiKu</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:'Segoe UI',Roboto,sans-serif;margin:0;background:#F3F7F2;color:#1F2937;display:flex;align-items:center;justify-content:center;min-height:100vh}
.card{max-width:440px;margin:20px;background:#fff;border:1px solid #D8E3D6;border-radius:16px;padding:26px;box-shadow:0 10px 30px rgba(0,0,0,.05)}
.tag{display:inline-block;background:#FEF3C7;color:#92400E;font-weight:800;font-size:11px;letter-spacing:.05em;text-transform:uppercase;padding:5px 10px;border-radius:8px}
h1{font-size:19px;margin:14px 0 6px;color:#036D19}p{font-size:13.5px;color:#4B5563;line-height:1.55}
.row{display:flex;justify-content:space-between;font-size:13px;padding:8px 0;border-bottom:1px solid #EEF2ED}.row b{color:#111827}
.foot{font-size:11.5px;color:#6B7280;margin-top:16px}</style></head><body>
<div class="card"><span class="tag">Mode Dukungan · Hanya Baca</span>
<h1 id="t">Sesi Dukungan</h1><div id="body">Memuat…</div></div>
<script>
fetch(location.pathname + location.search, {headers:{'Accept':'application/json'}})
 .then(r=>r.json()).then(d=>{
   if(!d||!d.employeeId){document.getElementById('body').innerHTML='<p>Sesi tidak ditemukan atau sudah berakhir.</p>';return;}
   document.getElementById('body').innerHTML='<div class="row"><span>Karyawan</span><b>'+d.fullName+' ('+d.employeeCode+')</b></div>'
     +'<div class="row"><span>Dimulai</span><b>'+(d.createdAt||'-')+'</b></div>'
     +'<div class="row"><span>Berakhir</span><b>'+(d.expiresAt||'-')+'</b></div>'
     +'<div class="row"><span>Oleh</span><b>'+(d.adminName||'admin')+'</b></div>'
     +'<p class="foot">Gunakan token ini pada aplikasi/alat debug (header Authorization: Bearer …). Sesi hanya untuk diagnosa — tidak dapat menulis data.</p>';
 }).catch(()=>{document.getElementById('body').innerHTML='<p>Sesi tidak ditemukan.</p>';});
</script></body></html>`;

/** Ambil ringkasan satu karyawan (dipakai konsol developer). */
async function devEmployeeSummary(companyId: string, empId: string) {
  const r = (await pool.query(
    `SELECT e.id, e.employee_code, e.full_name, e.position, e.active, e.photo_base64, e.avatar_color,
            e.shift_id, s.name AS shift_name
     FROM employees e LEFT JOIN shifts s ON s.id=e.shift_id
     WHERE e.id=$1 AND e.company_id=$2 LIMIT 1`, [empId, companyId]
  )).rows[0];
  if (!r) return null;
  const att = (await pool.query(
    `SELECT COUNT(*)::int AS total,
            COUNT(*) FILTER (WHERE (server_timestamp AT TIME ZONE 'Asia/Jakarta')::date = (now() AT TIME ZONE 'Asia/Jakarta')::date)::int AS today,
            MAX(server_timestamp) AS last_at
     FROM attendance WHERE employee_id=$1`, [empId]
  )).rows[0];
  const dev = (await pool.query(`SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE revoked_at IS NULL)::int AS active FROM devices WHERE employee_id=$1`, [empId])).rows[0];
  return {
    id: r.id, employeeCode: r.employee_code, fullName: r.full_name, position: r.position,
    active: r.active, avatarColor: r.avatar_color, photoBase64: r.photo_base64 ?? null,
    shiftId: r.shift_id, shiftName: r.shift_name,
    attendance: { total: att?.total ?? 0, today: att?.today ?? 0, lastAt: att?.last_at?.toISOString?.() ?? null },
    devices: { total: dev?.total ?? 0, active: dev?.active ?? 0 },
  };
}

// --- Diagnostics (snapshot) — read-only ---
app.get('/api/admin/diagnostics', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureDevToolTables();
    await ensureB9Tables();
    const cid = req.admin.companyId;
    const t0 = Date.now();
    await pool.query('SELECT 1');
    let t1 = Date.now();
    await pool.query('SELECT COUNT(*) FROM attendance WHERE company_id=$1', [cid]);
    const dbLatencyMs = Date.now() - t0;
    const queryLatencyMs = Date.now() - t1;
    const mem = process.memoryUsage();
    const stat = async (sql: string, p: any[] = [cid]) => (await pool.query(sql, p)).rows[0]?.c ?? 0;
    const counts = {
      employees: await stat(`SELECT COUNT(*)::int AS c FROM employees WHERE company_id=$1`),
      devices: await stat(`SELECT COUNT(*)::int AS c FROM devices d JOIN employees e ON e.id=d.employee_id WHERE e.company_id=$1`),
      attendance: await stat(`SELECT COUNT(*)::int AS c FROM attendance WHERE company_id=$1`),
      leaves: await stat(`SELECT COUNT(*)::int AS c FROM leaves WHERE company_id=$1`),
      overtimes: await stat(`SELECT COUNT(*)::int AS c FROM overtimes WHERE company_id=$1`),
      notifications: await stat(`SELECT COUNT(*)::int AS c FROM notifications WHERE company_id=$1`),
      auditLog: await stat(`SELECT COUNT(*)::int AS c FROM audit_log WHERE company_id=$1 OR company_id IS NULL`),
      impersonations: await stat(`SELECT COUNT(*)::int AS c FROM impersonation_tokens WHERE company_id=$1`),
    };
    const activeImp = await stat(`SELECT COUNT(*)::int AS c FROM impersonation_tokens WHERE company_id=$1 AND revoked_at IS NULL AND expires_at > now()`);
    const lastErr = (await pool.query(
      `SELECT action, target, detail, created_at FROM audit_log
       WHERE (company_id=$1 OR company_id IS NULL) AND action LIKE '%ERROR%'
       ORDER BY created_at DESC LIMIT 5`, [cid]
    )).rows.map((r) => ({ action: r.action, target: r.target, detail: r.detail, createdAt: r.created_at?.toISOString?.() ?? null }));
    res.json({
      ok: true,
      serverTime: new Date().toISOString(),
      uptimeSeconds: Math.round(process.uptime()),
      env: process.env.VERCEL_ENV || process.env.NODE_ENV || 'development',
      nodeVersion: process.version,
      region: process.env.VERCEL_REGION || null,
      apiVersion: process.env.APP_VERSION ?? '0.9.22',
      db: {
        latencyMs: dbLatencyMs, queryLatencyMs,
        poolTotal: (pool as any).totalCount ?? null,
        poolIdle: (pool as any).idleCount ?? null,
        poolWaiting: (pool as any).waitingCount ?? null,
      },
      memory: { rssMB: Math.round(mem.rss / 1048576), heapUsedMB: Math.round(mem.heapUsed / 1048576) },
      counts,
      activeImpersonations: activeImp,
      recentErrors: lastErr,
    });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Data repair (B9) — recompute late_minutes & backfill jadwal ---
app.post('/api/admin/data/repair', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureScheduleTable();
    await ensureLateColumn();
    const action = String(req.body?.action ?? '').trim();
    const from = String(req.body?.from ?? '').slice(0, 10);
    const to = String(req.body?.to ?? '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
      return res.status(400).json({ message: 'Rentang tanggal (from, to) wajib dalam format YYYY-MM-DD' });
    }
    if (from > to) return res.status(400).json({ message: 'Tanggal awal harus sebelum tanggal akhir' });
    const spanDays = Math.round((+new Date(to + 'T00:00:00Z') - +new Date(from + 'T00:00:00Z')) / 864e5);
    if (spanDays > 120) return res.status(400).json({ message: 'Rentang maksimum 120 hari per perbaikan' });
    const grace = await getLateGrace(req.admin.companyId);
    const repairTzOff = await getTzOffset(req.admin.companyId);
    // clearOverrides=true -> hitung ulang termasuk baris yang sudah dikoreksi manual.
    const clearOverrides = req.body?.clearOverrides === true;

    if (action === 'recompute-late') {
      const rows = (await pool.query(
        `SELECT a.id, a.employee_id, a.type, a.server_timestamp, a.client_timestamp
         FROM attendance a JOIN employees e ON e.id = a.employee_id
         WHERE e.company_id=$1 AND a.type='CHECK_IN'
           AND (a.server_timestamp AT TIME ZONE 'Asia/Jakarta')::date BETWEEN $2::date AND $3::date
         ORDER BY a.employee_id, a.server_timestamp`,
        [req.admin.companyId, from, to]
      )).rows;
      const schedRows = (await pool.query(
        `SELECT sc.employee_id, sc.date, sc.note, s.start_time
         FROM employee_schedules sc LEFT JOIN shifts s ON s.id = sc.shift_id
         WHERE sc.company_id=$1 AND sc.date BETWEEN $2::date AND $3::date`,
        [req.admin.companyId, from, to]
      )).rows;
      const schMap: any = {};
      for (const r of schedRows) schMap[r.employee_id + '|' + toDateStr(r.date)] = r;
      const cache: any = {};
      const resolveStart = async (empId: string, iso: string): Promise<string | null> => {
        const sc = schMap[empId + '|' + iso];
        if (sc) { if (sc.note === 'OFF') return null; return toTimeStr(sc.start_time) || null; }
        const key = empId + '|' + iso;
        if (!(key in cache)) { const shift = await resolveShiftForDate(empId, iso); cache[key] = shift.off ? null : shift.startTime; }
        return cache[key];
      };
      let updated = 0, changed = 0;
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        for (const r of rows) {
          const iso = isoDateTz(new Date(r.server_timestamp));
          const startTime = await resolveStart(r.employee_id, iso);
          if (!startTime) continue;
          const scanAt = new Date(r.client_timestamp ?? r.server_timestamp);
          const st = computeLateStatusAtOffset(scanAt, startTime, repairTzOff, grace);
          const newStatus = st.status === 'TERLAMBAT' ? 'TERLAMBAT' : 'APPROVED';
          const before = (await client.query(`SELECT late_minutes, status, late_overridden FROM attendance WHERE id=$1`, [r.id])).rows[0];
          // Hormati koreksi manual: lewati baris late_overridden (kecuali diminta menimpa).
          if (before?.late_overridden && !clearOverrides) continue;
          if ((before?.late_minutes ?? 0) !== st.lateMinutes || before?.status !== newStatus) changed++;
          await client.query(`UPDATE attendance SET late_minutes=$2, status=$3, late_overridden=false WHERE id=$1`, [r.id, st.lateMinutes, newStatus]);
          updated++;
        }
        await client.query('COMMIT');
      } catch (e) { await client.query('ROLLBACK').catch(() => {}); throw e; }
      finally { client.release(); }
      await audit(req, 'DATA_REPAIR_RECOMPUTE', {
        detail: `Hitung ulang keterlambatan ${from}..${to}: ${updated} baris diproses, ${changed} berubah (toleransi ${grace} mnt)`,
      });
      return res.json({ ok: true, action, processed: updated, changed, grace, message: `${updated} baris absensi diproses, ${changed} diperbarui.` });
    }

    if (action === 'backfill-schedule') {
      const workdays = [0, 1, 2, 3, 4, 5];
      const employees = (await pool.query(
        `SELECT id, shift_id FROM employees WHERE company_id=$1 AND active=true AND shift_id IS NOT NULL`, [req.admin.companyId]
      )).rows;
      let inserted = 0, skipped = 0;
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        let d = new Date(from + 'T00:00:00Z');
        while (toDateStr(d) <= to) {
          const dow = (d.getUTCDay() + 6) % 7;
          if (workdays.includes(dow)) {
            const date = toDateStr(d);
            for (const e of employees) {
              const exists = (await client.query(`SELECT 1 FROM employee_schedules WHERE company_id=$1 AND employee_id=$2 AND date=$3::date`, [req.admin.companyId, e.id, date])).rowCount;
              if (exists) { skipped++; continue; }
              await client.query(
                `INSERT INTO employee_schedules (company_id, employee_id, date, shift_id, note, updated_at)
                 VALUES ($1,$2,$3::date,$4,NULL, now()) ON CONFLICT (employee_id, date) DO NOTHING`,
                [req.admin.companyId, e.id, date, e.shift_id]
              );
              inserted++;
            }
          }
          d = new Date(d.getTime() + 864e5);
        }
        await client.query('COMMIT');
      } catch (e) { await client.query('ROLLBACK').catch(() => {}); throw e; }
      finally { client.release(); }
      await audit(req, 'DATA_REPAIR_BACKFILL', { detail: `Backfill jadwal ${from}..${to}: ${inserted} dibuat, ${skipped} dilewati` });
      return res.json({ ok: true, action, inserted, skipped, message: `${inserted} jadwal baru dibuat (Senin–Sabtu dari shift default), ${skipped} sudah ada.` });
    }

    return res.status(400).json({ message: 'Aksi tidak dikenal. Gunakan recompute-late atau backfill-schedule.' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Impersonation karyawan (view-only) — B9 ---
app.get('/api/admin/impersonations', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureB9Tables();
    await pool.query(`UPDATE impersonation_tokens SET revoked_at=now() WHERE company_id=$1 AND revoked_at IS NULL AND expires_at <= now()`, [req.admin.companyId]);
    const rows = (await pool.query(
      `SELECT it.id, it.employee_id, it.admin_name, it.note, it.created_at, it.expires_at, it.revoked_at,
              e.full_name, e.employee_code, e.avatar_color
       FROM impersonation_tokens it LEFT JOIN employees e ON e.id = it.employee_id
       WHERE it.company_id=$1 ORDER BY it.created_at DESC LIMIT 100`, [req.admin.companyId]
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, employeeId: r.employee_id, fullName: r.full_name, employeeCode: r.employee_code,
      avatarColor: r.avatar_color, adminName: r.admin_name, note: r.note,
      createdAt: r.created_at?.toISOString?.() ?? null,
      expiresAt: r.expires_at?.toISOString?.() ?? null,
      revokedAt: r.revoked_at?.toISOString?.() ?? null,
      active: !r.revoked_at && r.expires_at && new Date(r.expires_at) > new Date(),
    }));
    res.json({ items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/admin/impersonations', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureB9Tables();
    const employeeId = String(req.body?.employeeId ?? '').trim();
    const note = String(req.body?.note ?? '').trim();
    const minutes = Math.min(120, Math.max(5, Number(req.body?.minutes ?? 30)));
    if (!employeeId) return res.status(400).json({ message: 'employeeId wajib diisi' });
    const emp = (await pool.query(`SELECT id, full_name, employee_code FROM employees WHERE id=$1 AND company_id=$2 LIMIT 1`, [employeeId, req.admin.companyId])).rows[0];
    if (!emp) return res.status(404).json({ message: 'Karyawan tidak ditemukan' });
    const token = crypto.randomBytes(24).toString('hex');
    const a: any = (req as any).admin ?? {};
    const row = (await pool.query(
      `INSERT INTO impersonation_tokens (token, company_id, employee_id, admin_id, admin_name, admin_role, note, expires_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7, now() + ($8 || ' minutes')::interval)
       RETURNING expires_at`,
      [token, req.admin.companyId, employeeId, a.adminId ?? null, a.adminName ?? a.email ?? null, a.role ?? null, note || null, String(minutes)]
    )).rows[0];
    await audit(req, 'IMPERSONATE_START', { target: `${emp.full_name} (${emp.employee_code})`, detail: `Sesi dukungan ${minutes} menit${note ? ' • ' + note : ''}` });
    res.json({ ok: true, token, employee: { id: emp.id, fullName: emp.full_name, employeeCode: emp.employee_code }, expiresAt: row.expires_at?.toISOString?.() ?? null, minutes, viewOnly: true });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.delete('/api/admin/impersonations/:id', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureB9Tables();
    const row = (await pool.query(
      `UPDATE impersonation_tokens SET revoked_at=now() WHERE id=$1 AND company_id=$2 AND revoked_at IS NULL RETURNING employee_id`,
      [req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Sesi tidak ditemukan atau sudah berakhir' });
    await audit(req, 'IMPERSONATE_END', { target: row.employee_id, detail: 'Sesi dukungan diakhiri' });
    res.json({ ok: true, message: 'Sesi dukungan diakhiri' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// Ringkasan karyawan (read-only) + rute sesi dukungan (JSON untuk admin; HTML untuk peramban).
app.get('/api/admin/impersonation/session', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureB9Tables();
    const token = String(req.query.token ?? '').trim();
    if (!token) return res.status(400).json({ message: 'token wajib diisi' });
    const row = (await pool.query(`SELECT employee_id, created_at, expires_at, revoked_at, admin_name FROM impersonation_tokens WHERE token=$1 AND company_id=$2 LIMIT 1`, [token, req.admin.companyId])).rows[0];
    if (!row) return res.status(404).json({ message: 'Sesi tidak ditemukan' });
    if (row.revoked_at) return res.status(410).json({ message: 'Sesi sudah diakhiri' });
    if (new Date(row.expires_at) <= new Date()) return res.status(410).json({ message: 'Sesi sudah kedaluwarsa' });
    const summary = await devEmployeeSummary(req.admin.companyId, row.employee_id);
    res.json({
      viewOnly: true, token,
      employeeId: row.employee_id, fullName: summary?.fullName ?? null, employeeCode: summary?.employeeCode ?? null,
      createdAt: row.created_at?.toISOString?.() ?? null, expiresAt: row.expires_at?.toISOString?.() ?? null,
      adminName: row.admin_name ?? null, summary,
    });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.get('/api/impersonate/:token', async (req, res) => {
  try {
    await ensureB9Tables();
    const token = String(req.params.token ?? '').trim();
    const accept = String(req.header('accept') || '');
    const wantsJson = accept.includes('application/json') || String(req.query.format || '') === 'json';
    const row = (await pool.query(`SELECT employee_id, company_id, created_at, expires_at, revoked_at, admin_name FROM impersonation_tokens WHERE token=$1 LIMIT 1`, [token])).rows[0];
    if (!row || row.revoked_at || new Date(row.expires_at) <= new Date()) {
      if (!wantsJson) { res.setHeader('Content-Type', 'text/html; charset=utf-8'); return res.send(B9_IMP_BODY_CONTENT); }
      return res.status(410).json({ message: 'Sesi dukungan tidak valid atau sudah berakhir' });
    }
    const summary = await devEmployeeSummary(row.company_id, row.employee_id);
    if (wantsJson) {
      return res.json({
        viewOnly: true, token,
        employeeId: row.employee_id, fullName: summary?.fullName ?? null, employeeCode: summary?.employeeCode ?? null,
        createdAt: row.created_at?.toISOString?.() ?? null, expiresAt: row.expires_at?.toISOString?.() ?? null,
        adminName: row.admin_name ?? null, summary,
      });
    }
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(B9_IMP_BODY_CONTENT);
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- B6: Dashboard Sistem ---
app.get('/api/admin/system-status', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureDevToolTables();
    const t0 = Date.now();
    await pool.query('SELECT 1');
    const dbLatency = Date.now() - t0;
    const cid = req.admin.companyId;
    const [emp, dev, att, leaves, ot, releases, auditCount, lastAudit] = await Promise.all([
      pool.query(`SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE active)::int AS active FROM employees WHERE company_id=$1`, [cid]),
      pool.query(`SELECT COUNT(*)::int AS total, COUNT(DISTINCT employee_id)::int AS employees,
                         COUNT(*) FILTER (WHERE revoked_at IS NOT NULL)::int AS revoked,
                         COUNT(*) FILTER (WHERE last_seen_at > now() - interval '7 days')::int AS recent
                  FROM devices d JOIN employees e ON e.id = d.employee_id WHERE e.company_id=$1`, [cid]),
      pool.query(`SELECT COUNT(*)::int AS total FROM attendance WHERE company_id=$1 AND (server_timestamp AT TIME ZONE 'Asia/Jakarta')::date = (now() AT TIME ZONE 'Asia/Jakarta')::date`, [cid]),
      pool.query(`SELECT COUNT(*) FILTER (WHERE status='PENDING')::int AS pending FROM leaves WHERE company_id=$1`, [cid]),
      pool.query(`SELECT COUNT(*) FILTER (WHERE status='PENDING')::int AS pending FROM overtimes WHERE company_id=$1`, [cid]),
      pool.query(`SELECT version_name, version_code, active FROM app_releases WHERE company_id=$1 OR company_id IS NULL ORDER BY version_code DESC LIMIT 1`, [cid]),
      pool.query(`SELECT COUNT(*)::int AS total FROM audit_log WHERE company_id=$1 OR company_id IS NULL`, [cid]),
      pool.query(`SELECT action, actor_name, created_at FROM audit_log WHERE company_id=$1 OR company_id IS NULL ORDER BY created_at DESC LIMIT 1`, [cid]),
    ]);
    const rel = releases.rows[0] ?? null;
    const la = lastAudit.rows[0] ?? null;
    res.json({
      ok: true,
      serverTime: new Date().toISOString(),
      dbLatencyMs: dbLatency,
      uptimeAcceptable: dbLatency < 500,
      api: { service: 'absensiku-api', version: process.env.APP_VERSION ?? '0.9.22' },
      employees: { total: emp.rows[0]?.total ?? 0, active: emp.rows[0]?.active ?? 0 },
      devices: { total: dev.rows[0]?.total ?? 0, employees: dev.rows[0]?.employees ?? 0, revoked: dev.rows[0]?.revoked ?? 0, recent: dev.rows[0]?.recent ?? 0 },
      todayAttendance: att.rows[0]?.total ?? 0,
      pendingLeaves: leaves.rows[0]?.pending ?? 0,
      pendingOvertimes: ot.rows[0]?.pending ?? 0,
      latestRelease: rel ? { versionName: rel.version_name, versionCode: rel.version_code, active: rel.active } : null,
      audit: { total: auditCount.rows[0]?.total ?? 0, lastAction: la?.action ?? null, lastActor: la?.actor_name ?? null, lastAt: la?.created_at?.toISOString?.() ?? null },
    });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- B7: Log Aktivitas / Audit (diperkuat B9: filter aktor, aksi, tanggal) ---
app.get('/api/admin/audit', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureDevToolTables();
    const limit = Math.min(500, Math.max(1, Number(req.query.limit ?? 60)));
    const q = String(req.query.q ?? '').trim();
    const actor = String(req.query.actor ?? '').trim();
    const action = String(req.query.action ?? '').trim();
    const from = String(req.query.from ?? '').trim();
    const to = String(req.query.to ?? '').trim();
    const params: any[] = [req.admin.companyId];
    let where = `(company_id = $1 OR company_id IS NULL)`;
    if (q) { params.push('%' + q + '%'); where += ` AND (action ILIKE $${params.length} OR target ILIKE $${params.length} OR actor_name ILIKE $${params.length} OR detail ILIKE $${params.length})`; }
    if (actor) { params.push('%' + actor + '%'); where += ` AND actor_name ILIKE $${params.length}`; }
    if (action) { params.push(action.toUpperCase() + '%'); where += ` AND action ILIKE $${params.length}`; }
    if (from) { params.push(from); where += ` AND created_at >= $${params.length}::date`; }
    if (to) { params.push(to); where += ` AND created_at < ($${params.length}::date + interval '1 day')`; }
    params.push(limit);
    const rows = (await pool.query(
      `SELECT id, actor_name, actor_role, action, target, detail, ip, created_at
       FROM audit_log WHERE ${where} ORDER BY created_at DESC LIMIT $${params.length}`, params
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, actorName: r.actor_name, actorRole: r.actor_role, action: r.action,
      target: r.target, detail: r.detail, ip: r.ip, createdAt: r.created_at?.toISOString?.() ?? null,
    }));
    res.json({ items, logs: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// Ekspor audit ke CSV (B9). Menghormati filter yang sama dengan GET /audit.
app.get('/api/admin/audit/export', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureDevToolTables();
    const q = String(req.query.q ?? '').trim();
    const actor = String(req.query.actor ?? '').trim();
    const action = String(req.query.action ?? '').trim();
    const from = String(req.query.from ?? '').trim();
    const to = String(req.query.to ?? '').trim();
    const params: any[] = [req.admin.companyId];
    let where = `(company_id = $1 OR company_id IS NULL)`;
    if (q) { params.push('%' + q + '%'); where += ` AND (action ILIKE $${params.length} OR target ILIKE $${params.length} OR actor_name ILIKE $${params.length} OR detail ILIKE $${params.length})`; }
    if (actor) { params.push('%' + actor + '%'); where += ` AND actor_name ILIKE $${params.length}`; }
    if (action) { params.push(action.toUpperCase() + '%'); where += ` AND action ILIKE $${params.length}`; }
    if (from) { params.push(from); where += ` AND created_at >= $${params.length}::date`; }
    if (to) { params.push(to); where += ` AND created_at < ($${params.length}::date + interval '1 day')`; }
    const rows = (await pool.query(
      `SELECT actor_name, actor_role, action, target, detail, ip, created_at
       FROM audit_log WHERE ${where} ORDER BY created_at DESC LIMIT 5000`, params
    )).rows;
    const csvEsc = (v: any) => {
      const s = v == null ? '' : String(v);
      return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    };
    const header = ['Waktu', 'Aktor', 'Peran', 'Aksi', 'Target', 'Detail', 'IP'];
    const lines = [header.join(',')];
    for (const r of rows) {
      lines.push([
        r.created_at ? new Date(r.created_at).toLocaleString('id-ID') : '',
        r.actor_name || '', r.actor_role || '', r.action || '', r.target || '', r.detail || '', r.ip || '',
      ].map(csvEsc).join(','));
    }
    const csv = '\ufeff' + lines.join('\r\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="log-aktivitas-${isoDateTz()}.csv"`);
    res.send(csv);
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.delete('/api/admin/audit', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureDevToolTables();
    await pool.query(`DELETE FROM audit_log WHERE company_id = $1 OR company_id IS NULL`, [req.admin.companyId]);
    await audit(req, 'AUDIT_CLEAR', { detail: 'Menghapus seluruh log aktivitas' });
    res.json({ ok: true, message: 'Log aktivitas dibersihkan' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- B8: Broadcast Pengumuman ---
app.get('/api/admin/broadcasts', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureReleaseTable();
    const rows = (await pool.query(
      `SELECT id, title, body, kind, created_at,
              (SELECT COUNT(*)::int FROM employees e WHERE e.company_id = $1 AND e.active = true) AS recipients,
              COALESCE(array_length(read_by, 1), 0) AS read_count
       FROM notifications WHERE company_id = $1 AND employee_id IS NULL
       ORDER BY created_at DESC LIMIT 100`, [req.admin.companyId]
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, title: r.title, body: r.body, kind: r.kind,
      recipients: r.recipients, readCount: r.read_count,
      createdAt: r.created_at?.toISOString?.() ?? null,
    }));
    res.json({ items, broadcasts: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/admin/broadcast', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureReleaseTable();
    const title = String(req.body?.title ?? '').trim();
    const body = String(req.body?.body ?? '').trim();
    const kind = String(req.body?.kind ?? 'INFO').toUpperCase();
    if (!title) return res.status(400).json({ message: 'Judul pengumuman wajib diisi.' });
    const allowed = ['INFO', 'ANNOUNCEMENT', 'URGENT'];
    const k = allowed.includes(kind) ? kind : 'INFO';
    const row = (await pool.query(
      `INSERT INTO notifications (company_id, employee_id, title, body, kind)
       VALUES ($1, NULL, $2, $3, $4) RETURNING id`,
      [req.admin.companyId, title, body || null, k]
    )).rows[0];
    const n = (await pool.query(`SELECT COUNT(*)::int AS c FROM employees WHERE company_id=$1 AND active=true`, [req.admin.companyId])).rows[0]?.c ?? 0;
    await audit(req, 'BROADCAST_SEND', { target: title, detail: `Pengumuman "${title}" dikirim ke ${n} karyawan` });
    res.json({ ok: true, id: row.id, recipients: n, message: 'Pengumuman dikirim' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.delete('/api/admin/broadcast/:id', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureReleaseTable();
    const row = (await pool.query(
      `DELETE FROM notifications WHERE id=$1 AND company_id=$2 AND employee_id IS NULL RETURNING title`,
      [req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Pengumuman tidak ditemukan' });
    await audit(req, 'BROADCAST_DELETE', { target: row.title, detail: `Pengumuman "${row.title}" dihapus` });
    res.json({ ok: true, message: 'Pengumuman dihapus' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- B9: Manajemen Perangkat ---
app.get('/api/admin/devices', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureDevToolTables();
    const rows = (await pool.query(
      `SELECT d.id, d.device_key, d.platform, d.last_login_at, d.last_seen_at, d.revoked_at, d.app_version_code,
              d.created_at, e.id AS employee_id, e.employee_code, e.full_name, e.photo_base64, e.avatar_color
       FROM devices d JOIN employees e ON e.id = d.employee_id
       WHERE e.company_id = $1
       ORDER BY d.revoked_at NULLS FIRST, d.last_login_at DESC NULLS LAST LIMIT 300`, [req.admin.companyId]
    )).rows;
    const items = rows.map((r) => ({
      id: r.id, deviceKey: r.device_key, platform: r.platform,
      employeeId: r.employee_id, employeeCode: r.employee_code, fullName: r.full_name,
      avatarColor: r.avatar_color, photoBase64: r.photo_base64 ?? null,
      lastLoginAt: r.last_login_at?.toISOString?.() ?? null,
      lastSeenAt: r.last_seen_at?.toISOString?.() ?? null,
      revokedAt: r.revoked_at?.toISOString?.() ?? null,
      appVersionCode: r.app_version_code ?? null,
      createdAt: r.created_at?.toISOString?.() ?? null,
    }));
    res.json({ items, devices: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.delete('/api/admin/devices/:id', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureDevToolTables();
    const row = (await pool.query(
      `UPDATE devices d SET revoked_at = now()
         FROM employees e
        WHERE d.id = $1 AND d.employee_id = e.id AND e.company_id = $2
        RETURNING d.id, e.full_name`, [req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Perangkat tidak ditemukan' });
    await audit(req, 'DEVICE_REVOKE', { target: row.full_name, detail: `Akses perangkat "${row.full_name}" dicabut` });
    res.json({ ok: true, message: 'Perangkat dicabut' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.put('/api/admin/devices/:id/restore', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureDevToolTables();
    const row = (await pool.query(
      `UPDATE devices d SET revoked_at = NULL
         FROM employees e
        WHERE d.id = $1 AND d.employee_id = e.id AND e.company_id = $2
        RETURNING d.id, e.full_name`, [req.params.id, req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Perangkat tidak ditemukan' });
    await audit(req, 'DEVICE_RESTORE', { target: row.full_name, detail: `Akses perangkat "${row.full_name}" dipulihkan` });
    res.json({ ok: true, message: 'Perangkat dipulihkan' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- C11: Feature Flags / Remote Config ---
const DEFAULT_FLAGS: { key: string; label: string; description: string; enabled: boolean }[] = [
  { key: 'attendance_photo', label: 'Foto Selfie saat Absen', description: 'Wajibkan verifikasi foto saat absen masuk/keluar.', enabled: true },
  { key: 'overtime', label: 'Pengajuan Lembur', description: 'Izinkan karyawan mengajukan lembur dari aplikasi.', enabled: true },
  { key: 'leave', label: 'Pengajuan Izin', description: 'Izinkan karyawan mengajukan izin/cuti dari aplikasi.', enabled: true },
  { key: 'biometric_login', label: 'Login Biometrik', description: 'Aktifkan opsi login sidik jari/wajah di aplikasi.', enabled: true },
  { key: 'self_change_password', label: 'Ganti Password Mandiri', description: 'Izinkan karyawan mengganti password sendiri di tab Profil.', enabled: true },
  { key: 'ops_module', label: 'Tab Operasional (POS/Driver/Opname)', description: 'Tampilkan tab Operasional di aplikasi karyawan (Kasir, Driver, Pramuniaga, Kepala Gudang).', enabled: true },
  { key: 'offline_queue', label: 'Antrian Absen Offline', description: 'Absensi disimpan di perangkat saat internet buruk, lalu terkirim otomatis (waktu scan tetap asli sehingga tidak jadi telat).', enabled: true },
  { key: 'gps_tolerant', label: 'Absensi Tetap Tercatat saat GPS Lemah', description: 'Absensi tidak ditolak karena akurasi GPS rendah/di luar radius — cukup ditandai untuk verifikasi admin.', enabled: true },
];

async function ensureFlagsSeeded(companyId: string) {
  await ensureDevToolTables();
  await pool.query(
    `INSERT INTO feature_flags (company_id, key, label, description, enabled)
     SELECT $1, f.key, f.label, f.description, f.enabled
     FROM jsonb_to_recordset($2::jsonb) AS f(key text, label text, description text, enabled boolean)
     ON CONFLICT (company_id, key) DO NOTHING`,
    [companyId, JSON.stringify(DEFAULT_FLAGS)]
  );
}

async function getFlags(companyId: string): Promise<Record<string, boolean>> {
  try {
    await ensureFlagsSeeded(companyId);
    const rows = (await pool.query(`SELECT key, enabled FROM feature_flags WHERE company_id=$1`, [companyId])).rows;
    const out: Record<string, boolean> = {};
    for (const f of DEFAULT_FLAGS) out[f.key] = true;
    for (const r of rows) out[r.key] = !!r.enabled;
    return out;
  } catch { return {}; }
}

app.get('/api/admin/flags', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureFlagsSeeded(req.admin.companyId);
    const rows = (await pool.query(
      `SELECT key, label, description, enabled, updated_by, updated_at
       FROM feature_flags WHERE company_id=$1 ORDER BY key`, [req.admin.companyId]
    )).rows;
    const items = rows.map((r) => ({
      key: r.key, label: r.label, description: r.description, enabled: r.enabled,
      updatedBy: r.updated_by, updatedAt: r.updated_at?.toISOString?.() ?? null,
    }));
    res.json({ items, flags: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.put('/api/admin/flags', adminAuth, devOnly, async (req, res) => {
  try {
    await ensureFlagsSeeded(req.admin.companyId);
    const incoming = req.body?.flags;
    if (!incoming || typeof incoming !== 'object') return res.status(400).json({ message: 'flags wajib berupa objek' });
    const a: any = (req as any).admin ?? {};
    const changed: string[] = [];
    for (const [key, val] of Object.entries(incoming)) {
      if (!DEFAULT_FLAGS.find((f) => f.key === key)) continue;
      await pool.query(
        `UPDATE feature_flags SET enabled=$3, updated_by=$4, updated_at=now() WHERE company_id=$1 AND key=$2`,
        [req.admin.companyId, key, !!val, a.adminName ?? a.email ?? null]
      );
      changed.push(`${key}=${val ? 'ON' : 'OFF'}`);
    }
    await audit(req, 'FLAGS_UPDATE', { detail: changed.join(', ') || 'tidak ada perubahan' });
    res.json({ ok: true, message: 'Feature flags diperbarui', changed });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Tab 5: Shift & Jadwal ---
// Kolom tambahan shift: warna (untuk UI) & status aktif. Auto-migrate.
let shiftsExtraReady: Promise<any> | null = null;
function ensureShiftsExtra() {
  if (!shiftsExtraReady) {
    shiftsExtraReady = pool.query(`
      ALTER TABLE shifts ADD COLUMN IF NOT EXISTS color text;
      ALTER TABLE shifts ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;
      ALTER TABLE shifts ADD COLUMN IF NOT EXISTS office_location_id uuid;
    `);
  }
  return shiftsExtraReady;
}

// ==================== PENGATURAN PER LOKASI KANTOR (B75) ====================
// Shift & jadwal mengikuti lokasi kantor; pengaturan (toleransi telat, zona
// waktu, toleransi drift GPS, akurasi minimum) dapat diatur PER lokasi. Bila
// tidak diisi untuk lokasi tsb, otomatis memakai pengaturan perusahaan.
let locationSettingsReady: Promise<any> | null = null;
function ensureLocationSettings() {
  if (!locationSettingsReady) {
    locationSettingsReady = pool.query(`
      CREATE TABLE IF NOT EXISTS office_location_settings (
        location_id uuid PRIMARY KEY REFERENCES office_locations(id) ON DELETE CASCADE,
        company_id uuid NOT NULL,
        late_grace_minutes integer,
        timezone text,
        gps_drift_tolerance_meters integer,
        minimum_accuracy_meters integer,
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_ols_company ON office_location_settings (company_id);
    `);
  }
  return locationSettingsReady;
}

/**
 * Pengaturan EFEKTIF sebuah lokasi: nilai khusus lokasi bila ada, jika tidak
 * memakai pengaturan perusahaan (companies). Selalu mengembalikan angka penuh.
 */
async function resolveLocationSettings(companyId: string, locationId: string | null | undefined) {
  await ensureLocationSettings();
  await ensureCompanySettings();
  const c = (await pool.query(
    `SELECT late_grace_minutes, timezone, gps_drift_tolerance_meters, minimum_location_accuracy_meters
     FROM companies WHERE id=$1`, [companyId]
  )).rows[0] || {};
  let over: any = null;
  if (locationId) {
    over = (await pool.query(
      `SELECT late_grace_minutes, timezone, gps_drift_tolerance_meters, minimum_accuracy_meters
       FROM office_location_settings WHERE location_id=$1 AND company_id=$2 LIMIT 1`, [locationId, companyId]
    )).rows[0] || null;
  }
  const numOr = (v: any, f: any) => (Number.isFinite(Number(v)) ? Number(v) : f);
  return {
    lateGraceMinutes: over?.late_grace_minutes != null ? numOr(over.late_grace_minutes, c.late_grace_minutes) : numOr(c.late_grace_minutes, 0),
    timezone: (over?.timezone && String(over.timezone)) || c.timezone || 'Asia/Jakarta',
    gpsDriftToleranceMeters: over?.gps_drift_tolerance_meters != null ? numOr(over.gps_drift_tolerance_meters, c.gps_drift_tolerance_meters) : numOr(c.gps_drift_tolerance_meters, 75),
    minimumAccuracyMeters: over?.minimum_accuracy_meters != null ? numOr(over.minimum_accuracy_meters, c.minimum_location_accuracy_meters) : numOr(c.minimum_location_accuracy_meters, 80),
    overrides: {
      lateGraceMinutes: over?.late_grace_minutes != null,
      timezone: !!(over?.timezone && String(over.timezone)),
      gpsDriftToleranceMeters: over?.gps_drift_tolerance_meters != null,
      minimumAccuracyMeters: over?.minimum_accuracy_meters != null,
    },
  };
}

const SHIFT_PALETTE = ['#036D19', '#1D6FB8', '#F85800', '#7A3FB5', '#B8860B', '#0E7490', '#2E8B57', '#B34A6B'];

app.get('/api/admin/shifts', adminAuth, async (req, res) => {
  try {
    await ensureShiftsExtra();
    const rows = (await pool.query(
      `SELECT s.id, s.name, s.start_time, s.end_time, s.color, s.active, s.office_location_id,
              ol.name AS office_location_name,
              (SELECT COUNT(*) FROM employees e WHERE e.shift_id = s.id AND e.active = true) AS employee_count
       FROM shifts s LEFT JOIN office_locations ol ON ol.id = s.office_location_id
       WHERE s.company_id = $1 ORDER BY s.active DESC, s.start_time`, [req.admin.companyId]
    )).rows;
    const items = rows.map((r, i) => ({
      id: r.id, name: r.name, startTime: toTimeStr(r.start_time), endTime: toTimeStr(r.end_time),
      color: r.color || SHIFT_PALETTE[i % SHIFT_PALETTE.length], active: r.active !== false,
      officeLocationId: r.office_location_id ?? null,
      officeLocationName: r.office_location_name ?? null,
      employeeCount: Number(r.employee_count)
    }));
    res.json({ items, shifts: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/admin/shifts', adminAuth, async (req, res) => {
  try {
    await ensureShiftsExtra();
    const b = req.body ?? {};
    const name = String(b.name ?? '').trim();
    const startTime = String(b.startTime ?? '');
    const endTime = String(b.endTime ?? '');
    if (!name || !startTime || !endTime) return res.status(400).json({ message: 'Nama dan jam shift wajib diisi' });
    const color = String(b.color ?? '').trim() || SHIFT_PALETTE[Math.floor(Math.random() * SHIFT_PALETTE.length)];
    const active = typeof b.active === 'boolean' ? b.active : true;
    const officeLocationId = b.officeLocationId ? String(b.officeLocationId) : null;
    const row = (await pool.query(
      `INSERT INTO shifts (company_id, name, start_time, end_time, color, active, office_location_id) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [req.admin.companyId, name, startTime, endTime, color, active, officeLocationId]
    )).rows[0];
    res.json({ id: row.id, message: 'Shift ditambahkan' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.put('/api/admin/shifts/:id', adminAuth, async (req, res) => {
  try {
    await ensureShiftsExtra();
    const b = req.body ?? {};
    const row = (await pool.query(
      `UPDATE shifts SET
        name = COALESCE($3, name),
        start_time = COALESCE($4, start_time),
        end_time = COALESCE($5, end_time),
        color = COALESCE($6, color),
        active = COALESCE($7, active),
        office_location_id = CASE WHEN $8 THEN $9::uuid ELSE office_location_id END
       WHERE id = $1 AND company_id = $2 RETURNING id`,
      [req.params.id, req.admin.companyId, b.name ?? null, b.startTime ?? null, b.endTime ?? null,
       (b.color != null ? String(b.color) : null), (typeof b.active === 'boolean' ? b.active : null),
       (b.officeLocationId !== undefined), (b.officeLocationId ? String(b.officeLocationId) : null)]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Shift tidak ditemukan' });
    res.json({ message: 'Shift diperbarui' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.delete('/api/admin/shifts/:id', adminAuth, async (req, res) => {
  try {
    await ensureScheduleTable();
    // Lepas dari shift default karyawan DAN jadwal harian, agar tidak ada
    // referensi menggantung (jadwal menunjuk shift yang sudah terhapus).
    await pool.query(`UPDATE employees SET shift_id=NULL WHERE shift_id=$1`, [req.params.id]);
    await pool.query(`DELETE FROM employee_schedules WHERE shift_id=$1`, [req.params.id]);
    const row = (await pool.query(`DELETE FROM shifts WHERE id=$1 AND company_id=$2 RETURNING id`, [req.params.id, req.admin.companyId])).rows[0];
    if (!row) return res.status(404).json({ message: 'Shift tidak ditemukan' });
    res.json({ message: 'Shift dihapus' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});


// ==================== ADMIN: PENGATURAN PER LOKASI KANTOR (B75) ====================
// Shift & jadwal mengikuti lokasi kantor. Pengaturan (toleransi telat, zona
// waktu, drift GPS, akurasi minimum) dapat diatur per lokasi; kosong = warisi
// pengaturan perusahaan.

app.get('/api/admin/location-settings', adminAuth, async (req, res) => {
  try {
    await ensureLocationSettings();
    await ensureOfficeLocations();
    const locs = (await pool.query(
      `SELECT id, name, is_default FROM office_locations WHERE company_id=$1 ORDER BY is_default DESC, created_at`,
      [req.admin.companyId]
    )).rows;
    const items: any[] = [];
    for (const l of locs) {
      const eff = await resolveLocationSettings(req.admin.companyId, l.id);
      items.push({
        locationId: l.id, locationName: l.name, isDefault: !!l.is_default,
        lateGraceMinutes: eff.lateGraceMinutes, timezone: eff.timezone,
        gpsDriftToleranceMeters: eff.gpsDriftToleranceMeters,
        minimumAccuracyMeters: eff.minimumAccuracyMeters,
        overrides: eff.overrides,
      });
    }
    res.json({ items, locations: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.put('/api/admin/location-settings/:locationId', adminAuth, async (req, res) => {
  try {
    await ensureLocationSettings();
    const b = req.body ?? {};
    const locId = String(req.params.locationId);
    const intOrNull = (v: any) => (v === null || v === undefined || v === '' ? null : (Number.isFinite(Number(v)) ? Math.round(Number(v)) : null));
    const tzOrNull = (v: any) => (v == null || String(v).trim() === '' ? null : String(v).trim());
    await pool.query(
      `INSERT INTO office_location_settings
         (location_id, company_id, late_grace_minutes, timezone, gps_drift_tolerance_meters, minimum_accuracy_meters, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6, now())
       ON CONFLICT (location_id) DO UPDATE SET
         late_grace_minutes = EXCLUDED.late_grace_minutes,
         timezone = EXCLUDED.timezone,
         gps_drift_tolerance_meters = EXCLUDED.gps_drift_tolerance_meters,
         minimum_accuracy_meters = EXCLUDED.minimum_accuracy_meters,
         updated_at = now()`,
      [locId, req.admin.companyId, intOrNull(b.lateGraceMinutes), tzOrNull(b.timezone),
       intOrNull(b.gpsDriftToleranceMeters), intOrNull(b.minimumAccuracyMeters)]
    );
    const eff = await resolveLocationSettings(req.admin.companyId, locId);
    res.json({ ok: true, message: 'Pengaturan lokasi disimpan', data: eff });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.delete('/api/admin/location-settings/:locationId', adminAuth, async (req, res) => {
  try {
    await ensureLocationSettings();
    await pool.query(`DELETE FROM office_location_settings WHERE location_id=$1 AND company_id=$2`,
      [String(req.params.locationId), req.admin.companyId]);
    res.json({ ok: true, message: 'Pengaturan lokasi dikembalikan ke bawaan perusahaan' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// Ringkasan "Setup Lokasi": lokasi + pengaturan + jumlah shift + jumlah karyawan.
app.get('/api/admin/location-setup', adminAuth, async (req, res) => {
  try {
    await ensureShiftsExtra();
    await ensureOfficeLocations();
    const locs = (await pool.query(
      `SELECT id, name, address, radius_meters, minimum_accuracy_meters, is_default, active
       FROM office_locations WHERE company_id=$1 ORDER BY is_default DESC, created_at`,
      [req.admin.companyId]
    )).rows;
    const items: any[] = [];
    for (const l of locs) {
      const eff = await resolveLocationSettings(req.admin.companyId, l.id);
      const sc = (await pool.query(`SELECT COUNT(*)::int AS n FROM shifts WHERE company_id=$1 AND office_location_id=$2`, [req.admin.companyId, l.id])).rows[0];
      const ec = (await pool.query(`SELECT COUNT(*)::int AS n FROM employees WHERE company_id=$1 AND office_location_id=$2 AND active=true`, [req.admin.companyId, l.id])).rows[0];
      items.push({
        locationId: l.id, locationName: l.name, address: l.address ?? null, isDefault: !!l.is_default,
        radiusMeters: Math.round(Number(l.radius_meters) || 100),
        minimumAccuracyMeters: eff.minimumAccuracyMeters,
        lateGraceMinutes: eff.lateGraceMinutes, timezone: eff.timezone,
        gpsDriftToleranceMeters: eff.gpsDriftToleranceMeters,
        shiftCount: Number(sc?.n || 0), employeeCount: Number(ec?.n || 0),
        overrides: eff.overrides,
      });
    }
    res.json({ items, locations: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// Terapkan pengaturan lokasi ke SELURUH karyawan lokasi tsb (shift default).
app.post('/api/admin/location-setup/:locationId/apply', adminAuth, async (req, res) => {
  try {
    await ensureShiftsExtra();
    const locId = String(req.params.locationId);
    const shiftId = req.body?.defaultShiftId ? String(req.body.defaultShiftId) : null;
    let n = 0;
    if (shiftId) {
      const r = await pool.query(
        `UPDATE employees SET shift_id=$3, updated_at=now()
         WHERE company_id=$1 AND office_location_id=$2 AND active=true RETURNING id`,
        [req.admin.companyId, locId, shiftId]
      );
      n = r.rowCount || 0;
    }
    res.json({ ok: true, updated: n, message: n > 0 ? `Shift default diterapkan ke ${n} karyawan` : 'Tidak ada perubahan' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// ==================== ADMIN: KELUHAN / SARAN (ANONIM) ====================
// GET daftar keluhan (filter status/kategori/q + ringkasan).
app.get('/api/admin/complaints', adminAuth, async (req, res) => {
  try {
    await ensureComplaintTable();
    const status = String(req.query.status ?? '').trim().toUpperCase();
    const category = String(req.query.category ?? '').trim().toUpperCase();
    const q = String(req.query.q ?? '').trim();
    const params: any[] = [req.admin.companyId];
    let where = `(company_id = $1 OR company_id IS NULL)`;
    if (COMPLAINT_STATUSES.includes(status)) { params.push(status); where += ` AND status = $${params.length}`; }
    if (COMPLAINT_CATEGORIES.includes(category)) { params.push(category); where += ` AND category = $${params.length}`; }
    if (q) { params.push(`%${q}%`); where += ` AND (message ILIKE $${params.length} OR COALESCE(subject,'') ILIKE $${params.length})`; }
    const rows = (await pool.query(
      `SELECT id, category, subject, message, sender_name, status, admin_note, handled_by,
              to_char(handled_at,'YYYY-MM-DD"T"HH24:MI:SSOF') AS handled_at,
              to_char(created_at,'YYYY-MM-DD"T"HH24:MI:SSOF') AS created_at
       FROM complaints WHERE ${where} ORDER BY created_at DESC LIMIT 500`, params
    )).rows;
    const stat = (await pool.query(
      `SELECT
         COUNT(*)::int AS total,
         COUNT(*) FILTER (WHERE status='BARU')::int AS baru,
         COUNT(*) FILTER (WHERE status='DIBACA')::int AS dibaca,
         COUNT(*) FILTER (WHERE status='DITINDAKLANJUTI')::int AS ditindak,
         COUNT(*) FILTER (WHERE status='SELESAI')::int AS selesai
       FROM complaints WHERE (company_id = $1 OR company_id IS NULL)`, [req.admin.companyId]
    )).rows[0];
    const items = rows.map((r) => ({
      id: r.id, category: r.category, subject: r.subject ?? null, message: r.message,
      status: r.status, adminNote: r.admin_note ?? null, handledBy: r.handled_by ?? null,
      senderName: r.sender_name ?? null, handledAt: r.handled_at ?? null, createdAt: r.created_at,
    }));
    res.json({ items, complaints: items, stats: {
      total: Number(stat.total), baru: Number(stat.baru), dibaca: Number(stat.dibaca),
      ditindak: Number(stat.ditindak), selesai: Number(stat.selesai),
    }, categories: COMPLAINT_CATEGORIES, statuses: COMPLAINT_STATUSES });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// PATCH: ubah status + catatan internal admin (opsional).
app.patch('/api/admin/complaints/:id', adminAuth, async (req, res) => {
  try {
    await ensureComplaintTable();
    const b = req.body ?? {};
    let status: string | null = b.status != null ? String(b.status).trim().toUpperCase() : null;
    if (status && !COMPLAINT_STATUSES.includes(status)) return res.status(400).json({ message: 'Status tidak valid' });
    const note = b.adminNote != null ? String(b.adminNote).slice(0, 2000) : null;
    const row = (await pool.query(
      `UPDATE complaints SET
         status = COALESCE($3, status),
         admin_note = COALESCE($4, admin_note),
         handled_by = CASE WHEN $3 IS NOT NULL OR $4 IS NOT NULL THEN $5 ELSE handled_by END,
         handled_at = CASE WHEN $3 IS NOT NULL OR $4 IS NOT NULL THEN now() ELSE handled_at END
       WHERE id = $1 AND (company_id = $2 OR company_id IS NULL) RETURNING id`,
      [String(req.params.id), req.admin.companyId, status, note, (req as any).admin?.adminName ?? 'Admin']
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Keluhan tidak ditemukan' });
    await audit(req, 'COMPLAINT_UPDATE', { target: String(req.params.id), detail: `status=${status ?? '-'}` });
    res.json({ message: 'Keluhan diperbarui' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// DELETE: hapus satu keluhan.
app.delete('/api/admin/complaints/:id', adminAuth, async (req, res) => {
  try {
    await ensureComplaintTable();
    const row = (await pool.query(
      `DELETE FROM complaints WHERE id=$1 AND (company_id=$2 OR company_id IS NULL) RETURNING id`,
      [String(req.params.id), req.admin.companyId]
    )).rows[0];
    if (!row) return res.status(404).json({ message: 'Keluhan tidak ditemukan' });
    await audit(req, 'COMPLAINT_DELETE', { target: String(req.params.id) });
    res.json({ message: 'Keluhan dihapus' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// --- Kolom tambahan (auto-migrate) ---
let lateColumnReady: Promise<any> | null = null;
function ensureLateColumn() {
  if (!lateColumnReady) {
    lateColumnReady = pool.query(`
      ALTER TABLE attendance ADD COLUMN IF NOT EXISTS late_minutes integer NOT NULL DEFAULT 0;
      ALTER TABLE attendance ADD COLUMN IF NOT EXISTS late_overridden boolean NOT NULL DEFAULT false;
    `);
  }
  return lateColumnReady;
}

// Kolom tambahan agar absensi TETAP TERCATAT walau GPS lemah, di luar radius,
// atau dikirim dari ANTRIAN OFFLINE. Prinsip: kehadiran karyawan tidak boleh
// hilang hanya karena sinyal/HP bermasalah — cukup ditandai untuk ditinjau admin.
//  - geo_status          : OK | LOW_ACCURACY | OUTSIDE_RADIUS | OUTSIDE_RADIUS_FAR
//  - verification_status : NONE | NEEDED | VERIFIED | REJECTED
//  - offline_sync        : true bila baris ini hasil sinkron dari antrian offline
let geoTolerantReady: Promise<any> | null = null;
function ensureGeoTolerantColumns() {
  if (!geoTolerantReady) {
    geoTolerantReady = pool.query(`
      ALTER TABLE attendance ADD COLUMN IF NOT EXISTS geo_status text NOT NULL DEFAULT 'OK';
      ALTER TABLE attendance ADD COLUMN IF NOT EXISTS verification_status text NOT NULL DEFAULT 'NONE';
      ALTER TABLE attendance ADD COLUMN IF NOT EXISTS offline_sync boolean NOT NULL DEFAULT false;
    `);
  }
  return geoTolerantReady;
}

/**
 * MIGRASI MENYELURUH untuk kolom yang dipakai jalur KARYAWAN (B58 — PERBAIKAN BUG).
 *
 * KENAPA INI ADA:
 *   Rute `/api/attendance/today` MEMBACA kolom `geo_status`, `verification_status`,
 *   dan `offline_sync`, TETAPI tidak pernah memastikan kolomnya ada — hanya rute
 *   admin (/api/admin/attendance, /api/admin/attendance/flagged) yang memanggil
 *   `ensureGeoTolerantColumns()`. Pada database yang baru di-deploy, kolom itu
 *   belum ada, sehingga query karyawan gagal dengan:
 *       error: column "geo_status" does not exist  -> HTTP 500
 *
 *   Dampak nyata: aplikasi lama memanggil getTodayAttendance() → 500 → jatuh ke
 *   path cadangan `/attendance/today-status` → 404. Karyawan melihat notif
 *   "Endpoint tidak ditemukan: GET /api/attendance/today-status" dan halaman
 *   Absen gagal dimuat, walau sesi & login sebenarnya SEHAT.
 *
 *   Sekarang SETIAP rute yang menyentuh kolom tersebut memanggil helper ini,
 *   sehingga tabel selalu siap walaupun hanya jalur karyawan yang diakses.
 */
function ensureAttendanceColumnsAll() {
  return Promise.all([
    ensureLateColumn(),
    ensureGeoTolerantColumns(),
    ensureScheduleTable(),
    ensureCompanySettings(),
  ]);
}

// Kolom read_by (array teks) untuk melacak karyawan yang sudah membaca/menutup
// notifikasi broadcast. Auto-migrate agar tidak perlu intervensi manual.
let readColReady: Promise<any> | null = null;
function ensureReadCol() {
  if (!readColReady) {
    // Pastikan tabel notifications (beserta kolom read_by) benar-benar ada
    // sebelum endpoint karyawan menanyakannya — mencegah error 500 saat
    // tabel belum sempat dibuat.
    readColReady = ensureReleaseTable().then(() =>
      pool.query(`ALTER TABLE notifications ADD COLUMN IF NOT EXISTS read_by text[] NOT NULL DEFAULT '{}';`)
    );
  }
  return readColReady;
}

// --- Tabel rilis APK (dibuat otomatis bila belum ada) ---
let releaseTableReady: Promise<any> | null = null;
function ensureReleaseTable() {
  if (!releaseTableReady) {
    releaseTableReady = pool.query(`
      CREATE TABLE IF NOT EXISTS app_releases (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid REFERENCES companies(id) ON DELETE CASCADE,
        version_name text NOT NULL,
        version_code integer NOT NULL,
        apk_url text NOT NULL,
        mandatory boolean NOT NULL DEFAULT false,
        notes text,
        active boolean NOT NULL DEFAULT true,
        download_count integer NOT NULL DEFAULT 0,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS device_tokens (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        employee_id uuid REFERENCES employees(id) ON DELETE CASCADE,
        token text NOT NULL UNIQUE,
        platform text NOT NULL DEFAULT 'android',
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS notifications (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid REFERENCES companies(id) ON DELETE CASCADE,
        employee_id uuid REFERENCES employees(id) ON DELETE CASCADE,
        title text NOT NULL,
        body text,
        kind text NOT NULL DEFAULT 'INFO',
        read boolean NOT NULL DEFAULT false,
        read_by text[] NOT NULL DEFAULT '{}',
        created_at timestamptz NOT NULL DEFAULT now()
      );
    `);
  }
  return releaseTableReady;
}

async function pushNotification(companyId: string, employeeId: string | null, title: string, body: string, kind = 'INFO') {
  try {
    await ensureReleaseTable();
    await pool.query(
      `INSERT INTO notifications (company_id, employee_id, title, body, kind) VALUES ($1,$2,$3,$4,$5)`,
      [companyId, employeeId, title, body, kind]
    );
  } catch (error) {
    console.error('pushNotification gagal:', error);
  }
}

// --- Jadwal karyawan mingguan (per-hari shift) ---
// Tabel dibuat otomatis saat pertama dipakai (tanpa perlu migrasi manual).
let scheduleTableReady: Promise<any> | null = null;
function ensureScheduleTable() {
  if (!scheduleTableReady) {
    scheduleTableReady = pool.query(`
      CREATE TABLE IF NOT EXISTS employee_schedules (
        company_id uuid NOT NULL,
        employee_id uuid NOT NULL,
        date date NOT NULL,
        shift_id uuid,
        note text,
        updated_at timestamptz NOT NULL DEFAULT now(),
        PRIMARY KEY (employee_id, date)
      );
    `);
  }
  return scheduleTableReady;
}

// GET jadwal satu minggu untuk seluruh karyawan (dipakai Tab Shift & Jadwal).
app.get('/api/admin/schedule', adminAuth, async (req, res) => {
  try {
    await ensureScheduleTable();
    const weekStart = normalizeWeekStart(String(req.query.weekStart ?? ''));
    const weekEnd = addDays(weekStart, 6);
    const employees = (await pool.query(
      `SELECT e.id, e.employee_code, e.full_name, e.position, e.avatar_color, e.photo_base64, e.shift_id,
              e.office_location_id, ol.name AS office_name,
              s.name AS shift_name, s.start_time, s.end_time, s.office_location_id AS shift_office_location_id
       FROM employees e
       LEFT JOIN shifts s ON s.id = e.shift_id
       LEFT JOIN office_locations ol ON ol.id = e.office_location_id
       WHERE e.company_id = $1 AND e.active = true ORDER BY e.employee_code`, [req.admin.companyId]
    )).rows;
    const schedRows = (await pool.query(
      `SELECT employee_id, to_char(date,'YYYY-MM-DD') AS d, shift_id, note
       FROM employee_schedules WHERE company_id = $1 AND date BETWEEN $2::date AND $3::date`,
      [req.admin.companyId, weekStart, weekEnd]
    )).rows;
    const byEmp: Record<string, Record<string, any>> = {};
    for (const r of schedRows) {
      (byEmp[r.employee_id] ||= {})[r.d] = { shiftId: r.shift_id || null, note: r.note || null };
    }
    const items = employees.map((e) => ({
      employeeId: e.id, employeeCode: e.employee_code, fullName: e.full_name,
      position: e.position, avatarColor: e.avatar_color, photoBase64: e.photo_base64 ?? null,
      officeLocationId: e.office_location_id ?? null,
      officeLocationName: e.office_name ?? null,
      defaultShiftId: e.shift_id || null, defaultShiftName: e.shift_name || null,
      defaultShiftStart: toTimeStr(e.start_time) || '', defaultShiftEnd: toTimeStr(e.end_time) || '',
      defaultShiftOfficeLocationId: e.shift_office_location_id ?? null,
      days: byEmp[e.id] || {},
    }));
    res.json({ weekStart, weekEnd, items, employees: items });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

// PUT jadwal: simpan perubahan beberapa sel {employeeId, date, shiftId, note}.
app.put('/api/admin/schedule', adminAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    await ensureScheduleTable();
    const body = req.body ?? {};
    // Dukung bentuk lama { assignments:[{employeeId, shiftId}] } -> set shift default.
    let entries: any[] = Array.isArray(body.entries) ? body.entries : [];
    if (entries.length === 0 && Array.isArray(body.assignments)) {
      for (const a of body.assignments) {
        if (!a?.employeeId) continue;
        await client.query(
          `UPDATE employees SET shift_id = $3, updated_at = now() WHERE id = $1 AND company_id = $2`,
          [a.employeeId, req.admin.companyId, a.shiftId ?? null]
        );
      }
      return res.json({ message: 'Jadwal default tersimpan', count: body.assignments.length });
    }
    await client.query('BEGIN');
    let count = 0;
    for (const e of entries) {
      if (!e?.employeeId || !e?.date) continue;
      const note = e.note === 'OFF' ? 'OFF' : null;
      const shiftId = e.shiftId || null;
      // Verifikasi karyawan milik perusahaan ini.
      const ok = await client.query(`SELECT 1 FROM employees WHERE id=$1 AND company_id=$2`, [e.employeeId, req.admin.companyId]);
      if (!ok.rowCount) continue;
      if (!shiftId && !note) {
        await client.query(
          `DELETE FROM employee_schedules WHERE employee_id=$1 AND date=$2`, [e.employeeId, e.date]
        );
      } else {
        await client.query(
          `INSERT INTO employee_schedules (company_id, employee_id, date, shift_id, note, updated_at)
           VALUES ($1,$2,$3::date,$4,$5, now())
           ON CONFLICT (employee_id, date)
           DO UPDATE SET shift_id=EXCLUDED.shift_id, note=EXCLUDED.note, updated_at=now()`,
          [req.admin.companyId, e.employeeId, e.date, shiftId, note]
        );
      }
      count++;
    }
    await client.query('COMMIT');
    res.json({ message: 'Jadwal mingguan tersimpan', count });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    console.error(error); res.status(500).json({ message: 'Server error' });
  } finally { client.release(); }
});

// POST /api/admin/schedule/fill-default — isi otomatis jadwal mingguan
// dengan SHIFT DEFAULT tiap karyawan (Senin–Sabtu), melewati karyawan tanpa
// shift default. Jadwal harian yang sudah ada TIDAK ditimpa kecuali replace=true.
app.post('/api/admin/schedule/fill-default', adminAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    await ensureScheduleTable();
    const b = req.body ?? {};
    const weekStart = normalizeWeekStart(String(b.weekStart ?? ''));
    const replace = b.replace === true;
    const workdays = [0, 1, 2, 3, 4, 5]; // Senin–Sabtu
    const employees = (await client.query(
      `SELECT id, shift_id FROM employees WHERE company_id=$1 AND active=true AND shift_id IS NOT NULL`,
      [req.admin.companyId]
    )).rows;
    let count = 0;
    await client.query('BEGIN');
    for (const e of employees) {
      for (const d of workdays) {
        const date = addDays(weekStart, d);
        if (!replace) {
          const ex = await client.query(`SELECT 1 FROM employee_schedules WHERE employee_id=$1 AND date=$2::date`, [e.id, date]);
          if (ex.rowCount) continue;
        }
        await client.query(
          `INSERT INTO employee_schedules (company_id, employee_id, date, shift_id, note, updated_at)
           VALUES ($1,$2,$3::date,$4,NULL, now())
           ON CONFLICT (employee_id, date) DO UPDATE SET shift_id=EXCLUDED.shift_id, note=EXCLUDED.note, updated_at=now()`,
          [req.admin.companyId, e.id, date, e.shift_id]
        );
        count++;
      }
    }
    await client.query('COMMIT');
    res.json({ ok: true, count, message: `${count} slot jadwal diisi dari shift default` });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    console.error(error); res.status(500).json({ message: 'Server error' });
  } finally { client.release(); }
});

// POST /api/admin/schedule/copy-week — salin jadwal dari satu minggu ke minggu lain.
app.post('/api/admin/schedule/copy-week', adminAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    await ensureScheduleTable();
    const b = req.body ?? {};
    const fromWeek = normalizeWeekStart(String(b.fromWeek ?? ''));
    const toWeek = normalizeWeekStart(String(b.toWeek ?? ''));
    if (fromWeek === toWeek) return res.status(400).json({ message: 'Minggu sumber & tujuan sama' });
    const replace = b.replace === true;
    const rows = (await client.query(
      `SELECT employee_id, date, shift_id, note FROM employee_schedules
       WHERE company_id=$1 AND date BETWEEN $2::date AND $3::date`,
      [req.admin.companyId, fromWeek, addDays(fromWeek, 6)]
    )).rows;
    if (replace) {
      await client.query(`DELETE FROM employee_schedules WHERE company_id=$1 AND date BETWEEN $2::date AND $3::date`, [req.admin.companyId, toWeek, addDays(toWeek, 6)]);
    }
    let count = 0;
    await client.query('BEGIN');
    for (const r of rows) {
      const src = toDateStr(r.date);
      const dowIdx = (new Date(src + 'T00:00:00Z').getUTCDay() + 6) % 7; // 0=Senin
      const target = addDays(toWeek, dowIdx);
      if (!replace) {
        const ex = await client.query(`SELECT 1 FROM employee_schedules WHERE employee_id=$1 AND date=$2::date`, [r.employee_id, target]);
        if (ex.rowCount) continue;
      }
      await client.query(
        `INSERT INTO employee_schedules (company_id, employee_id, date, shift_id, note, updated_at)
         VALUES ($1,$2,$3::date,$4,$5, now())
         ON CONFLICT (employee_id, date) DO UPDATE SET shift_id=EXCLUDED.shift_id, note=EXCLUDED.note, updated_at=now()`,
        [req.admin.companyId, r.employee_id, target, r.shift_id, r.note]
      );
      count++;
    }
    await client.query('COMMIT');
    res.json({ ok: true, count, message: `${count} slot jadwal disalin` });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    console.error(error); res.status(500).json({ message: 'Server error' });
  } finally { client.release(); }
});

// ==================== IMPORT JADWAL DARI EXCEL (Shift & Jadwal) ====================
// Menerima matriks jadwal bulanan (hasil pembacaan Excel di sisi klien):
//   rows: [{ name, days: { "YYYY-MM-DD": "P" | "S" | "OFF" | "" } }]
// Kode sel dipetakan ke SHIFT berdasarkan NAMA shift (default: "Pagi" / "Siang"),
// atau dapat disetel lewat body.codes = { "P": "<shiftId>", "S": "<shiftId>" }.
// Sel "OFF"/"L" -> libur; sel kosong -> dilewati (tidak mengubah).
app.post('/api/admin/schedule/import', adminAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    await ensureScheduleTable();
    await ensureShiftsExtra();
    const b = req.body ?? {};
    const rows: any[] = Array.isArray(b.rows) ? b.rows : [];
    if (rows.length === 0) return res.status(400).json({ message: 'Tidak ada baris jadwal untuk diimpor' });
    const replace = b.replace === true; // bila true: hapus jadwal lama pada rentang, lalu isi ulang

    // Muat shift perusahaan (untuk pemetaan kode -> shiftId).
    const shifts = (await client.query(
      `SELECT id, lower(name) AS lname, name FROM shifts WHERE company_id=$1 AND active IS NOT FALSE`,
      [req.admin.companyId]
    )).rows;
    const shiftByLname = new Map<string, string>();
    for (const s of shifts) shiftByLname.set(String(s.lname), s.id);

    // Daftar karyawan aktif (dicocokkan via NAMA, fallback ke kode karyawan).
    const emps = (await client.query(
      `SELECT id, lower(full_name) AS lname, employee_code FROM employees WHERE company_id=$1 AND active=true`,
      [req.admin.companyId]
    )).rows;
    const empByLname = new Map<string, string>();
    const empByCode = new Map<string, string>();
    for (const e of emps) { empByLname.set(String(e.lname).trim(), e.id); empByCode.set(String(e.employee_code).trim().toLowerCase(), e.id); }

    // Pemetaan kode sel -> shiftId. Prioritas: body.codes -> nama shift (Pagi/Siang) -> shift pertama.
    const customCodes: Record<string, string> = (b.codes && typeof b.codes === 'object') ? b.codes : {};
    const firstShiftId = shifts[0]?.id ?? null;
    function resolveShift(codeRaw: string): string | null {
      const code = String(codeRaw || '').trim();
      if (!code) return null;
      const up = code.toUpperCase();
      // 1) pemetaan eksplisit dari klien (mis. {"P": "<uuid>", "S": "<uuid>"})
      for (const k of Object.keys(customCodes)) {
        if (k.toUpperCase() === up && customCodes[k]) return customCodes[k];
      }
      // 2) cocokkan nama shift (mis. "P" -> shift bernama "Pagi"/"P")
      const lname = code.toLowerCase();
      if (shiftByLname.has(lname)) return shiftByLname.get(lname)!;
      const alias: Record<string, string> = { p: 'pagi', s: 'siang', m: 'malam', sore: 'sore', pagi: 'pagi', siang: 'siang', malam: 'malam' };
      const target = alias[lname];
      if (target && shiftByLname.has(target)) return shiftByLname.get(target)!;
      // 3) fallback: shift pertama (hanya untuk kode yang jelas bukan OFF/L)
      if (!['OFF', 'L', 'LIBUR', 'X'].includes(up)) return firstShiftId;
      return null;
    }
    function isOff(codeRaw: string): boolean {
      const up = String(codeRaw || '').trim().toUpperCase();
      return ['OFF', 'L', 'LIBUR', 'X', 'O'].includes(up);
    }

    const inserted: { employeeId: string; date: string; shiftId: string | null; note: string | null }[] = [];
    const unmatched: string[] = [];
    let minDate: string | null = null, maxDate: string | null = null;
    for (const r of rows) {
      const rawName = String(r?.name ?? '').trim();
      if (!rawName) continue;
      const empId = empByLname.get(rawName.toLowerCase()) || empByCode.get(rawName.toLowerCase());
      if (!empId) { unmatched.push(rawName); continue; }
      const days = (r?.days && typeof r.days === 'object') ? r.days : {};
      for (const date of Object.keys(days)) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) continue;
        const code = String(days[date] ?? '').trim();
        if (!code) continue; // sel kosong -> lewati
        if (!minDate || date < minDate) minDate = date;
        if (!maxDate || date > maxDate) maxDate = date;
        if (isOff(code)) {
          inserted.push({ employeeId: empId, date, shiftId: null, note: 'OFF' });
        } else {
          const sid = resolveShift(code);
          if (sid) inserted.push({ employeeId: empId, date, shiftId: sid, note: null });
        }
      }
    }
    if (inserted.length === 0) {
      return res.status(400).json({ message: 'Tidak ada sel jadwal yang cocok. Periksa nama karyawan & kode sel (P/S/OFF).', unmatched });
    }

    await client.query('BEGIN');
    if (replace && minDate && maxDate) {
      await client.query(
        `DELETE FROM employee_schedules WHERE company_id=$1 AND date BETWEEN $2::date AND $3::date`,
        [req.admin.companyId, minDate, maxDate]
      );
    }
    let count = 0;
    for (const it of inserted) {
      await client.query(
        `INSERT INTO employee_schedules (company_id, employee_id, date, shift_id, note, updated_at)
         VALUES ($1,$2,$3::date,$4,$5, now())
         ON CONFLICT (employee_id, date)
         DO UPDATE SET shift_id=EXCLUDED.shift_id, note=EXCLUDED.note, updated_at=now()`,
        [req.admin.companyId, it.employeeId, it.date, it.shiftId, it.note]
      );
      count++;
    }
    await client.query('COMMIT');
    await audit(req, 'SCHEDULE_IMPORT', { detail: `${count} slot dari Excel (${minDate}..${maxDate})` });
    res.json({
      ok: true, count, matchedEmployees: rows.length - unmatched.length,
      period: { from: minDate, to: maxDate }, unmatched,
      message: `${count} slot jadwal diimpor dari Excel` + (unmatched.length ? ` • ${unmatched.length} nama tak cocok` : ''),
    });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    console.error(error); res.status(500).json({ message: 'Server error' });
  } finally { client.release(); }
});

// === HELPERS & EXPORT ===

interface AuthRequest extends express.Request { user: { employeeId: string; companyId: string; deviceId: string } }
function auth(req: express.Request, res: express.Response, next: express.NextFunction) {
  return employeeAuthentication(req, res, next);
}
function adminAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  return adminAuthentication(req, res, next);
}

/**
 * Guard khusus: hanya akun dengan role DEV yang boleh mengelola Rilis/Update
 * Aplikasi. Pertahanan berlapis — walaupun tab disembunyikan di UI, endpoint
 * tetap ditolak untuk role lain (mis. SUPERADMIN).
 */
function devOnly(req: express.Request, res: express.Response, next: express.NextFunction) {
  const role = String((req as any).admin?.role || '').toUpperCase();
  if (role !== 'DEV') return res.status(403).json({ message: 'Akses khusus developer diperlukan' });
  next();
}

/** Role yang boleh mengelola pengguna & akses (B6 RBAC). */
const MANAGE_ROLES = ['SUPERADMIN', 'DEV'];
function canManageUsers(role: any): boolean {
  return MANAGE_ROLES.includes(String(role || '').toUpperCase());
}

/**
 * Kolom persetujuan akun (idempotent). Akun hasil pendaftaran mandiri ("Daftar"
 * di Jurnal) berstatus PENDING (approved=false) sampai disetujui SUPERADMIN.
 * Akun lama & akun yang dibuat admin otomatis approved=true.
 */
let adminsApprovalReady: Promise<any> | null = null;
function ensureAdminApproval(pool: Pool) {
  if (!adminsApprovalReady) {
    adminsApprovalReady = pool
      .query(`
        ALTER TABLE admins ADD COLUMN IF NOT EXISTS approved boolean NOT NULL DEFAULT true;
        ALTER TABLE admins ADD COLUMN IF NOT EXISTS approved_at timestamptz;
        ALTER TABLE admins ADD COLUMN IF NOT EXISTS approved_by text;
      `)
      .catch((e) => { adminsApprovalReady = null; throw e; });
  }
  return adminsApprovalReady;
}

/**
 * B6: MANAJEMEN PENGGUNA & AKSES (RBAC).
 * Kelola akun admin/operator (SUPERADMIN/HR/MANAGER/DEV) + peran & statusnya.
 * Hanya SUPERADMIN & DEV yang boleh mengakses. Aturan pengaman:
 *  - Tidak boleh menghapus / menonaktifkan akun diri sendiri.
 *  - Minimal harus tersisa 1 SUPERADMIN aktif di perusahaan.
 *  - Akun DEV hanya boleh dikelola oleh DEV.
 */
app.get('/api/admin/users', adminAuth, async (req, res) => {
  try {
    await ensureAdminApproval(pool);
    if (!canManageUsers((req as any).admin.role)) return res.status(403).json({ message: 'Akses khusus manajemen pengguna diperlukan' });
    const rows = (await pool.query(
      `SELECT id, name, email, role, active, approved, created_at, updated_at FROM admins
       WHERE company_id=$1 AND role<>'REPORT_USER' ORDER BY (approved=false) DESC, (role='DEV') DESC, role, name`, [req.admin.companyId]
    )).rows;
    const items = rows.map((r: any) => ({
      id: r.id, name: r.name, email: r.email, role: r.role, active: r.active,
      approved: r.approved !== false,
      pending: r.approved === false,
      self: r.id === req.admin.adminId,
      createdAt: r.created_at?.toISOString?.() ?? null,
      updatedAt: r.updated_at?.toISOString?.() ?? null,
    }));
    res.json({ items, users: items, pendingCount: items.filter((u: any) => u.pending).length });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/admin/users', adminAuth, async (req, res) => {
  try {
    const me: any = (req as any).admin;
    if (!canManageUsers(me.role)) return res.status(403).json({ message: 'Akses khusus manajemen pengguna diperlukan' });
    const b = req.body ?? {};
    const name = String(b.name ?? '').trim();
    const email = String(b.email ?? '').trim().toLowerCase();
    const password = String(b.password ?? '');
    const role = String(b.role ?? 'HR').toUpperCase();
    if (!name || !email || !password) return res.status(400).json({ message: 'Nama, email, dan password wajib diisi' });
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ message: 'Format email tidak valid' });
    if (password.length < 6) return res.status(400).json({ message: 'Password minimal 6 karakter' });
    if (!['SUPERADMIN', 'HR', 'MANAGER', 'DEV'].includes(role)) return res.status(400).json({ message: 'Peran tidak valid' });
    if (role === 'DEV' && me.role !== 'DEV') return res.status(403).json({ message: 'Hanya developer dapat membuat akun developer' });
    const dupe = await pool.query(`SELECT 1 FROM admins WHERE email=$1`, [email]);
    if (dupe.rowCount) return res.status(409).json({ message: 'Email sudah dipakai akun lain' });
    const hash = await bcrypt.hash(password, 12);
    const row = (await pool.query(
      `INSERT INTO admins (company_id, name, email, password_hash, role, active, approved, approved_at, approved_by)
       VALUES ($1,$2,$3,$4,$5,true,true,now(),$6) RETURNING id`, [me.companyId, name, email, hash, role, me.email || 'admin']
    )).rows[0];
    await audit(req, 'USER_CREATE', { target: email, detail: `Buat akun ${role}: ${name}` });
    res.json({ id: row.id, message: 'Akun pengguna dibuat' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.put('/api/admin/users/:id', adminAuth, async (req, res) => {
  try {
    const me: any = (req as any).admin;
    if (!canManageUsers(me.role)) return res.status(403).json({ message: 'Akses khusus manajemen pengguna diperlukan' });
    const id = req.params.id;
    const b = req.body ?? {};
    const target = (await pool.query(`SELECT id, name, email, role, active FROM admins WHERE id=$1 AND company_id=$2`, [id, me.companyId])).rows[0];
    if (!target || target.role==='REPORT_USER') return res.status(404).json({ message: 'Pengguna tidak ditemukan' });
    if (target.role === 'DEV' && me.role !== 'DEV') return res.status(403).json({ message: 'Hanya developer dapat mengubah akun developer' });

    let role = target.role;
    if (b.role != null) {
      const nr = String(b.role).toUpperCase();
      if (!['SUPERADMIN', 'HR', 'MANAGER', 'DEV'].includes(nr)) return res.status(400).json({ message: 'Peran tidak valid' });
      if (nr === 'DEV' && me.role !== 'DEV') return res.status(403).json({ message: 'Hanya developer dapat menetapkan peran developer' });
      role = nr;
    }
    let active = target.active;
    if (typeof b.active === 'boolean') active = b.active;

    const isSelf = id === me.adminId;
    // Pengaman: tidak boleh menurunkan/menonaktifkan akun sendiri bila dia SUPERADMIN terakhir, dst.
    if (isSelf && (active === false || role !== target.role)) {
      // Untuk keamanan, cegah menonaktifkan diri sendiri.
      if (active === false) return res.status(400).json({ message: 'Tidak dapat menonaktifkan akun sendiri' });
    }
    // Pastikan minimal 1 SUPERADMIN aktif tersisa.
    if (target.role === 'SUPERADMIN' && (role !== 'SUPERADMIN' || active === false)) {
      const c = (await pool.query(`SELECT COUNT(*)::int AS n FROM admins WHERE company_id=$1 AND role='SUPERADMIN' AND active=true AND id<>$2`, [me.companyId, id])).rows[0];
      if (Number(c.n) < 1) return res.status(400).json({ message: 'Harus tersisa minimal satu SUPERADMIN aktif' });
    }

    const pwd = b.password != null && String(b.password).length > 0 ? String(b.password) : null;
    if (pwd && pwd.length < 6) return res.status(400).json({ message: 'Password minimal 6 karakter' });
    const hash = pwd ? await bcrypt.hash(pwd, 12) : null;

    // Ubah email akun (opsional). Normalisasi lowercase + cek duplikat.
    let email: string | null = null;
    if (b.email != null && String(b.email).trim() !== '') {
      const ne = String(b.email).trim().toLowerCase();
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(ne)) return res.status(400).json({ message: 'Format email tidak valid' });
      if (ne !== String(target.email).toLowerCase()) {
        const dupe = await pool.query(`SELECT 1 FROM admins WHERE email=$1 AND id<>$2`, [ne, id]);
        if (dupe.rowCount) return res.status(409).json({ message: 'Email sudah dipakai akun lain' });
        email = ne;
      }
    }

    await pool.query(
      `UPDATE admins SET
        name = COALESCE($3, name),
        email = COALESCE($7, email),
        role = $4,
        active = $5,
        password_hash = COALESCE($6, password_hash),
        updated_at = now()
       WHERE id=$1 AND company_id=$2`,
      [id, me.companyId, b.name != null ? String(b.name).trim() : null, role, active, hash, email]
    );
    await audit(req, 'USER_UPDATE', { target: email || target.email, detail: `Perbarui akun (peran: ${role}, status: ${active ? 'aktif' : 'nonaktif'})${email ? `, email: ${target.email} -> ${email}` : ''}${pwd ? ', reset password' : ''}` });
    res.json({ ok: true, email: email || target.email, message: 'Akun diperbarui' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

app.delete('/api/admin/users/:id', adminAuth, async (req, res) => {
  try {
    const me: any = (req as any).admin;
    if (!canManageUsers(me.role)) return res.status(403).json({ message: 'Akses khusus manajemen pengguna diperlukan' });
    const id = req.params.id;
    if (id === me.adminId) return res.status(400).json({ message: 'Tidak dapat menghapus akun sendiri' });
    const target = (await pool.query(`SELECT id, name, email, role FROM admins WHERE id=$1 AND company_id=$2`, [id, me.companyId])).rows[0];
    if (!target || target.role==='REPORT_USER') return res.status(404).json({ message: 'Pengguna tidak ditemukan' });
    if (target.role === 'DEV' && me.role !== 'DEV') return res.status(403).json({ message: 'Hanya developer dapat menghapus akun developer' });
    if (target.role === 'SUPERADMIN') {
      const c = (await pool.query(`SELECT COUNT(*)::int AS n FROM admins WHERE company_id=$1 AND role='SUPERADMIN' AND active=true AND id<>$2`, [me.companyId, id])).rows[0];
      if (Number(c.n) < 1) return res.status(400).json({ message: 'Harus tersisa minimal satu SUPERADMIN aktif' });
    }
    await pool.query(`DELETE FROM admins WHERE id=$1 AND company_id=$2`, [id, me.companyId]);
    await audit(req, 'USER_DELETE', { target: target.email, detail: `Hapus akun ${target.role}: ${target.name}` });
    res.json({ ok: true, message: 'Akun dihapus' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

/**
 * Setujui / tolak akun hasil pendaftaran mandiri ("Daftar" di Jurnal).
 * body.action = 'approve' (aktifkan) | 'reject' (hapus). Hanya SUPERADMIN/DEV.
 */
app.post('/api/admin/users/:id/approve', adminAuth, async (req, res) => {
  try {
    await ensureAdminApproval(pool);
    const me: any = (req as any).admin;
    if (!canManageUsers(me.role)) return res.status(403).json({ message: 'Akses khusus manajemen pengguna diperlukan' });
    const id = req.params.id;
    const action = String(req.body?.action || 'approve').toLowerCase();
    const target = (await pool.query(`SELECT id, name, email, role, approved FROM admins WHERE id=$1 AND company_id=$2`, [id, me.companyId])).rows[0];
    if (!target || target.role==='REPORT_USER') return res.status(404).json({ message: 'Pengguna tidak ditemukan' });

    if (action === 'reject' || action === 'delete') {
      if (id === me.adminId) return res.status(400).json({ message: 'Tidak dapat menghapus akun sendiri' });
      await pool.query(`DELETE FROM admins WHERE id=$1 AND company_id=$2`, [id, me.companyId]);
      await audit(req, 'USER_REJECT', { target: target.email, detail: `Tolak & hapus akun pendaftar: ${target.name}` });
      return res.json({ ok: true, rejected: true, message: 'Pendaftaran ditolak & akun dihapus' });
    }

    await pool.query(
      `UPDATE admins SET approved=true, approved_at=now(), approved_by=$3, updated_at=now()
       WHERE id=$1 AND company_id=$2`,
      [id, me.companyId, me.email || 'admin']
    );
    await audit(req, 'USER_APPROVE', { target: target.email, detail: `Setujui akun pendaftar: ${target.name}` });
    res.json({ ok: true, approved: true, message: 'Akun disetujui & kini dapat masuk' });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Server error' }); }
});

const AVATAR_COLORS = ['#036D19', '#F85800', '#1D6FB8', '#7A3FB5', '#B8860B', '#C74700', '#2E8B57', '#B34A6B'];
function pickColor(): string {
  return AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];
}

/**
 * Toleransi pergeseran GPS yang SUDAH DIBATASI (meter).
 *
 * GPS di dalam gedung bisa meleset puluhan meter, jadi absensi di tepi area
 * kantor wajar bila sedikit melewati radius. Namun toleransi TIDAK boleh
 * sebesar apa pun: dibatasi maksimum +150 m atau 50% dari radius kantor
 * (mana yang lebih kecil) supaya absen tidak pernah bisa dilakukan dari jauh.
 *
 * Dipakai BERSAMA oleh validasi absensi dan endpoint /api/config agar aplikasi
 * dan server memakai batas yang PERSIS sama.
 */
function cappedDriftTolerance(officeRadius: any, configured: any): number {
  const radius = Number(officeRadius) || 0;
  const raw = Math.max(0, Math.round(Number(configured) || 75));
  return Math.min(raw, Math.min(150, Math.round(radius * 0.5)));
}

/** Radius efektif = radius kantor + toleransi drift (dibatasi). */
function effectiveRadiusOf(officeRadius: any, configured: any): number {
  const radius = Number(officeRadius) || 0;
  return Math.min(radius + cappedDriftTolerance(radius, configured), Math.round(radius * 1.5) + 50);
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number) {
  const r = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return 2 * r * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Offset zona waktu operasional (WIB = UTC+7) dalam menit.
 * Server Vercel berjalan pada UTC, sehingga SEMUA perhitungan tanggal/jam
 * absensi harus digeser ke WIB agar "hari ini" & keterlambatan tidak salah 7 jam.
 */
const TZ_OFFSET_MIN = 7 * 60;

/** Tanggal (YYYY-MM-DD) menurut WIB untuk sebuah instant. */
function isoDateTz(d: Date = new Date()): string {
  return new Date(d.getTime() + TZ_OFFSET_MIN * 60000).toISOString().slice(0, 10);
}

/** Menit-dalam-hari (0..1439) menurut WIB untuk sebuah instant. */
function minutesOfDayTz(d: Date): number {
  const t = new Date(d.getTime() + TZ_OFFSET_MIN * 60000);
  return t.getUTCHours() * 60 + t.getUTCMinutes();
}

/**
 * Offset zona waktu (menit) untuk label IANA / offset eksplisit.
 *   'Asia/Jakarta' -> 420, 'Asia/Makassar' -> 480, 'Asia/Jayapura' -> 540,
 *   'Asia/Singapore' -> 480, 'UTC' -> 0, 'GMT+7' / '+07:00' -> 420.
 * Bila tz kosong/tak dikenal -> default WIB (420).
 */
function tzOffsetMinutes(tz: string | null | undefined): number {
  if (!tz) return TZ_OFFSET_MIN;
  const s = String(tz).trim();
  if (/^(utc|gmt)$/i.test(s)) return 0;
  const m = s.match(/^(?:utc|gmt)?\s*([+-])\s*(\d{1,2})(?::?(\d{2}))?$/i);
  if (m) {
    const sign = m[1] === '-' ? -1 : 1;
    return sign * (Number(m[2]) * 60 + Number(m[3] ?? 0));
  }
  try {
    const dtf = new Intl.DateTimeFormat('en-US', {
      timeZone: s, hour12: false,
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    });
    const parts: Record<string, number> = {};
    for (const p of dtf.formatToParts(new Date())) {
      if (p.type !== 'literal') parts[p.type] = Number(p.value);
    }
    const asUTC = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second);
    return Math.round((asUTC - Date.now()) / 60000);
  } catch {
    return TZ_OFFSET_MIN;
  }
}

/** Tanggal (YYYY-MM-DD) menurut ZONA WAKTU (offset menit) untuk sebuah instant. */
function isoDateAtOffset(d: Date, offsetMin: number): string {
  return new Date(d.getTime() + offsetMin * 60000).toISOString().slice(0, 10);
}

/** Menit-dalam-hari (0..1439) menurut ZONA WAKTU (offset menit). */
function minutesOfDayAtOffset(d: Date, offsetMin: number): number {
  const t = new Date(d.getTime() + offsetMin * 60000);
  return t.getUTCHours() * 60 + t.getUTCMinutes();
}

/** Cache offset zona waktu per-perusahaan (agar tak query DB tiap absen). */
const _tzCache: { [k: string]: { v: number; t: number } } = {};
async function getTzOffset(companyId: string): Promise<number> {
  try {
    const c = _tzCache[companyId];
    if (c && Date.now() - c.t < 60000) return c.v;
    await ensureCompanySettings();
    const r = await pool.query(`SELECT timezone FROM companies WHERE id=$1`, [companyId]);
    const off = tzOffsetMinutes(r.rows[0]?.timezone);
    _tzCache[companyId] = { v: off, t: Date.now() };
    return off;
  } catch {
    return TZ_OFFSET_MIN;
  }
}

/**
 * Sanity-clamp waktu check-in dari klien. Perangkat dengan jam salah bisa
 * menyebabkan status keterlambatan keliru. Aturan:
 *  - waktu di masa depan (> 10 menit) -> pakai waktu server (now);
 *  - waktu terlalu lampau (> 24 jam, mis. retry antrian offline) -> pakai now.
 * Mengembalikan { at, clamped }.
 */
function saneClientTime(ts: any): { at: Date; clamped: boolean } {
  const now = Date.now();
  const t = new Date(ts ?? now);
  if (!Number.isFinite(t.getTime())) return { at: new Date(now), clamped: true };
  const diff = now - t.getTime();
  if (diff > 24 * 60 * 60 * 1000) return { at: new Date(now), clamped: true };
  if (diff < -10 * 60 * 1000) return { at: new Date(now), clamped: true };
  return { at: t, clamped: false };
}


function toDateStr(value: any): string {
  if (value instanceof Date) return isoDateTz(value);
  return String(value).slice(0, 10);
}

/** Kembalikan Senin dari minggu yang memuat [iso] (atau minggu berjalan bila kosong). */
function normalizeWeekStart(iso: string): string {
  const base = /^\d{4}-\d{2}-\d{2}$/.test(iso)
    ? new Date(iso + 'T00:00:00Z')
    : new Date(isoDateTz() + 'T00:00:00Z');
  const dow = (base.getUTCDay() + 6) % 7; // 0 = Senin
  base.setUTCDate(base.getUTCDate() - dow);
  return base.toISOString().slice(0, 10);
}

/** Tambah [n] hari pada tanggal ISO (YYYY-MM-DD). */
function addDays(iso: string, n: number): string {
  const d = new Date(iso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/**
 * Tentukan shift EFEKTIF karyawan pada tanggal tertentu:
 *  - jadwal harian (employee_schedules) menang atas shift default,
 *  - note 'OFF' -> libur,
 *  - bila tanggal tidak diatur -> pakai shift default karyawan.
 * @returns { off, shiftId, name, startTime, endTime } (start/end "HH:MM").
 */
async function resolveShiftForDate(employeeId: string, isoDate: string) {
  const row = (await pool.query(
    `SELECT e.shift_id AS def_id, ds.name AS def_name, ds.start_time AS def_start, ds.end_time AS def_end,
            sc.shift_id AS day_id, sc.note AS day_note,
            ss.name AS day_name, ss.start_time AS day_start, ss.end_time AS day_end,
            ol.id AS loc_id, ol.name AS loc_name
     FROM employees e
     LEFT JOIN shifts ds ON ds.id = e.shift_id
     LEFT JOIN employee_schedules sc ON sc.employee_id = e.id AND sc.date = $2::date
     LEFT JOIN shifts ss ON ss.id = sc.shift_id
     LEFT JOIN office_locations ol ON ol.id = e.office_location_id
     WHERE e.id = $1 LIMIT 1`, [employeeId, isoDate]
  )).rows[0];
  if (!row) return { off: false, shiftId: null, name: null, startTime: null, endTime: null, officeLocationId: null, officeLocationName: null };
  const officeLocationId = row.loc_id ?? null;
  const officeLocationName = row.loc_name ?? null;
  if (row.day_note === 'OFF') return { off: true, shiftId: null, name: 'Libur', startTime: null, endTime: null, officeLocationId, officeLocationName };
  if (row.day_id && row.day_name) {
    return { off: false, shiftId: row.day_id, name: row.day_name, startTime: toTimeStr(row.day_start), endTime: toTimeStr(row.day_end), officeLocationId, officeLocationName };
  }
  if (row.def_id && row.def_name) {
    return { off: false, shiftId: row.def_id, name: row.def_name, startTime: toTimeStr(row.def_start), endTime: toTimeStr(row.def_end), officeLocationId, officeLocationName };
  }
  return { off: false, shiftId: null, name: null, startTime: null, endTime: null, officeLocationId, officeLocationName };
}

/**
 * Hitung status absensi dari waktu check-in terhadap jadwal shift (zona WIB).
 * @returns 'ON_TIME' (tepat waktu) atau 'TERLAMBAT' (+ menit keterlambatan).
 */
function computeLateStatus(checkIn: Date, startTime: string | null, graceMinutes = 0): { status: string; lateMinutes: number } {
  return computeLateStatusAtOffset(checkIn, startTime, TZ_OFFSET_MIN, graceMinutes);
}

/**
 * Sama seperti computeLateStatus, namun zona waktu dapat ditentukan (per-perusahaan)
 * dan toleransi dihormati (diff > grace). @param offsetMin offset zona waktu (menit).
 */
function computeLateStatusAtOffset(checkIn: Date, startTime: string | null, offsetMin: number, graceMinutes = 0): { status: string; lateMinutes: number } {
  if (!startTime) return { status: 'APPROVED', lateMinutes: 0 };
  const [hh, mm] = startTime.split(':').map(Number);
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return { status: 'APPROVED', lateMinutes: 0 };
  const shiftStartMin = hh * 60 + mm;
  const grace = Math.max(0, Math.round(Number(graceMinutes) || 0));
  const diff = minutesOfDayAtOffset(checkIn, offsetMin) - shiftStartMin - grace;
  if (diff >= 1) return { status: 'TERLAMBAT', lateMinutes: diff };
  return { status: 'ON_TIME', lateMinutes: 0 };
}

function toTimeStr(value: any): string {
  if (value == null) return '';
  const s = String(value);
  return s.length >= 5 ? s.slice(0, 5) : s;
}

/** Label durasi menit -> "2 jam 30 mnt" (dipakai ringkasan HR). */
function durLabelBackend(minutes: any): string {
  const m = Math.max(0, Math.round(Number(minutes) || 0));
  if (m === 0) return '0 mnt';
  const h = Math.floor(m / 60);
  const r = m % 60;
  if (h > 0 && r > 0) return `${h} jam ${r} mnt`;
  if (h > 0) return `${h} jam`;
  return `${r} mnt`;
}

function diffMinutes(start: string, end: string): number {
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  if ([sh, sm, eh, em].some((n) => !Number.isFinite(n))) return 0;
  let mins = (eh * 60 + em) - (sh * 60 + sm);
  if (mins < 0) mins += 24 * 60;
  return mins;
}

// ==================== PENGATURAN PERUSAHAAN (B7) ====================
// Kolom tambahan: toleransi keterlambatan (menit), timezone label, logo perusahaan.
let companySettingsReady: Promise<any> | null = null;
function ensureCompanySettings() {
  if (!companySettingsReady) {
    companySettingsReady = pool.query(`
      ALTER TABLE companies ADD COLUMN IF NOT EXISTS late_grace_minutes integer NOT NULL DEFAULT 0;
      ALTER TABLE companies ADD COLUMN IF NOT EXISTS timezone text NOT NULL DEFAULT 'Asia/Jakarta';
      ALTER TABLE companies ADD COLUMN IF NOT EXISTS logo_base64 text;
      ALTER TABLE companies ADD COLUMN IF NOT EXISTS gps_drift_tolerance_meters integer NOT NULL DEFAULT 75;
    `);
  }
  return companySettingsReady;
}
/** Ambil toleransi keterlambatan (menit) sebuah perusahaan. Default 0. Cache 60s. */
const _graceCache: { [k: string]: { v: number; t: number } } = {};
async function getLateGrace(companyId: string): Promise<number> {
  try {
    const c = _graceCache[companyId];
    if (c && Date.now() - c.t < 60000) return c.v;
    await ensureCompanySettings();
    const r = await pool.query(`SELECT late_grace_minutes FROM companies WHERE id=$1`, [companyId]);
    const v = Number(r.rows[0]?.late_grace_minutes);
    const val = Number.isFinite(v) && v >= 0 ? Math.round(v) : 0;
    _graceCache[companyId] = { v: val, t: Date.now() };
    return val;
  } catch { return 0; }
}

// ==================== MULTI LOKASI KANTOR (B64) ====================
// Fitur: satu perusahaan dapat memiliki BEBERAPA lokasi/cabang kantor, dan
// setiap karyawan dapat ditugaskan ke salah satu lokasi tersebut. Bila karyawan
// tidak ditugaskan (office_location_id = NULL), ia memakai lokasi Default
// perusahaan. Bila perusahaan belum punya baris lokasi sama sekali, sistem
// otomatis membuat satu baris Default dari kolom lama (companies.office_*)
// sehingga SEMUA data & aplikasi lama tetap berjalan tanpa perubahan.
let officeLocationsReady: Promise<any> | null = null;
function ensureOfficeLocations() {
  if (!officeLocationsReady) {
    officeLocationsReady = pool.query(`
      CREATE TABLE IF NOT EXISTS office_locations (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
        name text NOT NULL,
        address text,
        latitude double precision NOT NULL,
        longitude double precision NOT NULL,
        radius_meters integer NOT NULL DEFAULT 100,
        minimum_accuracy_meters integer NOT NULL DEFAULT 80,
        is_default boolean NOT NULL DEFAULT false,
        active boolean NOT NULL DEFAULT true,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_office_locations_company ON office_locations (company_id);
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS office_location_id uuid;

      -- Desain APK per lokasi kantor (B67) — Level 1 (warna/logo/nama) & Level 2
      -- (gambar header/splash/login). Satu baris per lokasi kantor.
      CREATE TABLE IF NOT EXISTS app_branding (
        location_id uuid PRIMARY KEY REFERENCES office_locations(id) ON DELETE CASCADE,
        company_id uuid NOT NULL,
        brand_name text,
        display_name text,
        tagline text,
        primary_color text,
        primary_dark_color text,
        accent_color text,
        bg_color text,
        surface_color text,
        text_color text,
        muted_color text,
        logo_url text,
        logo_base64 text,
        logo_white_url text,
        logo_white_base64 text,
        header_image_url text,
        splash_image_url text,
        login_image_url text,
        updated_by text,
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_app_branding_company ON app_branding (company_id);
    `).catch((e) => { officeLocationsReady = null; throw e; });
  }
  return officeLocationsReady;
}

/**
 * Pastikan perusahaan memiliki TEPAT SATU lokasi Default. Bila belum ada baris
 * lokasi sama sekali, buat dari kolom lama companies(office_name/office_latitude/
 * office_longitude/office_radius_meters/minimum_location_accuracy_meters).
 */
async function seedDefaultOfficeLocation(companyId: string) {
  await ensureOfficeLocations();
  const has = (await pool.query(
    `SELECT 1 FROM office_locations WHERE company_id=$1 LIMIT 1`, [companyId]
  )).rowCount;
  if (has) {
    // Pastikan ada tepat satu default.
    const d = (await pool.query(
      `SELECT id FROM office_locations WHERE company_id=$1 AND is_default=true LIMIT 1`, [companyId]
    )).rows[0];
    if (!d) {
      await pool.query(
        `UPDATE office_locations SET is_default=true WHERE id = (
           SELECT id FROM office_locations WHERE company_id=$1 ORDER BY created_at LIMIT 1
         )`, [companyId]
      );
    }
    return;
  }
  const c = (await pool.query(
    `SELECT office_name, address, office_latitude, office_longitude, office_radius_meters, minimum_location_accuracy_meters
     FROM companies WHERE id=$1`, [companyId]
  )).rows[0];
  if (!c) return;
  await pool.query(
    `INSERT INTO office_locations (company_id, name, address, latitude, longitude, radius_meters, minimum_accuracy_meters, is_default)
     VALUES ($1,$2,$3,$4,$5,$6,$7,true)`,
    [companyId, c.office_name || 'Kantor Pusat', c.address ?? null,
     Number(c.office_latitude) || 0, Number(c.office_longitude) || 0,
     Math.round(Number(c.office_radius_meters) || 100), Math.round(Number(c.minimum_location_accuracy_meters) || 80)]
  );
}

/**
 * Tentukan lokasi kantor EFEKTIF untuk seorang karyawan.
 * Prioritas: (1) lokasi yang ditugaskan ke karyawan, (2) lokasi Default
 * perusahaan, (3) kolom lama companies. Bila ketiganya kosong -> null
 * (absensi tanpa batas lokasi, sama seperti perilaku lama).
 */
async function resolveEmployeeOfficeLocation(companyId: string, employeeId: string | null) {
  await ensureOfficeLocations();
  await seedDefaultOfficeLocation(companyId);
  let loc: any = null;
  let source: 'employee' | 'default' | 'legacy' = 'default';
  if (employeeId) {
    loc = (await pool.query(
      `SELECT ol.id, ol.name, ol.address, ol.latitude, ol.longitude, ol.radius_meters, ol.minimum_accuracy_meters
       FROM employees e JOIN office_locations ol ON ol.id = e.office_location_id
       WHERE e.id=$1 AND e.company_id=$2 LIMIT 1`, [employeeId, companyId]
    )).rows[0];
    if (loc) source = 'employee';
  }
  if (!loc) {
    loc = (await pool.query(
      `SELECT id, name, address, latitude, longitude, radius_meters, minimum_accuracy_meters
       FROM office_locations WHERE company_id=$1 AND is_default=true LIMIT 1`, [companyId]
    )).rows[0];
    if (loc) source = 'default';
  }
  if (!loc) {
    const c = (await pool.query(
      `SELECT office_name AS name, address, office_latitude AS latitude, office_longitude AS longitude,
              office_radius_meters AS radius_meters, minimum_location_accuracy_meters AS minimum_accuracy_meters
       FROM companies WHERE id=$1`, [companyId]
    )).rows[0];
    if (c && Number(c.latitude) && Number(c.longitude)) { loc = { ...c, id: null }; source = 'legacy'; }
  }
  if (!loc) return null;
  return {
    id: loc.id ?? null,
    name: loc.name ?? null,
    address: loc.address ?? null,
    latitude: Number(loc.latitude),
    longitude: Number(loc.longitude),
    radius_meters: Math.round(Number(loc.radius_meters) || 100),
    minimum_accuracy_meters: Math.round(Number(loc.minimum_accuracy_meters) || 80),
    source,
  };
}

class HttpError extends Error { constructor(public status: number, message: string) { super(message); } }

// ==================== FACE (enrollment & verifikasi) ====================
// Endpoint wajah: /api/face/enrollment, /api/face/verify, /api/face/enrollment (DELETE).
// Data tersimpan permanen di tabel `face_enrollments` (Postgres).
app.use('/api/face', createFaceRouter({ pool, auth }));

// ==================== MODUL OPERASIONAL (B11) ====================
// Fitur per-jabatan karyawan (multi-role / jabatan rangkap):
//   DRIVER (perjalanan+surat jalan), PRAMUNIAGA (stock opname),
//   KEPALA_GUDANG (opname full + crosscek), KASIR (POS).
app.use('/api/ops', createOpsRouter({ pool, auth, adminAuth }));

// ==================== 404 JSON (BUKAN HTML) ====================
// Penting (B57): sebelumnya rute tak dikenal dijawab halaman HTML 404 bawaan
// Vercel. Klien Android memakai org.json untuk membaca respons, jadi HTML
// gagal di-parse dan pesannya jatuh ke fallback "Permintaan gagal (HTTP 404)"
// tanpa petunjuk apa pun — memakan waktu diagnosis berjam-jam.
// Sekarang SELALU balas JSON dengan pesan + jalur yang diminta.
app.use((req, res) => {
  res.status(404).json({
    message: `Endpoint tidak ditemukan: ${req.method} ${req.path}`,
    code: 'NOT_FOUND',
    path: req.path,
  });
});

export default app;

if (process.env.VERCEL !== '1') {
  app.listen(port, () => console.log(`AbsensiKu API listening on :${port}`));
}
