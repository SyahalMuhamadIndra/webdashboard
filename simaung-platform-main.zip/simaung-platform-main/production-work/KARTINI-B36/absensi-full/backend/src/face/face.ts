// =====================================================================
//  Mesin wajah sisi server (template v5, NCC) — ESM TypeScript.
//
//  Padanan 1:1 dari `server/src/faceMatcher.js` (CommonJS) agar skor
//  di server == di perangkat. Hanya jalur TEMPLATE (v5) yang dipakai
//  aplikasi (probe & sample selalu template v5).
// =====================================================================
import express from 'express';
import type { Pool } from 'pg';

const TEMPLATE_LEN = 32 * 32; // 1024

// ---------------------------------------------------------------------
//  MODE BARU (v0.9.9): "ANTI-SPOOF LONGGAR".
//  Kemiripan identitas tidak lagi menjadi gerbang ketat. Verifikasi hanya
//  memastikan: (a) ada wajah asli, dan (b) wajah yang difoto MASIH MIRIP
//  dengan sample terdaftar (bukan orang lain / foto lama di layar lain).
//  Karena itu ambang diturunkan drastis -> absensi jauh lebih mudah lolos.
// ---------------------------------------------------------------------
const TEMPLATE_LARGE_DIFF = 46;
/** Ambang "cukup mirip" untuk anti-spoof (dulu 72 — terlalu ketat). */
const TPL_MATCH = 40;
/** Ambang "hampir mirip" (peringatan lembut). */
const TPL_NEAR = 28;

/** True bila JSON v5 template. */
export function isTemplate(sig: any): boolean {
  if (sig == null) return false;
  try {
    const o = typeof sig === 'string' ? JSON.parse(sig) : sig;
    return !!(o && o.v === 5 && Array.isArray(o.t));
  } catch {
    return false;
  }
}

/** Decode template JSON v5 -> array int 0..255, atau null bila invalid. */
export function decodeTemplate(sig: any): number[] | null {
  try {
    const o = typeof sig === 'string' ? JSON.parse(sig) : sig;
    if (!o || o.v !== 5 || !Array.isArray(o.t)) return null;
    if (o.t.length !== TEMPLATE_LEN) return null;
    return o.t.map((v: any) => Math.max(0, Math.min(255, Math.trunc(Number(v)))));
  } catch {
    return null;
  }
}

/** Skor NCC 0..100 antara dua template; -1 bila invalid. */
export function templateScore(sigA: any, sigB: any): number {
  const a = decodeTemplate(sigA);
  const b = decodeTemplate(sigB);
  if (!a || !b || a.length !== b.length) return -1.0;
  let dot = 0, na = 0, nb = 0, large = 0;
  for (let i = 0; i < a.length; i++) {
    const x = a[i], y = b[i];
    dot += x * y;
    na += x * x;
    nb += y * y;
    if (Math.abs(x - y) > TEMPLATE_LARGE_DIFF) large++;
  }
  if (na <= 0 || nb <= 0) return -1.0;
  let score = (dot / (Math.sqrt(na) * Math.sqrt(nb))) * 100.0;
  score -= (large / a.length) * 140.0;
  return Math.max(0.0, Math.min(100.0, score));
}

/** Verifikasi template terhadap banyak sample (mayoritas). */
export function robustMatchTemplate(probeTemplate: any, storedTemplates: any[], threshold = TPL_MATCH) {
  if (!storedTemplates || storedTemplates.length === 0) {
    return { isMatch: false, score: 0.0, isNearMatch: false, effectiveThreshold: threshold, sampleCount: 0 };
  }
  const scores = storedTemplates.map((t) => templateScore(probeTemplate, t)).filter((s) => s >= 0);
  if (scores.length === 0) {
    return { isMatch: false, score: 0.0, isNearMatch: false, effectiveThreshold: threshold, sampleCount: 0 };
  }
  const required = scores.length === 1 ? 1 : Math.ceil(scores.length / 2);
  const matchCount = scores.filter((s) => s >= threshold).length;
  const sorted = [...scores].sort((a, b) => b - a);
  const representative = sorted.slice(0, required).reduce((s, v) => s + v, 0) / required;
  return {
    isMatch: matchCount >= required,
    score: representative,
    isNearMatch: matchCount < required && sorted[0] >= TPL_NEAR,
    effectiveThreshold: threshold,
    sampleCount: scores.length,
  };
}

/** Normalisasi payload enrollment. */
function parseEnrollPayload(body: any) {
  let samples = body?.samples;
  if (typeof samples === 'string') {
    try { samples = JSON.parse(samples); } catch { samples = [samples]; }
  }
  if (!Array.isArray(samples) || samples.length < 1) {
    throw new Error('Butuh minimal 1 sample wajah (disarankan 3).');
  }
  samples = samples.filter((s: any) => typeof s === 'string' && s.trim() !== '');
  if (samples.length === 0) throw new Error('Sample wajah tidak valid.');
  const templates = samples.filter((s: string) => isTemplate(s) && decodeTemplate(s) !== null);
  if (templates.length === 0) {
    throw new Error('Sample wajah versi lama (tanpa tekstur). Rekam ulang wajah.');
  }
  let basePhotoBase64: string | null = null;
  if (typeof body?.basePhotoBase64 === 'string' && body.basePhotoBase64.length > 0) {
    if (body.basePhotoBase64.length > 2_000_000) throw new Error('Foto dasar terlalu besar.');
    basePhotoBase64 = body.basePhotoBase64;
  }
  return { samples, basePhotoBase64, templates };
}

// ---------------------------------------------------------------------
//  Store Postgres (persisten). Tabel dibuat otomatis bila belum ada.
// ---------------------------------------------------------------------
class PgFaceStore {
  private ready: Promise<any> | null = null;
  constructor(private pool: Pool) {}

  private async ensureTable() {
    if (!this.ready) {
      this.ready = this.pool.query(`
        CREATE TABLE IF NOT EXISTS face_enrollments (
          employee_code text PRIMARY KEY,
          samples jsonb NOT NULL,
          base_photo_base64 text,
          updated_at timestamptz NOT NULL DEFAULT now()
        );
      `);
    }
    return this.ready;
  }

  async get(key: string) {
    await this.ensureTable();
    const r = await this.pool.query(
      `SELECT samples, base_photo_base64, updated_at FROM face_enrollments WHERE employee_code = $1`,
      [key],
    );
    if (!r.rows || r.rows.length === 0) return null;
    const row = r.rows[0];
    let samples = row.samples;
    if (typeof samples === 'string') {
      try { samples = JSON.parse(samples); } catch { samples = []; }
    }
    return {
      samples: Array.isArray(samples) ? samples : [],
      basePhotoBase64: row.base_photo_base64 || null,
      updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : null,
    };
  }

  async save(key: string, record: any) {
    await this.ensureTable();
    await this.pool.query(
      `INSERT INTO face_enrollments (employee_code, samples, base_photo_base64, updated_at)
       VALUES ($1, $2::jsonb, $3, now())
       ON CONFLICT (employee_code)
       DO UPDATE SET samples = EXCLUDED.samples,
                     base_photo_base64 = EXCLUDED.base_photo_base64,
                     updated_at = now()`,
      [key, JSON.stringify(record.samples || []), record.basePhotoBase64 || null],
    );
  }

  async remove(key: string) {
    await this.ensureTable();
    await this.pool.query(`DELETE FROM face_enrollments WHERE employee_code = $1`, [key]);
  }
}

/**
 * Bangun router wajah.
 * @param deps.pool Pool Postgres (DATABASE_URL).
 * @param deps.auth middleware Express yang memasang req.user.employeeCode.
 */
export function createFaceRouter(deps: { pool: Pool; auth: express.RequestHandler }) {
  const router = express.Router();
  const store = new PgFaceStore(deps.pool);

  // GET /face/enrollment
  router.get('/enrollment', deps.auth, async (req, res) => {
    try {
      const rec: any = await store.get((req as any).user.employeeId);
      if (!rec) return res.json({ enrolled: false, sampleCount: 0, hasBasePhoto: false, outdated: false });
      const samples: string[] = rec.samples || [];
      const templates = samples.filter((s) => isTemplate(s) && decodeTemplate(s) !== null);
      const outdated = samples.length > 0 && templates.length === 0;
      res.json({
        enrolled: samples.length > 0,
        sampleCount: samples.length,
        hasBasePhoto: !!rec.basePhotoBase64,
        outdated,
        updatedAt: rec.updatedAt || null,
      });
    } catch {
      res.status(500).json({ message: 'Gagal memuat status wajah.' });
    }
  });

  // POST /face/enrollment
  router.post('/enrollment', deps.auth, async (req, res) => {
    try {
      const { samples, basePhotoBase64 } = parseEnrollPayload(req.body || {});
      await store.save((req as any).user.employeeId, {
        samples, basePhotoBase64, updatedAt: new Date().toISOString(),
      });
      res.json({ ok: true, sampleCount: samples.length, hasBasePhoto: !!basePhotoBase64 });
    } catch (e: any) {
      res.status(400).json({ message: e?.message || 'Enrollment gagal.' });
    }
  });

  // GET /face/photo  -> foto sample tersimpan (untuk ditampilkan di layar kamera)
  router.get('/photo', deps.auth, async (req, res) => {
    try {
      const rec: any = await store.get((req as any).user.employeeId);
      if (!rec || !rec.basePhotoBase64) {
        return res.status(404).json({ hasPhoto: false, message: 'Belum ada foto sample tersimpan.' });
      }
      res.json({
        hasPhoto: true,
        basePhotoBase64: rec.basePhotoBase64,
        updatedAt: rec.updatedAt || null,
      });
    } catch {
      res.status(500).json({ message: 'Gagal memuat foto sample.' });
    }
  });

  // POST /face/verify
  router.post('/verify', deps.auth, async (req, res) => {
    try {
      const probe = req.body?.probe;
      if (typeof probe !== 'string' || probe.trim() === '') {
        return res.status(400).json({ message: 'Probe wajah diperlukan.' });
      }
      const threshold = Number.isFinite(req.body?.threshold) ? Math.trunc(req.body.threshold) : TPL_MATCH;
      const rec: any = await store.get((req as any).user.employeeId);
      const samples: string[] = (rec && rec.samples) || [];
      if (samples.length === 0) {
        return res.status(409).json({ message: 'Belum ada data wajah. Lakukan enrollment dulu.' });
      }
      const storedTemplates = samples.filter((s) => isTemplate(s));
      const decision = robustMatchTemplate(probe, storedTemplates, threshold);
      const score = Math.round(decision.score);
      const message = decision.isMatch
        ? `Wajah cocok (${score}%)`
        : decision.isNearMatch
        ? `Wajah agak berbeda (${score}%) — pastikan wajah Anda yang benar. Minimal ${decision.effectiveThreshold}%.`
        : `Wajah berbeda dari sample (${score}%). Minimal ${decision.effectiveThreshold}%.`;
      res.json({
        match: decision.isMatch,
        score,
        nearMatch: decision.isNearMatch,
        effectiveThreshold: decision.effectiveThreshold,
        sampleCount: samples.length,
        mode: 'TEMPLATE',
        message,
      });
    } catch {
      res.status(500).json({ message: 'Verifikasi wajah gagal.' });
    }
  });

  // DELETE /face/enrollment
  router.delete('/enrollment', deps.auth, async (req, res) => {
    try {
      await store.remove((req as any).user.employeeId);
      res.json({ ok: true });
    } catch {
      res.status(500).json({ message: 'Gagal menghapus data wajah.' });
    }
  });

  return router;
}
