import {mountOlseraCatalogStaging,olseraCatalogStagingSchema} from './olsera-catalog-staging.js';
import {mountOlseraReports,olseraReportSchema} from './olsera-reports.js';
import {mountOwnerConsole,ownerConsoleSchema} from './owner-console.js';
import {mountOutletHistory} from './outlet-history/routes.js';
import {mountOwnerFinance,ownerFinanceSchema} from './owner-finance.js';
import { mountOwnerEvidence } from './owner-evidence.js';
import { businessOperationsSchema, mountBusinessOperations } from './business-operations.js';
import bcrypt from 'bcryptjs';
import { explainReports } from './business-insights.js';
import { driveAccountingManifest } from './data/drive-accounting-manifest.js';
import type { Pool } from 'pg';
import type { Express, RequestHandler } from 'express';

const units = ['retail', 'fnb', 'kosan', 'penginapan'] as const;
const reportRoles=['OWNER','UNIT_MANAGER','FINANCE','PROPERTY_STAFF','KITCHEN','RECEPTION','RENTAL_MANAGER'];
type Access={role:string;unit:string;property:string|null};
const propertyUnits = ['kosan', 'penginapan'];
const money = (v: unknown): v is number => typeof v === 'number' && Number.isSafeInteger(v) && v>0 && v<=999999999999999;
const text = (v: unknown) => typeof v === 'string' ? v.trim() : '';
const validDate = (v: string) => {
  if (!/^(20[0-9]{2}|2100)-[0-9]{2}-[0-9]{2}$/.test(v)) return false;
  const d = new Date(v+'T00:00:00Z');
  return Number.isFinite(+d) && d.toISOString().startsWith(v);
};
const uuid = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;

export function mountBusinessReports(app: Express, pool: Pool, adminAuth: RequestHandler) {
  let ready: Promise<unknown> | undefined;
  const ensure = () => ready ??= pool.query(
    `SELECT pg_advisory_xact_lock(218761449);
     CREATE TABLE IF NOT EXISTS business_report_branch_units (
       company_id uuid NOT NULL REFERENCES companies(id), branch_id uuid NOT NULL REFERENCES branches(id),
       unit text NOT NULL CHECK (unit IN ('retail','fnb')), PRIMARY KEY(company_id,branch_id));
     CREATE TABLE IF NOT EXISTS business_report_targets (
       company_id uuid NOT NULL REFERENCES companies(id), unit text NOT NULL CHECK (unit IN ('retail','fnb','kosan','penginapan')),
       period date NOT NULL, amount numeric(16,0) NOT NULL CHECK (amount>0), PRIMARY KEY(company_id,unit,period));
     DO $$ BEGIN
       IF EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='business_report_targets'::regclass
          AND conname='business_report_targets_unit_check' AND pg_get_constraintdef(oid) NOT LIKE '%kosan%') THEN
         ALTER TABLE business_report_targets DROP CONSTRAINT business_report_targets_unit_check;
         ALTER TABLE business_report_targets ADD CONSTRAINT business_report_targets_unit_check CHECK (unit IN ('retail','fnb','kosan','penginapan'));
       END IF;
     END $$;
     CREATE TABLE IF NOT EXISTS business_report_property_receipts (
       id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES companies(id),
       unit text NOT NULL CHECK (unit IN ('kosan','penginapan')), property text NOT NULL,
       reference text NOT NULL, paid_on date NOT NULL, amount numeric(16,0) NOT NULL CHECK(amount>0),
       created_by uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
       voided_by uuid, voided_at timestamptz, void_reason text, UNIQUE(company_id,unit,reference));
     CREATE INDEX IF NOT EXISTS business_report_property_period ON business_report_property_receipts(company_id,unit,paid_on);
     CREATE TABLE IF NOT EXISTS business_report_access(
       company_id uuid NOT NULL REFERENCES companies(id), admin_id uuid PRIMARY KEY REFERENCES admins(id) ON DELETE CASCADE,
       role text NOT NULL CHECK(role IN ('OWNER','UNIT_MANAGER','FINANCE','PROPERTY_STAFF','KITCHEN','RECEPTION','RENTAL_MANAGER')),
       unit text NOT NULL CHECK(unit IN ('all','retail','fnb','kosan','penginapan')), property text,
       created_by uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
     DO $$ BEGIN
       IF EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='business_report_access'::regclass
         AND conname='business_report_access_role_check' AND pg_get_constraintdef(oid) NOT LIKE '%KITCHEN%') THEN
         ALTER TABLE business_report_access DROP CONSTRAINT business_report_access_role_check;
         ALTER TABLE business_report_access ADD CONSTRAINT business_report_access_role_check
           CHECK(role IN ('OWNER','UNIT_MANAGER','FINANCE','PROPERTY_STAFF','KITCHEN','RECEPTION','RENTAL_MANAGER'));
       END IF;
     END $$;
     ${businessOperationsSchema}${ownerFinanceSchema}${ownerConsoleSchema}${olseraReportSchema}${olseraCatalogStagingSchema}`
  ).catch(error => { ready = undefined; throw error; });
  const access:RequestHandler=async(req,res,next)=>{
    if(req.admin.role==='SUPERADMIN'){res.locals.reportAccess={role:'SYSTEM_ADMIN',unit:'all',property:null};return next();}
    if(req.admin.role!=='REPORT_USER')return res.status(403).json({message:'Akun belum diberi akses laporan multibisnis.'});
    try{
      await ensure();
      const grant=(await pool.query('SELECT role,unit,property FROM business_report_access WHERE company_id=$1 AND admin_id=$2',[req.admin.companyId,req.admin.adminId])).rows[0];
      if(!grant)return res.status(403).json({message:'Akses laporan tidak aktif.'});
      res.locals.reportAccess=grant;next();
    }catch{res.status(503).json({message:'Izin laporan belum dapat diverifikasi.'});}
  };
  const byRole=(...roles:string[]):RequestHandler=>(_req,res,next)=>{
    if(!roles.includes(res.locals.reportAccess.role))return res.status(403).json({message:'Peran Anda tidak memiliki izin untuk tindakan ini.'});
    next();
  };
  const group=byRole('SYSTEM_ADMIN','OWNER');
  const system=byRole('SYSTEM_ADMIN');
  const permits=(a:Access,unit:string,property?:string)=> (a.unit==='all'||a.unit===unit)&&(a.property===null||property===a.property);
  const noStore:RequestHandler=(_req,res,next)=>{res.set('Cache-Control','no-store');next();};
  app.get('/api/admin/business-reports/access',adminAuth,access,noStore,async(req,res)=>{
    const grant=res.locals.reportAccess as Access;
    try{
      let accounts=[];
      if(grant.role==='SYSTEM_ADMIN'){
        await ensure();
        accounts=(await pool.query(`SELECT a.id,a.name,a.email,a.active,b.role,b.unit,b.property FROM business_report_access b
          JOIN admins a ON a.id=b.admin_id AND a.company_id=b.company_id WHERE b.company_id=$1 AND a.role='REPORT_USER' ORDER BY a.name`,[req.admin.companyId])).rows;
      }
      res.json({grant,accounts});
    }catch{res.status(500).json({message:'Daftar akses gagal dimuat.'});}
  });
  app.get('/api/admin/business-reports/drive-accounting',adminAuth,access,noStore,async(req,res)=>{
    if((res.locals.reportAccess as Access).role!=='OWNER')return res.status(403).json({message:'Laporan unggahan hanya tersedia untuk Owner.'});
    try{
      const tenant=await pool.query('SELECT code FROM companies WHERE id=$1',[req.admin.companyId]);
      if(tenant.rows[0]?.code!==driveAccountingManifest.companyCode)return res.status(404).json({message:'Arsip tidak tersedia untuk tenant ini.'});
      res.json(driveAccountingManifest);
    }catch{res.status(503).json({message:'Laporan unggahan belum dapat dimuat.'});}
  });
  app.post('/api/admin/business-reports/access',adminAuth,access,system,async(req,res)=>{
    const b=req.body??{}, name=text(b.name), email=text(b.email).toLowerCase(), password=b.password, role=b.role, unit=b.unit;
    const locationRoles=['PROPERTY_STAFF','RECEPTION','RENTAL_MANAGER','KITCHEN'];
    const property=locationRoles.includes(role)?text(b.property):null;
    if(!name||name.length>100||email.length>200||!/^\S+@[^@\s]+\.[^@\s]+$/.test(email)||
       typeof password!=='string'||password.length<12||Buffer.byteLength(password)>72||
       !reportRoles.includes(role)||!(unit==='all'||units.some(u=>u===unit))||
       (role==='OWNER'&&unit!=='all')||(role==='UNIT_MANAGER'&&unit==='all')||
       (role==='PROPERTY_STAFF'&&!propertyUnits.includes(unit))||(role==='RECEPTION'&&unit!=='penginapan')||
       (role==='RENTAL_MANAGER'&&unit!=='kosan')||(role==='KITCHEN'&&(unit!=='fnb'||!property||!uuid.test(property)))||
       (locationRoles.includes(role)&&(!property||property.length>100)))
      return res.status(400).json({message:'Periksa nama, email, kata sandi minimal 12 karakter, peran, dan cakupan.'});
    try{
      await ensure();
      if(role==='KITCHEN'){
        const mapped=await pool.query("SELECT 1 FROM business_report_branch_units WHERE company_id=$1 AND branch_id=$2 AND unit='fnb'",[req.admin.companyId,property]);
        if(!mapped.rowCount)return res.status(400).json({message:'Pilih cabang F&B yang sudah dipetakan.'});
      }
      const hash=await bcrypt.hash(password,12);
      const result=await pool.query(`WITH account AS (
        INSERT INTO admins(company_id,name,email,password_hash,role,active,approved)
        VALUES ($1,$2,$3,$4,'REPORT_USER',true,true) ON CONFLICT(email) DO NOTHING RETURNING id
      ) INSERT INTO business_report_access(company_id,admin_id,role,unit,property,created_by)
       SELECT $1,id,$5,$6,$7,$8 FROM account RETURNING admin_id`,[req.admin.companyId,name,email,hash,role,unit,property,req.admin.adminId]);
      if(!result.rowCount)return res.status(409).json({message:'Email sudah digunakan. Gunakan akun khusus laporan dengan email berbeda.'});
      res.status(201).json({ok:true});
    }catch{res.status(500).json({message:'Akun laporan tidak dapat dibuat.'});}
  });
  app.delete('/api/admin/business-reports/access/:id',adminAuth,access,system,async(req,res)=>{
    const id=String(req.params.id);
    if(!uuid.test(id))return res.status(400).json({message:'ID akun tidak valid.'});
    try{
      await ensure();
      const result=await pool.query(`UPDATE admins SET active=false
         WHERE company_id=$1 AND id=$2 AND role='REPORT_USER'
         AND EXISTS(SELECT 1 FROM business_report_access WHERE company_id=$1 AND admin_id=$2)
         RETURNING id`,[req.admin.companyId,id]);
      if(!result.rowCount)return res.status(404).json({message:'Akun laporan tidak ditemukan.'});
      res.json({ok:true});
    }catch{res.status(500).json({message:'Akses tidak dapat dinonaktifkan.'});}
  });
  app.put('/api/admin/business-reports/branch', adminAuth, access, group, async (req,res) => {
    const {branchId,unit} = req.body ?? {};
    if (typeof branchId !== 'string' || !uuid.test(branchId) || !['retail','fnb'].includes(unit)) return res.status(400).json({ message:'Pilih cabang dan unit Retail atau F&B.' });
    try {
      await ensure();
      const result = await pool.query(`
        INSERT INTO business_report_branch_units (company_id,branch_id,unit)
        SELECT company_id,id,$3 FROM branches WHERE company_id=$1 AND id=$2
        ON CONFLICT (company_id,branch_id) DO UPDATE SET unit=EXCLUDED.unit WHERE business_report_branch_units.unit=EXCLUDED.unit
      `,[req.admin.companyId,branchId,unit]);
      if (!result.rowCount) return res.status(409).json({message:'Cabang tidak tersedia atau sudah dipetakan ke unit lain.'});
      res.json({ok:true});
    } catch (error) { console.error('Business report mapping failed',error); res.status(500).json({message:'Pemetaan tidak tersimpan.'}); }
  });
  app.put('/api/admin/business-reports/target', adminAuth, access, group, async (req,res) => {
    const {unit,year,month,amount} = req.body ?? {};
    if (!units.some(u=>u===unit) || !Number.isInteger(year) || year<2000 || year>2100 ||
        !Number.isInteger(month) || month<1 || month>12 || !money(amount)) {
      return res.status(400).json({message:'Isi tahun, bulan, dan target rupiah yang valid.'});
    }
    try {
      await ensure();
      await pool.query(`INSERT INTO business_report_targets(company_id,unit,period,amount)
        VALUES ($1,$2,make_date($3,$4,1),$5)
        ON CONFLICT(company_id,unit,period) DO UPDATE SET amount=EXCLUDED.amount`,[req.admin.companyId,unit,year,month,amount]);
      res.json({ok:true});
    } catch(error) { console.error('Saving report target failed',error); res.status(500).json({message:'Target tidak tersimpan.'}); }
  });
  app.post('/api/admin/business-reports/property-receipts',adminAuth,access,byRole('SYSTEM_ADMIN','OWNER','FINANCE','PROPERTY_STAFF'),async(req,res)=>{
    const body=req.body??{}, unit=body.unit, property=text(body.property), reference=text(body.reference).toUpperCase(), paidOn=text(body.paidOn), amount=body.amount;
    if(!permits(res.locals.reportAccess,unit,property))return res.status(403).json({message:'Properti ini di luar cakupan akun Anda.'});
    if (!propertyUnits.includes(unit)||!property||property.length>100||!reference||reference.length>80||!validDate(paidOn)||!money(amount))
      return res.status(400).json({message:'Isi unit, properti, nomor bukti unik, tanggal, dan nominal rupiah yang valid.'});
    try{
      await ensure();
      const company=req.admin.companyId;
      const inserted=await pool.query(`INSERT INTO business_report_property_receipts(company_id,unit,property,reference,paid_on,amount,created_by)
        VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(company_id,unit,reference) DO NOTHING RETURNING id`,
        [company,unit,property,reference,paidOn,amount,req.admin.adminId]);
      if(inserted.rowCount)return res.status(201).json({ok:true,id:inserted.rows[0].id});
      const prior=(await pool.query(`SELECT id,property,paid_on::text,amount::text,voided_at FROM business_report_property_receipts
        WHERE company_id=$1 AND unit=$2 AND reference=$3`,[company,unit,reference])).rows[0];
      if(prior&&!prior.voided_at&&prior.property===property&&prior.paid_on===paidOn&&Number(prior.amount)===amount)
        return res.json({ok:true,id:prior.id});
      res.status(409).json({message:'Nomor bukti sudah dipakai. Periksa catatan sebelumnya.'});
    }catch(error){console.error('Property receipt save failed',error);res.status(500).json({message:'Penerimaan belum tersimpan.'});}
  });
  app.post('/api/admin/business-reports/property-receipts/:id/void',adminAuth,access,byRole('SYSTEM_ADMIN','OWNER','FINANCE'),async(req,res)=>{
    const id=String(req.params.id),reason=text(req.body?.reason);
    if(!uuid.test(id)||reason.length<3||reason.length>300)return res.status(400).json({message:'Isi alasan pembatalan (3–300 karakter).'});
    try{
      await ensure();
      const r=await pool.query(`WITH receipt AS (
          UPDATE business_report_property_receipts SET voided_at=now(),voided_by=$3,void_reason=$4
          WHERE company_id=$1 AND id=$2 AND voided_at IS NULL AND ($5='all' OR unit=$5) RETURNING id
        ), reopen AS (
          UPDATE business_property_bills SET paid_at=NULL,receipt_id=NULL
          WHERE receipt_id IN(SELECT id FROM receipt) RETURNING id
        ) SELECT id FROM receipt`,[req.admin.companyId,id,req.admin.adminId,reason,res.locals.reportAccess.unit]);
      if(!r.rowCount)return res.status(404).json({message:'Catatan tidak ditemukan atau sudah dibatalkan.'});
      res.json({ok:true});
    }catch(error){console.error('Property receipt void failed',error);res.status(500).json({message:'Pembatalan gagal.'});}
  });
  mountBusinessOperations(app,pool,adminAuth,access,ensure);
  mountOutletHistory(app,pool,adminAuth,access);
  mountOwnerEvidence(app,pool,adminAuth,access,ensure);
  mountOwnerFinance(app,pool,adminAuth,access,ensure);
  mountOwnerConsole(app,pool,adminAuth,access,ensure);
  mountOlseraReports(app,pool,adminAuth,access,ensure);
  mountOlseraCatalogStaging(app,pool,adminAuth,access,ensure);
  app.get(['/api/admin/business-reports','/api/admin/business-reports/insights','/api/admin/business-reports/operations/overview'], adminAuth, access, async (req,res) => {
    const grant=res.locals.reportAccess as Access;
    const operational=req.path.endsWith('/operations/overview');
    if(!operational&&grant.role!=='OWNER')return res.status(403).json({message:'Pusat Laporan hanya tersedia untuk Owner.'});
    if(grant.role==='KITCHEN')return res.status(403).json({message:'Akun dapur hanya dapat membuka antrean dapur.'});
    const unit=String(req.query.unit ?? grant.unit);
    if(grant.unit!=='all'&&unit!==grant.unit)return res.status(403).json({message:'Unit ini di luar cakupan akun Anda.'});
    if(grant.property!==null&&req.path.endsWith('/insights'))return res.status(403).json({message:'Penjelasan grup tidak tersedia bagi petugas properti.'});
    const year=Number(req.query.year), month=req.query.month===undefined?null:Number(req.query.month);
    if ((unit!=='all'&&!units.some(v=>v===unit)) || !Number.isInteger(year)||year<2000||year>2100 || (month!==null&&(!Number.isInteger(month)||month<1||month>12))) return res.status(400).json({message:'Unit atau periode tidak valid.'});
    const startMonth=month??1, endMonth=month===null||month===12?1:month+1;
    const start=`${year}-${String(startMonth).padStart(2,'0')}-01`;
    const end=`${year+(month===null||month===12?1:0)}-${String(endMonth).padStart(2,'0')}-01`;
    try {
      await ensure();
      const company=req.admin.companyId;
      const [branch, sales, targets, properties, receipts] = await Promise.all([
        pool.query(`SELECT b.id,b.name,m.unit FROM branches b LEFT JOIN business_report_branch_units m ON m.company_id=b.company_id AND m.branch_id=b.id WHERE b.company_id=$1 AND ($2='all' OR m.unit=$2) ORDER BY b.name`,[company,grant.unit]),
        operational ? Promise.resolve({rows:[]}) : pool.query(`
          SELECT m.unit,b.id AS branch_id,b.name AS branch,
                 to_char(s.created_at AT TIME ZONE 'Asia/Jakarta','YYYY-MM') AS period,
                 count(*)::int AS receipts, sum(s.total)::text AS sales
          FROM ops_pos_sales s
          LEFT JOIN branches b ON b.company_id=s.company_id AND b.id=s.branch_id
          LEFT JOIN business_report_branch_units m ON m.company_id=b.company_id AND m.branch_id=b.id
          WHERE s.company_id=$1 AND s.status='PAID'
            AND s.created_at >= ($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
            AND s.created_at < ($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
            AND ($4='all' OR m.unit=$4)
          GROUP BY 1,2,3,4 ORDER BY 4,1,3
        `,[company,start,end,unit]),
        pool.query(`SELECT unit, to_char(period,'YYYY-MM') AS period, amount::text FROM business_report_targets WHERE company_id=$1 AND period >= $2::date AND period < $3::date AND ($4='all' OR unit=$4) AND $5::text IS NULL ORDER BY unit,period`,[company,start,end,unit,grant.property]),
        operational ? Promise.resolve({rows:[]}) : pool.query(`SELECT unit, 'property:'||property AS branch_id, property AS branch,
          to_char(paid_on,'YYYY-MM') AS period, count(*)::int AS receipts, sum(amount)::text AS sales
          FROM business_report_property_receipts WHERE company_id=$1 AND voided_at IS NULL AND paid_on >= $2::date AND paid_on < $3::date
          AND ($4='all' OR unit=$4) AND ($5::text IS NULL OR property=$5) GROUP BY 1,2,3,4 ORDER BY 4,1,3`,[company,start,end,unit,grant.property]),
        pool.query(`SELECT id,unit,property,reference,paid_on::text,amount::text,(voided_at IS NOT NULL) AS voided
          FROM business_report_property_receipts WHERE company_id=$1 AND paid_on >= $2::date AND paid_on < $3::date
          AND ($4='all' OR unit=$4) AND ($5::text IS NULL OR property=$5) ORDER BY paid_on DESC,created_at DESC,id LIMIT 200`,[company,start,end,unit,grant.property]),
      ]);
      res.set('Cache-Control','no-store');
      if(operational)return res.json({start,end,branches:branch.rows,targets:targets.rows,rows:[],receipts:receipts.rows});
      if(req.path.endsWith('/insights')){
        // Compare equal calendar periods; for a period still in progress,
        // cap the comparator at the same WIB calendar day offset.
        const previous=(await pool.query(`
          WITH bounds AS (
            SELECT ($2::date - CASE WHEN $4::boolean THEN interval '1 month' ELSE interval '1 year' END)::date AS lo,
                   CASE WHEN $3::date <= (now() AT TIME ZONE 'Asia/Jakarta')::date THEN $2::date ELSE LEAST($2::date,
                         ($2::date - CASE WHEN $4::boolean THEN interval '1 month' ELSE interval '1 year' END)::date
                           + GREATEST(0,LEAST($3::date,(now() AT TIME ZONE 'Asia/Jakarta')::date + 1)-$2::date)) END AS hi
          ), totals AS (
            SELECT m.unit,count(*) AS receipts, sum(s.total) AS sales
            FROM ops_pos_sales s JOIN business_report_branch_units m ON m.company_id=s.company_id AND m.branch_id=s.branch_id
            CROSS JOIN bounds
            WHERE s.company_id=$1 AND s.status='PAID'
              AND s.created_at >= (bounds.lo::timestamp AT TIME ZONE 'Asia/Jakarta')
              AND s.created_at < (bounds.hi::timestamp AT TIME ZONE 'Asia/Jakarta') AND ($5='all' OR m.unit=$5) GROUP BY m.unit
            UNION ALL
            SELECT p.unit,count(*),sum(p.amount) FROM business_report_property_receipts p CROSS JOIN bounds
            WHERE p.company_id=$1 AND p.voided_at IS NULL AND p.paid_on >= bounds.lo AND p.paid_on < bounds.hi AND ($5='all' OR p.unit=$5) GROUP BY p.unit
          ) SELECT unit, receipts::int, sales::text FROM totals
        `,[company,start,end,month!==null,unit])).rows;
        const insights=await explainReports(company,unit,start,end,month!==null,[...sales.rows,...properties.rows],targets.rows,branch.rows,previous);
        return res.json({insights});
      }
      const daily=req.query.daily==='1'&&['all','retail','fnb'].includes(unit)
        ? (await pool.query(`
          WITH by_method AS (
            SELECT m.unit,b.id AS branch_id,b.name AS branch,
              (s.created_at AT TIME ZONE 'Asia/Jakarta')::date AS day,
              COALESCE(NULLIF(UPPER(trim(s.payment_method)),''),'UNKNOWN') AS method,
              count(*)::int AS receipts,sum(s.total) AS sales
            FROM ops_pos_sales s
            JOIN branches b ON b.company_id=s.company_id AND b.id=s.branch_id
            JOIN business_report_branch_units m ON m.company_id=s.company_id AND m.branch_id=b.id
            WHERE s.company_id=$1 AND s.status='PAID'
              AND s.created_at >= ($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
              AND s.created_at < ($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
              AND ($4='all' OR m.unit=$4)
            GROUP BY 1,2,3,4,5
          ) SELECT unit,branch_id,branch,to_char(day,'YYYY-MM-DD') AS day,
            sum(receipts)::int AS receipts,sum(sales)::text AS sales,
            jsonb_object_agg(method,receipts) AS methods
          FROM by_method GROUP BY unit,branch_id,branch,day ORDER BY day DESC,branch,branch_id
        `,[company,start,end,unit])).rows:[];
      const posDetails=req.query.breakdown==='1'&&['all','retail','fnb'].includes(unit)
        ? await Promise.all([
          pool.query(`
            WITH totals AS (
              SELECT m.unit,b.id AS branch_id,b.name AS branch,
                     COALESCE(NULLIF(i.product_name,''),'Produk') AS product,
                     COALESCE(NULLIF(p.category,''),'Tanpa kategori') AS category,
                     sum(i.qty)::text AS quantity,sum(i.total)::text AS item_total,
                     COALESCE(sum(i.qty*i.cost),0)::text AS item_cost,
                     count(*) FILTER (WHERE i.cost IS NULL OR i.cost<=0)::int AS no_cost
              FROM ops_pos_sales s JOIN ops_pos_sale_items i ON i.sale_id=s.id
              JOIN branches b ON b.id=s.branch_id AND b.company_id=s.company_id
              JOIN business_report_branch_units m ON m.branch_id=b.id AND m.company_id=b.company_id
              LEFT JOIN ops_products p ON p.id=i.product_id AND p.company_id=s.company_id
              WHERE s.company_id=$1 AND s.status='PAID'
                AND s.created_at>=($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
                AND s.created_at<($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
                AND ($4='all' OR m.unit=$4)
              GROUP BY m.unit,b.id,b.name,COALESCE(NULLIF(i.product_name,''),'Produk'),COALESCE(NULLIF(p.category,''),'Tanpa kategori')
            ) SELECT * FROM totals ORDER BY item_total::numeric DESC,product,branch_id
          `,[company,start,end,unit]),
          pool.query(`
            SELECT m.unit,b.id AS branch_id,b.name AS branch,
                   COALESCE(NULLIF(s.cashier_name,''),'Tidak tercatat') AS cashier,
                   COALESCE(s.session_id::text,'') AS shift,
                   (ss.opened_at AT TIME ZONE 'Asia/Jakarta')::text AS shift_opened,
                   count(*) FILTER (WHERE s.status='PAID')::int AS receipts,
                   COALESCE(sum(s.total) FILTER (WHERE s.status='PAID'),0)::text AS sales,
                   COALESCE(sum(s.discount+s.member_discount) FILTER (WHERE s.status='PAID'),0)::text AS discounts,
                   count(*) FILTER (WHERE s.status='VOID')::int AS voids,
                   count(*) FILTER (WHERE s.status='REFUNDED')::int AS refunds,
                   COALESCE(sum(s.total) FILTER (WHERE s.status='REFUNDED'),0)::text AS refunded_sale_value
            FROM ops_pos_sales s JOIN branches b ON b.id=s.branch_id AND b.company_id=s.company_id
            JOIN business_report_branch_units m ON m.branch_id=b.id AND m.company_id=b.company_id
            LEFT JOIN ops_pos_sessions ss ON ss.id=s.session_id AND ss.company_id=s.company_id
            WHERE s.company_id=$1 AND s.status IN ('PAID','VOID','REFUNDED')
              AND s.created_at>=($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
              AND s.created_at<($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
              AND ($4='all' OR m.unit=$4)
            GROUP BY 1,2,3,4,5,6 ORDER BY shift_opened DESC NULLS LAST,cashier,branch_id
          `,[company,start,end,unit]),
          pool.query(`
            WITH totals AS (
            SELECT m.unit,b.id AS branch_id,b.name AS branch,x.key AS method,
                   sum((x.value #>> '{}')::numeric)::text AS amount
            FROM ops_pos_sales s JOIN branches b ON b.id=s.branch_id AND b.company_id=s.company_id
            JOIN business_report_branch_units m ON m.branch_id=b.id AND m.company_id=b.company_id
            CROSS JOIN LATERAL jsonb_each(CASE WHEN jsonb_typeof(s.payment_methods)='object' AND s.payment_methods<>'{}'::jsonb
              THEN s.payment_methods WHEN s.payment_method IS NULL OR s.payment_method IN ('SPLIT','TEMPO')
              THEN '{}'::jsonb ELSE jsonb_build_object(s.payment_method,s.total) END) x
            WHERE s.company_id=$1 AND s.status='PAID' AND jsonb_typeof(x.value)='number' AND x.key<>'TEMPO'
              AND s.created_at>=($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
              AND s.created_at<($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
              AND ($4='all' OR m.unit=$4)
            GROUP BY m.unit,b.id,b.name,x.key
            ) SELECT * FROM totals ORDER BY amount::numeric DESC,method,branch_id
          `,[company,start,end,unit]),
        ]):[];
      const propertyDaily=req.query.daily==='1'&&['all','kosan','penginapan'].includes(unit)
        ? (await pool.query(`
          SELECT unit,'property:'||property AS branch_id,to_char(paid_on,'YYYY-MM-DD') AS day,sum(amount)::text AS sales
          FROM business_report_property_receipts
          WHERE company_id=$1 AND voided_at IS NULL AND paid_on >= $2::date AND paid_on < $3::date
          AND ($4='all' OR unit=$4) AND ($5::text IS NULL OR property=$5)
          GROUP BY 1,2,3 ORDER BY 3
        `,[company,start,end,unit,grant.property])).rows:[];

      const propertyMetrics=req.query.daily==='1'&&['all','kosan','penginapan'].includes(unit)
        ? (await pool.query(`
          WITH rooms AS (
            SELECT r.id,r.unit,r.property,r.active FROM business_property_rooms r
            WHERE r.company_id=$1 AND ($4='all' OR r.unit=$4) AND ($5::text IS NULL OR r.property=$5)
          ), occupancy AS (
            SELECT r.id, count(*) FILTER (WHERE b.status='ACTIVE') AS occupied,
              count(*) FILTER (WHERE b.status='BOOKED' AND b.starts_on < $3::date AND b.ends_on > $2::date) AS reserved,
              count(*) FILTER (WHERE b.status='ACTIVE' AND b.ends_on BETWEEN (now() AT TIME ZONE 'Asia/Jakarta')::date AND (now() AT TIME ZONE 'Asia/Jakarta')::date+30) AS ending,
              COALESCE(sum(GREATEST(0,LEAST(COALESCE((b.checked_out_at AT TIME ZONE 'Asia/Jakarta')::date,(now() AT TIME ZONE 'Asia/Jakarta')::date),$3::date)
                -GREATEST((b.checked_in_at AT TIME ZONE 'Asia/Jakarta')::date,$2::date))) FILTER (WHERE b.checked_in_at IS NOT NULL),0) AS measured_nights,
              count(*) FILTER (WHERE b.checked_in_at IS NULL AND b.status IN ('ACTIVE','CLOSED') AND b.starts_on<$3::date AND b.ends_on>$2::date) AS unknown_stays
            FROM rooms r LEFT JOIN business_property_bookings b ON b.room_id=r.id GROUP BY r.id
          ), billing AS (
            SELECT r.id, count(i.id) FILTER (WHERE i.paid_at IS NULL) AS unpaid,
              COALESCE(sum(i.amount) FILTER (WHERE i.paid_at IS NULL),0) AS unpaid_amount,
              count(i.id) FILTER (WHERE i.paid_at IS NULL AND i.due_on < (now() AT TIME ZONE 'Asia/Jakarta')::date) AS overdue_count,
              COALESCE(sum(i.amount) FILTER (WHERE i.paid_at IS NULL AND (now() AT TIME ZONE 'Asia/Jakarta')::date-i.due_on BETWEEN 1 AND 30),0) AS overdue_30,
              COALESCE(sum(i.amount) FILTER (WHERE i.paid_at IS NULL AND (now() AT TIME ZONE 'Asia/Jakarta')::date-i.due_on BETWEEN 31 AND 60),0) AS overdue_60,
              COALESCE(sum(i.amount) FILTER (WHERE i.paid_at IS NULL AND (now() AT TIME ZONE 'Asia/Jakarta')::date-i.due_on>60),0) AS overdue_older,
              count(i.id) FILTER (WHERE i.paid_at IS NULL AND i.due_on IS NULL) AS undated
            FROM rooms r LEFT JOIN business_property_bookings b ON b.room_id=r.id AND b.status<>'CANCELLED'
            LEFT JOIN business_property_bills i ON i.booking_id=b.id AND i.period >= $2::date AND i.period < $3::date
            GROUP BY r.id
          ), deposits AS (
            SELECT r.id, COALESCE(sum(d.amount),0) AS held
            FROM rooms r LEFT JOIN business_property_bookings b ON b.room_id=r.id
            LEFT JOIN business_property_deposits d ON d.booking_id=b.id AND d.refunded_at IS NULL GROUP BY r.id
          ) SELECT r.unit,r.property,('property:'||r.property) AS branch_id,
            count(*) FILTER (WHERE r.active)::int AS active_rooms,
            count(*) FILTER (WHERE o.occupied>0)::int AS occupied_rooms,
            sum(o.reserved)::int AS reserved,sum(o.ending)::int AS ending,sum(o.measured_nights)::int AS measured_nights,sum(o.unknown_stays)::int AS unknown_stays,
            sum(i.unpaid)::int AS unpaid_count,sum(i.unpaid_amount)::text AS unpaid_amount,
            sum(i.overdue_count)::int AS overdue_count,sum(i.overdue_30)::text AS overdue_30,sum(i.overdue_60)::text AS overdue_60,
            sum(i.overdue_older)::text AS overdue_older,sum(i.undated)::int AS undated,sum(d.held)::text AS held_deposit
          FROM rooms r JOIN occupancy o ON o.id=r.id JOIN billing i ON i.id=r.id JOIN deposits d ON d.id=r.id
          GROUP BY 1,2,3 ORDER BY 1,2
        `,[company,start,end,unit,grant.property])).rows:[];

      if(req.query.daily==='1'&&['all','kosan','penginapan'].includes(unit)){
        const locations=await pool.query(`SELECT name,unit FROM business_properties
          WHERE company_id=$1 AND ($2='all' OR unit=$2) AND ($3::text IS NULL OR name=$3)
          ORDER BY unit,name`,[company,unit,grant.property]);
        for(const location of locations.rows){
          if(propertyMetrics.some(row=>row.unit===location.unit&&row.property===location.name))continue;
          propertyMetrics.push({unit:location.unit,property:location.name,branch_id:'property:'+location.name,
            active_rooms:0,occupied_rooms:0,reserved:0,ending:0,measured_nights:0,unknown_stays:0,
            unpaid_count:0,unpaid_amount:'0',overdue_count:0,overdue_30:'0',overdue_60:'0',overdue_older:'0',
            undated:0,held_deposit:'0'});
        }
      }

      const stockSignals=req.query.alerts==='1'&&['all','retail','fnb'].includes(unit)
        ? await pool.query(`
          WITH levels AS (
            SELECT m.unit,b.id AS branch_id,b.name AS location,'Barang' AS kind,p.name,p.unit AS stock_unit,
                   st.quantity::numeric AS balance,p.min_stock::numeric AS minimum
            FROM business_report_branch_units m JOIN branches b ON b.id=m.branch_id AND b.company_id=m.company_id
            JOIN ops_branch_config cfg ON cfg.company_id=m.company_id AND cfg.branch_id=m.branch_id
            JOIN stock_balances st ON st.company_id=cfg.company_id AND st.warehouse_id=cfg.warehouse_id
            JOIN ops_products p ON p.id=st.product_id AND p.company_id=st.company_id AND p.active=true
            WHERE m.company_id=$1 AND ($2='all' OR m.unit=$2) AND st.quantity <= GREATEST(COALESCE(p.min_stock,0),0)
            UNION ALL
            SELECT m.unit,b.id,b.name,'Bahan',p.name,p.unit,p.stock,p.min_stock
            FROM business_report_branch_units m JOIN branches b ON b.id=m.branch_id AND b.company_id=m.company_id
            JOIN ops_materials p ON p.company_id=m.company_id AND p.branch_id=m.branch_id AND p.active=true
            WHERE m.company_id=$1 AND m.unit='fnb' AND ($2='all' OR m.unit=$2)
              AND p.stock <= GREATEST(COALESCE(p.min_stock,0),0)
          )
          SELECT *, count(*) OVER ()::int AS matched FROM levels
          ORDER BY (balance<=0) DESC,unit,location,name LIMIT 100
        `,[company,unit]).then(r=>r.rows).catch(()=>null):null;
      const cashSignals=req.query.alerts==='1'&&['all','retail','fnb'].includes(unit)
        ? await pool.query(`
          SELECT m.unit,b.id AS branch_id,b.name AS location,ss.id AS shift_id,ss.code,
            to_char(ss.closed_at AT TIME ZONE 'Asia/Jakarta','YYYY-MM-DD') AS day,
            ss.closing_cash::text AS counted,ss.expected_cash::text AS expected,ss.cash_diff::text AS difference
          FROM ops_pos_sessions ss JOIN branches b ON b.id=ss.branch_id AND b.company_id=ss.company_id
          JOIN business_report_branch_units m ON m.branch_id=b.id AND m.company_id=b.company_id
          WHERE ss.company_id=$1 AND ($4='all' OR m.unit=$4)
            AND ss.closed_at>=($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
            AND ss.closed_at<($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
            AND ss.cash_diff IS DISTINCT FROM 0 AND ss.cash_diff IS NOT NULL
          ORDER BY abs(ss.cash_diff) DESC,ss.closed_at DESC,ss.id LIMIT 100
        `,[company,start,end,unit]).then(r=>r.rows).catch(()=>null):null;
      const kitchenMetrics=req.query.daily==='1'&&['all','fnb'].includes(unit)
        ? await pool.query(`
          SELECT 'fnb' AS unit,b.id AS branch_id,b.name AS branch,t.kind,
            count(*)::int AS tickets,count(*) FILTER(WHERE t.sale_id IS NULL AND t.status<>'CANCELLED')::int AS open,
            count(*) FILTER(WHERE t.status='CANCELLED')::int AS cancelled,
            count(*) FILTER(WHERE t.ready_at IS NOT NULL)::int AS timed,
            round(avg(EXTRACT(epoch FROM (t.ready_at-t.created_at))/60) FILTER(WHERE t.ready_at IS NOT NULL),1)::text AS mean_ready
          FROM business_fnb_tickets t JOIN branches b ON b.id=t.branch_id AND b.company_id=t.company_id
          WHERE t.company_id=$1 AND t.created_at>=($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
            AND t.created_at<($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
          GROUP BY 1,2,3,4 ORDER BY b.name,t.kind
        `,[company,start,end]).then(r=>r.rows).catch(()=>null):null;
      const wasteMetrics=req.query.daily==='1'&&['all','fnb'].includes(unit)
        ? await pool.query(`
          SELECT 'fnb' AS unit,b.id AS branch_id,b.name AS branch,p.name AS material,p.unit AS stock_unit,
            sum(v.qty)::text AS quantity,COALESCE(sum(v.cost),0)::text AS waste_cost
          FROM ops_material_moves v JOIN ops_materials p ON p.id=v.material_id AND p.company_id=v.company_id AND p.branch_id=v.branch_id
          JOIN branches b ON b.id=v.branch_id AND b.company_id=v.company_id
          JOIN business_report_branch_units m ON m.company_id=b.company_id AND m.branch_id=b.id AND m.unit='fnb'
          WHERE v.company_id=$1 AND v.ref_type='WASTE' AND v.created_at>=($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
           AND v.created_at<($3::date::timestamp AT TIME ZONE 'Asia/Jakarta')
          GROUP BY 1,2,3,4,5 ORDER BY b.name,p.name
        `,[company,start,end]).then(r=>r.rows).catch(()=>null):null;
      res.json({branches:branch.rows,rows:[...sales.rows,...properties.rows],receipts:receipts.rows,targets:targets.rows,daily,propertyDaily,propertyMetrics,stockSignals,cashSignals,kitchenMetrics,wasteMetrics,
        calculatedAt:new Date().toISOString(),
        products:posDetails[0]?.rows??[],shifts:posDetails[1]?.rows??[],paymentTotals:posDetails[2]?.rows??[],start,end,unit});
    } catch (error) { console.error('Business report read failed',error); res.status(500).json({message:'Laporan multibisnis belum dapat dimuat.'}); }
  });
}
