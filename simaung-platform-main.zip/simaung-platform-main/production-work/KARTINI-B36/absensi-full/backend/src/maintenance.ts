import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import type { Pool } from 'pg';
import { CONTROL_HTML, GUARD_JS } from './maintenance-assets.js';

export type MaintenanceState = { enabled: boolean; message: string; version: number; updatedAt: string | null };
export interface MaintenanceStore {
  read(): Promise<MaintenanceState>;
  write(state: MaintenanceState, actor: string): Promise<MaintenanceState | null>;
  history(): Promise<unknown[]>;
}

// Persistent shared state: never store the switch in process memory on Vercel.
export class PostgresMaintenanceStore implements MaintenanceStore {
  private ready: Promise<unknown> | null = null;
  constructor(private pool: Pool) {}
  private async init() {
    if (!this.ready) this.ready = this.pool.query(`
      CREATE TABLE IF NOT EXISTS kartini_maintenance (
        id integer PRIMARY KEY CHECK (id=1), enabled boolean NOT NULL DEFAULT false,
        message text NOT NULL, version integer NOT NULL DEFAULT 0, updated_at timestamptz DEFAULT now()
      );
      INSERT INTO kartini_maintenance (id, message) VALUES (1, 'Sistem sedang maintenance. Silakan coba kembali beberapa saat lagi.') ON CONFLICT DO NOTHING;
      CREATE TABLE IF NOT EXISTS kartini_maintenance_history (
        id bigserial PRIMARY KEY, enabled boolean NOT NULL, message text NOT NULL,
        actor text NOT NULL, version integer NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
      );`).catch(e => { this.ready = null; throw e; });
    await this.ready;
  }
  async read(): Promise<MaintenanceState> {
    await this.init();
    const { rows } = await this.pool.query('SELECT enabled,message,version,updated_at FROM kartini_maintenance WHERE id=1');
    if (!rows[0]) throw new Error('Maintenance state missing');
    return { enabled: rows[0].enabled, message: rows[0].message, version: rows[0].version, updatedAt: rows[0].updated_at };
  }
  async write(state: MaintenanceState, actor: string) {
    await this.init();
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const { rows } = await client.query(`UPDATE kartini_maintenance SET enabled=$1,message=$2,version=version+1,updated_at=now()
        WHERE id=1 AND version=$3 RETURNING enabled,message,version,updated_at`, [state.enabled, state.message, state.version]);
      if (!rows[0]) { await client.query('ROLLBACK'); return null; }
      await client.query('INSERT INTO kartini_maintenance_history(enabled,message,actor,version) VALUES ($1,$2,$3,$4)',
        [state.enabled, state.message, actor, rows[0].version]);
      await client.query('COMMIT');
      return { enabled: rows[0].enabled, message: rows[0].message, version: rows[0].version, updatedAt: rows[0].updated_at };
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  }
  async history() {
    await this.init();
    return (await this.pool.query('SELECT enabled,message,actor,version,created_at FROM kartini_maintenance_history ORDER BY id DESC LIMIT 30')).rows;
  }
}

export const SERVICES = [
  ['portal', 'Website utama', 'https://tokokartini.com/'],
  ['admin', 'Panel admin', 'https://admin.tokokartini.com/'],
  ['api', 'API & database', 'https://api.tokokartini.com/api/health'],
  ['pos', 'Kasir / POS', 'https://pos.tokokartini.com/'],
  ['opname', 'Stock opname', 'https://opname.tokokartini.com/'],
  ['jurnal', 'Jurnal keuangan', 'https://jurnal.tokokartini.com/login'],
  ['report', 'Pusat laporan', 'https://report.tokokartini.com/'],
  ['unduh', 'Pusat unduhan', 'https://unduh.tokokartini.com/'],
] as const;

export function createMaintenance({ store, authorize, ownerLogin, inspect, probe = fetch }: {
  store: MaintenanceStore;
  authorize: express.RequestHandler;
  ownerLogin?: express.RequestHandler;
  inspect?: express.RequestHandler;
  probe?: typeof fetch;
}) {
  const router = express.Router();
  router.use((_req, res, next) => { res.set('Cache-Control', 'no-store, max-age=0'); next(); });
  router.get(['/control', '/control/'], (_req, res) => res.type('html').send(CONTROL_HTML));
  router.get('/control-manifest.webmanifest', (_req, res) => res.type('application/manifest+json').send({
    id: '/control', name: 'Simaung Kontrol Layanan', short_name: 'Simaung Kontrol', lang: 'id',
    start_url: '/control', scope: '/control', display: 'standalone', background_color: '#0b1815', theme_color: '#102a23',
    icons: [{ src: '/control-icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' }],
  }));
  router.get('/control-icon.svg', (_req, res) => res.type('image/svg+xml').send('<svg xmlns="http://www.w3.org/2000/svg" width="192" height="192" viewBox="0 0 192 192"><rect width="192" height="192" rx="44" fill="#102a23"/><path d="M55 42h24v46l39-46h30l-47 53 50 55h-32l-40-47v47H55z" fill="#b7f1bf"/></svg>'));
  router.get('/maintenance-guard.js', (_req, res) => res.type('application/javascript').send(GUARD_JS));
  router.post('/api/maintenance/login', ownerLogin || ((_req, res) => res.status(503).json({ message: 'Login kontroler belum dikonfigurasi.' })));
  router.get('/api/maintenance/status', async (_req, res) => {
    try { res.json(await store.read()); }
    catch { res.status(503).json({ code: 'STATUS_UNAVAILABLE', message: 'Status layanan belum dapat diperiksa.' }); }
  });
  const control = '/api/admin/maintenance';
  router.use(control, authorize);
  router.get(control, async (_req, res) => res.json(await store.read()));
  if (inspect) router.get(control + '/readiness', inspect);
  router.get(control + '/history', async (_req, res) => res.json({ items: await store.history() }));
  router.put(control, async (req, res) => {
    const { enabled, message, version } = req.body ?? {};
    if (typeof enabled !== 'boolean' || typeof message !== 'string' || !message.trim() || message.length > 500 || !Number.isSafeInteger(version) || version < 0)
      return res.status(400).json({ message: 'Status, pesan (1–500 karakter), dan versi wajib valid.' });
    const result = await store.write({ enabled, message: message.trim(), version, updatedAt: null }, req.admin.adminId);
    if (!result) return res.status(409).json({ message: 'Status telah berubah dari perangkat lain. Muat ulang sebelum menyimpan.' });
    return res.json(result);
  });
  router.get(control + '/monitor', async (_req, res) => {
    const services = await Promise.all(SERVICES.map(async ([id, name, url]) => {
      const start = Date.now();
      try {
        const response = await probe(url, { signal: AbortSignal.timeout(6000), redirect: 'follow', cache: 'no-store' });
        let healthy = response.ok;
        if (id === 'api' && healthy) healthy = (await response.json()).ok === true;
        else await response.body?.cancel();
        return { id, name, url, healthy, status: response.status, latencyMs: Date.now() - start };
      } catch { return { id, name, url, healthy: false, status: null, latencyMs: Date.now() - start }; }
    }));
    res.json({ checkedAt: new Date().toISOString(), services });
  });
  router.use((_error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    res.status(503).json({ code: 'CONTROL_UNAVAILABLE', message: 'Kontrol belum dapat disimpan atau dibaca. Periksa koneksi database dan coba kembali.' });
  });
  const exceptions = new Set(['/api/admin/login', '/api/health', '/api/app/latest']);
  const gate: express.RequestHandler = async (req, res, next) => {
    if (req.method === 'OPTIONS' || exceptions.has(req.path) || !req.path.startsWith('/api/')) return next();
    try {
      const state = await store.read();
      if (!state.enabled) return next();
      res.set({ 'Cache-Control': 'no-store', 'Retry-After': '30' });
      return res.status(503).json({ code: 'MAINTENANCE', message: state.message, maintenance: true });
    } catch {
      // Fail closed: cannot accidentally reopen business operations after a DB failure.
      return res.status(503).set('Cache-Control', 'no-store').json({ code: 'STATUS_UNAVAILABLE', message: 'Status layanan belum dapat diperiksa. Silakan coba kembali.' });
    }
  };
  return { router, gate };
}

// A fresh DB lookup is mandatory. Do not reuse the legacy adminAuth fallback
// which accepts role claims when the database is unavailable.
export function maintenanceOwnerAuth(pool: Pool): express.RequestHandler {
  return async (req, res, next) => {
    const secret = process.env.MAINTENANCE_LOGIN_SECRET;
    if (!secret || secret.length < 32) return res.status(503).json({ message: 'Login khusus kontroler belum dikonfigurasi.' });
    const token = req.header('authorization');
    if (!token?.startsWith('Bearer ')) return res.status(401).json({ message: 'Silakan masuk sebagai pemilik.' });
    let payload: jwt.JwtPayload;
    try {
      const verified = jwt.verify(token.slice(7), secret, { algorithms: ['HS256'] });
      if (typeof verified === 'string' || !verified.adminId || verified.purpose !== 'maintenance-control'
          || verified.sub !== process.env.MAINTENANCE_OWNER_EMAIL?.trim().toLowerCase()) throw new Error('invalid');
      payload = verified;
    } catch { return res.status(401).json({ message: 'Sesi tidak valid. Silakan masuk kembali.' }); }
    try {
      const { rows } = await pool.query('SELECT id,company_id,role,active FROM admins WHERE id=$1', [payload.adminId]);
      const row = rows[0];
      const allowed = (process.env.MAINTENANCE_ADMIN_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
      // Explicit owner allowlist avoids granting global shutdown to every admin.
      if (!allowed.length) return res.status(503).json({ message: 'MAINTENANCE_ADMIN_IDS belum diatur oleh pengelola hosting.' });
      if (!row || row.active !== true || !['SUPERADMIN', 'DEV'].includes(String(row.role).toUpperCase()) || !allowed.includes(String(row.id)))
        return res.status(403).json({ message: 'Akses kontrol hanya untuk akun pemilik yang diizinkan.' });
      req.admin = { adminId: String(row.id), companyId: String(row.company_id), role: String(row.role) };
      next();
    } catch { return res.status(503).json({ message: 'Verifikasi akses tidak tersedia. Coba kembali.' }); }
  };
}

// Controller credentials are independent of regular admin/employee accounts.
// A separate signing secret prevents controller tokens from authenticating to
// unrelated business/admin endpoints.
export function maintenanceOwnerLogin(pool: Pool): express.RequestHandler {
  let ready: Promise<unknown> | null = null;
  return async (req, res) => {
    const secret = process.env.MAINTENANCE_LOGIN_SECRET;
    const owner = process.env.MAINTENANCE_OWNER_EMAIL?.trim().toLowerCase();
    const passwordHash = process.env.MAINTENANCE_OWNER_PASSWORD_HASH;
    const adminId = (process.env.MAINTENANCE_ADMIN_IDS || '').split(',').map(x => x.trim()).find(Boolean);
    if (!secret || secret.length < 32 || !owner || !passwordHash || !adminId)
      return res.status(503).json({ message: 'Login khusus kontroler belum dikonfigurasi.' });
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');
    if (!email || email.length > 254 || !password || password.length > 256)
      return res.status(400).json({ message: 'Email dan kata sandi wajib diisi dengan benar.' });
    try {
      if (!ready) ready = pool.query(`CREATE TABLE IF NOT EXISTS kartini_control_login_attempts (
        bucket text PRIMARY KEY, attempts integer NOT NULL DEFAULT 1, started_at timestamptz NOT NULL DEFAULT now()
      )`).catch(error => { ready = null; throw error; });
      await ready;
      const ip = String(req.header('x-real-ip') || req.ip || 'unknown').slice(0, 200);
      const bucket = crypto.createHash('sha256').update(ip).digest('hex');
      const rate = await pool.query(`INSERT INTO kartini_control_login_attempts(bucket) VALUES ($1)
        ON CONFLICT(bucket) DO UPDATE SET
          attempts = CASE WHEN kartini_control_login_attempts.started_at < now()-interval '15 minutes' THEN 1 ELSE kartini_control_login_attempts.attempts+1 END,
          started_at = CASE WHEN kartini_control_login_attempts.started_at < now()-interval '15 minutes' THEN now() ELSE kartini_control_login_attempts.started_at END
        RETURNING attempts`, [bucket]);
      if (Number(rate.rows[0]?.attempts) > 10)
        return res.status(429).set('Retry-After', '900').json({ message: 'Terlalu banyak percobaan masuk. Coba kembali 15 menit lagi.' });
      const valid = await bcrypt.compare(password, passwordHash);
      if (!valid || email !== owner) return res.status(401).json({ message: 'Email atau kata sandi salah.' });
      const account = (await pool.query('SELECT id,role,active FROM admins WHERE id=$1', [adminId])).rows[0];
      if (!account || account.active !== true || !['SUPERADMIN','DEV'].includes(String(account.role).toUpperCase()))
        return res.status(403).json({ message: 'Akun pemilik tidak aktif atau tidak diizinkan.' });
      await pool.query('DELETE FROM kartini_control_login_attempts WHERE bucket=$1', [bucket]);
      const token = jwt.sign({ adminId, purpose: 'maintenance-control' }, secret,
        { algorithm: 'HS256', subject: owner, expiresIn: '12h' });
      return res.json({ token, name: 'Pemilik', role: 'MAINTENANCE_OWNER' });
    } catch {
      return res.status(503).json({ message: 'Login kontroler belum tersedia. Silakan coba kembali.' });
    }
  };
}
