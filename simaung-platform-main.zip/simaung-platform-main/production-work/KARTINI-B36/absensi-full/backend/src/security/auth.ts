import type express from 'express';
import jwt from 'jsonwebtoken';
import type { Pool } from 'pg';

const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
type Database = Pick<Pool, 'query'>;

function claims(req: express.Request, secret: string): jwt.JwtPayload | null {
  const header = req.header('authorization');
  if (!header?.startsWith('Bearer ') || !secret || secret === 'change-me-in-production') return null;
  try {
    const payload = jwt.verify(header.slice(7), secret, { algorithms: ['HS256'] });
    if (typeof payload === 'string' || !Number.isFinite(payload.exp)) return null;
    return payload;
  } catch { return null; }
}

export function createEmployeeAuth(pool: Database, secret: string): express.RequestHandler {
  return async (req, res, next) => {
    const payload = claims(req, secret);
    if (!payload || typeof payload.sub !== 'string' || !uuid.test(payload.sub)
        || typeof payload.deviceId !== 'string' || !uuid.test(payload.deviceId)
        || typeof payload.companyId !== 'string' || !uuid.test(payload.companyId))
      return res.status(401).json({ message: 'Token tidak valid atau kedaluwarsa', code: 'SESSION_INVALID' });
    try {
      const result = await pool.query(`SELECT e.id, e.company_id, e.active,
          d.id AS valid_device_id, d.revoked_at
        FROM employees e LEFT JOIN devices d ON d.id=$2 AND d.employee_id=e.id
        WHERE e.id=$1 LIMIT 1`, [payload.sub, payload.deviceId]);
      const row = result.rows[0];
      if (!row) return res.status(401).json({ message: 'Akun Anda telah dihapus.', code: 'ACCOUNT_GONE' });
      if (row.active !== true) return res.status(401).json({ message: 'Akun Anda dinonaktifkan.', code: 'ACCOUNT_INACTIVE' });
      if (!row.valid_device_id || row.revoked_at)
        return res.status(401).json({ message: 'Akses perangkat ini telah dicabut atau tidak terdaftar.', code: 'DEVICE_REVOKED' });
      if (String(row.company_id) !== payload.companyId)
        return res.status(401).json({ message: 'Data akun berubah. Silakan masuk kembali.', code: 'SESSION_INVALID' });
      req.user = { employeeId: String(row.id), companyId: String(row.company_id), deviceId: String(row.valid_device_id) };
      next();
    } catch {
      return res.status(503).json({ message: 'Verifikasi akun belum tersedia. Silakan coba kembali.', code: 'AUTH_UNAVAILABLE' });
    }
  };
}

export function createAdminAuth(pool: Database, secret: string): express.RequestHandler {
  return async (req, res, next) => {
    const payload = claims(req, secret);
    if (!payload || typeof payload.adminId !== 'string' || !uuid.test(payload.adminId)
        || typeof payload.companyId !== 'string' || !uuid.test(payload.companyId))
      return res.status(401).json({ message: 'Sesi admin tidak valid atau kedaluwarsa', code: 'SESSION_INVALID' });
    try {
      const result = await pool.query('SELECT id,company_id,name,email,role,active,approved FROM admins WHERE id=$1', [payload.adminId]);
      const row = result.rows[0];
      if (!row || row.active !== true || row.approved === false)
        return res.status(401).json({ message: 'Akun admin tidak aktif, belum disetujui, atau telah dihapus.', code: 'ACCOUNT_INACTIVE' });
      if (String(row.company_id) !== payload.companyId)
        return res.status(401).json({ message: 'Data akun berubah. Silakan masuk kembali.', code: 'SESSION_INVALID' });
      if (String(row.role).toUpperCase()==='REPORT_USER') {
        const path=req.originalUrl.split('?')[0];
        if(path!=='/api/admin/me'&&!/^\/api\/admin\/business-reports(?:\/|$)/.test(path))
          return res.status(403).json({message:'Akun ini hanya untuk Pusat Laporan.'});
      }
      // Identity, tenant and role always come from the current database row.
      req.admin = { adminId: String(row.id), companyId: String(row.company_id), role: String(row.role).toUpperCase() };
      Object.assign(req.admin, { adminName: row.name, email: row.email });
      next();
    } catch {
      return res.status(503).json({ message: 'Verifikasi admin belum tersedia. Silakan coba kembali.', code: 'AUTH_UNAVAILABLE' });
    }
  };
}
