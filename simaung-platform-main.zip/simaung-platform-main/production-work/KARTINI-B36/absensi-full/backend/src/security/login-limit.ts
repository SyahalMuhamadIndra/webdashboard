import { createHmac } from 'node:crypto';
import type { RequestHandler } from 'express';
import type { Pool } from 'pg';

export function createLoginLimit(pool: Pool, secret: string, realm: string, field: string): RequestHandler {
  let ready: Promise<unknown> | undefined;
  return async (req, res, next) => {
    const raw = req.body?.[field];
    if (typeof raw !== 'string' || !raw.trim() || raw.length > 256) {
      res.status(400).json({ message: 'Identitas login tidak valid.' });
      return;
    }
    const digest = createHmac('sha256', secret).update(realm + ':' + raw.trim().toLowerCase()).digest('hex');
    try {
      ready ??= pool.query(`CREATE TABLE IF NOT EXISTS auth_login_windows (
        bucket text PRIMARY KEY,
        attempts integer NOT NULL DEFAULT 1,
        started_at timestamptz NOT NULL DEFAULT now()
      )`).catch(error => { ready = undefined; throw error; });
      await ready;
      const result = await pool.query(`INSERT INTO auth_login_windows(bucket) VALUES ($1)
        ON CONFLICT (bucket) DO UPDATE SET
        attempts = CASE WHEN auth_login_windows.started_at <= now() - interval '15 minutes' THEN 1
                        ELSE LEAST(auth_login_windows.attempts + 1, 11) END,
        started_at = CASE WHEN auth_login_windows.started_at <= now() - interval '15 minutes'
                          THEN now() ELSE auth_login_windows.started_at END
        RETURNING attempts`, [digest]);
      if (Number(result.rows[0].attempts) > 10) {
        res.status(429).set('Retry-After', '900').json({ message: 'Terlalu banyak percobaan masuk. Coba lagi dalam 15 menit.' });
        return;
      }
      next();
    } catch {
      res.status(503).json({ message: 'Login sementara tidak tersedia.' });
    }
  };
}
