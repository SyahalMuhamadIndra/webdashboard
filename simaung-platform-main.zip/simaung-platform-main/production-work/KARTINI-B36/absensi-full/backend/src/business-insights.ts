import {createHash} from 'node:crypto';

type Row = {unit:string|null;branch_id:string|null;sales:string;receipts:number};
type Target = {unit:string;amount:string};
type Branch = {unit:string|null};
const labels: Record<string,string> = {retail:'Retail',fnb:'F&B',kosan:'Kosan',penginapan:'Penginapan'};
const rupiah = new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:2});
const percent = new Intl.NumberFormat('id-ID',{maximumFractionDigits:2});
const cache = new Map<string,{expires:number;data:Promise<Record<string,string>>}>();

export async function explainReports(companyId:string,scope:string,start:string,end:string,monthly:boolean,rows:Row[],targets:Target[],branches:Branch[],previous:Pick<Row,'unit'|'sales'|'receipts'>[]=[]){
  const cards=Object.keys(labels).filter(u=>scope==='all'||u===scope).map(unit=>{
    const relevant=rows.filter(r=>r.unit===unit), location=new Map<string,number>();
    for(const r of relevant)if(r.branch_id)location.set(r.branch_id,(location.get(r.branch_id)??0)+Number(r.sales));
    const revenue=relevant.reduce((n,r)=>n+Number(r.sales),0);
    const count=relevant.reduce((n,r)=>n+Number(r.receipts),0);
    const ts=targets.filter(t=>t.unit===unit);
    const configured=!['retail','fnb'].includes(unit)||branches.some(b=>b.unit===unit);
    const target=configured&&ts.length===(monthly?1:12)?ts.reduce((n,t)=>n+Number(t.amount),0):null;
    const achievement=target===null?null:revenue/target*100;
    const gap=target===null?null:revenue-target;
    const prior=previous.find(r=>r.unit===unit&&r.receipts>0);
    const priorRevenue=prior?Number(prior.sales):null, priorCount=prior?.receipts??null;
    const average=count?revenue/count:null, priorAverage=priorCount?priorRevenue!/priorCount:null;
    // Exact decomposition: volume at prior average, then value at current volume.
    const volumeEffect=priorAverage===null?null:(count-priorCount!)*priorAverage;
    const valueEffect=priorAverage===null||average===null?null:count*(average-priorAverage);
    const effect=(n:number)=>n>=0?'menambah '+rupiah.format(n):'mengurangi '+rupiah.format(-n);
    const drivers=priorCount&&count&&volumeEffect!==null&&valueEffect!==null
      ? ' Dibanding periode sebelumnya: pembayaran '+priorCount+' → '+count+' dan rata-rata '+rupiah.format(priorAverage!)+' → '+rupiah.format(average!)+'. Perubahan jumlah '+effect(volumeEffect)+'; perubahan nilai rata-rata '+effect(valueEffect)+'.'
      : ' Pembayaran pembanding belum cukup untuk memisahkan pengaruh jumlah dan nilai rata-rata.';
    const fallback=!configured?'Belum ada cabang yang dipetakan ke unit ini.'
       :target===null?'Target periode belum lengkap, jadi pencapaian belum bisa dinilai.'
       :(!count?'Belum ada pembayaran tercatat pada periode ini. ':count+' pembayaran tercatat pada periode ini. ')+
         'Omzet '+rupiah.format(revenue)+' dari target '+rupiah.format(target)+' ('+percent.format(achievement!)+'%). '+
         (gap!<0?'Masih kurang '+rupiah.format(-gap!)+'.':gap!>0?'Melampaui target '+rupiah.format(gap!)+'.':'Target tercapai tepat.')+
         drivers;
    return {unit,revenue,count,target,achievement,gap,priorRevenue,priorCount,average,priorAverage,volumeEffect,valueEffect,locations:location.size,
      largestLocationRevenue:Math.max(0,...location.values()),fallback,drivers};
  });
  const eligible=cards.filter(c=>c.target!==null&&c.count>0).map(({fallback,drivers,...facts})=>facts);
  const key=process.env.GEMINI_API_KEY?.trim();
  const model=process.env.GEMINI_REPORT_MODEL?.trim();
  let ai:Record<string,string>={};
  if(key&&model&&/^gemini-[a-z0-9.-]+$/.test(model)&&eligible.length){
    const input={start,end,monthly,units:eligible};
    const cacheKey=createHash('sha256').update(companyId+'\0'+JSON.stringify(input)).digest('hex');
    const prior=cache.get(cacheKey);
    if(prior&&prior.expires>Date.now())ai=await prior.data;
    else{
      const data=(async()=>{
        try{
          const response=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent',{
            method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},
            signal:AbortSignal.timeout(9000),
            body:JSON.stringify({
              systemInstruction:{parts:[{text:'Tulis penjelasan pencapaian untuk tiap unit berdasarkan angka agregat ini saja. Gunakan bahasa Indonesia, maksimal 2 kalimat per unit. Jelaskan faktor terukur: perubahan jumlah pembayaran dan nilai rata-rata dibanding periode sebelumnya. Efek volume dan nilai rata-rata menjelaskan perubahan omzet antarperiode, bukan penyebab selisih target. Jika tidak ada pembanding, nyatakan itu. Jangan mengarang penyebab, tren, nama, atau data yang tidak diberikan. Jangan menyatakan penyebab operasional diketahui. Jika data tidak cukup, katakan apa yang belum bisa disimpulkan. Kembalikan objek JSON dengan kunci kode unit dan nilai string; tanpa markdown.'}]},
              contents:[{parts:[{text:JSON.stringify(input)}]}],
              generationConfig:{responseMimeType:'application/json',temperature:0.2,maxOutputTokens:1100}
            }),
          });
          if(!response.ok){console.warn('Gemini business insights unavailable:',response.status);return {};}
          const payload=await response.json() as {candidates?:{content?:{parts?:{text?:string;thought?:boolean}[]}}[]};
          const raw=payload.candidates?.[0]?.content?.parts?.filter(p=>!p.thought).map(p=>p.text??'').join('')??'';
          const parsed:unknown=JSON.parse(raw);
          if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))return {};
          return Object.fromEntries(eligible.flatMap(({unit})=>{
            const value=(parsed as Record<string,unknown>)[unit];
            return typeof value==='string'&&value.trim()&&value.length<=800?[[unit,value.trim()]]:[];
          }));
        }catch{return {};}
      })();
      if(cache.size>=128)cache.delete(cache.keys().next().value!);
      cache.set(cacheKey,{expires:Date.now()+15*60_000,data});
      ai=await data;
      if(!Object.keys(ai).length)cache.set(cacheKey,{expires:Date.now()+60_000,data});
    }
  }
  return Object.fromEntries(cards.map(c=>[c.unit,{text:ai[c.unit]?(ai[c.unit]+c.drivers):c.fallback,source:ai[c.unit]?'gemini':'report'}]));
}
