import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import type {Express,RequestHandler} from 'express';
import type {Pool} from 'pg';
export const olseraCatalogStagingSchema=`CREATE TABLE IF NOT EXISTS business_olsera_catalog_staging(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),company_id uuid NOT NULL REFERENCES companies(id),branch_id uuid NOT NULL REFERENCES branches(id),
 captured_on date NOT NULL,payload_hash text NOT NULL,payload jsonb NOT NULL,summary jsonb NOT NULL,
 status text NOT NULL DEFAULT 'STAGED' CHECK(status='STAGED'),actor uuid NOT NULL,created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(company_id,branch_id,payload_hash));`;
export function validateCatalogStaging(d:any){
 if(d?.format!=='simaung.olsera.catalog-staging.v1'||d.mode!=='STAGING_ONLY'||typeof d.asOfDate!=='string'||!/^20\d\d-\d\d-\d\d$/.test(d.asOfDate))throw Error('Format staging katalog tidak valid.');
 if(!Array.isArray(d.productRows)||!d.productRows.length||d.productRows.length>20000||!Array.isArray(d.recipeRows)||d.recipeRows.length>40000)throw Error('Jumlah produk / resep tidak valid.');
 const names=new Map<string,any[]>(),skus=new Map<string,any[]>(),keys=new Set<string>();let missingSku=0,duplicates=0;
 for(const r of d.productRows){
  if(typeof r.name!=='string'||!r.name||r.name.length>300)throw Error('Nama produk sumber tidak valid.');
  const list=names.get(r.name)??[];list.push(r);names.set(r.name,list);
  const key=JSON.stringify([r.name,r.variant_names??'',r.sku??'']);if(keys.has(key))duplicates++;keys.add(key);
  if(r.sku){if(typeof r.sku!=='string'||r.sku.length>100)throw Error('SKU tidak valid.');const s=r.sku.trim().toLowerCase(),ls=skus.get(s)??[];ls.push(r);skus.set(s,ls);}else missingSku++;
 }
 let resolved=0;const issues:any[]=[];
 for(const [i,r]of d.recipeRows.entries()){
  const product=r.sku?skus.get(String(r.sku).trim().toLowerCase())??[]:(names.get(r.product)??[]).filter(p=>(p.variant_names??'')===(r.variant??''));
  const material=names.get(r.material)??[];
  const q=Number(r.qty),factor=Number(r['uom conversion']);
  if(product.length!==1||material.length!==1||!Number.isFinite(q)||q<=0||!Number.isFinite(factor)||factor<=0||!material[0]?.uom)
   issues.push({line:i+2,sku:r.sku??'',type:product.length!==1?'PRODUCT_AMBIGUOUS':material.length!==1?'MATERIAL_AMBIGUOUS':'UNIT_CONVERSION_REVIEW'});
  else resolved++;
 }
 return {productNames:names.size,productVariantRows:d.productRows.length,recipeRows:d.recipeRows.length,resolvedRecipes:resolved,recipeIssues:issues.length,duplicateSkuCount:[...skus.values()].filter(v=>v.length>1).length,duplicateSourceRowCount:duplicates,blankSkuRows:missingSku,issues:issues.slice(0,100),stockActivation:'NOT_AUTHORIZED_NO_CUTOVER_DATE',livePosEffect:'NONE'};
}
export function mountOlseraCatalogStaging(app:Express,pool:Pool,auth:RequestHandler,access:RequestHandler,ensure:()=>Promise<unknown>){
 const root='/api/admin/business-reports/olsera/catalog';
 const allowed=(res:any)=>['OWNER','SYSTEM_ADMIN','FINANCE'].includes(res.locals.reportAccess.role)&&res.locals.reportAccess.unit==='all'&&!res.locals.reportAccess.property;
 app.get(root,auth,access,async(req,res)=>{
  res.set('Cache-Control','no-store');if(!allowed(res))return res.status(403).json({message:'Akses pengelolaan pusat diperlukan.'});
  try{await ensure();const r=await pool.query(`SELECT s.id,s.captured_on::text,s.summary,s.status,s.created_at,b.name AS branch,b.code FROM business_olsera_catalog_staging s JOIN branches b ON b.id=s.branch_id AND b.company_id=s.company_id WHERE s.company_id=$1 ORDER BY s.created_at DESC LIMIT 50`,[req.admin.companyId]);res.json({items:r.rows});}catch{res.status(503).json({message:'Staging katalog belum dapat dibaca.'});}
 });
 for(const commit of [false,true])app.post(root+(commit?'/commit':'/preview'),auth,access,async(req,res)=>{
  res.set('Cache-Control','no-store');if(!allowed(res))return res.status(403).json({message:'Akses pengelolaan pusat diperlukan.'});
  try{
   await ensure();const b=req.body??{};
   if(typeof b.gzipBase64!=='string'||b.gzipBase64.length>4000000)throw Error('Bundle staging terlalu besar atau tidak valid.');
   const raw=gunzipSync(Buffer.from(b.gzipBase64,'base64'),{maxOutputLength:18000000}),d=JSON.parse(raw.toString('utf8')),summary=validateCatalogStaging(d);
   const branch=(await pool.query(`SELECT b.id,b.code,b.name FROM branches b JOIN business_report_branch_units m ON m.company_id=b.company_id AND m.branch_id=b.id WHERE b.company_id=$1 AND b.id::text=$2 AND b.is_active=true`,[req.admin.companyId,String(b.branch??'')])).rows[0];
   if(!branch||branch.code!==d.branchCode)return res.status(400).json({message:'Cabang tujuan tidak sesuai dengan sumber katalog.'});
   const hash=createHash('sha256').update(raw).digest('hex'),fingerprint=createHash('sha256').update(JSON.stringify([req.admin.companyId,branch.id,hash,'STAGING_ONLY'])).digest('hex');
   if(commit){
    if(b.reviewed!==true||b.sourceAccount!==d.sourceAccount||b.fingerprint!==fingerprint)return res.status(409).json({message:'Periksa kembali pratinjau staging.'});
    const r=await pool.query(`INSERT INTO business_olsera_catalog_staging(company_id,branch_id,captured_on,payload_hash,payload,summary,actor) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(company_id,branch_id,payload_hash) DO NOTHING RETURNING id`,[req.admin.companyId,branch.id,d.asOfDate,hash,JSON.stringify(d),JSON.stringify(summary),req.admin.adminId]);
    return res.json({ok:true,id:r.rows[0]?.id,replayed:!r.rowCount,mode:'STAGING_ONLY',stockEffect:'NONE',livePosEffect:'NONE'});
   }
   res.json({branch,sourceAccount:d.sourceAccount,period:{start:d.asOfDate,end:d.asOfDate},hash,fingerprint,summary,sourceFiles:d.sources?.map((s:any)=>s.name)??[],mode:'STAGING_ONLY'});
  }catch(e){res.status(400).json({message:e instanceof Error?e.message:'Bundle staging tidak valid.'});}
 });
}
