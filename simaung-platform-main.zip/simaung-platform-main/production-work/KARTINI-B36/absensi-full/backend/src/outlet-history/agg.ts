// @ts-nocheck
import { dataset, MONTH_FULL_ID, MONTH_ID } from './dataset.js'
import type { AskItem, Outlet, OutletRow, Totals, Week } from './types.js'

const DAY = 86400000

export function parseDate(d: string): number {
  return Date.parse(d + 'T00:00:00Z')
}

/** Jumlah minggu (Senin–Minggu) yang mayoritas harinya jatuh di bulan tsb. */
export function expectedWeeksInMonth(year: number, month: number): number {
  const first = Date.UTC(year, month - 1, 1)
  const last = Date.UTC(year, month, 0)
  const dow = (new Date(first).getUTCDay() + 6) % 7 // 0 = Senin
  let cur = first - dow * DAY
  let count = 0
  while (cur <= last) {
    let inMonth = 0
    for (let i = 0; i < 7; i++) {
      const d = new Date(cur + i * DAY)
      if (d.getUTCFullYear() === year && d.getUTCMonth() === month - 1) inMonth++
    }
    if (inMonth >= 4) count++
    cur += 7 * DAY
  }
  return count
}

export function expectedWeeksInYear(year: number): number {
  let n = 0
  for (let m = 1; m <= 12; m++) n += expectedWeeksInMonth(year, m)
  return n
}

/** Normalised "now" (UTC midnight) so week comparisons are stable. */
export function todayUTC(): Date {
  const n = new Date()
  return new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate()))
}

/**
 * Only count weeks that have already started. The current month is still
 * running, so penalising an outlet for "missing" future weeks would be wrong.
 */
export function expectedWeeksElapsedInMonth(year: number, month: number, today: Date): number {
  const first = Date.UTC(year, month - 1, 1)
  const last = Date.UTC(year, month, 0)
  const dow = (new Date(first).getUTCDay() + 6) % 7
  let cur = first - dow * DAY
  let count = 0
  while (cur <= last) {
    let inMonth = 0
    for (let i = 0; i < 7; i++) {
      const d = new Date(cur + i * DAY)
      if (d.getUTCFullYear() === year && d.getUTCMonth() === month - 1) inMonth++
    }
    if (inMonth >= 4 && cur <= today.getTime()) count++
    cur += 7 * DAY
  }
  return count
}

export function isCurrentMonth(year: number, month: number, today: Date): boolean {
  return today.getUTCFullYear() === year && today.getUTCMonth() + 1 === month
}

export function isCurrentYear(year: number, today: Date): boolean {
  return today.getUTCFullYear() === year
}

/** Expected report count for the period, capped at "weeks already started". */
export function expectedWeeksFor(p: { mode: 'month' | 'year'; year: number; month: number }): number {
  const today = todayUTC()
  if (p.mode === 'month') {
    return isCurrentMonth(p.year, p.month, today)
      ? expectedWeeksElapsedInMonth(p.year, p.month, today)
      : expectedWeeksInMonth(p.year, p.month)
  }
  if (isCurrentYear(p.year, today)) {
    let n = 0
    for (let m = 1; m <= 12; m++) {
      if (m < today.getUTCMonth() + 1) n += expectedWeeksInMonth(p.year, m)
      else if (m === today.getUTCMonth() + 1) n += expectedWeeksElapsedInMonth(p.year, m, today)
    }
    return n
  }
  return expectedWeeksInYear(p.year)
}

export type PeriodMode = 'month' | 'year'

export type Period = { mode: PeriodMode; year: number; month: number }

export function periodLabel(p: Period): string {
  return p.mode === 'month'
    ? `${MONTH_FULL_ID[p.month]} ${p.year}`
    : `Tahun ${p.year}`
}

export function previousPeriod(p: Period): Period {
  if (p.mode === 'month') {
    return p.month === 1
      ? { mode: 'month', year: p.year - 1, month: 12 }
      : { mode: 'month', year: p.year, month: p.month - 1 }
  }
  return { mode: 'year', year: p.year - 1, month: 1 }
}

export function weeksInPeriod(p: Period): Week[] {
  return dataset.weeks.filter((w) =>
    p.mode === 'month' ? w.year === p.year && w.month === p.month : w.year === p.year,
  )
}

export function availablePeriods(): Period[] {
  const keys = new Set(dataset.weeks.map((w) => `${w.year}-${w.month}`))
  const out: Period[] = []
  for (const k of keys) {
    const [y, m] = k.split('-').map(Number)
    out.push({ mode: 'month', year: y, month: m })
  }
  out.sort((a, b) => b.year - a.year || b.month - a.month)

  const years = [...new Set(dataset.weeks.map((w) => w.year))].sort((a, b) => b - a)
  const yearly = years.map((y) => ({ mode: 'year' as const, year: y, month: 1 }))
  return [...out, ...yearly]
}

const sum = (xs: number[]) => xs.reduce((a, b) => a + b, 0)

/**
 * Laba tidak selalu dilaporkan. Kita tidak pernah menganggap "kosong" = 0,
 * karena itu akan membuat laba terlihat lebih buruk dari kenyataan.
 */
export function totalsOf(weeks: Week[]): Totals & { labaOmzetCoverage: number } {
  const withLaba = weeks.filter((w) => w.laba_bersih !== null)
  const omzet = sum(weeks.map((w) => w.omzet || 0))
  const laba = sum(withLaba.map((w) => w.laba_bersih || 0))
  const labaOmzet = sum(withLaba.map((w) => w.omzet || 0))
  const trx = sum(weeks.map((w) => w.transaksi || 0))
  return {
    omzet,
    laba,
    labaCoverageOmzet: omzet > 0 ? labaOmzet / omzet : 0,
    hpp: sum(weeks.map((w) => w.hpp || 0)),
    beban: sum(weeks.map((w) => w.beban || 0)),
    transaksi: trx,
    avgBasket: trx > 0 ? omzet / trx : null,
    margin: labaOmzet > 0 ? laba / labaOmzet : null,
    weeks: weeks.length,
    outlets: new Set(weeks.map((w) => w.outlet)).size,
  }
}

function pctDelta(cur: number, prev: number): number | null {
  if (!prev || !isFinite(prev) || prev === 0) return null
  return (cur - prev) / Math.abs(prev)
}

export function outletRows(
  p: Period,
  outletIds: string[],
): OutletRow[] {
  const prev = previousPeriod(p)
  const cur = weeksInPeriod(p)
  const prevWeeks = weeksInPeriod(prev)
  const expected = expectedWeeksFor(p)
  const totalOmzet = sum(cur.map((w) => w.omzet || 0))
  const rows: OutletRow[] = []

  for (const o of dataset.outlets as Outlet[]) {
    if (outletIds.length && !outletIds.includes(o.id)) continue
    const ws = cur.filter((w) => w.outlet === o.name)
    const ps = prevWeeks.filter((w) => w.outlet === o.name)
    if (!ws.length) continue
    const t = totalsOf(ws)
    const pt = totalsOf(ps)
    const crit = ws.reduce((a, w) => a + w.issues.filter((i) => i.sev === 'critical').length, 0)
    const warn = ws.reduce((a, w) => a + w.issues.filter((i) => i.sev === 'warning').length, 0)
    rows.push({
      id: o.id,
      name: o.name,
      emoji: o.emoji,
      category: o.category,
      omzet: t.omzet,
      laba: t.laba,
      margin: t.margin,
      transaksi: t.transaksi,
      avgBasket: t.avgBasket,
      weeks: t.weeks,
      expectedWeeks: expected,
      share: totalOmzet > 0 ? t.omzet / totalOmzet : 0,
      deltaOmzet: pctDelta(t.omzet, pt.omzet),
      deltaLaba: pt.laba ? pctDelta(t.laba, pt.laba) : null,
      labaConfidence: t.labaCoverageOmzet,
      issues: crit * 2 + warn,
    })
  }
  rows.sort((a, b) => b.omzet - a.omzet)
  return rows
}

/** Seri tren: bulanan → per minggu; tahunan → per bulan. */
export function trendSeries(p: Period, outletIds: string[]) {
  const cur = weeksInPeriod(p).filter(
    (w) => !outletIds.length || outletIds.includes(slugOf(w.outlet)),
  )
  if (p.mode === 'month') {
    // bucket by ISO week so outlets reporting Sun–Sat vs Mon–Sun merge cleanly
    const buckets = new Map<string, Week[]>()
    for (const w of cur) {
      const d = new Date(parseDate(w.start))
      const dow = (d.getUTCDay() + 6) % 7
      const monday = new Date(d.getTime() - dow * DAY).toISOString().slice(0, 10)
      if (!buckets.has(monday)) buckets.set(monday, [])
      buckets.get(monday)!.push(w)
    }
    return [...buckets.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([k, ws]) => {
        const d = new Date(parseDate(k))
        return {
          label: `${d.getUTCDate()}/${d.getUTCMonth() + 1}`,
          full: `Minggu ${d.getUTCDate()} ${MONTH_ID[d.getUTCMonth() + 1]}`,
          omzet: sum(ws.map((w) => w.omzet || 0)),
          laba: sum(ws.filter((w) => w.laba_bersih !== null).map((w) => w.laba_bersih || 0)),
        }
      })
  }
  const byMonth = new Map<number, Week[]>()
  for (const w of cur) {
    if (!byMonth.has(w.month)) byMonth.set(w.month, [])
    byMonth.get(w.month)!.push(w)
  }
  return [...byMonth.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([m, ws]) => ({
      label: MONTH_ID[m],
      full: MONTH_FULL_ID[m],
      omzet: sum(ws.map((w) => w.omzet || 0)),
      laba: sum(ws.filter((w) => w.laba_bersih !== null).map((w) => w.laba_bersih || 0)),
    }))
}

export function slugOf(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
}

// ---------------------------------------------------------------- "kenapa?"
const money = (n: number) => {
  if (Math.abs(n) >= 1e9) return `Rp${(n / 1e9).toFixed(2)} M`
  if (Math.abs(n) >= 1e6) return `Rp${(n / 1e6).toFixed(1)} jt`
  if (Math.abs(n) >= 1e3) return `Rp${(n / 1e3).toFixed(0)} rb`
  return `Rp${n.toFixed(0)}`
}

export function buildAsks(p: Period, outletIds: string[]): AskItem[] {
  const prev = previousPeriod(p)
  const cur = weeksInPeriod(p)
  const prevWeeks = weeksInPeriod(prev)
  const expected = expectedWeeksFor(p)
  const asks: AskItem[] = []

  for (const o of dataset.outlets as Outlet[]) {
    if (outletIds.length && !outletIds.includes(o.id)) continue
    const ws = cur.filter((w) => w.outlet === o.name)
    const ps = prevWeeks.filter((w) => w.outlet === o.name)
    if (!ws.length) continue
    const t = totalsOf(ws)
    const pt = totalsOf(ps)
    const add = (
      sev: AskItem['sev'],
      title: string,
      detail: string,
      ask: string,
    ) => asks.push({ sev, outlet: o.name, emoji: o.emoji, title, detail, ask })

    // 1. laporan tidak lengkap
    if (ws.length < expected && expected > 0) {
      const missing = expected - ws.length
      add(
        missing > expected / 2 ? 'critical' : 'warning',
        `${missing} minggu tanpa laporan`,
        `Hanya ${ws.length} dari ${expected} minggu yang masuk di periode ini. Angka periode belum final.`,
        `Minta laporan minggu yang kosong — total bisa berubah saat data lengkap.`,
      )
    }

    // 2. tidak ada HPP → laba tidak bisa dipastikan
    const noHpp = ws.filter((w) => w.hpp === null).length
    if (noHpp === ws.length) {
      add(
        'warning',
        'HPP belum pernah diisi',
        `${noHpp} laporan tanpa HPP, jadi laba bersih tidak bisa dihitung — yang terlihat hanya omzet.`,
        'Minta rincian HPP per minggu sebelum memakai angka laba outlet ini.',
      )
    }

    // 3. HPP terlalu tinggi
    const hppWeeks = ws.filter((w) => w.hpp !== null && w.omzet > 0)
    if (hppWeeks.length) {
      const ratio = sum(hppWeeks.map((w) => w.hpp!)) / sum(hppWeeks.map((w) => w.omzet))
      if (ratio > 0.8) {
        add(
          'critical',
          `HPP ${(ratio * 100).toFixed(0)}% dari omzet`,
          `Dari ${money(t.omzet)} omzet, ${money(sum(hppWeeks.map((w) => w.hpp!)))} habis untuk bahan. Sisa untuk gaji, sewa, dan listrik sangat tipis.`,
          'Tanya: harga jual terlalu rendah, porsi terlalu besar, atau HPP salah catat?',
        )
      } else if (ratio > 0.65) {
        add(
          'warning',
          `Margin kotor hanya ${((1 - ratio) * 100).toFixed(0)}%`,
          `HPP ${(ratio * 100).toFixed(0)}% dari omzet — di bawah 35% margin kotor, rawan rugi saat biaya naik.`,
          'Cek harga beli bahan dan standar porsi minggu ini.',
        )
      }
    }

    // 4. rugi
    const lossWeeks = ws.filter((w) => w.laba_bersih !== null && w.laba_bersih < 0)
    if (lossWeeks.length) {
      add(
        'critical',
        `Rugi di ${lossWeeks.length} minggu`,
        `Total kerugian ${money(sum(lossWeeks.map((w) => w.laba_bersih!)))}. Minggu terburuk: ${money(Math.min(...lossWeeks.map((w) => w.laba_bersih!)))}.`,
        'Minta rincian beban minggu tersebut — apa yang membengkak?',
      )
    }

    // 5. omzet turun tajam
    if (pt.omzet > 0 && t.omzet > 0) {
      const d = (t.omzet - pt.omzet) / pt.omzet
      if (d < -0.25 && ps.length >= 2) {
        add(
          'warning',
          `Omzet turun ${Math.abs(d * 100).toFixed(0)}%`,
          `Dari ${money(pt.omzet)} (periode lalu) ke ${money(t.omzet)}. Turun ${money(pt.omzet - t.omzet)}.`,
          'Tanya penyebabnya: sepi pengunjung, tutup, atau laporan belum lengkap?',
        )
      }
    }

    // 6. laba tidak masuk akal terhadap margin yang dilaporkan
    for (const w of ws) {
      const m = w.issues.find((i) => i.code === 'margin_beda' || i.code === 'omzet_vs_rincian')
      if (m) {
        add('critical', 'Angka di laporan tidak saling cocok', m.text, 'Minta tim menghitung ulang sebelum angka ini dipakai untuk keputusan.')
        break
      }
    }

    // 7. angka identik berturut-turut
    const dup = ws.find((w) => w.issues.some((i) => i.code === 'omzet_identik'))
    if (dup) {
      add(
        'warning',
        'Omzet sama persis di minggu berurutan',
        `Minggu ${dup.start} mencatat omzet yang identik dengan minggu sebelumnya — pola umum laporan hasil salin-tempel.`,
        'Minta bukti transaksi (struk/rekap kasir) untuk minggu tersebut.',
      )
    }

    // 8. kas menumpuk
    const lastWithKas = [...ws].reverse().find((w) => w.kas_akhir !== null)
    if (lastWithKas && lastWithKas.kas_akhir && t.omzet > 0) {
      const months = lastWithKas.kas_akhir / (t.omzet / Math.max(ws.length, 1)) / 4.33
      if (months > 3) {
        add(
          'info',
          `Kas menganggur ~${months.toFixed(1)} bulan`,
          `Saldo kas ${money(lastWithKas.kas_akhir)} setara ${months.toFixed(1)} bulan omzet, tidak berputar.`,
          'Pertimbangkan dipakai untuk stok, renovasi, atau disimpan sebagai cadangan resmi.',
        )
      }
    }
  }

  const rank = { critical: 0, warning: 1, info: 2 }
  return asks
    .sort((a, b) => rank[a.sev] - rank[b.sev])
    .slice(0, 12)
}

export function issueSummary(weeks: Week[]) {
  let critical = 0
  let warning = 0
  let info = 0
  for (const w of weeks) {
    for (const i of w.issues) {
      if (i.sev === 'critical') critical++
      else if (i.sev === 'warning') warning++
      else info++
    }
  }
  return { critical, warning, info }
}

export function outletWeeks(name: string, p: Period): Week[] {
  return weeksInPeriod(p).filter((w) => w.outlet === name)
}
