const idn = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 })
const idn1 = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 1 })

/** Rp 15.787.500 */
export function rp(n: number | null | undefined): string {
  if (n === null || n === undefined || !isFinite(n)) return '—'
  return `Rp ${idn.format(Math.round(n))}`
}

/** Rp 15,8 jt / Rp 3,00 M / Rp 407 rb */
export function compact(n: number | null | undefined): string {
  if (n === null || n === undefined || !isFinite(n)) return '—'
  const a = Math.abs(n)
  const sign = n < 0 ? '−' : ''
  if (a >= 1e12) return `${sign}Rp ${idn1.format(a / 1e12)} T`
  if (a >= 1e9) return `${sign}Rp ${idn1.format(a / 1e9)} M`
  if (a >= 1e6) return `${sign}Rp ${idn1.format(a / 1e6)} jt`
  if (a >= 1e3) return `${sign}Rp ${idn.format(Math.round(a / 1e3))} rb`
  return `${sign}Rp ${idn.format(a)}`
}

export function num(n: number | null | undefined): string {
  if (n === null || n === undefined || !isFinite(n)) return '—'
  return idn.format(Math.round(n))
}

export function pct(x: number | null | undefined, digits = 1): string {
  if (x === null || x === undefined || !isFinite(x)) return '—'
  return `${idn1.format(x * 100)}%`
}

export function deltaPct(x: number | null | undefined): string {
  if (x === null || x === undefined || !isFinite(x)) return '—'
  const s = x > 0 ? '+' : x < 0 ? '−' : ''
  return `${s}${idn1.format(Math.abs(x) * 100)}%`
}

export function dmy(iso: string): string {
  const d = new Date(iso + 'T00:00:00Z')
  return `${d.getUTCDate()}/${d.getUTCMonth() + 1}`
}
