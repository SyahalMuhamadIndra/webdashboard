export type Issue = {
  code: string
  sev: 'critical' | 'warning' | 'info'
  text: string
}

export type Week = {
  outlet: string
  start: string
  end: string
  year: number
  month: number
  week: number
  omzet: number
  hpp: number | null
  laba_kotor: number | null
  beban: number | null
  laba_bersih: number | null
  transaksi: number | null
  avg_basket: number | null
  kas_akhir: number | null
  pengeluaran: number | null
  piutang: number | null
  stok: number | null
  target_next: number | null
  format: string
  author: string | null
  source: string[]
  versions: number
  issues: Issue[]
}

export type Outlet = {
  id: string
  name: string
  category: string
  emoji: string
  authors: string[]
  weeks_reported: number
  first_week: string
  last_week: string
}

export type Dataset = {
  generated_at: string
  source: string
  outlets: Outlet[]
  weeks: Week[]
}

export type PeriodMode = 'month' | 'year'

export type Totals = {
  omzet: number
  laba: number
  labaCoverageOmzet: number
  hpp: number
  beban: number
  transaksi: number
  avgBasket: number | null
  margin: number | null
  weeks: number
  outlets: number
}

export type OutletRow = {
  id: string
  name: string
  emoji: string
  category: string
  omzet: number
  laba: number
  margin: number | null
  transaksi: number
  avgBasket: number | null
  weeks: number
  expectedWeeks: number
  share: number
  deltaOmzet: number | null
  deltaLaba: number | null
  labaConfidence: number
  issues: number
}

export type AskItem = {
  sev: 'critical' | 'warning' | 'info'
  outlet: string
  emoji: string
  title: string
  detail: string
  ask: string
}
