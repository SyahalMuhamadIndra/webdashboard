export const dataset = {
 "generated_at": "2026-11-19T07:39:36Z",
 "source": "Weekly Report xlsx (7 outlet, Mar–Nov 2026)",
 "outlets": [
  {
   "id": "cherry-bakes-house",
   "name": "Cherry Bakes House",
   "category": "Bakery",
   "emoji": "🍞",
   "authors": [
    "Maryam Fatonah",
    "Sesky Triokta Nursyabani"
   ],
   "weeks_reported": 29,
   "first_week": "2026-03-22",
   "last_week": "2026-11-15"
  },
  {
   "id": "maja-koffie",
   "name": "Maja Koffie",
   "category": "Coffee & Eatery",
   "emoji": "☕",
   "authors": [
    "Etin Suhaetin",
    "Nabila Nurhuda Sysiera"
   ],
   "weeks_reported": 34,
   "first_week": "2026-03-22",
   "last_week": "2026-11-15"
  },
  {
   "id": "mitra-water",
   "name": "Mitra Water",
   "category": "Depot Air",
   "emoji": "💧",
   "authors": [
    "Suhendra"
   ],
   "weeks_reported": 30,
   "first_week": "2026-03-22",
   "last_week": "2026-11-15"
  },
  {
   "id": "rm-sindang-hurip",
   "name": "RM Sindang Hurip",
   "category": "Rumah Makan",
   "emoji": "🍚",
   "authors": [
    "Akbar",
    "M Abdul Azis"
   ],
   "weeks_reported": 30,
   "first_week": "2026-03-22",
   "last_week": "2026-11-15"
  },
  {
   "id": "river-inn",
   "name": "River Inn",
   "category": "Resto & Villa",
   "emoji": "🌿",
   "authors": [
    "Etin Suhaetin",
    "Manda"
   ],
   "weeks_reported": 2,
   "first_week": "2026-11-01",
   "last_week": "2026-11-14"
  },
  {
   "id": "sweet-escape",
   "name": "Sweet Escape",
   "category": "Dessert Cafe",
   "emoji": "🍰",
   "authors": [
    "Maryam Fatonah"
   ],
   "weeks_reported": 29,
   "first_week": "2026-03-22",
   "last_week": "2026-11-15"
  },
  {
   "id": "tk-kartini",
   "name": "Tk Kartini",
   "category": "Toko Kue",
   "emoji": "🎂",
   "authors": [
    "Ita & Sopian",
    "Ita Novita",
    "Sopian"
   ],
   "weeks_reported": 33,
   "first_week": "2026-03-22",
   "last_week": "2026-11-15"
  }
 ],
 "weeks": [
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-03-22",
   "end": "2026-03-28",
   "year": 2026,
   "month": 3,
   "week": 12,
   "omzet": 22865000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 17.0,
   "avg_basket": 1345000.0,
   "kas_akhir": 42122712.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "22 Mar - 28 Mar"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-03-29",
   "end": "2026-04-04",
   "year": 2026,
   "month": 4,
   "week": 13,
   "omzet": 12091000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 13.0,
   "avg_basket": 930076.92,
   "kas_akhir": 50900326.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "29 Mar - 4 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp51 jt = 4.2× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-04-05",
   "end": "2026-04-11",
   "year": 2026,
   "month": 4,
   "week": 14,
   "omzet": 10214500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 11.0,
   "avg_basket": 928590.91,
   "kas_akhir": 58197433.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "5 Apr - 11 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp58 jt = 5.7× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-04-12",
   "end": "2026-04-18",
   "year": 2026,
   "month": 4,
   "week": 15,
   "omzet": 12530500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1350000.0,
   "laba_bersih": null,
   "transaksi": 12.0,
   "avg_basket": 1044208.33,
   "kas_akhir": 45288012.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "12 Apr - 18 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-04-19",
   "end": "2026-04-25",
   "year": 2026,
   "month": 4,
   "week": 16,
   "omzet": 15349000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1350000.0,
   "laba_bersih": null,
   "transaksi": 16.0,
   "avg_basket": 959312.5,
   "kas_akhir": 42618876.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "19 Apr - 25 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-05-03",
   "end": "2026-05-09",
   "year": 2026,
   "month": 5,
   "week": 18,
   "omzet": 16534000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1272000.0,
   "laba_bersih": null,
   "transaksi": 17.0,
   "avg_basket": 972588.24,
   "kas_akhir": 55258056.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "3 Mei - 9 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-05-10",
   "end": "2026-05-16",
   "year": 2026,
   "month": 5,
   "week": 19,
   "omzet": 19164000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1730769.0,
   "laba_bersih": null,
   "transaksi": 18.0,
   "avg_basket": 1064666.67,
   "kas_akhir": 59657782.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "10 Mei - 16 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-05-17",
   "end": "2026-05-23",
   "year": 2026,
   "month": 5,
   "week": 20,
   "omzet": 17505000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1730769.0,
   "laba_bersih": null,
   "transaksi": 17.0,
   "avg_basket": 1029705.88,
   "kas_akhir": 60652885.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "17 Mei - 23 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-06-01",
   "end": "2026-06-07",
   "year": 2026,
   "month": 6,
   "week": 23,
   "omzet": 23175500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1730000.0,
   "laba_bersih": null,
   "transaksi": 18.0,
   "avg_basket": 1287527.78,
   "kas_akhir": 70176191.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "1 Juni - 7 Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-06-08",
   "end": "2026-06-14",
   "year": 2026,
   "month": 6,
   "week": 24,
   "omzet": 17493000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1730000.0,
   "laba_bersih": null,
   "transaksi": 20.0,
   "avg_basket": 874650.0,
   "kas_akhir": 72040348.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "8 Juni - 14 Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp72 jt = 4.1× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-06-15",
   "end": "2026-06-21",
   "year": 2026,
   "month": 6,
   "week": 25,
   "omzet": 17953000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1730000.0,
   "laba_bersih": null,
   "transaksi": 20.0,
   "avg_basket": 897650.0,
   "kas_akhir": 91654377.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "15 Juni - 21 Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp92 jt = 5.1× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-06-22",
   "end": "2026-06-28",
   "year": 2026,
   "month": 6,
   "week": 26,
   "omzet": 17911500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1730000.0,
   "laba_bersih": null,
   "transaksi": 19.0,
   "avg_basket": 942710.53,
   "kas_akhir": 99519783.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "22 Juni - 28 Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp100 jt = 5.6× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-07-06",
   "end": "2026-07-12",
   "year": 2026,
   "month": 7,
   "week": 28,
   "omzet": 17241500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1730000.0,
   "laba_bersih": null,
   "transaksi": 18.0,
   "avg_basket": 957861.11,
   "kas_akhir": 96733198.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "6 Juli - 12 Juli"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp97 jt = 5.6× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-07-13",
   "end": "2026-07-19",
   "year": 2026,
   "month": 7,
   "week": 29,
   "omzet": 16693000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1730000.0,
   "laba_bersih": null,
   "transaksi": 17.0,
   "avg_basket": 981941.18,
   "kas_akhir": 110030205.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "13 Juli - 19 Juli"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp110 jt = 6.6× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-07-27",
   "end": "2026-08-02",
   "year": 2026,
   "month": 7,
   "week": 31,
   "omzet": 16666000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1730000.0,
   "laba_bersih": null,
   "transaksi": 17.0,
   "avg_basket": 980352.94,
   "kas_akhir": 119851586.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "27 Juli - 2 Agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp120 jt = 7.2× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-08-03",
   "end": "2026-08-09",
   "year": 2026,
   "month": 8,
   "week": 32,
   "omzet": 16693500.0,
   "hpp": 7662959.0,
   "laba_kotor": 9030541.0,
   "beban": 2458101.0,
   "laba_bersih": 6572440.0,
   "transaksi": 17.0,
   "avg_basket": 981970.59,
   "kas_akhir": 123585995.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "3 agustus - 9 agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp124 jt = 7.4× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-08-10",
   "end": "2026-08-16",
   "year": 2026,
   "month": 8,
   "week": 33,
   "omzet": 13207500.0,
   "hpp": 6457578.0,
   "laba_kotor": 6749922.0,
   "beban": 1930162.0,
   "laba_bersih": 4819760.0,
   "transaksi": 16.0,
   "avg_basket": 825468.75,
   "kas_akhir": 127556101.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "10 agustus - 16 agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp128 jt = 9.7× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-08-17",
   "end": "2026-08-23",
   "year": 2026,
   "month": 8,
   "week": 34,
   "omzet": 17493136.0,
   "hpp": 8089074.0,
   "laba_kotor": 9404062.0,
   "beban": 5940245.0,
   "laba_bersih": 3463817.0,
   "transaksi": 15.0,
   "avg_basket": 1166209.07,
   "kas_akhir": 131665198.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "17 agustus - 23 agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp132 jt = 7.5× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-08-24",
   "end": "2026-08-30",
   "year": 2026,
   "month": 8,
   "week": 35,
   "omzet": 15697314.0,
   "hpp": 7116827.0,
   "laba_kotor": 8580487.0,
   "beban": 2384516.0,
   "laba_bersih": 6195971.0,
   "transaksi": 15.0,
   "avg_basket": 1046487.6,
   "kas_akhir": 133736973.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "24 agustus - 30 agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp134 jt = 8.5× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-08-31",
   "end": "2026-09-06",
   "year": 2026,
   "month": 9,
   "week": 36,
   "omzet": 15697314.0,
   "hpp": 7116827.0,
   "laba_kotor": 8580487.0,
   "beban": 2384516.0,
   "laba_bersih": 6195971.0,
   "transaksi": 15.0,
   "avg_basket": 1046487.6,
   "kas_akhir": 133736973.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "31 agustus - 6 september"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Tanggal di header (24/08–30/08) tidak cocok dengan nama tab; dipakai nama tab."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp134 jt = 8.5× omzet mingguan (dana menganggur)."
    },
    {
     "code": "omzet_identik",
     "sev": "warning",
     "text": "Omzet persis sama dengan minggu sebelumnya (Rp15,697,314) — cek apakah laporan disalin."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-09-07",
   "end": "2026-09-13",
   "year": 2026,
   "month": 9,
   "week": 37,
   "omzet": 14899000.0,
   "hpp": 7320522.0,
   "laba_kotor": 7578478.0,
   "beban": 2415615.0,
   "laba_bersih": 5162863.0,
   "transaksi": 16.0,
   "avg_basket": 931187.5,
   "kas_akhir": 142612749.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "7 september - 13 september"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp143 jt = 9.6× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-09-14",
   "end": "2026-09-20",
   "year": 2026,
   "month": 9,
   "week": 38,
   "omzet": 15078750.0,
   "hpp": 6802480.0,
   "laba_kotor": 8276270.0,
   "beban": 3016311.0,
   "laba_bersih": 5259959.0,
   "transaksi": 18.0,
   "avg_basket": 837708.33,
   "kas_akhir": 146774406.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "14 september - 20 september"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp147 jt = 9.7× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-09-21",
   "end": "2026-09-27",
   "year": 2026,
   "month": 9,
   "week": 39,
   "omzet": 14608886.0,
   "hpp": 6157986.0,
   "laba_kotor": 8450900.0,
   "beban": 3800201.0,
   "laba_bersih": 4650699.0,
   "transaksi": 16.0,
   "avg_basket": 913055.38,
   "kas_akhir": 151006306.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "21 september - 27 september"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp151 jt = 10.3× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-10-05",
   "end": "2026-10-11",
   "year": 2026,
   "month": 10,
   "week": 41,
   "omzet": 13088250.0,
   "hpp": 6464290.0,
   "laba_kotor": 6623960.0,
   "beban": 2573208.0,
   "laba_bersih": 4050752.0,
   "transaksi": 16.0,
   "avg_basket": 818015.62,
   "kas_akhir": 152027104.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "5 oktober - 11 oktober"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp152 jt = 11.6× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-10-12",
   "end": "2026-10-18",
   "year": 2026,
   "month": 10,
   "week": 42,
   "omzet": 14906500.0,
   "hpp": 7617333.0,
   "laba_kotor": 7289167.0,
   "beban": 4046090.0,
   "laba_bersih": 3243077.0,
   "transaksi": 16.0,
   "avg_basket": 931656.25,
   "kas_akhir": 151306382.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "12 oktober - 18 oktober"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp151 jt = 10.2× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-10-19",
   "end": "2026-10-25",
   "year": 2026,
   "month": 10,
   "week": 43,
   "omzet": 12897500.0,
   "hpp": 7107413.0,
   "laba_kotor": 5790087.0,
   "beban": 2184237.0,
   "laba_bersih": 3605850.0,
   "transaksi": 17.0,
   "avg_basket": 758676.47,
   "kas_akhir": 163656106.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "19 oktober - 25 oktober"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp164 jt = 12.7× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-10-26",
   "end": "2026-11-01",
   "year": 2026,
   "month": 10,
   "week": 44,
   "omzet": 15168500.0,
   "hpp": 8036314.0,
   "laba_kotor": 7132186.0,
   "beban": 4291611.0,
   "laba_bersih": 2840575.0,
   "transaksi": 18.0,
   "avg_basket": 842694.44,
   "kas_akhir": 168720116.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "26 oktober - 1 November"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp169 jt = 11.1× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-11-02",
   "end": "2026-11-08",
   "year": 2026,
   "month": 11,
   "week": 45,
   "omzet": 17731250.0,
   "hpp": 11166798.0,
   "laba_kotor": 6564452.0,
   "beban": 2287794.0,
   "laba_bersih": 4276658.0,
   "transaksi": 21.0,
   "avg_basket": 844345.24,
   "kas_akhir": 162763959.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Sesky Triokta Nursyabani",
   "source": [
    "2 November - 8 November"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp163 jt = 9.2× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Cherry Bakes House",
   "start": "2026-11-09",
   "end": "2026-11-15",
   "year": 2026,
   "month": 11,
   "week": 46,
   "omzet": 14347700.0,
   "hpp": 8246993.0,
   "laba_kotor": 6100707.0,
   "beban": 2838340.0,
   "laba_bersih": 3262367.0,
   "transaksi": 19.0,
   "avg_basket": 755142.11,
   "kas_akhir": 171182349.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Sesky Triokta Nursyabani",
   "source": [
    "9 November - 15 November"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp171 jt = 11.9× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-03-22",
   "end": "2026-03-28",
   "year": 2026,
   "month": 3,
   "week": 12,
   "omzet": 139159500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 1503.0,
   "avg_basket": 92587.82,
   "kas_akhir": null,
   "pengeluaran": 77008293.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "22 Mar - 28 Mar"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-03-29",
   "end": "2026-04-04",
   "year": 2026,
   "month": 4,
   "week": 13,
   "omzet": 75836500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 905.0,
   "avg_basket": 83797.24,
   "kas_akhir": null,
   "pengeluaran": 168722050.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": null,
   "source": [
    "29 Mar - 4 Apr"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-04-05",
   "end": "2026-04-11",
   "year": 2026,
   "month": 4,
   "week": 14,
   "omzet": 77921500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 852.0,
   "avg_basket": 91457.16,
   "kas_akhir": null,
   "pengeluaran": 39771037.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": null,
   "source": [
    "5 Apr - 11 Apr"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-04-12",
   "end": "2026-04-18",
   "year": 2026,
   "month": 4,
   "week": 15,
   "omzet": 74229499.0,
   "hpp": 45235096.0,
   "laba_kotor": 28994403.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 905.0,
   "avg_basket": 58772.37,
   "kas_akhir": null,
   "pengeluaran": 71696450.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "12 Apr - 18 Apr"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "905 transaksi × Rp58,772 = Rp53.2 jt, tidak sama dengan omzet Rp74.2 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-04-19",
   "end": "2026-04-25",
   "year": 2026,
   "month": 4,
   "week": 16,
   "omzet": 84226500.0,
   "hpp": 0.0,
   "laba_kotor": 84226500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 976.0,
   "avg_basket": 62022.46,
   "kas_akhir": null,
   "pengeluaran": 38609325.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "19 Apr - 25 Apr"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "976 transaksi × Rp62,022 = Rp60.5 jt, tidak sama dengan omzet Rp84.2 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-04-26",
   "end": "2026-05-02",
   "year": 2026,
   "month": 4,
   "week": 17,
   "omzet": 88407500.0,
   "hpp": 0.0,
   "laba_kotor": 88407500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 988.0,
   "avg_basket": 64814.88,
   "kas_akhir": null,
   "pengeluaran": 165484879.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "26 Apr - 02 Mei"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "988 transaksi × Rp64,815 = Rp64.0 jt, tidak sama dengan omzet Rp88.4 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-05-03",
   "end": "2026-05-09",
   "year": 2026,
   "month": 5,
   "week": 18,
   "omzet": 83348000.0,
   "hpp": 0.0,
   "laba_kotor": 83348000.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 930.0,
   "avg_basket": 63479.06,
   "kas_akhir": null,
   "pengeluaran": 62923095.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "03 Mei - 09 Mei"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "930 transaksi × Rp63,479 = Rp59.0 jt, tidak sama dengan omzet Rp83.3 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-05-10",
   "end": "2026-05-16",
   "year": 2026,
   "month": 5,
   "week": 19,
   "omzet": 90714500.0,
   "hpp": 0.0,
   "laba_kotor": 90714500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 992.0,
   "avg_basket": 68879.65,
   "kas_akhir": null,
   "pengeluaran": 66142260.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "10 Mei - 16 Mei"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "992 transaksi × Rp68,880 = Rp68.3 jt, tidak sama dengan omzet Rp90.7 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-05-17",
   "end": "2026-05-23",
   "year": 2026,
   "month": 5,
   "week": 20,
   "omzet": 79869500.0,
   "hpp": 0.0,
   "laba_kotor": 79869500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 863.0,
   "avg_basket": 66336.79,
   "kas_akhir": null,
   "pengeluaran": 50987970.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "17 Mei - 23 Mei"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "863 transaksi × Rp66,337 = Rp57.2 jt, tidak sama dengan omzet Rp79.9 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-05-24",
   "end": "2026-05-31",
   "year": 2026,
   "month": 5,
   "week": 21,
   "omzet": 123971500.0,
   "hpp": 0.0,
   "laba_kotor": 123971500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 1258.0,
   "avg_basket": 70278.63,
   "kas_akhir": null,
   "pengeluaran": 140828461.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "24 Mei - 31 Mei"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "1258 transaksi × Rp70,279 = Rp88.4 jt, tidak sama dengan omzet Rp124.0 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-06-01",
   "end": "2026-06-07",
   "year": 2026,
   "month": 6,
   "week": 23,
   "omzet": 92555500.0,
   "hpp": 0.0,
   "laba_kotor": 92555500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 984.0,
   "avg_basket": 69800.53,
   "kas_akhir": null,
   "pengeluaran": 57738498.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "01 Juni -  7 Juni"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "984 transaksi × Rp69,801 = Rp68.7 jt, tidak sama dengan omzet Rp92.6 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-06-08",
   "end": "2026-06-14",
   "year": 2026,
   "month": 6,
   "week": 24,
   "omzet": 92477500.0,
   "hpp": 0.0,
   "laba_kotor": 92477500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 961.0,
   "avg_basket": 70111.83,
   "kas_akhir": null,
   "pengeluaran": 58558276.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "8 Juni - 14 Juni"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "961 transaksi × Rp70,112 = Rp67.4 jt, tidak sama dengan omzet Rp92.5 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-06-15",
   "end": "2026-06-21",
   "year": 2026,
   "month": 6,
   "week": 25,
   "omzet": 92155500.0,
   "hpp": 0.0,
   "laba_kotor": 92155500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 957.0,
   "avg_basket": 70834.36,
   "kas_akhir": null,
   "pengeluaran": 61024469.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "15 Juni - 21 Juni"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "957 transaksi × Rp70,834 = Rp67.8 jt, tidak sama dengan omzet Rp92.2 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-06-22",
   "end": "2026-06-28",
   "year": 2026,
   "month": 6,
   "week": 26,
   "omzet": 93114000.0,
   "hpp": 0.0,
   "laba_kotor": 93114000.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 894.0,
   "avg_basket": 72745.31,
   "kas_akhir": null,
   "pengeluaran": 188021349.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "22 Juni -28 Juni"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "894 transaksi × Rp72,745 = Rp65.0 jt, tidak sama dengan omzet Rp93.1 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-06-29",
   "end": "2026-07-05",
   "year": 2026,
   "month": 7,
   "week": 27,
   "omzet": 87584000.0,
   "hpp": 0.0,
   "laba_kotor": 87584000.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 904.0,
   "avg_basket": 71967.13,
   "kas_akhir": null,
   "pengeluaran": 141073382.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "29 Juni - 5 Juli"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "904 transaksi × Rp71,967 = Rp65.1 jt, tidak sama dengan omzet Rp87.6 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-07-06",
   "end": "2026-07-12",
   "year": 2026,
   "month": 7,
   "week": 28,
   "omzet": 88245500.0,
   "hpp": 0.0,
   "laba_kotor": 88245500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 924.0,
   "avg_basket": 71686.03,
   "kas_akhir": null,
   "pengeluaran": 54920481.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "06 Juli - 12 Juli"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "924 transaksi × Rp71,686 = Rp66.2 jt, tidak sama dengan omzet Rp88.2 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-07-13",
   "end": "2026-07-19",
   "year": 2026,
   "month": 7,
   "week": 29,
   "omzet": 81733000.0,
   "hpp": 0.0,
   "laba_kotor": 81733000.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 943.0,
   "avg_basket": 66020.19,
   "kas_akhir": null,
   "pengeluaran": 59112648.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "13 Juli - 19 Juli"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "943 transaksi × Rp66,020 = Rp62.3 jt, tidak sama dengan omzet Rp81.7 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-07-20",
   "end": "2026-07-26",
   "year": 2026,
   "month": 7,
   "week": 30,
   "omzet": 81837500.0,
   "hpp": 0.0,
   "laba_kotor": 81837500.0,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 852.0,
   "avg_basket": 72809.16,
   "kas_akhir": null,
   "pengeluaran": 65051139.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Etin Suhaetin",
   "source": [
    "20 Juli - 26 Juli"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "852 transaksi × Rp72,809 = Rp62.0 jt, tidak sama dengan omzet Rp81.8 jt."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-07-27",
   "end": "2026-08-02",
   "year": 2026,
   "month": 7,
   "week": 31,
   "omzet": 80749500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 1196.0,
   "avg_basket": 67516.3,
   "kas_akhir": 278889096.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "riwayat",
   "author": null,
   "source": [
    "Riwayat Omzet"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Diambil dari tab riwayat (tab mingguan tidak ada)"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-08-03",
   "end": "2026-08-09",
   "year": 2026,
   "month": 8,
   "week": 32,
   "omzet": 85141500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 11152006.0,
   "laba_bersih": 73989494.0,
   "transaksi": 1276.0,
   "avg_basket": 66725.31,
   "kas_akhir": 337672813.0,
   "pengeluaran": null,
   "piutang": 1500000.0,
   "stok": 29054127.0,
   "target_next": null,
   "format": "riwayat",
   "author": null,
   "source": [
    "Riwayat Omzet"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Diambil dari tab riwayat (tab mingguan tidak ada)"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-08-10",
   "end": "2026-08-16",
   "year": 2026,
   "month": 8,
   "week": 33,
   "omzet": 84196500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 17471591.0,
   "laba_bersih": 66724909.0,
   "transaksi": 1252.0,
   "avg_basket": 67249.6,
   "kas_akhir": 358601215.0,
   "pengeluaran": null,
   "piutang": 2709900.0,
   "stok": 34054792.0,
   "target_next": null,
   "format": "riwayat",
   "author": null,
   "source": [
    "Riwayat Omzet"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Diambil dari tab riwayat (tab mingguan tidak ada)"
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp359 jt = 4.3× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-08-17",
   "end": "2026-08-23",
   "year": 2026,
   "month": 8,
   "week": 34,
   "omzet": 85060000.0,
   "hpp": 66397486.0,
   "laba_kotor": 18662514.0,
   "beban": 13301174.0,
   "laba_bersih": 5361340.0,
   "transaksi": 1249.0,
   "avg_basket": 68102.48,
   "kas_akhir": 375925898.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 25671350.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Nabila Nurhuda Sysiera",
   "source": [
    "WEEKLY v3 (17 Ags - 23 Ags)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp376 jt = 4.4× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-08-24",
   "end": "2026-08-30",
   "year": 2026,
   "month": 8,
   "week": 35,
   "omzet": 83901000.0,
   "hpp": 61191863.0,
   "laba_kotor": 22709137.0,
   "beban": 9909880.0,
   "laba_bersih": 12799257.0,
   "transaksi": 1204.0,
   "avg_basket": 69685.22,
   "kas_akhir": 406779258.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 22572960.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Nabila Nurhuda Sysiera",
   "source": [
    "WEEKLY v3 (24 Ags - 30 Ags)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp407 jt = 4.8× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-08-31",
   "end": "2026-09-06",
   "year": 2026,
   "month": 9,
   "week": 36,
   "omzet": 84418500.0,
   "hpp": 61701184.0,
   "laba_kotor": 22717316.0,
   "beban": 12624332.0,
   "laba_bersih": 10092984.0,
   "transaksi": 1235.0,
   "avg_basket": 68355.06,
   "kas_akhir": null,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 33698734.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Nabila Nurhuda Sysiera",
   "source": [
    "WEEKLY v3 (31 Ags - 6 Sep)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-09-07",
   "end": "2026-09-13",
   "year": 2026,
   "month": 9,
   "week": 37,
   "omzet": 84270000.0,
   "hpp": 61851050.0,
   "laba_kotor": 22418950.0,
   "beban": 23532844.0,
   "laba_bersih": -1113894.0,
   "transaksi": 1147.0,
   "avg_basket": 73469.92,
   "kas_akhir": null,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 39464414.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Nabila Nurhuda Sysiera",
   "source": [
    "WEEKLY v3 (7 Sep - 13 Sep)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "rugi",
     "sev": "critical",
     "text": "Laba bersih negatif Rp1.1 jt."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-09-14",
   "end": "2026-09-20",
   "year": 2026,
   "month": 9,
   "week": 38,
   "omzet": 86919500.0,
   "hpp": 54519566.0,
   "laba_kotor": 32399934.0,
   "beban": 16731397.0,
   "laba_bersih": 15668537.0,
   "transaksi": 1239.0,
   "avg_basket": 70152.95,
   "kas_akhir": 356340443.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 32608291.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Nabila Nurhuda Sysiera",
   "source": [
    "WEEKLY v3 (14 Sep - 20 Sep)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp356 jt = 4.1× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-09-21",
   "end": "2026-09-27",
   "year": 2026,
   "month": 9,
   "week": 39,
   "omzet": 80757000.0,
   "hpp": 57277298.0,
   "laba_kotor": 23479702.0,
   "beban": 5406661.0,
   "laba_bersih": 18073041.0,
   "transaksi": 1195.0,
   "avg_basket": 67579.08,
   "kas_akhir": 403234747.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 28914478.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Nabila Nurhuda Sysiera",
   "source": [
    "WEEKLY v3 (21 Sep - 27 Sep)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp403 jt = 5.0× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-09-28",
   "end": "2026-10-04",
   "year": 2026,
   "month": 10,
   "week": 40,
   "omzet": 89067000.0,
   "hpp": 59689163.0,
   "laba_kotor": 29377837.0,
   "beban": 84336753.0,
   "laba_bersih": -54958916.0,
   "transaksi": 1230.0,
   "avg_basket": 72412.2,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 0.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Etin Suhaetin",
   "source": [
    "WEEKLY v3 (28 Sep - 04 Okt)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "rugi",
     "sev": "critical",
     "text": "Laba bersih negatif Rp55.0 jt."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-10-05",
   "end": "2026-10-11",
   "year": 2026,
   "month": 10,
   "week": 41,
   "omzet": 84757000.0,
   "hpp": 56964894.0,
   "laba_kotor": 27792106.0,
   "beban": 12820080.0,
   "laba_bersih": 14972026.0,
   "transaksi": 1300.0,
   "avg_basket": 65197.69,
   "kas_akhir": 300127524.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 41389919.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Etin Suhaetin",
   "source": [
    "WEEKLY v3 (05-11 Okt)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-10-12",
   "end": "2026-10-18",
   "year": 2026,
   "month": 10,
   "week": 42,
   "omzet": 97367000.0,
   "hpp": 59734950.0,
   "laba_kotor": 37632050.0,
   "beban": 14805828.0,
   "laba_bersih": 22826222.0,
   "transaksi": 1368.0,
   "avg_basket": 71174.71,
   "kas_akhir": 338571247.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 38022543.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Etin Suhaetin",
   "source": [
    "WEEKLY v3 (12-18 Okt)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-10-19",
   "end": "2026-10-25",
   "year": 2026,
   "month": 10,
   "week": 43,
   "omzet": 89359000.0,
   "hpp": 64778535.0,
   "laba_kotor": 24580465.0,
   "beban": 10268032.0,
   "laba_bersih": 13435931.0,
   "transaksi": 1265.0,
   "avg_basket": 70639.53,
   "kas_akhir": 325474824.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 37490064.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": null,
   "source": [
    "PROTO v4 (19-25 Okt)",
    "WEEKLY v3 (19-25 Okt)"
   ],
   "versions": 4,
   "issues": [
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "4 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-10-26",
   "end": "2026-11-01",
   "year": 2026,
   "month": 10,
   "week": 44,
   "omzet": 81208500.0,
   "hpp": 52552843.0,
   "laba_kotor": 28655657.0,
   "beban": 65427017.0,
   "laba_bersih": -36771360.0,
   "transaksi": 1163.0,
   "avg_basket": 69826.74,
   "kas_akhir": 339142515.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 47126751.0,
   "target_next": 90000000.0,
   "format": "proto",
   "author": "Nabila Nurhuda Sysiera",
   "source": [
    "WEEKLY v3 (26 Okt- 1 Nov )"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "rugi",
     "sev": "critical",
     "text": "Laba bersih negatif Rp36.8 jt."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp339 jt = 4.2× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-11-02",
   "end": "2026-11-08",
   "year": 2026,
   "month": 11,
   "week": 45,
   "omzet": 90754500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": 40800004.0,
   "transaksi": 1348.0,
   "avg_basket": 67325.3,
   "kas_akhir": 364430764.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": 85000000.0,
   "format": "proto",
   "author": null,
   "source": [
    " PROTO v4 (2-8 Nov)"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp364 jt = 4.0× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Maja Koffie",
   "start": "2026-11-09",
   "end": "2026-11-15",
   "year": 2026,
   "month": 11,
   "week": 46,
   "omzet": 85204500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": 24689739.0,
   "transaksi": 1236.0,
   "avg_basket": 68935.68,
   "kas_akhir": 384067007.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": 85000000.0,
   "format": "proto",
   "author": null,
   "source": [
    "PROTO v4 (9-15 Nov)"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp384 jt = 4.5× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-03-22",
   "end": "2026-03-28",
   "year": 2026,
   "month": 3,
   "week": 12,
   "omzet": 557000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 8.0,
   "avg_basket": 69625.0,
   "kas_akhir": 3908000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "22 Mar - 28 Mar"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "unit_ribuan",
     "sev": "info",
     "text": "Nilai dilaporkan dalam ribuan (bukan rupiah penuh); sudah dikonversi ×1.000."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp4 jt = 7.0× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-03-29",
   "end": "2026-04-04",
   "year": 2026,
   "month": 4,
   "week": 13,
   "omzet": 588000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 103000000.0,
   "laba_bersih": null,
   "transaksi": 14.0,
   "avg_basket": 42000.0,
   "kas_akhir": 1837000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "29 Mar - 4 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "unit_ribuan",
     "sev": "info",
     "text": "Nilai dilaporkan dalam ribuan (bukan rupiah penuh); sudah dikonversi ×1.000."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-04-05",
   "end": "2026-04-11",
   "year": 2026,
   "month": 4,
   "week": 14,
   "omzet": 358000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 103000000.0,
   "laba_bersih": null,
   "transaksi": 8.0,
   "avg_basket": 44750.0,
   "kas_akhir": 1557000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "5 Apr - 11 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "unit_ribuan",
     "sev": "info",
     "text": "Nilai dilaporkan dalam ribuan (bukan rupiah penuh); sudah dikonversi ×1.000."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp2 jt = 4.3× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-04-12",
   "end": "2026-04-20",
   "year": 2026,
   "month": 4,
   "week": 15,
   "omzet": 623000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 9.0,
   "avg_basket": 69222.22,
   "kas_akhir": 1951.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "12 Apr - 20 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-04-20",
   "end": "2026-04-27",
   "year": 2026,
   "month": 4,
   "week": 17,
   "omzet": 384000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 103000.0,
   "laba_bersih": null,
   "transaksi": 4.0,
   "avg_basket": 96000.0,
   "kas_akhir": 1688000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "20 Apr - 27 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp2 jt = 4.4× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-05-03",
   "end": "2026-05-11",
   "year": 2026,
   "month": 5,
   "week": 18,
   "omzet": 407000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 81400.0,
   "kas_akhir": 434000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "03 mei - 11 mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-05-10",
   "end": "2026-05-17",
   "year": 2026,
   "month": 5,
   "week": 19,
   "omzet": 511000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 103000.0,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 102200.0,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "10 mei - 17 mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-05-17",
   "end": "2026-05-25",
   "year": 2026,
   "month": 5,
   "week": 20,
   "omzet": 394000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 78800.0,
   "kas_akhir": 531000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    " 17 mei - 25 mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-05-25",
   "end": "2026-06-01",
   "year": 2026,
   "month": 5,
   "week": 22,
   "omzet": 394000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 78800.0,
   "kas_akhir": 531000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    " 25 mei - 1 juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "omzet_identik",
     "sev": "warning",
     "text": "Omzet persis sama dengan minggu sebelumnya (Rp394,000) — cek apakah laporan disalin."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-06-01",
   "end": "2026-06-07",
   "year": 2026,
   "month": 6,
   "week": 23,
   "omzet": 649000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 129800.0,
   "kas_akhir": 1175000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "1 juni - 7 juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-06-07",
   "end": "2026-06-14",
   "year": 2026,
   "month": 6,
   "week": 23,
   "omzet": 551000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 110200.0,
   "kas_akhir": 1332000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "7 juni - 14 juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-06-14",
   "end": "2026-06-21",
   "year": 2026,
   "month": 6,
   "week": 24,
   "omzet": 442000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 88400.0,
   "kas_akhir": 1375000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "14juni-21juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-06-22",
   "end": "2026-06-28",
   "year": 2026,
   "month": 6,
   "week": 26,
   "omzet": 417000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 53500.0,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 83400.0,
   "kas_akhir": 1675000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "22 juni - 28 juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "kas_menganggur",
     "sev": "info",
     "text": "Kas akhir Rp2 jt = 4.0× omzet mingguan (dana menganggur)."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-06-28",
   "end": "2026-07-06",
   "year": 2026,
   "month": 7,
   "week": 26,
   "omzet": 600000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 120000.0,
   "kas_akhir": 1283000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "28 juni - 6 july"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-07-06",
   "end": "2026-07-13",
   "year": 2026,
   "month": 7,
   "week": 28,
   "omzet": 1000000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 125000.0,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 200000.0,
   "kas_akhir": 1195000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "6 july-13july"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp1.0 jt tapi rincian penjualan Rp0.5 jt (selisih Rp0.5 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-07-14",
   "end": "2026-07-20",
   "year": 2026,
   "month": 7,
   "week": 29,
   "omzet": 491000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 98200.0,
   "kas_akhir": 1375000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "14-july - 20july"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-07-21",
   "end": "2026-07-27",
   "year": 2026,
   "month": 7,
   "week": 30,
   "omzet": 522000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 104400.0,
   "kas_akhir": 1584500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    " 21-july - 27july"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-07-27",
   "end": "2026-08-03",
   "year": 2026,
   "month": 7,
   "week": 31,
   "omzet": 272000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 54400.0,
   "kas_akhir": 375500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "28 july- 03july"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.3 jt tapi rincian penjualan Rp0.6 jt (selisih Rp0.3 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Nama tab tidak bisa dibaca; periode diambil dari header laporan."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-08-12",
   "end": "2026-08-17",
   "year": 2026,
   "month": 8,
   "week": 33,
   "omzet": 372000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 74400.0,
   "kas_akhir": 578000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "12aug-17-aug"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.4 jt tapi rincian penjualan Rp0.7 jt (selisih Rp0.4 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-08-18",
   "end": "2026-08-23",
   "year": 2026,
   "month": 8,
   "week": 34,
   "omzet": 363000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 72600.0,
   "kas_akhir": 930000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    " 18aug-23-aug"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.4 jt tapi rincian penjualan Rp0.6 jt (selisih Rp0.2 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-08-24",
   "end": "2026-08-30",
   "year": 2026,
   "month": 8,
   "week": 35,
   "omzet": 399000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 5.0,
   "avg_basket": 79800.0,
   "kas_akhir": 1165000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "24aug-30-aug"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.4 jt tapi rincian penjualan Rp0.5 jt (selisih Rp0.1 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-09-07",
   "end": "2026-09-13",
   "year": 2026,
   "month": 9,
   "week": 37,
   "omzet": 450000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 2.0,
   "avg_basket": 225000.0,
   "kas_akhir": 394000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    " 07sep-13sep"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.5 jt tapi rincian penjualan Rp0.5 jt (selisih Rp0.1 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-09-13",
   "end": "2026-09-20",
   "year": 2026,
   "month": 9,
   "week": 37,
   "omzet": 450000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 3.0,
   "avg_basket": 150000.0,
   "kas_akhir": 550000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    " 13sep-20sep"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.5 jt tapi rincian penjualan Rp0.6 jt (selisih Rp0.1 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "omzet_identik",
     "sev": "warning",
     "text": "Omzet persis sama dengan minggu sebelumnya (Rp450,000) — cek apakah laporan disalin."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-09-20",
   "end": "2026-09-27",
   "year": 2026,
   "month": 9,
   "week": 38,
   "omzet": 273000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 3.0,
   "avg_basket": 91000.0,
   "kas_akhir": 773000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "20sep-27sep"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.3 jt tapi rincian penjualan Rp0.5 jt (selisih Rp0.2 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Tanggal di header (14/09–20/09) tidak cocok dengan nama tab; dipakai nama tab."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-09-27",
   "end": "2026-10-04",
   "year": 2026,
   "month": 9,
   "week": 39,
   "omzet": 273000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 3.0,
   "avg_basket": 91000.0,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "27sep-04october"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "omzet_identik",
     "sev": "warning",
     "text": "Omzet persis sama dengan minggu sebelumnya (Rp273,000) — cek apakah laporan disalin."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-10-12",
   "end": "2026-10-18",
   "year": 2026,
   "month": 10,
   "week": 42,
   "omzet": 204000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 3.0,
   "avg_basket": 68000.0,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "12sep-18october"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.2 jt tapi rincian penjualan Rp0.4 jt (selisih Rp0.2 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Nama tab tidak bisa dibaca; periode diambil dari header laporan."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-10-18",
   "end": "2026-10-25",
   "year": 2026,
   "month": 10,
   "week": 42,
   "omzet": 204000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 3.0,
   "avg_basket": 68000.0,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "18sep-15october"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.2 jt tapi rincian penjualan Rp0.4 jt (selisih Rp0.2 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Nama tab tidak bisa dibaca; periode diambil dari header laporan."
    },
    {
     "code": "omzet_identik",
     "sev": "warning",
     "text": "Omzet persis sama dengan minggu sebelumnya (Rp204,000) — cek apakah laporan disalin."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-10-26",
   "end": "2026-11-01",
   "year": 2026,
   "month": 10,
   "week": 44,
   "omzet": 386000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 190000.0,
   "laba_bersih": null,
   "transaksi": 3.0,
   "avg_basket": 128666.67,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "26oct-01 Nov-2026"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.4 jt tapi rincian penjualan Rp0.6 jt (selisih Rp0.2 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-11-01",
   "end": "2026-11-08",
   "year": 2026,
   "month": 11,
   "week": 44,
   "omzet": 386000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 3.0,
   "avg_basket": 128666.67,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "01 Nov-8 2026"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.4 jt tapi rincian penjualan Rp0.7 jt (selisih Rp0.3 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Nama tab tidak bisa dibaca; periode diambil dari header laporan."
    },
    {
     "code": "omzet_identik",
     "sev": "warning",
     "text": "Omzet persis sama dengan minggu sebelumnya (Rp386,000) — cek apakah laporan disalin."
    }
   ]
  },
  {
   "outlet": "Mitra Water",
   "start": "2026-11-08",
   "end": "2026-11-15",
   "year": 2026,
   "month": 11,
   "week": 45,
   "omzet": 386000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 3.0,
   "avg_basket": 128666.67,
   "kas_akhir": 558000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Suhendra",
   "source": [
    "Copy of 01 Nov-8 2026"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "omzet_vs_rincian",
     "sev": "critical",
     "text": "Omzet di header Rp0.4 jt tapi rincian penjualan Rp0.4 jt (selisih Rp0.1 jt)."
    },
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Nama tab tidak bisa dibaca; periode diambil dari header laporan."
    },
    {
     "code": "omzet_identik",
     "sev": "warning",
     "text": "Omzet persis sama dengan minggu sebelumnya (Rp386,000) — cek apakah laporan disalin."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-03-22",
   "end": "2026-03-28",
   "year": 2026,
   "month": 3,
   "week": 12,
   "omzet": 16946000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 27.0,
   "avg_basket": 627629.63,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "22 Mar - 28 Mar"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-03-29",
   "end": "2026-04-04",
   "year": 2026,
   "month": 4,
   "week": 13,
   "omzet": 12653000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 22.0,
   "avg_basket": 575136.36,
   "kas_akhir": 4355784.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "29 Mar - 4 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-04-05",
   "end": "2026-04-11",
   "year": 2026,
   "month": 4,
   "week": 14,
   "omzet": 3962000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 25.0,
   "avg_basket": 158480.0,
   "kas_akhir": null,
   "pengeluaran": 7827500.0,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Akbar",
   "source": [
    "5 Apr - 11 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "lonjakan",
     "sev": "warning",
     "text": "Omzet berubah -69% dari minggu sebelumnya (Rp12.7 jt → Rp4.0 jt)."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-04-12",
   "end": "2026-04-18",
   "year": 2026,
   "month": 4,
   "week": 15,
   "omzet": 2317000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 16.0,
   "avg_basket": 144812.5,
   "kas_akhir": null,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Akbar",
   "source": [
    "12 Apr-18Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Tanggal di header (05/04–11/04) tidak cocok dengan nama tab; dipakai nama tab."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-04-19",
   "end": "2026-04-25",
   "year": 2026,
   "month": 4,
   "week": 16,
   "omzet": 6699000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 24.0,
   "avg_basket": 279125.0,
   "kas_akhir": 2609500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Akbar",
   "source": [
    "19 Apr-25 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "lonjakan",
     "sev": "warning",
     "text": "Omzet berubah +189% dari minggu sebelumnya (Rp2.3 jt → Rp6.7 jt)."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-04-26",
   "end": "2026-05-01",
   "year": 2026,
   "month": 4,
   "week": 17,
   "omzet": 4561000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 34.0,
   "avg_basket": 134147.06,
   "kas_akhir": 1817747.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Akbar",
   "source": [
    "26 Apr-1 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Tanggal di header (19/04–25/04) tidak cocok dengan nama tab; dipakai nama tab."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-05-02",
   "end": "2026-05-08",
   "year": 2026,
   "month": 5,
   "week": 18,
   "omzet": 7056000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 35.0,
   "avg_basket": 201600.0,
   "kas_akhir": 3389929.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Akbar",
   "source": [
    "2Mei-8Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Tanggal di header (19/04–25/04) tidak cocok dengan nama tab; dipakai nama tab."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-05-09",
   "end": "2026-05-15",
   "year": 2026,
   "month": 5,
   "week": 19,
   "omzet": 4977000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 22.0,
   "avg_basket": 226227.27,
   "kas_akhir": 2058629.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Akbar",
   "source": [
    "9Mei-15Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-05-22",
   "end": "2026-05-28",
   "year": 2026,
   "month": 5,
   "week": 21,
   "omzet": 5515000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 21.0,
   "avg_basket": 215000.0,
   "kas_akhir": null,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Akbar",
   "source": [
    "22Mei-28Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "basket_tidak_cocok",
     "sev": "warning",
     "text": "21 transaksi × Rp215,000 = Rp4.5 jt, tidak sama dengan omzet Rp5.5 jt."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-05-29",
   "end": "2026-06-03",
   "year": 2026,
   "month": 5,
   "week": 22,
   "omzet": 7835000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 14.0,
   "avg_basket": 559642.0,
   "kas_akhir": 5769429.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Akbar",
   "source": [
    "29Mei-3Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-06-01",
   "end": "2026-06-07",
   "year": 2026,
   "month": 6,
   "week": 23,
   "omzet": 8677000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 14.0,
   "avg_basket": 559642.0,
   "kas_akhir": 5769429.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "1 JUNI - 7 JUNI"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-06-08",
   "end": "2026-06-14",
   "year": 2026,
   "month": 6,
   "week": 24,
   "omzet": 5038000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 18.0,
   "avg_basket": 279888.89,
   "kas_akhir": 2845129.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "8 JUNI - 14 JUNI"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Tanggal di header (08/06–21/06) tidak cocok dengan nama tab; dipakai nama tab."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-06-15",
   "end": "2026-06-21",
   "year": 2026,
   "month": 6,
   "week": 25,
   "omzet": 5108000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 13.0,
   "avg_basket": 392923.08,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "15 JUNI - 21 JUNI"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-06-22",
   "end": "2026-06-28",
   "year": 2026,
   "month": 6,
   "week": 26,
   "omzet": 4546000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 7.0,
   "avg_basket": 649428.57,
   "kas_akhir": 1580000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "22 JUNI - 28 JUNI"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-07-06",
   "end": "2026-07-12",
   "year": 2026,
   "month": 7,
   "week": 28,
   "omzet": 2225000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 17.0,
   "avg_basket": 130882.35,
   "kas_akhir": 3872000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "6 July - 12 July"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-07-13",
   "end": "2026-07-19",
   "year": 2026,
   "month": 7,
   "week": 29,
   "omzet": 2142000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 16.0,
   "avg_basket": 133875.0,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "13 july - 19 july"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-07-20",
   "end": "2026-07-26",
   "year": 2026,
   "month": 7,
   "week": 30,
   "omzet": 4689000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 16.0,
   "avg_basket": 293062.5,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "20 - 26 july"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-08-03",
   "end": "2026-08-09",
   "year": 2026,
   "month": 8,
   "week": 32,
   "omzet": 3683000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 16.0,
   "avg_basket": 230187.5,
   "kas_akhir": 1010000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "3 agustus - 9 agus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-08-10",
   "end": "2026-08-16",
   "year": 2026,
   "month": 8,
   "week": 33,
   "omzet": 3560500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 11.0,
   "avg_basket": 323681.82,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "10 agustus - 16 agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-08-17",
   "end": "2026-08-23",
   "year": 2026,
   "month": 8,
   "week": 34,
   "omzet": 4463500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 15.0,
   "avg_basket": 297566.67,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "17 agustus - 23 agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-08-24",
   "end": "2026-08-30",
   "year": 2026,
   "month": 8,
   "week": 35,
   "omzet": 2790000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 15.0,
   "avg_basket": 186000.0,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "24 agustus - 30 agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-08-31",
   "end": "2026-09-06",
   "year": 2026,
   "month": 9,
   "week": 36,
   "omzet": 2088000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 15.0,
   "avg_basket": 139200.0,
   "kas_akhir": 0.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "31 agustus - 6 september"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-09-07",
   "end": "2026-09-13",
   "year": 2026,
   "month": 9,
   "week": 37,
   "omzet": 2225000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 15.0,
   "avg_basket": 148333.33,
   "kas_akhir": 3890200.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "7 -13 september"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-09-14",
   "end": "2026-09-20",
   "year": 2026,
   "month": 9,
   "week": 38,
   "omzet": 4964000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 15.0,
   "avg_basket": 330933.33,
   "kas_akhir": 2894200.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "14- 20"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Periode di laporan kosong/salah; direkonstruksi dari minggu sebelumnya."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-09-21",
   "end": "2026-09-27",
   "year": 2026,
   "month": 9,
   "week": 39,
   "omzet": 3063000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 15.0,
   "avg_basket": 204200.0,
   "kas_akhir": 1483000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "21- 27 september"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-10-05",
   "end": "2026-10-12",
   "year": 2026,
   "month": 10,
   "week": 41,
   "omzet": 4870500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 15.0,
   "avg_basket": 324700.0,
   "kas_akhir": 1483000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "5 oktober - 12 oktober"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-10-13",
   "end": "2026-10-18",
   "year": 2026,
   "month": 10,
   "week": 42,
   "omzet": 4475000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 15.0,
   "avg_basket": 298333.33,
   "kas_akhir": 1483000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "13- 18 oktober"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-10-19",
   "end": "2026-10-25",
   "year": 2026,
   "month": 10,
   "week": 43,
   "omzet": 4495000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 15.0,
   "avg_basket": 299666.67,
   "kas_akhir": 1483000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "19 - 25 oktober"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-11-02",
   "end": "2026-11-08",
   "year": 2026,
   "month": 11,
   "week": 45,
   "omzet": 5839500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 19.0,
   "avg_basket": 307342.11,
   "kas_akhir": 1735000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "2 nov - 8 nov"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "RM Sindang Hurip",
   "start": "2026-11-09",
   "end": "2026-11-15",
   "year": 2026,
   "month": 11,
   "week": 46,
   "omzet": 6057000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 22.0,
   "avg_basket": 275318.18,
   "kas_akhir": 1135000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "M Abdul Azis",
   "source": [
    "9 nov - 15 nov"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "River Inn",
   "start": "2026-11-01",
   "end": "2026-11-07",
   "year": 2026,
   "month": 11,
   "week": 44,
   "omzet": 19620000.0,
   "hpp": 5366000.0,
   "laba_kotor": 14254000.0,
   "beban": 11454175.0,
   "laba_bersih": 8165825.0,
   "transaksi": 92.0,
   "avg_basket": 213260.87,
   "kas_akhir": 24713034.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 878500.0,
   "target_next": 30380000.0,
   "format": "proto",
   "author": "Manda",
   "source": [
    "WEEKLY v3 (01 Nov 26 - 07 Nov 2"
   ],
   "versions": 1,
   "issues": []
  },
  {
   "outlet": "River Inn",
   "start": "2026-11-08",
   "end": "2026-11-14",
   "year": 2026,
   "month": 11,
   "week": 45,
   "omzet": 16137800.0,
   "hpp": 3376569.0,
   "laba_kotor": 12761231.0,
   "beban": 6014255.0,
   "laba_bersih": 10123545.0,
   "transaksi": 107.0,
   "avg_basket": 150820.56,
   "kas_akhir": 31188269.0,
   "pengeluaran": null,
   "piutang": 0.0,
   "stok": 518500.0,
   "target_next": 39242200.0,
   "format": "proto",
   "author": "Manda",
   "source": [
    " WEEKLY v3 (08 Nov 26 - 14 Nov ",
    "Copy of  WEEKLY v3 (15 Nov 26 -"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-03-22",
   "end": "2026-03-28",
   "year": 2026,
   "month": 3,
   "week": 12,
   "omzet": 18197000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 160.0,
   "avg_basket": 113731.25,
   "kas_akhir": 18197000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "22 Mar - 28 Mar"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-03-29",
   "end": "2026-04-04",
   "year": 2026,
   "month": 4,
   "week": 13,
   "omzet": 10444200.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 122.0,
   "avg_basket": 85608.2,
   "kas_akhir": 15502253.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "29 Mar - 4 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-04-05",
   "end": "2026-04-11",
   "year": 2026,
   "month": 4,
   "week": 14,
   "omzet": 8704000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 131.0,
   "avg_basket": 66442.75,
   "kas_akhir": 14659559.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "5 Apr - 11 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-04-12",
   "end": "2026-04-18",
   "year": 2026,
   "month": 4,
   "week": 15,
   "omzet": 11957700.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1350000.0,
   "laba_bersih": null,
   "transaksi": 145.0,
   "avg_basket": 82466.9,
   "kas_akhir": 15628915.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "12 Apr - 18 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-04-19",
   "end": "2026-04-25",
   "year": 2026,
   "month": 4,
   "week": 16,
   "omzet": 13390700.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1050000.0,
   "laba_bersih": null,
   "transaksi": 188.0,
   "avg_basket": 71227.13,
   "kas_akhir": 26536340.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "19 Apr - 25 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-05-03",
   "end": "2026-05-09",
   "year": 2026,
   "month": 5,
   "week": 18,
   "omzet": 14075000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1000000.0,
   "laba_bersih": null,
   "transaksi": 196.0,
   "avg_basket": 71811.22,
   "kas_akhir": 16500262.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "3 Mei - 9 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-05-10",
   "end": "2026-05-16",
   "year": 2026,
   "month": 5,
   "week": 19,
   "omzet": 14495000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1150000.0,
   "laba_bersih": null,
   "transaksi": 206.0,
   "avg_basket": 70364.08,
   "kas_akhir": 22422026.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    " 10 Mei - 16 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-05-17",
   "end": "2026-05-23",
   "year": 2026,
   "month": 5,
   "week": 20,
   "omzet": 10340700.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1150000.0,
   "laba_bersih": null,
   "transaksi": 144.0,
   "avg_basket": 71810.42,
   "kas_akhir": 19839067.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "17 Mei - 23 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-06-01",
   "end": "2026-06-07",
   "year": 2026,
   "month": 6,
   "week": 23,
   "omzet": 17914200.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1050000.0,
   "laba_bersih": null,
   "transaksi": 233.0,
   "avg_basket": 76884.98,
   "kas_akhir": 15064142.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "1 Juni - 7 Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-06-08",
   "end": "2026-06-14",
   "year": 2026,
   "month": 6,
   "week": 24,
   "omzet": 10433400.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1050000.0,
   "laba_bersih": null,
   "transaksi": 147.0,
   "avg_basket": 70975.51,
   "kas_akhir": 16640237.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "8 Juni - 14 Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-06-15",
   "end": "2026-06-21",
   "year": 2026,
   "month": 6,
   "week": 25,
   "omzet": 13735600.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1000000.0,
   "laba_bersih": null,
   "transaksi": 167.0,
   "avg_basket": 82249.1,
   "kas_akhir": 21421605.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "15 Juni - 21 Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-06-22",
   "end": "2026-06-28",
   "year": 2026,
   "month": 6,
   "week": 26,
   "omzet": 11089300.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1100000.0,
   "laba_bersih": null,
   "transaksi": 158.0,
   "avg_basket": 68380.38,
   "kas_akhir": 30317280.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "22 Juni - 28 Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-07-06",
   "end": "2026-07-12",
   "year": 2026,
   "month": 7,
   "week": 28,
   "omzet": 11862200.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1000000.0,
   "laba_bersih": null,
   "transaksi": 152.0,
   "avg_basket": 76593.42,
   "kas_akhir": 21372913.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "6 Juli - 12 Juli"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-07-13",
   "end": "2026-07-19",
   "year": 2026,
   "month": 7,
   "week": 29,
   "omzet": 10692600.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1100000.0,
   "laba_bersih": null,
   "transaksi": 152.0,
   "avg_basket": 68518.42,
   "kas_akhir": 22966219.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "13 Juli - 19 Juli"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-07-27",
   "end": "2026-08-02",
   "year": 2026,
   "month": 7,
   "week": 31,
   "omzet": 10372700.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 1100000.0,
   "laba_bersih": null,
   "transaksi": 172.0,
   "avg_basket": 59834.3,
   "kas_akhir": 15473137.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "27 Juli - 2 Agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-08-03",
   "end": "2026-08-09",
   "year": 2026,
   "month": 8,
   "week": 32,
   "omzet": 10738800.0,
   "hpp": 7949393.0,
   "laba_kotor": 2789407.0,
   "beban": 2257000.0,
   "laba_bersih": 532407.0,
   "transaksi": 166.0,
   "avg_basket": 63169.41,
   "kas_akhir": 15544997.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "3 agustus - 9 Agustus"
   ],
   "versions": 1,
   "issues": []
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-08-10",
   "end": "2026-08-16",
   "year": 2026,
   "month": 8,
   "week": 33,
   "omzet": 10798600.0,
   "hpp": 9845500.0,
   "laba_kotor": 953100.0,
   "beban": 2480331.0,
   "laba_bersih": -1527231.0,
   "transaksi": 158.0,
   "avg_basket": 67072.05,
   "kas_akhir": 17578825.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "10 agustus - 16 Agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 91% dari omzet — margin kotor hanya 9%."
    },
    {
     "code": "rugi",
     "sev": "critical",
     "text": "Laba bersih negatif Rp1.5 jt."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-08-17",
   "end": "2026-08-23",
   "year": 2026,
   "month": 8,
   "week": 34,
   "omzet": 12271700.0,
   "hpp": 8830299.0,
   "laba_kotor": 3441401.0,
   "beban": 1801400.0,
   "laba_bersih": 1640001.0,
   "transaksi": 188.0,
   "avg_basket": 62931.79,
   "kas_akhir": 18861989.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "17 agustus - 23 Agustus"
   ],
   "versions": 1,
   "issues": []
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-08-24",
   "end": "2026-08-30",
   "year": 2026,
   "month": 8,
   "week": 35,
   "omzet": 11119700.0,
   "hpp": 8298514.0,
   "laba_kotor": 2821186.0,
   "beban": 1617000.0,
   "laba_bersih": 1204186.0,
   "transaksi": 187.0,
   "avg_basket": 58218.32,
   "kas_akhir": 29022689.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "24 agustus - 30 Agustus"
   ],
   "versions": 1,
   "issues": []
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-08-31",
   "end": "2026-09-06",
   "year": 2026,
   "month": 9,
   "week": 36,
   "omzet": 11119700.0,
   "hpp": 8298514.0,
   "laba_kotor": 2821186.0,
   "beban": 1617000.0,
   "laba_bersih": 1204186.0,
   "transaksi": 187.0,
   "avg_basket": 58218.32,
   "kas_akhir": 29022689.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "31 agustus - 6 september"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Tanggal di header (24/08–30/08) tidak cocok dengan nama tab; dipakai nama tab."
    },
    {
     "code": "omzet_identik",
     "sev": "warning",
     "text": "Omzet persis sama dengan minggu sebelumnya (Rp11,119,700) — cek apakah laporan disalin."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-09-07",
   "end": "2026-09-13",
   "year": 2026,
   "month": 9,
   "week": 37,
   "omzet": 10113100.0,
   "hpp": 7543000.0,
   "laba_kotor": 2570100.0,
   "beban": 1778500.0,
   "laba_bersih": 791600.0,
   "transaksi": 166.0,
   "avg_basket": 60557.49,
   "kas_akhir": 14817455.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "7 september - 13 september"
   ],
   "versions": 1,
   "issues": []
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-09-14",
   "end": "2026-09-20",
   "year": 2026,
   "month": 9,
   "week": 38,
   "omzet": 9704500.0,
   "hpp": 7036428.0,
   "laba_kotor": 2668072.0,
   "beban": 1345000.0,
   "laba_bersih": 1323072.0,
   "transaksi": 149.0,
   "avg_basket": 63845.39,
   "kas_akhir": 16792430.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "14 september - 20 september"
   ],
   "versions": 1,
   "issues": []
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-09-21",
   "end": "2026-09-27",
   "year": 2026,
   "month": 9,
   "week": 39,
   "omzet": 10382200.0,
   "hpp": 6437613.0,
   "laba_kotor": 3944587.0,
   "beban": 2232500.0,
   "laba_bersih": 1712087.0,
   "transaksi": 164.0,
   "avg_basket": 61798.81,
   "kas_akhir": 16663657.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "21 september - 27 september"
   ],
   "versions": 1,
   "issues": []
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-10-05",
   "end": "2026-10-11",
   "year": 2026,
   "month": 10,
   "week": 41,
   "omzet": 10428300.0,
   "hpp": 6861509.0,
   "laba_kotor": 3566791.0,
   "beban": 1790520.0,
   "laba_bersih": 1776271.0,
   "transaksi": 170.0,
   "avg_basket": 61342.94,
   "kas_akhir": 20068780.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "5 oktober - 11 oktober"
   ],
   "versions": 1,
   "issues": []
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-10-12",
   "end": "2026-10-18",
   "year": 2026,
   "month": 10,
   "week": 42,
   "omzet": 7972400.0,
   "hpp": 5604500.0,
   "laba_kotor": 2367900.0,
   "beban": 2884000.0,
   "laba_bersih": -516100.0,
   "transaksi": 122.0,
   "avg_basket": 64816.26,
   "kas_akhir": 19074923.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "12 oktober - 18 oktober"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "rugi",
     "sev": "critical",
     "text": "Laba bersih negatif Rp0.5 jt."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-10-19",
   "end": "2026-10-25",
   "year": 2026,
   "month": 10,
   "week": 43,
   "omzet": 6032700.0,
   "hpp": 5316500.0,
   "laba_kotor": 716200.0,
   "beban": 1065000.0,
   "laba_bersih": -348800.0,
   "transaksi": 102.0,
   "avg_basket": 59144.12,
   "kas_akhir": 19172923.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": 13800000.0,
   "format": "proto",
   "author": null,
   "source": [
    "19 oktober - 25 oktober",
    "PROTO (19-25 Okt)"
   ],
   "versions": 2,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 88% dari omzet — margin kotor hanya 12%."
    },
    {
     "code": "rugi",
     "sev": "critical",
     "text": "Laba bersih negatif Rp0.3 jt."
    },
    {
     "code": "duplikat",
     "sev": "warning",
     "text": "2 tab laporan berbeda untuk minggu yang sama"
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Nama tab tidak bisa dibaca; periode diambil dari header laporan."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-10-26",
   "end": "2026-11-01",
   "year": 2026,
   "month": 10,
   "week": 44,
   "omzet": 6920100.0,
   "hpp": 5051000.0,
   "laba_kotor": 1869100.0,
   "beban": 2301284.0,
   "laba_bersih": -432184.0,
   "transaksi": 67.0,
   "avg_basket": 97466.2,
   "kas_akhir": 11626631.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Maryam Fatonah",
   "source": [
    "26 oktober - 1 november"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "rugi",
     "sev": "critical",
     "text": "Laba bersih negatif Rp0.4 jt."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-11-02",
   "end": "2026-11-08",
   "year": 2026,
   "month": 11,
   "week": 45,
   "omzet": 7917300.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": 2736430.0,
   "transaksi": 119.0,
   "avg_basket": 66531.93,
   "kas_akhir": 14883723.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": 13800000.0,
   "format": "proto",
   "author": null,
   "source": [
    "2 november - 8 november"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Sweet Escape",
   "start": "2026-11-09",
   "end": "2026-11-15",
   "year": 2026,
   "month": 11,
   "week": 46,
   "omzet": 7337200.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": 2920909.0,
   "transaksi": 111.0,
   "avg_basket": 66100.9,
   "kas_akhir": 13164294.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": 13800000.0,
   "format": "proto",
   "author": null,
   "source": [
    "9 november - 15 november"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-03-22",
   "end": "2026-03-28",
   "year": 2026,
   "month": 3,
   "week": 12,
   "omzet": 125693500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": 1087.0,
   "avg_basket": 115633.39,
   "kas_akhir": 125693500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "22 Mar - 28 Mar"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-03-29",
   "end": "2026-04-04",
   "year": 2026,
   "month": 4,
   "week": 13,
   "omzet": 130546500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 115671500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "29 Mar - 4 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-04-05",
   "end": "2026-04-11",
   "year": 2026,
   "month": 4,
   "week": 14,
   "omzet": 121061500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 112013000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "5 Apr - 11 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-04-12",
   "end": "2026-04-18",
   "year": 2026,
   "month": 4,
   "week": 15,
   "omzet": 92631000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": null,
   "laba_bersih": null,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 92631000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "12 Apr - 18 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_beban",
     "sev": "warning",
     "text": "Beban operasional kosong."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-04-19",
   "end": "2026-04-25",
   "year": 2026,
   "month": 4,
   "week": 16,
   "omzet": 90383500.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 2823077.0,
   "laba_bersih": null,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 90383500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita Novita",
   "source": [
    "19 Apr - 25 Apr"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-04-26",
   "end": "2026-05-02",
   "year": 2026,
   "month": 4,
   "week": 17,
   "omzet": 124299000.0,
   "hpp": 105842645.70848379,
   "laba_kotor": 18456354.291516215,
   "beban": 0.0,
   "laba_bersih": 18456354.291516215,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 124299000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita Novita",
   "source": [
    "26 Apr - 2 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-05-03",
   "end": "2026-05-09",
   "year": 2026,
   "month": 5,
   "week": 18,
   "omzet": 109483000.0,
   "hpp": null,
   "laba_kotor": null,
   "beban": 2411538.0,
   "laba_bersih": null,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 109483000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita Novita",
   "source": [
    "3 Mei - 9 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "no_hpp",
     "sev": "warning",
     "text": "HPP tidak diisi — laba bersih tidak bisa dipastikan."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-05-10",
   "end": "2026-05-16",
   "year": 2026,
   "month": 5,
   "week": 19,
   "omzet": 107155000.0,
   "hpp": 90671670.0,
   "laba_kotor": 16483330.0,
   "beban": 2411538.0,
   "laba_bersih": 14071792.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 107155000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "10 mei - 16 mei "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-05-17",
   "end": "2026-05-23",
   "year": 2026,
   "month": 5,
   "week": 20,
   "omzet": 103688000.0,
   "hpp": 90984564.62084699,
   "laba_kotor": 12703435.379153013,
   "beban": 2411538.0,
   "laba_bersih": 10291897.379153013,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 103688000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "17 Mei - 23 Mei"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 88% dari omzet — margin kotor hanya 12%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-06-01",
   "end": "2026-06-07",
   "year": 2026,
   "month": 6,
   "week": 23,
   "omzet": 127110000.0,
   "hpp": 108456255.66572417,
   "laba_kotor": 18653744.33,
   "beban": 5672154.0,
   "laba_bersih": 12981590.33,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 127110000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "1 Juni - 7 Juni "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-06-08",
   "end": "2026-06-14",
   "year": 2026,
   "month": 6,
   "week": 24,
   "omzet": 108109500.0,
   "hpp": 93822018.96933956,
   "laba_kotor": 14287481.03,
   "beban": 4562867.0,
   "laba_bersih": 9724614.031,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 108109500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "8 Juni - 14 Juni "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 87% dari omzet — margin kotor hanya 13%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-06-15",
   "end": "2026-06-21",
   "year": 2026,
   "month": 6,
   "week": 25,
   "omzet": 120043500.0,
   "hpp": 102990218.46165861,
   "laba_kotor": 17053281.54,
   "beban": 6908971.0,
   "laba_bersih": 10144310.54,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 120043500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "15 Juni - 21 Juni"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 86% dari omzet — margin kotor hanya 14%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-06-22",
   "end": "2026-06-28",
   "year": 2026,
   "month": 6,
   "week": 26,
   "omzet": 131312000.0,
   "hpp": 112367277.68055882,
   "laba_kotor": 18944722.32,
   "beban": 9143923.0,
   "laba_bersih": 9800799.319,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 131412000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "22 Juni - 28 Juni "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 86% dari omzet — margin kotor hanya 14%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-06-29",
   "end": "2026-07-05",
   "year": 2026,
   "month": 7,
   "week": 27,
   "omzet": 122714000.0,
   "hpp": 105991222.0,
   "laba_kotor": 16722778.0,
   "beban": 0.0,
   "laba_bersih": 16722778.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 122714000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "29 Juni - 5 Juli"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 86% dari omzet — margin kotor hanya 14%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-07-06",
   "end": "2026-07-12",
   "year": 2026,
   "month": 7,
   "week": 28,
   "omzet": 92286500.0,
   "hpp": 77036612.4960683,
   "laba_kotor": 15249887.5,
   "beban": 3264000.0,
   "laba_bersih": 11985887.5,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 92286500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "6 Juli - 12 Juli "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 83% dari omzet — margin kotor hanya 17%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-07-13",
   "end": "2026-07-19",
   "year": 2026,
   "month": 7,
   "week": 29,
   "omzet": 101097600.0,
   "hpp": 89123129.0,
   "laba_kotor": 11974471.0,
   "beban": 4556385.0,
   "laba_bersih": 7418086.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 101097600.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "13 Juli - 19 juli "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 88% dari omzet — margin kotor hanya 12%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-07-20",
   "end": "2026-07-26",
   "year": 2026,
   "month": 7,
   "week": 30,
   "omzet": 93420000.0,
   "hpp": 79399104.77601294,
   "laba_kotor": 14020895.22,
   "beban": 3698769.0,
   "laba_bersih": 10322126.22,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 93420000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "20 Juli - 26 Juli "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-07-27",
   "end": "2026-08-02",
   "year": 2026,
   "month": 7,
   "week": 31,
   "omzet": 99666000.0,
   "hpp": 83589892.0,
   "laba_kotor": 16076108.0,
   "beban": 5525500.0,
   "laba_bersih": 10550608.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 99666000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "27 Juli - 2 Agustus"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 84% dari omzet — margin kotor hanya 16%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-08-03",
   "end": "2026-08-09",
   "year": 2026,
   "month": 8,
   "week": 32,
   "omzet": 99425000.0,
   "hpp": 83755542.0,
   "laba_kotor": 15669458.0,
   "beban": 4035269.0,
   "laba_bersih": 11634189.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 99425000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "3 Agustus - 9 Agustus "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 84% dari omzet — margin kotor hanya 16%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-08-10",
   "end": "2026-08-16",
   "year": 2026,
   "month": 8,
   "week": 33,
   "omzet": 97197000.0,
   "hpp": 82146262.0,
   "laba_kotor": 15050738.0,
   "beban": 4967577.0,
   "laba_bersih": 10083161.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 97197000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "10 Agustus - 16 Agustus "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-08-17",
   "end": "2026-08-23",
   "year": 2026,
   "month": 8,
   "week": 34,
   "omzet": 107186500.0,
   "hpp": 91170652.0,
   "laba_kotor": 16015848.0,
   "beban": 4122077.0,
   "laba_bersih": 11893771.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 107186500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "17 Agustus - 23 Agustus "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-08-24",
   "end": "2026-08-30",
   "year": 2026,
   "month": 8,
   "week": 35,
   "omzet": 106574000.0,
   "hpp": 90143360.0,
   "laba_kotor": 16430640.0,
   "beban": 8325769.0,
   "laba_bersih": 8104871.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 106574000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "24 Agustus - 30Agustus "
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-08-31",
   "end": "2026-09-06",
   "year": 2026,
   "month": 9,
   "week": 36,
   "omzet": 114501951.0,
   "hpp": 97067396.0,
   "laba_kotor": 17434555.0,
   "beban": 8325769.0,
   "laba_bersih": 9108786.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 106574000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "31 Agustus - 6 September"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Tanggal di header (24/08–30/08) tidak cocok dengan nama tab; dipakai nama tab."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-09-07",
   "end": "2026-09-13",
   "year": 2026,
   "month": 9,
   "week": 37,
   "omzet": 111525500.0,
   "hpp": 93467000.0,
   "laba_kotor": 18058500.0,
   "beban": 5137769.0,
   "laba_bersih": 12920731.0,
   "transaksi": null,
   "avg_basket": null,
   "kas_akhir": 118706000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "7 Sept -13 Sept"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 84% dari omzet — margin kotor hanya 16%."
    },
    {
     "code": "no_trx",
     "sev": "warning",
     "text": "Jumlah transaksi tidak diisi."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-09-14",
   "end": "2026-09-20",
   "year": 2026,
   "month": 9,
   "week": 38,
   "omzet": 101010500.0,
   "hpp": 85317874.0,
   "laba_kotor": 15692626.0,
   "beban": 5096115.0,
   "laba_bersih": 10596511.0,
   "transaksi": 1087.0,
   "avg_basket": 92925.94,
   "kas_akhir": 111526000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "14 sept - 20 sept"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 84% dari omzet — margin kotor hanya 16%."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-09-21",
   "end": "2026-09-27",
   "year": 2026,
   "month": 9,
   "week": 39,
   "omzet": 116149000.0,
   "hpp": 99240253.0,
   "laba_kotor": 16908747.0,
   "beban": 4750155.0,
   "laba_bersih": 12158592.0,
   "transaksi": 1048.0,
   "avg_basket": 110829.2,
   "kas_akhir": 101010500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "21 sept - 27 sept"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-09-28",
   "end": "2026-10-04",
   "year": 2026,
   "month": 10,
   "week": 40,
   "omzet": 109086251.0,
   "hpp": 92765140.0,
   "laba_kotor": 16321111.0,
   "beban": 4673227.0,
   "laba_bersih": 11647884.0,
   "transaksi": 1048.0,
   "avg_basket": 104089.93,
   "kas_akhir": 116149000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "28 sept - 4 Okt"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    },
    {
     "code": "tanggal",
     "sev": "info",
     "text": "Tanggal di header (21/09–27/09) tidak cocok dengan nama tab; dipakai nama tab."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-10-05",
   "end": "2026-10-11",
   "year": 2026,
   "month": 10,
   "week": 41,
   "omzet": 94100637.0,
   "hpp": 79440363.0,
   "laba_kotor": 14660274.0,
   "beban": 5584500.0,
   "laba_bersih": 9075774.0,
   "transaksi": 1017.0,
   "avg_basket": 92527.67,
   "kas_akhir": null,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Ita & Sopian",
   "source": [
    "5 Okt - 11 Okt"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 84% dari omzet — margin kotor hanya 16%."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-10-12",
   "end": "2026-10-18",
   "year": 2026,
   "month": 10,
   "week": 42,
   "omzet": 105175391.0,
   "hpp": 88728391.0,
   "laba_kotor": 16447000.0,
   "beban": 5094000.0,
   "laba_bersih": 11353000.0,
   "transaksi": 1025.0,
   "avg_basket": 102610.14,
   "kas_akhir": null,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Sopian",
   "source": [
    "12 Okt - 18 OKt"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 84% dari omzet — margin kotor hanya 16%."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-10-19",
   "end": "2026-10-25",
   "year": 2026,
   "month": 10,
   "week": 43,
   "omzet": 99428500.0,
   "hpp": 84721500.0,
   "laba_kotor": 14707000.0,
   "beban": 4661000.0,
   "laba_bersih": 10046000.0,
   "transaksi": 1059.0,
   "avg_basket": 93889.05,
   "kas_akhir": 99428500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Sopian",
   "source": [
    "19 Okt - 25 Okt"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-10-26",
   "end": "2026-11-01",
   "year": 2026,
   "month": 10,
   "week": 44,
   "omzet": 93504995.0,
   "hpp": 80013543.0,
   "laba_kotor": 13491452.0,
   "beban": 4661000.0,
   "laba_bersih": 8830452.0,
   "transaksi": 1059.0,
   "avg_basket": 88295.56,
   "kas_akhir": 99428500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Sopian",
   "source": [
    "26 Okt - 1 Nov"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 86% dari omzet — margin kotor hanya 14%."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-11-02",
   "end": "2026-11-08",
   "year": 2026,
   "month": 11,
   "week": 45,
   "omzet": 112576500.0,
   "hpp": 96217861.0,
   "laba_kotor": 16358639.0,
   "beban": 4661000.0,
   "laba_bersih": 8830452.0,
   "transaksi": 999.0,
   "avg_basket": 112689.19,
   "kas_akhir": 112576500.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Sopian",
   "source": [
    "2 Nov - 8 Nov"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 85% dari omzet — margin kotor hanya 15%."
    }
   ]
  },
  {
   "outlet": "Tk Kartini",
   "start": "2026-11-09",
   "end": "2026-11-15",
   "year": 2026,
   "month": 11,
   "week": 46,
   "omzet": 99080000.0,
   "hpp": 85154696.0,
   "laba_kotor": 13925304.0,
   "beban": 5715500.0,
   "laba_bersih": 8209804.0,
   "transaksi": 971.0,
   "avg_basket": 102039.13,
   "kas_akhir": 99080000.0,
   "pengeluaran": null,
   "piutang": null,
   "stok": null,
   "target_next": null,
   "format": "classic",
   "author": "Sopian",
   "source": [
    "9 Nov - 15 Nov"
   ],
   "versions": 1,
   "issues": [
    {
     "code": "hpp_tinggi",
     "sev": "critical",
     "text": "HPP 86% dari omzet — margin kotor hanya 14%."
    }
   ]
  }
 ]
};
export const MONTH_ID=["", "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
export const MONTH_FULL_ID=["", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];