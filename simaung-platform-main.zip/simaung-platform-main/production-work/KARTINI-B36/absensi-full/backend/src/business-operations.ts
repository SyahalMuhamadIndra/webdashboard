import {restaurantSchema} from './ops/restaurant.js';
import {randomUUID} from 'node:crypto';
import type {Express, Request, RequestHandler, Response} from 'express';
import type {Pool, PoolClient} from 'pg';

export const businessOperationsSchema=`${restaurantSchema}
 CREATE TABLE IF NOT EXISTS business_kitchen_status (
  sale_id uuid PRIMARY KEY REFERENCES ops_pos_sales(id), company_id uuid NOT NULL REFERENCES companies(id),
  status text NOT NULL CHECK(status IN ('PREPARING','READY','SERVED')),
  changed_by uuid NOT NULL, updated_at timestamptz NOT NULL DEFAULT now()
 );
 CREATE TABLE IF NOT EXISTS business_properties (
  company_id uuid NOT NULL REFERENCES companies(id), unit text NOT NULL CHECK(unit IN ('kosan','penginapan')),
  name text NOT NULL, PRIMARY KEY(company_id,unit,name)
 );
 CREATE TABLE IF NOT EXISTS business_property_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES companies(id),
  unit text NOT NULL CHECK(unit IN ('kosan','penginapan')), property text NOT NULL, code text NOT NULL,
  active boolean NOT NULL DEFAULT true, UNIQUE(company_id,unit,property,code)
 );
 CREATE TABLE IF NOT EXISTS business_property_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), room_id uuid NOT NULL REFERENCES business_property_rooms(id),
  guest text NOT NULL, starts_on date NOT NULL, ends_on date NOT NULL CHECK(ends_on>starts_on),
  rate numeric(16,0) NOT NULL CHECK(rate>0), status text NOT NULL CHECK(status IN ('BOOKED','ACTIVE','CLOSED','CANCELLED')),
  created_by uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), closed_at timestamptz, ended_on date
 );
 ALTER TABLE business_property_bookings ADD COLUMN IF NOT EXISTS checked_in_at timestamptz;
 ALTER TABLE business_property_bookings ADD COLUMN IF NOT EXISTS checked_out_at timestamptz;
 CREATE INDEX IF NOT EXISTS business_property_booking_room ON business_property_bookings(room_id,starts_on,ends_on);
 CREATE TABLE IF NOT EXISTS business_property_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), booking_id uuid NOT NULL REFERENCES business_property_bookings(id),
  period date NOT NULL, amount numeric(16,0) NOT NULL CHECK(amount>0), paid_at timestamptz,
  receipt_id uuid REFERENCES business_report_property_receipts(id), UNIQUE(booking_id,period)
 );
 ALTER TABLE business_property_bills ADD COLUMN IF NOT EXISTS due_on date;
 CREATE TABLE IF NOT EXISTS business_property_deposits (
  booking_id uuid PRIMARY KEY REFERENCES business_property_bookings(id),
  amount numeric(16,0) NOT NULL CHECK(amount>0), received_by uuid NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(), refunded_at timestamptz, refunded_by uuid
 );`;

type Grant={role:string;unit:string;property:string|null};
class Rejected extends Error{
  constructor(public status:number,message:string){super(message);}
}
const bad=(message:string,status=400):never=>{throw new Rejected(status,message);};
const txt=(x:unknown)=>typeof x==='string'?x.trim():'';
const id=(x:unknown)=>typeof x==='string'&&/^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(x);
const valid=(x:unknown,max:number)=>typeof x==='string'&&x.length>0&&x.length<=max;
const money=(x:unknown)=>typeof x==='number'&&Number.isSafeInteger(x)&&x>0&&x<=999999999999999;
function day(v:unknown):v is string{
 if(typeof v!=='string'||!/^(20[0-9]{2}|2100)-\d\d-\d\d$/.test(v))return false;
 const d=new Date(v+'T00:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===v;
}
const today=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const root='/api/admin/business-reports/operations';
const propertyUnits=['kosan','penginapan'];

export function mountBusinessOperations(app:Express,pool:Pool,auth:RequestHandler,access:RequestHandler,ensure:()=>Promise<unknown>){
 const tx=async<T>(f:(db:PoolClient)=>Promise<T>)=>{
  const db=await pool.connect();
  try{await db.query('BEGIN');const out=await f(db);await db.query('COMMIT');return out;}
  catch(e){await db.query('ROLLBACK');throw e;}
  finally{db.release();}
 };
 type Context={req:Request;res:Response;grant:Grant;c:string;actor:string};
 const route=(method:'get'|'post',path:string,f:(k:Context)=>Promise<unknown>)=>{
  app[method](root+path,auth,access,async(req,res)=>{
   res.set('Cache-Control','no-store');
   try{
    await ensure();
    res.json(await f({req,res,grant:res.locals.reportAccess,c:req.admin.companyId,actor:req.admin.adminId}));
   }catch(e){
    if(e instanceof Rejected)return res.status(e.status).json({message:e.message});
    console.error('Business operations failed',e instanceof Error?e.name:'Unknown');
    res.status(500).json({message:'Tindakan tidak dapat diproses.'});
   }
  });
 };
 const role=(g:Grant,...allowed:string[])=>{if(!['SYSTEM_ADMIN','OWNER',...allowed].includes(g.role))bad('Aksi ini di luar peran akun Anda.',403);};
 const unitAccess=(g:Grant,unit:string)=>{if(g.unit!=='all'&&g.unit!==unit)bad('Unit ini di luar cakupan akun Anda.',403);};
 const propertyAccess=(g:Grant,unit:string,property:string)=>{
  unitAccess(g,unit);
  if(g.property&&g.property!==property)bad('Properti ini di luar cakupan akun Anda.',403);
 };
 const propertyRole=(g:Grant,unit:string,finance=false)=>{
  if(!propertyUnits.includes(unit))bad('Pilih unit Kosan atau Penginapan.');
  role(g,'UNIT_MANAGER',unit==='kosan'?'RENTAL_MANAGER':'RECEPTION',...(finance?['FINANCE']:[]));
  unitAccess(g,unit);
 };

 route('get','/kitchen',async({req,grant,c})=>{
  role(grant,'KITCHEN','UNIT_MANAGER'); unitAccess(grant,'fnb');
  const date=String(req.query.date??today()), selected=grant.property||txt(req.query.branch);
  if(!day(date)||(selected&&!id(selected)))bad('Tanggal atau outlet tidak valid.');
  const [branches,tickets]=await Promise.all([
   pool.query(`SELECT b.id,b.name FROM branches b JOIN business_report_branch_units m ON m.branch_id=b.id AND m.company_id=b.company_id
    WHERE b.company_id=$1 AND m.unit='fnb' AND ($2::uuid IS NULL OR b.id=$2) ORDER BY b.name`,[c,selected||null]),
   pool.query(`SELECT s.id, COALESCE(s.code,'') AS code,b.name AS branch, s.created_at,
     COALESCE(k.status,'NEW') AS status, COALESCE(items.items,'[]'::jsonb) AS items
    FROM ops_pos_sales s JOIN branches b ON b.id=s.branch_id AND b.company_id=s.company_id
    JOIN business_report_branch_units m ON m.branch_id=b.id AND m.company_id=b.company_id AND m.unit='fnb'
    LEFT JOIN business_kitchen_status k ON k.sale_id=s.id AND k.company_id=s.company_id
    LEFT JOIN LATERAL (SELECT jsonb_agg(jsonb_build_object('name',i.product_name,'qty',i.qty) ORDER BY i.id) AS items
       FROM ops_pos_sale_items i WHERE i.sale_id=s.id) items ON true
    WHERE s.company_id=$1 AND s.status='PAID' AND ($3::uuid IS NULL OR s.branch_id=$3)
    AND NOT EXISTS(SELECT 1 FROM business_fnb_tickets t WHERE t.sale_id=s.id)
    AND NOT EXISTS(SELECT 1 FROM business_fnb_ticket_sales x WHERE x.sale_id=s.id)
    AND s.created_at >= ($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
    AND s.created_at < (($2::date+1)::timestamp AT TIME ZONE 'Asia/Jakarta')
    ORDER BY CASE WHEN k.status='SERVED' THEN 1 ELSE 0 END,s.created_at DESC LIMIT 200`,[c,date,selected||null])
  ]);
  const live=(await pool.query(`SELECT t.id,b.name AS branch,t.kind,t.table_code,t.status,t.sale_id,t.items,t.paid_items,t.created_at,
    ('DAPUR-'||upper(left(t.id::text,8))) AS code, 'restaurant' AS source
    FROM business_fnb_tickets t JOIN branches b ON b.id=t.branch_id AND b.company_id=t.company_id
    WHERE t.company_id=$1 AND ($3::uuid IS NULL OR t.branch_id=$3) AND t.status<>'CANCELLED'
    AND t.created_at>=($2::date::timestamp AT TIME ZONE 'Asia/Jakarta')
    AND t.created_at<(($2::date+1)::timestamp AT TIME ZONE 'Asia/Jakarta')
    ORDER BY t.created_at DESC LIMIT 200`,[c,date,selected||null])).rows;
  return {date,branches:branches.rows,tickets:[...live,...tickets.rows]};

 });
 route('post','/kitchen/status',async({req,grant,c,actor})=>{
  role(grant,'KITCHEN','UNIT_MANAGER');unitAccess(grant,'fnb');
  const {saleId,from,to}=req.body??{};
  if(!id(saleId)||!['NEW','PREPARING','READY'].includes(from)||({NEW:'PREPARING',PREPARING:'READY',READY:'SERVED'} as Record<string,string>)[from]!==to)
    bad('Perubahan status tidak valid.');
  if(req.body.source==='restaurant'){
   const changed=await pool.query(`UPDATE business_fnb_tickets SET status=$4,updated_at=now(),ready_at=CASE WHEN $4='READY' THEN COALESCE(ready_at,now()) ELSE ready_at END
     WHERE company_id=$1 AND id=$2 AND status=$3 AND ($5::uuid IS NULL OR branch_id=$5) RETURNING id`,
     [c,saleId,from,to,grant.property]);
   if(!changed.rowCount)bad('Tiket tidak tersedia atau sudah berubah. Muat ulang antrean.',409);
   return {ok:true};
  }
  const updated=await tx(async db=>{
   const found=await db.query(`SELECT s.id FROM ops_pos_sales s JOIN business_report_branch_units m
     ON m.branch_id=s.branch_id AND m.company_id=s.company_id AND m.unit='fnb'
     WHERE s.company_id=$1 AND s.id=$2 AND s.status='PAID' AND ($3::uuid IS NULL OR s.branch_id=$3) FOR UPDATE OF s`,[c,saleId,grant.property]);
   if(!found.rowCount)bad('Pesanan tidak tersedia untuk outlet ini.',404);
   const old=(await db.query('SELECT status FROM business_kitchen_status WHERE sale_id=$1',[saleId])).rows[0]?.status??'NEW';
   if(old!==from)bad('Pesanan sudah berubah. Muat ulang antrean.',409);
   return db.query(`INSERT INTO business_kitchen_status (sale_id,company_id,status,changed_by) VALUES ($1,$2,$3,$4)
     ON CONFLICT(sale_id) DO UPDATE SET status=EXCLUDED.status,changed_by=EXCLUDED.changed_by,updated_at=now()`,[saleId,c,to,actor]);
  });
  return {ok:!!updated.rowCount};
 });

 route('get','/property',async({req,grant,c})=>{
  const unit=String(req.query.unit??grant.unit), property=grant.property||txt(req.query.property);
  propertyRole(grant,unit,true);
  const month=String(req.query.month??today().slice(0,7));
  if(!day(month+'-01')||property.length>100)bad('Properti atau periode tidak valid.');
  const filters=[c,unit,property||null];
  const saved=await Promise.all([
   pool.query(`SELECT id,property,code,active FROM business_property_rooms
     WHERE company_id=$1 AND unit=$2 AND ($3::text IS NULL OR property=$3) ORDER BY property,code`,filters),
   pool.query(`SELECT b.id,r.property,r.code,b.room_id,b.guest,b.starts_on::text,b.ends_on::text,b.ended_on::text,b.rate::text,b.status,
        d.amount::text AS deposit,(d.refunded_at IS NOT NULL) AS deposit_refunded
     FROM business_property_bookings b JOIN business_property_rooms r ON r.id=b.room_id
     LEFT JOIN business_property_deposits d ON d.booking_id=b.id
     WHERE r.company_id=$1 AND r.unit=$2 AND ($3::text IS NULL OR r.property=$3)
       AND ((b.starts_on < $4::date + interval '1 month' AND b.ends_on >= $4::date) OR b.status='ACTIVE')
     ORDER BY b.starts_on DESC,b.id LIMIT 251`,[...filters,month+'-01']),
   pool.query(`SELECT i.id,r.property,r.code,b.guest,b.status,i.period::text,i.due_on::text,i.amount::text,i.paid_at,(p.voided_at IS NOT NULL) AS receipt_voided
     FROM business_property_bills i JOIN business_property_bookings b ON b.id=i.booking_id
     JOIN business_property_rooms r ON r.id=b.room_id LEFT JOIN business_report_property_receipts p ON p.id=i.receipt_id
     WHERE r.company_id=$1 AND r.unit=$2 AND ($3::text IS NULL OR r.property=$3) AND i.period >= $4::date
       AND i.period < $4::date+interval '1 month' AND b.status<>'CANCELLED'
     ORDER BY i.period DESC,i.id LIMIT 250`,[...filters,month+'-01'])
  ]);
  const locations=await pool.query(`SELECT name FROM business_properties WHERE company_id=$1 AND unit=$2
    AND ($3::text IS NULL OR name=$3) UNION SELECT DISTINCT property FROM business_property_rooms
    WHERE company_id=$1 AND unit=$2 AND ($3::text IS NULL OR property=$3) ORDER BY 1`,[c,unit,grant.property]);
  return {unit,property,month,properties:locations.rows.map(r=>r.name),rooms:saved[0].rows,bookings:saved[1].rows.slice(0,250),bookingLimit:saved[1].rows.length>250,bills:saved[2].rows,today:today()};
 });
 route('post','/property/room',async({req,grant,c})=>{
  const b=req.body??{},unit=txt(b.unit),property=txt(b.property),code=txt(b.code).toUpperCase();
  propertyRole(grant,unit);propertyAccess(grant,unit,property);
  if(!valid(property,100)||!valid(code,30))bad('Isi nama properti dan kode kamar.');
  const r=await pool.query(`INSERT INTO business_property_rooms(company_id,unit,property,code) VALUES ($1,$2,$3,$4)
    ON CONFLICT(company_id,unit,property,code) DO NOTHING RETURNING id`,[c,unit,property,code]);
  if(!r.rowCount)bad('Kode kamar sudah terdaftar di properti ini.',409);
  return {ok:true,id:r.rows[0].id};
 });
 route('post','/property/room/status',async({req,grant,c})=>{
  const {roomId,active}=req.body??{};
  if(!id(roomId)||typeof active!=='boolean')bad('Pilih kamar dan status yang valid.');
  return tx(async db=>{
   const room=(await db.query('SELECT * FROM business_property_rooms WHERE company_id=$1 AND id=$2 FOR UPDATE',[c,roomId])).rows[0];
   if(!room)bad('Kamar tidak ditemukan.',404);
   propertyRole(grant,room.unit);propertyAccess(grant,room.unit,room.property);
   if(!active&&(await db.query("SELECT 1 FROM business_property_bookings WHERE room_id=$1 AND (status='ACTIVE' OR (status='BOOKED' AND ends_on>$2::date)) LIMIT 1",[roomId,today()])).rowCount)
    bad('Kamar masih punya kontrak atau reservasi berjalan. Selesaikan atau batalkan dulu.',409);
   await db.query('UPDATE business_property_rooms SET active=$2 WHERE id=$1',[roomId,active]);
   return {ok:true};
  });
 });
 route('post','/property/booking',async({req,grant,c,actor})=>{
  const b=req.body??{}, guest=txt(b.guest), begin=b.startsOn, end=b.endsOn;
  if(!id(b.roomId)||!valid(guest,100)||!day(begin)||!day(end)||begin>=end||!money(b.rate))bad('Isi kamar, nama penghuni/tamu, tanggal dan tarif yang sah.');
  const nights=(Date.parse(end)-Date.parse(begin))/86400000;
  if(nights>3660)bad('Rentang tanggal terlalu panjang.');
  return tx(async db=>{
   const room=(await db.query('SELECT * FROM business_property_rooms WHERE company_id=$1 AND id=$2 AND active=true FOR UPDATE',[c,b.roomId])).rows[0];
   if(!room)bad('Kamar tidak ditemukan.',404);
   propertyRole(grant,room.unit);propertyAccess(grant,room.unit,room.property);
   const overlap=await db.query(`SELECT 1 FROM business_property_bookings WHERE room_id=$1 AND status<>'CANCELLED'
     AND starts_on < $3::date AND COALESCE(ended_on,ends_on) > $2::date LIMIT 1`,[b.roomId,begin,end]);
   if(overlap.rowCount)bad('Kamar sudah terisi atau dipesan pada periode itu.',409);
   const booking=(await db.query(`INSERT INTO business_property_bookings(room_id,guest,starts_on,ends_on,rate,status,created_by)
    VALUES ($1,$2,$3,$4,$5,'BOOKED',$6) RETURNING id`,[b.roomId,guest,begin,end,b.rate,actor])).rows[0];
   if(room.unit==='penginapan'){
    const total=b.rate*nights;
    if(!money(total))bad('Total inap melampaui batas nominal.');
    await db.query('INSERT INTO business_property_bills(booking_id,period,amount,due_on) VALUES ($1,$2,$3,$4)',[booking.id,begin,total,end]);
   }
   return {ok:true,id:booking.id};
  });
 });
 const loadBooking=async(db:PoolClient,c:string,bookingId:string)=>(await db.query(`
  SELECT b.id,b.status,b.starts_on::text,b.ends_on::text,r.unit,r.property,r.id AS room_id FROM business_property_bookings b
  JOIN business_property_rooms r ON r.id=b.room_id WHERE r.company_id=$1 AND b.id=$2 FOR UPDATE OF r,b`,[c,bookingId])).rows[0];
 route('post','/property/booking/status',async({req,grant,c})=>{
  const {bookingId,to}=req.body??{};
  if(!id(bookingId)||!['ACTIVE','CLOSED','CANCELLED'].includes(to))bad('Status tidak valid.');
  return tx(async db=>{
   const b=await loadBooking(db,c,bookingId);
   if(!b)bad('Catatan kamar tidak ditemukan.',404);
   propertyRole(grant,b.unit);propertyAccess(grant,b.unit,b.property);
   const date=today();
   if(to==='ACTIVE'&&(b.status!=='BOOKED'||date<b.starts_on||date>=b.ends_on))bad('Check-in atau mulai kontrak hanya pada masa booking, sebelum tanggal selesai.',409);
   if(to==='ACTIVE'&&(await db.query("SELECT 1 FROM business_property_bookings WHERE room_id=$1 AND id<>$2 AND status='ACTIVE'",[b.room_id,bookingId])).rowCount)
    bad('Kamar masih ditempati. Selesaikan kunjungan atau kontrak sebelumnya dahulu.',409);
   if(to==='CLOSED'&&b.status!=='ACTIVE')bad('Hanya catatan aktif yang dapat diselesaikan.',409);
   if(to==='CANCELLED'){
    if(b.status!=='BOOKED')bad('Hanya booking yang belum dimulai dapat dibatalkan.',409);
    const paid=await db.query(`SELECT 1 FROM business_property_bills WHERE booking_id=$1 AND paid_at IS NOT NULL
      UNION ALL SELECT 1 FROM business_property_deposits WHERE booking_id=$1 AND refunded_at IS NULL`,[bookingId]);
    if(paid.rowCount)bad('Ada pembayaran atau deposit aktif. Rekonsiliasi sebelum membatalkan.',409);
   }
   if(to==='CLOSED'&&b.unit==='penginapan'&&date<b.ends_on)
    bad('Checkout lebih awal perlu koreksi tagihan; alur ini hanya untuk checkout sesuai jadwal atau setelahnya.',409);
   const ended=to==='CLOSED'?(date<b.ends_on?date:b.ends_on):null;
   await db.query(`UPDATE business_property_bookings SET status=$2,
    closed_at=CASE WHEN $2 IN ('CLOSED','CANCELLED') THEN now() END,
    checked_in_at=CASE WHEN $2='ACTIVE' THEN COALESCE(checked_in_at,now()) ELSE checked_in_at END,
    checked_out_at=CASE WHEN $2='CLOSED' THEN now() ELSE checked_out_at END,
    ended_on=CASE WHEN $2='CLOSED' THEN GREATEST(starts_on+1,$3::date) END WHERE id=$1`,[bookingId,to,ended]);
   return {ok:true};
  });
 });
 route('post','/property/rent/bills',async({req,grant,c})=>{
  const b=req.body??{}, month=txt(b.month)+'-01',property=txt(b.property),dueOn=txt(b.dueOn);
  propertyRole(grant,'kosan');propertyAccess(grant,'kosan',property);
  if(!day(month)||!valid(property,100)||month>today()||(dueOn&&(!day(dueOn)||dueOn<month)))bad('Pilih properti dan bulan berjalan/sebelumnya. Jatuh tempo tidak boleh sebelum bulan tagihan.');
  const generated=await pool.query(`
   INSERT INTO business_property_bills(booking_id,period,amount,due_on)
   SELECT b.id,$3::date,b.rate,$4::date FROM business_property_bookings b JOIN business_property_rooms r ON r.id=b.room_id
   WHERE r.company_id=$1 AND r.unit='kosan' AND r.property=$2 AND b.status IN ('ACTIVE','CLOSED')
     AND b.starts_on < ($3::date+interval '1 month') AND COALESCE(b.ended_on,b.ends_on)>$3::date
   ON CONFLICT(booking_id,period) DO NOTHING`,[c,property,month,dueOn||null]);
  return {ok:true,created:generated.rowCount};
 });
 route('post','/property/bill/pay',async({req,grant,c,actor})=>{
  const {billId,paidOn}=req.body??{};
  if(!id(billId)||!day(paidOn)||paidOn>today())bad('Pilih tagihan dan tanggal pembayaran yang sah.');
  return tx(async db=>{
   const b=(await db.query(`SELECT i.id,i.amount,i.paid_at,i.receipt_id,r.unit,r.property,b.status
      FROM business_property_bills i JOIN business_property_bookings b ON b.id=i.booking_id
      JOIN business_property_rooms r ON r.id=b.room_id WHERE r.company_id=$1 AND i.id=$2 FOR UPDATE OF b,i`,[c,billId])).rows[0];
   if(!b)bad('Tagihan tidak ditemukan.',404);
   propertyRole(grant,b.unit,true);propertyAccess(grant,b.unit,b.property);
   if(b.status==='CANCELLED')bad('Booking sudah dibatalkan.',409);
   if(b.paid_at)return {ok:true,receiptId:b.receipt_id};
   const rec=(await db.query(`INSERT INTO business_report_property_receipts(company_id,unit,property,reference,paid_on,amount,created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[c,b.unit,b.property,'TAGIHAN-'+billId+'-'+randomUUID().slice(0,8),paidOn,b.amount,actor])).rows[0];
   await db.query('UPDATE business_property_bills SET paid_at=now(),receipt_id=$2 WHERE id=$1',[billId,rec.id]);
   return {ok:true,receiptId:rec.id};
  });
 });
 route('post','/property/deposit',async({req,grant,c,actor})=>{
  const b=req.body??{};
  if(!id(b.bookingId)||!['receive','refund'].includes(b.action)||(b.action==='receive'&&!money(b.amount)))bad('Isi booking dan nominal deposit yang sah.');
  return tx(async db=>{
   const booking=await loadBooking(db,c,b.bookingId);
   if(!booking)bad('Booking tidak ditemukan.',404);
   propertyRole(grant,booking.unit,true);propertyAccess(grant,booking.unit,booking.property);
   if(b.action==='receive'){
    if(!['BOOKED','ACTIVE'].includes(booking.status))bad('Booking sudah ditutup atau dibatalkan.',409);
    const r=await db.query(`INSERT INTO business_property_deposits (booking_id,amount,received_by) VALUES ($1,$2,$3)
     ON CONFLICT(booking_id) DO NOTHING`,[b.bookingId,b.amount,actor]);
    if(!r.rowCount)bad('Deposit untuk booking ini sudah pernah tercatat.',409);
   }else{
    const r=await db.query(`UPDATE business_property_deposits SET refunded_at=now(),refunded_by=$2
      WHERE booking_id=$1 AND refunded_at IS NULL`,[b.bookingId,actor]);
    if(!r.rowCount)bad('Tidak ada deposit aktif untuk dikembalikan.',409);
   }
   return {ok:true};
  });
 });
}
