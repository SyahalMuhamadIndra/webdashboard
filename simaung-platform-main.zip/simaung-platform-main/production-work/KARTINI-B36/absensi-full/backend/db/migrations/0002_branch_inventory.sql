-- Run under maintenance after a verified snapshot. Does not delete legacy rows.
CREATE SCHEMA IF NOT EXISTS kartini_ops;
CREATE TABLE IF NOT EXISTS public.kartini_schema_migrations(key text PRIMARY KEY,applied_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS public.ops_branch_access(
 company_id uuid NOT NULL REFERENCES public.companies(id), actor_id uuid NOT NULL,
 branch_id uuid NOT NULL REFERENCES public.branches(id), PRIMARY KEY(company_id,actor_id,branch_id)
);
CREATE TABLE IF NOT EXISTS public.ops_branch_config(
 company_id uuid NOT NULL REFERENCES public.companies(id),branch_id uuid PRIMARY KEY REFERENCES public.branches(id),
 warehouse_id uuid NOT NULL UNIQUE REFERENCES public.warehouses(id),legacy boolean NOT NULL DEFAULT false
);
CREATE UNIQUE INDEX IF NOT EXISTS ops_one_legacy_branch ON public.ops_branch_config(company_id) WHERE legacy;
INSERT INTO public.branches(company_id,code,name)
 SELECT c.id,'MAIN','Cabang Utama' FROM public.companies c
 WHERE NOT EXISTS(SELECT 1 FROM public.branches b WHERE b.company_id=c.id AND b.code='MAIN');
INSERT INTO public.warehouses(company_id,branch_id,code,name)
 SELECT b.company_id,b.id,'MAIN','Gudang Utama' FROM public.branches b WHERE b.code='MAIN'
 AND NOT EXISTS(SELECT 1 FROM public.warehouses w WHERE w.branch_id=b.id AND w.code='MAIN');
INSERT INTO public.ops_branch_config(company_id,branch_id,warehouse_id,legacy)
 SELECT b.company_id,b.id,w.id,true FROM public.branches b JOIN public.warehouses w ON w.branch_id=b.id AND w.code='MAIN'
 WHERE b.code='MAIN' ON CONFLICT(branch_id) DO NOTHING;
-- Existing users are assigned only to the legacy location; new assignments are explicit.
INSERT INTO public.ops_branch_access(company_id,actor_id,branch_id)
 SELECT e.company_id,e.id,c.branch_id FROM public.employees e JOIN public.ops_branch_config c ON c.company_id=e.company_id AND c.legacy
 WHERE NOT EXISTS(SELECT 1 FROM public.kartini_schema_migrations WHERE key='branch_inventory_v1')
 ON CONFLICT DO NOTHING;
INSERT INTO public.ops_branch_access(company_id,actor_id,branch_id)
 SELECT a.company_id,a.id,c.branch_id FROM public.admins a JOIN public.ops_branch_config c ON c.company_id=a.company_id AND c.legacy
 WHERE NOT EXISTS(SELECT 1 FROM public.kartini_schema_migrations WHERE key='branch_inventory_v1')
 ON CONFLICT DO NOTHING;
CREATE OR REPLACE FUNCTION kartini_ops.branch_id() RETURNS uuid LANGUAGE sql STABLE AS $$
 SELECT nullif(current_setting('kartini.branch_id',true),'')::uuid
$$;
CREATE OR REPLACE FUNCTION kartini_ops.company_id() RETURNS uuid LANGUAGE sql STABLE AS $$
 SELECT nullif(current_setting('kartini.company_id',true),'')::uuid
$$;
INSERT INTO public.profiles(id,email,full_name,is_active)
 SELECT id,email,name,active FROM public.admins ON CONFLICT(id) DO NOTHING;
INSERT INTO public.user_scopes(user_id,company_id,branch_id)
 SELECT a.id,a.company_id,c.branch_id FROM public.admins a JOIN public.ops_branch_config c ON c.company_id=a.company_id AND c.legacy
 WHERE NOT EXISTS(SELECT 1 FROM public.kartini_schema_migrations WHERE key='branch_inventory_v1')
 AND NOT EXISTS(SELECT 1 FROM public.user_scopes u WHERE u.user_id=a.id AND u.company_id=a.company_id AND u.branch_id=c.branch_id);
CREATE OR REPLACE FUNCTION kartini_ops.check_references() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE item record; value uuid; target_branch uuid; target_company uuid; row_data jsonb:=to_jsonb(NEW);
BEGIN
 SELECT company_id INTO target_company FROM public.branches WHERE id=NEW.branch_id;
 IF target_company IS NULL OR (row_data?'company_id' AND (row_data->>'company_id')::uuid IS DISTINCT FROM target_company) THEN RAISE EXCEPTION 'Company/branch mismatch'; END IF;
 FOR item IN SELECT * FROM (VALUES('sale_id','ops_pos_sales'),('session_id','ops_pos_sessions'),('customer_id','ops_customers'),('material_id','ops_materials'),('receivable_id','ops_receivables'),('opname_id','ops_stock_opnames'),('note_id','ops_delivery_notes'),('trip_id','ops_trips')) AS x(key,target) LOOP
  value:=nullif(row_data->>item.key,'')::uuid;
  IF value IS NOT NULL THEN
   EXECUTE format('SELECT branch_id FROM public.%I WHERE id=$1',item.target) INTO target_branch USING value;
   IF target_branch IS DISTINCT FROM NEW.branch_id THEN RAISE EXCEPTION 'Cross-branch reference rejected'; END IF;
  END IF;
 END LOOP;
 value:=nullif(row_data->>'product_id','')::uuid;
 IF value IS NOT NULL AND NOT EXISTS(SELECT 1 FROM public.ops_products p WHERE p.id=value AND p.company_id=target_company) THEN RAISE EXCEPTION 'Product company mismatch'; END IF;
 RETURN NEW;
END $$;
-- Canonical product identifiers are shared with ERP. Fail on conflicting SKU rather than silently merging.
INSERT INTO public.products(id,company_id,sku,name,is_active,is_track_inventory)
 SELECT p.id,p.company_id,coalesce(nullif(p.sku,''),'POS-'||p.id),p.name,p.active,true FROM public.ops_products p
 WHERE NOT EXISTS(SELECT 1 FROM public.products e WHERE e.id=p.id);
INSERT INTO public.stock_balances(company_id,warehouse_id,product_id,quantity,avg_cost)
 SELECT p.company_id,c.warehouse_id,p.id,p.stock,p.cost FROM public.ops_products p
 JOIN public.ops_branch_config c ON c.company_id=p.company_id AND c.legacy
 WHERE NOT EXISTS(SELECT 1 FROM public.stock_balances s WHERE s.warehouse_id=c.warehouse_id AND s.product_id=p.id);
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM public.stock_balances WHERE quantity<0) THEN RAISE EXCEPTION 'Resolve negative legacy stock before migration'; END IF;
END $$;
CREATE UNIQUE INDEX IF NOT EXISTS kartini_stock_location_product ON public.stock_balances(company_id,warehouse_id,product_id);
CREATE OR REPLACE FUNCTION kartini_ops.stock_ledger() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE delta numeric;
BEGIN
 IF NEW.quantity<0 THEN RAISE EXCEPTION 'Insufficient stock'; END IF;
 delta:=NEW.quantity-CASE WHEN TG_OP='INSERT' THEN 0 ELSE OLD.quantity END;
 IF delta<>0 AND current_setting('kartini.origin',true)='POS' THEN
  INSERT INTO public.stock_movements(company_id,warehouse_id,product_id,movement_type,quantity,unit_cost,description)
   VALUES(NEW.company_id,NEW.warehouse_id,NEW.product_id,'adjustment',delta,NEW.avg_cost,'POS/ERP stock synchronization');
 END IF;
 IF EXISTS(SELECT 1 FROM public.ops_branch_config c WHERE c.warehouse_id=NEW.warehouse_id AND c.legacy) THEN
  UPDATE public.ops_products SET stock=NEW.quantity,updated_at=now() WHERE id=NEW.product_id AND stock IS DISTINCT FROM NEW.quantity;
 END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS kartini_stock_ledger ON public.stock_balances;
CREATE TRIGGER kartini_stock_ledger AFTER INSERT OR UPDATE OF quantity ON public.stock_balances FOR EACH ROW EXECUTE FUNCTION kartini_ops.stock_ledger();
CREATE OR REPLACE FUNCTION kartini_ops.catalog_bridge() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF pg_trigger_depth()>2 THEN RETURN NEW; END IF;
 IF TG_TABLE_NAME='ops_products' THEN
  INSERT INTO public.products(id,company_id,sku,name,is_active,is_track_inventory)
   VALUES(NEW.id,NEW.company_id,coalesce(nullif(NEW.sku,''),'POS-'||NEW.id),NEW.name,NEW.active,true)
   ON CONFLICT(id) DO UPDATE SET sku=EXCLUDED.sku,name=EXCLUDED.name,is_active=EXCLUDED.is_active;
 ELSE
  INSERT INTO public.ops_products(id,company_id,sku,name,active,stock)VALUES(NEW.id,NEW.company_id,NEW.sku,NEW.name,NEW.is_active,0)
   ON CONFLICT(id) DO UPDATE SET sku=EXCLUDED.sku,name=EXCLUDED.name,active=EXCLUDED.active;
 END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS kartini_catalog_bridge ON public.ops_products;
CREATE TRIGGER kartini_catalog_bridge AFTER INSERT OR UPDATE OF sku,name,active ON public.ops_products FOR EACH ROW EXECUTE FUNCTION kartini_ops.catalog_bridge();
DROP TRIGGER IF EXISTS kartini_catalog_bridge ON public.products;
CREATE TRIGGER kartini_catalog_bridge AFTER INSERT OR UPDATE OF sku,name,is_active ON public.products FOR EACH ROW EXECUTE FUNCTION kartini_ops.catalog_bridge();
-- All operational documents and material/variant stock are branch owned.
DO $$ DECLARE r record;parent text;fk text; BEGIN
 FOR r IN SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename LIKE 'ops_%'
  AND tablename NOT IN ('ops_products','ops_settings','ops_branch_access','ops_branch_config') ORDER BY tablename LOOP
  EXECUTE format('ALTER TABLE public.%I ADD COLUMN IF NOT EXISTS branch_id uuid REFERENCES public.branches(id)',r.tablename);
  EXECUTE format('ALTER TABLE public.%I ALTER COLUMN branch_id SET DEFAULT kartini_ops.branch_id()',r.tablename);
  IF EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=r.tablename AND column_name='company_id') THEN
   EXECUTE format('UPDATE public.%I t SET branch_id=c.branch_id FROM public.ops_branch_config c WHERE c.company_id=t.company_id AND c.legacy AND t.branch_id IS NULL',r.tablename);
  END IF;
 END LOOP;
 -- Detail tables inherit existing parent branch, never an arbitrary company.
 FOR r IN SELECT * FROM (VALUES
  ('ops_delivery_note_items','note_id','ops_delivery_notes'),('ops_pos_sale_items','sale_id','ops_pos_sales'),
  ('ops_stock_opname_items','opname_id','ops_stock_opnames'),('ops_trip_events','trip_id','ops_trips'),
  ('ops_product_variants','product_id','ops_products')) AS x(child,key,parent) LOOP
  IF r.parent='ops_products' THEN
   EXECUTE format('UPDATE public.%I t SET branch_id=c.branch_id FROM public.ops_products p JOIN public.ops_branch_config c ON c.company_id=p.company_id AND c.legacy WHERE t.%I=p.id AND t.branch_id IS NULL',r.child,r.key);
  ELSE
   EXECUTE format('UPDATE public.%I t SET branch_id=p.branch_id FROM public.%I p WHERE t.%I=p.id AND t.branch_id IS NULL',r.child,r.parent,r.key);
  END IF;
 END LOOP;
 FOR r IN SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename LIKE 'ops_%'
  AND tablename NOT IN ('ops_products','ops_settings','ops_branch_access','ops_branch_config') LOOP
  EXECUTE format('ALTER TABLE public.%I ALTER COLUMN branch_id SET NOT NULL',r.tablename);
  EXECUTE format('DROP TRIGGER IF EXISTS kartini_branch_references ON public.%I',r.tablename);
  EXECUTE format('CREATE TRIGGER kartini_branch_references BEFORE INSERT OR UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION kartini_ops.check_references()',r.tablename);
  EXECUTE format('CREATE OR REPLACE VIEW kartini_ops.%I WITH(security_barrier=true) AS SELECT * FROM public.%I WHERE branch_id=kartini_ops.branch_id() WITH CASCADED CHECK OPTION',r.tablename,r.tablename);
 END LOOP;
END $$;
-- Product catalog is shared; stock is selected from the current branch warehouse.
DO $$ DECLARE cols text; BEGIN
 SELECT string_agg(CASE WHEN column_name='stock' THEN 'coalesce(s.quantity,0) AS stock' WHEN column_name='cost' THEN 'coalesce(s.avg_cost,p.cost) AS cost' ELSE 'p.'||quote_ident(column_name) END,',' ORDER BY ordinal_position)
 INTO cols FROM information_schema.columns WHERE table_schema='public' AND table_name='ops_products';
 EXECUTE 'CREATE OR REPLACE VIEW kartini_ops.ops_products WITH(security_barrier=true) AS SELECT '||cols||
 ' FROM public.ops_products p JOIN public.ops_branch_config c ON c.company_id=p.company_id AND c.branch_id=kartini_ops.branch_id() LEFT JOIN public.stock_balances s ON s.warehouse_id=c.warehouse_id AND s.product_id=p.id WHERE p.company_id=kartini_ops.company_id()';
END $$;
CREATE OR REPLACE FUNCTION kartini_ops.product_write() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE warehouse uuid; base public.ops_products; current_quantity numeric; BEGIN
 SELECT warehouse_id INTO warehouse FROM public.ops_branch_config WHERE branch_id=kartini_ops.branch_id() AND company_id=kartini_ops.company_id();
 IF warehouse IS NULL THEN RAISE EXCEPTION 'Branch warehouse unavailable'; END IF;
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Archive products instead of deleting shared catalog'; END IF;
 IF NEW.company_id IS DISTINCT FROM kartini_ops.company_id() THEN RAISE EXCEPTION 'Company not allowed'; END IF;
 IF TG_OP='INSERT' THEN
  NEW.id:=coalesce(NEW.id,gen_random_uuid());
  INSERT INTO public.ops_products(id,company_id,sku,name,category,unit,price,cost,stock,min_stock,active,image,barcode)
   VALUES(NEW.id,NEW.company_id,NEW.sku,NEW.name,NEW.category,coalesce(NEW.unit,'pcs'),coalesce(NEW.price,0),coalesce(NEW.cost,0),0,coalesce(NEW.min_stock,0),coalesce(NEW.active,true),NEW.image,NEW.barcode);
 ELSE
  IF NEW.id IS DISTINCT FROM OLD.id OR NEW.company_id IS DISTINCT FROM OLD.company_id THEN RAISE EXCEPTION 'Identity is immutable'; END IF;
  -- Lock canonical location balance before applying delta from the statement snapshot.
  INSERT INTO public.stock_balances(company_id,warehouse_id,product_id,quantity,avg_cost)VALUES(NEW.company_id,warehouse,NEW.id,0,coalesce(NEW.cost,0)) ON CONFLICT DO NOTHING;
 END IF;
 IF TG_OP='INSERT' THEN
  INSERT INTO public.stock_balances(company_id,warehouse_id,product_id,quantity,avg_cost)VALUES(NEW.company_id,warehouse,NEW.id,coalesce(NEW.stock,0),coalesce(NEW.cost,0));
 ELSE
  SELECT s.quantity INTO current_quantity FROM public.stock_balances s WHERE s.warehouse_id=warehouse AND s.product_id=NEW.id FOR UPDATE;
  current_quantity:=current_quantity+(NEW.stock-OLD.stock);
  IF current_quantity<0 THEN RETURN NULL; END IF;
  UPDATE public.stock_balances SET quantity=current_quantity,avg_cost=CASE WHEN NEW.cost IS DISTINCT FROM OLD.cost THEN NEW.cost ELSE avg_cost END,updated_at=now()
   WHERE warehouse_id=warehouse AND product_id=NEW.id;
  UPDATE public.ops_products SET sku=NEW.sku,name=NEW.name,category=NEW.category,unit=NEW.unit,price=NEW.price,cost=NEW.cost,min_stock=NEW.min_stock,active=NEW.active,image=NEW.image,barcode=NEW.barcode,updated_at=now() WHERE id=NEW.id;
 END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS product_write ON kartini_ops.ops_products;
CREATE TRIGGER product_write INSTEAD OF INSERT OR UPDATE OR DELETE ON kartini_ops.ops_products FOR EACH ROW EXECUTE FUNCTION kartini_ops.product_write();
INSERT INTO public.kartini_schema_migrations(key)VALUES('branch_inventory_v1')ON CONFLICT DO NOTHING;
