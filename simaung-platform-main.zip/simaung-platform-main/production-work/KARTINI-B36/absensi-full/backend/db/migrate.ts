import 'dotenv/config';
import { Pool } from 'pg';
import bcrypt from 'bcryptjs';

const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 2 });

async function main() {
  await pool.query(`
    CREATE EXTENSION IF NOT EXISTS pgcrypto;

    CREATE TABLE IF NOT EXISTS admins (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
      name text NOT NULL,
      email text NOT NULL UNIQUE,
      password_hash text NOT NULL,
      role text NOT NULL DEFAULT 'SUPERADMIN',
      active boolean NOT NULL DEFAULT true,
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
    );

    ALTER TABLE leaves ADD COLUMN IF NOT EXISTS attachment_base64 text;
    ALTER TABLE leaves ADD COLUMN IF NOT EXISTS attachment_type text;
    ALTER TABLE overtimes ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
    ALTER TABLE attendance ADD COLUMN IF NOT EXISTS face_score integer;

    -- Foto wajah karyawan (dipakai layar Profil).
    ALTER TABLE employees ADD COLUMN IF NOT EXISTS photo_base64 text;

    -- Perangkat: pencabutan akses + info versi aplikasi (Alat Developer).
    ALTER TABLE devices ADD COLUMN IF NOT EXISTS revoked_at timestamptz;
    ALTER TABLE devices ADD COLUMN IF NOT EXISTS last_seen_at timestamptz;
    ALTER TABLE devices ADD COLUMN IF NOT EXISTS app_version_code integer;

    -- Log aktivitas admin (audit trail) untuk Alat Developer.
    CREATE TABLE IF NOT EXISTS audit_log (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      company_id uuid,
      actor_type text NOT NULL DEFAULT 'ADMIN',
      actor_id text,
      actor_name text,
      actor_role text,
      action text NOT NULL,
      target text,
      detail text,
      ip text,
      created_at timestamptz NOT NULL DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS idx_audit_log_company_created ON audit_log (company_id, created_at DESC);

    -- Feature flags / remote config per perusahaan.
    CREATE TABLE IF NOT EXISTS feature_flags (
      company_id uuid NOT NULL,
      key text NOT NULL,
      label text,
      description text,
      enabled boolean NOT NULL DEFAULT true,
      updated_by text,
      updated_at timestamptz NOT NULL DEFAULT now(),
      PRIMARY KEY (company_id, key)
    );

    -- Kolom keputusan superadmin untuk pengajuan izin (approve/reject).
    ALTER TABLE leaves ADD COLUMN IF NOT EXISTS decided_at timestamptz;
    ALTER TABLE leaves ADD COLUMN IF NOT EXISTS decided_by uuid;
    ALTER TABLE leaves ADD COLUMN IF NOT EXISTS decision_note text;

    -- Kolom keputusan superadmin untuk pengajuan lembur.
    ALTER TABLE overtimes ADD COLUMN IF NOT EXISTS decided_at timestamptz;
    ALTER TABLE overtimes ADD COLUMN IF NOT EXISTS decided_by uuid;
    ALTER TABLE overtimes ADD COLUMN IF NOT EXISTS decision_note text;

    CREATE INDEX IF NOT EXISTS idx_leaves_employee ON leaves(employee_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_overtimes_employee ON overtimes(employee_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_attendance_day ON attendance(employee_id, server_timestamp DESC);

    -- ====== Rilis APK aplikasi (fitur "Update Aplikasi" via server) ======
    CREATE TABLE IF NOT EXISTS app_releases (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      company_id uuid REFERENCES companies(id) ON DELETE CASCADE,
      version_name text NOT NULL,
      version_code integer NOT NULL,
      apk_url text NOT NULL,
      mandatory boolean NOT NULL DEFAULT false,
      notes text,
      active boolean NOT NULL DEFAULT true,
      download_count integer NOT NULL DEFAULT 0,
      created_at timestamptz NOT NULL DEFAULT now()
    );
    -- Tabel mungkin sudah ada dari versi sebelumnya -> pastikan kolom terbaru.
    ALTER TABLE app_releases ADD COLUMN IF NOT EXISTS company_id uuid;
    ALTER TABLE app_releases ADD COLUMN IF NOT EXISTS platform text NOT NULL DEFAULT 'android';
    ALTER TABLE app_releases ADD COLUMN IF NOT EXISTS download_count integer NOT NULL DEFAULT 0;
    ALTER TABLE app_releases ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;
    CREATE INDEX IF NOT EXISTS idx_app_releases_version ON app_releases(version_code DESC);

    -- ====== Token perangkat untuk push notification (FCM / fallback internal) ======
    CREATE TABLE IF NOT EXISTS device_tokens (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      employee_id uuid REFERENCES employees(id) ON DELETE CASCADE,
      token text NOT NULL UNIQUE,
      platform text NOT NULL DEFAULT 'android',
      updated_at timestamptz NOT NULL DEFAULT now()
    );

    -- ====== Notifikasi dari server (jalur internal bila FCM belum aktif) ======
    CREATE TABLE IF NOT EXISTS notifications (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      company_id uuid REFERENCES companies(id) ON DELETE CASCADE,
      employee_id uuid REFERENCES employees(id) ON DELETE CASCADE,
      title text NOT NULL,
      body text,
      kind text NOT NULL DEFAULT 'INFO',
      read boolean NOT NULL DEFAULT false,
      created_at timestamptz NOT NULL DEFAULT now()
    );
    -- Tabel mungkin sudah ada dari versi sebelumnya -> pastikan kolom terbaru.
    ALTER TABLE notifications ADD COLUMN IF NOT EXISTS company_id uuid;
    ALTER TABLE notifications ADD COLUMN IF NOT EXISTS employee_id uuid;
    ALTER TABLE notifications ADD COLUMN IF NOT EXISTS read boolean NOT NULL DEFAULT false;
    CREATE INDEX IF NOT EXISTS idx_notifications_employee ON notifications(employee_id, created_at DESC);

    -- ====== Pengaturan per-perusahaan (B7/B15) ======
    -- Kata sandi default karyawan disimpan di DB agar tahan cold-start Vercel.
    CREATE TABLE IF NOT EXISTS app_settings (
      company_id uuid PRIMARY KEY,
      employee_default_password text NOT NULL DEFAULT 'abc123456',
      updated_at timestamptz NOT NULL DEFAULT now()
    );
  `);

  const companyId = (await pool.query(`SELECT id FROM companies ORDER BY created_at LIMIT 1`)).rows[0]?.id;
  if (!companyId) throw new Error('Company tidak ditemukan — jalankan db:seed dulu');

  // Migrations never reset existing account credentials or reactivate accounts.
  for (const [prefix, role, name] of [['OWNER', 'SUPERADMIN', 'Super Admin'], ['DEVELOPER', 'DEV', 'Developer']]) {
    const email = process.env[`BOOTSTRAP_${prefix}_EMAIL`];
    const password = process.env[`BOOTSTRAP_${prefix}_PASSWORD`];
    if (!email && !password) continue;
    if (!email || !password || password.length < 12) throw new Error(`Bootstrap ${prefix}: email dan password minimal 12 karakter wajib diisi.`);
    const hash = await bcrypt.hash(password, 12);
    await pool.query(`INSERT INTO admins (company_id,name,email,password_hash,role)
      VALUES ($1,$2,$3,$4,$5) ON CONFLICT (email) DO NOTHING`, [companyId,name,email,hash,role]);
  }
  console.log('Migrasi selesai. Kredensial akun yang sudah ada tidak diubah.');

}

main().finally(() => pool.end());


