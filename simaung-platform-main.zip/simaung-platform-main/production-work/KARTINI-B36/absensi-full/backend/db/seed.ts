import 'dotenv/config';
import { Pool } from 'pg';
import bcrypt from 'bcryptjs';

const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 2 });

function schema() {
  return `
    CREATE EXTENSION IF NOT EXISTS pgcrypto;
    CREATE TABLE IF NOT EXISTS companies (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, office_name text NOT NULL,
      office_latitude double precision NOT NULL, office_longitude double precision NOT NULL,
      office_radius_meters double precision NOT NULL DEFAULT 100, minimum_location_accuracy_meters double precision NOT NULL DEFAULT 100,
      created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
    );
    ALTER TABLE companies ADD COLUMN IF NOT EXISTS phone text;
    ALTER TABLE companies ADD COLUMN IF NOT EXISTS address text;
    CREATE TABLE IF NOT EXISTS employees (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
      employee_code text NOT NULL, full_name text NOT NULL, pin_hash text NOT NULL, active boolean NOT NULL DEFAULT true,
      created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(company_id, employee_code)
    );
    ALTER TABLE employees ADD COLUMN IF NOT EXISTS position text;
    ALTER TABLE employees ADD COLUMN IF NOT EXISTS phone text;
    ALTER TABLE employees ADD COLUMN IF NOT EXISTS avatar_color text;
    ALTER TABLE employees ADD COLUMN IF NOT EXISTS shift_id uuid;
    CREATE TABLE IF NOT EXISTS shifts (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
      name text NOT NULL, start_time time NOT NULL, end_time time NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS devices (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(), employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
      device_key text NOT NULL, platform text NOT NULL DEFAULT 'android', last_login_at timestamptz,
      last_seen_at timestamptz, revoked_at timestamptz, app_version_code integer,
      created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(employee_id, device_key)
    );
    CREATE TABLE IF NOT EXISTS attendance (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
      employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE, device_id uuid REFERENCES devices(id) ON DELETE SET NULL,
      type text NOT NULL CHECK (type IN ('CHECK_IN','CHECK_OUT')), latitude double precision NOT NULL, longitude double precision NOT NULL,
      accuracy_meters double precision NOT NULL, distance_meters double precision NOT NULL, mock_location boolean NOT NULL DEFAULT false,
      face_detected boolean NOT NULL DEFAULT false, liveness_passed boolean NOT NULL DEFAULT false, face_match boolean NOT NULL DEFAULT false,
      client_timestamp timestamptz NOT NULL, server_timestamp timestamptz NOT NULL DEFAULT now(), status text NOT NULL DEFAULT 'APPROVED',
      idempotency_key text NOT NULL UNIQUE
    );
  `;
}

async function main() {
  if (process.env.VERCEL_ENV === 'production' || process.env.ENABLE_DEMO_SEED !== 'true') throw new Error('Demo seed dinonaktifkan; hanya boleh pada database uji dengan ENABLE_DEMO_SEED=true.');
  await pool.query(schema());
  const company = await pool.query(
    `INSERT INTO companies (name, office_name, office_latitude, office_longitude, office_radius_meters, minimum_location_accuracy_meters)
     VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING RETURNING id`,
    ['AbsensiKu Demo', 'Kantor Utama', -5.100000, 105.300000, 100, 80]
  );
  let companyId = company.rows[0]?.id;
  if (!companyId) companyId = (await pool.query(`SELECT id FROM companies ORDER BY created_at LIMIT 1`)).rows[0]?.id;
  if (!companyId) throw new Error('Company seed gagal');

  const pinHash = await bcrypt.hash('abc123456', 12);
  await pool.query(
    `INSERT INTO employees (company_id, employee_code, full_name, pin_hash)
     VALUES ($1,$2,$3,$4)
     ON CONFLICT (company_id, employee_code)
     DO NOTHING`,
    [companyId, 'EMP001', 'Karyawan Demo', pinHash]
  );
  console.log('Seed demo selesai pada database uji.');
}

main().finally(() => pool.end());


