import 'dotenv/config';
import { Pool } from 'pg';
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 2 });
async function main(){
  const t = await pool.query(`SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY 1`);
  console.log('TABLES:', t.rows.map((r:any)=>r.table_name).join(', '));
  for (const tbl of ['companies','employees','shifts','leaves','overtimes','attendance']) {
    const c = await pool.query(`SELECT column_name,data_type FROM information_schema.columns WHERE table_name=$1 ORDER BY ordinal_position`,[tbl]);
    console.log(`\n${tbl}:`, c.rows.map((r:any)=>r.column_name+':'+r.data_type).join(', '));
  }
}
main().finally(()=>pool.end());


