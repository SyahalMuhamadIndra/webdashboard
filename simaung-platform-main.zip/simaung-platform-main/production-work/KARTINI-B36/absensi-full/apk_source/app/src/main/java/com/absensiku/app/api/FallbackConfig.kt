package com.absensiku.app.api

/**
 * FALLBACK PENGATURAN KANTOR (B54) — dipakai HANYA sebagai pilihan TERAKHIR.
 *
 * Urutan sumber pengaturan kantor (dari yang paling dipercaya):
 *   1. Server  (GET /api/config)            — paling akurat & terbaru
 *   2. Salinan lokal (cache dari login)     — dari kunjungan online sebelumnya
 *   3. Fallback ini                          — bila keduanya belum ada
 *
 * Alasan fallback ini ada (sesuai permintaan pemilik):
 *   Karyawan sudah pernah memakai aplikasi sebelumnya, jadi pengaturan kantor
 *   seharusnya sudah tersimpan. Namun bila karyawan memasang PEMBARUAN aplikasi
 *   dalam keadaan belum pernah sekali pun online (mis. instal ulang), tanpa
 *   fallback ini aplikasi tidak tahu radius kantor dan absen offline tidak bisa
 *   dihitung. Dengan nilai di bawah, PEMBACAAN GPS langsung berfungsi sejak
 *   detik pertama walau tanpa internet sama sekali.
 *
 * CATATAN KEAMANAN:
 *   - Server TETAP penentu akhir. Absen di luar jangkauan tetap DITOLAK server
 *     (lihat B52), jadi nilai fallback ini tidak membuka celah absen dari jauh.
 *   - Koordinat kantor ini sudah bersifat publik (tercantum di halaman web
 *     superadmin), jadi tidak ada informasi rahasia yang dibocorkan.
 *   - Bila admin mengubah lokasi kantor, nilai dari server/cache akan MENANG
 *     atas fallback ini secara otomatis.
 */
object FallbackConfig {

    /** Nama kantor default. */
    const val OFFICE_NAME = "Kantor Simaung Corporation"

    /** Alamat kantor. */
    const val ADDRESS = "Jalan Cut Nyak Dien, Sukajaya, Sumedang, Jawa Barat, 45321, Indonesia"

    /** Koordinat kantor pusat Simaung Corporation. */
    const val LATITUDE = -6.859486
    const val LONGITUDE = 107.922171

    /**
     * Radius area absen (meter) — DARI PENGATURAN PRODUKSI admin.tokokartini.com
     * ("Radius Absen" = 140 m). Bukan 100 m seperti data demo.
     */
    const val RADIUS_METERS = 140.0

    /**
     * Batas akurasi GPS (meter) — DARI PENGATURAN PRODUKSI
     * ("Akurasi GPS Maksimum" = ±50 m). Bukan 80 m seperti data demo.
     */
    const val MIN_ACCURACY_METERS = 50.0

    /**
     * Toleransi pergeseran GPS yang SUDAH DIBATASI — harus PERSIS sama dengan
     * cappedDriftTolerance() di server:
     *   min(75, min(150, radius / 2))
     * Dengan radius 140 m -> min(75, min(150, 70)) = 70 m.
     * Radius efektif = min(140 + 70, 140*1.5 + 50) = 210 m.
     */
    const val DRIFT_TOLERANCE_METERS = 70.0

    /** Bangun CompanyConfig fallback. */
    fun config(): CompanyConfig = CompanyConfig(
        officeName = OFFICE_NAME,
        address = ADDRESS,
        officeLatitude = LATITUDE,
        officeLongitude = LONGITUDE,
        officeRadiusMeters = RADIUS_METERS,
        minimumLocationAccuracyMeters = MIN_ACCURACY_METERS,
        shiftName = null,
        shiftStart = null,
        shiftEnd = null,
        gpsDriftToleranceMeters = DRIFT_TOLERANCE_METERS,
        effectiveRadiusMetersFromServer = null,
        features = emptyMap(),
    )
}
