package com.absensiku.app.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Business
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.R
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.MeResponse
import com.absensiku.app.biometric.BiometricPrefs
import com.absensiku.app.face.FaceRepository
import com.absensiku.app.reminder.AttendanceReminder
import com.absensiku.app.reminder.ReminderPrefs
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * Layar Profil karyawan.
 *
 * Menampilkan identitas + mengelola:
 *  - Foto profil (ambil dari galeri, kirim ke server).
 *  - Biometrik (login cepat dengan sidik jari / wajah perangkat).
 *  - Data wajah absensi (status terdaftar / rekam ulang).
 */
@Composable
fun ProfileScreen(
    api: ApiClient,
    onLogout: () -> Unit,
    /** Status wajah absensi: null = memuat, true = terdaftar, false = belum rekam. */
    enrolled: Boolean? = null,
    /** Mulai proses rekam ulang wajah (dibuka layar kamera full-screen). */
    onStartEnroll: () -> Unit = {},
    /** Info tindakan (sukses/gagal) ke notifikasi profesional aplikasi. */
    onNotify: (Boolean, String, String?) -> Unit = { _, _, _ -> },
    /** Feature flag: tampilkan/sembunyikan menu Ganti Password (Remote Config). */
    allowChangePassword: Boolean = true,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { FaceRepository(api, context) }
    val bio = remember { BiometricPrefs(context) }

    var me by remember { mutableStateOf<MeResponse?>(null) }
    var busy by remember { mutableStateOf(true) }

    // Foto profil: bitmap sementara yang baru dipilih/diunduh.
    var photoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var photoBusy by remember { mutableStateOf(false) }

    // Biometrik tersedia di perangkat & preferensi tersimpan.
    val biometricAvailable = remember { bio.isHardwareAvailable() }
    var biometricEnabled by remember { mutableStateOf(bio.isEnabled()) }

    // Ganti password (self-service): status default + dialog ganti.
    var pwIsDefault by remember { mutableStateOf(false) }
    var showChangePassword by remember { mutableStateOf(false) }

    // Pengingat Absen (reminder) — dikelola lokal di perangkat.
    val rp = remember { ReminderPrefs(context) }
    var reminderEnabled by remember { mutableStateOf(rp.enabled) }
    var reminderLead by remember { mutableStateOf(rp.leadMinutes) }
    var remindCheckout by remember { mutableStateOf(rp.remindCheckout) }

    fun applyBase64(b64: String?) {
        photoBitmap = decodeBase64(b64)
    }

    LaunchedEffect(Unit) {
        scope.launch {
            me = runCatching { api.getMe() }.getOrNull()
            applyBase64(me?.photoBase64)
            busy = false
            runCatching { api.getPasswordStatus() }.getOrNull()?.let { pwIsDefault = it.isDefault }
            // Jadwalkan ulang pengingat absen berdasarkan shift terbaru hari ini.
            if (me?.isOffToday != true) {
                rp.saveShift(me?.shiftStart?.take(5), me?.shiftEnd?.take(5))
                AttendanceReminder.schedule(
                    context,
                    AttendanceReminder.parseHm(me?.shiftStart),
                    AttendanceReminder.parseHm(me?.shiftEnd),
                )
            }
        }
    }

    if (showChangePassword) {
        ChangePasswordDialog(
            api = api,
            isDefault = pwIsDefault,
            onDismiss = { showChangePassword = false },
            onDone = { ok, title, msg ->
                showChangePassword = false
                if (ok) pwIsDefault = false
                onNotify(ok, title, msg)
            },
        )
    }

    val pickPhoto = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        photoBusy = true
        scope.launch {
            val result = withContext(Dispatchers.IO) { loadCompressedAvatar(uri, context.contentResolver) }
            if (result == null) {
                photoBusy = false
                onNotify(false, "Foto Gagal Dimuat", "Coba pilih gambar lain.")
                return@launch
            }
            photoBitmap = result.first
            try {
                api.updateMyPhoto(result.second)
                onNotify(true, "Foto Profil Diperbarui", "Foto profil Anda telah disimpan.")
            } catch (e: kotlinx.coroutines.CancellationException) {

                throw e

            } catch (e: Exception) {
                onNotify(false, "Gagal Menyimpan Foto", e.message ?: "Periksa koneksi lalu coba lagi.")
            } finally {
                photoBusy = false
            }
        }
    }

    val fullName = me?.fullName ?: api.employeeName()
    val initial = fullName.take(1).uppercase()

    Column(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        // ---------- Hero header (rounded bawah) ----------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(Brush.verticalGradient(listOf(KartiniColors.BrandGreenDark, KartiniColors.BrandGreen)))
                .padding(top = 24.dp, bottom = 30.dp, start = 20.dp, end = 20.dp),
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // ---- Avatar + tombol kamera ----
                Box(modifier = Modifier.size(112.dp)) {
                    Box(
                        modifier = Modifier.size(100.dp).clip(CircleShape).background(Color.White)
                            .align(Alignment.Center),
                        contentAlignment = Alignment.Center,
                    ) {
                        val bmp = photoBitmap
                        if (busy || photoBusy) {
                            CircularProgressIndicator(color = KartiniColors.BrandGreen, modifier = Modifier.size(28.dp))
                        } else if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Foto profil",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(CircleShape),
                            )
                        } else {
                            Text(
                                text = initial,
                                color = KartiniColors.BrandGreen, fontSize = 38.sp, fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                    // Tombol kamera (ubah foto)
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(KartiniColors.BrandOrange)
                            .border(2.dp, Color.White, CircleShape)
                            .align(Alignment.BottomEnd)
                            .clickable(enabled = !photoBusy) { pickPhoto.launch("image/*") },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Outlined.CameraAlt, contentDescription = "Ubah foto",
                            tint = Color.White, modifier = Modifier.size(18.dp),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    if (photoBitmap != null) "Ketuk ikon kamera untuk ganti foto" else "Ketuk ikon kamera untuk pasang foto",
                    color = Color.White.copy(alpha = 0.72f), fontSize = 11.sp,
                )
                Spacer(Modifier.height(12.dp))
                Text(fullName, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "${me?.position ?: "Karyawan"} • ${me?.companyName ?: "Simaung Corporation"}",
                    color = Color.White.copy(alpha = 0.82f), fontSize = 13.sp,
                )
                Spacer(Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .background(Color.White, RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 5.dp),
                ) {
                    Text(
                        text = me?.employeeCode ?: api.employeeCode().ifBlank { "-" },
                        color = KartiniColors.BrandGreen, fontSize = 11.5.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }

        // ---------- Konten ----------
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionTitle("Informasi Karyawan")
            SectionCard {
                ProfileRow(Icons.Outlined.Business, "Perusahaan", me?.companyName ?: "-")
                HorizontalDivider(color = KartiniColors.DividerLight)
                ProfileRow(Icons.Outlined.Badge, "Jabatan", me?.position ?: "Karyawan")
                HorizontalDivider(color = KartiniColors.DividerLight)
                ProfileRow(Icons.Outlined.Phone, "Nomor Telepon", me?.phone?.ifBlank { "-" } ?: "-")
                HorizontalDivider(color = KartiniColors.DividerLight)
                ProfileRow(
                    Icons.Outlined.Badge, "Kode Karyawan",
                    me?.employeeCode ?: api.employeeCode().ifBlank { "-" },
                )
            }

            SectionTitle("Keamanan & Biometrik")
            SectionCard {
                if (allowChangePassword) {
                    ActionRow(
                        icon = Icons.Outlined.Lock,
                        title = "Ganti Password",
                        subtitle = if (pwIsDefault)
                            "Masih memakai password default — segera ganti"
                        else "Ubah password akun Anda",
                        trailing = {
                            Button(
                                onClick = { showChangePassword = true },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (pwIsDefault) KartiniColors.BrandOrange else KartiniColors.BrandGreen,
                                    contentColor = Color.White,
                                ),
                            ) { Text("Ganti", fontSize = 12.5.sp, fontWeight = FontWeight.Bold) }
                        },
                    )
                    HorizontalDivider(color = KartiniColors.DividerLight)
                }
                ActionRow(
                    icon = Icons.Outlined.Face,
                    title = "Data Wajah Absensi",
                    subtitle = when (enrolled) {
                        null -> "Memeriksa status…"
                        true -> "Terdaftar — absensi siap digunakan"
                        false -> "Belum terdaftar — rekam sekarang"
                    },
                    trailing = {
                        when (enrolled) {
                            false -> Button(
                                onClick = onStartEnroll,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = KartiniColors.BrandOrange,
                                    contentColor = Color.White,
                                ),
                            ) { Text("Rekam", fontSize = 12.5.sp, fontWeight = FontWeight.Bold) }
                            true -> TextButton(onClick = onStartEnroll) {
                                Text("Rekam Ulang", color = KartiniColors.BrandGreen, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                            }
                            null -> CircularProgressIndicator(
                                color = KartiniColors.BrandGreen, strokeWidth = 2.dp,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    },
                )
                HorizontalDivider(color = KartiniColors.DividerLight)
                ActionRow(
                    icon = Icons.Filled.Fingerprint,
                    title = "Login Biometrik",
                    subtitle = when {
                        !biometricAvailable -> "Tidak tersedia di perangkat ini"
                        biometricEnabled -> "Aktif — masuk dengan sidik jari/wajah"
                        else -> "Nonaktif — aktifkan untuk masuk cepat"
                    },
                    trailing = {
                        Switch(
                            checked = biometricEnabled,
                            enabled = biometricAvailable,
                            onCheckedChange = { value ->
                                biometricEnabled = value
                                bio.setEnabled(value)
                                if (value) {
                                    // Bila perangkat ini sudah punya kredensial tersimpan
                                    // (mis. dari login sebelumnya), biometrik langsung siap.
                                    // Bila belum, kredensial akan tersimpan otomatis saat
                                    // login berikutnya (karena flag sudah aktif) — sehingga
                                    // tombol "Masuk dengan Biometrik" muncul di layar masuk.
                                    if (bio.hasCredentials()) {
                                        onNotify(true, "Login Biometrik Diaktifkan", "Anda bisa masuk dengan sidik jari/wajah di layar masuk.")
                                    } else {
                                        onNotify(true, "Login Biometrik Diaktifkan", "Setelah keluar, masuk sekali dengan Kode & Password agar biometrik siap dipakai.")
                                    }
                                } else {
                                    // Nonaktifkan + hapus kredensial agar tidak ada sisa data.
                                    bio.clearCredentials()
                                    onNotify(true, "Login Biometrik Nonaktif", null)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = KartiniColors.BrandGreen,
                            ),
                        )
                    },
                )
            }

            if (me?.shiftName != null) {
                SectionTitle("Shift Kerja")
                SectionCard {
                    ProfileRow(
                        Icons.Outlined.Schedule, "Shift Hari Ini",
                        if (me?.isOffToday == true) "Libur (OFF)"
                        else "${me?.shiftName} • ${(me?.shiftStart ?: "").take(5)} - ${(me?.shiftEnd ?: "").take(5)}",
                    )
                    if (me?.defaultShiftName != null && me?.isOffToday != true) {
                        HorizontalDivider(color = KartiniColors.DividerLight)
                        ProfileRow(Icons.Outlined.Schedule, "Shift Default", me?.defaultShiftName ?: "-")
                    }
                }
            }

            // ---------- Pengingat Absen (reminder) ----------
            if (me?.shiftName != null && me?.isOffToday != true) {
                SectionTitle("Pengingat Absen")
                SectionCard {
                    ActionRow(
                        icon = Icons.Outlined.Alarm,
                        title = "Pengingat Absen",
                        subtitle = if (reminderEnabled)
                            "Aktif — diingatkan ${reminderLead} menit sebelum shift" +
                                (if (remindCheckout) " & saat pulang" else "")
                        else "Nonaktif — aktifkan agar tidak lupa absen",
                        trailing = {
                            Switch(
                                checked = reminderEnabled,
                                onCheckedChange = { value ->
                                    reminderEnabled = value
                                    rp.enabled = value
                                    val startMin = AttendanceReminder.parseHm(me?.shiftStart)
                                    val endMin = AttendanceReminder.parseHm(me?.shiftEnd)
                                    rp.saveShift(me?.shiftStart?.take(5), me?.shiftEnd?.take(5))
                                    if (value) {
                                        AttendanceReminder.schedule(context, startMin, endMin)
                                        onNotify(true, "Pengingat Absen Aktif",
                                            "Anda akan diingatkan ${reminderLead} menit sebelum jam masuk" +
                                                (if (remindCheckout) " dan saat jam pulang." else "."))
                                    } else {
                                        AttendanceReminder.cancel(context)
                                        onNotify(true, "Pengingat Absen Nonaktif", null)
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = KartiniColors.BrandGreen,
                                ),
                            )
                        },
                    )
                    if (reminderEnabled) {
                        HorizontalDivider(color = KartiniColors.DividerLight)
                        ProfileRow(
                            Icons.Outlined.Alarm, "Waktu Pengingat",
                            "${reminderLead} menit sebelum masuk" +
                                (if (remindCheckout) " • saat pulang" else ""),
                        )
                        HorizontalDivider(color = KartiniColors.DividerLight)
                        ActionRow(
                            icon = Icons.Outlined.Schedule,
                            title = "Saat Pengingat",
                            subtitle = "Atur berapa menit sebelum jam masuk Anda diingatkan",
                            trailing = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    TextButton(onClick = {
                                        reminderLead = (reminderLead - 5).coerceIn(0, 60)
                                        rp.leadMinutes = reminderLead
                                        AttendanceReminder.schedule(
                                            context,
                                            AttendanceReminder.parseHm(me?.shiftStart),
                                            AttendanceReminder.parseHm(me?.shiftEnd),
                                        )
                                    }) { Text("−5", color = KartiniColors.BrandGreen, fontWeight = FontWeight.Bold) }
                                    Text("${reminderLead}m", fontWeight = FontWeight.Bold, color = KartiniColors.BrandGreen)
                                    TextButton(onClick = {
                                        reminderLead = (reminderLead + 5).coerceIn(0, 60)
                                        rp.leadMinutes = reminderLead
                                        AttendanceReminder.schedule(
                                            context,
                                            AttendanceReminder.parseHm(me?.shiftStart),
                                            AttendanceReminder.parseHm(me?.shiftEnd),
                                        )
                                    }) { Text("+5", color = KartiniColors.BrandGreen, fontWeight = FontWeight.Bold) }
                                }
                            },
                        )
                        HorizontalDivider(color = KartiniColors.DividerLight)
                        ActionRow(
                            icon = Icons.Outlined.Schedule,
                            title = "Ingatkan Absen Pulang",
                            subtitle = "Pengingat saat jam pulang kerja tiba",
                            trailing = {
                                Switch(
                                    checked = remindCheckout,
                                    onCheckedChange = { v ->
                                        remindCheckout = v
                                        rp.remindCheckout = v
                                        AttendanceReminder.schedule(
                                            context,
                                            AttendanceReminder.parseHm(me?.shiftStart),
                                            AttendanceReminder.parseHm(me?.shiftEnd),
                                        )
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = KartiniColors.BrandGreen,
                                    ),
                                )
                            },
                        )
                    }
                }
            }

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = KartiniColors.StatusBadBg,
                    contentColor = KartiniColors.StatusBadFg,
                ),
            ) {
                Icon(
                    painterResource(R.drawable.ic_logout), contentDescription = null,
                    tint = KartiniColors.StatusBadFg, modifier = Modifier.size(20.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text("Keluar", fontWeight = FontWeight.Bold)
            }
            Text(
                text = "Aplikasi Absensi Simaung Corporation • v${com.absensiku.app.BuildConfig.VERSION_NAME}",
                color = KartiniColors.OnSurfaceMuted, fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ---------------- Dialog Ganti Password ----------------

/**
 * Dialog ganti password karyawan (self-service).
 * Aturan password: 6-20 karakter, memuat huruf DAN angka, berbeda dari yang lama.
 */
@Composable
private fun ChangePasswordDialog(
    api: ApiClient,
    isDefault: Boolean,
    onDismiss: () -> Unit,
    onDone: (ok: Boolean, title: String, msg: String?) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var current by remember { mutableStateOf("") }
    var newPw by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var obscureCurrent by remember { mutableStateOf(true) }
    var obscureNew by remember { mutableStateOf(true) }
    var obscureConfirm by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun validate(): String? {
        if (current.isBlank()) return "Password saat ini wajib diisi."
        if (newPw.length < 6 || newPw.length > 20) return "Password baru harus 6-20 karakter."
        if (!Regex("[A-Za-z]").containsMatchIn(newPw) || !Regex("[0-9]").containsMatchIn(newPw)) {
            return "Password baru harus memuat huruf dan angka."
        }
        if (newPw == current) return "Password baru harus berbeda dari password lama."
        if (confirm != newPw) return "Konfirmasi password tidak cocok."
        return null
    }

    AlertDialog(
        onDismissRequest = { if (!loading) onDismiss() },
        shape = RoundedCornerShape(20.dp),
        containerColor = Color.White,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(38.dp).clip(RoundedCornerShape(11.dp))
                        .background(KartiniColors.BrandGreenSoft),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = KartiniColors.BrandGreen, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(10.dp))
                Text("Ganti Password", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = KartiniColors.OnSurface)
            }
        },
        text = {
            Column {
                if (isDefault) {
                    Text(
                        "Anda masih memakai password default. Demi keamanan, segera ganti password Anda.",
                        fontSize = 12.5.sp, color = KartiniColors.BrandOrange, fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(10.dp))
                }
                PasswordField(
                    value = current, onValueChange = { current = it; error = null },
                    label = "Password Saat Ini", obscure = obscureCurrent,
                    onToggle = { obscureCurrent = !obscureCurrent }, enabled = !loading,
                )
                Spacer(Modifier.height(10.dp))
                PasswordField(
                    value = newPw, onValueChange = { newPw = it; error = null },
                    label = "Password Baru", obscure = obscureNew,
                    onToggle = { obscureNew = !obscureNew }, enabled = !loading,
                )
                Spacer(Modifier.height(10.dp))
                PasswordField(
                    value = confirm, onValueChange = { confirm = it; error = null },
                    label = "Ulangi Password Baru", obscure = obscureConfirm,
                    onToggle = { obscureConfirm = !obscureConfirm }, enabled = !loading,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Minimal 6 karakter, kombinasi huruf dan angka.",
                    fontSize = 11.5.sp, color = KartiniColors.OnSurfaceMuted,
                )
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, fontSize = 12.5.sp, color = KartiniColors.StatusBadFg, fontWeight = FontWeight.SemiBold)
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !loading,
                onClick = {
                    val v = validate()
                    if (v != null) { error = v; return@Button }
                    loading = true
                    scope.launch {
                        try {
                            api.changePassword(current, newPw)
                            onDone(true, "Password Diperbarui", "Password Anda berhasil diganti. Gunakan password baru saat login berikutnya.")
                        } catch (e: kotlinx.coroutines.CancellationException) {

                            throw e

                        } catch (e: Exception) {
                            error = e.message ?: "Gagal mengganti password. Periksa koneksi lalu coba lagi."
                        } finally {
                            loading = false
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = KartiniColors.BrandGreen, contentColor = Color.White,
                ),
            ) {
                if (loading) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Menyimpan…")
                } else {
                    Text("Simpan", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = { if (!loading) onDismiss() }) {
                Text("Batal", color = KartiniColors.OnSurfaceMuted, fontWeight = FontWeight.SemiBold)
            }
        },
    )
}

@Composable
private fun PasswordField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    obscure: Boolean,
    onToggle: () -> Unit,
    enabled: Boolean,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        enabled = enabled,
        singleLine = true,
        visualTransformation = if (obscure) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            IconButton(onClick = onToggle) {
                Icon(
                    if (obscure) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                    contentDescription = null, tint = KartiniColors.OnSurfaceMuted,
                )
            }
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = KartiniColors.BrandGreen,
            unfocusedBorderColor = KartiniColors.Outline,
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White,
            cursorColor = KartiniColors.BrandGreen,
            focusedTextColor = KartiniColors.OnSurface,
            unfocusedTextColor = KartiniColors.OnSurface,
            focusedLabelColor = KartiniColors.BrandGreen,
            unfocusedLabelColor = KartiniColors.OnSurfaceMuted,
            disabledTextColor = KartiniColors.OnSurfaceMuted,
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth(),
    )
}

// ---------------- Komponen bantu ----------------

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        color = KartiniColors.OnSurfaceMuted,
        fontSize = 12.5.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 4.dp, top = 4.dp),
    )
}

@Composable
private fun SectionCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Box(modifier = Modifier.border(1.dp, KartiniColors.DividerLight, RoundedCornerShape(18.dp))) {
            Column { content() }
        }
    }
}

@Composable
private fun ProfileRow(
    icon: ImageVector,
    title: String,
    value: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBox(icon)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 12.sp, color = KartiniColors.OnSurfaceMuted)
            Spacer(Modifier.height(2.dp))
            Text(value, fontSize = 14.sp, color = KartiniColors.OnSurface, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun ActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBox(icon)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, color = KartiniColors.OnSurface, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, fontSize = 12.sp, color = KartiniColors.OnSurfaceMuted)
        }
        Spacer(Modifier.width(8.dp))
        trailing()
    }
}

@Composable
private fun IconBox(icon: ImageVector) {
    Box(
        modifier = Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(KartiniColors.BrandGreenSoft),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = KartiniColors.BrandGreen, modifier = Modifier.size(20.dp))
    }
}

// ---------------- Utilitas gambar ----------------

/** Decode base64 (tanpa prefix) menjadi Bitmap, atau null bila gagal/kosong. */
private fun decodeBase64(b64: String?): Bitmap? {
    if (b64.isNullOrBlank()) return null
    return runCatching {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }.getOrNull()
}

/** Muat gambar dari galeri, kompres (persegi-ish, maks 512px) + base64 JPEG. */
private fun loadCompressedAvatar(
    uri: Uri,
    resolver: android.content.ContentResolver,
): Pair<Bitmap, String>? {
    return try {
        val input = resolver.openInputStream(uri) ?: return null
        val original = BitmapFactory.decodeStream(input)
        input.close()
        if (original == null) return null
        val maxDim = 512
        val scale = minOf(1f, maxDim.toFloat() / maxOf(original.width, original.height))
        val bmp = if (scale < 1f) {
            Bitmap.createScaledBitmap(original, (original.width * scale).toInt(), (original.height * scale).toInt(), true)
        } else original
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        bmp to Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    } catch (_: Exception) {
        null
    }
}
