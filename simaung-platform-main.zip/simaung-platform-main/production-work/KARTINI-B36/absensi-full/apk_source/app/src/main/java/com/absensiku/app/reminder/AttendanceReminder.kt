package com.absensiku.app.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Pengingat Absen (reminder).
 *
 * Fitur ini dibangun dari kondisi NYATA di lapangan: karyawan kerap LUPA absen
 * masuk / absen pulang — bukan karena tidak hadir, tetapi karena sibuk. Karena
 * jam absen mengikuti SHIFT, pengingat dijadwalkan pada:
 *   - (jam mulai shift − lead) menit  → "Waktunya absen masuk".
 *   - (jam berakhir shift + offset)   → "Jangan lupa absen pulang" (opsional).
 *
 * Pengingat bersifat perangkat (tidak bergantung server) sehingga tetap berbunyi
 * walau aplikasi tidak dibuka. Di sisi aplikasi juga ada pengingat saat aplikasi
 * aktif (lihat ReminderBanner) sebagai lapisan kedua.
 */
object AttendanceReminder {

    const val EXTRA_KIND = "reminder_kind"
    const val KIND_CHECKIN = "CHECKIN"
    const val KIND_CHECKOUT = "CHECKOUT"

    private const val REQ_CHECKIN = 43101
    private const val REQ_CHECKOUT = 43102

    /**
     * Hitung epoch-millis pengingat berikutnya untuk hari ini.
     * @return pasangan (waktuMillis, kind) atau null bila waktu sudah terlewat.
     */
    fun nextTriggerMillis(
        nowMs: Long,
        shiftStartMinutes: Int?, // menit-dalam-hari (mis. 08:00 -> 480)
        shiftEndMinutes: Int?,
        prefs: ReminderPrefs,
    ): Pair<Long, String>? {
        if (!prefs.enabled) return null
        val checkinAt = shiftStartMinutes?.let { it - prefs.leadMinutes }
        val checkoutAt = if (prefs.remindCheckout) shiftEndMinutes?.let { it + prefs.checkoutLeadMinutes } else null
        val nowMin = minutesOfDay(nowMs)
        // Kandidat hari ini yang belum terlewat; pilih yang paling dekat.
        val candidates = listOfNotNull(
            checkinAt?.takeIf { it > nowMin + 1 }?.let { it to KIND_CHECKIN },
            checkoutAt?.takeIf { it > nowMin + 1 }?.let { it to KIND_CHECKOUT },
        )
        val pick = candidates.minByOrNull { it.first } ?: return null
        val addDays = if (pick.first < nowMin) 1 else 0
        val dayStart = startOfDay(nowMs)
        return (dayStart + (pick.first + addDays * 1440) * 60_000L) to pick.second
    }

    /** Jadwalkan pengingat berikutnya (aman dipanggil berulang). */
    fun schedule(context: Context, shiftStartMinutes: Int?, shiftEndMinutes: Int?) {
        val prefs = ReminderPrefs(context)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        cancel(context)
        if (!prefs.enabled) return
        val next = nextTriggerMillis(System.currentTimeMillis(), shiftStartMinutes, shiftEndMinutes, prefs) ?: return
        val (atMs, kind) = next
        val pi = pendingIntent(context, kind, atMs)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
            } else {
                alarm.set(AlarmManager.RTC_WAKEUP, atMs, pi)
            }
        } catch (_: Exception) {
            // Beberapa OEM membatasi alarm; biarkan pengingat aplikasi (banner) menutupi.
        }
    }

    fun cancel(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        for (kind in listOf(KIND_CHECKIN, KIND_CHECKOUT)) {
            val pi = PendingIntent.getBroadcast(
                context, reqCode(kind, 0L), Intent(context, AttendanceReminderReceiver::class.java),
                pendingFlags(),
            )
            runCatching { alarm.cancel(pi) }
        }
    }

    private fun pendingIntent(context: Context, kind: String, atMs: Long): PendingIntent {
        val intent = Intent(context, AttendanceReminderReceiver::class.java).apply {
            putExtra(EXTRA_KIND, kind)
        }
        return PendingIntent.getBroadcast(context, reqCode(kind, atMs), intent, pendingFlags())
    }

    private fun reqCode(kind: String, atMs: Long): Int {
        val base = if (kind == KIND_CHECKOUT) REQ_CHECKOUT else REQ_CHECKIN
        // Sertakan jam agar alarm lama tak bentrok dengan jadwal baru.
        return base + ((atMs / 60_000L) % 1000).toInt()
    }

    private fun pendingFlags(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

    private fun minutesOfDay(ms: Long): Int {
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = ms
        return cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
    }

    private fun startOfDay(ms: Long): Long {
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = ms
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    /** "HH:mm" -> menit-dalam-hari, atau null bila tak valid. */
    fun parseHm(hm: String?): Int? {
        if (hm.isNullOrBlank()) return null
        val parts = hm.take(5).split(":")
        if (parts.size != 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        if (h !in 0..23 || m !in 0..59) return null
        return h * 60 + m
    }
}
