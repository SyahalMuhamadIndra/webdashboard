package com.absensiku.app.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.absensiku.app.update.AppNotifications

/**
 * Penerima alarm Pengingat Absen. Menampilkan notifikasi sistem lalu
 * MENJADWALKAN ULANG pengingat untuk hari berikutnya (alarm satu-kali karena
 * keterbatasan Doze mode — dijadwalkan ulang setiap kali berbunyi).
 */
class AttendanceReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra(AttendanceReminder.EXTRA_KIND) ?: AttendanceReminder.KIND_CHECKIN
        val prefs = ReminderPrefs(context)

        if (prefs.enabled) {
            val notif = AppNotifications(context)
            val id = if (kind == AttendanceReminder.KIND_CHECKOUT) 4302 else 4301
            if (kind == AttendanceReminder.KIND_CHECKOUT) {
                notif.show(
                    id,
                    "Jangan Lupa Absen Pulang",
                    "Saatnya pulang kerja. Buka aplikasi untuk melakukan absen pulang (check-out) hari ini.",
                )
            } else {
                notif.show(
                    id,
                    "Waktunya Absen Masuk",
                    "Jangan lupa absen masuk sebelum shift dimulai. Buka aplikasi, lalu lakukan absen masuk (check-in).",
                )
            }
        }

        // Jadwalkan ulang berdasarkan shift tersimpan (bila ada).
        val startMin = AttendanceReminder.parseHm(prefs.lastStartHm())
        val endMin = AttendanceReminder.parseHm(prefs.lastEndHm())
        AttendanceReminder.schedule(context, startMin, endMin)
    }
}
