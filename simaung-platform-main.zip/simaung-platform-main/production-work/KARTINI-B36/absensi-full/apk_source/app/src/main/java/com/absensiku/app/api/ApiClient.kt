package com.absensiku.app.api

import android.content.Context
import android.provider.Settings
import com.absensiku.app.BuildConfig
import com.absensiku.app.ui.theme.BrandingPalette
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Dilempar saat sesi tidak lagi valid (akun dihapus/dinonaktifkan atau perangkat
 * dicabut). Berbeda dari error biasa — pemanggil harus logout, bukan sekadar
 * menampilkan pesan.
 */
class SessionExpiredException(message: String) : IllegalStateException(message)

/**
 * Error HTTP yang membawa KODE STATUS asli (mis. 404, 403, 500).
 *
 * Dipakai agar pemanggil bisa membedakan "endpoint tidak ada" (404) dari error
 * lain yang bermakna. Sebelumnya semua kegagalan non-sesi dilempar sebagai
 * IllegalStateException biasa tanpa kode, sehingga [getFirst] tidak punya cara
 * untuk tahu mana yang masih layak dicoba ke path cadangan.
 */
class HttpStatusException(val code: Int, message: String) : IllegalStateException(message)

/**
 * Klien HTTP untuk API absensi.
 *
 * Base URL diambil dari BuildConfig.API_BASE_URL (di-set lewat gradle property
 * "absensiApiUrl"). Kontrak endpoint mengikuti README project:
 *   POST /api/auth/login
 *   GET  /api/config
 *   GET  /api/attendance/today
 *   POST /api/attendance
 * dan endpoint tambahan untuk riwayat, izin, serta lembur.
 */
class ApiClient(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("absensi_prefs", Context.MODE_PRIVATE)

    /**
     * Dipanggil otomatis ketika server menolak sesi (HTTP 401 / perangkat dicabut).
     * Penyebab paling umum: akun karyawan DIHAPUS atau DINONAKTIFKAN saat perangkat
     * masih login. Aplikasi harus langsung logout — bukan terus menampilkan error
     * berulang. Pemilik (MainActivity) mengeset callback ini ke aksi logout.
     */
    var onSessionExpired: ((message: String) -> Unit)? = null

    /** Agar logout terpaksa hanya dipicu sekali walau ada beberapa request gagal. */
    @Volatile private var sessionFlagged = false

    private fun ensureSessionValid(code: Int, raw: String) {
        val msg = extractError(raw, code)
        // Bila belum ada token (mis. login salah password), ini BUKAN sesi kedaluwarsa.
        if ((code != 401 && code != 403) || token().isNullOrBlank()) {
            throw HttpStatusException(code, msg)
        }
        val lower = msg.lowercase()
        val isSessionIssue = code == 401 ||
            lower.contains("dicabut") || lower.contains("dihapus") ||
            lower.contains("dinonaktifkan")
        if (!isSessionIssue) throw HttpStatusException(code, msg)
        if (!sessionFlagged) {
            sessionFlagged = true
            onSessionExpired?.invoke(msg)
        }
        throw SessionExpiredException(msg)
    }

    private val client = OkHttpClient.Builder()
        // Timeout lebih pendek agar gagal cepat (fail fast) dan tidak "loading terus".
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        // Simpan koneksi lebih lama agar request berikutnya tak perlu handshake ulang.
        .connectionPool(okhttp3.ConnectionPool(5, 5, TimeUnit.MINUTES))
        .build()

    private val base: String = BuildConfig.API_BASE_URL.trimEnd('/')
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val formType = "application/x-www-form-urlencoded".toMediaType()

    /**
     * Mesin ANTRIAN ABSEN OFFLINE (B51).
     *
     * Dipakai layar Absen untuk: (a) menyimpan absensi saat jaringan buruk/GPS
     * lemah, (b) mengirim ulang antrian otomatis begitu ada koneksi. Dibuat lazy
     * agar tidak ada biaya saat aplikasi hanya dipakai online.
     */
    val queue: AttendanceQueueManager by lazy { AttendanceQueueManager(appContext, this) }

    /**
     * Pemanasan koneksi (fire-and-forget): membuka TCP + TLS ke server lebih awal
     * supaya request pertama (mis. login) tidak menanggung waktu handshake.
     * Aman dipanggil berkali-kali; kegagalan diabaikan.
     */
    fun warmUp() {
        runCatching {
            val req = Request.Builder().url("$base/health").get().build()
            client.newCall(req).enqueue(object : okhttp3.Callback {
                override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {}
                override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                    response.close()
                }
            })
        }
    }

    // ---------- session ----------

    fun isLoggedIn(): Boolean = !token().isNullOrBlank()

    fun token(): String? = prefs.getString("token", null)

    fun employeeName(): String = prefs.getString("employeeName", "Karyawan") ?: "Karyawan"

    fun employeeCode(): String = prefs.getString("employeeCode", "") ?: ""

    fun logout() {
        sessionFlagged = false
        // B54: JANGAN `clear()` — dulu logout menghapus SELURUH prefs, termasuk
        // (a) ANTRIAN ABSEN OFFLINE yang belum terkirim dan (b) SALINAN
        // pengaturan kantor. Akibatnya absensi yang tersimpan di HP bisa HILANG
        // dan aplikasi harus online lagi untuk tahu radius kantor. Sekarang hanya
        // data SESI yang dihapus; antrian & salinan kantor tetap dipertahankan.
        prefs.edit()
            .remove("token")
            .remove("employeeName")
            .remove("employeeCode")
            .remove("cached_employeeCode")
            .apply()
    }

    private fun saveSession(token: String, name: String, code: String) {
        sessionFlagged = false
        prefs.edit()
            .putString("token", token)
            .putString("employeeName", name)
            .putString("employeeCode", code)
            .apply()
    }

    private fun deviceId(): String =
        Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"

    private fun headers(builder: Request.Builder) {
        builder.addHeader("Accept", "application/json")
        builder.addHeader("X-Device-Id", deviceId())
        token()?.let { builder.addHeader("Authorization", "Bearer $it") }
    }

    // ---------- core req ----------

    private suspend fun post(path: String, body: JSONObject, auth: Boolean = true): JSONObject = withContext(Dispatchers.IO) {
        val b = Request.Builder().url("$base$path").post(body.toString().toRequestBody(jsonType))
        b.addHeader("Accept", "application/json")
        b.addHeader("X-Device-Id", deviceId())
        if (auth) token()?.let { b.addHeader("Authorization", "Bearer $it") }
        client.newCall(b.build()).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) ensureSessionValid(resp.code, raw)
            if (raw.isBlank()) JSONObject() else JSONObject(raw)
        }
    }

    private suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        val b = Request.Builder().url("$base$path").get()
        headers(b)
        client.newCall(b.build()).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) ensureSessionValid(resp.code, raw)
            if (raw.isBlank()) JSONObject() else JSONObject(raw)
        }
    }

    private suspend fun put(path: String, body: JSONObject, auth: Boolean = true): JSONObject = withContext(Dispatchers.IO) {
        val b = Request.Builder().url("$base$path").put(body.toString().toRequestBody(jsonType))
        b.addHeader("Accept", "application/json")
        b.addHeader("X-Device-Id", deviceId())
        if (auth) token()?.let { b.addHeader("Authorization", "Bearer $it") }
        client.newCall(b.build()).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) ensureSessionValid(resp.code, raw)
            if (raw.isBlank()) JSONObject() else JSONObject(raw)
        }
    }

    private suspend fun delete(path: String): JSONObject = withContext(Dispatchers.IO) {
        val b = Request.Builder().url("$base$path").delete()
        b.addHeader("Accept", "application/json")
        b.addHeader("X-Device-Id", deviceId())
        token()?.let { b.addHeader("Authorization", "Bearer $it") }
        client.newCall(b.build()).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) ensureSessionValid(resp.code, raw)
            if (raw.isBlank()) JSONObject() else JSONObject(raw)
        }
    }

    /**
     * Coba beberapa kandidat path GET, pakai yang pertama berhasil.
     *
     * PENTING (B57) — INI PENYEBAB NOTIF "Permintaan gagal (HTTP 404)":
     * versi lama menelan SEMUA error lalu melempar error dari kandidat TERAKHIR.
     * Karena path cadangan (/auth/me, /profile, /settings, /attendance/today-status)
     * memang TIDAK ada di server, error asli yang bermakna — terutama 401
     * "sesi berakhir" atau "perangkat dicabut" — selalu TERTIMPA oleh 404 dari
     * path cadangan. Akibatnya karyawan melihat notif menyesatkan yang tidak ada
     * hubungannya dengan masalah sebenarnya, dan tidak diarahkan untuk LOGIN ULANG.
     *
     * Aturan sekarang:
     *  - Sesi tidak valid (SessionExpiredException) -> langsung dilempar, TIDAK
     *    mencoba path lain. Pesan inilah yang benar untuk karyawan.
     *  - 404 / 405 -> endpoint kandidat memang tidak ada, wajar. Coba kandidat berikut.
     *  - Error lain (401/403/500/timeout) -> langsung dilempar, jangan ditelan.
     */
    private suspend fun getFirst(vararg paths: String): JSONObject {
        var last: Exception? = null
        for (p in paths) {
            try {
                return get(p)
            } catch (e: SessionExpiredException) {
                throw e
            } catch (e: HttpStatusException) {
                if (e.code == 404 || e.code == 405) { last = e; continue }
                throw e
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw (last ?: IllegalStateException("Tidak ada endpoint yang cocok"))
    }

    private fun extractError(raw: String, code: Int): String {
        return try {
            val o = JSONObject(raw)
            o.optString("message").ifBlank { o.optString("error") }.ifBlank { "HTTP $code" }
        } catch (_: Exception) { "Permintaan gagal (HTTP $code)" }
    }

    private fun unwrap(o: JSONObject): JSONObject = o.optJSONObject("data") ?: o
    private fun unwrapArr(o: JSONObject, key: String): JSONArray {
        o.optJSONArray(key)?.let { return it }
        o.optJSONObject("data")?.optJSONArray(key)?.let { return it }
        o.optJSONArray("data")?.let { return it }
        return JSONArray()
    }

    // ---------- endpoints ----------

    suspend fun login(employeeCode: String, password: String) {
        val body = JSONObject().apply {
            put("employeeCode", employeeCode)
            put("pin", password)
            put("deviceId", deviceId())
            // Kirim versi aplikasi agar panel developer bisa memantau versi terpasang.
            put("versionCode", BuildConfig.VERSION_CODE)
        }
        val o = unwrap(post("/auth/login", body, auth = false))
        val parsed = parseLogin(o)
        if (parsed.token.isBlank()) throw IllegalStateException("Token tidak diterima dari server")
        saveSession(parsed.token, parsed.employeeName, parsed.employeeCode.ifBlank { employeeCode })
        // B54: saat login kita PASTI online — momen paling tepat untuk menyimpan
        // salinan pengaturan kantor (lat/lng/radius). Dengan ini, karyawan yang
        // sudah pernah absen/login tidak perlu online lagi untuk membaca GPS &
        // menghitung zona, walau aplikasi diperbarui lalu dibuka di sinyal buruk.
        runCatching {
            prefs.edit().putString("cached_employeeCode", parsed.employeeCode.ifBlank { employeeCode }).apply()
            val cfg = getConfig()
            // Simpan juga lokasi absensi terakhir sebagai cadangan (bila ada).
            runCatching { getTodayAttendance() }
            // getConfig() sudah menyimpan salinan lewat saveCache(KEY_CONFIG, ...)
            if (cfg.officeLatitude == 0.0 && cfg.officeLongitude == 0.0) {
                // Konfigurasi kantor belum diatur admin — biarkan apa adanya.
            }
        }
    }

    suspend fun getMe(): MeResponse {
        val o = unwrap(getFirst("/me", "/auth/me", "/profile"))
        saveCache(KEY_ME, o)
        return parseMe(o)
    }

    suspend fun getConfig(): CompanyConfig {
        val o = unwrap(getFirst("/config", "/settings"))
        saveCache(KEY_CONFIG, o)
        // B67 — terapkan desain per lokasi kantor ke seluruh aplikasi.
        // getConfig() dipanggil SETELAH login (saat lokasi karyawan sudah
        // diketahui server), sehingga tema yang masuk memang milik lokasinya.
        applyThemeFromConfig(o)
        return parseConfig(o)
    }

    /** B67: ambil blok `theme` dari respons /api/config lalu pakai sebagai palet. */
    private fun applyThemeFromConfig(o: JSONObject) {
        runCatching {
            val t = parseConfig(o).theme
            if (t != null) {
                BrandingPalette.applyTheme(t)
                BrandingPalette.saveRaw(appContext, o.optJSONObject("theme"))
            }
        }
    }

    // ---------- CACHE data (B53) ----------
    // GPS itu SATELIT — tidak butuh internet. Tapi untuk tahu "apakah saya di
    // dalam radius kantor" aplikasi perlu pengaturan kantor (latitude/longitude/
    // radius). Bila jaringan buruk, pengaturan itu diambil dari salinan terakhir
    // yang tersimpan di HP, sehingga PEMBACAAN GPS TIDAK PERNAH terhalang
    // jaringan. Ini memperbaiki bug: dulu GPS baru dibaca SETELAH request
    // jaringan berhasil — jadi saat sinyal jelek, GPS tidak pernah dibaca sama
    // sekali padahal GPS-nya sendiri normal.

    private fun cacheKey(name: String) = "cache_$name"

    private fun saveCache(name: String, o: JSONObject) {
        // Simpan JSON mentah dari server; dibaca kembali dengan parser yang sama
        // sehingga tidak perlu penulis/pembaca khusus per model.
        runCatching { prefs.edit().putString(cacheKey(name), o.toString()).apply() }
    }

    private fun readCache(name: String): JSONObject? =
        prefs.getString(cacheKey(name), null)?.let { runCatching { JSONObject(it) }.getOrNull() }

    /** Pengaturan kantor terakhir yang tersimpan (untuk dipakai saat offline). */
    fun cachedConfig(): CompanyConfig? = readCache(KEY_CONFIG)?.let { parseConfig(it) }

    /**
     * B54: pengaturan kantor untuk perhitungan LOKAL (jarak & zona) saat jaringan
     * buruk. Urutan: salinan dari login/kunjungan terakhir → fallback bawaan.
     * Selalu mengembalikan nilai (tidak pernah null) supaya pembacaan GPS tidak
     * pernah terhalang oleh absennya pengaturan kantor.
     */
    fun effectiveOfficeConfig(): CompanyConfig = cachedConfig() ?: FallbackConfig.config()

    /** True bila pengaturan kantor berasal dari fallback bawaan (belum pernah online). */
    fun officeConfigIsFallback(): Boolean = cachedConfig() == null

    /** Profil terakhir yang tersimpan. */
    fun cachedMe(): MeResponse? = readCache(KEY_ME)?.let { parseMe(it) }

    /** Status absensi hari ini yang terakhir tersimpan. */
    fun cachedToday(): TodayAttendance? = readCache(KEY_TODAY)?.let { parseToday(it) }

    /**
     * Memuat data halaman Absen secara PARALEL (bukan berurutan) supaya jauh
     * lebih cepat. Sebelumnya getMe → getConfig → getToday dipanggil beruntun
     * (3x waktu tunggu jaringan). Kini ketiganya berjalan bersamaan.
     */
    suspend fun loadAbsenData(): Triple<MeResponse, CompanyConfig, TodayAttendance> = coroutineScope {
        val meDef = async { getMe() }
        val cfgDef = async { getConfig() }
        val todayDef = async { getTodayAttendance() }
        Triple(meDef.await(), cfgDef.await(), todayDef.await())
    }

    /**
     * Data halaman Absen yang TAHAN TERHADAP JARINGAN BURUK (B53).
     *
     * @param config pengaturan kantor (WAJIB) — dari server bila berhasil,
     *   atau dari SALINAN TERAKHIR di HP bila jaringan gagal. Inilah yang membuat
     *   pembacaan GPS tidak lagi terhalang jaringan.
     * @param me / today boleh null (memakai salinan terakhir bila ada).
     * @param offline true bila data berasal dari salinan lokal.
     */
    data class AbsenData(
        val me: MeResponse?,
        val config: CompanyConfig?,
        val today: TodayAttendance?,
        val offline: Boolean,
        val message: String?,
    )

    /**
     * Muat data halaman Absen TANPA membiarkan gangguan jaringan menghalangi GPS.
     *
     * Strategi: coba jaringan; bila gagal, pakai salinan terakhir (cache) untuk
     * ME/CONFIG/TODAY. Pengaturan kantor dari cache sudah cukup untuk menghitung
     * jarak & zona secara lokal, sehingga karyawan tetap bisa scan walau sinyal
     * buruk — dan absensinya masuk antrian offline.
     */
    suspend fun loadAbsenDataResilient(): AbsenData = coroutineScope {
        val meDef = async { runCatching { getMe() }.getOrNull() }
        val cfgDef = async { runCatching { getConfig() }.getOrNull() }
        val todayDef = async { runCatching { getTodayAttendance() }.getOrNull() }
        // Ambil hasil jaringan SEKALI saja, lalu jatuh ke salinan lokal bila null.
        val netMe = meDef.await()
        val netCfg = cfgDef.await()
        val netToday = todayDef.await()
        val me = netMe ?: cachedMe()
        val cfg = netCfg ?: cachedConfig() ?: FallbackConfig.config()
        val today = netToday ?: cachedToday()
        // Dianggap "offline" bila pengaturan kantor atau profil tak terambil dari
        // jaringan (itulah yang penting untuk menghitung zona).
        val offline = netCfg == null || netMe == null
        AbsenData(
            me = me,
            config = cfg,
            today = today,
            offline = offline,
            message = if (netCfg == null) "Jaringan buruk — memakai pengaturan kantor terakhir yang tersimpan." else null,
        )
    }

    suspend fun getTodayAttendance(): TodayAttendance {
        val o = unwrap(getFirst("/attendance/today", "/attendance/today-status"))
        saveCache(KEY_TODAY, o)
        return parseToday(o)
    }

    /**
     * Jadwal mingguan MILIK karyawan (shift per-hari yang diatur superadmin).
     * @param weekStart tanggal ISO Senin (YYYY-MM-DD); null = minggu berjalan.
     */
    suspend fun getSchedule(weekStart: String? = null): List<ScheduleDay> {
        val path = if (weekStart.isNullOrBlank()) "/schedule" else "/schedule?weekStart=$weekStart"
        return parseSchedule(unwrapArr(get(path), "days"))
    }

    suspend fun submitAttendance(
        type: String,
        latitude: Double,
        longitude: Double,
        accuracyMeters: Float,
        isMockLocation: Boolean,
        faceDetected: Boolean,
        livenessPassed: Boolean,
        clientTimestamp: Long,
        faceScore: Int? = null,
        faceVerifySource: String? = null,
    ): AttendanceResponse {
        val body = JSONObject().apply {
            put("type", type)
            put("latitude", latitude)
            put("longitude", longitude)
            put("accuracyMeters", accuracyMeters.toDouble())
            put("isMockLocation", isMockLocation)
            put("faceDetected", faceDetected)
            put("livenessPassed", livenessPassed)
            faceScore?.let { put("faceScore", it) }
            faceVerifySource?.let { put("faceVerifySource", it) }
            put("clientTimestamp", clientTimestamp)
            put("deviceId", deviceId())
        }
        return parseAttendance(unwrap(post("/attendance", body)))
    }

    /**
     * Kirim ANTRIAN ABSEN OFFLINE (batch) ke server — B51.
     *
     * Setiap item membawa `clientId` (ID lokal) agar hasil per-item bisa
     * dipetakan kembali oleh AttendanceQueueManager. Keterlambatan dihitung
     * server dari `clientTimestamp` (waktu scan ASLI), sehingga absensi yang
     * tertunda karena sinyal buruk tetap tercatat TEPAT WAKTU.
     *
     * Endpoint bersifat idempoten per item (memakai idempotency_key yang sama
     * seperti POST /attendance), jadi aman dipanggil berulang.
     */
    suspend fun syncAttendance(items: List<PendingAttendance>): JSONObject {
        val arr = JSONArray()
        items.forEach { p ->
            arr.put(JSONObject().apply {
                put("clientId", p.clientId)
                put("type", p.type)
                put("latitude", p.latitude)
                put("longitude", p.longitude)
                put("accuracyMeters", p.accuracyMeters)
                put("isMockLocation", p.isMockLocation)
                put("faceDetected", p.faceDetected)
                put("livenessPassed", p.livenessPassed)
                p.faceScore?.let { put("faceScore", it) }
                p.faceVerifySource?.let { put("faceVerifySource", it) }
                put("clientTimestamp", p.clientTimestamp)
                put("deviceId", deviceId())
            })
        }
        val body = JSONObject().apply {
            put("items", arr)
            put("deviceId", deviceId())
        }
        return unwrap(post("/attendance/sync", body))
    }

    suspend fun getHistory(limit: Int = 50): List<HistoryItem> {
        val o = getFirst("/attendance/history?limit=$limit", "/attendance/history", "/history?limit=$limit")
        return parseHistory(unwrapArr(o, "items").let {
            if (it.length() > 0) it else unwrapArr(o, "history")
        }.let {
            if (it.length() > 0) it else unwrapArr(o, "data")
        })
    }

    suspend fun listLeaves(): List<LeaveItem> {
        val o = getFirst("/leaves", "/leave", "/leaves/list")
        return parseLeaves(unwrapArr(o, "items").let {
            if (it.length() > 0) it else unwrapArr(o, "leaves")
        })
    }

    /**
     * Ajukan izin. Untuk kategori SAKIT, attachmentBase64 diisi foto surat sakit.
     * Server lama yang belum mengenal field lampiran tetap aman karena field hanya
     * dikirim bila ada.
     */
    suspend fun createLeave(
        category: String,
        startDate: String,
        endDate: String,
        reason: String?,
        attachmentBase64: String? = null,
    ) {
        val body = JSONObject().apply {
            put("category", category)
            put("startDate", startDate)
            put("endDate", endDate)
            reason?.takeIf { it.isNotBlank() }?.let { put("reason", it) }
            attachmentBase64?.let {
                put("attachmentBase64", it)
                put("attachmentType", "image/jpeg")
            }
        }
        post("/leaves", body)
    }

    suspend fun listOvertimes(): List<OvertimeItem> {
        val o = getFirst("/overtime", "/overtimes", "/overtime/list")
        return parseOvertimes(unwrapArr(o, "items").let {
            if (it.length() > 0) it else unwrapArr(o, "overtimes")
        })
    }

    suspend fun createOvertime(date: String, startTime: String, endTime: String, reason: String?): Int {
        val body = JSONObject().apply {
            put("date", date)
            put("startTime", startTime)
            put("endTime", endTime)
            reason?.takeIf { it.isNotBlank() }?.let { put("reason", it) }
        }
        val o = unwrap(post("/overtime", body))
        return o.intOrNull("durationMinutes") ?: 0
    }

    // ================= FACE (enrollment & verifikasi via server) =================

    /** Status enrollment wajah karyawan (dikelola server). */
    suspend fun getFaceEnrollment(): FaceEnrollmentStatus {
        val o = unwrap(getFirst("/face/enrollment"))
        return FaceEnrollmentStatus(
            enrolled = o.bool("enrolled"),
            sampleCount = o.intOrNull("sampleCount") ?: 0,
            hasBasePhoto = o.bool("hasBasePhoto"),
            outdated = o.bool("outdated"),
        )
    }

    /** Kirim sample wajah (multi-sample) + foto dasar untuk dikelola server. */
    suspend fun submitFaceEnrollment(samples: List<String>, basePhotoBase64: String?) {
        val arr = JSONArray()
        samples.forEach { arr.put(it) }
        val body = JSONObject().apply {
            put("samples", arr)
            basePhotoBase64?.let { put("basePhotoBase64", it) }
        }
        post("/face/enrollment", body)
    }

    /** Hapus data wajah (re-enroll). */
    suspend fun deleteFaceEnrollment() {
        val b = Request.Builder().url("$base/face/enrollment").delete()
        headers(b)
        withContext(Dispatchers.IO) {
            client.newCall(b.build()).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) ensureSessionValid(resp.code, raw)
            }
        }
    }

    /**
     * Ambil FOTO SAMPLE wajah yang tersimpan di server (base64 JPEG, tanpa prefix).
     * Dipakai untuk menampilkan thumbnail sample di pojok kiri atas layar kamera
     * saat karyawan hendak absen.
     * @return base64 JPEG, atau null bila server belum punya foto sample.
     */
    suspend fun getFacePhoto(): String? {
        return try {
            val o = unwrap(get("/face/photo"))
            if (!o.bool("hasPhoto")) null
            else o.str("basePhotoBase64")?.takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Simpan FOTO PROFIL karyawan ke server (base64 JPEG tanpa prefix).
     * Kirim [base64] = null/kosong untuk menghapus foto profil.
     */
    suspend fun updateMyPhoto(base64: String?) {
        val body = JSONObject().apply { put("photoBase64", base64 ?: "") }
        put("/me/photo", body)
    }

    /**
     * Ganti PASSWORD karyawan (self-service dari tab Profil).
     * Server memverifikasi [currentPassword] sebelum menyimpan [newPassword].
     * @throws IllegalStateException berisi pesan server bila gagal.
     */
    suspend fun changePassword(currentPassword: String, newPassword: String) {
        val body = JSONObject().apply {
            put("currentPassword", currentPassword)
            put("newPassword", newPassword)
        }
        put("/me/password", body)
    }

    /** Status password: apakah masih memakai password default (123456). */
    suspend fun getPasswordStatus(): PasswordStatus {
        val o = unwrap(getFirst("/me/password-status"))
        return PasswordStatus(
            isDefault = o.bool("isDefault"),
            passwordChanged = o.bool("passwordChanged"),
        )
    }

    /**
     * Verifikasi probe wajah DI SERVER (otoritatif).
     * @return true bila server memutuskan cocok (keputusan server yang berlaku).
     */
    suspend fun verifyFace(probe: String, threshold: Int = 40): FaceVerifyResult {
        val body = JSONObject().apply {
            put("probe", probe)
            put("threshold", threshold)
        }
        val o = unwrap(post("/face/verify", body))
        return FaceVerifyResult(
            match = o.bool("match"),
            score = o.intOrNull("score") ?: 0,
            nearMatch = o.bool("nearMatch"),
            effectiveThreshold = o.intOrNull("effectiveThreshold") ?: 0,
            sampleCount = o.intOrNull("sampleCount") ?: 0,
            message = o.str("message"),
        )
    }

    // ================= PEMBARUAN APLIKASI & NOTIFIKASI (v0.9.12) =================

    suspend fun checkAppUpdate(): ServerUpdateInfo? {
        val o = unwrap(
            getFirst(
                "/app/latest?versionCode=${BuildConfig.VERSION_CODE}&platform=android",
                "/app/latest"
            )
        )
        if (!o.bool("updateAvailable")) return null
        val url = o.str("apkUrl") ?: return null
        return ServerUpdateInfo(
            available = true,
            versionName = o.str("latestVersionName") ?: "terbaru",
            versionCode = o.intOrNull("latestVersionCode") ?: 0,
            apkUrl = url,
            mandatory = o.bool("mandatory"),
            notes = o.str("notes"),
        )
    }

    suspend fun getNotifications(): List<ServerNotification> {
        val o = getFirst("/notifications")
        return parseNotifications(unwrapArr(o, "items").let {
            if (it.length() > 0) it else unwrapArr(o, "notifications")
        })
    }

    /** Tandai satu notifikasi sudah dibaca/dihapus agar tidak muncul lagi. */
    suspend fun markNotificationRead(id: String) {
        runCatching { post("/notifications/$id/read", JSONObject()) }
    }

    suspend fun registerDeviceToken(token: String) {
        val body = JSONObject().apply {
            put("token", token)
            put("platform", "android")
        }
        runCatching { post("/device-token", body) }
    }

    // ================= MODUL OPERASIONAL (B11) =================
    // Fitur per-jabatan karyawan (multi-role / jabatan rangkap).

    // ---------- Produk (gudang & katalog POS) ----------

    suspend fun listProducts(): List<OpsProduct> {
        val o = getFirst("/ops/products")
        return parseOpsProducts(unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "products") })
    }

    // ---------- Manajemen katalog barang (admin/kepala gudang) ----------

    /** Daftar seluruh barang untuk kelola katalog (Kepala Gudang). */
    suspend fun listAdminProducts(): List<OpsProduct> {
        val o = get("/ops/catalog")
        return parseOpsProducts(unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "products") })
    }

    /** Tambah barang baru ke katalog. Mengembalikan id barang. */
    suspend fun createProduct(fields: ProductInput): String {
        val o = unwrap(post("/ops/catalog", productBody(fields)))
        return o.optString("id")
    }

    /** Ubah data barang (hanya field yang diisi yang dikirim). */
    suspend fun updateProduct(id: String, fields: ProductInput) {
        put("/ops/catalog/$id", productBody(fields, partial = true))
    }

    /** Hapus barang dari katalog. */
    suspend fun deleteProduct(id: String) {
        delete("/ops/catalog/$id")
    }

    private fun productBody(f: ProductInput, partial: Boolean = false): JSONObject {
        return JSONObject().apply {
            f.sku?.let { put("sku", it) }
            f.barcode?.let { put("barcode", it) }
            f.name?.let { put("name", it) }
            f.category?.let { put("category", it) }
            f.unit?.let { put("unit", it) }
            f.price?.let { put("price", it) }
            f.cost?.let { put("cost", it) }
            f.stock?.let { put("stock", it) }
            f.minStock?.let { put("minStock", it) }
            f.active?.let { put("active", it) }
            if (!partial && f.name == null) put("name", "")
        }
    }

    /** Cari produk via barcode/SKU (scan). Mengembalikan null bila tidak ada. */
    suspend fun lookupProduct(code: String): OpsProduct? {
        return try {
            val o = get("/ops/products/lookup?code=${java.net.URLEncoder.encode(code, "UTF-8")}")
            o.optJSONObject("product")?.let { parseOpsProduct(it) }
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { null }
    }

    // ---------- Varian produk ----------

    suspend fun listVariants(productId: String): List<ProductVariant> {
        val o = get("/ops/products/$productId/variants")
        return parseVariants(unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "variants") })
    }

    suspend fun createVariant(productId: String, name: String, price: Double, stock: Int, sku: String?): String {
        val body = JSONObject().apply {
            put("name", name); put("price", price); put("stock", stock)
            sku?.takeIf { it.isNotBlank() }?.let { put("sku", it) }
        }
        return unwrap(post("/ops/products/$productId/variants", body)).optString("id")
    }

    suspend fun deleteVariant(id: String) { delete("/ops/variants/$id") }

    // ---------- Pelanggan / member ----------

    suspend fun listCustomers(): List<PosCustomer> {
        val o = get("/ops/customers")
        return parseCustomers(unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "customers") })
    }

    suspend fun createCustomer(name: String, phone: String?, tier: String, discountPercent: Double): String {
        val body = JSONObject().apply {
            put("name", name)
            phone?.takeIf { it.isNotBlank() }?.let { put("phone", it) }
            put("tier", tier); put("discountPercent", discountPercent)
        }
        return unwrap(post("/ops/customers", body)).optString("id")
    }

    // ---------- Pengaturan POS ----------

    suspend fun getPosSettings(): PosSettings {
        val o = get("/ops/pos/settings")
        return parsePosSettings(o.optJSONObject("settings") ?: JSONObject())
    }

    // ---------- Tahan pesanan (hold) ----------

    suspend fun listHolds(): List<PosHold> {
        val o = get("/ops/pos/holds")
        return parseHolds(unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "holds") })
    }

    suspend fun createHold(label: String, payload: JSONObject): String {
        val body = JSONObject().apply { put("label", label); put("payload", payload) }
        return unwrap(post("/ops/pos/holds", body)).optString("id")
    }

    suspend fun deleteHold(id: String) { delete("/ops/pos/holds/$id") }


    // ---------- Stock Opname (Pramuniaga / Kepala Gudang) ----------

    suspend fun listOpnames(mine: Boolean): List<OpnameSession> {
        val o = get("/ops/opnames${if (mine) "?mine=1" else ""}")
        return parseOpnames(unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "opnames") })
    }

    /** Mulai opname: kirim daftar hitungan. Server mengambil stok sistem & selisih. */
    suspend fun submitOpname(area: String?, note: String?, items: List<Triple<String, String, Int>>): JSONObject {
        val out = items.map { (id, name, counted) ->
            OpnameDraftInput(productId = id, productName = name, countedStock = counted, useCounted = true)
        }
        return submitOpname(area, note, out, kindFull = false)
    }

    /**
     * Mulai opname dengan mutasi lengkap (ala Allstock):
     * barang masuk / keluar / rusak per produk. Server menghitung stok fisik &
     * menerapkan mutasi ke stok master secara realtime.
     */
    suspend fun submitOpname(
        area: String?,
        note: String?,
        items: List<OpnameDraftInput>,
        kindFull: Boolean = false,
    ): JSONObject {
        val arr = JSONArray()
        items.forEach { it ->
            arr.put(JSONObject().apply {
                put("productId", it.productId)
                it.productName.takeIf { n -> n.isNotBlank() }?.let { n -> put("productName", n) }
                put("qtyIn", it.qtyIn)
                put("qtyOut", it.qtyOut)
                put("qtyReject", it.qtyReject)
                if (it.useCounted) put("countedStock", it.countedStock)
                it.note.takeIf { n -> n.isNotBlank() }?.let { n -> put("note", n) }
            })
        }
        val body = JSONObject().apply {
            area?.takeIf { it.isNotBlank() }?.let { put("area", it) }
            note?.takeIf { it.isNotBlank() }?.let { put("note", it) }
            if (kindFull) put("kind", "FULL")
            put("items", arr)
        }
        return unwrap(post("/ops/opnames", body))
    }

    /** Rekap mutasi harian (flat) ala Allstock: masuk / keluar / rusak. */
    suspend fun getOpnameLog(date: String? = null, mine: Boolean = false): OpnameLog {
        val qs = buildString {
            date?.takeIf { it.isNotBlank() }?.let { append("?date=").append(it) }
            if (mine) append(if (contains("?")) "&mine=1" else "?mine=1")
        }
        val o = get("/ops/opnames/log$qs")
        val items = parseOpnameLogRows(
            unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "rows") }
        )
        val t = o.optJSONObject("totals")
        return OpnameLog(
            date = o.str("date") ?: (date ?: ""),
            items = items,
            totalIn = t?.intOrNull("in") ?: 0,
            totalOut = t?.intOrNull("out") ?: 0,
            totalReject = t?.intOrNull("reject") ?: 0,
        )
    }

    /** Detail sesi opname + item (untuk crosscek). */
    suspend fun getOpnameDetail(id: String): Pair<OpnameSession, List<OpnameItem>> {
        val o = unwrap(get("/ops/opnames/$id"))
        val session = parseOpnameSession(o.optJSONObject("opname") ?: o)
        val items = parseOpnameItems(unwrapArr(o, "items"))
        return session to items
    }

    /** Kepala Gudang: crosscek hasil opname pramuniaga (APPROVED / REJECTED). */
    suspend fun reviewOpname(id: String, decision: String, note: String?) {
        val body = JSONObject().apply {
            put("decision", decision)
            note?.takeIf { it.isNotBlank() }?.let { put("note", it) }
        }
        post("/ops/opnames/$id/review", body)
    }

    /** Hapus sesi opname + kembalikan (rollback) mutasi stok master. */
    suspend fun deleteOpname(id: String) {
        delete("/ops/opnames/$id")
    }

    // ---------- Driver (perjalanan & surat jalan) ----------

    suspend fun listTrips(mine: Boolean): List<TripItem> {
        val o = get("/ops/trips${if (mine) "?mine=1" else ""}")
        return parseTrips(unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "trips") })
    }

    suspend fun createTrip(destination: String, vehicle: String?, note: String?): JSONObject {
        val body = JSONObject().apply {
            put("destination", destination)
            vehicle?.takeIf { it.isNotBlank() }?.let { put("vehicle", it) }
            note?.takeIf { it.isNotBlank() }?.let { put("note", it) }
        }
        return unwrap(post("/ops/trips", body))
    }

    suspend fun updateTripStatus(tripId: String, status: String, note: String?, lat: Double?, lng: Double?) {
        val body = JSONObject().apply {
            put("status", status)
            note?.takeIf { it.isNotBlank() }?.let { put("note", it) }
            lat?.let { put("lat", it) }
            lng?.let { put("lng", it) }
        }
        post("/ops/trips/$tripId/event", body)
    }

    suspend fun sendTripLocation(tripId: String, lat: Double, lng: Double) {
        val body = JSONObject().apply { put("lat", lat); put("lng", lng) }
        runCatching { post("/ops/trips/$tripId/location", body) }
    }

    suspend fun listDeliveryNotes(tripId: String): List<DeliveryNote> {
        val o = get("/ops/trips/$tripId/notes")
        return parseDeliveryNotes(unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "notes") })
    }

    suspend fun getDeliveryNote(id: String): Pair<DeliveryNote, List<DeliveryItem>> {
        val o = unwrap(get("/ops/delivery-notes/$id"))
        val note = o.optJSONObject("note")?.let { parseDeliveryNote(it) }
            ?: DeliveryNote(id, null, null, null, null, "ISSUED", 0, createdAt = null)
        val items = parseDeliveryItems(unwrapArr(o, "items"))
        return note to items
    }

    suspend fun createDeliveryNote(
        tripId: String,
        recipientName: String?,
        address: String?,
        note: String?,
        items: List<DeliveryItem>,
    ): JSONObject {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("productName", it.productName)
                it.productId?.let { id -> put("productId", id) }
                it.sku?.let { s -> put("sku", s) }
                put("qty", it.qty)
                it.unit?.let { u -> put("unit", u) }
            })
        }
        val body = JSONObject().apply {
            recipientName?.takeIf { it.isNotBlank() }?.let { put("recipientName", it) }
            address?.takeIf { it.isNotBlank() }?.let { put("address", it) }
            note?.takeIf { it.isNotBlank() }?.let { put("note", it) }
            put("items", arr)
        }
        return unwrap(post("/ops/trips/$tripId/notes", body))
    }

    suspend fun markDeliveryDelivered(id: String) {
        post("/ops/delivery-notes/$id/deliver", JSONObject())
    }

    // ---------- Kasir / POS ----------

    suspend fun getPosSession(): PosSession? {
        val o = unwrap(get("/ops/pos/session"))
        val s = o.optJSONObject("session") ?: return null
        return parsePosSession(s)
    }

    suspend fun openPosSession(openingCash: Double): JSONObject {
        val body = JSONObject().apply { put("openingCash", openingCash) }
        return unwrap(post("/ops/pos/session/open", body))
    }

    suspend fun closePosSession(closingCash: Double, note: String?): JSONObject {
        val body = JSONObject().apply {
            put("closingCash", closingCash)
            note?.takeIf { it.isNotBlank() }?.let { put("note", it) }
        }
        return unwrap(post("/ops/pos/session/close", body))
    }

    suspend fun listPosSales(mine: Boolean = true): List<PosSale> {
        val o = get("/ops/pos/sales${if (mine) "?mine=1" else ""}")
        return parsePosSales(unwrapArr(o, "items").let { if (it.length() > 0) it else unwrapArr(o, "sales") })
    }

    suspend fun posSummary(): PosSummary = parsePosSummary(unwrap(get("/ops/pos/summary")))

    /** Proses transaksi: item (productId, name, price, qty), diskon, bayar, metode. */
    suspend fun checkoutPos(
        items: List<PosSaleItem>,
        discount: Double,
        paid: Double,
        paymentMethod: String,
        tax: Double = 0.0,
        memberDiscount: Double = 0.0,
        customerId: String? = null,
        note: String? = null,
        cashReceived: Double? = null,
        splitPayments: List<Pair<String, Double>> = emptyList(),
    ): JSONObject {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                it.productId?.let { id -> put("productId", id) }
                it.variantId?.let { id -> put("variantId", id) }
                put("productName", it.productName)
                put("price", it.price)
                put("qty", it.qty)
            })
        }
        val body = JSONObject().apply {
            put("items", arr)
            put("discount", discount)
            put("tax", tax)
            put("memberDiscount", memberDiscount)
            put("paid", paid)
            put("paymentMethod", paymentMethod)
            customerId?.takeIf { it.isNotBlank() }?.let { put("customerId", it) }
            note?.takeIf { it.isNotBlank() }?.let { put("note", it) }
            cashReceived?.let { put("cashReceived", it) }
            if (splitPayments.isNotEmpty()) {
                val sp = JSONArray()
                splitPayments.forEach { (m, amt) -> sp.put(JSONObject().apply { put("method", m); put("amount", amt) }) }
                put("splitPayments", sp)
            }
        }
        return unwrap(post("/ops/pos/sales", body))
    }

    companion object {
        private const val KEY_ME = "me"
        private const val KEY_CONFIG = "config"
        private const val KEY_TODAY = "today"
    }
}
