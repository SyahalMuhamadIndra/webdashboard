package com.absensiku.app.face.engine.util

import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * =====================================================================
 *  FACE TEMPLATE MATCHER (v5) — skor NCC + penalti penyimpangan besar
 * =====================================================================
 *
 * Padanan Kotlin 1:1 dari `templateScore` / `robustMatchTemplate` pada
 * `server/src/faceMatcher.js`. Menghitung kemiripan dua template v5
 * (grid keabuan) memakai *Normalized Cross-Correlation* (0..100) dengan
 * penalti tambahan untuk banyaknya bin yang menyimpang jauh.
 *
 * Ambang & rumus disamakan dengan server agar keputusan lokal == server.
 */
object FaceTemplateMatcher {

    /** Ambang skor agar dianggap cocok (%). */
    const val TPL_MATCH = 72.0

    /** Ambang skor untuk "hampir mirip". */
    const val TPL_NEAR = 62.0

    /** Selisih per-bin yang dianggap "menyimpang jauh". */
    private const val LARGE_DIFF = 46

    /** Bobot penalti penyimpangan (per fraksi). */
    private const val LARGE_PENALTY = 140.0

    /** True bila signature adalah template v5. */
    fun isTemplate(sig: String?): Boolean = FaceTemplateExtractor.isTemplate(sig)

    /**
     * Skor NCC 0..100 antara dua template v5. Mengembalikan -1.0 bila invalid.
     */
    fun matchScore(sigA: String, sigB: String): Double {
        val a = decode(sigA) ?: return -1.0
        val b = decode(sigB) ?: return -1.0
        if (a.size != b.size) return -1.0
        var dot = 0.0
        var na = 0.0
        var nb = 0.0
        var large = 0
        for (i in a.indices) {
            val x = a[i].toDouble()
            val y = b[i].toDouble()
            dot += x * y
            na += x * x
            nb += y * y
            if (abs(x - y) > LARGE_DIFF) large++
        }
        if (na <= 0.0 || nb <= 0.0) return -1.0
        var score = (dot / (sqrt(na) * sqrt(nb))) * 100.0
        score -= (large.toDouble() / a.size) * LARGE_PENALTY
        return max(0.0, min(100.0, score))
    }

    private fun decode(sig: String?): IntArray? {
        if (sig.isNullOrBlank()) return null
        return try {
            val o = JSONObject(sig)
            if (o.optInt("v", -1) != 5) return null
            val arr = o.optJSONArray("t") ?: return null
            if (arr.length() != FaceTemplateExtractor.LENGTH) return null
            val out = IntArray(arr.length())
            for (i in 0 until arr.length()) {
                out[i] = arr.optInt(i, 0).coerceIn(0, 255)
            }
            out
        } catch (_: Exception) {
            null
        }
    }
}
