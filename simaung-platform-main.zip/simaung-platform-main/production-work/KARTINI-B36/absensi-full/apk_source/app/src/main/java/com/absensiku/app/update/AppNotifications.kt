package com.absensiku.app.update

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.absensiku.app.MainActivity
import com.absensiku.app.R

/**
 * Penampil notifikasi sistem (v0.9.12) — dipakai untuk notifikasi yang dikirim
 * server lewat endpoint /notifications (jalur internal bila FCM belum ada),
 * termasuk pemberitahuan "update aplikasi tersedia".
 */
class AppNotifications(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "absensiku_updates"
        private const val CHANNEL_NAME = "Pembaruan & Informasi"
        private const val PREFS = "app_notifications"
        private const val KEY_SHOWN_IDS = "shown_notif_ids"
        private const val MAX_KEEP = 200
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Notifikasi pembaruan aplikasi dan informasi dari server"
                    enableVibration(true)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    /** Kumpulan id notifikasi yang sudah pernah ditampilkan (anti-muncul-ulang). */
    private fun shownIds(): MutableSet<String> =
        (prefs.getStringSet(KEY_SHOWN_IDS, emptySet()) ?: emptySet()).toMutableSet()

    fun isShown(id: String): Boolean = shownIds().contains(id)

    fun markShown(id: String) {
        val set = shownIds()
        set.add(id)
        // Batasi ukuran agar prefs tidak tumbuh tanpa batas.
        val trimmed = if (set.size > MAX_KEEP) set.toList().takeLast(MAX_KEEP).toSet() else set
        prefs.edit().putStringSet(KEY_SHOWN_IDS, trimmed).apply()
    }

    /** Tandai semua id sebagai sudah ditampilkan (mis. saat login pertama). */
    fun markAllShown(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val set = shownIds()
        set.addAll(ids)
        val trimmed = if (set.size > MAX_KEEP) set.toList().takeLast(MAX_KEEP).toSet() else set
        prefs.edit().putStringSet(KEY_SHOWN_IDS, trimmed).apply()
    }

    /** Buang satu notifikasi yang sudah ditutup/dihapus karyawan. */
    fun forget(id: String) {
        val set = shownIds()
        set.remove(id)
        prefs.edit().putStringSet(KEY_SHOWN_IDS, set).apply()
    }

    fun show(id: Int, title: String, body: String?): Boolean {
        ensureChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }
        val intent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE else PendingIntent.FLAG_UPDATE_CURRENT
        val pi = PendingIntent.getActivity(context, id, intent, flags)

        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_logo_kartini)
            .setContentTitle(title)
            .setContentText(body ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body ?: ""))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(id, notif)
            true
        } catch (_: SecurityException) {
            false
        }
    }
}
