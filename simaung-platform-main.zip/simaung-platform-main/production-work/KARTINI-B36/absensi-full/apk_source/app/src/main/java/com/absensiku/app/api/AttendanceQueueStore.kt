package com.absensiku.app.api

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Penyimpanan ANTRIAN ABSEN OFFLINE (di perangkat).
 *
 * Latar belakang (keluhan nyata karyawan):
 *   Absensi sangat bergantung pada internet + GPS. Saat sinyal jelek di lokasi
 *   kerja, karyawan tidak bisa absen dan baru berhasil ketika sinyal membaik —
 *   akibatnya tercatat TERLAMBAT padahal ia sudah tiba tepat waktu.
 *
 * Karena modul ini TIDAK memakai Room / WorkManager (agar APK tetap kecil &
 * tidak menambah dependensi), antrian disimpan sebagai JSON di SharedPreferences
 * (\"absensi_prefs\"). Ukurannya sangat kecil (maksimum puluhan item) sehingga
 * SharedPreferences sudah memadai.
 *
 * Yang disimpan adalah WAKTU SCAN ASLI (`clientTimestamp`) — bukan waktu kirim.
 * Server menghitung keterlambatan dari waktu scan, jadi absensi yang tertunda
 * tetap tercatat TEPAT WAKTU.
 */
class AttendanceQueueStore(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Semua item antrian (urut waktu scan). */
    fun all(): List<PendingAttendance> {
        val raw = prefs.getString(KEY_QUEUE, null) ?: return emptyList()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        val out = ArrayList<PendingAttendance>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out += fromJson(o)
        }
        return out.sortedBy { it.clientTimestamp }
    }

    fun size(): Int = all().size

    /** Tambahkan satu item; kembalikan true bila berhasil disimpan. */
    fun add(item: PendingAttendance): Boolean {
        val list = all().toMutableList()
        // Batasi agar antrian tidak tumbuh tanpa batas (jaga ukuran prefs).
        if (list.size >= MAX_ITEMS) list.removeAt(0)
        list += item
        return persist(list)
    }

    /** Ganti seluruh isi antrian (dipakai setelah sinkronisasi). */
    fun replace(items: List<PendingAttendance>): Boolean {
        val capped = if (items.size > MAX_ITEMS) items.takeLast(MAX_ITEMS) else items
        return persist(capped.sortedBy { it.clientTimestamp })
    }

    fun remove(clientId: String): Boolean = persist(all().filterNot { it.clientId == clientId })

    fun clear() = prefs.edit().remove(KEY_QUEUE).apply()

    fun pendingCount(): Int = size()

    // ---------- internal ----------

    private fun persist(items: List<PendingAttendance>): Boolean {
        val arr = JSONArray()
        items.forEach { arr.put(toJson(it)) }
        return prefs.edit().putString(KEY_QUEUE, arr.toString()).commit()
    }

    private fun toJson(i: PendingAttendance): JSONObject = JSONObject().apply {
        put("clientId", i.clientId)
        put("type", i.type)
        put("latitude", i.latitude)
        put("longitude", i.longitude)
        put("accuracyMeters", i.accuracyMeters)
        put("isMockLocation", i.isMockLocation)
        put("faceDetected", i.faceDetected)
        put("livenessPassed", i.livenessPassed)
        i.faceScore?.let { put("faceScore", it) }
        i.faceVerifySource?.let { put("faceVerifySource", it) }
        put("clientTimestamp", i.clientTimestamp)
        put("queuedAt", i.queuedAt)
        put("attempts", i.attempts)
        i.note?.let { put("note", it) }
    }

    private fun fromJson(o: JSONObject): PendingAttendance = PendingAttendance(
        clientId = o.optString("clientId", ""),
        type = o.optString("type", "CHECK_IN"),
        latitude = o.optDouble("latitude", 0.0),
        longitude = o.optDouble("longitude", 0.0),
        accuracyMeters = o.optDouble("accuracyMeters", 0.0),
        isMockLocation = o.optBoolean("isMockLocation", false),
        faceDetected = o.optBoolean("faceDetected", true),
        livenessPassed = o.optBoolean("livenessPassed", true),
        faceScore = if (o.isNull("faceScore")) null else o.optInt("faceScore"),
        faceVerifySource = if (o.isNull("faceVerifySource")) null else o.optString("faceVerifySource"),
        clientTimestamp = o.optLong("clientTimestamp", System.currentTimeMillis()),
        queuedAt = o.optLong("queuedAt", System.currentTimeMillis()),
        attempts = o.optInt("attempts", 0),
        note = if (o.isNull("note")) null else o.optString("note"),
    )

    companion object {
        /** Prefs yang sama dipakai ApiClient (token, dsb). */
        const val PREFS_NAME = "absensi_prefs"
        const val KEY_QUEUE = "attendance_queue_v1"
        /** Batas aman jumlah item antrian. */
        const val MAX_ITEMS = 60
    }
}
