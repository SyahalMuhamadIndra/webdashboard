package com.absensiku.app.update

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.absensiku.app.ui.theme.KartiniColors

/**
 * Popup pembaruan aplikasi di dalam aplikasi (v0.9.12).
 *
 * - Tombol "Perbarui Sekarang" mengunduh APK lalu memasangnya otomatis.
 * - Tombol "Lewati" hanya muncul bila pembaruan TIDAK wajib.
 * - Bila wajib (mandatory), dialog tidak dapat ditutup.
 */
@Composable
fun UpdateDialog(
    versionName: String,
    mandatory: Boolean,
    notes: String?,
    downloading: Boolean,
    progressText: String?,
    onUpdate: () -> Unit,
    onSkip: () -> Unit,
) {
    Dialog(
        onDismissRequest = { if (!mandatory) onSkip() },
        properties = DialogProperties(
            dismissOnBackPress = !mandatory,
            dismissOnClickOutside = !mandatory,
            usePlatformDefaultWidth = false,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(listOf(KartiniColors.BrandGreenDeep, KartiniColors.BrandGreen))
                    )
                    .padding(horizontal = 22.dp, vertical = 22.dp),
            ) {
                Text(
                    "Pembaruan Aplikasi",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 19.sp,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Versi terbaru $versionName tersedia",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 13.sp,
                )
            }

            Column(modifier = Modifier.padding(22.dp)) {
                if (!notes.isNullOrBlank()) {
                    Text("Apa yang baru:", color = KartiniColors.OnSurface, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(notes, color = KartiniColors.OnSurfaceMuted, fontSize = 13.sp, lineHeight = 19.sp)
                    Spacer(Modifier.height(16.dp))
                }

                if (mandatory) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(KartiniColors.BrandOrangeSoft)
                            .padding(12.dp),
                    ) {
                        Text(
                            "Pembaruan ini WAJIB. Anda harus memperbarui aplikasi untuk melanjutkan.",
                            color = KartiniColors.BrandOrangeDeep,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }

                if (downloading) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = KartiniColors.BrandGreen,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            progressText ?: "Mengunduh pembaruan…",
                            color = KartiniColors.OnSurfaceMuted,
                            fontSize = 13.sp,
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }

                Button(
                    enabled = !downloading,
                    onClick = onUpdate,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = KartiniColors.BrandGreen,
                        contentColor = Color.White,
                        disabledContainerColor = KartiniColors.BrandGreen.copy(alpha = 0.5f),
                        disabledContentColor = Color.White,
                    ),
                ) {
                    Text(
                        if (downloading) "Memproses…" else "Perbarui Sekarang",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.5.sp,
                    )
                }

                if (!mandatory) {
                    Spacer(Modifier.height(4.dp))
                    TextButton(enabled = !downloading, onClick = onSkip, modifier = Modifier.fillMaxWidth()) {
                        Text("Lewati", color = KartiniColors.OnSurfaceMuted, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}
