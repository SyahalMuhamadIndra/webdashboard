package com.absensiku.app.api

import android.content.Context
import org.json.JSONObject
import java.util.UUID

/**
 * Mesin ANTRIAN ABSEN OFFLINE.
 *
 * Alur kerja:
 *  1. Karyawan menekan Check-In/Check-Out, scan wajah lolos, tapi jaringan buruk
 *     atau GPS belum presisi  →  [capture] menyimpan absensi ke perangkat
 *     (dengan WAKTU SCAN ASLI). UI langsung menampilkan "Tersimpan".
 *  2. Kapan pun ada jaringan (otomatis saat aplikasi dibuka, saat kembali ke
 *     depan, saat koneksi pulih, atau saat karyawan menekan tombol)  →
 *     [syncNow] mengirim seluruh antrian ke POST /api/attendance/sync.
 *  3. Server menghitung keterlambatan dari WAKTU SCAN (clientTimestamp),
 *     jadi absensi yang tertunda tetap TEPAT WAKTU — tidak jadi telat.
 *
 * Idempoten: item yang sudah tercatat dibalas `duplicate: true` lalu dibuang
 * dari antrian, sehingga aman dikirim berulang kali.
 */
class AttendanceQueueManager(
    private val context: Context,
    private val api: ApiClient,
) {
    private val store = AttendanceQueueStore(context)

    /** Berapa absensi yang masih menunggu terkirim. */
    fun pendingCount(): Int = store.pendingCount()

    /** Semua item yang masih menunggu (untuk ditampilkan di UI). */
    fun pending(): List<PendingAttendance> = store.all()

    /**
     * Ganti isi antrian tanpa mengubah data item — dipakai untuk MEMBERSIHKAN
     * item yang sudah basi (terlalu lama) dari sisi UI.
     */
    fun replaceForPrune(items: List<PendingAttendance>) {
        store.replace(items)
    }

    /**
     * Simpan absensi ke antrian offline.
     * @param note catatan di layar, mis. "Sinyal lemah" atau "Di luar radius".
     */
    fun capture(
        type: String,
        latitude: Double,
        longitude: Double,
        accuracyMeters: Double,
        isMockLocation: Boolean,
        faceDetected: Boolean,
        livenessPassed: Boolean,
        faceScore: Int?,
        faceVerifySource: String?,
        clientTimestamp: Long = System.currentTimeMillis(),
        note: String? = null,
    ): PendingAttendance {
        val item = PendingAttendance(
            clientId = UUID.randomUUID().toString(),
            type = type,
            latitude = latitude,
            longitude = longitude,
            accuracyMeters = accuracyMeters,
            isMockLocation = isMockLocation,
            faceDetected = faceDetected,
            livenessPassed = livenessPassed,
            faceScore = faceScore,
            faceVerifySource = faceVerifySource,
            clientTimestamp = clientTimestamp,
            queuedAt = System.currentTimeMillis(),
            note = note,
        )
        store.add(item)
        return item
    }

    /** Ringkasan hasil satu putaran sinkronisasi. */
    data class SyncOutcome(
        val attempted: Int,
        val sent: Int,
        val duplicates: Int,
        val rejected: Int,
        val remaining: Int,
        val offline: Boolean,
        val lastMessage: String? = null,
        /** Item yang DIBUANG karena jelas di luar jangkauan kantor (kunci lokasi). */
        val outOfRange: Int = 0,
    )

    /**
     * Kirim seluruh antrian sekarang (bila ada jaringan).
     *
     * Item yang BERHASIL (atau sudah tercatat / duplicate) dibuang dari antrian.
     * Item yang DITOLAK karena datanya tidak valid juga dibuang (agar tidak
     * menyumbat) — kecuali kegagalan karena jaringan, yang membuat item tetap
     * dipertahankan untuk dicoba lagi nanti.
     */
    suspend fun syncNow(maxBatch: Int = 50): SyncOutcome {
        val items = store.all()
        if (items.isEmpty()) {
            return SyncOutcome(0, 0, 0, 0, 0, offline = false)
        }

        val batch = items.take(maxBatch)
        val response: JSONObject = try {
            api.syncAttendance(batch)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            // Jaringan mati / server tidak terjangkau → pertahankan antrian.
            return SyncOutcome(
                attempted = batch.size,
                sent = 0,
                duplicates = 0,
                rejected = 0,
                remaining = store.pendingCount(),
                offline = true,
                lastMessage = e.message,
            )
        }

        val results = try {
            parseSyncResults(response)
        } catch (e: Exception) {
            // Balasan tak terduga → jangan buang item, coba lagi nanti.
            return SyncOutcome(
                attempted = batch.size,
                sent = 0,
                duplicates = 0,
                rejected = 0,
                remaining = store.pendingCount(),
                offline = false,
                lastMessage = e.message,
            )
        }

        val byId = results.associateBy { it.clientId }
        var sent = 0
        var duplicates = 0
        var rejected = 0
        var outOfRange = 0
        var lastMessage: String? = null

        val keep = ArrayList<PendingAttendance>()
        for (item in batch) {
            val r = byId[item.clientId]
            when {
                // Tidak ada balasan untuk item ini → coba lagi nanti.
                r == null -> keep += item.copy(attempts = item.attempts + 1)

                r.ok -> {
                    if (r.duplicate) duplicates++ else sent++
                    if (r.message != null) lastMessage = r.message
                }

                // KUNCI LOKASI: jelas di luar jangkauan kantor → BUANG, jangan
                // dicoba ulang. Hasilnya akan selalu sama dan hanya membuat
                // antrian menyumbat.
                r.rejectedOutOfRange -> {
                    outOfRange++
                    lastMessage = r.message
                }

                else -> {
                    // Ditolak karena alasan lain (mis. "Lokasi mock", "tipe tidak
                    // valid", atau "Check-in hari ini sudah ada"). Coba sekali lagi
                    // bila baru gagal 1x, lalu buang agar tidak menyumbat antrian.
                    if (item.attempts < 1) {
                        keep += item.copy(attempts = item.attempts + 1, note = r.message ?: item.note)
                    } else {
                        rejected++
                        lastMessage = r.message
                    }
                }
            }
        }
        // Sisa item di luar batch selalu dipertahankan.
        items.drop(batch.size).forEach { keep += it }
        store.replace(keep)

        return SyncOutcome(
            attempted = batch.size,
            sent = sent,
            duplicates = duplicates,
            rejected = rejected,
            remaining = store.pendingCount(),
            offline = false,
            lastMessage = lastMessage,
            outOfRange = outOfRange,
        )
    }

    private fun parseSyncResults(o: JSONObject): List<SyncItemResult> {
        val root = o.optJSONObject("data") ?: o
        val arr = root.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<SyncItemResult>(arr.length())
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { out += parseSyncResult(it) }
        }
        return out
    }
}
