package com.absensiku.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.FragmentActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.core.content.ContextCompat
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.SessionExpiredException
import com.absensiku.app.reminder.AttendanceReminder
import com.absensiku.app.reminder.ReminderPrefs
import com.absensiku.app.biometric.BiometricLoginButton
import com.absensiku.app.biometric.BiometricPrefs
import com.absensiku.app.face.FaceRepository
import com.absensiku.app.face.FaceScanView
import com.absensiku.app.location.LocationResult
import com.absensiku.app.location.LocationValidator
import com.absensiku.app.screens.AbsenScreen
import com.absensiku.app.screens.HistoryScreen
import com.absensiku.app.screens.ScheduleScreen
import com.absensiku.app.screens.LeaveScreen
import com.absensiku.app.screens.OvertimeScreen
import com.absensiku.app.screens.OpsScreen
import com.absensiku.app.screens.ProfileScreen
import com.absensiku.app.api.MeResponse
import com.absensiku.app.update.ApkDownloadState
import com.absensiku.app.update.ApkUpdater
import com.absensiku.app.update.AppNotifications
import com.absensiku.app.update.UpdateDialog
import com.absensiku.app.api.ServerUpdateInfo
import com.absensiku.app.ui.components.AppNotice
import com.absensiku.app.ui.components.AppNoticeHost
import com.absensiku.app.ui.components.BrandAccentBar
import com.absensiku.app.ui.components.BrandLogoCard
import com.absensiku.app.ui.components.NoticeKind
import com.absensiku.app.ui.theme.AbsensiKuTheme
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// PENTING (perbaikan biometrik): FragmentActivity (bukan ComponentActivity)
// karena BiometricPrompt memerlukan FragmentActivity sebagai host. Dengan
// ComponentActivity, upaya membuka prompt selalu gagal sehingga login biometrik
// tidak pernah berjalan.
class MainActivity : FragmentActivity() {
    private lateinit var api: ApiClient
    private lateinit var location: LocationValidator
    private var permissionsReady by mutableStateOf(false)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val locOk = result[Manifest.permission.ACCESS_FINE_LOCATION] == true &&
                result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            val camOk = result[Manifest.permission.CAMERA] == true
            permissionsReady = locOk && camOk
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        api = ApiClient(this)
        location = LocationValidator(this)
        permissionsReady = hasRequiredPermissions()

        // B67 — pakai desain lokasi kantor yang TERAKHIR tersimpan, sehingga
        // layar login langsung tampil sesuai cabang tanpa menunggu jaringan.
        // Desain terbaru menyusul otomatis dari GET /api/config setelah login.
        com.absensiku.app.ui.theme.BrandingPalette.loadFromPrefs(this)

        // Pemanasan koneksi lebih awal (asinkron) supaya login/absen pertama
        // tidak menunggu handshake TCP+TLS. Tidak memblok UI.
        api.warmUp()

        // Siapkan kanal notifikasi (pembaruan aplikasi & info server).
        AppNotifications(this).ensureChannel()

        setContent {
            AbsensiKuTheme {
                AbsensiApp(
                    api = api,
                    locationValidator = location,
                    permissionsReady = permissionsReady,
                    onRequestPermissions = { requestPermissionsIfNeeded() },
                )
            }
        }
    }

    private fun hasRequiredPermissions(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsIfNeeded() {
        val permissions = buildList {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
                add(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                add(Manifest.permission.CAMERA)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (permissions.isNotEmpty()) permissionLauncher.launch(permissions.toTypedArray())
    }
}

private fun isInternetAvailable(context: android.content.Context): Boolean {
    val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
    val network = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(network) ?: return false
    // B51: cukup ada jalur INTERNET. Syarat NET_CAPABILITY_VALIDATED (koneksi
    // "terbukti" ke internet) DIBUANG karena di lokasi kerja bersinyal lemah
    // validasi sering gagal walau data sebenarnya bisa terkirim — dulu inilah
    // alasan karyawan tidak bisa absen sama sekali.
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/** B51: format jam:menit untuk waktu scan asli (epoch millis). */
private fun hhmm(ms: Long): String =
    java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ms))

/** B51: tebak penyebab kegagalan kirim (untuk catatan di banner antrian). */
private fun offlineReason(msg: String?): String? {
    val l = msg?.lowercase() ?: return null
    return when {
        l.contains("timeout") || l.contains("unable to resolve") || l.contains("unknownhost") ||
            l.contains("failed to connect") || l.contains("network") || l.contains("socket") ||
            l.contains("connect") || l.contains("host") || l.contains("unreachable") -> "Tidak ada sinyal"
        l.contains("gps") || l.contains("lokasi") -> "GPS lemah"
        else -> null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AbsensiApp(
    api: ApiClient,
    locationValidator: LocationValidator,
    permissionsReady: Boolean,
    onRequestPermissions: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Minta izin (lokasi + kamera) OTOMATIS saat aplikasi pertama kali dibuka.
    var permissionAsked by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(permissionsReady) {
        if (!permissionsReady && !permissionAsked) {
            permissionAsked = true
            onRequestPermissions()
        }
    }

    var loggedIn by rememberSaveable { mutableStateOf(api.isLoggedIn()) }
    var scanType by rememberSaveable { mutableStateOf("CHECK_IN") }
    var scanning by rememberSaveable { mutableStateOf(false) }
    // true bila kamera dibuka dari tab Profil untuk REKAM (ulang) wajah, bukan absen.
    var enrollMode by rememberSaveable { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }
    // B51: sisa absensi yang menunggu terkirim (antrian offline) + status kirim.
    var pendingCount by remember { mutableIntStateOf(0) }
    var syncingQueue by remember { mutableStateOf(false) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    // Panel "Lainnya": menampung tab sekunder agar bilah bawah tetap rapi.
    var showMore by rememberSaveable { mutableStateOf(false) }

    // Status enrollment wajah (untuk notif tab Absen & status tab Profil).
    var enrolled by remember { mutableStateOf<Boolean?>(null) }
    // Apakah pengguna sudah pernah melewati/menutup peringatan "belum rekam wajah".
    var enrollWarnDismissed by rememberSaveable { mutableStateOf(false) }
    // Pengingat absen dalam-aplikasi: agar tidak muncul berulang dalam satu sesi.
    var checkinReminderShown by rememberSaveable { mutableStateOf(false) }
    val faceRepo = remember { FaceRepository(api, context) }

    // Notifikasi profesional (menggantikan snackbar polos).
    var notice by remember { mutableStateOf<AppNotice?>(null) }
    val showNotice: (NoticeKind, String, String?) -> Unit = { kind, title, message ->
        notice = AppNotice(kind = kind, title = title, message = message)
    }
    val showMessage: (String) -> Unit = { msg ->
        notice = AppNotice(kind = NoticeKind.INFO, title = msg)
    }
    // Tema warna default notifikasi mengikuti jenis.
    val showSuccess: (String, String?) -> Unit = { t, m -> showNotice(NoticeKind.SUCCESS, t, m) }
    val showError: (String, String?) -> Unit = { t, m -> showNotice(NoticeKind.ERROR, t, m) }
    val showWarn: (String, String?) -> Unit = { t, m -> showNotice(NoticeKind.WARNING, t, m) }

    // ================= B51: ANTRIAN ABSEN OFFLINE =================
    // Absensi yang discan saat sinyal buruk disimpan di perangkat bersama WAKTU
    // SCAN ASLI; dikirim otomatis begitu ada koneksi. Karena server menghitung
    // telat dari waktu scan, absensi tertunda TIDAK menjadi telat.

    /** Kirim seluruh antrian (diam-diam bila `notify` = false). */
    fun flushQueue(notify: Boolean) {
        if (api.queue.pendingCount() == 0) { pendingCount = 0; return }
        scope.launch {
            syncingQueue = true
            try {
                val out = api.queue.syncNow()
                pendingCount = api.queue.pendingCount()
                if (notify) {
                    when {
                        out.offline -> showMessage("Belum ada koneksi. Antrian absen tetap tersimpan di HP.")
                        out.sent + out.duplicates > 0 ->
                            showSuccess("Absensi Terkirim", "${out.sent + out.duplicates} absensi berhasil dikirim ke server.")
                        else -> showMessage("Antrian absen: ${out.remaining} menunggu terkirim.")
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (notify) showError("Sinkronisasi Gagal", e.message)
            } finally { syncingQueue = false }
        }
    }

    // Kirim antrian saat aplikasi dibuka (setelah login)…
    LaunchedEffect(loggedIn) {
        pendingCount = api.queue.pendingCount()
        if (loggedIn && pendingCount > 0) flushQueue(notify = false)
    }

    // …lalu coba terus-menerus selama aplikasi terbuka, sehingga begitu sinyal
    // kembali, absensi langsung terkirim tanpa karyawan harus membuka apa pun.
    LaunchedEffect(loggedIn) {
        if (!loggedIn) return@LaunchedEffect
        while (true) {
            delay(45_000L)
            val left = api.queue.pendingCount()
            pendingCount = left
            if (left > 0 && isInternetAvailable(context)) flushQueue(notify = true)
        }
    }

    // ==== Penanganan sesi tidak valid (akun dihapus/dinonaktifkan, perangkat dicabut) ====
    // Bila server menolak token (HTTP 401), ApiClient memanggil onSessionExpired;
    // kita paksa logout + tampilkan pesan. Ini memperbaiki bug "akun dihapus tapi
    // device tetap login & hanya muncul notif 404".
    LaunchedEffect(Unit) {
        api.onSessionExpired = { message ->
            api.logout()
            scope.launch {
                loggedIn = false
                scanning = false
                enrollMode = false
                enrolled = null
                showError("Sesi Berakhir", message ?: "Akun Anda tidak lagi aktif. Silakan login kembali atau hubungi pengelola.")
            }
        }
    }

    // ================= PEMBARUAN APLIKASI (v0.9.12, server-push) =================
    val updater = remember { ApkUpdater(context) }
    val notifier = remember { AppNotifications(context) }
    // Pass pertama setelah login: tumpukan notifikasi lama tidak perlu dipop ulang.
    var firstNotifPass by remember { mutableStateOf(true) }
    var updateInfo by remember { mutableStateOf<ServerUpdateInfo?>(null) }
    var updating by remember { mutableStateOf(false) }
    var updateProgress by remember { mutableStateOf<String?>(null) }
    // Unduhan via DownloadManager sistem (id != 0) — dipoll agar tidak stuck.
    var updateDownloadId by remember { mutableStateOf(0L) }
    var pendingReceiver by remember { mutableStateOf<android.content.BroadcastReceiver?>(null) }

    // Feature flags (Remote Config) dari server — mengendalikan tampil/tidaknya
    // fitur tanpa perlu merilis APK baru. Default semua aktif bila belum dimuat.
    var features by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    fun feat(key: String): Boolean = features[key] ?: true

    // Data karyawan (profil + peran jabatan) — menentukan tab Operasional (B11).
    var meData by remember { mutableStateOf<MeResponse?>(null) }
    // Tab Operasional muncul bila karyawan punya peran operasional DAN fitur
    // "ops_module" aktif di Remote Config (dapat di-on/off dari panel web).
    val opsEnabled = meData?.hasAnyOpsRole == true && feat("ops_module")

    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { pendingReceiver?.let { runCatching { context.unregisterReceiver(it) } } }
    }

    LaunchedEffect(Unit) {
        runCatching {
            api.checkAppUpdate()?.let { info ->
                updater.clearIfUpgraded(info.versionCode)
                if (!updater.isSkipped(info.versionCode)) updateInfo = info
            }
        }
    }

    // Menyelesaikan pembaruan: buka installer (atau minta izin pemasangan).
    val finishInstall: () -> Unit = {
        updating = false
        updateProgress = null
        updateDownloadId = 0L
        scope.launch {
            if (!updater.installWithPermission()) {
                showWarn("Izinkan Pemasangan", "Aktifkan izin pemasangan lalu tekan Perbarui Sekarang lagi.")
            }
        }
    }

    // Fallback: unduh langsung (HTTP) bila DownloadManager sistem gagal/tertahan.
    val runManualDownload: suspend () -> Boolean = {
        val info = updateInfo
        if (info == null) false
        else {
            updateProgress = "Mengunduh langsung…"
            val ok = updater.downloadApkManually(info) { done, total ->
                updateProgress = if (total > 0) {
                    val pct = ((done * 100) / total).coerceIn(0, 100)
                    "Mengunduh… $pct% (${done / 1_048_576}/${total / 1_048_576} MB)"
                } else {
                    "Mengunduh… ${done / 1_048_576} MB"
                }
            }
            ok
        }
    }

    val startUpdate: () -> Unit = {
        val info = updateInfo
        if (info != null && !updating) {
            updating = true
            updateProgress = "Menghubungi server unduhan…"
            if (!updater.canInstallPackages()) updater.openInstallPermissionSettings()
            val id = updater.startDownload(info)
            if (id <= 0) {
                // DownloadManager gagal di-enqueue → langsung pakai unduhan langsung.
                updateDownloadId = 0L
                scope.launch {
                    if (runManualDownload()) finishInstall() else {
                        updating = false; updateProgress = null
                        showError("Gagal Memperbarui", "Unduhan tidak dapat dimulai. Periksa koneksi lalu coba lagi.")
                    }
                }
            } else {
                updateDownloadId = id
            }
        }
    }

    // Polling status unduhan + fallback otomatis (anti-stuck). Popup tidak akan
    // "Memproses…" selamanya lagi: bila DownloadManager gagal/diam > ~20 detik,
    // unduhan dialihkan ke metode langsung.
    LaunchedEffect(updating, updateDownloadId) {
        val id = updateDownloadId
        if (!updating || id <= 0L) return@LaunchedEffect
        var stalledTicks = 0
        var lastBytes = -1L
        while (updating) {
            kotlinx.coroutines.delay(1500L)
            if (updateDownloadId != id) return@LaunchedEffect
            when (val st = updater.downloadState(id)) {
                is ApkDownloadState.Success -> {
                    // Pastikan berkas benar-benar ada; kalau tidak, fallback manual.
                    if (updater.apkExists()) finishInstall()
                    else {
                        if (runManualDownload()) finishInstall()
                        else { updating = false; updateProgress = null; showError("Gagal Memperbarui", "Berkas unduhan tidak ditemukan.") }
                    }
                    return@LaunchedEffect
                }
                is ApkDownloadState.Failed -> {
                    // DM gagal → coba unduhan langsung.
                    if (runManualDownload()) finishInstall()
                    else { updating = false; updateProgress = null; showError("Gagal Memperbarui", "Unduhan gagal (kode ${st.reason}). Coba lagi nanti.") }
                    return@LaunchedEffect
                }
                is ApkDownloadState.Running -> {
                    if (st.total > 0) {
                        val pct = ((st.downloaded * 100) / st.total).coerceIn(0, 100)
                        updateProgress = "Mengunduh… $pct% (${st.downloaded / 1_048_576}/${st.total / 1_048_576} MB)"
                        stalledTicks = 0
                    } else {
                        updateProgress = "Mengunduh… ${st.downloaded / 1_048_576} MB"
                    }
                    if (st.downloaded == lastBytes) stalledTicks++ else { stalledTicks = 0; lastBytes = st.downloaded }
                    if (stalledTicks >= 25) { // ~37 detik tanpa kemajuan → fallback
                        if (runManualDownload()) finishInstall()
                        else { updating = false; updateProgress = null; showError("Gagal Memperbarui", "Unduhan tersendat. Periksa koneksi lalu coba lagi.") }
                        return@LaunchedEffect
                    }
                }
                is ApkDownloadState.Pending -> {
                    stalledTicks++
                    updateProgress = "Menyiapkan unduhan…"
                    if (stalledTicks >= 15) { // ~22 detik masih pending → fallback
                        if (runManualDownload()) finishInstall()
                        else { updating = false; updateProgress = null; showError("Gagal Memperbarui", "Server unduhan tidak merespons. Coba lagi nanti.") }
                        return@LaunchedEffect
                    }
                }
            }
        }
    }

    val skipUpdate: () -> Unit = {
        updateInfo?.let { updater.markSkipped(it.versionCode) }
        updating = false; updateProgress = null; updateDownloadId = 0L
        updateInfo = null
    }

    val updateDialogHost: @Composable () -> Unit = {
        updateInfo?.let { info ->
            UpdateDialog(
                versionName = info.versionName,
                mandatory = info.mandatory,
                notes = info.notes,
                downloading = updating,
                progressText = updateProgress,
                onUpdate = startUpdate,
                onSkip = skipUpdate,
            )
        }
    }

    LaunchedEffect(loggedIn) {
        if (!loggedIn) return@LaunchedEffect
        while (true) {
            runCatching {
                val list = api.getNotifications()
                // Saat pertama kali login setelah update, daftarkan SEMUA notifikasi
                // yang ada sebagai "sudah tampil" supaya tumpukan lama tidak
                // muncul berulang-ulang (ini penyebab notif "muncul terus").
                val unseen = list.filter { !notifier.isShown(it.id) }
                if (firstNotifPass && unseen.isNotEmpty()) {
                    notifier.markAllShown(list.map { it.id })
                } else {
                    for (n in unseen) {
                        notifier.markShown(n.id)
                        notifier.show(n.id.hashCode(), n.title, n.body)
                        // Tandai sudah dibaca di server agar tidak dikirim lagi.
                        runCatching { api.markNotificationRead(n.id) }
                        if (n.kind == "UPDATE") {
                            api.checkAppUpdate()?.let { info ->
                                if (!updater.isSkipped(info.versionCode)) updateInfo = info
                            }
                        }
                    }
                }
            }
            firstNotifPass = false
            kotlinx.coroutines.delay(60_000L)
        }
    }

    if (!loggedIn) {
        Box(Modifier.fillMaxSize()) {
            LoginScreen(
                api = api,
                onLoggedIn = { loggedIn = true; firstNotifPass = true },
                showMessage = showMessage,
            )
            AppNoticeHost(
                notice = notice,
                onDismiss = { notice = null },
                modifier = Modifier.align(Alignment.TopCenter),
            )
            updateDialogHost()
        }
        return
    }

    // Muat status enrollment wajah untuk notif tab Absen & status tab Profil.
    LaunchedEffect(loggedIn, refreshKey) {
        if (!loggedIn) return@LaunchedEffect
        enrolled = runCatching { faceRepo.isEnrolled() }.getOrNull()
    }

    // Muat feature flags (Remote Config) — agar fitur yang dimatikan server
    // langsung hilang dari navigasi pada pembukaan aplikasi berikutnya.
    LaunchedEffect(loggedIn, refreshKey) {
        if (!loggedIn) return@LaunchedEffect
        features = runCatching { api.getConfig().features }.getOrDefault(emptyMap())
    }

    // Muat profil + peran jabatan (B11) — menentukan tab Operasional muncul.
    LaunchedEffect(loggedIn, refreshKey) {
        if (!loggedIn) return@LaunchedEffect
        meData = runCatching { api.getMe() }.getOrNull()
        // Jadwalkan ulang pengingat absen sesuai shift terbaru.
        meData?.let { m ->
            if (!m.isOffToday) {
                ReminderPrefs(context).saveShift(m.shiftStart?.take(5), m.shiftEnd?.take(5))
                AttendanceReminder.schedule(
                    context,
                    AttendanceReminder.parseHm(m.shiftStart),
                    AttendanceReminder.parseHm(m.shiftEnd),
                )
            }
        }
    }

    // Pengingat Absen dalam aplikasi (lapisan kedua, saat aplikasi dibuka):
    // bila mendekati/melewati jam masuk dan karyawan BELUM check-in hari ini,
    // tampilkan pengingat halus agar tidak lupa absen.
    LaunchedEffect(loggedIn, meData, refreshKey) {
        if (!loggedIn) return@LaunchedEffect
        val m: MeResponse = meData ?: return@LaunchedEffect
        val rp = ReminderPrefs(context)
        if (!rp.enabled || m.isOffToday) return@LaunchedEffect
        val startMin = AttendanceReminder.parseHm(m.shiftStart) ?: return@LaunchedEffect
        val today = runCatching { api.getTodayAttendance() }.getOrNull()
        val nowCal = java.util.Calendar.getInstance()
        val nowMin = nowCal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + nowCal.get(java.util.Calendar.MINUTE)
        // Hanya ketika sudah masuk jendela pengingat (lead) s/d 4 jam setelah jam masuk.
        if (nowMin >= startMin - rp.leadMinutes && nowMin <= startMin + 240) {
            if (today?.checkInAt == null && !checkinReminderShown) {
                checkinReminderShown = true
                notice = AppNotice(
                    kind = NoticeKind.INFO,
                    title = "Waktunya Absen Masuk",
                    message = "Anda belum melakukan absen masuk hari ini. Buka tab Absen untuk check-in " +
                        "(shift ${m.shiftName ?: "hari ini"} mulai ${(m.shiftStart ?: "").take(5)}).",
                )
            }
        } else {
            checkinReminderShown = false
        }
    }

    // Notifikasi "belum rekam sample wajah" saat masuk ke tab Absen.
    LaunchedEffect(loggedIn, selectedTab, enrolled, enrollWarnDismissed, scanning) {
        if (loggedIn && !scanning && selectedTab == 0 && enrolled == false && !enrollWarnDismissed) {
            enrollWarnDismissed = true
            notice = AppNotice(
                kind = NoticeKind.WARNING,
                title = "Wajah Belum Direkam",
                message = "Rekam sampel wajah dulu agar bisa absen. Buka tab Profil → Data Wajah Absensi → Rekam.",
            )
        }
    }

    if (scanning) {
        Box(Modifier.fillMaxSize()) {
            FaceScanView(
                api = api,
                forceEnroll = enrollMode,
                onCancel = { scanning = false; enrollMode = false },
                onResult = { face ->
                    // Enrollment selesai (bukan absensi) -> cukup beri tahu.
                    if (face.enrolled) {
                        scope.launch {
                            showSuccess(
                                "Wajah Berhasil Direkam",
                                "Data wajah Anda tersimpan. Absensi berikutnya akan diverifikasi otomatis.",
                            )
                            scanning = false
                            enrollMode = false
                            refreshKey++
                        }
                        return@FaceScanView
                    }

                    // Wajah tidak cocok dengan data terdaftar.
                    if (!face.match) {
                        scanning = false
                        val scoreTxt = face.score?.let { "Kemiripan $it%" }
                        showError(
                            "Wajah Tidak Cocok",
                            face.message ?: "Wajah tidak sesuai dengan data terdaftar. Coba lagi dengan pencahayaan lebih baik.",
                        )
                        return@FaceScanView
                    }

                    scope.launch {
                        try {
                            when (val loc = locationValidator.getCurrentLocation()) {
                                is LocationResult.Success -> {
                                    if (loc.isMock) throw IllegalStateException("Lokasi mock terdeteksi")
                                    val scanTimestamp = System.currentTimeMillis()
                                    // B51: coba kirim ONLINE. Bila jaringan buruk /
                                    // GPS lemah, absensi DISIMPAN ke antrian offline
                                    // (dengan waktu scan ASLI) — tidak hilang, tidak
                                    // ditolak, dan tidak menjadi telat.
                                    val response = try {
                                        api.submitAttendance(
                                            type = scanType,
                                            latitude = loc.latitude,
                                            longitude = loc.longitude,
                                            accuracyMeters = loc.accuracyMeters,
                                            isMockLocation = loc.isMock,
                                            faceDetected = face.faceDetected,
                                            livenessPassed = face.livenessPassed,
                                            faceScore = face.score,
                                            faceVerifySource = face.source,
                                            clientTimestamp = scanTimestamp,
                                        )
                                    } catch (e: SessionExpiredException) {
                                        throw e
                                    } catch (e: java.io.IOException) {
                                        // Benar-benar TIDAK ADA JARINGAN (timeout, DNS,
                                        // tidak ada rute, TLS gagal). Hanya kondisi ini
                                        // yang boleh masuk antrian offline.
                                        api.queue.capture(
                                            type = scanType,
                                            latitude = loc.latitude,
                                            longitude = loc.longitude,
                                            accuracyMeters = loc.accuracyMeters.toDouble(),
                                            isMockLocation = loc.isMock,
                                            faceDetected = face.faceDetected,
                                            livenessPassed = face.livenessPassed,
                                            faceScore = face.score,
                                            faceVerifySource = face.source,
                                            clientTimestamp = scanTimestamp,
                                            note = offlineReason(e.message) ?: "Tidak ada sinyal",
                                        )
                                        pendingCount = api.queue.pendingCount()
                                        showWarn(
                                            "Absensi Tersimpan di HP",
                                            "Sinyal/GPS lemah — absensi disimpan dulu di perangkat. " +
                                                "Waktu absen TETAP tercatat saat Anda scan (${hhmm(scanTimestamp)}), " +
                                                "jadi TIDAK dihitung telat. Akan terkirim otomatis begitu ada sinyal.",
                                        )
                                        return@launch
                                    } catch (e: Exception) {
                                        // Server MENOLAK absensi (mis. di luar jangkauan
                                        // kantor). JANGAN dimasukkan ke antrian — hasilnya
                                        // akan selalu sama, dan ini menjaga kunci lokasi.
                                        showError(
                                            "Absensi Tidak Bisa Disimpan",
                                            e.message ?: "Absensi ditolak server.",
                                        )
                                        return@launch
                                    }
                                    val title = if (response.type == "CHECK_OUT") {
                                        "Absen Keluar Berhasil"
                                    } else if (response.status == "TERLAMBAT") {
                                        "Absen Masuk — Terlambat"
                                    } else {
                                        "Absen Masuk Berhasil"
                                    }
                                    val detail = buildString {
                                        append("Wajah ${face.score ?: 0}% (${face.source})")
                                        append(" • ${response.distanceMeters.toInt()} m dari kantor")
                                        if (response.status == "TERLAMBAT" && response.lateMinutes > 0) {
                                            append(" • Terlambat ${response.lateMinutes} menit")
                                        }
                                        if (response.offlineSync) append(" • dari antrian offline")
                                        if (response.needsVerification) append(" • perlu verifikasi admin")
                                    }
                                    if (response.status == "TERLAMBAT") {
                                        showWarn(title, detail)
                                    } else {
                                        showSuccess(title, detail)
                                    }
                                }
                                is LocationResult.MissingPermission -> {
                                    onRequestPermissions()
                                    throw IllegalStateException("Izin lokasi diperlukan")
                                }
                                is LocationResult.Error -> throw IllegalStateException(loc.message)
                                is LocationResult.GpsDisabled -> throw IllegalStateException("GPS belum tersedia")
                            }
                        } catch (e: kotlinx.coroutines.CancellationException) {

                            throw e

                        } catch (e: Exception) {
                            val msg = e.message ?: "Absensi gagal"
                            val lower = msg.lowercase()
                            when {
                                lower.contains("izin") || lower.contains("gps") || lower.contains("lokasi") ->
                                    showWarn("Absensi Tertunda", msg)
                                else -> showError("Absensi Gagal", msg)
                            }
                        } finally {
                            scanning = false
                            refreshKey++
                        }
                    }
                },
            )
            AppNoticeHost(
                notice = notice,
                onDismiss = { notice = null },
                modifier = Modifier.align(Alignment.TopCenter),
            )
            updateDialogHost()
        }
        return
    }

    // ---- Panel "Lainnya" (bottom sheet) ----
    // Daftar lengkap tab (dipakai untuk routing konten, berbasis indeks yang
    // stabil karena urutannya tetap). Izin/Lembur mengikuti feature flags,
    // Operasional mengikuti rol + flag ops_module.
    val allTabs = listOf(
        Triple("absen", "Absen", R.drawable.ic_tab_absen),
        Triple("jadwal", "Jadwal", R.drawable.ic_tab_jadwal),
        Triple("riwayat", "Riwayat", R.drawable.ic_tab_riwayat),
        Triple("profil", "Profil", R.drawable.ic_tab_profile),
        Triple("izin", "Izin", R.drawable.ic_tab_izin),
        Triple("lembur", "Lembur", R.drawable.ic_tab_lembur),
        Triple("operasional", "Operasional", R.drawable.ic_tab_operasional),
    ).filter { (id, _, _) ->
        when (id) {
            "izin" -> feat("leave")
            "lembur" -> feat("overtime")
            "operasional" -> opsEnabled
            else -> true
        }
    }
    // Tab sekunder yang tampil di panel "Lainnya" = semua tab selain 3 utama.
    val primaryIds = setOf("absen", "jadwal", "riwayat")
    val moreTabs = allTabs.filter { it.first !in primaryIds }
    val selectedTabId = allTabs.getOrNull(selectedTab.coerceIn(0, (allTabs.size - 1).coerceAtLeast(0)))?.first ?: "absen"

    if (showMore) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showMore = false },
            sheetState = sheetState,
            containerColor = KartiniColors.CreamSurface,
        ) {
            MoreSheet(
                tabs = moreTabs,
                selectedId = selectedTabId,
                onPick = { id ->
                    val idx = allTabs.indexOfFirst { it.first == id }
                    if (idx >= 0) selectedTab = idx
                    showMore = false
                },
            )
        }
    }

    Scaffold(
        containerColor = KartiniColors.CreamBg,
        bottomBar = {
            // Bilah bawah dibuat RAPI & PROFESIONAL: hanya 3 tab utama (jarang
            // berubah) + tombol "Lainnya". Tab sekunder (Profil, Izin, Lembur,
            // Operasional) dipindah ke panel "Lainnya" (bottom sheet) agar bilah
            // tidak menumpuk/menyempit walau tab bertambah.
            val primaryTabs = listOf(
                Triple("absen", "Absen", R.drawable.ic_tab_absen),
                Triple("jadwal", "Jadwal", R.drawable.ic_tab_jadwal),
                Triple("riwayat", "Riwayat", R.drawable.ic_tab_riwayat),
            )
            val barTabs = primaryTabs + Triple("more", "Lainnya", R.drawable.ic_tab_more)
            // Tandai aktif sesuai posisi tab utama; jika sedang di tab sekunder,
            // sorot tombol "Lainnya".
            val primaryActive = selectedTab in primaryTabs.indices
            val safeSelected = if (primaryActive) selectedTab else barTabs.lastIndex
            KartiniBottomBar(
                tabs = barTabs,
                selectedIndex = safeSelected,
                onSelect = { idx ->
                    if (idx == barTabs.lastIndex) showMore = true else selectedTab = idx
                },
            )
        },
    ) { padding ->
        Box(modifier = Modifier.padding(bottom = padding.calculateBottomPadding())) {
            val activeId = selectedTabId
            when (activeId) {
                "absen" -> key(refreshKey) {
                    AbsenScreen(
                        api = api,
                        locationValidator = locationValidator,
                        // B51: TIDAK ADA lagi blokir "Internet Diperlukan". Karyawan
                        // boleh scan kapan pun; bila jaringan buruk, absensi
                        // disimpan di HP dengan waktu scan asli.
                        onCheckIn = {
                            if (!permissionsReady) onRequestPermissions()
                            else { scanType = "CHECK_IN"; scanning = true }
                        },
                        onCheckOut = {
                            if (!permissionsReady) onRequestPermissions()
                            else { scanType = "CHECK_OUT"; scanning = true }
                        },
                        showMessage = showMessage,
                    )
                }
                "jadwal" -> ScheduleScreen(api = api, showMessage = showMessage)
                "riwayat" -> HistoryScreen(api = api, showMessage = showMessage)
                "izin" -> LeaveScreen(api = api, showMessage = showMessage)
                "lembur" -> OvertimeScreen(api = api, showMessage = showMessage)
                "operasional" -> meData?.let { m ->
                    OpsScreen(api = api, locationValidator = locationValidator, me = m, showMessage = showMessage)
                }
                "profil" -> ProfileScreen(
                    api = api,
                    enrolled = enrolled,
                    allowChangePassword = feat("self_change_password"),
                    onStartEnroll = {
                        if (!permissionsReady) onRequestPermissions()
                        else { enrollMode = true; scanning = true }
                    },
                    onNotify = { ok, title, msg ->
                        if (ok) showSuccess(title, msg) else showError(title, msg)
                    },
                    onLogout = { api.logout(); loggedIn = false; enrollMode = false; enrolled = null },
                )
            }
            AppNoticeHost(
                notice = notice,
                onDismiss = { notice = null },
                modifier = Modifier.align(Alignment.TopCenter),
            )
            updateDialogHost()
        }
    }
}

// ================= LOGIN =================

@Composable
private fun absenFieldColors() = OutlinedTextFieldDefaults.colors(
    // Warna kontainer dibuat tetap terang (cream). Karena itu warna teks,
    // label, ikon, dan kursor WAJIB dipatok ke warna gelap secara eksplisit —
    // kalau tidak, saat perangkat memakai mode gelap (dark mode) warna teks
    // otomatis putih sehingga kode & PIN tampak "peang" / tidak terbaca di
    // atas latar cream.
    focusedBorderColor = KartiniColors.BrandGreen,
    unfocusedBorderColor = KartiniColors.Outline,
    focusedContainerColor = KartiniColors.CreamDeep,
    unfocusedContainerColor = KartiniColors.CreamDeep,
    cursorColor = KartiniColors.BrandGreen,
    // Teks yang diketik
    focusedTextColor = KartiniColors.OnSurface,
    unfocusedTextColor = KartiniColors.OnSurface,
    // Label (Kode Karyawan / PIN)
    focusedLabelColor = KartiniColors.BrandGreen,
    unfocusedLabelColor = KartiniColors.OnSurfaceMuted,
    // Ikon depan & belakang
    focusedLeadingIconColor = KartiniColors.Olive,
    unfocusedLeadingIconColor = KartiniColors.Olive,
    focusedTrailingIconColor = KartiniColors.OnSurfaceMuted,
    unfocusedTrailingIconColor = KartiniColors.OnSurfaceMuted,
    // Warna placeholder & teks seleksi
    focusedPlaceholderColor = KartiniColors.OnSurfaceMuted,
    unfocusedPlaceholderColor = KartiniColors.OnSurfaceMuted,
)

@Composable
private fun LoginScreen(
    api: ApiClient,
    onLoggedIn: () -> Unit,
    showMessage: (String) -> Unit,
) {
    var employeeCode by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var obscure by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    // Preferensi kode tersimpan + login biometrik (tetap ada meski sudah logout).
    val bioPrefs = remember { BiometricPrefs(context) }
    var rememberCode by remember { mutableStateOf(bioPrefs.savedEmployeeCode() != null) }

    // Isi otomatis kode bila pernah disimpan.
    LaunchedEffect(Unit) {
        bioPrefs.savedEmployeeCode()?.let { if (employeeCode.isBlank()) employeeCode = it }
    }

    // Fungsi login bersama (dipakai tombol Login & Biometrik).
    fun doLogin(code: String, pass: String, persist: Boolean) {
        if (loading) return
        loading = true
        scope.launch {
            try {
                api.login(code, pass)
                // PENTING (perbaikan biometrik): kredensial tersimpan HANYA boleh
                // dihapus bila pengguna BENAR-BENAR berniat mematikannya. Jika
                // login biometrik masih aktif, jangan hapus — justru perbarui
                // kredensial agar login cepat tetap berfungsi (mis. setelah ganti
                // password). Sebelumnya, login manual dengan "Simpan kode karyawan"
                // tidak dicentang akan menghapus kredensial sehingga tombol
                // biometrik hilang / gagal.
                // Cermin aturan sama diterapkan pada validasi form (lihat `persist`).
                if (persist || bioPrefs.isEnabled()) {
                    bioPrefs.saveCredentials(code.trim(), pass)
                } else {
                    bioPrefs.clearCredentials()
                }
                onLoggedIn()
            } catch (e: kotlinx.coroutines.CancellationException) {

                throw e

            } catch (e: Exception) {
                val msg = when (e) {
                    is java.net.UnknownHostException -> "Tidak ada koneksi internet"
                    is java.net.SocketTimeoutException -> "Koneksi ke server timeout. Periksa internet Anda"
                    else -> e.message ?: "Login gagal. Periksa kode & password Anda"
                }
                showMessage(msg)
            } finally {
                loading = false
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(16.dp))

            // Kartu logo (identik dengan source: 92dp, radius 26, padding 8).
            Box(
                modifier = Modifier
                    .size(92.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color.White)
                    .padding(8.dp),
                contentAlignment = Alignment.Center,
            ) {
                com.absensiku.app.ui.components.BrandImage(
                    src = com.absensiku.app.ui.theme.BrandingPalette.logoSrc,
                    fallbackRes = R.drawable.ic_logo_kartini,
                    contentDescription = com.absensiku.app.ui.theme.BrandingPalette.brandName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)),
                )
            }

            Spacer(Modifier.height(20.dp))
            Text(
                com.absensiku.app.ui.theme.BrandingPalette.displayName,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = KartiniColors.OnSurface,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                com.absensiku.app.ui.theme.BrandingPalette.tagline,
                color = KartiniColors.OnSurfaceMuted,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(36.dp))

            OutlinedTextField(
                value = employeeCode,
                onValueChange = { employeeCode = it },
                label = { Text("Kode Karyawan") },
                leadingIcon = {
                    Icon(Icons.Outlined.PersonOutline, contentDescription = null, tint = KartiniColors.Olive)
                },
                singleLine = true,
                colors = absenFieldColors(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                leadingIcon = {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = KartiniColors.Olive)
                },
                singleLine = true,
                visualTransformation = if (obscure) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { obscure = !obscure }) {
                        Icon(
                            if (obscure) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = null,
                            tint = KartiniColors.OnSurfaceMuted,
                        )
                    }
                },
                colors = absenFieldColors(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(6.dp))

            // ---------- Simpan kode karyawan + biometrik ----------
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(
                    checked = rememberCode,
                    onCheckedChange = { rememberCode = it },
                    colors = CheckboxDefaults.colors(
                        checkedColor = KartiniColors.BrandGreen,
                        uncheckedColor = KartiniColors.Olive,
                        checkmarkColor = Color.White,
                    ),
                )
                Text(
                    "Simpan kode karyawan",
                    color = KartiniColors.OnSurface,
                    fontSize = 13.5.sp,
                    modifier = Modifier.weight(1f),
                )
            }

            Spacer(Modifier.height(18.dp))

            Button(
                enabled = !loading && employeeCode.isNotBlank() && password.isNotBlank(),
                onClick = { doLogin(employeeCode.trim(), password, rememberCode) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = KartiniColors.BrandGreen,
                    contentColor = Color.White,
                    disabledContainerColor = KartiniColors.BrandGreen.copy(alpha = 0.45f),
                    disabledContentColor = Color.White,
                ),
            ) {
                if (loading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Memproses...", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                } else {
                    Icon(Icons.Filled.Login, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Login", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            // ---------- Tombol login biometrik (bila aktif & didukung) ----------
            if (bioPrefs.canQuickLogin()) {
                Spacer(Modifier.height(12.dp))
                BiometricLoginButton(
                    prefs = bioPrefs,
                    onLogin = { code, savedPin -> doLogin(code, savedPin, persist = true) },
                    onError = { showMessage(it) },
                )
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "Internet wajib aktif untuk login dan setiap transaksi absensi.",
                color = KartiniColors.OnSurfaceMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ================= BOTTOM NAVIGATION (kustom, rapi & profesional) =================
// Menggantikan NavigationBar bawaan agar saat tab banyak (hingga 7) tetap enak
// dilihat: label satu baris tanpa terpotong ("Operasio nal"), ikon dalam pil
// lembut saat aktif, dan pemisah halus di atas bilah.
@Composable
private fun KartiniBottomBar(
    tabs: List<Triple<String, String, Int>>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
) {
    Surface(
        color = Color.White,
        shadowElevation = 12.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(KartiniColors.DividerLight)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                tabs.forEachIndexed { index, tab ->
                    val selected = index == selectedIndex
                    val tint = if (selected) KartiniColors.BrandGreen else KartiniColors.OnSurfaceMuted
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onSelect(index) }
                            .padding(vertical = 5.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) KartiniColors.BrandGreenSoft else Color.Transparent)
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                painter = painterResource(tab.third),
                                contentDescription = tab.second,
                                tint = tint,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = tab.second,
                            color = tint,
                            fontSize = 10.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}

// ================= PANEL "LAINNYA" (bottom sheet) =================
// Menampilkan tab sekunder (Profil, Izin, Lembur, Operasional) dalam bentuk
// daftar kartu yang rapi. Dipilih -> langsung berpindah tab.
@Composable
private fun MoreSheet(
    tabs: List<Triple<String, String, Int>>,
    selectedId: String,
    onPick: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, bottom = 28.dp),
    ) {
        Text(
            text = "Menu Lainnya",
            color = KartiniColors.OnSurface,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "Pilih menu untuk berpindah halaman",
            color = KartiniColors.OnSurfaceMuted,
            fontSize = 12.sp,
        )
        Spacer(Modifier.height(16.dp))
        tabs.forEach { (id, label, icon) ->
            val selected = id == selectedId
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (selected) KartiniColors.BrandGreenSoft else Color.Transparent)
                    .clickable { onPick(id) }
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) KartiniColors.BrandGreen else KartiniColors.CreamDeep),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        painter = painterResource(icon),
                        contentDescription = label,
                        tint = if (selected) Color.White else KartiniColors.BrandGreen,
                        modifier = Modifier.size(22.dp),
                    )
                }
                Spacer(Modifier.width(14.dp))
                Text(
                    text = label,
                    color = KartiniColors.OnSurface,
                    fontSize = 15.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier.weight(1f),
                )
                if (selected) {
                    Text(
                        text = "Aktif",
                        color = KartiniColors.BrandGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}
