package com.absensiku.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.ScheduleDay
import com.absensiku.app.ui.components.BrandTopBar
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale

private val DOW_SHORT = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")

/** Jadwal kerja mingguan karyawan (shift efektif per hari). */
@Composable
fun ScheduleScreen(
    api: ApiClient,
    showMessage: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var days by remember { mutableStateOf<List<ScheduleDay>>(emptyList()) }
    var weekStart by remember { mutableStateOf(mondayOf(Calendar.getInstance())) }
    var busy by remember { mutableStateOf(true) }

    fun load() {
        scope.launch {
            busy = true
            try {
                days = api.getSchedule(weekStart)
            } catch (e: kotlinx.coroutines.CancellationException) {

                throw e

            } catch (e: Exception) {
                showMessage(e.message ?: "Gagal memuat jadwal")
            }
            busy = false
        }
    }
    LaunchedEffect(weekStart) { load() }

    val todayIso = LocalDate.now().toString()
    val byDate = remember(days) { days.associateBy { it.date } }
    // Susun 7 hari Senin..Minggu walau server belum mengirim semua hari.
    val week: List<ScheduleDay> = (0..6).map { i ->
        val d = addDays(weekStart, i)
        byDate[d] ?: ScheduleDay(date = d, off = false, shiftName = null, startTime = null, endTime = null)
    }
    val workDays = week.count { !it.off && (!it.startTime.isNullOrBlank() || it.shiftName != null) }
    val offDays = week.count { it.off }
    val dominantShift = week.filter { !it.off }.mapNotNull { it.shiftName }.groupingBy { it }.eachCount()
        .maxByOrNull { it.value }?.key

    Box(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        Column(modifier = Modifier.fillMaxSize()) {
            BrandTopBar(title = "Jadwal Kerja", subtitle = "Rencana shift mingguan Anda")
            if (busy) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = KartiniColors.BrandGreen,
                )
            }
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 14.dp),
            ) {
                // ---- Header minggu + navigasi ----
                WeekHeader(
                    weekStart = weekStart,
                    onPrev = { weekStart = addDays(weekStart, -7) },
                    onNext = { weekStart = addDays(weekStart, 7) },
                    onToday = { weekStart = mondayOf(Calendar.getInstance()) },
                )
                Spacer(Modifier.height(14.dp))

                // ---- Ringkasan minggu ----
                SummaryRow(workDays = workDays, offDays = offDays, dominantShift = dominantShift)
                Spacer(Modifier.height(14.dp))

                // ---- Strip hari (Sen..Min) ----
                WeekStrip(week = week, todayIso = todayIso)
                Spacer(Modifier.height(16.dp))

                // ---- Judul daftar ----
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(width = 4.dp, height = 18.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(KartiniColors.BrandGreen),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Detail Harian",
                        color = KartiniColors.OnSurface,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                    )
                }
                Spacer(Modifier.height(10.dp))

                if (days.isEmpty() && !busy) {
                    EmptyState()
                } else {
                    week.forEach { d ->
                        ScheduleDayCard(d, isToday = d.date == todayIso)
                        Spacer(Modifier.height(10.dp))
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

/* ---------------- Header minggu + navigasi ---------------- */

@Composable
private fun WeekHeader(
    weekStart: String,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onToday: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
    ) {
        Column(
            modifier = Modifier
                .background(Brush.verticalGradient(listOf(KartiniColors.BrandGreenDark, KartiniColors.BrandGreen)))
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.DateRange, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Periode Jadwal", color = Color.White.copy(alpha = 0.80f), fontSize = 11.5.sp)
                    Text(
                        weekRangeLabel(weekStart),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.18f))
                        .border(1.dp, Color.White.copy(alpha = 0.30f), RoundedCornerShape(50))
                        .clickable { onToday() }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Text("Hari ini", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                IconButton(
                    onClick = onPrev,
                    modifier = Modifier.size(34.dp).clip(CircleShape).background(Color.White),
                ) {
                    Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "Minggu sebelumnya", tint = KartiniColors.BrandGreen)
                }
                Text(
                    "Geser minggu",
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 11.5.sp,
                )
                IconButton(
                    onClick = onNext,
                    modifier = Modifier.size(34.dp).clip(CircleShape).background(Color.White),
                ) {
                    Icon(Icons.Filled.KeyboardArrowRight, contentDescription = "Minggu berikutnya", tint = KartiniColors.BrandGreen)
                }
            }
        }
    }
}

/* ---------------- Ringkasan ---------------- */

@Composable
private fun SummaryRow(workDays: Int, offDays: Int, dominantShift: String?) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SummaryPill(
            label = "Hari Kerja",
            value = "$workDays",
            accent = KartiniColors.BrandGreen,
            modifier = Modifier.weight(1f),
        )
        SummaryPill(
            label = "Hari Libur",
            value = "$offDays",
            accent = KartiniColors.BrandOrangeDeep,
            modifier = Modifier.weight(1f),
        )
        SummaryPill(
            label = "Shift Utama",
            value = dominantShift ?: "—",
            accent = KartiniColors.Olive,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun SummaryPill(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = KartiniColors.CreamSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, color = KartiniColors.OnSurfaceMuted, fontSize = 10.5.sp, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            Text(
                value,
                color = accent,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 1,
            )
        }
    }
}

/* ---------------- Week strip ---------------- */

@Composable
private fun WeekStrip(week: List<ScheduleDay>, todayIso: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            week.forEachIndexed { i, d ->
                val isToday = d.date == todayIso
                val isOff = d.off
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        DOW_SHORT.getOrElse(i) { "" },
                        color = if (isToday) KartiniColors.BrandGreen else KartiniColors.OnSurfaceMuted,
                        fontSize = 11.sp,
                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                    )
                    Spacer(Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isOff -> KartiniColors.BrandOrangeSoft
                                    else -> KartiniColors.BrandGreenSoft
                                }
                            )
                            .then(
                                if (isToday) Modifier.border(2.dp, KartiniColors.BrandGreen, CircleShape) else Modifier
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        val dayNum = d.date.substringAfterLast('-').trimStart('0')
                        Text(
                            dayNum,
                            color = if (isOff) KartiniColors.BrandOrangeDeep else KartiniColors.BrandGreenDeep,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(
                        modifier = Modifier.size(6.dp).clip(CircleShape).background(
                            if (isOff) KartiniColors.BrandOrange else KartiniColors.BrandGreen
                        ),
                    )
                }
            }
        }
    }
}

/* ---------------- Kartu hari ---------------- */

@Composable
private fun ScheduleDayCard(d: ScheduleDay, isToday: Boolean) {
    val accent = if (d.off) KartiniColors.BrandOrangeDeep else KartiniColors.BrandGreen
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isToday) 4.dp else 2.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth().height(androidx.compose.foundation.layout.IntrinsicSize.Min)) {
            // Aksen kiri
            Box(
                modifier = Modifier
                    .width(5.dp)
                    .fillMaxHeight()
                    .background(accent),
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            weekdayLong(d.date),
                            color = KartiniColors.OnSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                        )
                        if (isToday) {
                            Spacer(Modifier.width(8.dp))
                            TagChip("Hari ini", KartiniColors.BrandGreen, KartiniColors.BrandGreenSoft)
                        }
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(
                        dateLong(d.date),
                        color = KartiniColors.OnSurfaceMuted,
                        fontSize = 12.sp,
                    )
                }

                if (d.off) {
                    TagChip("LIBUR", KartiniColors.BrandOrangeDeep, KartiniColors.BrandOrangeSoft)
                } else {
                    Column(horizontalAlignment = Alignment.End) {
                        TagChip(d.shiftName ?: "Shift", KartiniColors.BrandGreenDeep, KartiniColors.BrandGreenSoft)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${shortHm(d.startTime)} - ${shortHm(d.endTime)}",
                            color = KartiniColors.OnSurface,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.5.sp,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TagChip(text: String, fg: Color, bg: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(text, color = fg, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun EmptyState() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = KartiniColors.CreamSurface),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Filled.DateRange, contentDescription = null, tint = KartiniColors.OnSurfaceMuted, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(10.dp))
            Text(
                "Belum ada jadwal untuk minggu ini",
                color = KartiniColors.OnSurface,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.5.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Jadwal akan muncul setelah diatur oleh admin.",
                color = KartiniColors.OnSurfaceMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/* ---------------- Helper tampilan ---------------- */

private fun shortHm(hm: String?): String {
    if (hm.isNullOrBlank()) return "--:--"
    val parts = hm.split(":")
    return if (parts.size >= 2) "${parts[0].padStart(2, '0')}:${parts[1].take(2)}" else hm
}

private fun weekdayLong(iso: String): String = try {
    LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("EEEE", Locale("id", "ID")))
} catch (_: Exception) { iso }

private fun dateLong(iso: String): String = try {
    LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("id", "ID")))
} catch (_: Exception) { iso }

private fun weekRangeLabel(weekStart: String): String = try {
    val s = LocalDate.parse(weekStart)
    val e = s.plusDays(6)
    val fmt = DateTimeFormatter.ofPattern("d MMM", Locale("id", "ID"))
    val fmtY = DateTimeFormatter.ofPattern("d MMM yyyy", Locale("id", "ID"))
    if (s.month == e.month) "${s.format(fmt)} – ${e.format(fmtY)}" else "${s.format(fmt)} – ${e.format(fmtY)}"
} catch (_: Exception) { weekStart }

private fun mondayOf(cal: Calendar): String {
    val c = cal.clone() as Calendar
    while (c.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) c.add(Calendar.DAY_OF_MONTH, -1)
    return isoOf(c)
}

private fun addDays(iso: String, n: Int): String = try {
    LocalDate.parse(iso).plusDays(n.toLong()).toString()
} catch (_: Exception) { iso }

private fun isoOf(c: Calendar): String {
    val y = c.get(Calendar.YEAR)
    val m = (c.get(Calendar.MONTH) + 1).toString().padStart(2, '0')
    val d = c.get(Calendar.DAY_OF_MONTH).toString().padStart(2, '0')
    return "$y-$m-$d"
}
