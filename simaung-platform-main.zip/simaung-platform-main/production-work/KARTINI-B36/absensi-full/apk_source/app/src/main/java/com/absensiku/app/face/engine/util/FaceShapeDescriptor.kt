package com.absensiku.app.face.engine.util

import android.graphics.PointF
import com.absensiku.app.face.engine.model.FaceContourType
import com.absensiku.app.face.engine.model.FaceResult
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Deskriptor bentuk wajah (shape descriptor) — peningkat diskriminasi.
 *
 * Fitur rasio jarak landmark bersifat global dan sering mirip antar orang
 * berbeda (kembar proporsi, beda gender, pemakai kacamata). Untuk menekannya,
 * kita menambahkan *profil radial kontur wajah*:
 *
 *   1. Ambil kontur FACE (keliling wajah) dalam KOORDINAT TERNORMALISASI
 *      relatif terhadap centroid bounding-box (skala independen).
 *   2. Sampling ke [N] bin sudut (0..2π): untuk tiap bin sudut, ambil radius
 *      maksimum titik kontur. Radius dinormalisasi (mean → 100) agar scale-free.
 *   3. Hasil: vektor [N] nilai bulat 0..255 = "sidik jari" bentuk wajah.
 *
 * Vektor ini sensitif terhadap lekuk pipi, dagu, dan rahang — berbeda nyata
 * antar individu, namun tahan terhadap perubahan ekspresi ringan karena
 * memakai radius maksimum (selubung luar wajah).
 */
object FaceShapeDescriptor {

    /** Jumlah bin sudut. 36 = resolusi 10° (cukup detail, tetap ringkas). */
    const val BINS = 36

    /** Sub-sampling kontur untuk kecepatan (maks titik yang dipakai). */
    private const val MAX_POINTS = 96

    /**
     * Menghasilkan profil radial [BINS] sesuai kategori [keyPrefix]
     * (`shape_` untuk kontur wajah).
     * Mengembalikan map kosong bila kontur wajah tidak cukup.
     */
    fun radialProfile(face: FaceResult, keyPrefix: String = "shape_"): Map<String, Int> {
        val contour = face.contours[FaceContourType.FACE]
        if (contour == null || contour.size < 6) return emptyMap()

        // 1) Sub-sampling seragam.
        val step = (contour.size / MAX_POINTS).coerceAtLeast(1)
        val pts = ArrayList<PointF>(MAX_POINTS)
        var i = 0
        while (i < contour.size) {
            pts.add(contour[i])
            i += step
        }
        if (pts.size < 6) return emptyMap()

        // 2) Centroid.
        var cx = 0f
        var cy = 0f
        for (p in pts) { cx += p.x; cy += p.y }
        cx /= pts.size
        cy /= pts.size

        // 3) Radius maksimum per bin sudut.
        val bins = DoubleArray(BINS) { 0.0 }
        for (p in pts) {
            val dx = (p.x - cx).toDouble()
            val dy = (p.y - cy).toDouble()
            val r = sqrt(dx * dx + dy * dy)
            var theta = atan2(dy, dx)          // -π..π
            if (theta < 0) theta += 2 * Math.PI
            val bin = ((theta / (2 * Math.PI)) * BINS).toInt().coerceIn(0, BINS - 1)
            if (r > bins[bin]) bins[bin] = r
        }

        // 4) Tahan celah: isi bin kosong dengan interpolasi antar tetangga berisi.
        val filled = fillGaps(bins)
        val mean = filled.average()
        if (mean <= 0.0) return emptyMap()

        // 5) Normalisasi (mean → 100) & kuantisasi.
        val out = LinkedHashMap<String, Int>(BINS)
        for (k in 0 until BINS) {
            out["$keyPrefix$k"] = GeoUtils.bounded(filled[k] / mean * 100.0)
        }
        return out
    }

    /** Isi bin bernilai 0 dengan rata-rata tetangga terdekat yang terisi. */
    private fun fillGaps(bins: DoubleArray): DoubleArray {
        val n = bins.size
        val out = bins.copyOf()
        for (idx in 0 until n) {
            if (out[idx] > 0.0) continue
            var before = -1
            for (j in 1..n) {
                val k = (idx - j + n) % n
                if (bins[k] > 0.0) { before = k; break }
            }
            var after = -1
            for (j in 1..n) {
                val k = (idx + j) % n
                if (bins[k] > 0.0) { after = k; break }
            }
            out[idx] = when {
                before >= 0 && after >= 0 -> (bins[before] + bins[after]) / 2.0
                before >= 0 -> bins[before]
                after >= 0 -> bins[after]
                else -> 0.0
            }
        }
        return out
    }
}
