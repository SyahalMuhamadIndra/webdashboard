package com.absensiku.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.R
import com.absensiku.app.ui.theme.BrandingPalette
import com.absensiku.app.ui.theme.KartiniColors

@Composable
fun BrandLogo(size: Dp, onDark: Boolean = false, modifier: Modifier = Modifier) {
    // B67 — logo dinamis: pakai unggahan/tautan dari panel admin bila ada,
    // jika tidak pakai logo bawaan aplikasi.
    val src = if (onDark) BrandingPalette.logoWhiteSrc else BrandingPalette.logoSrc
    val res = if (onDark) R.drawable.ic_logo_kartini_white else R.drawable.ic_logo_kartini
    BrandImage(
        src = src,
        fallbackRes = res,
        contentDescription = BrandingPalette.brandName,
        modifier = modifier.size(size),
        contentScale = ContentScale.Fit,
    )
}

@Composable
fun BrandLogoCard(size: Dp, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(size / 4),
        color = Color.White,
        shadowElevation = 6.dp,
        modifier = modifier.size(size),
    ) {
        Box(modifier = Modifier.padding(size * 0.14f), contentAlignment = Alignment.Center) {
            BrandLogo(size = size * 0.72f)
        }
    }
}

@Composable
fun BrandTopBar(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    listOf(KartiniColors.BrandGreenDeep, KartiniColors.BrandGreen)
                )
            )
            .padding(start = 18.dp, end = 12.dp, top = 18.dp, bottom = 18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = Color.White, modifier = Modifier.size(44.dp)) {
                Box(modifier = Modifier.padding(7.dp), contentAlignment = Alignment.Center) {
                    BrandLogo(size = 30.dp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(subtitle, color = Color.White.copy(alpha = 0.78f), fontSize = 12.sp)
            }
            if (action != null) action()
        }
    }
}

@Composable
fun BrandAccentBar(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(3.dp)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        KartiniColors.BrandGreen,
                        KartiniColors.BrandGreen,
                        KartiniColors.BrandOrange,
                        KartiniColors.BrandOrange,
                    )
                )
            )
    )
}
