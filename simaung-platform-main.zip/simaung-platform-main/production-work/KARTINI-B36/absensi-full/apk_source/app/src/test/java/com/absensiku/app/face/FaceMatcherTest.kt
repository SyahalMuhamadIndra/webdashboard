package com.absensiku.app.face

import com.absensiku.app.face.engine.core.FaceMatcher
import com.absensiku.app.face.engine.core.FaceMatchingService
import com.absensiku.app.face.engine.util.FaceTemplateExtractor
import com.absensiku.app.face.engine.util.FaceTemplateMatcher
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit test mesin verifikasi wajah: template tektur v5 (utama) + geometris v4.
 */
class FaceMatcherTest {

    /** Template v5 deterministik (grid 32x32, array int). */
    private fun template(seed: Int, noise: Int = 0): String {
        val n = FaceTemplateExtractor.GRID * FaceTemplateExtractor.GRID
        val arr = org.json.JSONArray()
        var s = seed.toLong() and 0xFFFFFFFFL
        for (i in 0 until n) {
            s = (s * 1664525 + 1013904223) and 0xFFFFFFFFL
            val base = (Math.sin(i * 0.35 + seed) * 60 + 128)
            val nz = if (noise > 0) ((s % (2 * noise + 1)) - noise).toInt() else 0
            arr.put((base + nz).toInt().coerceIn(0, 255))
        }
        val root = JSONObject()
        root.put("v", 5)
        root.put("t", arr)
        return root.toString()
    }

    private val geoKeys = listOf(
        "eye_l_nose", "eye_r_nose", "ear_width_ratio", "cheek_width_ratio",
        "eye_l_cheek_l", "eye_r_cheek_r", "mouth_width_eye_ratio",
        "mouth_width_nose_ratio", "mouth_height_width_ratio", "nose_chin_mouth_ratio",
        "face_aspect_ratio", "nose_top_rel", "nose_bottom_rel", "nose_width_rel",
        "eye_l_width_rel", "eye_r_width_rel", "brow_l_rel", "brow_r_rel",
        "lip_upper_width_rel", "lip_lower_width_rel",
    )

    private fun geoSignature(geoBase: Int, shapeBase: Int, jitter: Int = 0): String {
        val f = JSONObject()
        geoKeys.forEachIndexed { i, k -> f.put(k, geoBase + i + jitter) }
        for (b in 0 until 36) f.put("shape_$b", shapeBase + b + jitter)
        val root = JSONObject()
        root.put("v", 4)
        root.put("f", f)
        return root.toString()
    }

    // ---------- TEMPLATE v5 (utama) ----------

    @Test
    fun template_identical_scoresHundred() {
        val t = template(1234)
        assertTrue(FaceTemplateMatcher.matchScore(t, t) >= 99.0)
    }

    @Test
    fun template_smallNoise_stillAboveThreshold() {
        val a = template(1234, 0)
        val b = template(1234, 8)
        val s = FaceTemplateMatcher.matchScore(a, b)
        assertTrue("skor=$s", s >= FaceMatchingService.TPL_MATCH)
    }

    @Test
    fun template_differentPerson_isRejected() {
        val a = template(10)
        val b = template(9999)
        val s = FaceTemplateMatcher.matchScore(a, b)
        assertTrue("skor=$s", s < FaceMatchingService.TPL_MATCH)
    }

    @Test
    fun isTemplate_distinguishesV5FromV4() {
        assertTrue(FaceTemplateExtractor.isTemplate(template(1)))
        assertFalse(FaceTemplateExtractor.isTemplate(geoSignature(80, 90)))
    }

    // ---------- GEOMETRIS v4 ----------

    @Test
    fun geo_identical_scoresHundred_andMatches() {
        val a = geoSignature(80, 90)
        assertEquals(100.0, FaceMatcher.similarityScore(a, a), 0.001)
        assertTrue(FaceMatcher.isMatchDecision(a, a, 85))
    }

    @Test
    fun geo_similarGeometryDifferentShape_isRejected() {
        val enrolled = geoSignature(80, 90)
        val impostor = geoSignature(80, 165)
        assertFalse(FaceMatcher.isMatchDecision(impostor, enrolled, 85))
    }

    @Test
    fun legacySignature_detected() {
        assertTrue(FaceMatcher.isLegacySignature("[1,2,3]"))
        assertTrue(FaceMatcher.isLegacySignature("{\"v\":2,\"f\":[1,2]}"))
        assertFalse(FaceMatcher.isLegacySignature(geoSignature(80, 90)))
    }

    @Test
    fun splitSamples_roundTrip() {
        val list = listOf(template(1), template(2))
        assertEquals(list, FaceMatcher.splitSamples(FaceMatcher.joinSamples(list)))
    }
}
