package com.absensiku.app.reminder

import android.content.Context

/**
 * Preferensi Pengingat Absen (reminder masuk/pulang).
 *
 * Disimpan lokal di perangkat. Default AKTIF agar karyawan langsung dibantu
 * mengingat jam absen sesuai shift-nya.
 */
class ReminderPrefs(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("reminder_prefs", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, true)
        set(v) = prefs.edit().putBoolean(KEY_ENABLED, v).apply()

    /** Berapa menit sebelum jam masuk pengingat "absensi masuk" berbunyi. */
    var leadMinutes: Int
        get() = prefs.getInt(KEY_LEAD, 15)
        set(v) = prefs.edit().putInt(KEY_LEAD, v.coerceIn(0, 120)).apply()

    /** Ingatkan juga saat jam pulang tiba. */
    var remindCheckout: Boolean
        get() = prefs.getBoolean(KEY_CHECKOUT, true)
        set(v) = prefs.edit().putBoolean(KEY_CHECKOUT, v).apply()

    /** Berapa menit SETELAH jam pulang pengingat pulang berbunyi. */
    var checkoutLeadMinutes: Int
        get() = prefs.getInt(KEY_CHECKOUT_LEAD, 0)
        set(v) = prefs.edit().putInt(KEY_CHECKOUT_LEAD, v.coerceIn(0, 120)).apply()

    /** Simpan jam shift terakhir (HH:mm) agar alarm bisa dijadwalkan ulang. */
    fun saveShift(startHm: String?, endHm: String?) {
        prefs.edit()
            .putString(KEY_SHIFT_START, startHm)
            .putString(KEY_SHIFT_END, endHm)
            .apply()
    }

    fun lastStartHm(): String? = prefs.getString(KEY_SHIFT_START, null)
    fun lastEndHm(): String? = prefs.getString(KEY_SHIFT_END, null)

    companion object {
        private const val KEY_ENABLED = "reminder_enabled"
        private const val KEY_LEAD = "reminder_lead_minutes"
        private const val KEY_CHECKOUT = "reminder_remind_checkout"
        private const val KEY_CHECKOUT_LEAD = "reminder_checkout_lead_minutes"
        private const val KEY_SHIFT_START = "reminder_shift_start"
        private const val KEY_SHIFT_END = "reminder_shift_end"
    }
}
