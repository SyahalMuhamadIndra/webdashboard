package com.absensiku.app.screens.ops

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.DeliveryItem
import com.absensiku.app.api.DeliveryNote
import com.absensiku.app.api.TripItem
import com.absensiku.app.location.LocationResult
import com.absensiku.app.location.LocationValidator
import com.absensiku.app.ui.components.OpsBadge
import com.absensiku.app.ui.components.OpsCard
import com.absensiku.app.ui.components.OpsEmpty
import com.absensiku.app.ui.components.OpsGhostButton
import com.absensiku.app.ui.components.OpsKeyValue
import com.absensiku.app.ui.components.OpsPrimaryButton
import com.absensiku.app.ui.components.OpsSectionTitle
import com.absensiku.app.ui.components.OpsTextField
import com.absensiku.app.ui.components.OpsTopBar
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.launch

/**
 * Driver (B11): tracking perjalanan + pembuatan surat jalan.
 * Lokasi diambil dari LocationValidator dan dikirim sebagai posisi terakhir.
 */
@Composable
fun DriverTripsScreen(
    api: ApiClient,
    locationValidator: LocationValidator,
    showMessage: (String) -> Unit,
    onBack: () -> Unit,
) {
    var mode by remember { mutableStateOf("list") }
    var trips by remember { mutableStateOf<List<TripItem>>(emptyList()) }
    var busy by remember { mutableStateOf(true) }
    var current by remember { mutableStateOf<TripItem?>(null) }
    val scope = rememberCoroutineScope()

    fun load() {
        scope.launch {
            busy = true
            try { trips = api.listTrips(mine = true) }
            catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { showMessage(e.message ?: "Gagal memuat perjalanan") }
            busy = false
        }
    }
    LaunchedEffect(Unit) { load() }

    Box(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        Column(modifier = Modifier.fillMaxSize()) {
            OpsTopBar(
                title = when (mode) {
                    "formTrip" -> "Perjalanan Baru"
                    "tripDetail" -> "Detail Perjalanan"
                    "formNote" -> "Buat Surat Jalan"
                    else -> "Perjalanan & Surat Jalan"
                },
                subtitle = "Tracking perjalanan & surat jalan",
                onBack = {
                    when (mode) {
                        "list" -> onBack()
                        "tripDetail" -> mode = "list"
                        else -> mode = if (current != null) "tripDetail" else "list"
                    }
                },
            )
            if (busy && mode == "list") {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp), color = KartiniColors.BrandGreen)
            }
            when (mode) {
                "formTrip" -> TripForm(
                    api = api,
                    showMessage = showMessage,
                    onDone = { mode = "list"; load() },
                    onCancel = { mode = "list" },
                )
                "tripDetail" -> current?.let { tr ->
                    TripDetail(
                        api = api,
                        trip = tr,
                        locationValidator = locationValidator,
                        showMessage = showMessage,
                        onCreateNote = { mode = "formNote" },
                        onChanged = { load() },
                        onGoList = { mode = "list" },
                    )
                } ?: run { mode = "list" }
                "formNote" -> current?.let { tr ->
                    NoteForm(
                        api = api,
                        trip = tr,
                        showMessage = showMessage,
                        onDone = { mode = "tripDetail" },
                        onCancel = { mode = "tripDetail" },
                    )
                } ?: run { mode = "list" }
                else -> Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp, vertical = 16.dp),
                ) {
                    OpsPrimaryButton(text = "Mulai Perjalanan Baru", onClick = { mode = "formTrip" })
                    Spacer(Modifier.height(18.dp))
                    OpsSectionTitle("Perjalanan Saya (${trips.size})")
                    Spacer(Modifier.height(12.dp))
                    if (trips.isEmpty()) {
                        OpsEmpty("Belum ada perjalanan. Mulai perjalanan baru di atas.")
                    } else {
                        trips.forEach { t ->
                            TripRowItem(t) { current = t; mode = "tripDetail" }
                            Spacer(Modifier.height(10.dp))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
private fun TripRowItem(t: TripItem, onClick: () -> Unit) {
    OpsCard {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text(t.code ?: "Perjalanan", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = KartiniColors.OnSurface)
                Text("Tujuan: ${t.destination ?: "-"}", fontSize = 12.sp, color = KartiniColors.OnSurfaceMuted)
            }
            OpsBadge(t.status)
        }
        if (!t.vehicle.isNullOrBlank()) {
            Spacer(Modifier.height(6.dp))
            OpsKeyValue("Kendaraan", t.vehicle!!)
        }
        Spacer(Modifier.height(10.dp))
        OpsGhostButton(text = "Buka Detail", onClick = onClick, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun TripForm(
    api: ApiClient,
    showMessage: (String) -> Unit,
    onDone: () -> Unit,
    onCancel: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var destination by remember { mutableStateOf("") }
    var vehicle by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        OpsSectionTitle("Rincian Perjalanan")
        Spacer(Modifier.height(12.dp))
        OpsTextField(destination, { destination = it }, "Tujuan perjalanan *")
        Spacer(Modifier.height(10.dp))
        OpsTextField(vehicle, { vehicle = it }, "Kendaraan (mis. L 1234 AB)")
        Spacer(Modifier.height(10.dp))
        OpsTextField(note, { note = it }, "Catatan")
        Spacer(Modifier.height(16.dp))
        OpsPrimaryButton(
            text = if (saving) "Memulai…" else "Mulai Perjalanan",
            enabled = !saving,
            onClick = {
                if (destination.isBlank()) { showMessage("Tujuan wajib diisi"); return@OpsPrimaryButton }
                saving = true
                scope.launch {
                    try {
                        api.createTrip(destination.trim(), vehicle.ifBlank { null }, note.ifBlank { null })
                        showMessage("Perjalanan dimulai")
                        onDone()
                    } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                    catch (e: Exception) { showMessage(e.message ?: "Gagal memulai perjalanan") }
                    saving = false
                }
            },
        )
        Spacer(Modifier.height(10.dp))
        OpsGhostButton(text = "Batal", onClick = onCancel, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun TripDetail(
    api: ApiClient,
    trip: TripItem,
    locationValidator: LocationValidator,
    showMessage: (String) -> Unit,
    onCreateNote: () -> Unit,
    onChanged: () -> Unit,
    onGoList: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var notes by remember { mutableStateOf<List<DeliveryNote>>(emptyList()) }
    var sendingLoc by remember { mutableStateOf(false) }

    fun loadNotes() {
        scope.launch {
            try { notes = api.listDeliveryNotes(trip.id) }
            catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { showMessage(e.message ?: "Gagal memuat surat jalan") }
        }
    }
    LaunchedEffect(trip.id) { loadNotes() }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        OpsCard {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(trip.code ?: "Perjalanan", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold,
                    color = KartiniColors.OnSurface, modifier = Modifier.weight(1f))
                OpsBadge(trip.status)
            }
            Spacer(Modifier.height(8.dp))
            OpsKeyValue("Driver", trip.driverName ?: "-")
            OpsKeyValue("Tujuan", trip.destination ?: "-")
            OpsKeyValue("Kendaraan", trip.vehicle ?: "-")
            if (!trip.note.isNullOrBlank()) OpsKeyValue("Catatan", trip.note!!)
            if (trip.lastLat != null && trip.lastLng != null) {
                OpsKeyValue("Posisi", String.format(java.util.Locale.US, "%.5f, %.5f", trip.lastLat, trip.lastLng))
            }
        }
        Spacer(Modifier.height(14.dp))

        if (trip.status != "COMPLETED" && trip.status != "CANCELLED") {
            OpsSectionTitle("Perbarui Status")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatusBtn("Tiba", enabled = trip.status != "ARRIVED") {
                    scope.launch { sendStatus(api, trip.id, "ARRIVED", showMessage) { onChanged() } }
                }
                StatusBtn("Selesai", enabled = true) {
                    scope.launch { sendStatus(api, trip.id, "COMPLETED", showMessage) { onChanged() } }
                }
                StatusBtn("Batal", enabled = true) {
                    scope.launch { sendStatus(api, trip.id, "CANCELLED", showMessage) { onChanged() } }
                }
            }
            Spacer(Modifier.height(10.dp))
            OpsGhostButton(
                text = if (sendingLoc) "Mengirim lokasi…" else "Kirim Lokasi Terkini",
                onClick = {
                    sendingLoc = true
                    scope.launch {
                        try {
                            when (val loc = locationValidator.getCurrentLocation()) {
                                is LocationResult.Success -> {
                                    api.sendTripLocation(trip.id, loc.latitude, loc.longitude)
                                    showMessage("Lokasi terkirim")
                                }
                                else -> showMessage("Lokasi tidak tersedia. Cek GPS & izin.")
                            }
                        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                        catch (e: Exception) { showMessage(e.message ?: "Gagal mengirim lokasi") }
                        sendingLoc = false
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
        }

        OpsSectionTitle("Surat Jalan (${notes.size})")
        Spacer(Modifier.height(10.dp))
        OpsPrimaryButton(text = "Buat Surat Jalan", onClick = onCreateNote)
        Spacer(Modifier.height(10.dp))
        if (notes.isEmpty()) {
            OpsEmpty("Belum ada surat jalan untuk perjalanan ini.")
        } else {
            notes.forEach { n ->
                OpsCard {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(n.code ?: "Surat Jalan", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = KartiniColors.OnSurface)
                            Text("Penerima: ${n.recipientName ?: "-"}", fontSize = 12.sp, color = KartiniColors.OnSurfaceMuted)
                        }
                        OpsBadge(n.status)
                    }
                    Spacer(Modifier.height(6.dp))
                    OpsKeyValue("Alamat", n.address ?: "-")
                    OpsKeyValue("Jumlah item", "${n.totalItems}")
                    if (n.status.equals("ISSUED", true)) {
                        Spacer(Modifier.height(8.dp))
                        OpsGhostButton(text = "Tandai Terkirim", onClick = {
                            scope.launch {
                                try { api.markDeliveryDelivered(n.id); showMessage("Ditandai terkirim"); loadNotes() }
                                catch (e: kotlinx.coroutines.CancellationException) { throw e }
                                catch (e: Exception) { showMessage(e.message ?: "Gagal") }
                            }
                        }, modifier = Modifier.fillMaxWidth())
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        OpsGhostButton(text = "Kembali ke Daftar", onClick = onGoList, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.StatusBtn(
    label: String, enabled: Boolean, onClick: () -> Unit,
) {
    TextButton(onClick = { if (enabled) onClick() }, enabled = enabled, modifier = Modifier.weight(1f)) {
        Text(label, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
    }
}

private suspend fun sendStatus(
    api: ApiClient, tripId: String, status: String,
    showMessage: (String) -> Unit, onChanged: () -> Unit,
) {
    try {
        api.updateTripStatus(tripId, status, null, null, null)
        showMessage("Status diperbarui: $status")
        onChanged()
    } catch (e: kotlinx.coroutines.CancellationException) { throw e }
    catch (e: Exception) { showMessage(e.message ?: "Gagal memperbarui status") }
}

@Composable
private fun NoteForm(
    api: ApiClient,
    trip: TripItem,
    showMessage: (String) -> Unit,
    onDone: () -> Unit,
    onCancel: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var recipient by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    // Baris item dinamis: nama, qty, satuan.
    val rows = remember { mutableStateListOf(Triple("", "", "")) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        OpsSectionTitle("Data Penerima")
        Spacer(Modifier.height(12.dp))
        OpsTextField(recipient, { recipient = it }, "Nama penerima / tujuan")
        Spacer(Modifier.height(10.dp))
        OpsTextField(address, { address = it }, "Alamat")
        Spacer(Modifier.height(10.dp))
        OpsTextField(note, { note = it }, "Catatan")
        Spacer(Modifier.height(16.dp))
        OpsSectionTitle("Daftar Barang")
        Spacer(Modifier.height(10.dp))
        rows.forEachIndexed { idx, row ->
            OpsCard {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("Barang ${idx + 1}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = KartiniColors.OnSurface, modifier = Modifier.weight(1f))
                    if (rows.size > 1) {
                        TextButton(onClick = { rows.removeAt(idx) }) { Text("Hapus", fontSize = 12.sp) }
                    }
                }
                OpsTextField(row.first, { rows[idx] = Triple(it, row.second, row.third) }, "Nama barang")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OpsTextField(
                        row.second, { rows[idx] = Triple(row.first, it.filter { c -> c.isDigit() }, row.third) },
                        "Qty", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f),
                    )
                    OpsTextField(row.third, { rows[idx] = Triple(row.first, row.second, it) }, "Satuan", modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        OpsGhostButton(text = "+ Tambah Baris", onClick = { rows.add(Triple("", "", "")) }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        OpsPrimaryButton(
            text = if (saving) "Menyimpan…" else "Simpan Surat Jalan",
            enabled = !saving,
            onClick = {
                val items = rows.mapNotNull { r ->
                    val nm = r.first.trim()
                    if (nm.isEmpty()) null
                    else DeliveryItem(productId = null, productName = nm, sku = null, qty = r.second.toIntOrNull() ?: 0, unit = r.third.ifBlank { null })
                }
                if (items.isEmpty()) { showMessage("Isi minimal satu barang"); return@OpsPrimaryButton }
                saving = true
                scope.launch {
                    try {
                        api.createDeliveryNote(trip.id, recipient.ifBlank { null }, address.ifBlank { null }, note.ifBlank { null }, items)
                        showMessage("Surat jalan dibuat")
                        onDone()
                    } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                    catch (e: Exception) { showMessage(e.message ?: "Gagal menyimpan surat jalan") }
                    saving = false
                }
            },
        )
        Spacer(Modifier.height(10.dp))
        OpsGhostButton(text = "Batal", onClick = onCancel, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
    }
}
