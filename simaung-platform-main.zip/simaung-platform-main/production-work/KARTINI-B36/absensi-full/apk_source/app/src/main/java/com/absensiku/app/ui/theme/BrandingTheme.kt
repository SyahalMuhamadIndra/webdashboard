package com.absensiku.app.ui.theme

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import org.json.JSONObject

/**
 * B67 — DESAIN DINAMIS PER LOKASI KANTOR (Level 1 + Level 2).
 *
 * Satu APK yang tampilannya berubah mengikuti LOKASI KANTOR karyawan yang login.
 * Server mengirim blok `theme` di GET /api/config (lihat resolveBranding() di
 * backend/src/server.ts). Blok itu dipetakan ke [AppTheme], lalu dipakai untuk
 * mengisi [BrandingPalette].
 *
 * KartiniColors (Theme.kt) membaca [BrandingPalette] lewat getter, sehingga
 * SELURUH aplikasi (443 pemakaian warna) otomatis mengikuti desain baru TANPA
 * perlu mengubah satu pun pemanggilan warna.
 *
 * Level 1 : warna (7) + nama merek + nama tampilan + slogan.
 * Level 2 : logo, logo putih, gambar header, splash, latar login.
 *
 * Catatan Android: nama & ikon di layar utama HP TIDAK dapat diubah dari jarak
 * jauh tanpa memasang ulang APK — itu batasan sistem, bukan bug.
 */
data class AppTheme(
    val brandName: String? = null,
    val displayName: String? = null,
    val tagline: String? = null,
    val primaryColor: String? = null,
    val primaryDarkColor: String? = null,
    val accentColor: String? = null,
    val bgColor: String? = null,
    val surfaceColor: String? = null,
    val textColor: String? = null,
    val mutedColor: String? = null,
    val logoUrl: String? = null,
    val logoBase64: String? = null,
    val logoWhiteUrl: String? = null,
    val logoWhiteBase64: String? = null,
    val headerImageUrl: String? = null,
    val splashImageUrl: String? = null,
    val loginImageUrl: String? = null,
) {
    /** Sumber logo: unggahan (base64) menang atas tautan. */
    val logoSource: String? get() = logoBase64 ?: logoUrl
    val logoWhiteSource: String? get() = logoWhiteBase64 ?: logoWhiteUrl
}

/**
 * Palet + identitas yang SEDANG aktif. Nilai awal = palet resmi Simaung Corporation,
 * jadi bila server belum mengirim `theme` (atau sedang offline), tampilan tetap
 * sama persis seperti sebelumnya — tidak ada risiko layar rusak.
 *
 * Memakai Compose state: begitu [applyTheme] dipanggil, semua komponen yang
 * memakai warna akan menggambar ulang otomatis.
 */
object BrandingPalette {

    // ---- Warna (Level 1) ----
    var primary: Color by mutableStateOf(Color(0xFF232935))       // hijau logo
    var primaryDark: Color by mutableStateOf(Color(0xFF161B24))   // hijau tua (header)
    var primaryDarkest: Color by mutableStateOf(Color(0xFF11151D))
    var primarySoft: Color by mutableStateOf(Color(0xFFE9EDF3))   // hijau muda (latar ikon)
    var accent: Color by mutableStateOf(Color(0xFF486380))        // oranye logo
    var accentDeep: Color by mutableStateOf(Color(0xFF354D68))
    var accentSoft: Color by mutableStateOf(Color(0xFFE8EFF7))
    var bg: Color by mutableStateOf(Color(0xFFF3F5F8))            // latar cream
    var surface: Color by mutableStateOf(Color(0xFFFFFFFF))
    var bgDeep: Color by mutableStateOf(Color(0xFFE5EAF1))
    var onSurface: Color by mutableStateOf(Color(0xFF1A1A1A))
    var onSurfaceMuted: Color by mutableStateOf(Color(0xFF6C6C6C))
    var outline: Color by mutableStateOf(Color(0xFFDCE2EA))
    var divider: Color by mutableStateOf(Color(0xFFEEF1F5))

    // ---- Identitas (Level 1) ----
    var brandName: String by mutableStateOf("Simaung Corporation")
    var displayName: String by mutableStateOf("Simaung Corporation")
    var tagline: String by mutableStateOf("Absensi Karyawan")

    // ---- Gambar (Level 2) — data URI (base64) atau tautan http(s) ----
    var logoSrc: String? by mutableStateOf(null)
    var logoWhiteSrc: String? by mutableStateOf(null)
    var headerSrc: String? by mutableStateOf(null)
    var splashSrc: String? by mutableStateOf(null)
    var loginSrc: String? by mutableStateOf(null)

    /** True bila ada desain khusus (bukan bawaan) yang sedang aktif. */
    var hasCustomDesign: Boolean by mutableStateOf(false)
        private set

    /** Terapkan desain dari server. Field null = pertahankan nilai bawaan. */
    fun applyTheme(t: AppTheme) {
        primary = parseHexColor(t.primaryColor, primary)
        primaryDark = parseHexColor(t.primaryDarkColor, primaryDark)
        // Turunan yang tidak dikirim server dihitung dari warna utama agar tetap
        // selaras (mis. hijau tergelap = versi gelap dari warna utama).
        primaryDarkest = darken(primaryDark, 0.45f)
        primarySoft = lighten(primary, 0.86f)
        accent = parseHexColor(t.accentColor, accent)
        accentDeep = darken(accent, 0.25f)
        accentSoft = lighten(accent, 0.86f)
        bg = parseHexColor(t.bgColor, bg)
        surface = parseHexColor(t.surfaceColor, surface)
        bgDeep = darken(bg, 0.06f)
        onSurface = parseHexColor(t.textColor, onSurface)
        onSurfaceMuted = parseHexColor(t.mutedColor, onSurfaceMuted)
        outline = darken(bg, 0.12f)
        divider = darken(bg, 0.07f)

        t.brandName?.takeIf { it.isNotBlank() }?.let { brandName = it }
        t.displayName?.takeIf { it.isNotBlank() }?.let { displayName = it }
        t.tagline?.takeIf { it.isNotBlank() }?.let { tagline = it }

        logoSrc = t.logoSource
        logoWhiteSrc = t.logoWhiteSource
        headerSrc = t.headerImageUrl
        splashSrc = t.splashImageUrl
        loginSrc = t.loginImageUrl

        hasCustomDesign = true
    }

    /** Kembalikan ke palet resmi Simaung Corporation. */
    fun reset() {
        primary = Color(0xFF232935); primaryDark = Color(0xFF161B24)
        primaryDarkest = Color(0xFF11151D); primarySoft = Color(0xFFE9EDF3)
        accent = Color(0xFF486380); accentDeep = Color(0xFF354D68)
        accentSoft = Color(0xFFE8EFF7)
        bg = Color(0xFFF3F5F8); surface = Color(0xFFFFFFFF); bgDeep = Color(0xFFE5EAF1)
        onSurface = Color(0xFF1A1A1A); onSurfaceMuted = Color(0xFF6C6C6C)
        outline = Color(0xFFDCE2EA); divider = Color(0xFFEEF1F5)
        brandName = "Simaung Corporation"; displayName = "Simaung Corporation"
        tagline = "Masuk untuk melakukan absensi"
        logoSrc = null; logoWhiteSrc = null; headerSrc = null; splashSrc = null; loginSrc = null
        hasCustomDesign = false
    }

    // ---------- Simpanan lokal (agar desain langsung benar saat app dibuka) ----------
    private const val PREFS = "branding_prefs"
    private const val KEY_RAW = "theme_json"

    fun saveRaw(ctx: Context, raw: JSONObject?) {
        runCatching {
            ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_RAW, raw?.toString() ?: "").apply()
        }
    }

    fun loadFromPrefs(ctx: Context) {
        val raw = runCatching {
            ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_RAW, null)
        }.getOrNull()
        if (raw.isNullOrBlank()) return
        runCatching { applyTheme(parseAppTheme(JSONObject(raw))) }
    }
}

// ==================== Utilitas warna ====================

/** "#036D19" / "036D19" / "#ABC" -> Color. Gagal = fallback (tidak pernah crash). */
fun parseHexColor(v: String?, fallback: Color): Color {
    if (v.isNullOrBlank()) return fallback
    var s = v.trim().removePrefix("#")
    if (s.length == 3) s = s.map { "$it$it" }.joinToString("")
    if (s.length == 6) s = "FF$s"
    if (s.length != 8) return fallback
    return try {
        Color(s.toLong(16))
    } catch (_: Exception) {
        fallback
    }
}

/** Versi lebih gelap dari sebuah warna (untuk garis/aksen turunan). */
private fun darken(c: Color, amount: Float): Color = Color(
    red = c.red * (1f - amount),
    green = c.green * (1f - amount),
    blue = c.blue * (1f - amount),
    alpha = c.alpha,
)

/** Versi lebih terang dari sebuah warna (untuk latar ikon/badge). */
private fun lighten(c: Color, amount: Float): Color = Color(
    red = c.red + (1f - c.red) * amount,
    green = c.green + (1f - c.green) * amount,
    blue = c.blue + (1f - c.blue) * amount,
    alpha = c.alpha,
)

/** Ubah objek "theme" dari server menjadi [AppTheme]. */
internal fun parseAppTheme(o: JSONObject?): AppTheme {
    if (o == null) return AppTheme()
    fun s(k: String): String? = o.optString(k, "").takeIf { it.isNotBlank() && !o.isNull(k) }
    return AppTheme(
        brandName = s("brandName"),
        displayName = s("displayName"),
        tagline = s("tagline"),
        primaryColor = s("primaryColor"),
        primaryDarkColor = s("primaryDarkColor"),
        accentColor = s("accentColor"),
        bgColor = s("bgColor"),
        surfaceColor = s("surfaceColor"),
        textColor = s("textColor"),
        mutedColor = s("mutedColor"),
        logoUrl = s("logoUrl"),
        logoBase64 = s("logoBase64"),
        logoWhiteUrl = s("logoWhiteUrl"),
        logoWhiteBase64 = s("logoWhiteBase64"),
        headerImageUrl = s("headerImageUrl"),
        splashImageUrl = s("splashImageUrl"),
        loginImageUrl = s("loginImageUrl"),
    )
}
