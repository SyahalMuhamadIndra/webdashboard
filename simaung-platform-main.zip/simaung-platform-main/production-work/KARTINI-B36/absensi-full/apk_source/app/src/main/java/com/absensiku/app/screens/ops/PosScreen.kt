package com.absensiku.app.screens.ops

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.MeResponse
import com.absensiku.app.api.OpsProduct
import com.absensiku.app.api.PosCustomer
import com.absensiku.app.api.PosHold
import com.absensiku.app.api.PosSale
import com.absensiku.app.api.PosSaleItem
import com.absensiku.app.api.PosSession
import com.absensiku.app.api.PosSettings
import com.absensiku.app.api.PosSummary
import com.absensiku.app.api.ProductVariant
import com.absensiku.app.ui.components.OpsBadge
import com.absensiku.app.ui.components.OpsCard
import com.absensiku.app.ui.components.OpsEmpty
import com.absensiku.app.ui.components.OpsGhostButton
import com.absensiku.app.ui.components.OpsKeyValue
import com.absensiku.app.ui.components.OpsSectionTitle
import com.absensiku.app.ui.components.OpsTextField
import com.absensiku.app.ui.components.OpsTone
import com.absensiku.app.ui.components.formatRp
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

// ---------- Design system POS: STRUKTUR ala referensi, WARNA = brand Simaung Corporation ----------
private val PosPrimary = KartiniColors.BrandGreen        // hijau brand utama
private val PosPrimaryLight = KartiniColors.Olive        // hijau lebih terang (gradien)
private val PosGold = KartiniColors.BrandOrange          // aksen oranye brand
private val PosGreen = KartiniColors.BrandGreen          // tombol bayar / sukses
private val PosBg = KartiniColors.CreamBg
private val PosText = KartiniColors.OnSurface
private val PosMuted = KartiniColors.OnSurfaceMuted
private val PosBorder = KartiniColors.Outline
private val PosDanger = KartiniColors.StatusBadFg
private val PosSurface = KartiniColors.CreamSurface

/**
 * POS Kasir — struktur & alur mengikuti referensi “Kasir Pro POS”:
 *  - grid produk + tab kategori + pencarian (kartu: ikon kategori, harga, stok, ribbon stok rendah);
 *  - panel “Pesanan” (keranjang) + ringkasan + tombol Bayar;
 *  - modal Pembayaran (metode, uang cepat, uang pas, kembalian);
 *  - struk + bagikan (WhatsApp/email).
 *  WARNA memakai palet resmi Simaung Corporation (hijau/oranye/cream).
 */
@Composable
fun PosScreen(
    api: ApiClient,
    me: MeResponse,
    showMessage: (String) -> Unit,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(true) }
    var session by remember { mutableStateOf<PosSession?>(null) }
    var products by remember { mutableStateOf<List<OpsProduct>>(emptyList()) }
    var summary by remember { mutableStateOf<PosSummary?>(null) }
    var sales by remember { mutableStateOf<List<PosSale>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var sub by remember { mutableStateOf("kasir") } // kasir | tutup | riwayat

    fun load() {
        scope.launch {
            busy = true
            try {
                session = api.getPosSession()
                if (session != null) {
                    products = api.listProducts()
                    summary = api.posSummary()
                    sales = api.listPosSales(mine = true)
                }
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { showMessage(e.message ?: "Gagal memuat data kasir") }
            busy = false
        }
    }
    LaunchedEffect(Unit) { load() }

    Box(modifier = Modifier.fillMaxSize().background(PosBg)) {
        Column(modifier = Modifier.fillMaxSize()) {
            PosTopBar(
                title = "Kasir — Simaung Corporation",
                subtitle = session?.let { "Sesi dibuka ${it.openedAt?.replace("T", " ")?.take(16) ?: ""}" }
                    ?: "Belum ada sesi terbuka",
                onBack = onBack,
            )
            if (busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp), color = PosPrimaryLight)
            }
            val sess = session
            if (sess == null) {
                OpenSessionForm(api = api, showMessage = showMessage, onOpened = { load() })
            } else {
                when (sub) {
                    "tutup" -> CloseSessionForm(
                        api = api, session = sess, showMessage = showMessage,
                        onDone = { sub = "kasir"; load() }, onCancel = { sub = "kasir" },
                    )
                    "riwayat" -> HistoryView(sales = sales, summary = summary, onBack = { sub = "kasir" })
                    else -> KasirView(
                        api = api, me = me, session = sess, products = products,
                        summary = summary, query = query,
                        onQueryChange = { query = it },
                        showMessage = showMessage,
                        onRefresh = { load() },
                        onCloseSession = { sub = "tutup" },
                        onHistory = { sub = "riwayat" },
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------
//  Top bar hijau (gradien brand)
// ------------------------------------------------------------------
@Composable
private fun PosTopBar(title: String, subtitle: String, onBack: (() -> Unit)? = null) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(KartiniColors.BrandGreenDeep, KartiniColors.BrandGreen)))
            .padding(start = 6.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                TextButton(onClick = onBack) { Text("‹", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
            } else {
                Spacer(Modifier.width(10.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                Text(subtitle, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun PosPrimaryButton(text: String, onClick: () -> Unit, enabled: Boolean = true, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = PosPrimary, contentColor = Color.White, disabledContainerColor = PosPrimary.copy(alpha = 0.4f)),
        modifier = modifier.fillMaxWidth().height(50.dp),
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

@Composable
private fun OpenSessionForm(api: ApiClient, showMessage: (String) -> Unit, onOpened: () -> Unit) {
    val scope = rememberCoroutineScope()
    var saving by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 20.dp),
    ) {
        Spacer(Modifier.height(8.dp))
        OpsCard {
            Text("Mulai Melayani", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = PosText)
            Spacer(Modifier.height(6.dp))
            Text(
                "Tekan tombol di bawah untuk mulai sesi kasir. Tidak perlu mengisi kas awal — " +
                    "cukup layani transaksi, sistem mencatat penjualan otomatis.",
                fontSize = 13.sp, color = PosMuted,
            )
        }
        Spacer(Modifier.height(18.dp))
        PosPrimaryButton(
            text = if (saving) "Memulai…" else "Mulai Sesi Kasir",
            enabled = !saving,
            onClick = {
                saving = true
                scope.launch {
                    try {
                        api.openPosSession(0.0)
                        showMessage("Sesi kasir dimulai")
                        onOpened()
                    } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                    catch (e: Exception) { showMessage(e.message ?: "Gagal memulai sesi") }
                    saving = false
                }
            },
        )
    }
}

@Composable
private fun CloseSessionForm(
    api: ApiClient, session: PosSession, showMessage: (String) -> Unit,
    onDone: () -> Unit, onCancel: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var cash by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 20.dp),
    ) {
        OpsSectionTitle("Tutup Sesi Kasir")
        Spacer(Modifier.height(12.dp))
        OpsCard {
            OpsKeyValue("Dibuka", session.openedAt?.replace("T", " ")?.take(16) ?: "-")
            OpsKeyValue("Status", "Sesi kasir aktif")
        }
        Spacer(Modifier.height(14.dp))
        OpsTextField(cash, { cash = it.filter { c -> c.isDigit() } }, "Uang tunai di laci saat ini (Rp)", keyboardType = KeyboardType.Number)
        Spacer(Modifier.height(10.dp))
        OpsTextField(note, { note = it }, "Catatan (opsional)")
        if (result != null) {
            Spacer(Modifier.height(12.dp))
            OpsCard { Text(result!!, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PosPrimary) }
        }
        Spacer(Modifier.height(18.dp))
        PosPrimaryButton(
            text = if (saving) "Menutup…" else "Tutup Sesi",
            enabled = !saving,
            onClick = {
                saving = true
                scope.launch {
                    try {
                        val r = api.closePosSession(cash.toDoubleOrNull() ?: 0.0, note.ifBlank { null })
                        val exp = r.optDouble("expectedCash", 0.0)
                        val diff = r.optDouble("cashDiff", 0.0)
                        result = "Kas seharusnya ${formatRp(exp)} • Selisih ${formatRp(diff)}"
                        showMessage("Sesi kasir ditutup")
                        onDone()
                    } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                    catch (e: Exception) { showMessage(e.message ?: "Gagal menutup sesi") }
                    saving = false
                }
            },
        )
        Spacer(Modifier.height(10.dp))
        OpsGhostButton(text = "Batal", onClick = onCancel, modifier = Modifier.fillMaxWidth())
    }
}

// ------------------------------------------------------------------
//  KASIR — grid produk + tab kategori + panel pesanan
// ------------------------------------------------------------------

/** Baris keranjang POS (mendukung varian & produk tanpa master). */
private data class CartLine(
    val productId: String?,
    val variantId: String?,
    val name: String,
    val variantName: String?,
    val price: Double,
    val qty: Int,
) {
    val key: String get() = "${productId ?: name}::${variantId ?: "-"}"
    val total: Double get() = price * qty
    fun toSaleItem() = PosSaleItem(productId, name + (variantName?.let { " ($it)" } ?: ""), null, price, qty, total, variantId, variantName)
}

@Composable
private fun KasirView(
    api: ApiClient, me: MeResponse, session: PosSession, products: List<OpsProduct>,
    summary: PosSummary?, query: String, onQueryChange: (String) -> Unit,
    showMessage: (String) -> Unit, onRefresh: () -> Unit,
    onCloseSession: () -> Unit, onHistory: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val cart = remember { mutableStateListOf<CartLine>() }
    var discount by remember { mutableStateOf("") }
    var activeCategory by remember { mutableStateOf("all") }
    var showCheckout by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf<JSONObject?>(null) }
    var settings by remember { mutableStateOf<PosSettings?>(null) }
    var customers by remember { mutableStateOf<List<PosCustomer>>(emptyList()) }
    var holds by remember { mutableStateOf<List<PosHold>>(emptyList()) }
    var selectedCustomer by remember { mutableStateOf<PosCustomer?>(null) }
    var showCustomers by remember { mutableStateOf(false) }
    var showHolds by remember { mutableStateOf(false) }
    var scanCode by remember { mutableStateOf("") }
    var scanOpen by remember { mutableStateOf(false) }
    var variantFor by remember { mutableStateOf<Pair<OpsProduct, List<ProductVariant>>?>(null) }

    LaunchedEffect(Unit) {
        try { settings = api.getPosSettings() } catch (e: Exception) { /* pakai default */ }
        try { customers = api.listCustomers() } catch (e: Exception) { /* opsional */ }
        try { holds = api.listHolds() } catch (e: Exception) { /* opsional */ }
    }

    val categories = products.mapNotNull { it.category?.takeIf { c -> c.isNotBlank() } }.distinct()

    val filtered = products.filter { p ->
        val okCat = activeCategory == "all" || p.category == activeCategory
        val okQ = query.isBlank() || p.name.contains(query, true) || (p.sku?.contains(query, true) == true) || (p.barcode?.contains(query) == true)
        okCat && okQ
    }

    val subtotal = cart.sumOf { it.total }
    val disc = discount.toDoubleOrNull() ?: 0.0
    val memberBy = (settings?.let { if (it.taxEnabled) it.taxRate else 0.0 } ?: 0.0)
    val memberPct = selectedCustomer?.discountPercent ?: 0.0
    val memberDiscount = Math.floor(subtotal * memberPct / 100.0)
    val tax = Math.floor((subtotal - disc - memberDiscount).coerceAtLeast(0.0) * memberBy / 100.0)
    val total = (subtotal - disc - memberDiscount + tax).coerceAtLeast(0.0)
    val itemCount = cart.sumOf { it.qty }
    val lowThreshold = settings?.lowStockThreshold ?: 5

    fun addProduct(p: OpsProduct) {
        if (p.stock <= 0) { showMessage("Stok ${p.name} habis"); return }
        // Cek varian (muat dulu); jika ada, tampilkan pilihan.
        scope.launch {
            val vs = try { api.listVariants(p.id) } catch (e: Exception) { emptyList() }
            if (vs.isNotEmpty()) { variantFor = p to vs } else {
                val found = cart.indexOfFirst { it.productId == p.id && it.variantId == null }
                if (found >= 0) cart[found] = cart[found].copy(qty = cart[found].qty + 1)
                else cart.add(CartLine(p.id, null, p.name, null, p.price, 1))
            }
        }
    }
    fun addVariant(p: OpsProduct, v: ProductVariant) {
        val found = cart.indexOfFirst { it.productId == p.id && it.variantId == v.id }
        if (found >= 0) cart[found] = cart[found].copy(qty = cart[found].qty + 1)
        else cart.add(CartLine(p.id, v.id, p.name, v.name, v.price, 1))
    }
    fun changeQty(key: String, delta: Int) {
        val i = cart.indexOfFirst { it.key == key }
        if (i < 0) return
        val n = cart[i].qty + delta
        if (n <= 0) cart.removeAt(i) else cart[i] = cart[i].copy(qty = n)
    }

    val r = receipt
    if (r != null) {
        ReceiptDialog(
            code = r.optString("code"),
            subtotal = r.optDouble("subtotal", 0.0),
            discount = r.optDouble("discount", 0.0),
            memberDiscount = r.optDouble("memberDiscount", 0.0),
            tax = r.optDouble("tax", 0.0),
            total = r.optDouble("total", 0.0),
            paid = r.optDouble("paid", 0.0),
            change = r.optDouble("change", 0.0),
            method = r.optString("paymentMethod", "CASH"),
            customerName = r.optString("customerName").takeIf { it.isNotBlank() },
            onDone = { receipt = null; cart.clear(); discount = ""; selectedCustomer = null; showCheckout = false; onRefresh() },
        )
    }

    // Dialog pilih varian
    variantFor?.let { (p, vs) ->
        AlertDialog(
            onDismissRequest = { variantFor = null },
            title = { Text(p.name, fontWeight = FontWeight.ExtraBold, color = PosText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Pilih varian", fontSize = 12.sp, color = PosMuted)
                    vs.forEach { v ->
                        Surface(
                            color = PosSurface, shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, PosBorder),
                            modifier = Modifier.fillMaxWidth().clickable { addVariant(p, v); variantFor = null },
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                                Text(v.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = PosText, modifier = Modifier.weight(1f))
                                Text(formatRp(v.price), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PosPrimary)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { variantFor = null }) { Text("Batal", color = PosMuted) } },
        )
    }

    // Dialog pilih pelanggan / member
    if (showCustomers) {
        CustomerPickerDialog(
            customers = customers, selected = selectedCustomer,
            onPick = { selectedCustomer = it; showCustomers = false },
            onClear = { selectedCustomer = null; showCustomers = false },
            onAdd = { name, phone, tier, dsc ->
                scope.launch {
                    try { api.createCustomer(name, phone, tier, dsc); customers = api.listCustomers(); showMessage("Pelanggan ditambahkan") }
                    catch (e: Exception) { showMessage(e.message ?: "Gagal menambah pelanggan") }
                }
            },
            onClose = { showCustomers = false },
        )
    }

    // Dialog pesanan ditahan
    if (showHolds) {
        HoldsDialog(
            holds = holds, onResume = { h ->
                try {
                    val o = JSONObject(h.payloadJson)
                    val arr = o.optJSONArray("lines") ?: JSONArray()
                    cart.clear()
                    for (i in 0 until arr.length()) {
                        val x = arr.optJSONObject(i) ?: continue
                        cart.add(CartLine(
                            x.optString("productId").takeIf { it.isNotBlank() },
                            x.optString("variantId").takeIf { it.isNotBlank() },
                            x.optString("name"), x.optString("variantName").takeIf { it.isNotBlank() },
                            x.optDouble("price"), x.optInt("qty"),
                        ))
                    }
                    discount = o.optString("discount")
                    scope.launch { try { api.deleteHold(h.id); holds = api.listHolds() } catch (e: Exception) { } }
                    showHolds = false
                    showMessage("Pesanan dilanjutkan")
                } catch (e: Exception) { showMessage("Gagal memuat pesanan") }
            },
            onDelete = { h ->
                scope.launch { try { api.deleteHold(h.id); holds = api.listHolds() } catch (e: Exception) { } }
            },
            onClose = { showHolds = false },
        )
    }

    if (showCheckout) {
        CheckoutView(
            api = api, cartLines = cart.toList(), subtotal = subtotal,
            discount = discount, onDiscount = { discount = it.filter { c -> c.isDigit() } },
            total = total, disc = disc, tax = tax, memberDiscount = memberDiscount, taxRate = memberBy,
            splitEnabled = settings?.splitPaymentEnabled ?: true,
            customer = selectedCustomer, note = null,
            onBack = { showCheckout = false },
            onQty = { key, delta -> changeQty(key, delta) },
            showMessage = showMessage,
            onPaid = { res -> receipt = res },
        )
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            StatBox("Penjualan hari ini", formatRp(summary?.total ?: 0.0), "${summary?.count ?: 0} transaksi", PosPrimary, Modifier.weight(1f))
            StatBox("Keranjang", formatRp(subtotal), "$itemCount item", PosGold, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OpsGhostButton(text = "Riwayat", onClick = onHistory, modifier = Modifier.weight(1f))
            OpsGhostButton(text = "Tutup Sesi", onClick = onCloseSession, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OpsGhostButton(text = "Scan", onClick = { scanOpen = true }, modifier = Modifier.weight(1f))
            OpsGhostButton(text = if (holds.isEmpty()) "Tahan" else "Tahan (${holds.size})", onClick = { showHolds = true }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))

        // Pilih pelanggan / member
        Surface(
            color = PosSurface, shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, PosBorder),
            modifier = Modifier.fillMaxWidth().clickable { showCustomers = true },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                Text("\uD83D\uDC64", fontSize = 16.sp)
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(selectedCustomer?.name ?: "Pelanggan Umum", fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = PosText)
                    selectedCustomer?.let {
                        Text("Member ${it.tier.uppercase()} • diskon ${it.discountPercent.toInt()}%", fontSize = 11.sp, color = PosGold)
                    }
                }
                Text("Ubah", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PosPrimary)
            }
        }
        Spacer(Modifier.height(14.dp))

        // Tab kategori (horizontal scroll)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            CategoryChip("Semua", activeCategory == "all") { activeCategory = "all" }
            categories.forEach { c -> CategoryChip(c, activeCategory == c) { activeCategory = c } }
        }
        Spacer(Modifier.height(12.dp))
        OpsTextField(query, onQueryChange, "Cari produk / SKU / barcode…")
        Spacer(Modifier.height(12.dp))

        if (filtered.isEmpty()) {
            OpsEmpty("Tidak ada produk. Coba kata kunci lain atau isi katalog barang.")
        } else {
            filtered.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    pair.forEach { p ->
                        val q = cart.filter { it.productId == p.id }.sumOf { it.qty }
                        ProductGridCard(p = p, qty = q, lowThreshold = lowThreshold, modifier = Modifier.weight(1f)) { addProduct(p) }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }
        }
        Spacer(Modifier.height(12.dp))

        CartPanel(
            cartLines = cart.toList(),
            subtotal = subtotal, discount = discount, disc = disc,
            memberDiscount = memberDiscount, tax = tax, memberPct = memberPct, taxRate = memberBy,
            total = total,
            onQty = { key, delta -> changeQty(key, delta) },
            onDiscount = { discount = it },
            onClear = { cart.clear() },
            onPay = { if (cart.isNotEmpty()) showCheckout = true },
        )
        if (cart.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            OpsGhostButton(text = "\u23F8  Tahan Pesanan", onClick = {
                scope.launch {
                    try {
                        val lines = JSONArray()
                        cart.forEach { l ->
                            lines.put(JSONObject().apply {
                                l.productId?.let { put("productId", it) }
                                l.variantId?.let { put("variantId", it) }
                                put("name", l.name); l.variantName?.let { put("variantName", it) }
                                put("price", l.price); put("qty", l.qty)
                            })
                        }
                        val payload = JSONObject().apply { put("lines", lines); put("discount", discount) }
                        api.createHold("Pesanan ${cart.sumOf { it.qty }} item", payload)
                        cart.clear(); discount = ""
                        holds = api.listHolds()
                        showMessage("Pesanan ditahan")
                    } catch (e: Exception) { showMessage(e.message ?: "Gagal menahan pesanan") }
                }
            }, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(20.dp))
    }

    // Dialog scan barcode / input kode
    if (scanOpen) {
        AlertDialog(
            onDismissRequest = { scanOpen = false },
            title = { Text("Scan / Input Barcode", fontWeight = FontWeight.ExtraBold, color = PosText) },
            text = {
                Column {
                    Text("Masukkan barcode / kode SKU produk lalu tekan Cari.", fontSize = 12.sp, color = PosMuted)
                    Spacer(Modifier.height(10.dp))
                    OpsTextField(scanCode, { scanCode = it }, "Barcode / SKU")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val code = scanCode.trim()
                    if (code.isNotEmpty()) {
                        scope.launch {
                            val p = products.find { it.barcode == code || it.sku == code }
                                ?: api.lookupProduct(code)
                            if (p != null) { addProduct(p); showMessage("Ditambahkan: ${p.name}"); scanOpen = false; scanCode = "" }
                            else showMessage("Produk tidak ditemukan")
                        }
                    }
                }) { Text("Cari", fontWeight = FontWeight.Bold, color = PosPrimary) }
            },
            dismissButton = { TextButton(onClick = { scanOpen = false; scanCode = "" }) { Text("Tutup", color = PosMuted) } },
        )
    }
}


@Composable
private fun StatBox(label: String, value: String, sub: String, accent: Color, modifier: Modifier = Modifier) {
    Surface(
        color = PosSurface, shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, PosBorder), modifier = modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(modifier = Modifier.size(width = 26.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(accent))
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = PosText)
            Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PosMuted, letterSpacing = 0.4.sp)
            Text(sub, fontSize = 11.sp, color = PosMuted)
        }
    }
}

@Composable
private fun CategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) PosPrimary else PosSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (selected) PosPrimary else PosBorder),
        modifier = Modifier.clickable { onClick() },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)) {
            Text(catIcon(label), fontSize = 13.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                label, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) Color.White else PosMuted, maxLines = 1,
            )
        }
    }
}

private fun catIcon(name: String): String = when (name.lowercase()) {
    "semua" -> "\uD83D\uDDC2\uFE0F"
    "makanan" -> "\uD83C\uDF5C"
    "minuman" -> "\uD83E\uDD64"
    "snack" -> "\uD83C\uDF7F"
    "sembako" -> "\uD83C\uDF3E"
    "rokok" -> "\uD83D\uDEAC"
    else -> "\uD83D\uDCE6"
}

@Composable
private fun ProductGridCard(p: OpsProduct, qty: Int, lowThreshold: Int = 5, modifier: Modifier = Modifier, onAdd: () -> Unit) {
    val isLow = p.stock <= lowThreshold
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = PosSurface,
        border = BorderStroke(1.dp, if (qty > 0) PosPrimary else PosBorder),
        shadowElevation = if (qty > 0) 3.dp else 1.dp,
        modifier = modifier.clickable { onAdd() },
    ) {
        Column {
            // Header ikon kategori + ribbon stok rendah (warna brand)
            Box(
                modifier = Modifier.fillMaxWidth().height(74.dp)
                    .background(Brush.verticalGradient(listOf(KartiniColors.BrandGreenSoft, KartiniColors.CreamDeep))),
            ) {
                Text(catIcon(p.category ?: ""), fontSize = 34.sp, modifier = Modifier.align(Alignment.Center))
                if (isLow) {
                    Surface(color = PosDanger, shape = RoundedCornerShape(6.dp), modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)) {
                        Text("Stok rendah", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                    }
                }
                if (qty > 0) {
                    Surface(color = PosPrimary, shape = CircleShape, modifier = Modifier.align(Alignment.TopStart).padding(6.dp)) {
                        Text("$qty", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp))
                    }
                }
            }
            Column(modifier = Modifier.padding(10.dp)) {
                Text(p.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = PosText, maxLines = 2, minLines = 2)
                Spacer(Modifier.height(4.dp))
                Text(formatRp(p.price), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = PosPrimary)
                Text(
                    "Stok: ${p.stock} ${p.unit ?: ""}",
                    fontSize = 10.5.sp,
                    color = if (isLow) PosDanger else PosMuted,
                )
            }
        }
    }
}

@Composable
private fun CartPanel(
    cartLines: List<CartLine>, subtotal: Double, discount: String, disc: Double,
    memberDiscount: Double, tax: Double, memberPct: Double, taxRate: Double, total: Double,
    onQty: (String, Int) -> Unit, onDiscount: (String) -> Unit, onClear: () -> Unit, onPay: () -> Unit,
) {
    Surface(color = PosSurface, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, PosBorder)) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.size(30.dp).clip(RoundedCornerShape(9.dp))
                        .background(Brush.horizontalGradient(listOf(PosPrimary, PosPrimaryLight))),
                    contentAlignment = Alignment.Center,
                ) { Text("\uD83D\uDED2", fontSize = 15.sp) }
                Spacer(Modifier.width(10.dp))
                Text("Pesanan", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = PosText, modifier = Modifier.weight(1f))
                if (cartLines.isNotEmpty()) {
                    TextButton(onClick = onClear) { Text("Kosongkan", color = PosDanger, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (cartLines.isEmpty()) {
                OpsEmpty("Keranjang kosong — ketuk produk untuk menambah.")
            } else {
                cartLines.forEach { l ->
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                l.name + (l.variantName?.let { " ($it)" } ?: ""),
                                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = PosText, maxLines = 1,
                            )
                            Text("${formatRp(l.price)} × ${l.qty} = ${formatRp(l.total)}", fontSize = 11.sp, color = PosMuted)
                        }
                        TextButton(onClick = { onQty(l.key, -1) }) { Text("\u2212", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = PosPrimary) }
                        Text("${l.qty}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PosText)
                        TextButton(onClick = { onQty(l.key, +1) }) { Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = PosPrimary) }
                        TextButton(onClick = { onQty(l.key, -l.qty) }) { Text("\u2715", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PosDanger) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OpsTextField(discount, { onDiscount(it.filter { c -> c.isDigit() }) }, "Diskon (Rp)", keyboardType = KeyboardType.Number)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("Subtotal", fontSize = 12.sp, color = PosMuted, modifier = Modifier.weight(1f))
                    Text(formatRp(subtotal), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = PosText)
                }
                if (disc > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Diskon", fontSize = 12.sp, color = PosMuted, modifier = Modifier.weight(1f))
                        Text("− " + formatRp(disc), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = PosDanger)
                    }
                }
                if (memberDiscount > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Member (${memberPct.toInt()}%)", fontSize = 12.sp, color = PosMuted, modifier = Modifier.weight(1f))
                        Text("− " + formatRp(memberDiscount), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = PosGold)
                    }
                }
                if (tax > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Pajak (${taxRate.toInt()}%)", fontSize = 12.sp, color = PosMuted, modifier = Modifier.weight(1f))
                        Text(formatRp(tax), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = PosText)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.fillMaxWidth()) {
                    Text("Total", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = PosText, modifier = Modifier.weight(1f))
                    Text(formatRp(total), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = PosPrimary)
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onPay,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PosGreen, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                ) { Text("Bayar  ${formatRp(total)}", fontWeight = FontWeight.Bold, fontSize = 15.sp) }
            }
        }
    }
}

// ------------------------------------------------------------------
//  PEMBAYARAN (modal ala referensi)
// ------------------------------------------------------------------
private data class PayMethod(val key: String, val label: String, val icon: String, val backend: String)

private val payMethods = listOf(
    PayMethod("cash", "Tunai", "\uD83D\uDCB5", "CASH"),
    PayMethod("qris", "QRIS", "\uD83D\uDCF1", "NON_CASH"),
    PayMethod("transfer", "Transfer", "\uD83C\uDFE6", "NON_CASH"),
    PayMethod("card", "Kartu", "\uD83D\uDCB3", "NON_CASH"),
)

@Composable
private fun CheckoutView(
    api: ApiClient, cartLines: List<CartLine>, subtotal: Double, discount: String, onDiscount: (String) -> Unit,
    total: Double, disc: Double, tax: Double, memberDiscount: Double, taxRate: Double,
    splitEnabled: Boolean, customer: PosCustomer?, note: String?,
    onBack: () -> Unit, onQty: (String, Int) -> Unit,
    showMessage: (String) -> Unit, onPaid: (JSONObject) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var method by remember { mutableStateOf("cash") }
    var cash by remember { mutableStateOf(total.toLong().toString()) }
    var noteText by remember { mutableStateOf("") }
    var processing by remember { mutableStateOf(false) }
    var splitMode by remember { mutableStateOf(false) }
    // Baris split: (metode, nominal). Selalu ada minimal satu baris.
    val splits = remember { mutableStateListOf<Pair<String, String>>("cash" to "") }
    val backendMethod = payMethods.first { it.key == method }.backend
    val cashVal = cash.toDoubleOrNull() ?: 0.0
    val change = if (backendMethod == "CASH" && !splitMode) cashVal - total else 0.0
    val splitSum = splits.sumOf { it.second.toDoubleOrNull() ?: 0.0 }
    val splitRemaining = total - splitSum
    val canPay = cartLines.isNotEmpty() && !processing &&
        if (splitMode) splitSum + 0.001 >= total else (backendMethod != "CASH" || cashVal >= total)

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .background(PosBg).padding(horizontal = 16.dp, vertical = 16.dp),
    ) {
        // Banner total (gradien brand lembut)
        Box(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(KartiniColors.BrandGreenSoft, KartiniColors.CreamDeep)))
                .padding(vertical = 18.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Total Tagihan", fontSize = 12.sp, color = PosMuted, fontWeight = FontWeight.Medium)
                Text(formatRp(total), fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = PosPrimary)
                customer?.let { Text("Pelanggan: ${it.name}", fontSize = 11.sp, color = PosMuted) }
            }
        }
        Spacer(Modifier.height(16.dp))

        OpsSectionTitle("Keranjang (${cartLines.sumOf { it.qty }} item)")
        Spacer(Modifier.height(8.dp))
        OpsCard {
            cartLines.forEach { l ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(l.name + (l.variantName?.let { " ($it)" } ?: ""), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = PosText, maxLines = 1)
                        Text("${formatRp(l.price)} × ${l.qty}", fontSize = 11.sp, color = PosMuted)
                    }
                    TextButton(onClick = { onQty(l.key, -1) }) { Text("\u2212", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = PosPrimary) }
                    Text("${l.qty}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PosText)
                    TextButton(onClick = { onQty(l.key, +1) }) { Text("+", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = PosPrimary) }
                    Spacer(Modifier.width(4.dp))
                    Text(formatRp(l.total), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PosText)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        OpsTextField(discount, onDiscount, "Diskon (Rp)", keyboardType = KeyboardType.Number)

        // Rincian perhitungan
        Spacer(Modifier.height(12.dp))
        OpsCard {
            OpsKeyValue("Subtotal", formatRp(subtotal))
            OpsKeyValue("Diskon", formatRp(disc))
            if (memberDiscount > 0) OpsKeyValue("Diskon member", formatRp(memberDiscount))
            if (tax > 0) OpsKeyValue("Pajak (${taxRate.toInt()}%)", formatRp(tax))
            OpsKeyValue("Total", formatRp(total))
            if (backendMethod == "CASH" && !splitMode) OpsKeyValue("Kembalian", formatRp(change))
        }
        Spacer(Modifier.height(16.dp))

        OpsSectionTitle("Metode Pembayaran")
        Spacer(Modifier.height(8.dp))
        // Toggle split bila diaktifkan
        if (splitEnabled) {
            Surface(
                color = if (splitMode) KartiniColors.BrandGreenSoft else PosSurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (splitMode) PosPrimary else PosBorder),
                modifier = Modifier.fillMaxWidth().clickable { splitMode = !splitMode },
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Text("\uD83D\uDD00", fontSize = 15.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("Bayar Sebagian (Split)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (splitMode) PosPrimary else PosText, modifier = Modifier.weight(1f))
                    Text(if (splitMode) "Aktif" else "Nonaktif", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (splitMode) PosPrimary else PosMuted)
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        if (!splitMode) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                payMethods.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        pair.forEach { m ->
                            val sel = method == m.key
                            Surface(
                                color = if (sel) KartiniColors.BrandGreenSoft else PosSurface,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, if (sel) PosPrimary else PosBorder),
                                modifier = Modifier.weight(1f).clickable { method = m.key },
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp)) {
                                    Text(m.icon, fontSize = 16.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Text(m.label, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (sel) PosPrimary else PosText)
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                splits.forEachIndexed { idx, (mm, amt) ->
                    OpsCard {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Text("Metode ${idx + 1}", fontSize = 11.sp, color = PosMuted, modifier = Modifier.weight(1f))
                            if (splits.size > 1) {
                                TextButton(onClick = { splits.removeAt(idx) }) { Text("Hapus", color = PosDanger, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            payMethods.forEach { p ->
                                val sel = mm == p.key
                                Surface(
                                    color = if (sel) KartiniColors.BrandGreenSoft else PosSurface,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, if (sel) PosPrimary else PosBorder),
                                    modifier = Modifier.clickable { splits[idx] = p.key to amt },
                                ) { Text(p.label, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = if (sel) PosPrimary else PosMuted, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OpsTextField(amt, { v -> splits[idx] = mm to v.filter { c -> c.isDigit() } }, "Nominal (Rp)", keyboardType = KeyboardType.Number)
                    }
                }
                OpsGhostButton(text = "+ Tambah metode", onClick = { splits.add("cash" to "") }, modifier = Modifier.fillMaxWidth())
                Text(
                    if (splitRemaining > 0) "Kurang: ${formatRp(splitRemaining)}" else "Cukup • Kembalian: ${formatRp(-splitRemaining)}",
                    fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = if (splitRemaining > 0.001) PosDanger else PosPrimary,
                )
            }
        }

        if (backendMethod == "CASH" && !splitMode) {
            Spacer(Modifier.height(16.dp))
            OpsSectionTitle("Uang Diterima")
            Spacer(Modifier.height(8.dp))
            OpsCard {
                OpsTextField(cash, { cash = it.filter { c -> c.isDigit() } }, "Uang diterima (Rp)", keyboardType = KeyboardType.Number)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OpsGhostButton(text = "Uang Pas", onClick = { cash = total.toLong().toString() }, modifier = Modifier.weight(1f))
                    OpsGhostButton(text = "Reset", onClick = { cash = "" }, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Text("Uang cepat", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = PosMuted)
                Spacer(Modifier.height(6.dp))
                quickCashOptions(total).chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { v ->
                            OpsGhostButton(text = formatRp(v), onClick = { cash = v.toLong().toString() }, modifier = Modifier.weight(1f))
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                val tone = if (change >= 0) PosPrimary else PosDanger
                Text(
                    if (change >= 0) "Kembalian: ${formatRp(change)}" else "Uang kurang: ${formatRp(-change)}",
                    fontSize = 13.sp, fontWeight = FontWeight.Bold, color = tone,
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        OpsTextField(noteText, { noteText = it }, "Catatan (opsional)")
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                processing = true
                scope.launch {
                    try {
                        val fp = splits.map { m -> (payMethods.first { it.key == m.first }.backend) to (m.second.toDoubleOrNull() ?: 0.0) }
                        val res = api.checkoutPos(
                            items = cartLines.map { it.toSaleItem() },
                            discount = disc, paid = if (splitMode || backendMethod != "CASH") total else cashVal,
                            paymentMethod = if (splitMode) "SPLIT" else backendMethod,
                            tax = tax, memberDiscount = memberDiscount,
                            customerId = customer?.id, note = noteText.ifBlank { null },
                            cashReceived = if (backendMethod == "CASH" && !splitMode) cashVal else null,
                            splitPayments = if (splitMode) fp else emptyList(),
                        )
                        onPaid(res)
                    } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                    catch (e: Exception) { showMessage(e.message ?: "Gagal memproses transaksi") }
                    processing = false
                }
            },
            enabled = canPay,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PosGreen, contentColor = Color.White, disabledContainerColor = PosGreen.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text(if (processing) "Memproses…" else "Selesai & Cetak", fontWeight = FontWeight.Bold, fontSize = 15.sp) }
        Spacer(Modifier.height(10.dp))
        OpsGhostButton(text = "Kembali ke Barang", onClick = onBack, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
    }
}

/** Saran uang cepat: pembulatan ke atas + pecahan umum. */
private fun quickCashOptions(total: Double): List<Double> {
    val out = linkedSetOf<Double>()
    if (total > 0) {
        out.add(Math.ceil(total / 5000.0) * 5000.0)
        out.add(Math.ceil(total / 10000.0) * 10000.0)
        out.add(Math.ceil(total / 50000.0) * 50000.0)
    }
    listOf(10000.0, 20000.0, 50000.0, 100000.0, 150000.0, 200000.0).forEach { if (it >= total) out.add(it) }
    return out.take(6).toList()
}

// ------------------------------------------------------------------
//  STRUK (dialog) + bagikan
// ------------------------------------------------------------------
@Composable
private fun ReceiptDialog(
    code: String, subtotal: Double, discount: Double, memberDiscount: Double, tax: Double,
    total: Double, paid: Double, change: Double,
    method: String, customerName: String?, onDone: () -> Unit,
) {
    val ctx = LocalContext.current
    val methodLabel = when (method) {
        "CASH" -> "Tunai"; "SPLIT" -> "Split"; else -> "Non-Tunai"
    }
    val receiptText = buildString {
        appendLine("STRUK — Simaung Corporation")
        appendLine("No: $code")
        if (customerName != null) appendLine("Pelanggan: $customerName")
        appendLine("------------------------------")
        appendLine("Subtotal : ${formatRp(subtotal)}")
        appendLine("Diskon   : ${formatRp(discount)}")
        if (memberDiscount > 0) appendLine("Member   : ${formatRp(memberDiscount)}")
        if (tax > 0) appendLine("Pajak    : ${formatRp(tax)}")
        appendLine("Total    : ${formatRp(total)}")
        appendLine("Metode   : $methodLabel")
        appendLine("Dibayar  : ${formatRp(paid)}")
        appendLine("Kembali  : ${formatRp(change)}")
        appendLine("------------------------------")
        append("Terima kasih telah berbelanja")
    }
    fun share() {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Struk $code")
            putExtra(Intent.EXTRA_TEXT, receiptText)
        }
        ctx.startActivity(Intent.createChooser(i, "Bagikan struk"))
    }
    AlertDialog(
        onDismissRequest = { },
        title = { Text("Transaksi Berhasil", fontWeight = FontWeight.ExtraBold, color = PosPrimary) },
        text = {
            Column {
                OpsKeyValue("Kode", code.ifBlank { "-" })
                customerName?.let { OpsKeyValue("Pelanggan", it) }
                OpsKeyValue("Metode", methodLabel)
                OpsKeyValue("Subtotal", formatRp(subtotal))
                OpsKeyValue("Diskon", formatRp(discount))
                if (memberDiscount > 0) OpsKeyValue("Diskon member", formatRp(memberDiscount))
                if (tax > 0) OpsKeyValue("Pajak", formatRp(tax))
                OpsKeyValue("Total", formatRp(total))
                OpsKeyValue("Dibayar", formatRp(paid))
                OpsKeyValue("Kembalian", formatRp(change))
                Spacer(Modifier.height(8.dp))
                Text("Gunakan tombol Bagikan untuk mengirim struk via WhatsApp/email.", fontSize = 11.sp, color = PosMuted)
            }
        },
        confirmButton = { TextButton(onClick = { share() }) { Text("Bagikan", fontWeight = FontWeight.Bold, color = PosPrimary) } },
        dismissButton = { TextButton(onClick = onDone) { Text("Transaksi Baru", fontWeight = FontWeight.Bold, color = PosGreen) } },
    )
}

// ------------------------------------------------------------------
//  PELANGGAN / MEMBER (dialog)
// ------------------------------------------------------------------
@Composable
private fun CustomerPickerDialog(
    customers: List<PosCustomer>, selected: PosCustomer?,
    onPick: (PosCustomer) -> Unit, onClear: () -> Unit,
    onAdd: (String, String?, String, Double) -> Unit, onClose: () -> Unit,
) {
    var adding by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var tier by remember { mutableStateOf("regular") }
    var disc by remember { mutableStateOf("") }
    val tiers = listOf("regular", "silver", "gold", "platinum")
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Pelanggan / Member", fontWeight = FontWeight.ExtraBold, color = PosText) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                if (adding) {
                    OpsTextField(name, { name = it }, "Nama pelanggan")
                    Spacer(Modifier.height(8.dp))
                    OpsTextField(phone, { phone = it }, "No. HP", keyboardType = KeyboardType.Phone)
                    Spacer(Modifier.height(8.dp))
                    Text("Tier", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PosMuted)
                    Spacer(Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        tiers.forEach { t ->
                            val sel = tier == t
                            Surface(
                                color = if (sel) KartiniColors.BrandGreenSoft else PosSurface,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, if (sel) PosPrimary else PosBorder),
                                modifier = Modifier.clickable { tier = t; disc = if (t == "gold") "10" else if (t == "silver") "5" else if (t == "platinum") "15" else "" },
                            ) { Text(t.replaceFirstChar { it.uppercase() }, fontSize = 12.sp, color = if (sel) PosPrimary else PosMuted, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OpsTextField(disc, { disc = it.filter { c -> c.isDigit() } }, "Diskon member (%)", keyboardType = KeyboardType.Number)
                    Spacer(Modifier.height(10.dp))
                    PosPrimaryButton(text = "Simpan Pelanggan", onClick = {
                        if (name.isNotBlank()) { onAdd(name.trim(), phone.ifBlank { null }, tier, disc.toDoubleOrNull() ?: 0.0); name = ""; phone = ""; disc = ""; adding = false }
                    })
                } else {
                    if (selected != null) {
                        Surface(color = KartiniColors.BrandGreenSoft, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(10.dp)) {
                                Text("Terpilih: ${selected.name}", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = PosPrimary, modifier = Modifier.weight(1f))
                                TextButton(onClick = onClear) { Text("Hapus", color = PosDanger, fontSize = 12.sp) }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                    Surface(
                        color = PosSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, PosBorder),
                        modifier = Modifier.fillMaxWidth().clickable { onClear() },
                    ) { Text("Pelanggan Umum (tanpa member)", fontSize = 13.sp, color = PosText, modifier = Modifier.padding(12.dp)) }
                    Spacer(Modifier.height(8.dp))
                    if (customers.isEmpty()) {
                        Text("Belum ada pelanggan.", fontSize = 12.sp, color = PosMuted)
                    } else {
                        customers.forEach { c ->
                            Surface(
                                color = PosSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, PosBorder),
                                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp).clickable { onPick(c) },
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(12.dp)) {
                                    Text("\uD83D\uDC64", fontSize = 14.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(c.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = PosText)
                                        Text("${c.tier.uppercase()} • ${c.phone ?: "tanpa no"}", fontSize = 11.sp, color = PosMuted)
                                    }
                                    if (c.discountPercent > 0) Text("-${c.discountPercent.toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PosGold)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OpsGhostButton(text = "+ Tambah pelanggan baru", onClick = { adding = true }, modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Tutup", fontWeight = FontWeight.Bold, color = PosMuted) } },
    )
}

// ------------------------------------------------------------------
//  PESANAN DITAHAN (hold)
// ------------------------------------------------------------------
@Composable
private fun HoldsDialog(
    holds: List<PosHold>, onResume: (PosHold) -> Unit, onDelete: (PosHold) -> Unit, onClose: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Pesanan Ditahan", fontWeight = FontWeight.ExtraBold, color = PosText) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                if (holds.isEmpty()) {
                    Text("Belum ada pesanan yang ditahan.", fontSize = 12.5.sp, color = PosMuted)
                } else {
                    holds.forEach { h ->
                        Surface(
                            color = PosSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, PosBorder),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(h.label ?: "Pesanan", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PosText)
                                Text("${h.cashierName ?: "Kasir"} • ${h.createdAt?.replace("T", " ")?.take(16) ?: ""}", fontSize = 10.5.sp, color = PosMuted)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OpsGhostButton(text = "Lanjutkan", onClick = { onResume(h) }, modifier = Modifier.weight(1f))
                                    OpsGhostButton(text = "Hapus", onClick = { onDelete(h) }, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Tutup", fontWeight = FontWeight.Bold, color = PosMuted) } },
    )
}

// ------------------------------------------------------------------
//  RIWAYAT
// ------------------------------------------------------------------
@Composable
private fun HistoryView(sales: List<PosSale>, summary: PosSummary?, onBack: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
    ) {
        OpsSectionTitle("Ringkasan Hari Ini")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            StatBox("Total", formatRp(summary?.total ?: 0.0), "${summary?.count ?: 0} transaksi", PosPrimary, Modifier.weight(1f))
            StatBox("Tunai", formatRp(summary?.cash ?: 0.0), "", PosGreen, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            StatBox("Non-Tunai", formatRp(summary?.nonCash ?: 0.0), "", PosGold, Modifier.weight(1f))
            StatBox("Transaksi", "${sales.size}", "hari ini", PosPrimary, Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        OpsSectionTitle("Transaksi Terbaru")
        Spacer(Modifier.height(10.dp))
        if (sales.isEmpty()) {
            OpsEmpty("Belum ada transaksi.")
        } else {
            sales.forEach { s ->
                OpsCard {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(s.code ?: "Transaksi", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PosText)
                            Text(s.createdAt?.replace("T", " ")?.take(16) ?: "", fontSize = 11.sp, color = PosMuted)
                            s.customerName?.let { Text("Pelanggan: $it", fontSize = 11.sp, color = PosMuted) }
                        }
                        Text(formatRp(s.total), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = PosPrimary)
                    }
                    Spacer(Modifier.height(4.dp))
                    OpsBadge(
                        when (s.paymentMethod) { "CASH" -> "Tunai"; "SPLIT" -> "Split"; else -> "Non-Tunai" },
                        if (s.paymentMethod == "CASH") OpsTone.OK else OpsTone.INFO,
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        OpsGhostButton(text = "Kembali ke Kasir", onClick = onBack, modifier = Modifier.fillMaxWidth())
    }
}
