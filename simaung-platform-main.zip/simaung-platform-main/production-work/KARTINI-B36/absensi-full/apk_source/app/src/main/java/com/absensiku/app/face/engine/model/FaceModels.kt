package com.absensiku.app.face.engine.model

import android.graphics.PointF
import android.graphics.Rect

/**
 * Model data hasil deteksi & verifikasi wajah.
 *
 * Hasil konversi 1:1 dari `FaceDetectionResult`, `FaceMatchResult`,
 * `FaceMatchDecision`, `LivenessCheckResult`, dan `FrameQualityResult`
 * di Flutter (`face_matching_service.dart`).
 */

/** Hasil deteksi wajah tunggal. */
data class FaceDetectionResult(
    val faceDetected: Boolean = false,
    val faceCount: Int = 0,
    val face: FaceResult? = null,
    val error: String? = null,
)

/**
 * Representasi wajah yang sudah dinormalisasi dari ML Kit.
 * Menggantikan tipe `Face` milik Flutter dengan struktur Android-native.
 */
data class FaceResult(
    val boundingBox: Rect,
    val landmarks: Map<FaceLandmarkType, PointF>,
    val contours: Map<FaceContourType, List<PointF>>,
    val leftEyeOpenProbability: Float?,
    val rightEyeOpenProbability: Float?,
    val headEulerAngleX: Float?,
    val headEulerAngleY: Float?,
    val headEulerAngleZ: Float?,
) {
    val landmarkCount: Int get() = landmarks.size
    val contourCount: Int get() = contours.size
}

/** Hasil perbandingan wajah. */
data class FaceMatchResult(
    val similarityScore: Double = 0.0,
    val isMatch: Boolean = false,
    val isNearMatch: Boolean = false,
    val faceDetected: Boolean = false,
    val message: String? = null,
)

/** Hasil keputusan pencocokan multi-sample yang robust. */
data class FaceMatchDecision(
    val isMatch: Boolean,
    val score: Double,
    val isNearMatch: Boolean = false,
    val effectiveThreshold: Int = 0,
)

/** Hasil pemeriksaan liveness (anti-spoofing) dari satu frame. */
data class LivenessCheckResult(
    val faceDetected: Boolean = false,
    val faceCount: Int = 0,
    val eyesOpen: Boolean = false,
    val isFrontal: Boolean = false,
    val headAngleX: Float? = null,
    val headAngleY: Float? = null,
    val headAngleZ: Float? = null,
    val isLive: Boolean = false,
    val message: String? = null,
)

/** Hasil penilaian kualitas frame untuk auto-capture. */
data class FrameQualityResult(
    val faceDetected: Boolean = false,
    val qualityScore: Double = 0.0,
    val eyesOpen: Boolean = false,
    val centered: Boolean = false,
    val largeEnough: Boolean = false,
    val capturable: Boolean = false,
    val message: String? = null,
)

/** Tipe landmark wajah (setara `FaceLandmarkType` ML Kit). */
enum class FaceLandmarkType {
    LEFT_EYE, RIGHT_EYE, NOSE_BASE, LEFT_MOUTH, RIGHT_MOUTH,
    BOTTOM_MOUTH, LEFT_CHEEK, RIGHT_CHEEK, LEFT_EAR, RIGHT_EAR,
}

/** Tipe kontur wajah (setara `FaceContourType` ML Kit). */
enum class FaceContourType {
    FACE, NOSE_BRIDGE, NOSE_BOTTOM, LEFT_EYE, RIGHT_EYE,
    LEFT_EYEBROW_TOP, RIGHT_EYEBROW_TOP, UPPER_LIP_TOP, LOWER_LIP_BOTTOM,
}
