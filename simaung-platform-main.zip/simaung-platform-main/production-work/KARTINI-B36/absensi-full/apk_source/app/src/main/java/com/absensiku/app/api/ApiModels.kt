package com.absensiku.app.api

import org.json.JSONArray
import org.json.JSONObject

/** Balasan login. */
data class LoginResponse(
    val token: String,
    val employeeName: String,
    val employeeCode: String,
)

/** Info profil karyawan. */
data class MeResponse(
    val fullName: String,
    val position: String?,
    val employeeCode: String,
    val companyName: String?,
    val phone: String?,
    val shiftName: String?,
    val shiftStart: String?,
    val shiftEnd: String?,
    val leaveQuota: Int?,
    val isOffToday: Boolean = false,
    val defaultShiftName: String? = null,
    /** Foto profil (base64 JPEG tanpa prefix) — null bila belum diset. */
    val photoBase64: String? = null,
    /**
     * Peran jabatan karyawan (B10/B11) — bisa LEBIH DARI SATU (jabatan rangkap).
     * Contoh: ["DRIVER","PRAMUNIAGA"]. Menentukan modul Operasional yang tampil.
     */
    val roles: List<String> = emptyList(),
) {
    fun hasRole(key: String): Boolean = roles.any { it.equals(key, ignoreCase = true) }
    /** True bila karyawan punya salah satu peran operasional. */
    val hasAnyOpsRole: Boolean
        get() = roles.any { listOf("DRIVER", "PRAMUNIAGA", "KEPALA_GUDANG", "KASIR").contains(it.uppercase()) }
}

/** Status password karyawan (untuk reminder ganti password default). */
data class PasswordStatus(
    val isDefault: Boolean = false,
    val passwordChanged: Boolean = false,
)

/** Konfigurasi kantor. */
data class CompanyConfig(
    val officeName: String?,
    val address: String?,
    val officeLatitude: Double,
    val officeLongitude: Double,
    val officeRadiusMeters: Double,
    val minimumLocationAccuracyMeters: Double,
    val shiftName: String?,
    val shiftStart: String?,
    val shiftEnd: String?,
    /**
     * Toleransi pergeseran GPS (meter) — sudah DIBATASI di server dan dikirim
     * dalam bentuk final. Radius efektif = radius kantor + toleransi ini.
     */
    val gpsDriftToleranceMeters: Double = 0.0,
    /**
     * Radius EFEKTIF (meter) yang dihitung SERVER — batas resmi yang dipakai
     * saat menerima/menolak absensi. Bila server mengirim angkanya, aplikasi
     * memakai nilai ini APA ADANYA agar tampilan dan penolakan selalu cocok.
     */
    val effectiveRadiusMetersFromServer: Double? = null,
    /** Feature flags (Remote Config) — dikendalikan dari panel superadmin. */
    val features: Map<String, Boolean> = emptyMap(),
    /**
     * B67 — Desain aplikasi (warna, logo, gambar) KHUSUS lokasi kantor karyawan.
     * Null = server belum mengirim (pakai palet resmi bawaan).
     */
    val theme: com.absensiku.app.ui.theme.AppTheme? = null,
) {
    /** True bila fitur aktif. Default true (aman) bila flag tidak dikirim server. */
    fun feature(key: String): Boolean = features[key] ?: true

    /**
     * Radius efektif = radius kantor + toleransi pergeseran GPS.
     *
     * Bila server mengirim `effectiveRadiusMeters`, nilai itulah yang dipakai
     * (sumber kebenaran tunggal). Bila tidak (server versi lama), hitung lokal
     * dengan pembatasan yang sama seperti server agar tidak pernah lebih longgar.
     */
    val effectiveRadiusMeters: Double
        get() = effectiveRadiusMetersFromServer
            ?: (officeRadiusMeters + gpsDriftToleranceMeters.coerceAtLeast(0.0))
                .coerceAtMost(officeRadiusMeters * 1.5 + 50)
}

/** Status absensi hari ini. */
data class TodayAttendance(
    val checkInAt: String?,
    val checkOutAt: String?,
    val status: String? = null,
    val lateMinutes: Int = 0,
    val shiftName: String? = null,
    val shiftStart: String? = null,
    val shiftEnd: String? = null,
    val isOffToday: Boolean = false,
    /** OK / LOW_ACCURACY / OUTSIDE_RADIUS / OUTSIDE_RADIUS_FAR (null = belum absen). */
    val geoStatus: String? = null,
    /** NONE / NEEDED / VERIFIED / REJECTED. */
    val verificationStatus: String? = null,
    /** True bila absensi ini dikirim dari ANTRIAN OFFLINE (disimpan dulu di HP). */
    val offlineSync: Boolean = false,
)

/** Balasan submit absensi. */
data class AttendanceResponse(
    val type: String,
    val distanceMeters: Double,
    val serverTimestamp: String?,
    val status: String? = null,
    val lateMinutes: Int = 0,
    /** OK / LOW_ACCURACY / OUTSIDE_RADIUS / OUTSIDE_RADIUS_FAR. */
    val geoStatus: String? = null,
    /** NONE / NEEDED / VERIFIED / REJECTED. */
    val verificationStatus: String? = null,
    /** True bila tercatat dari antrian offline. */
    val offlineSync: Boolean = false,
    /** Catatan tambahan dari server (mis. "menunggu verifikasi admin"). */
    val note: String? = null,
) {
    /** Server menandai absensi sah tetapi perlu ditinjau admin (GPS lemah / luar radius). */
    val needsVerification: Boolean get() = verificationStatus == "NEEDED"
}

// ================= Antrian absen OFFLINE =================

/**
 * Satu absensi yang discan saat SINYAL BURUK / GPS LEMAH dan disimpan dulu di
 * perangkat. Berisi WAKTU SCAN ASLI (`clientTimestamp`) sehingga saat akhirnya
 * terkirim, absensi tetap tercatat TEPAT WAKTU (bukan terlambat).
 */
data class PendingAttendance(
    /** ID lokal unik (dibuat perangkat) — dipakai server untuk melaporkan hasil. */
    val clientId: String,
    val type: String,                 // CHECK_IN / CHECK_OUT
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Double,       // <= 0 = tidak diketahui
    val isMockLocation: Boolean,
    val faceDetected: Boolean,
    val livenessPassed: Boolean,
    val faceScore: Int?,
    val faceVerifySource: String?,
    /** Waktu scan ASLI di perangkat (epoch millis). */
    val clientTimestamp: Long,
    /** Waktu antrian dibuat (untuk pembersihan item basi). */
    val queuedAt: Long,
    val attempts: Int = 0,
    /** Catatan di layar, mis. \"Di luar radius\" — tidak dikirim ke server. */
    val note: String? = null,
) {
    /** Jarak item ini dari \"sekarang\" — dipakai untuk membuang antrian yang basi. */
    val ageMillis: Long get() = System.currentTimeMillis() - queuedAt
}

/** Hasil sinkronisasi satu item dari server. */
data class SyncItemResult(
    val clientId: String,
    val ok: Boolean,
    val duplicate: Boolean = false,
    val message: String? = null,
    val status: String? = null,
    val lateMinutes: Int = 0,
    val geoStatus: String? = null,
    val verificationStatus: String? = null,
    /**
     * Ditolak karena JELAS di luar jangkauan kantor (kunci lokasi). Item seperti
     * ini TIDAK boleh dicoba ulang — hasilnya akan selalu sama.
     */
    val rejectedOutOfRange: Boolean = false,
)

/** Satu entri jadwal harian (dipakai layar Jadwal). */
data class ScheduleDay(
    val date: String,
    val off: Boolean,
    val shiftName: String?,
    val startTime: String?,
    val endTime: String?,
)

/** Satu baris riwayat absensi. */
data class HistoryItem(
    val type: String,
    val serverTimestamp: String,
    val distanceMeters: Double,
    val status: String,
    val faceDetected: Boolean = false,
    val faceScore: Int? = null,
    val workMinutes: Int? = null,
)

/** Satu baris pengajuan izin/cuti. */
data class LeaveItem(
    val id: String,
    val category: String,
    val startDate: String,
    val endDate: String,
    val reason: String?,
    val status: String,
    val hasAttachment: Boolean = false,
    val attachmentUrl: String? = null,
)

/** Satu baris pengajuan lembur. */
data class OvertimeItem(
    val id: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val durationMinutes: Int,
    val reason: String?,
    val status: String,
)

/** Status enrollment wajah (dikelola server). */
data class FaceEnrollmentStatus(
    val enrolled: Boolean,
    val sampleCount: Int,
    val hasBasePhoto: Boolean,
    val outdated: Boolean = false,
)

/** Hasil verifikasi wajah dari server (otoritatif). */
data class FaceVerifyResult(
    val match: Boolean,
    val score: Int,
    val nearMatch: Boolean,
    val effectiveThreshold: Int,
    val sampleCount: Int,
    val message: String?,
)

/** Info pembaruan aplikasi (dari server). */
data class ServerUpdateInfo(
    val available: Boolean,
    val versionName: String,
    val versionCode: Int,
    val apkUrl: String,
    val mandatory: Boolean,
    val notes: String?,
)

/** Notifikasi dari server (jalur internal). */
data class ServerNotification(
    val id: String,
    val title: String,
    val body: String?,
    val kind: String,
    val createdAt: String?,
)

// ================= JSON parsing helpers =================

internal fun JSONObject.str(key: String): String? =
    if (isNull(key)) null else optString(key)

internal fun JSONObject.dbl(key: String, def: Double = 0.0): Double =
    if (isNull(key)) def else optDouble(key, def)

internal fun JSONObject.intOrNull(key: String): Int? =
    if (isNull(key)) null else optInt(key)

internal fun JSONObject.bool(key: String, def: Boolean = false): Boolean =
    if (isNull(key)) def else optBoolean(key, def)

internal fun parseLogin(o: JSONObject): LoginResponse = LoginResponse(
    token = o.str("token") ?: o.str("accessToken") ?: "",
    employeeName = o.str("employeeName") ?: o.str("fullName") ?: "Karyawan",
    employeeCode = o.str("employeeCode") ?: "",
)

internal fun parseMe(o: JSONObject): MeResponse = MeResponse(
    fullName = o.str("fullName") ?: o.str("employeeName") ?: "Karyawan",
    position = o.str("position"),
    employeeCode = o.str("employeeCode") ?: "",
    companyName = o.str("companyName"),
    phone = o.str("phone"),
    shiftName = o.str("shiftName"),
    shiftStart = o.str("shiftStart"),
    shiftEnd = o.str("shiftEnd"),
    leaveQuota = o.intOrNull("leaveQuota") ?: o.intOrNull("remainingLeave"),
    isOffToday = o.bool("isOffToday"),
    defaultShiftName = o.str("defaultShiftName"),
    photoBase64 = o.str("photoBase64")?.takeIf { it.isNotBlank() },
    roles = parseStringList(o.optJSONArray("roles")),
)

/** Ubah JSONArray string menjadi List<String> (aman untuk null). */
internal fun parseStringList(a: JSONArray?): List<String> {
    if (a == null) return emptyList()
    val out = ArrayList<String>(a.length())
    for (i in 0 until a.length()) {
        val v = a.optString(i, "")
        if (v.isNotBlank()) out += v
    }
    return out
}

internal fun parseConfig(o: JSONObject): CompanyConfig = CompanyConfig(
    officeName = o.str("officeName"),
    address = o.str("address"),
    officeLatitude = o.dbl("officeLatitude", o.dbl("officeLat")),
    officeLongitude = o.dbl("officeLongitude", o.dbl("officeLng")),
    officeRadiusMeters = o.dbl("officeRadiusMeters", o.dbl("radius", 100.0)),
    minimumLocationAccuracyMeters = o.dbl("minimumLocationAccuracyMeters", o.dbl("minimumAccuracy", 50.0)),
    shiftName = o.str("shiftName"),
    shiftStart = o.str("shiftStart"),
    shiftEnd = o.str("shiftEnd"),
    gpsDriftToleranceMeters = o.dbl("gpsDriftToleranceMeters", 0.0),
    effectiveRadiusMetersFromServer = if (o.isNull("effectiveRadiusMeters")) null else o.optDouble("effectiveRadiusMeters"),
    features = parseFeatures(o.optJSONObject("features")),
    theme = com.absensiku.app.ui.theme.parseAppTheme(o.optJSONObject("theme")),
)

/** Ubah objek "features" dari server menjadi Map<String, Boolean>. */
internal fun parseFeatures(o: JSONObject?): Map<String, Boolean> {
    if (o == null) return emptyMap()
    val out = mutableMapOf<String, Boolean>()
    val it = o.keys()
    while (it.hasNext()) {
        val k = it.next()
        out[k] = o.optBoolean(k, true)
    }
    return out
}

internal fun parseToday(o: JSONObject): TodayAttendance = TodayAttendance(
    checkInAt = o.str("checkInAt"),
    checkOutAt = o.str("checkOutAt"),
    status = o.str("status"),
    lateMinutes = o.intOrNull("lateMinutes") ?: 0,
    shiftName = o.str("shiftName"),
    shiftStart = o.str("shiftStart"),
    shiftEnd = o.str("shiftEnd"),
    isOffToday = o.bool("isOffToday"),
    geoStatus = o.str("geoStatus"),
    verificationStatus = o.str("verificationStatus"),
    offlineSync = o.bool("offlineSync"),
)

internal fun parseAttendance(o: JSONObject): AttendanceResponse = AttendanceResponse(
    type = o.str("type") ?: "ABSEN",
    distanceMeters = o.dbl("distanceMeters"),
    serverTimestamp = o.str("serverTimestamp"),
    status = o.str("status"),
    lateMinutes = o.intOrNull("lateMinutes") ?: 0,
    geoStatus = o.str("geoStatus"),
    verificationStatus = o.str("verificationStatus"),
    offlineSync = o.bool("offlineSync"),
    note = o.str("note"),
)

/** Ubah satu balasan `results[]` dari POST /attendance/sync menjadi objek. */
internal fun parseSyncResult(o: JSONObject): SyncItemResult = SyncItemResult(
    clientId = o.str("clientId") ?: "",
    ok = o.bool("ok"),
    duplicate = o.bool("duplicate"),
    message = o.str("message"),
    status = o.str("status"),
    lateMinutes = o.intOrNull("lateMinutes") ?: 0,
    geoStatus = o.str("geoStatus"),
    verificationStatus = o.str("verificationStatus"),
    rejectedOutOfRange = o.bool("rejectedOutOfRange"),
)

internal fun parseSchedule(a: JSONArray): List<ScheduleDay> {
    val out = ArrayList<ScheduleDay>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += ScheduleDay(
            date = o.str("date") ?: "",
            off = o.bool("off"),
            shiftName = o.str("shiftName"),
            startTime = o.str("startTime"),
            endTime = o.str("endTime"),
        )
    }
    return out
}

internal fun parseHistory(a: JSONArray): List<HistoryItem> {
    val out = ArrayList<HistoryItem>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += HistoryItem(
            type = o.str("type") ?: "",
            serverTimestamp = o.str("serverTimestamp") ?: o.str("timestamp") ?: "",
            distanceMeters = o.dbl("distanceMeters"),
            status = o.str("status") ?: "",
            faceDetected = o.bool("faceDetected"),
            faceScore = o.intOrNull("faceScore") ?: o.intOrNull("faceConfidence"),
            workMinutes = o.intOrNull("workMinutes"),
        )
    }
    return out
}

internal fun parseLeaves(a: JSONArray): List<LeaveItem> {
    val out = ArrayList<LeaveItem>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += LeaveItem(
            id = o.str("id") ?: "leave_$i",
            category = o.str("category") ?: "IZIN",
            startDate = o.str("startDate") ?: "",
            endDate = o.str("endDate") ?: "",
            reason = o.str("reason"),
            status = o.str("status") ?: "PENDING",
            hasAttachment = o.bool("hasAttachment") || !o.str("attachmentUrl").isNullOrBlank(),
            attachmentUrl = o.str("attachmentUrl"),
        )
    }
    return out
}

internal fun parseOvertimes(a: JSONArray): List<OvertimeItem> {
    val out = ArrayList<OvertimeItem>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += OvertimeItem(
            id = o.str("id") ?: "ot_$i",
            date = o.str("date") ?: "",
            startTime = o.str("startTime") ?: "",
            endTime = o.str("endTime") ?: "",
            durationMinutes = o.intOrNull("durationMinutes") ?: 0,
            reason = o.str("reason"),
            status = o.str("status") ?: "PENDING",
        )
    }
    return out
}

internal fun parseNotifications(a: JSONArray): List<ServerNotification> {
    val out = ArrayList<ServerNotification>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += ServerNotification(
            id = o.str("id") ?: "notif_$i",
            title = o.str("title") ?: "",
            body = o.str("body"),
            kind = o.str("kind") ?: "INFO",
            createdAt = o.str("createdAt"),
        )
    }
    return out
}

// =====================================================================
//  MODEL MODUL OPERASIONAL (B11) — Driver, Opname, POS.
// =====================================================================

/** Master barang (stok opname / katalog POS). */
data class OpsProduct(
    val id: String,
    val sku: String?,
    val barcode: String? = null,
    val name: String,
    val category: String?,
    val unit: String?,
    val price: Double,
    val cost: Double,
    val stock: Int,
    val minStock: Int,
    val active: Boolean = true,
) { val low: Boolean get() = stock <= minStock }

/** Input untuk menambah/mengubah barang (nilai null = tidak diisi). */
data class ProductInput(
    val name: String? = null,
    val sku: String? = null,
    val barcode: String? = null,
    val category: String? = null,
    val unit: String? = null,
    val price: Double? = null,
    val cost: Double? = null,
    val stock: Int? = null,
    val minStock: Int? = null,
    val active: Boolean? = null,
)

/** Varian produk. */
data class ProductVariant(
    val id: String,
    val productId: String?,
    val name: String,
    val price: Double,
    val stock: Int,
    val sku: String? = null,
    val active: Boolean = true,
)

/** Pelanggan / member POS. */
data class PosCustomer(
    val id: String,
    val name: String,
    val phone: String?,
    val tier: String,
    val discountPercent: Double,
    val points: Int = 0,
)

/** Pengaturan POS. */
data class PosSettings(
    val taxRate: Double,
    val taxEnabled: Boolean,
    val splitPaymentEnabled: Boolean,
    val lowStockThreshold: Int,
    val storeName: String?,
)

/** Pesanan ditahan (hold order). */
data class PosHold(
    val id: String,
    val label: String?,
    val cashierName: String?,
    val payloadJson: String,
    val createdAt: String?,
)

/** Satu baris hasil hitung opname. */
data class OpnameItem(
    val productId: String?,
    val productName: String,
    val sku: String?,
    val systemStock: Int,
    val countedStock: Int,
    val diff: Int,
    /** Mutasi barang saat opname (ala Allstock): masuk, keluar, rusak/reject. */
    val qtyIn: Int = 0,
    val qtyOut: Int = 0,
    val qtyReject: Int = 0,
    val note: String? = null,
)

/** Input satu baris draf opname (mutasi masuk/keluar/rusak). */
data class OpnameDraftInput(
    val productId: String,
    val productName: String,
    val qtyIn: Int = 0,
    val qtyOut: Int = 0,
    val qtyReject: Int = 0,
    val countedStock: Int = 0,
    /** true = pakai hasil hitung manual; false = hitung dari mutasi. */
    val useCounted: Boolean = false,
    val note: String = "",
)

/** Sesi stok opname. */
data class OpnameSession(
    val id: String,
    val employeeName: String?,
    val kind: String,
    val area: String?,
    val note: String?,
    val totalItems: Int,
    val totalDiff: Int,
    val status: String,
    val reviewedBy: String?,
    val reviewNote: String?,
    val createdAt: String?,
)

/** Perjalanan driver (tracking). */
data class TripItem(
    val id: String,
    val code: String?,
    val driverName: String?,
    val vehicle: String?,
    val destination: String?,
    val note: String?,
    val status: String,
    val lastLat: Double?,
    val lastLng: Double?,
    val createdAt: String?,
)

/** Satu baris item surat jalan. */
data class DeliveryItem(
    val productId: String?,
    val productName: String,
    val sku: String?,
    val qty: Int,
    val unit: String?,
)

/** Surat jalan. */
data class DeliveryNote(
    val id: String,
    val code: String?,
    val driverName: String?,
    val recipientName: String?,
    val address: String?,
    val status: String,
    val totalItems: Int,
    val destination: String? = null,
    val vehicle: String? = null,
    val createdAt: String?,
)

/** Sesi kasir (POS). */
data class PosSession(
    val id: String,
    val cashierName: String?,
    val openingCash: Double,
    val closingCash: Double?,
    val expectedCash: Double?,
    val cashDiff: Double?,
    val status: String,
    val openedAt: String?,
)

/** Transaksi POS. */
data class PosSale(
    val id: String,
    val code: String?,
    val cashierName: String?,
    val subtotal: Double,
    val discount: Double,
    val tax: Double = 0.0,
    val memberDiscount: Double = 0.0,
    val customerName: String? = null,
    val total: Double,
    val paid: Double,
    val change: Double,
    val paymentMethod: String,
    val status: String,
    val createdAt: String?,
)

/** Satu baris item transaksi POS. */
data class PosSaleItem(
    val productId: String?,
    val productName: String,
    val sku: String?,
    val price: Double,
    val qty: Int,
    val total: Double,
    val variantId: String? = null,
    val variantName: String? = null,
)

/** Ringkasan penjualan kasir hari ini. */
data class PosSummary(
    val count: Int,
    val total: Double,
    val cash: Double,
    val nonCash: Double,
)

internal fun parseOpsProduct(o: JSONObject): OpsProduct = OpsProduct(
    id = o.str("id") ?: "",
    sku = o.str("sku")?.takeIf { it.isNotBlank() },
    barcode = o.str("barcode")?.takeIf { it.isNotBlank() },
    name = o.str("name") ?: "",
    category = o.str("category")?.takeIf { it.isNotBlank() },
    unit = o.str("unit")?.takeIf { it.isNotBlank() },
    price = o.dbl("price"),
    cost = o.dbl("cost"),
    stock = o.intOrNull("stock") ?: 0,
    minStock = o.intOrNull("minStock") ?: 0,
    active = o.bool("active", true),
)

internal fun parseOpsProducts(a: JSONArray): List<OpsProduct> {
    val out = ArrayList<OpsProduct>(a.length())
    for (i in 0 until a.length()) a.optJSONObject(i)?.let { out += parseOpsProduct(it) }
    return out
}

internal fun parseOpnameItems(a: JSONArray): List<OpnameItem> {
    val out = ArrayList<OpnameItem>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += OpnameItem(
            productId = o.str("productId"),
            productName = o.str("productName") ?: "",
            sku = o.str("sku"),
            systemStock = o.intOrNull("systemStock") ?: 0,
            countedStock = o.intOrNull("countedStock") ?: 0,
            diff = o.intOrNull("diff") ?: 0,
            qtyIn = o.intOrNull("qtyIn") ?: 0,
            qtyOut = o.intOrNull("qtyOut") ?: 0,
            qtyReject = o.intOrNull("qtyReject") ?: 0,
            note = o.str("note"),
        )
    }
    return out
}

internal fun parseOpnameSession(o: JSONObject): OpnameSession = OpnameSession(
    id = o.str("id") ?: "",
    employeeName = o.str("employeeName"),
    kind = o.str("kind") ?: "PRAMUNIAGA",
    area = o.str("area"),
    note = o.str("note"),
    totalItems = o.intOrNull("totalItems") ?: 0,
    totalDiff = o.intOrNull("totalDiff") ?: 0,
    status = o.str("status") ?: "SUBMITTED",
    reviewedBy = o.str("reviewedBy"),
    reviewNote = o.str("reviewNote"),
    createdAt = o.str("createdAt"),
)

/** Satu baris rekap mutasi harian (GET /ops/opnames/log). */
data class OpnameLogRow(
    val id: String,
    val opnameId: String?,
    val productName: String,
    val sku: String?,
    val qtyIn: Int,
    val qtyOut: Int,
    val qtyReject: Int,
    val note: String?,
    val employeeName: String?,
    val kind: String?,
    val area: String?,
    val status: String,
    val createdAt: String?,
)

/** Rekap mutasi harian + total. */
data class OpnameLog(
    val date: String,
    val items: List<OpnameLogRow>,
    val totalIn: Int,
    val totalOut: Int,
    val totalReject: Int,
)

internal fun parseOpnameLogRows(a: JSONArray): List<OpnameLogRow> {
    val out = ArrayList<OpnameLogRow>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += OpnameLogRow(
            id = o.str("id") ?: "",
            opnameId = o.str("opnameId"),
            productName = o.str("productName") ?: "",
            sku = o.str("sku"),
            qtyIn = o.intOrNull("qtyIn") ?: 0,
            qtyOut = o.intOrNull("qtyOut") ?: 0,
            qtyReject = o.intOrNull("qtyReject") ?: 0,
            note = o.str("note"),
            employeeName = o.str("employeeName"),
            kind = o.str("kind"),
            area = o.str("area"),
            status = o.str("status") ?: "",
            createdAt = o.str("createdAt"),
        )
    }
    return out
}

internal fun parseOpnames(a: JSONArray): List<OpnameSession> {
    val out = ArrayList<OpnameSession>(a.length())
    for (i in 0 until a.length()) a.optJSONObject(i)?.let { out += parseOpnameSession(it) }
    return out
}

internal fun parseTripItem(o: JSONObject): TripItem = TripItem(
    id = o.str("id") ?: "",
    code = o.str("code"),
    driverName = o.str("driverName"),
    vehicle = o.str("vehicle"),
    destination = o.str("destination"),
    note = o.str("note"),
    status = o.str("status") ?: "ASSIGNED",
    lastLat = if (o.isNull("lastLat")) null else o.optDouble("lastLat"),
    lastLng = if (o.isNull("lastLng")) null else o.optDouble("lastLng"),
    createdAt = o.str("createdAt"),
)

internal fun parseTrips(a: JSONArray): List<TripItem> {
    val out = ArrayList<TripItem>(a.length())
    for (i in 0 until a.length()) a.optJSONObject(i)?.let { out += parseTripItem(it) }
    return out
}

internal fun parseDeliveryItems(a: JSONArray): List<DeliveryItem> {
    val out = ArrayList<DeliveryItem>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += DeliveryItem(
            productId = o.str("productId"),
            productName = o.str("productName") ?: "",
            sku = o.str("sku"),
            qty = o.intOrNull("qty") ?: 0,
            unit = o.str("unit"),
        )
    }
    return out
}

internal fun parseDeliveryNote(o: JSONObject): DeliveryNote = DeliveryNote(
    id = o.str("id") ?: "",
    code = o.str("code"),
    driverName = o.str("driverName"),
    recipientName = o.str("recipientName"),
    address = o.str("address"),
    status = o.str("status") ?: "ISSUED",
    totalItems = o.intOrNull("totalItems") ?: 0,
    destination = o.str("destination"),
    vehicle = o.str("vehicle"),
    createdAt = o.str("createdAt"),
)

internal fun parseDeliveryNotes(a: JSONArray): List<DeliveryNote> {
    val out = ArrayList<DeliveryNote>(a.length())
    for (i in 0 until a.length()) a.optJSONObject(i)?.let { out += parseDeliveryNote(it) }
    return out
}

internal fun parsePosSession(o: JSONObject): PosSession = PosSession(
    id = o.str("id") ?: "",
    cashierName = o.str("cashierName"),
    openingCash = o.dbl("openingCash"),
    closingCash = if (o.isNull("closingCash")) null else o.optDouble("closingCash"),
    expectedCash = if (o.isNull("expectedCash")) null else o.optDouble("expectedCash"),
    cashDiff = if (o.isNull("cashDiff")) null else o.optDouble("cashDiff"),
    status = o.str("status") ?: "OPEN",
    openedAt = o.str("openedAt"),
)

internal fun parsePosSales(a: JSONArray): List<PosSale> {
    val out = ArrayList<PosSale>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += PosSale(
            id = o.str("id") ?: "",
            code = o.str("code"),
            cashierName = o.str("cashierName"),
            subtotal = o.dbl("subtotal"),
            discount = o.dbl("discount"),
            tax = o.dbl("tax"),
            memberDiscount = o.dbl("memberDiscount"),
            customerName = o.str("customerName"),
            total = o.dbl("total"),
            paid = o.dbl("paid"),
            change = o.dbl("change"),
            paymentMethod = o.str("paymentMethod") ?: "CASH",
            status = o.str("status") ?: "PAID",
            createdAt = o.str("createdAt"),
        )
    }
    return out
}

internal fun parseVariants(a: JSONArray): List<ProductVariant> {
    val out = ArrayList<ProductVariant>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += ProductVariant(
            id = o.str("id") ?: "",
            productId = o.str("productId"),
            name = o.str("name") ?: "",
            price = o.dbl("price"),
            stock = o.intOrNull("stock") ?: 0,
            sku = o.str("sku"),
            active = o.bool("active", true),
        )
    }
    return out
}

internal fun parseCustomers(a: JSONArray): List<PosCustomer> {
    val out = ArrayList<PosCustomer>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += PosCustomer(
            id = o.str("id") ?: "",
            name = o.str("name") ?: "",
            phone = o.str("phone"),
            tier = o.str("tier") ?: "regular",
            discountPercent = o.dbl("discountPercent"),
            points = o.intOrNull("points") ?: 0,
        )
    }
    return out
}

internal fun parsePosSettings(o: JSONObject): PosSettings = PosSettings(
    taxRate = o.dbl("taxRate"),
    taxEnabled = o.bool("taxEnabled", false),
    splitPaymentEnabled = o.bool("splitPaymentEnabled", true),
    lowStockThreshold = o.intOrNull("lowStockThreshold") ?: 5,
    storeName = o.str("storeName"),
)

internal fun parseHolds(a: JSONArray): List<PosHold> {
    val out = ArrayList<PosHold>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += PosHold(
            id = o.str("id") ?: "",
            label = o.str("label"),
            cashierName = o.str("cashierName"),
            payloadJson = o.optJSONObject("payload")?.toString() ?: "{}",
            createdAt = o.str("createdAt"),
        )
    }
    return out
}


internal fun parsePosSaleItems(a: JSONArray): List<PosSaleItem> {
    val out = ArrayList<PosSaleItem>(a.length())
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        out += PosSaleItem(
            productId = o.str("productId"),
            productName = o.str("productName") ?: "",
            sku = o.str("sku"),
            price = o.dbl("price"),
            qty = o.intOrNull("qty") ?: 0,
            total = o.dbl("total"),
        )
    }
    return out
}

internal fun parsePosSummary(o: JSONObject): PosSummary = PosSummary(
    count = o.intOrNull("count") ?: 0,
    total = o.dbl("total"),
    cash = o.dbl("cash"),
    nonCash = o.dbl("nonCash"),
)
