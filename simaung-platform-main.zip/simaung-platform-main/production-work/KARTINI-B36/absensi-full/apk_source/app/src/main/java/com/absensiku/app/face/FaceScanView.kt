package com.absensiku.app.face

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.absensiku.app.api.ApiClient
import com.absensiku.app.face.engine.core.FaceMatchingService
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors
import kotlin.coroutines.resume

/**
 * Ambang kemiripan template (%). v0.9.9: diturunkan 72 -> 40.
 * Verifikasi kini bertujuan ANTI-SPOOF (masih mirip sample terdaftar),
 * bukan pencocokan identitas ketat -> absensi jauh lebih mudah lolos.
 */
private const val MATCH_THRESHOLD = 40

/** Jumlah sample wajah saat enrollment (cukup 1x). */
private const val ENROLL_SAMPLES_NEEDED = 1

/** Batas |yaw| (°) untuk dianggap kepala frontal (syarat arah hadap). */
private const val FRONTAL_THRESHOLD_DEG = 32f

/** Interval (ms) monitoring kualitas frame. */
private const val QUALITY_INTERVAL_MS = 350L

/** Batas dimensi bitmap wajah (anti-OOM pada perangkat memori kecil). */
private const val MAX_FACE_DIM = 1024

/**
 * Hasil pemindaian wajah (keputusan identitas diambil SERVER).
 *
 * @param match         server memutuskan wajah cocok (untuk verifikasi).
 * @param score         persentase kemiripan (null saat enrollment).
 * @param source        "SERVER" / "LOKAL" — dinyatakan siapa yang memutuskan.
 * @param enrolled      true bila baru selesai enrollment.
 * @param basePhotoBase64 foto dasar wajah (jpeg base64).
 */
data class FaceResult(
    val faceDetected: Boolean,
    val livenessPassed: Boolean,
    val match: Boolean = false,
    val score: Int? = null,
    val source: String = "LOKAL",
    val message: String? = null,
    val enrolled: Boolean = false,
    val basePhotoBase64: String? = null,
)

/**
 * Kamera depan (CameraX) + verifikasi wajah **berbasis server**.
 *
 * Pembagian tugas:
 *  - **Perangkat** menjalankan liveness pasif + kualitas frame + ekstraksi
 *    signature (butuh frame kamera mentah).
 *  - **Server** menyimpan sample enrollment & memutuskan cocok/tidak
 *    (lihat [FaceRepository]). Jika server tak terjangkau, keputusan
 *    fallback ke mesin lokal (ditandai `source = "LOKAL"`).
 */
@Composable
fun FaceScanView(
    api: ApiClient,
    onCancel: () -> Unit,
    onResult: (FaceResult) -> Unit,
    /** true = WAJIB merekam ulang (abaikan status terdaftar). Dipakai dari tab Profil. */
    forceEnroll: Boolean = false,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val service = remember { FaceMatchingService(context) }
    val repo = remember { FaceRepository(api, context) }
    val executor = remember { Executors.newSingleThreadExecutor() }

    // ---- status ----
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    // Buffer frame live (dari ImageAnalysis) untuk liveness tantangan.
    // AtomicReference: ditulis dari thread analyzer, dibaca dari thread UI.
    val liveHolder = remember { java.util.concurrent.atomic.AtomicReference<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf("Memeriksa data wajah…") }
    var quality by remember { mutableIntStateOf(0) }
    var capturable by remember { mutableStateOf(false) }
    // Kemiripan LIVE terhadap wajah terdaftar (%). -1 = belum tersedia.
    var liveSimilarity by remember { mutableIntStateOf(-1) }
    // Riwayat skor terakhir untuk smoothing (ambil yang terbaik -> lebih stabil).
    val recentSim = remember { mutableStateListOf<Int>() }
    // Hasil deteksi frame live (untuk hint & jalur verifikasi cepat).
    var liveFaceDetected by remember { mutableStateOf(false) }
    var liveTemplate by remember { mutableStateOf<String?>(null) }

    // ---- mode: null = memuat, true = enroll, false = verify ----
    var enrolling by remember { mutableStateOf<Boolean?>(null) }
    val sessionSamples = remember { mutableStateListOf<String>() }
    var enrollCount by remember { mutableIntStateOf(0) }

    // Template tersimpan untuk kemiripan LIVE (mode verifikasi saja).
    var storedTemplates by remember { mutableStateOf<List<String>>(emptyList()) }

    // Foto sample tersimpan (base64 JPEG) -> thumbnail di pojok kiri atas.
    var samplePhotoB64 by remember { mutableStateOf<String?>(null) }

    val saveBasePhoto: (Bitmap) -> String = { bmp ->
        runCatching {
            val f = File(context.cacheDir, "face_${System.currentTimeMillis()}.jpg")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            f.absolutePath
        }.getOrDefault("")
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { hasPermission = it }

    LaunchedEffect(Unit) {
        if (!hasPermission) permLauncher.launch(Manifest.permission.CAMERA)
    }

    // Tentukan mode dari status enrollment server (fallback lokal).
    LaunchedEffect(Unit) {
        val state = runCatching { repo.enrollmentState() }
            .getOrElse { FaceRepository.EnrollmentState(false, false, "LOKAL") }
        // Mode paksa (dari tab Profil): selalu enroll, walau sudah terdaftar.
        enrolling = forceEnroll || !state.enrolled
        // Muat template tersimpan untuk kemiripan LIVE.
        storedTemplates = runCatching { repo.localTemplates() }.getOrDefault(emptyList())
        // Muat FOTO SAMPLE tersimpan (server -> cache lokal) untuk thumbnail.
        samplePhotoB64 = runCatching { repo.storedSamplePhoto() }.getOrNull()
        sessionSamples.clear()
        enrollCount = 0
        hint = when {
            forceEnroll -> "Rekam ulang wajah — hadapkan wajah lalu tekan tombol"
            state.outdated -> "Data wajah lama perlu direkam ulang (keamanan)"
            state.enrolled -> "Hadapkan wajah lurus ke kamera"
            else -> "Hadapkan wajah lalu tekan tombol untuk merekam"
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { service.reset() }
            runCatching { executor.shutdown() }
        }
    }

    if (!hasPermission) {
        Column(
            modifier = Modifier.fillMaxSize().background(KartiniColors.BrandGreenDeep),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("Izin kamera diperlukan", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { permLauncher.launch(Manifest.permission.CAMERA) },
                colors = ButtonDefaults.buttonColors(containerColor = KartiniColors.BrandOrange),
            ) { Text("Izinkan Kamera") }
            TextButton(onClick = onCancel) { Text("Batal", color = Color.White) }
        }
        return
    }

    // ---- monitor kualitas + kemiripan LIVE ----
    // Memakai JPEG ImageCapture (JALUR YANG SAMA dengan tombol "Verifikasi & Absen"),
    // bukan frame grayscale ImageAnalysis — karena frame grayscale kerap gagal
    // dideteksi ML Kit, sehingga angka kemiripan tak pernah muncul.
    LaunchedEffect(Unit) {
        while (true) {
            try {
                val cap = imageCapture
                if (cap != null && !busy && enrolling != null) {
                    val bmp = runCatching { captureFrame(cap, executor) }.getOrNull()
                    if (bmp != null) {
                        val tpl = runCatching { service.captureTemplate(bmp) }.getOrNull()
                        if (tpl != null) {
                            liveTemplate = tpl
                            liveFaceDetected = true
                            capturable = true
                            quality = 100
                            if (enrolling == false && storedTemplates.isNotEmpty()) {
                                val scores = storedTemplates.map {
                                    com.absensiku.app.face.engine.util.FaceTemplateMatcher.matchScore(tpl, it)
                                }.filter { it >= 0.0 }
                                if (scores.isNotEmpty()) {
                                    // Skor LIVE = metrik KEPUTUSAN (mayoritas sample),
                                    // bukan skor maksimum satu sample. Ini membuat angka
                                    // di layar konsisten dengan hasil verifikasi.
                                    val need = if (scores.size == 1) 1 else Math.ceil(scores.size / 2.0).toInt()
                                    val top = scores.sortedDescending().take(need)
                                    val rep = top.sum() / need
                                    recentSim.add(rep.toInt().coerceIn(0, 100))
                                    if (recentSim.size > 6) recentSim.removeAt(0)
                                    // Median riwayat: angka tidak "melompat".
                                    val sortedWindow = recentSim.sorted()
                                    val n = sortedWindow.size
                                    val median = if (n % 2 == 1) sortedWindow[n / 2]
                                    else (sortedWindow[n / 2 - 1] + sortedWindow[n / 2]) / 2
                                    liveSimilarity = median.coerceIn(0, 100)
                                }
                            }
                        } else {
                            liveFaceDetected = false
                            capturable = false
                            if (enrolling == false) liveSimilarity = -1
                        }
                        runCatching { bmp.recycle() }
                    }
                }
            } catch (_: Throwable) {
                // Jangan pernah biarkan loop ini mematikan aplikasi.
            }
            delay(QUALITY_INTERVAL_MS)
        }
    }

    // Hint dinamis berdasar deteksi live.
    LaunchedEffect(liveFaceDetected, enrolling) {
        if (enrolling == false) {
            hint = if (liveFaceDetected) "Hadapkan wajah lurus ke kamera" else "Posisikan wajah Anda di dalam bingkai"
        }
    }

    val loading = enrolling == null

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        // ================= OVERLAY ATAS (judul + hint) =================
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.65f), Color.Black.copy(alpha = 0.20f), Color.Transparent)
                    )
                )
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                when {
                    loading -> "Menyiapkan…"
                    enrolling == true -> "Rekam Wajah"
                    else -> "Verifikasi Wajah"
                },
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp,
            )
            Spacer(Modifier.height(8.dp))
            Surface(color = Color.White.copy(alpha = 0.20f), shape = RoundedCornerShape(50)) {
                Text(
                    text = hint,
                    color = Color.White,
                    fontSize = 12.5.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                )
            }
        }

        // ================= AREA KAMERA + BINGKAI (ruang tersisa) =================
        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val providerFuture = ProcessCameraProvider.getInstance(ctx)
                    providerFuture.addListener({
                        val provider = providerFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }
                        val capture = ImageCapture.Builder()
                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                            .build()
                        imageCapture = capture

                        try {
                            provider.unbindAll()
                            provider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_FRONT_CAMERA,
                                preview,
                                capture,
                            )
                        } catch (_: Throwable) {
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                },
                modifier = Modifier.fillMaxSize(),
            )

            // ====== THUMBNAIL SAMPLE TERSIMPAN (pojok kiri atas) ======
            // Menampilkan foto wajah yang sudah disimpan di server, supaya
            // karyawan dapat membandingkan "ini saya" sebelum memotret.
            if (samplePhotoB64 != null) {
                val sampleBitmap = remember(samplePhotoB64) {
                    runCatching {
                        val bytes = Base64.decode(samplePhotoB64, Base64.DEFAULT)
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    }.getOrNull()
                }
                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 12.dp, top = 12.dp)
                        .wrapContentSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .border(2.dp, KartiniColors.BrandGreenSoft, RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.10f)),
                    ) {
                        if (sampleBitmap != null) {
                            Image(
                                bitmap = sampleBitmap.asImageBitmap(),
                                contentDescription = "Sample wajah tersimpan",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)),
                            )
                        } else {
                            Text(
                                "Sample",
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.align(Alignment.Center),
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Surface(
                        color = Color.Black.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(50),
                    ) {
                        Text(
                            "Sample tersimpan",
                            color = Color.White,
                            fontSize = 9.5.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                    }
                }
            }

            // Bingkai oval wajah — UKURAN ADAPTIF mengikuti ukuran layar HP
            // (dihitung dari lebar & tinggi area kamera, bukan ukuran tetap).
            BoxWithConstraints(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                val availW = maxWidth
                val availH = maxHeight
                // Oval wajah: ~72% lebar area (maks 300dp) & ~66% tinggi area (maks 380dp).
                val ovalW = minOf(availW * 0.72f, 300.dp)
                val ovalH = minOf(availH * 0.66f, 380.dp)

                Box(
                    modifier = Modifier
                        .size(width = ovalW, height = ovalH)
                        .clip(RoundedCornerShape(percent = 50))
                        .border(
                            width = 3.dp,
                            color = when {
                                enrolling == false && liveFaceDetected -> KartiniColors.BrandGreenSoft
                                enrolling == true && capturable -> KartiniColors.BrandGreenSoft
                                else -> Color.White.copy(alpha = 0.7f)
                            },
                            shape = RoundedCornerShape(percent = 50),
                        ),
                )
            }
        }

        // ================= PANEL BAWAH (tombol + status) =================
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f), Color.Black.copy(alpha = 0.85f))
                    )
                )
                .navigationBarsPadding()
                .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (enrolling == true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Sample: $enrollCount/$ENROLL_SAMPLES_NEEDED", color = Color.White, fontSize = 13.sp)
                    Spacer(Modifier.width(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        repeat(ENROLL_SAMPLES_NEEDED) { i ->
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (i < enrollCount) KartiniColors.BrandGreenSoft
                                        else Color.White.copy(alpha = 0.35f)
                                    )
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            // Kualitas / Kemiripan — angka persentase saja (tanpa progress bar).
            Surface(
                color = Color.White.copy(alpha = 0.14f),
                shape = RoundedCornerShape(50),
            ) {
                if (enrolling == false) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                    ) {
                        Text("Kemiripan (live)", color = Color.White.copy(alpha = 0.85f), fontSize = 12.5.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            if (liveSimilarity < 0) "…" else "$liveSimilarity%",
                            color = when {
                                liveSimilarity >= 55 -> KartiniColors.BrandGreenSoft
                                liveSimilarity >= 40 -> KartiniColors.BrandOrangeSoft
                                else -> Color.White
                            },
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                        )
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                    ) {
                        Text("Kualitas Wajah", color = Color.White.copy(alpha = 0.85f), fontSize = 12.5.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            "$quality%",
                            color = when {
                                capturable -> KartiniColors.BrandGreenSoft
                                quality >= 60 -> KartiniColors.BrandOrangeSoft
                                else -> Color.White
                            },
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Button(
                enabled = !busy && !loading,
                onClick = {
                    val cap = imageCapture ?: return@Button
                    busy = true
                    scope.launch {
                        var bmp: Bitmap? = null
                        try {
                            bmp = captureFrame(cap, executor)
                            if (bmp == null) { hint = "Gagal membaca frame kamera"; return@launch }
                            if (enrolling == true) {
                                handleEnroll(
                                    bitmap = bmp,
                                    service = service,
                                    repo = repo,
                                    sessionSamples = sessionSamples,
                                    saveBasePhoto = saveBasePhoto,
                                    onProgress = { hint = it; enrollCount = sessionSamples.size },
                                    onEnrolled = { b64 ->
                                        samplePhotoB64 = b64
                                        enrolling = false
                                        onResult(FaceResult(true, true, enrolled = true, basePhotoBase64 = b64))
                                    },
                                    onFail = { hint = it },
                                )
                            } else {
                                // Verifikasi: pakai TEMPLATE LIVE bila tersedia
                                // (menghindari deteksi ulang), jika tidak ambil dari frame baru.
                                val dec = liveTemplate?.let {
                                    repo.verifyTemplate(it, FaceMatchingService.TPL_MATCH)
                                } ?: handleVerify(
                                    bitmap = bmp,
                                    service = service,
                                    repo = repo,
                                    hint = { hint = it },
                                )
                                if (dec != null) {
                                    onResult(
                                        FaceResult(
                                            faceDetected = true,
                                            livenessPassed = true,
                                            match = dec.match,
                                            score = dec.score,
                                            source = dec.source,
                                            message = dec.message,
                                        )
                                    )
                                }
                            }
                        } catch (e: Throwable) {
                            // Tangkap SEMUA error agar aplikasi TIDAK crash/keluar sendiri.
                            hint = e.message ?: "Terjadi kendala saat memproses wajah. Coba lagi."
                        } finally {
                            runCatching { bmp?.recycle() }
                            busy = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (capturable) KartiniColors.BrandGreen else KartiniColors.BrandOrange,
                    contentColor = Color.White,
                    disabledContainerColor = KartiniColors.Olive.copy(alpha = 0.5f),
                    disabledContentColor = Color.White,
                ),
            ) {
                if (busy) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Memproses…", fontWeight = FontWeight.Bold)
                } else {
                    Text(
                        if (enrolling == true) "Rekam Sample Wajah" else "Verifikasi & Absen",
                        fontWeight = FontWeight.Bold, fontSize = 15.5.sp,
                    )
                }
            }
            if (enrolling == false) {
                TextButton(
                    onClick = {
                        sessionSamples.clear()
                        enrollCount = 0
                        enrolling = true
                        hint = "Rekam ulang wajah"
                    }
                ) { Text("Rekam ulang wajah", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp) }
            }
            TextButton(onClick = onCancel) { Text("Batal", color = Color.White) }
        }
    }
}

/**
 * Enrollment: cukup DETEKSI WAJAH (tanpa liveness) + template TEKSTUR (v5) per sample.
 * Semua sample dikirim ke server (fallback lokal bila offline).
 */
private suspend fun handleEnroll(
    bitmap: Bitmap,
    service: FaceMatchingService,
    repo: FaceRepository,
    sessionSamples: MutableList<String>,
    saveBasePhoto: (Bitmap) -> String,
    onProgress: (String) -> Unit,
    onEnrolled: (String) -> Unit,
    onFail: (String) -> Unit,
) {
    val det = service.detectFace(bitmap)
    if (!det.faceDetected || det.face == null) {
        onFail(det.error ?: "Wajah tidak terdeteksi. Posisikan wajah di dalam bingkai.")
        return
    }
    // Pakai hasil deteksi yang sama untuk ekstraksi (hindari deteksi ke-2).
    val template = service.captureTemplateWithFace(bitmap, det.face)
    if (template == null) {
        onFail("Template wajah gagal dibentuk. Posisikan wajah lebih jelas & dekat.")
        return
    }
    sessionSamples.add(template)
    if (sessionSamples.size >= ENROLL_SAMPLES_NEEDED) {
        val b64 = bitmap.toBase64Jpeg()
        val path = saveBasePhoto(bitmap)
        if (path.isNotBlank()) repo.cacheBasePhoto(path)
        repo.enrollTemplates(sessionSamples.toList(), b64)
        onEnrolled(b64)
    } else {
        onProgress("Sample ${sessionSamples.size}/$ENROLL_SAMPLES_NEEDED tersimpan. Ambil sample berikutnya.")
    }
}

/**
 * Verifikasi sederhana: cukup DETEKSI WAJAH (tanpa liveness/tantangan gerakan).
 *  1. Pastikan wajah terdeteksi (dan lurus/tidak menoleh).
 *  2. Bandingkan TEMPLATE TEKSTUR dengan sample tersimpan (server/lokal).
 */
private suspend fun handleVerify(
    bitmap: Bitmap,
    service: FaceMatchingService,
    repo: FaceRepository,
    hint: (String) -> Unit,
): VerifyDecision? {
    // SATU kali deteksi -> dapatkan jumlah wajah, mata, yaw, dan template sekaligus.
    val probe = service.buildProbe(bitmap)
    if (!probe.faceDetected) {
        hint(probe.message ?: "Wajah tidak terdeteksi")
        return null
    }
    if (probe.faceCount > 1) {
        hint("Pastikan hanya satu wajah yang terlihat di kamera.")
        return null
    }
    // Catatan: syarat "mata terbuka" DILONGGARKAN (hanya sebagai peringatan),
    // agar absensi tidak sering gagal saat deteksi sesaat tidak konsisten.
    val template = probe.template
    if (template == null) {
        hint("Template wajah gagal dibentuk. Posisikan lebih dekat & lurus.")
        return null
    }
    // Selalu kembalikan keputusan (cocok ATAU tidak cocok) ke pemanggil agar
    // UI dapat menampilkan notifikasi profesional saat wajah tidak cocok.
    return repo.verifyTemplate(template, FaceMatchingService.TPL_MATCH)
}

/** Ambil satu frame JPEG dari [ImageCapture] menjadi Bitmap (rotasi diterapkan). */
private suspend fun captureFrame(capture: ImageCapture, executor: java.util.concurrent.Executor): Bitmap? =
    suspendCancellableCoroutine { cont ->
        capture.takePicture(
            executor,
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val bmp = imageProxyToBitmap(image)
                    image.close()
                    cont.resume(bmp)
                }

                override fun onError(exception: ImageCaptureException) {
                    cont.resume(null)
                }
            },
        )
    }

private fun imageProxyToBitmap(image: ImageProxy): Bitmap? =
    try {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        // Decode terukur: hitung ukuran asli dulu, lalu subsample agar tidak OOM.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val opts = BitmapFactory.Options().apply {
            inSampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, MAX_FACE_DIM)
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null
        val rotation = image.imageInfo.rotationDegrees
        if (rotation != 0) bmp = bmp.rotate(rotation.toFloat())
        // Batasi dimensi akhir agar hemat memori.
        val maxDim = maxOf(bmp.width, bmp.height)
        if (maxDim > MAX_FACE_DIM) {
            val scale = MAX_FACE_DIM.toFloat() / maxDim
            val scaled = Bitmap.createScaledBitmap(
                bmp, (bmp.width * scale).toInt().coerceAtLeast(1),
                (bmp.height * scale).toInt().coerceAtLeast(1), true
            )
            bmp.recycle()
            bmp = scaled
        }
        bmp
    } catch (_: Throwable) {
        null
    }

/** Hitung inSampleSize (pangkat 2) agar dimensi <= reqDim. */
private fun calculateInSampleSize(width: Int, height: Int, reqDim: Int): Int {
    var sample = 1
    var w = width
    var h = height
    while (w / 2 >= reqDim && h / 2 >= reqDim) {
        w /= 2
        h /= 2
        sample *= 2
    }
    return sample
}

/** Frame analisis hemat memori: konversi Y-plane → bitmap grayscale (rotasi diterapkan). */
private fun imageProxyToGrayscale(image: ImageProxy): Bitmap? =
    try {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val w = image.width
        val h = image.height
        val bytes = ByteArray(w * h)
        val rowBytes = ByteArray(rowStride)
        for (row in 0 until h) {
            buffer.position(row * rowStride)
            val toRead = minOf(rowStride, buffer.remaining())
            buffer.get(rowBytes, 0, toRead)
            for (col in 0 until w) {
                bytes[row * w + col] = rowBytes[col * pixelStride]
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h)
        for (i in 0 until w * h) {
            val g = bytes[i].toInt() and 0xFF
            pixels[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
        }
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        val rotation = image.imageInfo.rotationDegrees
        if (rotation == 0) bmp else bmp.rotate(rotation.toFloat())
    } catch (_: Throwable) {
        null
    }

private fun Bitmap.rotate(degrees: Float): Bitmap {
    val matrix = Matrix().apply { postRotate(degrees) }
    return Bitmap.createBitmap(this, 0, 0, width, height, matrix, true)
}

private fun Bitmap.toBase64Jpeg(quality: Int = 80): String {
    val bos = ByteArrayOutputStream()
    compress(Bitmap.CompressFormat.JPEG, quality, bos)
    return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
}
