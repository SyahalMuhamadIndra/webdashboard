package com.absensiku.app.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File

/**
 * B67 — PEMUAT GAMBAR DESAIN (Level 2).
 *
 * Memuat logo / gambar header / splash / latar login yang dikirim server,
 * mendukung dua bentuk:
 *   1. data URI  : "data:image/png;base64,...."  (unggahan dari panel admin)
 *   2. tautan    : "https://..."                 (tautan gambar)
 *
 * Dilengkapi:
 *   - cache memori (LruCache)  -> gambar tidak diunduh berulang
 *   - cache disk  (OkHttp)     -> tetap tampil saat SINYAL BURUK / offline
 *
 * Bila sumber kosong atau gagal dimuat, pemanggil memakai gambar bawaan
 * (resource) sehingga tampilan TIDAK PERNAH kosong/rusak.
 */
object BrandImageLoader {

    private val client: OkHttpClient by lazy {
        val cacheDir = File(System.getProperty("java.io.tmpdir") ?: "/tmp", "brand_img")
        OkHttpClient.Builder()
            .cache(runCatching { Cache(cacheDir, 20L * 1024 * 1024) }.getOrNull())
            .build()
    }

    private val mem = LruCache<String, ImageBitmap>(24)

    /** Muat gambar dari data-URI base64 atau tautan http(s). Null bila gagal. */
    suspend fun load(src: String?): ImageBitmap? {
        if (src.isNullOrBlank()) return null
        mem.get(src)?.let { return it }
        val bmp = withContext(Dispatchers.IO) {
            runCatching {
                if (src.startsWith("data:")) decodeDataUri(src) else fetchUrl(src)
            }.getOrNull()
        } ?: return null
        val ib = bmp.asImageBitmap()
        mem.put(src, ib)
        return ib
    }

    private fun decodeDataUri(src: String): Bitmap? {
        val comma = src.indexOf(',')
        if (comma < 0) return null
        val b64 = src.substring(comma + 1)
        val bytes = runCatching { Base64.decode(b64, Base64.DEFAULT) }.getOrNull() ?: return null
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun fetchUrl(url: String): Bitmap? {
        val req = Request.Builder().url(url).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body ?: return null
            val bytes = body.bytes()
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }
    }
}

/**
 * Gambar desain: pakai [src] (data-URI/tautan) bila ada; jika tidak,
 * jatuh ke [fallbackRes] (gambar bawaan aplikasi).
 */
@Composable
fun BrandImage(
    src: String?,
    fallbackRes: Int,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Fit,
) {
    val ctx: Context = LocalContext.current
    if (src.isNullOrBlank()) {
        Image(
            painter = painterResource(fallbackRes),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale,
        )
        return
    }
    // Kunci cache memori per-src; ctx dipakai agar cache disk punya folder valid.
    val loaded by produceState<ImageBitmap?>(initialValue = null, key1 = src, key2 = ctx) {
        value = BrandImageLoader.load(src)
    }
    val bmp = loaded
    if (bmp != null) {
        Image(
            bitmap = bmp,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale,
        )
    } else {
        // Selagi memuat / bila gagal: tampilkan gambar bawaan agar tidak kosong.
        Image(
            painter = painterResource(fallbackRes),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale,
        )
    }
}
