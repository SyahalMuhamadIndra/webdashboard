package com.absensiku.app.screens

import android.graphics.Bitmap
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.R
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.CompanyConfig
import com.absensiku.app.api.MeResponse
import com.absensiku.app.api.TodayAttendance
import com.absensiku.app.location.LocationResult
import com.absensiku.app.location.LocationValidator
import com.absensiku.app.location.LocationValidator.Companion.distanceMeters
import com.absensiku.app.ui.components.BrandLogo
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle as DateTextStyle
import java.util.Locale

private fun izNow(): OffsetDateTime = OffsetDateTime.now(ZoneId.systemDefault())

/** Maksimum percobaan menyempurnakan akurasi GPS saat halaman Absen dipoll. */
private const val MAX_GPS_TRIES = 8

/** Jeda antar percobaan GPS (ms). */
private const val GPS_POLL_INTERVAL_MS = 1200L

/** B51: umur maksimum item antrian offline sebelum dibuang (24 jam). */
private const val STALE_QUEUE_MS = 24L * 60L * 60L * 1000L

private fun formatDateId(): String {
    val now = izNow()
    val day = now.format(DateTimeFormatter.ofPattern("d", Locale("id", "ID")))
    val month = now.month.getDisplayName(DateTextStyle.FULL, Locale("id", "ID"))
    return "$day $month ${now.year}"
}

private fun formatTime(iso: String?): String {
    if (iso.isNullOrBlank()) return "--:--"
    return runCatching {
        OffsetDateTime.parse(iso).atZoneSameInstant(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("HH:mm"))
    }.getOrElse { "--:--" }
}

private fun formatHm(hm: String?): String =
    if (hm.isNullOrBlank()) "-" else hm.substring(0, minOf(5, hm.length))

/** Decode foto profil (base64 JPEG tanpa prefix) → Bitmap, atau null bila kosong. */
private fun decodePhoto(b64: String?): Bitmap? {
    if (b64.isNullOrBlank()) return null
    return runCatching {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }.getOrNull()
}

@Composable
fun AbsenScreen(
    api: ApiClient,
    locationValidator: LocationValidator,
    onCheckIn: () -> Unit,
    onCheckOut: () -> Unit,
    showMessage: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var me by remember { mutableStateOf<MeResponse?>(null) }
    var photoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var config by remember { mutableStateOf<CompanyConfig?>(null) }
    var today by remember { mutableStateOf<TodayAttendance?>(null) }
    var distance by remember { mutableStateOf<Double?>(null) }
    var accuracy by remember { mutableStateOf<Float?>(null) }
    var inZone by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(true) }
    var fixAttempts by remember { mutableStateOf(0) }
    // Jumlah absensi yang masih menunggu terkirim (antrian offline) — B51.
    var pendingCount by remember { mutableStateOf(0) }
    var syncing by remember { mutableStateOf(false) }
    // Hasil GPS terakhir — dipakai untuk menghitung ulang jarak/zona ketika
    // pengaturan kantor baru datang dari jaringan (B53).
    var lastLoc by remember { mutableStateOf<LocationResult?>(null) }

    // Hitung ulang jarak/zona dari sebuah hasil lokasi + config yang ada.
    fun applyLocation(r: LocationResult, cfg: CompanyConfig?) {
        lastLoc = r
        when (r) {
            is LocationResult.Success -> {
                accuracy = r.accuracyMeters
                if (cfg != null) {
                    val d = distanceMeters(r.latitude, r.longitude, cfg.officeLatitude, cfg.officeLongitude)
                    distance = d
                    // B51: zona memakai RADIUS EFEKTIF (radius kantor + toleransi
                    // pergeseran GPS) dan TIDAK lagi mensyaratkan akurasi presisi.
                    // Tujuannya agar absensi tidak ditolak hanya karena GPS
                    // bergeser beberapa meter / akurasi sedang.
                    inZone = d <= cfg.effectiveRadiusMeters && !r.isMock
                }
            }
            else -> Unit
        }
    }

    // poll == true -> terus menyegarkan GPS (dipakai halaman Absen) supaya akurasi
    // naik & zona terdeteksi otomatis tanpa harus menekan Refresh berulang kali.
    fun refresh(poll: Boolean = false) {
        scope.launch {
            busy = true
            try {
                // ================= [1] BACA GPS LEBIH DULU (B53) =================
                // PENTING: GPS itu SATELIT — sama sekali TIDAK butuh internet.
                // Sebelumnya GPS baru dibaca SETELAH request jaringan berhasil,
                // sehingga saat sinyal jelek GPS tidak pernah dibaca padahal
                // GPS-nya sendiri normal. Sekarang GPS dibaca lebih dulu, memakai
                // pengaturan kantor dari SALINAN LOKAL bila jaringan belum siap.
                // B54: SELALU ada pengaturan kantor — dari server, dari salinan
                // login terakhir, atau fallback bawaan. Jadi pembacaan GPS +
                // perhitungan zona BERFUNGSI SEJAK DETIK PERTAMA tanpa internet.
                val cfgForGps = config ?: api.effectiveOfficeConfig()
                config = cfgForGps
                val target = cfgForGps.minimumLocationAccuracyMeters
                    .toFloat().coerceIn(10f, 100f)

                var attempts = 0
                while (true) {
                    val r = locationValidator.getCurrentLocation(targetAccuracyMeters = target)
                    applyLocation(r, cfgForGps)
                    attempts++
                    fixAttempts = attempts

                    // Berhenti lebih cepat: cukup berada di dalam radius efektif.
                    val good = r is LocationResult.Success &&
                        distance != null && distance!! <= cfgForGps.effectiveRadiusMeters
                    if (!poll || good || attempts >= MAX_GPS_TRIES) break
                    delay(GPS_POLL_INTERVAL_MS)
                }

                // ================= [2] MUAT DATA JARINGAN (TAHAN GAGAL) =================
                // Kegagalan jaringan TIDAK membatalkan pembacaan GPS di atas.
                val data = api.loadAbsenDataResilient()
                data.me?.let { m ->
                    me = m
                    photoBitmap = decodePhoto(m.photoBase64)
                }
                data.today?.let { today = it }
                data.config?.let { c ->
                    config = c
                    // Hitung ulang jarak/zona memakai pengaturan kantor terbaru.
                    lastLoc?.let { applyLocation(it, c) }
                }
                if (data.offline) {
                    // Beri tahu bahwa jaringan buruk, tapi GPS/absen tetap jalan.
                    data.message?.let { showMessage(it) }
                }
                pendingCount = api.queue.pendingCount()
            } catch (e: kotlinx.coroutines.CancellationException) {

                throw e

            } catch (e: Exception) {
                showMessage(e.message ?: "Gagal memuat")
            } finally { busy = false }
        }
    }

    // B51: buang antrian yang sudah BASI (lebih dari 24 jam) agar tidak menumpuk.
    fun pruneStaleQueue() {
        val stale = api.queue.pending().filter { it.ageMillis > STALE_QUEUE_MS }
        if (stale.isNotEmpty()) {
            val keep = api.queue.pending().filterNot { it.ageMillis > STALE_QUEUE_MS }
            api.queue.replaceForPrune(keep)
        }
        pendingCount = api.queue.pendingCount()
    }

    /**
     * B51: kirim antrian absen offline. Dipanggil otomatis saat halaman dibuka
     * dan saat pengguna menekan tombol di banner antrian.
     */
    fun flushQueue(notify: Boolean) {
        if (api.queue.pendingCount() == 0) { pendingCount = 0; return }
        scope.launch {
            syncing = true
            try {
                val out = api.queue.syncNow()
                pendingCount = api.queue.pendingCount()
                if (notify) {
                    when {
                        out.offline -> showMessage("Belum ada koneksi. Antrian absen tetap tersimpan.")
                        out.sent + out.duplicates > 0 ->
                            showMessage("${out.sent + out.duplicates} absensi berhasil dikirim ke server.")
                        else -> showMessage("Antrian absen: ${out.remaining} menunggu terkirim.")
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (notify) showMessage(e.message ?: "Sinkronisasi gagal")
            } finally { syncing = false }
        }
    }

    LaunchedEffect(Unit) {
        pruneStaleQueue()
        refresh(poll = true)
    }

    // B51: coba kirim antrian otomatis begitu halaman Absen terbuka (bila ada).
    // Sengaja dipisah dari refresh() agar tidak menunggu GPS lebih dulu.
    LaunchedEffect(Unit) {
        if (api.queue.pendingCount() > 0) flushQueue(notify = false)
    }

    val checkInAt = today?.checkInAt
    val checkOutAt = today?.checkOutAt
    val hasCheckIn = !checkInAt.isNullOrBlank()
    val hasCheckOut = !checkOutAt.isNullOrBlank()
    val canCheckOut = hasCheckIn && !hasCheckOut
    val canCheckIn = !hasCheckIn

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(KartiniColors.CreamBg)
            .verticalScroll(rememberScrollState())
    ) {
        // ---------- Header hero (rounded bottom) ----------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(Brush.verticalGradient(listOf(KartiniColors.BrandGreenDark, KartiniColors.BrandGreen)))
                .padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 30.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = Color.White.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.size(40.dp),
                    ) {
                        Box(modifier = Modifier.padding(7.dp), contentAlignment = Alignment.Center) {
                            BrandLogo(size = 26.dp, onDark = true)
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(com.absensiku.app.ui.theme.BrandingPalette.displayName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(com.absensiku.app.ui.theme.BrandingPalette.tagline, color = Color.White.copy(alpha = 0.72f), fontSize = 11.5.sp)
                    }
                    Surface(color = Color.White.copy(alpha = 0.18f), shape = RoundedCornerShape(50)) {
                        Text(
                            text = me?.position ?: "Karyawan",
                            color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        )
                    }
                }
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(48.dp).clip(CircleShape).background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        val bmp = photoBitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(CircleShape),
                            )
                        } else {
                            Text(
                                text = (me?.fullName?.take(1) ?: api.employeeName().take(1)).uppercase(),
                                color = KartiniColors.BrandGreen, fontWeight = FontWeight.Bold, fontSize = 20.sp
                            )
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Halo, ${me?.fullName?.substringBefore(' ') ?: api.employeeName().substringBefore(' ')} 👋",
                            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(formatDateId(), color = Color.White.copy(alpha = 0.80f), fontSize = 12.5.sp)
                    }
                }
            }
        }

        // ---------- Konten (di bawah header, tanpa tumpang tindih) ----------
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(top = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            AttendanceCard(checkInAt, checkOutAt, distance, accuracy, inZone, config?.officeRadiusMeters, config?.effectiveRadiusMeters)
            // B51: banner antrian absen offline (hanya tampil bila ada antrian).
            if (pendingCount > 0) {
                PendingQueueBanner(
                    count = pendingCount,
                    syncing = syncing,
                    onSync = { flushQueue(notify = true) },
                )
            }
            OfficeCard(config)
            ScheduleCard(today)
            Spacer(Modifier.height(4.dp))
            CheckButton(
                enabled = !busy && (canCheckIn || canCheckOut),
                canCheckOut = canCheckOut,
                onCheckIn = onCheckIn,
                onCheckOut = onCheckOut,
            )
            Spacer(Modifier.height(4.dp))
            RefreshFooter(
                busy = busy,
                inZone = inZone,
                fixAttempts = fixAttempts,
                onRefresh = { refresh(poll = true) },
            )
            Spacer(Modifier.height(36.dp))
        }
    }
}

// ---------------- Kartu status absensi (hero card) ----------------

@Composable
private fun AttendanceCard(
    inAt: String?,
    outAt: String?,
    distanceMeters: Double?,
    accuracy: Float?,
    inZone: Boolean,
    radiusMeters: Double?,
    effectiveRadiusMeters: Double? = null,
) {
    val inFilled = !inAt.isNullOrBlank()
    val outFilled = !outAt.isNullOrBlank()
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
    ) {
        Column(
            modifier = Modifier
                .background(Brush.verticalGradient(listOf(KartiniColors.BrandGreenDeep, KartiniColors.BrandGreen)))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Status Hari Ini", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(2.dp))
                    Text(formatDateId(), color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
                }
                StatusChip(
                    text = if (outFilled) "Selesai" else if (inFilled) "Sedang bekerja" else "Belum absen",
                    filled = outFilled,
                )
            }
            Spacer(Modifier.height(18.dp))

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TimeBlock(R.drawable.ic_check_in_box, "Check In", formatTime(inAt), inFilled, Modifier.weight(1f))
                Box(
                    modifier = Modifier.padding(horizontal = 8.dp).size(width = 1.dp, height = 44.dp)
                        .background(Color.White.copy(alpha = 0.22f))
                )
                TimeBlock(R.drawable.ic_check_out_box, "Check Out", formatTime(outAt), outFilled, Modifier.weight(1f))
            }

            Spacer(Modifier.height(18.dp))
            LocationStatusStrip(inZone, distanceMeters, accuracy, radiusMeters, effectiveRadiusMeters)
        }
    }
}

/**
 * B51: Banner ANTRIAN ABSEN OFFLINE.
 *
 * Muncul hanya bila ada absensi yang belum terkirim ke server (mis. karena
 * sinyal buruk di lokasi kerja). Karyawan melihat bahwa absennya SUDAH
 * tersimpan — bukan gagal — dan bisa menekan "Kirim" kapan pun ada sinyal.
 */
@Composable
private fun PendingQueueBanner(count: Int, syncing: Boolean, onSync: () -> Unit) {
    Surface(
        color = KartiniColors.BrandOrangeSoft,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(start = 14.dp, top = 10.dp, end = 6.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                painterResource(R.drawable.ic_clock_line), contentDescription = null,
                tint = KartiniColors.BrandOrangeDeep, modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "$count absensi tersimpan di HP",
                    color = KartiniColors.BrandGreenDeep, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "Belum terkirim karena sinyal. Waktu absen TETAP tercatat saat Anda scan — tidak jadi telat.",
                    color = KartiniColors.OnSurfaceMuted, fontSize = 11.5.sp,
                )
            }
            TextButton(onClick = onSync, enabled = !syncing) {
                if (syncing) {
                    CircularProgressIndicator(
                        color = KartiniColors.BrandGreen, modifier = Modifier.size(16.dp), strokeWidth = 2.dp,
                    )
                } else {
                    Text(
                        "Kirim", color = KartiniColors.BrandGreen,
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}

@Composable
private fun TimeBlock(icon: Int, label: String, value: String, filled: Boolean, modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(11.dp))
                .background(if (filled) Color.White else Color.White.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(icon), contentDescription = null,
                tint = if (filled) KartiniColors.BrandGreen else Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(21.dp),
            )
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label, color = Color.White.copy(alpha = 0.72f), fontSize = 11.5.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun LocationStatusStrip(
    inZone: Boolean,
    distanceMeters: Double?,
    accuracy: Float?,
    radiusMeters: Double?,
    effectiveRadiusMeters: Double? = null,
) {
    val title = when {
        inZone -> "Lokasi terdeteksi di dalam area kantor"
        distanceMeters != null -> "Anda di luar area kantor"
        else -> "Mendeteksi lokasi GPS…"
    }
    val bg = if (inZone) Color.White.copy(alpha = 0.16f) else KartiniColors.BrandOrange.copy(alpha = 0.26f)
    val accent = if (inZone) Color.White else KartiniColors.BrandOrangeSoft

    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(bg).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(accent),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painterResource(R.drawable.ic_pin_line), contentDescription = null,
                tint = KartiniColors.BrandGreenDeep, modifier = Modifier.size(18.dp)
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
            Spacer(Modifier.height(2.dp))
            val detail = buildString {
                if (distanceMeters != null) append("${distanceMeters.toInt()} m ke kantor")
                if (radiusMeters != null) { if (isNotEmpty()) append(" • "); append("radius ${radiusMeters.toInt()} m") }
                // B51: tampilkan radius efektif (radius + toleransi GPS) supaya
                // karyawan tahu area yang masih diterima.
                if (effectiveRadiusMeters != null && effectiveRadiusMeters > (radiusMeters ?: 0.0)) {
                    if (isNotEmpty()) append(" • "); append("toleransi s/d ${effectiveRadiusMeters.toInt()} m")
                }
                if (accuracy != null) { if (isNotEmpty()) append(" • "); append("akurasi ±${accuracy.toInt()} m") }
                if (isEmpty()) append("Menunggu sinyal GPS…")
            }
            Text(detail, color = Color.White.copy(alpha = 0.85f), fontSize = 11.5.sp)
        }
    }
}

@Composable
private fun StatusChip(text: String, filled: Boolean) {
    val bg = if (filled) Color.White else Color.White.copy(alpha = 0.18f)
    val fg = if (filled) KartiniColors.BrandGreen else Color.White
    Surface(color = bg, shape = RoundedCornerShape(50)) {
        Text(
            text, color = fg, fontWeight = FontWeight.Bold, fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
        )
    }
}

// ---------------- Kartu info (putih, elegan) ----------------

@Composable
private fun SoftCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Box(modifier = Modifier.border(1.dp, KartiniColors.DividerLight, RoundedCornerShape(18.dp))) {
            content()
        }
    }
}

@Composable
private fun OfficeCard(config: CompanyConfig?) {
    SoftCard {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(KartiniColors.BrandGreenSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painterResource(R.drawable.ic_pin_line), contentDescription = null,
                    tint = KartiniColors.BrandGreen, modifier = Modifier.size(21.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = config?.officeName ?: "Kantor Simaung Corporation",
                    color = KartiniColors.OnSurface, fontWeight = FontWeight.Bold, fontSize = 14.5.sp,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = buildString {
                        config?.officeRadiusMeters?.let { append("Radius ${it.toInt()} m • ") }
                        append(config?.address ?: "Lokasi kantor Anda")
                    },
                    color = KartiniColors.OnSurfaceMuted, fontSize = 12.sp,
                )
            }
        }
    }
}

@Composable
private fun ScheduleCard(today: TodayAttendance?) {
    val isOff = today?.isOffToday == true
    val shiftName = today?.shiftName ?: (if (isOff) "Libur" else "Shift Kerja")
    val start = formatHm(today?.shiftStart).let { if (it == "-") "--:--" else it }
    val end = formatHm(today?.shiftEnd).let { if (it == "-") "--:--" else it }
    val lateMin = today?.lateMinutes ?: 0
    val isLate = (today?.status == "TERLAMBAT") || lateMin > 0
    SoftCard {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(KartiniColors.BrandOrangeSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painterResource(R.drawable.ic_clock_line), contentDescription = null,
                    tint = KartiniColors.BrandOrangeDeep, modifier = Modifier.size(21.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Jadwal Hari Ini", color = KartiniColors.OnSurfaceMuted, fontSize = 11.5.sp)
                Spacer(Modifier.height(2.dp))
                Text(
                    if (isOff) "Libur (OFF)" else "$shiftName • $start - $end",
                    color = KartiniColors.OnSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                )
                if (isLate) {
                    Spacer(Modifier.height(3.dp))
                    Text(
                        "Terlambat $lateMin menit dari jam masuk",
                        color = KartiniColors.BrandOrangeDeep, fontSize = 12.sp,
                    )
                }
            }
        }
    }
}

// ---------------- Tombol utama ----------------

@Composable
private fun CheckButton(
    enabled: Boolean,
    canCheckOut: Boolean,
    onCheckIn: () -> Unit,
    onCheckOut: () -> Unit,
) {
    val label = if (canCheckOut) "Check-Out Sekarang" else "Check-In Sekarang"
    val fn = if (canCheckOut) onCheckOut else onCheckIn
    val brush = if (canCheckOut)
        Brush.horizontalGradient(listOf(KartiniColors.BrandOrangeDeep, KartiniColors.BrandOrange))
    else
        Brush.horizontalGradient(listOf(KartiniColors.BrandGreenDeep, KartiniColors.BrandGreen))

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) brush else Brush.horizontalGradient(
                listOf(KartiniColors.Olive.copy(alpha = 0.45f), KartiniColors.Olive.copy(alpha = 0.45f))
            ))
            .clickable(enabled = enabled) { fn() },
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                painterResource(R.drawable.ic_circle_check), contentDescription = null,
                tint = Color.White, modifier = Modifier.size(21.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
        }
    }
}

@Composable
private fun RefreshFooter(busy: Boolean, inZone: Boolean, fixAttempts: Int, onRefresh: () -> Unit) {
    val color = if (inZone) KartiniColors.StatusOkFg else KartiniColors.StatusWarnFg
    val bg = if (inZone) KartiniColors.StatusOkBg else KartiniColors.StatusWarnBg
    val text = when {
        inZone -> "Anda di dalam radius kantor"
        busy -> "Menyempurnakan sinyal GPS… (percobaan $fixAttempts)"
        else -> "Geser ke area terbuka lalu tekan Refresh, atau tunggu GPS mengunci"
    }
    Surface(color = bg, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(start = 14.dp, top = 8.dp, end = 6.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painterResource(R.drawable.ic_circle_check), contentDescription = null,
                tint = color, modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = text,
                color = color, fontSize = 12.sp, modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onRefresh) {
                if (busy) {
                    CircularProgressIndicator(
                        color = KartiniColors.BrandGreen, modifier = Modifier.size(16.dp), strokeWidth = 2.dp
                    )
                } else {
                    Text("Refresh", color = KartiniColors.BrandGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
    if (busy) LinearProgressIndicator(
        modifier = Modifier.fillMaxWidth().height(2.dp),
        color = KartiniColors.BrandGreen,
        trackColor = KartiniColors.BrandGreenSoft,
    )
}
