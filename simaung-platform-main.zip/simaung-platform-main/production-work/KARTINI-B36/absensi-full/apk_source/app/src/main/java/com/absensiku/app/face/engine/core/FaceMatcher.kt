package com.absensiku.app.face.engine.core

import com.absensiku.app.face.engine.model.FaceMatchDecision
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.min

/**
 * =====================================================================
 *  FACE MATCHER — Skoring kemiripan & keputusan (versi v4, diperketat)
 * =====================================================================
 *
 * Versi lama hanya memakai 20 fitur RASIO JARAK (geometris). Fitur ini rentan
 * *false-accept*: dua orang berbeda dapat memiliki proporsi global yang mirip
 * (terlebih pria pakai kacamata vs wanita). Untuk memperbaikinya:
 *
 *  - Signature v4 menambahkan **deskriptor bentuk kontur** (profil radial 36-bin)
 *    yang jauh lebih diskriminatif antar individu.
 *  - Keputusan cocok memakai **GERBANG GANDA**:
 *       1. skor unifikasi (0.6·bentuk + 0.4·geometris) ≥ ambang efektif
 *       2. skor BENTUK (intrinsik)  ≥ [MATCH_INTRINSIC]
 *       3. skor GEOMETRIS            ≥ [MATCH_GEOMETRIC]
 *    Jadi wajah hanya lolos bila mirip pada BENTUK **dan** proporsi.
 *
 * Signature v3 (tanpa bentuk) tetap didukung (otomatis ditolak bila hanya
 * mengandalkan geometris — memicu re-enroll demi keamanan). v1/v2 ditolak.
 */
object FaceMatcher {

    // ---- Ambang gerbang ganda (diperketat) ----
    /** Skor unifikasi minimal untuk dianggap cocok (setara/lampaui ambang efektif). */
    const val MATCH_UNIFIED = 90.0
    /** Skor BENTUK (intrinsik) minimal. */
    const val MATCH_INTRINSIC = 88.0
    /** Skor GEOMETRIS minimal. */
    const val MATCH_GEOMETRIC = 87.0
    /** Minimal fitur bentuk yang beririsan (dari 36 bin). */
    const val INTRINSIC_MIN_COMMON = 30

    private const val SHAPE_PREFIX = "shape_"

    /** Rincian skor untuk satu pasangan signature. */
    data class PairScore(
        val unified: Double,
        val intrinsic: Double,
        val geometric: Double,
        val matched: Boolean,
    )

    // =====================================================================
    //  SKOR DASAR
    // =====================================================================

    /** Skor (0..100) untuk himpunan kunci tertentu; -1 bila fitur kurang. */
    private fun scoreForKeys(keys: List<String>, a: Map<String, Int>, b: Map<String, Int>): Double {
        if (keys.isEmpty()) return -1.0
        var total = 0.0
        var outliers = 0
        val diffs = ArrayList<Int>(keys.size)
        for (k in keys) {
            val d = abs(a[k]!! - b[k]!!)
            total += featureScore(d)
            if (d > FaceFeatureExtractor.OUTLIER_DIFF_THRESHOLD) outliers++
            diffs.add(d)
        }
        var score = total / keys.size * 100

        val outlierRatio = outliers.toDouble() / keys.size
        if (outlierRatio > 0.20) score = min(score, 55.0)
        else if (outlierRatio > 0.10) score = min(score, 75.0)
        else if (outlierRatio > 0.05) score = min(score, 83.0)

        diffs.sort()
        val n = diffs.size
        val median = if (n % 2 == 1) diffs[n / 2].toDouble()
        else (diffs[n / 2 - 1] + diffs[n / 2]) / 2.0
        val meanDiff = diffs.sum().toDouble() / n

        if (meanDiff > 9) score = min(score, (100 - (meanDiff - 9) * 4.0).coerceIn(0.0, 100.0))
        if (median > 6) score = min(score, (92 - (median - 6) * 5.0).coerceIn(0.0, 92.0))

        return score.coerceIn(0.0, 100.0)
    }

    /**
     * Menghitung persentase kemiripan antara dua signature (0..100%).
     * Mendukung v3 (geometris) & v4 (geometris + bentuk).
     */
    fun similarityScore(sigA: String, sigB: String): Double {
        return try {
            val a = decodeFeatures(sigA)
            val b = decodeFeatures(sigB)
            if (a.isEmpty() || b.isEmpty()) return 0.0

            val commonKeys = a.keys.filter { b.containsKey(it) }
            if (commonKeys.size < FaceFeatureExtractor.MIN_COMMON_FEATURES) return 0.0
            scoreForKeys(commonKeys, a, b)
        } catch (_: Exception) {
            0.0
        }
    }

    /** Rincian skor (bentuk + geometris + unifikasi + keputusan gerbang ganda). */
    fun pairScore(sigA: String, sigB: String, baseThreshold: Int): PairScore {
        val eff = effectiveThreshold(baseThreshold).coerceAtLeast(MATCH_UNIFIED.toInt())
        return try {
            val a = decodeFeatures(sigA)
            val b = decodeFeatures(sigB)
            if (a.isEmpty() || b.isEmpty()) return PairScore(0.0, 0.0, 0.0, false)

            val common = a.keys.filter { b.containsKey(it) }
            if (common.size < FaceFeatureExtractor.MIN_COMMON_FEATURES) {
                return PairScore(0.0, 0.0, 0.0, false)
            }
            val intrinsicKeys = common.filter { it.startsWith(SHAPE_PREFIX) }
            val geometricKeys = common.filter { !it.startsWith(SHAPE_PREFIX) }

            val intrinsic = if (intrinsicKeys.size >= INTRINSIC_MIN_COMMON)
                scoreForKeys(intrinsicKeys, a, b) else -1.0
            val geometric = if (geometricKeys.size >= FaceFeatureExtractor.MIN_COMMON_FEATURES)
                scoreForKeys(geometricKeys, a, b) else -1.0

            val full = scoreForKeys(common, a, b)
            val unified = when {
                intrinsic >= 0 && geometric >= 0 -> 0.6 * intrinsic + 0.4 * geometric
                intrinsic >= 0 -> intrinsic
                else -> full
            }

            // Gerbang ganda: hanya cocok bila bentuk & geometris sama-sama tinggi.
            val matched = when {
                intrinsic >= 0 && geometric >= 0 ->
                    unified >= eff && intrinsic >= MATCH_INTRINSIC && geometric >= MATCH_GEOMETRIC
                intrinsic >= 0 ->
                    unified >= eff && intrinsic >= MATCH_INTRINSIC
                else ->
                    full >= eff
            }
            PairScore(unified, if (intrinsic < 0) full else intrinsic,
                if (geometric < 0) full else geometric, matched)
        } catch (_: Exception) {
            PairScore(0.0, 0.0, 0.0, false)
        }
    }

    /** Keputusan cocok/tidak untuk dua signature (gerbang ganda). */
    fun isMatchDecision(sigA: String, sigB: String, baseThreshold: Int): Boolean =
        pairScore(sigA, sigB, baseThreshold).matched

    /** Kontribusi skor (0.0-1.0) untuk satu fitur berdasarkan selisih absolut. */
    fun featureScore(diff: Int): Double {
        if (diff <= FaceFeatureExtractor.TIGHT_DIFF) return 1.0
        if (diff <= FaceFeatureExtractor.LOOSE_DIFF) {
            return 1.0 - 0.5 * (diff - FaceFeatureExtractor.TIGHT_DIFF) /
                (FaceFeatureExtractor.LOOSE_DIFF - FaceFeatureExtractor.TIGHT_DIFF).toDouble()
        }
        if (diff <= FaceFeatureExtractor.REJECT_DIFF) {
            return 0.5 - 0.5 * (diff - FaceFeatureExtractor.LOOSE_DIFF) /
                (FaceFeatureExtractor.REJECT_DIFF - FaceFeatureExtractor.LOOSE_DIFF).toDouble()
        }
        return 0.0
    }

    /** Ambang EFEKTIF = ambang dasar + margin konservatif. */
    fun effectiveThreshold(baseThreshold: Int): Int =
        (baseThreshold + FaceFeatureExtractor.CONSERVATIVE_MARGIN_PERCENT).coerceIn(0, 99)

    // =====================================================================
    //  MULTI-SAMPLE
    // =====================================================================

    /** Skor kemiripan terhadap SETIAP sample tersimpan secara terpisah. */
    fun scoresAgainstSamples(signature: String, samples: List<String>, baseThreshold: Int = 85): List<Double> =
        samples.map { pairScore(signature, it, baseThreshold).unified }

    /** Skor TERTINGGI antar sample (untuk tampilan info saja). */
    fun bestScoreAgainstSamples(signature: String, samples: List<String>): Double {
        if (samples.isEmpty()) return 0.0
        var best = 0.0
        for (s in samples) {
            val sc = similarityScore(signature, s)
            if (sc > best) best = sc
        }
        return best
    }

    /**
     * Verifikasi multi-sample ROBUST dengan gerbang ganda:
     * cocok hanya bila MAYORITAS sample memenuhi gerbang.
     */
    fun robustMatch(signature: String, samples: List<String>, thresholdPercent: Int): FaceMatchDecision {
        if (samples.isEmpty()) return FaceMatchDecision(isMatch = false, score = 0.0)

        val eff = effectiveThreshold(thresholdPercent).coerceAtLeast(MATCH_UNIFIED.toInt())
        val pairs = samples.map { pairScore(signature, it, thresholdPercent) }
        val scores = pairs.map { it.unified }
        val required = if (samples.size == 1) 1 else Math.ceil(samples.size / 2.0).toInt()

        val matchCount = pairs.count { it.matched }
        // "near": lolos ambang unifikasi tapi gagal salah satu gerbang bentuk/geometris.
        val baseMatchCount = scores.count { it >= eff }

        val sorted = scores.sortedDescending()
        val representative = sorted.take(required).sum() / required

        return FaceMatchDecision(
            isMatch = matchCount >= required,
            score = representative,
            isNearMatch = matchCount < required && baseMatchCount >= required,
            effectiveThreshold = eff,
        )
    }

    // =====================================================================
    //  SIGNATURE HELPERS
    // =====================================================================

    /** Mendekode signature menjadi Map fitur berkunci nama (format v3/v4). */
    fun decodeFeatures(sig: String): Map<String, Int> {
        return try {
            val decoded = JSONObject(sig)
            val v = decoded.optInt("v", -1)
            if (v != 3 && v != 4) return emptyMap()
            val f = decoded.optJSONObject("f") ?: return emptyMap()
            val result = LinkedHashMap<String, Int>()
            val keys = f.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                result[k] = f.getDouble(k).toInt()
            }
            result
        } catch (_: Exception) {
            emptyMap()
        }
    }

    /** True bila signature memakai format lama (v1/v2). */
    fun isLegacySignature(sig: String): Boolean {
        return try {
            val trimmed = sig.trim()
            if (trimmed.startsWith("[")) return true // v1
            val decoded = JSONObject(trimmed)
            decoded.optInt("v", -1) == 2 // v2
        } catch (_: Exception) {
            false
        }
    }

    /** True bila signature memakai format v4 (punya deskriptor bentuk). */
    fun isShapeAware(sig: String): Boolean {
        return try {
            JSONObject(sig.trim()).optInt("v", -1) == 4
        } catch (_: Exception) {
            false
        }
    }

    /** Jumlah fitur bentuk pada signature (0 bila v3). */
    fun shapeFeatureCount(sig: String): Int =
        decodeFeatures(sig).keys.count { it.startsWith(SHAPE_PREFIX) }

    /** Memisahkan signature multi-sample (JSON array of strings). */
    fun splitSamples(stored: String?): List<String> {
        if (stored.isNullOrEmpty()) return emptyList()
        val trimmed = stored.trim()
        return try {
            val arr = org.json.JSONArray(trimmed)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (_: Exception) {
            listOf(trimmed)
        }
    }

    /** Menggabungkan daftar signature menjadi satu string (JSON array). */
    fun joinSamples(samples: List<String>): String {
        val arr = org.json.JSONArray()
        samples.forEach { arr.put(it) }
        return arr.toString()
    }
}
