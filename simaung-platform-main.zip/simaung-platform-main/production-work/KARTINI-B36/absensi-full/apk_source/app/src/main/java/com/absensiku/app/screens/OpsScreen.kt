package com.absensiku.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.MeResponse
import com.absensiku.app.location.LocationValidator
import com.absensiku.app.screens.ops.DriverTripsScreen
import com.absensiku.app.screens.ops.OpnameScreen
import com.absensiku.app.screens.ops.PosScreen
import com.absensiku.app.screens.ops.ProductAdminScreen
import com.absensiku.app.ui.components.OpsEmpty
import com.absensiku.app.ui.components.OpsFacilityCard
import com.absensiku.app.ui.components.OpsHeroHeader
import com.absensiku.app.ui.components.OpsSectionTitle
import com.absensiku.app.ui.components.OpsTopBar
import com.absensiku.app.ui.theme.KartiniColors

/**
 * Hub modul OPERASIONAL (B11) — menyesuaikan peran jabatan karyawan.
 * Karyawan dengan JABATAN RANGKAP melihat seluruh fasilitas dari semua
 * perannya (mis. Driver + Pramuniaga -> Perjalanan & Stock Opname).
 */
@Composable
fun OpsScreen(
    api: ApiClient,
    locationValidator: LocationValidator,
    me: MeResponse,
    showMessage: (String) -> Unit,
) {
    var sub by remember { mutableStateOf<String?>(null) }

    when (sub) {
        "driver" -> DriverTripsScreen(api, locationValidator, showMessage) { sub = null }
        "opname" -> OpnameScreen(api, me, showMessage) { sub = null }
        "pos" -> PosScreen(api, me, showMessage) { sub = null }
        "products" -> ProductAdminScreen(api, me, showMessage) { sub = null }
        else -> OpsHub(me = me, onOpen = { sub = it })
    }
}

private val AccentDriver = Color(0xFF1D6FB8)
private val AccentOpname = KartiniColors.BrandOrange
private val AccentPos = KartiniColors.BrandGreen
private val AccentCatalog = Color(0xFF6A3FB5)

@Composable
private fun OpsHub(me: MeResponse, onOpen: (String) -> Unit) {
    val hasDriver = me.hasRole("DRIVER")
    val hasPramuniaga = me.hasRole("PRAMUNIAGA")
    val hasKepala = me.hasRole("KEPALA_GUDANG")
    val hasKasir = me.hasRole("KASIR")

    val roleLabels = me.roles.mapNotNull {
        when (it.uppercase()) {
            "DRIVER" -> "Driver"
            "PRAMUNIAGA" -> "Pramuniaga"
            "KEPALA_GUDANG" -> "Kepala Gudang"
            "KASIR" -> "Kasir"
            else -> null
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        Column(modifier = Modifier.fillMaxSize()) {
            OpsHeroHeader(roleLabels = roleLabels)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 16.dp),
            ) {
                OpsSectionTitle("Fasilitas Tersedia")
                Spacer(Modifier.height(12.dp))

                if (hasDriver) {
                    OpsFacilityCard(
                        title = "Perjalanan & Surat Jalan",
                        desc = "Mulai & pantau perjalanan, kirim lokasi, dan buat surat jalan.",
                        roleChips = if (hasDriver) listOf("Driver") else emptyList(),
                        accent = AccentDriver,
                    ) { onOpen("driver") }
                    Spacer(Modifier.height(12.dp))
                }
                if (hasPramuniaga || hasKepala) {
                    val desc = when {
                        hasKepala && hasPramuniaga -> "Hitung stok per area, lakukan opname full, dan crosscek hasil."
                        hasKepala -> "Opname full perusahaan & crosscek hasil opname pramuniaga."
                        else -> "Hitung & catat stok barang di area Anda."
                    }
                    val chips = buildList {
                        if (hasPramuniaga) add("Pramuniaga")
                        if (hasKepala) add("Kepala Gudang")
                    }
                    OpsFacilityCard(
                        title = "Stock Opname",
                        desc = desc,
                        roleChips = chips,
                        accent = AccentOpname,
                    ) { onOpen("opname") }
                    Spacer(Modifier.height(12.dp))
                }
                if (hasKepala) {
                    OpsFacilityCard(
                        title = "Kelola Barang",
                        desc = "Tambah & ubah master barang yang dipakai POS dan Stock Opname.",
                        roleChips = listOf("Kepala Gudang"),
                        accent = AccentCatalog,
                    ) { onOpen("products") }
                    Spacer(Modifier.height(12.dp))
                }
                if (hasKasir) {
                    OpsFacilityCard(
                        title = "POS Kasir",
                        desc = "Layani transaksi penjualan, atur keranjang, diskon & pembayaran.",
                        roleChips = listOf("Kasir"),
                        accent = AccentPos,
                    ) { onOpen("pos") }
                    Spacer(Modifier.height(12.dp))
                }

                if (!hasDriver && !hasPramuniaga && !hasKepala && !hasKasir) {
                    Spacer(Modifier.height(24.dp))
                    OpsEmpty("Akun Anda belum memiliki jabatan operasional.\nHubungi admin untuk pengaturan peran.")
                }
            }
        }
    }
}
