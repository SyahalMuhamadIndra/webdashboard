package com.absensiku.app.location

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

sealed class LocationResult {
    data class Success(
        val latitude: Double,
        val longitude: Double,
        val accuracyMeters: Float,
        val isMock: Boolean,
    ) : LocationResult()

    data object MissingPermission : LocationResult()
    data object GpsDisabled : LocationResult()
    data class Error(val message: String) : LocationResult()
}

/**
 * Pengambil lokasi presisi untuk absensi.
 *
 * Prinsip: **akurasi lebih penting daripada kecepatan** untuk absensi. Perangkat
 * memakai GPS HIGH_ACCURACY; cache lokasi hanya dipakai bila masih SEGAR **dan**
 * sudah AKURAT. Bila belum akurat, aplikasi mencoba beberapa kali sampai akurasi
 * memenuhi target (atau batas waktu tercapai) — inilah yang membuat absensi tidak
 * lagi salah menganggap "di luar area" saat pengguna sudah di titik kantor.
 */
class LocationValidator(private val context: Context) {

    private val fused = LocationServices.getFusedLocationProviderClient(context)

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Ambil lokasi untuk ABSENSI.
     *
     * @param targetAccuracyMeters akurasi yang dianggap "cukup baik" (meter). Bila
     *   hasil pertama belum mencapai target, coba lagi beberapa kali.
     * @param maxAttempts jumlah maksimum percobaan fix GPS.
     */
    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(
        targetAccuracyMeters: Float = DEFAULT_TARGET_ACCURACY_M,
        maxAttempts: Int = DEFAULT_MAX_ATTEMPTS,
    ): LocationResult {
        if (!hasPermission()) return LocationResult.MissingPermission

        // 1) Cache lokasi terakhir — HANYA jika segar DAN akurat.
        val cached = readCache()
        if (cached != null &&
            System.currentTimeMillis() - cached.time <= CACHE_FRESH_MS &&
            cached.accuracy > 0f && cached.accuracy <= CACHE_MAX_ACCURACY_M
        ) {
            return success(cached)
        }

        // 2) Minta fix GPS AKURASI TINGGI, ulangi sampai akurasi memadai.
        var best: Location? = null
        repeat(maxAttempts.coerceAtLeast(1)) { attempt ->
            val res = requestLocation(Priority.PRIORITY_HIGH_ACCURACY, HIGH_ACC_TIMEOUT_MS)
            if (res is LocationResult.Success) {
                val asLoc = Location("").apply {
                    latitude = res.latitude
                    longitude = res.longitude
                    accuracy = res.accuracyMeters
                }
                if (best == null || asLoc.accuracy < best!!.accuracy) best = asLoc
                // Sudah cukup akurat -> langsung pakai.
                if (asLoc.accuracy in 0f..targetAccuracyMeters) return res
                // Satu percobaan sudah cukup akurat secara umum -> berhenti lebih cepat.
                if (attempt == 0 && asLoc.accuracy <= GOOD_ENOUGH_ACCURACY_M) return res
            }
        }
        best?.let { return success(it) }

        // 3) Fallback: pakai cache lama (lebih baik daripada gagal total)…
        cached?.let { return success(it) }
        // …lalu fallback terakhir: prioritas seimbang.
        return requestLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, BALANCED_TIMEOUT_MS)
    }

    /** Ambil satu fix akurasi tinggi (tanpa percobaan berulang). */
    @SuppressLint("MissingPermission")
    suspend fun getHighAccuracyLocation(): LocationResult {
        if (!hasPermission()) return LocationResult.MissingPermission
        return requestLocation(Priority.PRIORITY_HIGH_ACCURACY, HIGH_ACC_TIMEOUT_MS)
    }

    @SuppressLint("MissingPermission")
    private suspend fun readCache(): Location? =
        runCatching { com.google.android.gms.tasks.Tasks.await(fused.lastLocation, 600, TimeUnit.MILLISECONDS) }
            .getOrNull()

    private fun success(loc: Location) = LocationResult.Success(
        latitude = loc.latitude,
        longitude = loc.longitude,
        accuracyMeters = loc.accuracy,
        isMock = isMock(loc),
    )

    @SuppressLint("MissingPermission")
    private suspend fun requestLocation(priority: Int, timeoutMs: Long): LocationResult {
        val result = withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine { cont ->
                val task = fused.getCurrentLocation(priority, null)
                var resumed = false
                fun finish(r: LocationResult) {
                    if (!resumed) { resumed = true; cont.resume(r) }
                }
                task.addOnSuccessListener { loc ->
                    if (loc == null) {
                        finish(LocationResult.Error("Lokasi belum tersedia, coba lagi"))
                    } else {
                        finish(
                            LocationResult.Success(
                                latitude = loc.latitude,
                                longitude = loc.longitude,
                                accuracyMeters = loc.accuracy,
                                isMock = isMock(loc),
                            )
                        )
                    }
                }.addOnFailureListener { e ->
                    finish(LocationResult.Error(e.message ?: "Gagal mengambil lokasi"))
                }
            }
        }
        return result ?: LocationResult.Error("Waktu pengambilan lokasi habis, coba lagi")
    }

    @Suppress("DEPRECATION")
    private fun isMock(loc: Location): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) loc.isMock
        else loc.isFromMockProvider

    companion object {
        /** Target akurasi default absensi (meter). */
        const val DEFAULT_TARGET_ACCURACY_M = 35f
        /** Akurasi yang dianggap "sudah bagus" untuk berhenti lebih awal. */
        private const val GOOD_ENOUGH_ACCURACY_M = 50f
        /** Umur maksimum cache agar masih dianggap segar. */
        private const val CACHE_FRESH_MS = 20_000L
        /** Akurasi maksimum cache agar boleh dipakai (meter). */
        private const val CACHE_MAX_ACCURACY_M = 50f

        private const val DEFAULT_MAX_ATTEMPTS = 3
        private const val HIGH_ACC_TIMEOUT_MS = 12_000L
        private const val BALANCED_TIMEOUT_MS = 8_000L

        fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val r = 6371000.0
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = kotlin.math.sin(dLat / 2).let { it * it } +
                kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
                kotlin.math.sin(dLon / 2).let { it * it }
            return 2 * r * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
        }
    }
}
