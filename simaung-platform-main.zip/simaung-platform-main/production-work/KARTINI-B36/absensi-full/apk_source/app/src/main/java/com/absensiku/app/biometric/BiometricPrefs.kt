package com.absensiku.app.biometric

import android.content.Context
import androidx.biometric.BiometricManager

/**
 * Preferensi untuk LOGIN BIOMETRIK.
 *
 * Disimpan pada berkas SharedPreferences tersendiri agar TIDAK terhapus saat
 * pengguna keluar (logout). Berisi:
 *  - enabled         : apakah login biometrik diaktifkan (via tab Profil).
 *  - savedEmployeeCode: kode karyawan yang diingat.
 *  - savedPin        : PIN terakhir (dipakai untuk login cepat setelah biometrik lolos).
 *
 * Catatan: PIN disimpan pada penyimpanan privat aplikasi (MODE_PRIVATE) — praktik
 * umum untuk "quick login" pada aplikasi internal. Tidak pernah dikirim ke mana pun
 * selain server absensi saat login.
 */
class BiometricPrefs(context: Context) {

    private val appCtx = context.applicationContext
    private val prefs = appCtx.getSharedPreferences("secure_login_prefs", Context.MODE_PRIVATE)

    // ---------- flag aktif ----------

    fun isEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, false)

    fun setEnabled(value: Boolean) {
        prefs.edit().putBoolean(KEY_ENABLED, value).apply()
    }

    // ---------- kredensial tersimpan ----------

    fun savedEmployeeCode(): String? = prefs.getString(KEY_CODE, null)?.takeIf { it.isNotBlank() }

    fun savedPin(): String? = prefs.getString(KEY_PIN, null)?.takeIf { it.isNotBlank() }

    fun saveCredentials(code: String, pin: String) {
        prefs.edit().putString(KEY_CODE, code).putString(KEY_PIN, pin).apply()
    }

    fun clearCredentials() {
        prefs.edit().remove(KEY_CODE).remove(KEY_PIN).apply()
    }

    fun hasCredentials(): Boolean = savedEmployeeCode() != null && savedPin() != null

    // ---------- ketersediaan perangkat ----------

    /** True bila perangkat punya sensor biometrik yang SUDAH terdaftar (siap pakai). */
    fun isHardwareAvailable(): Boolean {
        val manager = BiometricManager.from(appCtx)
        val result = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        return result == BiometricManager.BIOMETRIC_SUCCESS
    }

    /** True bila tombol "Login Biometrik" boleh ditampilkan di layar masuk. */
    fun canQuickLogin(): Boolean = isEnabled() && hasCredentials() && isHardwareAvailable()

    companion object {
        private const val KEY_ENABLED = "biometric_enabled"
        private const val KEY_CODE = "saved_employee_code"
        private const val KEY_PIN = "saved_pin"
    }
}
