package com.absensiku.app.update

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.core.content.FileProvider
import com.absensiku.app.BuildConfig
import com.absensiku.app.api.ServerUpdateInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Status unduhan APK (untuk polling anti-stuck). */
sealed class ApkDownloadState {
    data class Running(val downloaded: Long, val total: Long) : ApkDownloadState()
    object Success : ApkDownloadState()
    data class Failed(val reason: Int) : ApkDownloadState()
    object Pending : ApkDownloadState()
}

/**
 * Pengelola pembaruan APK (v0.9.12, diperkuat v0.9.17).
 *
 * Alur: server memberi tahu versi baru -> popup di aplikasi -> APK diunduh ke
 * penyimpanan aplikasi (external-files "updates") -> installer sistem dibuka ->
 * setelah berhasil dipasang berkas APK dihapus otomatis.
 *
 * v0.9.17: ditambah polling status + fallback unduhan manual. Sebelumnya popup
 * bisa "stuck / Memproses…" selamanya ketika DownloadManager sistem diam-diam
 * gagal/tertahan (umum di perangkat OEM tertentu). Kini bila DM tidak juga
 * selesai, unduhan dialihkan ke unduhan langsung (HTTP) agar tetap berhasil.
 */
class ApkUpdater(private val context: Context) {

    companion object {
        private const val TAG = "ApkUpdater"
        const val UPDATE_DIR = "updates"
        private const val PREFS = "apk_updater"
        private const val KEY_LAST_DOWNLOAD_ID = "last_download_id"
        private const val KEY_LAST_APK_PATH = "last_apk_path"
        private const val KEY_SKIPPED_CODE = "skipped_version_code"
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isSkipped(versionCode: Int): Boolean = prefs.getInt(KEY_SKIPPED_CODE, -1) == versionCode

    fun markSkipped(versionCode: Int) {
        prefs.edit().putInt(KEY_SKIPPED_CODE, versionCode).apply()
    }

    fun currentVersionCode(): Int = BuildConfig.VERSION_CODE
    fun currentVersionName(): String = BuildConfig.VERSION_NAME

    private fun updateDir(): File =
        File(context.getExternalFilesDir(null) ?: context.filesDir, UPDATE_DIR).apply { mkdirs() }

    fun startDownload(info: ServerUpdateInfo): Long {
        return try {
            val fileName = "AbsensiKu-v${info.versionName}.apk"
            val dest = File(updateDir(), fileName)
            if (dest.exists()) dest.delete()
            prefs.edit().putString(KEY_LAST_APK_PATH, dest.absolutePath).apply()

            val request = DownloadManager.Request(Uri.parse(info.apkUrl)).apply {
                setTitle("Memperbarui Aplikasi")
                setDescription("Mengunduh versi ${info.versionName}…")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                setDestinationInExternalFilesDir(context, null, "${UPDATE_DIR}/$fileName")
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
                setMimeType("application/vnd.android.package-archive")
            }
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val id = dm.enqueue(request)
            prefs.edit().putInt(KEY_LAST_DOWNLOAD_ID, id.toInt()).apply()
            id
        } catch (e: Exception) {
            Log.e(TAG, "startDownload gagal", e)
            -1L
        }
    }

    /** Query status unduhan sistem saat ini. */
    fun downloadState(downloadId: Long): ApkDownloadState {
        return try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val cursor: Cursor = dm.query(DownloadManager.Query().setFilterById(downloadId))
                ?: return ApkDownloadState.Failed(-1)
            cursor.use { c ->
                if (!c.moveToFirst()) return ApkDownloadState.Failed(-1)
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val downloaded = c.getLong(c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                return when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> ApkDownloadState.Success
                    DownloadManager.STATUS_FAILED -> {
                        val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                        ApkDownloadState.Failed(reason)
                    }
                    DownloadManager.STATUS_PENDING -> ApkDownloadState.Pending
                    else -> ApkDownloadState.Running(downloaded, total)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "downloadState gagal", e)
            ApkDownloadState.Failed(-1)
        }
    }

    /**
     * Unduhan manual (fallback) memakai HTTP langsung ke penyimpanan aplikasi.
     * Dipakai bila DownloadManager sistem tidak juga menyelesaikan unduhan.
     * @return true bila berkas APK berhasil tersimpan.
     */
    suspend fun downloadApkManually(
        info: ServerUpdateInfo,
        onProgress: (downloaded: Long, total: Long) -> Unit,
    ): Boolean = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            val fileName = "AbsensiKu-v${info.versionName}.apk"
            val dest = File(updateDir(), fileName)
            if (dest.exists()) dest.delete()

            val url = URL(info.apkUrl)
            conn = (url.openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 20_000
                readTimeout = 30_000
                requestMethod = "GET"
                setRequestProperty("Accept", "*/*")
            }
            conn.connect()
            val code = conn.responseCode
            if (code !in 200..299) {
                Log.e(TAG, "manual download HTTP $code")
                return@withContext false
            }
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                FileOutputStream(dest).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var sum = 0L
                    while (true) {
                        val read = input.read(buf)
                        if (read <= 0) break
                        out.write(buf, 0, read)
                        sum += read
                        withContext(Dispatchers.Main) { onProgress(sum, total) }
                    }
                    out.flush()
                }
            }
            conn.disconnect()
            val ok = dest.exists() && dest.length() > 0
            if (ok) {
                prefs.edit().putString(KEY_LAST_APK_PATH, dest.absolutePath).apply()
            }
            ok
        } catch (e: Exception) {
            Log.e(TAG, "downloadApkManually gagal", e)
            false
        } finally {
            runCatching { conn?.disconnect() }
        }
    }

    fun lastApkFile(): File? {
        val p = prefs.getString(KEY_LAST_APK_PATH, null) ?: return null
        val f = File(p)
        return if (f.exists() && f.length() > 0) f else null
    }

    fun installLastApk(): Boolean {
        val file = lastApkFile() ?: return false
        return try {
            val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "installLastApk gagal", e)
            false
        }
    }

    fun canInstallPackages(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.packageManager.canRequestPackageInstalls() else true

    fun openInstallPermissionSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).setData(Uri.parse("package:${context.packageName}"))
            } else Intent(Settings.ACTION_SECURITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "openInstallPermissionSettings gagal", e)
        }
    }

    fun installWithPermission(): Boolean =
        if (canInstallPackages()) installLastApk() else { openInstallPermissionSettings(); false }

    fun cleanupDownloadedApk() {
        runCatching {
            lastApkFile()?.delete()
            updateDir().listFiles()?.forEach { it.delete() }
            prefs.edit().remove(KEY_LAST_APK_PATH).remove(KEY_LAST_DOWNLOAD_ID).apply()
        }
    }

    fun clearIfUpgraded(releaseVersionCode: Int) {
        if (BuildConfig.VERSION_CODE >= releaseVersionCode) cleanupDownloadedApk()
    }

    fun registerDownloadCompleteReceiver(versionCode: Int, onDone: () -> Unit): BroadcastReceiver {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
                val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
                val mine = prefs.getInt(KEY_LAST_DOWNLOAD_ID, -1).toLong()
                if (id != mine) return
                onDone()
            }
        }
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }
        return receiver
    }

    fun downloadedApkSize(): Long = lastApkFile()?.length() ?: 0L
    fun apkExists(): Boolean = lastApkFile() != null
}
