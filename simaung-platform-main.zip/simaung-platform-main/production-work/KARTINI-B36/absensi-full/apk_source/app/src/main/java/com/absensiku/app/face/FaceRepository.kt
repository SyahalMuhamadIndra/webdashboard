package com.absensiku.app.face

import android.content.Context
import com.absensiku.app.api.ApiClient
import com.absensiku.app.face.engine.core.EnrollmentManager
import com.absensiku.app.face.engine.core.FaceMatcher
import com.absensiku.app.face.engine.core.FaceMatchingService
import com.absensiku.app.face.engine.util.FaceTemplateExtractor
import com.absensiku.app.face.engine.util.FaceTemplateMatcher

/**
 * Hasil keputusan enrollment.
 * @param source "SERVER" bila tersimpan di server, "LOKAL" bila fallback.
 */
data class EnrollDecision(val ok: Boolean, val source: String, val message: String? = null)

/**
 * Hasil keputusan verifikasi parsial (sebelum dikonfirmasi server).
 * @param source "SERVER" atau "LOKAL".
 */
data class VerifyDecision(
    val match: Boolean,
    val score: Int,
    val nearMatch: Boolean,
    val effectiveThreshold: Int,
    val message: String?,
    val source: String,
)

/**
 * Jembatan wajah **berbasis server**.
 *
 * Alur utama (server-side, agar keputusan absen otoritatif di server):
 *  - Enrollment  -> [enroll] mengirim sample ke server (`POST /face/enrollment`).
 *  - Verifikasi  -> [verify] mengirim PROBE ke server (`POST /face/verify`);
 *                   server yang menghitung skor & memutuskan cocok/tidak.
 *
 * Fallback (jaringan terputus / endpoint belum ter-deploy):
 *  - Sample tersimpan lokal (SharedPreferences) dipakai menghitung skor
 *    dengan mesin yang sama, sehingga absensi tetap dapat berjalan.
 *
 * `source` pada hasil menandakan keputusan diputuskan SERVER atau LOKAL.
 */
class FaceRepository(
    private val api: ApiClient,
    context: Context,
) {
    private val local = EnrollmentManager(
        context.applicationContext.getSharedPreferences("face_store", Context.MODE_PRIVATE)
    )

    private fun userId(): String = api.employeeCode().ifBlank { "default" }

    /**
     * Status enrollment: server bila memungkinkan, jika tidak fallback lokal.
     * @param enrolled true bila ada data wajah yang VALID & terbaru (v4/bentuk).
     * @param outdated true bila ada data lama (v3 tanpa deskriptor bentuk) -> wajib rekam ulang.
     */
    data class EnrollmentState(val enrolled: Boolean, val outdated: Boolean, val source: String)

    suspend fun enrollmentState(): EnrollmentState = try {
        val s = api.getFaceEnrollment()
        EnrollmentState(enrolled = s.enrolled && !s.outdated, outdated = s.outdated, source = "SERVER")
    } catch (_: Exception) {
        val samples = local.getSamples(userId())
        val has = samples.isNotEmpty()
        val hasTemplate = samples.any { FaceTemplateExtractor.isTemplate(it) }
        EnrollmentState(enrolled = has && hasTemplate, outdated = has && !hasTemplate, source = "LOKAL")
    }

    /** True bila data wajah valid & terbaru (bukan usang). */
    suspend fun isEnrolled(): Boolean = enrollmentState().enrolled

    // ================= TEMPLATE TEKSTUR (utama) =================

    /**
     * Simpan template wajah (v5) ke server. Fallback lokal bila offline.
     */
    suspend fun enrollTemplates(templates: List<String>, basePhotoBase64: String?): EnrollDecision {
        if (templates.isEmpty()) return EnrollDecision(false, "LOKAL", "Tidak ada sample untuk disimpan.")
        local.saveSamples(userId(), templates)
        return try {
            api.submitFaceEnrollment(templates, basePhotoBase64)
            EnrollDecision(true, "SERVER", "Wajah tersimpan di server.")
        } catch (e: kotlinx.coroutines.CancellationException) {

            throw e

        } catch (e: Exception) {
            EnrollDecision(true, "LOKAL", "Tersimpan di perangkat (server belum tersedia): ${e.message}")
        }
    }

    /**
     * Verifikasi template wajah. Server memutuskan (NCC); bila tak terjangkau,
     * hitung NCC lokal.
     */
    suspend fun verifyTemplate(probe: String, threshold: Int = FaceMatchingService.TPL_MATCH): VerifyDecision {
        return try {
            val r = api.verifyFace(probe, threshold)
            VerifyDecision(r.match, r.score, r.nearMatch, r.effectiveThreshold, r.message, "SERVER")
        } catch (_: Exception) {
            val stored = local.getSamples(userId()).filter { FaceTemplateExtractor.isTemplate(it) }
            if (stored.isEmpty()) {
                return VerifyDecision(
                    false, 0, false, threshold,
                    "Belum ada data wajah. Lakukan enrollment dulu.", "LOKAL",
                )
            }
            val scores = stored.map { FaceTemplateMatcher.matchScore(probe, it) }.filter { it >= 0.0 }
            if (scores.isEmpty()) {
                return VerifyDecision(false, 0, false, threshold, "Data wajah tidak valid. Rekam ulang.", "LOKAL")
            }
            val required = if (scores.size == 1) 1 else Math.ceil(scores.size / 2.0).toInt()
            val matchCount = scores.count { it >= threshold }
            val sorted = scores.sortedDescending()
            val representative = sorted.take(required).sum() / required
            val match = matchCount >= required
            val near = !match && sorted.first() >= FaceMatchingService.TPL_NEAR
            val msg = when {
                match -> "Cocok (${representative.toInt()}%) [lokal]"
                near -> "Hampir cocok (${representative.toInt()}%) [lokal]"
                else -> "Tidak cocok (${representative.toInt()}%) [lokal]"
            }
            VerifyDecision(match, representative.toInt(), near, threshold, msg, "LOKAL")
        }
    }

    /**
     * Simpan sample wajah ke server. Bila gagal (offline / endpoint belum ada),
     * simpan lokal agar absensi tetap bisa dilakukan.
     */
    suspend fun enroll(samples: List<String>, basePhotoBase64: String?): EnrollDecision {
        if (samples.isEmpty()) return EnrollDecision(false, "LOKAL", "Tidak ada sample untuk disimpan.")
        // Selalu cadangkan lokal (offline cache).
        local.saveSamples(userId(), samples)
        return try {
            api.submitFaceEnrollment(samples, basePhotoBase64)
            EnrollDecision(true, "SERVER", "Wajah tersimpan di server.")
        } catch (e: kotlinx.coroutines.CancellationException) {

            throw e

        } catch (e: Exception) {
            EnrollDecision(
                true, "LOKAL",
                "Tersimpan di perangkat (server belum tersedia): ${e.message}",
            )
        }
    }

    /**
     * Verifikasi probe wajah. Server yang memutuskan; jika tak terjangkau,
     * hitung lokal dengan sample tersimpan.
     */
    suspend fun verify(probe: String, threshold: Int = MATCH_THRESHOLD): VerifyDecision {
        return try {
            val r = api.verifyFace(probe, threshold)
            VerifyDecision(
                match = r.match,
                score = r.score,
                nearMatch = r.nearMatch,
                effectiveThreshold = r.effectiveThreshold,
                message = r.message,
                source = "SERVER",
            )
        } catch (e: kotlinx.coroutines.CancellationException) {

            throw e

        } catch (e: Exception) {
            val stored = local.getSamples(userId())
            if (stored.isEmpty()) {
                return VerifyDecision(
                    match = false, score = 0, nearMatch = false,
                    effectiveThreshold = FaceMatcher.effectiveThreshold(threshold),
                    message = "Belum ada data wajah. Lakukan enrollment dulu.",
                    source = "LOKAL",
                )
            }
            val d = FaceMatcher.robustMatch(probe, stored, threshold)
            val score = Math.round(d.score).toInt()
            val msg = when {
                d.isMatch -> "Cocok (${score}%) [lokal]"
                d.isNearMatch -> "Hampir cocok (${score}%) [lokal]"
                else -> "Tidak cocok (${score}%) [lokal]"
            }
            VerifyDecision(d.isMatch, score, d.isNearMatch, d.effectiveThreshold, msg, "LOKAL")
        }
    }

    /** Hapus data wajah (server + lokal). */
    suspend fun clear() {
        runCatching { api.deleteFaceEnrollment() }
        local.clear(userId())
    }

    /** True bila sample lokal memakai format lama (harus re-enroll). */
    fun hasLegacyLocalSample(): Boolean = local.hasLegacySample(userId())

    /** Template v5 tersimpan di perangkat (untuk skor kemiripan LIVE). */
    fun localTemplates(): List<String> =
        local.getSamples(userId()).filter { FaceTemplateExtractor.isTemplate(it) }

    /**
     * FOTO SAMPLE wajah tersimpan (base64 JPEG tanpa prefix), untuk thumbnail
     * di pojok kiri atas layar kamera.
     *
     * Urutan sumber:
     *  1. Server (`GET /face/photo`) — otoritatif & lintas-perangkat.
     *  2. Cache lokal (base64 tersimpan saat enrollment) — fallback offline.
     *
     * @return base64 JPEG, atau null bila belum ada sample sama sekali.
     */
    suspend fun storedSamplePhoto(): String? {
        // 1) Coba server dulu.
        runCatching { api.getFacePhoto() }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }
            ?.let { b64 ->
                // Segarkan cache lokal.
                runCatching { local.saveBasePhotoBase64(userId(), b64) }
                return b64
            }
        // 2) Fallback ke cache lokal base64.
        local.getBasePhotoBase64(userId())?.takeIf { it.isNotBlank() }?.let { return it }
        // 3) Fallback terakhir: baca berkas foto dasar yang di-cache (path lama).
        val path = local.getBasePhoto(userId())
        if (!path.isNullOrBlank()) {
            runCatching {
                val f = java.io.File(path)
                if (!f.exists()) return null
                val bytes = f.readBytes()
                return android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
            }
        }
        return null
    }

    /** Simpan referensi foto dasar secara lokal (cadangan). */
    fun cacheBasePhoto(path: String) = local.saveBasePhoto(userId(), path)

    companion object {
        /** Ambang kemiripan identitas (tidak lagi dipakai sbg gerbang ketat). */
        const val MATCH_THRESHOLD = 85
        const val ENROLL_SAMPLES_NEEDED = 3
    }
}
