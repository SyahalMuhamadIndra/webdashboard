package com.absensiku.app.face.engine.util

import android.graphics.PointF
import kotlin.math.sqrt

/**
 * Utilitas geometri 2D (padanan helper `_dist`, `_midpoint`, `_width`,
 * `_height`, `_top`, `_bounded` pada Dart).
 */
object GeoUtils {

    /** Jarak Euclidean antar dua titik. Mengembalikan 0 jika salah satu null. */
    fun dist(a: PointF?, b: PointF?): Double {
        if (a == null || b == null) return 0.0
        val dx = (a.x - b.x).toDouble()
        val dy = (a.y - b.y).toDouble()
        return sqrt(dx * dx + dy * dy)
    }

    /** Titik tengah antara dua titik. */
    fun midpoint(a: PointF, b: PointF): PointF =
        PointF((a.x + b.x) / 2f, (a.y + b.y) / 2f)

    /** Lebar bounding horizontal dari sekumpulan titik. */
    fun width(pts: List<PointF>): Double {
        var minX = Double.POSITIVE_INFINITY
        var maxX = Double.NEGATIVE_INFINITY
        for (p in pts) {
            if (p.x < minX) minX = p.x.toDouble()
            if (p.x > maxX) maxX = p.x.toDouble()
        }
        return maxX - minX
    }

    /** Tinggi bounding vertikal dari sekumpulan titik. */
    fun height(pts: List<PointF>): Double {
        var minY = Double.POSITIVE_INFINITY
        var maxY = Double.NEGATIVE_INFINITY
        for (p in pts) {
            if (p.y < minY) minY = p.y.toDouble()
            if (p.y > maxY) maxY = p.y.toDouble()
        }
        return maxY - minY
    }

    /** Nilai Y paling atas (minimum) dari sekumpulan titik. */
    fun top(pts: List<PointF>): Double {
        var minY = Double.POSITIVE_INFINITY
        for (p in pts) if (p.y < minY) minY = p.y.toDouble()
        return minY
    }

    /** Membulatkan nilai ke int dan meng-clamp ke rentang [0, 255]. */
    fun bounded(value: Double): Int = Math.round(value).toInt().coerceIn(0, 255)
}
