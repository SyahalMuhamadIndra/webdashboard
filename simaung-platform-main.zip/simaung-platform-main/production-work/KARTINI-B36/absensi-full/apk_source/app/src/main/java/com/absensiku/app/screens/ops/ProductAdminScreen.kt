package com.absensiku.app.screens.ops

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.MeResponse
import com.absensiku.app.api.OpsProduct
import com.absensiku.app.api.ProductInput
import com.absensiku.app.ui.components.OpsBadge
import com.absensiku.app.ui.components.OpsCard
import com.absensiku.app.ui.components.OpsEmpty
import com.absensiku.app.ui.components.OpsGhostButton
import com.absensiku.app.ui.components.OpsPrimaryButton
import com.absensiku.app.ui.components.OpsSectionTitle
import com.absensiku.app.ui.components.OpsTextField
import com.absensiku.app.ui.components.OpsTone
import com.absensiku.app.ui.components.OpsTopBar
import com.absensiku.app.ui.components.formatRp
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.launch

/**
 * Kelola Barang (katalog) — untuk admin / kepala gudang.
 * Master barang ini dipakai BERSAMA oleh modul POS (kasir) dan Stock Opname.
 * - Tambah / ubah / hapus barang & aktif/nonaktifkan.
 * - Kelola harga jual, harga pokok, stok, dan stok minimum.
 */
@Composable
fun ProductAdminScreen(
    api: ApiClient,
    me: MeResponse,
    showMessage: (String) -> Unit,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(true) }
    var products by remember { mutableStateOf<List<OpsProduct>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<OpsProduct?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<OpsProduct?>(null) }

    fun load() {
        scope.launch {
            busy = true
            try {
                products = api.listAdminProducts()
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { showMessage(e.message ?: "Gagal memuat daftar barang") }
            busy = false
        }
    }
    LaunchedEffect(Unit) { load() }

    val filtered = if (query.isBlank()) products
        else products.filter {
            it.name.contains(query, true) ||
                (it.sku?.contains(query, true) == true) ||
                (it.category?.contains(query, true) == true)
        }
    val lowCount = products.count { it.low && it.active }
    val activeCount = products.count { it.active }

    Box(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        Column(modifier = Modifier.fillMaxSize()) {
            OpsTopBar(
                title = "Kelola Barang",
                subtitle = "Katalog untuk POS & Stock Opname",
                onBack = onBack,
            )
            if (busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp), color = KartiniColors.BrandGreen)
            }

            if (showForm) {
                ProductForm(
                    api = api,
                    initial = editing,
                    showMessage = showMessage,
                    onDone = { showForm = false; editing = null; load() },
                    onCancel = { showForm = false; editing = null },
                )
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp, vertical = 16.dp),
                ) {
                    OpsSectionTitle("Ringkasan Katalog")
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        KpiBox("Total", "${products.size}", Modifier.weight(1f))
                        KpiBox("Aktif", "$activeCount", Modifier.weight(1f))
                        KpiBox("Stok Menipis", "$lowCount", Modifier.weight(1f), warn = lowCount > 0)
                    }
                    Spacer(Modifier.height(16.dp))
                    OpsPrimaryButton(text = "+ Tambah Barang", onClick = { editing = null; showForm = true })
                    Spacer(Modifier.height(16.dp))
                    OpsSectionTitle("Daftar Barang")
                    Spacer(Modifier.height(10.dp))
                    OpsTextField(query, { query = it }, "Cari barang / SKU / kategori")
                    Spacer(Modifier.height(12.dp))
                    if (filtered.isEmpty()) {
                        OpsEmpty(if (products.isEmpty()) "Belum ada barang. Tambahkan barang pertama Anda." else "Barang tidak ditemukan.")
                    } else {
                        filtered.forEach { p ->
                            ProductAdminRow(
                                p = p,
                                onEdit = { editing = p; showForm = true },
                                onDelete = { toDelete = p },
                                onToggleActive = {
                                    scope.launch {
                                        try {
                                            api.updateProduct(p.id, ProductInput(active = !p.active))
                                            showMessage(if (p.active) "Barang dinonaktifkan" else "Barang diaktifkan")
                                            load()
                                        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                                        catch (e: Exception) { showMessage(e.message ?: "Gagal mengubah status") }
                                    }
                                },
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }

    // Dialog konfirmasi hapus.
    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Hapus barang?", fontWeight = FontWeight.Bold) },
            text = { Text("“${p.name}” akan dihapus dari katalog. Tindakan ini tidak bisa dibatalkan.") },
            confirmButton = {
                TextButton(onClick = {
                    val target = p
                    toDelete = null
                    scope.launch {
                        try {
                            api.deleteProduct(target.id)
                            showMessage("Barang dihapus")
                            load()
                        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                        catch (e: Exception) { showMessage(e.message ?: "Gagal menghapus barang") }
                    }
                }) { Text("Hapus", color = KartiniColors.StatusBadFg, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Batal") } },
        )
    }
}

@Composable
private fun KpiBox(label: String, value: String, modifier: Modifier = Modifier, warn: Boolean = false) {
    OpsCard(modifier = modifier) {
        Text(
            value,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (warn) KartiniColors.StatusWarnFg else KartiniColors.OnSurface,
        )
        Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = KartiniColors.OnSurfaceMuted)
    }
}

@Composable
private fun ProductAdminRow(
    p: OpsProduct,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleActive: () -> Unit,
) {
    OpsCard {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(p.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = KartiniColors.OnSurface)
                    if (!p.active) {
                        Spacer(Modifier.width(8.dp))
                        OpsBadge("Nonaktif", OpsTone.NEUTRAL)
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    buildString {
                        p.sku?.takeIf { it.isNotBlank() }?.let { append("$it • ") }
                        append("Jual ${formatRp(p.price)} • Pokok ${formatRp(p.cost)}")
                    },
                    fontSize = 11.5.sp,
                    color = KartiniColors.OnSurfaceMuted,
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OpsBadge(
                        "Stok ${p.stock} ${p.unit ?: "pcs"}",
                        if (p.low) OpsTone.WARN else OpsTone.OK,
                    )
                    p.category?.takeIf { it.isNotBlank() }?.let {
                        Spacer(Modifier.width(6.dp))
                        OpsBadge(it, OpsTone.INFO)
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OpsGhostButton(text = "Ubah", onClick = onEdit, modifier = Modifier.weight(1f))
            OpsGhostButton(
                text = if (p.active) "Nonaktifkan" else "Aktifkan",
                onClick = onToggleActive,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onDelete) {
                Text("Hapus", color = KartiniColors.StatusBadFg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ProductForm(
    api: ApiClient,
    initial: OpsProduct?,
    showMessage: (String) -> Unit,
    onDone: () -> Unit,
    onCancel: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var sku by remember { mutableStateOf(initial?.sku ?: "") }
    var barcode by remember { mutableStateOf(initial?.barcode ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "") }
    var unit by remember { mutableStateOf(initial?.unit ?: "pcs") }
    var price by remember { mutableStateOf(initial?.price?.let { fmtNum(it) } ?: "") }
    var cost by remember { mutableStateOf(initial?.cost?.let { fmtNum(it) } ?: "") }
    var stock by remember { mutableStateOf(initial?.stock?.toString() ?: "0") }
    var minStock by remember { mutableStateOf(initial?.minStock?.toString() ?: "0") }
    var active by remember { mutableStateOf(initial?.active ?: true) }
    var saving by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        OpsSectionTitle(if (initial == null) "Tambah Barang" else "Ubah Barang")
        Spacer(Modifier.height(12.dp))
        OpsTextField(name, { name = it }, "Nama barang *")
        Spacer(Modifier.height(10.dp))
        OpsTextField(sku, { sku = it }, "SKU / kode barang")
        Spacer(Modifier.height(10.dp))
        OpsTextField(barcode, { barcode = it }, "Barcode (untuk scan di kasir)")
        Spacer(Modifier.height(10.dp))
        OpsTextField(category, { category = it }, "Kategori")
        Spacer(Modifier.height(10.dp))
        OpsTextField(unit, { unit = it }, "Satuan (pcs, kg, box…)")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            OpsTextField(price, { price = it.filter { c -> c.isDigit() } }, "Harga jual (Rp)", Modifier.weight(1f), KeyboardType.Number)
            OpsTextFieldFormat(cost, { cost = it.filter { c -> c.isDigit() } }, "Harga pokok (Rp)", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            OpsTextField(stock, { stock = it.filter { c -> c.isDigit() } }, "Stok", Modifier.weight(1f), KeyboardType.Number)
            OpsTextField(minStock, { minStock = it.filter { c -> c.isDigit() } }, "Stok minimum", Modifier.weight(1f), KeyboardType.Number)
        }
        Spacer(Modifier.height(14.dp))
        OpsCard {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Barang aktif", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = KartiniColors.OnSurface)
                    Text("Hanya barang aktif yang tampil di POS.", fontSize = 11.5.sp, color = KartiniColors.OnSurfaceMuted)
                }
                Switch(
                    checked = active,
                    onCheckedChange = { active = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = KartiniColors.BrandGreen),
                )
            }
        }
        Spacer(Modifier.height(18.dp))
        OpsPrimaryButton(
            text = if (saving) "Menyimpan…" else "Simpan",
            enabled = !saving && name.isNotBlank(),
            onClick = {
                saving = true
                scope.launch {
                    try {
                        val input = ProductInput(
                            name = name.trim(),
                            sku = sku.trim().ifBlank { null },
                            barcode = barcode.trim().ifBlank { null },
                            category = category.trim().ifBlank { null },
                            unit = unit.trim().ifBlank { "pcs" },
                            price = price.toDoubleOrNull() ?: 0.0,
                            cost = cost.toDoubleOrNull() ?: 0.0,
                            stock = stock.toIntOrNull() ?: 0,
                            minStock = minStock.toIntOrNull() ?: 0,
                            active = active,
                        )
                        if (initial == null) {
                            api.createProduct(input)
                            showMessage("Barang ditambahkan")
                        } else {
                            api.updateProduct(initial.id, input)
                            showMessage("Barang diperbarui")
                        }
                        onDone()
                    } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                    catch (e: Exception) { showMessage(e.message ?: "Gagal menyimpan barang") }
                    saving = false
                }
            },
        )
        Spacer(Modifier.height(10.dp))
        OpsGhostButton(text = "Batal", onClick = onCancel, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
    }
}

/** TextField angka dengan label (varian ringkas agar rapi berdampingan). */
@Composable
private fun OpsTextFieldFormat(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
) {
    OpsTextField(value, onValueChange, label, modifier, KeyboardType.Number)
}

private fun fmtNum(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
