package com.absensiku.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * Palette resmi Simaung Corporation (senada logo — sesuai desain yang disetujui):
 *   Hijau logo  #036D19  -> brand utama
 *   Oranye logo #F85800  -> aksen
 *
 * B67 — DINAMIS PER LOKASI: setiap nilai di bawah kini diambil dari
 * [BrandingPalette] (bukan warna tetap). Nilai awal BrandingPalette = palet
 * resmi di atas, jadi bila server tidak mengirim desain khusus, tampilan tetap
 * identik dengan sebelumnya.
 *
 * Karena berbentuk `get()`, SELURUH 443 pemakaian `KartiniColors.X` di aplikasi
 * otomatis mengikuti desain baru TANPA mengubah satu pun pemanggilan.
 */
object KartiniColors {
    val BrandGreen: Color get() = BrandingPalette.primary
    val BrandGreenDeep: Color get() = BrandingPalette.primaryDark
    val BrandGreenDark: Color get() = BrandingPalette.primaryDarkest
    val BrandGreenSoft: Color get() = BrandingPalette.primarySoft
    val BrandOrange: Color get() = BrandingPalette.accent
    val BrandOrangeDeep: Color get() = BrandingPalette.accentDeep
    val BrandOrangeSoft: Color get() = BrandingPalette.accentSoft

    val CreamBg: Color get() = BrandingPalette.bg
    val CreamSurface: Color get() = BrandingPalette.surface
    val CreamDeep: Color get() = BrandingPalette.bgDeep

    val DarkGreen: Color get() = BrandGreen
    val DarkGreenDeep: Color get() = BrandGreenDeep
    val Olive: Color get() = BrandGreenDeep
    val OliveLight: Color get() = BrandGreenSoft

    val White: Color = Color(0xFFFFFFFF)
    val OnSurface: Color get() = BrandingPalette.onSurface
    val OnSurfaceMuted: Color get() = BrandingPalette.onSurfaceMuted
    val Outline: Color get() = BrandingPalette.outline
    val DividerLight: Color get() = BrandingPalette.divider

    // Warna status (hijau sukses mengikuti brand; sisanya tetap agar makna
    // "peringatan/error" tidak hilang).
    val StatusOkBg: Color get() = BrandGreenSoft
    val StatusOkFg: Color get() = BrandGreenDeep
    val StatusWarnBg: Color = Color(0xFFFDE6D7)
    val StatusWarnFg: Color = Color(0xFFB14A00)
    val StatusBadBg: Color = Color(0xFFFBE0DD)
    val StatusBadFg: Color = Color(0xFFB0322E)
    val StatusInfoBg: Color = Color(0xFFE9EFE9)
    val StatusInfoFg: Color = Color(0xFF24503A)

    val GarnishRed: Color get() = BrandOrange
}

/**
 * Skema Material dibangun ULANG setiap kali komposisi dijalankan, sehingga
 * mengikuti [BrandingPalette] (perubahan desain langsung terlihat).
 *
 * Catatan penting (tidak diubah): aplikasi ini memakai SATU palet resmi yang
 * dipatok pada warna langsung, bukan pada colorScheme Material. Mode "Dark"
 * sengaja TIDAK dipakai — dulu menyebabkan teks kode & PIN tampak pucat di atas
 * kontainer cream. Tema tetap DIPAKU ke skema terang agar konsisten.
 */
@Composable
private fun kartiniColorScheme() = lightColorScheme(
    primary = KartiniColors.BrandGreen,
    onPrimary = KartiniColors.White,
    primaryContainer = KartiniColors.BrandGreenSoft,
    onPrimaryContainer = KartiniColors.BrandGreenDeep,
    secondary = KartiniColors.BrandOrange,
    onSecondary = KartiniColors.White,
    secondaryContainer = KartiniColors.BrandOrangeSoft,
    onSecondaryContainer = KartiniColors.BrandOrangeDeep,
    tertiary = KartiniColors.Olive,
    background = KartiniColors.CreamBg,
    onBackground = KartiniColors.OnSurface,
    surface = KartiniColors.White,
    onSurface = KartiniColors.OnSurface,
    surfaceVariant = KartiniColors.CreamSurface,
    onSurfaceVariant = KartiniColors.OnSurfaceMuted,
    outline = KartiniColors.Outline,
    error = KartiniColors.StatusBadFg,
    onError = KartiniColors.White,
)

@Composable
fun AbsensiKuTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = kartiniColorScheme(), content = content)
}
