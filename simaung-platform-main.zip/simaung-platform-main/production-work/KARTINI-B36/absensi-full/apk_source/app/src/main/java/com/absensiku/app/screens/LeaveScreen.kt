package com.absensiku.app.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.R
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.LeaveItem
import com.absensiku.app.ui.components.BrandTopBar
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale

// Kategori yang didukung (permintaan): hanya dua jenis.
private const val CAT_SICK = "SAKIT"
private const val CAT_PRIVATE = "IZIN"

private fun labelCategory(c: String): String = when (c) {
    "SAKIT" -> "Izin Sakit"
    else -> "Izin"
}

/** Pengajuan izin/cuti — tampilan profesional (ringkasan + kartu beraksen). */
@Composable
fun LeaveScreen(
    api: ApiClient,
    showMessage: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<LeaveItem>>(emptyList()) }
    var busy by remember { mutableStateOf(true) }
    var showDialog by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch {
            busy = true
            try {
                items = api.listLeaves()
            } catch (e: kotlinx.coroutines.CancellationException) {

                throw e

            } catch (e: Exception) {
                showMessage(e.message ?: "Gagal memuat")
            }
            busy = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    val pending = items.count { it.status != "APPROVED" && it.status != "REJECTED" }
    val approved = items.count { it.status == "APPROVED" }
    val rejected = items.count { it.status == "REJECTED" }

    Box(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        Column(modifier = Modifier.fillMaxSize()) {
            BrandTopBar(
                title = "Izin",
                subtitle = "Pengajuan izin & persetujuan superadmin",
            )
            if (busy) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = KartiniColors.BrandGreen,
                    trackColor = KartiniColors.BrandGreenSoft,
                )
            }

            if (!busy && items.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.Center,
                ) {
                    LeaveEmptyCard()
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 84.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    item { LeaveSummary(pending, approved, rejected) }
                    item { Spacer(Modifier.height(2.dp)) }
                    item { LeaveSectionTitle("Daftar Pengajuan") }
                    item { Spacer(Modifier.height(2.dp)) }
                    items(items, key = { it.id }) { LeaveCard(it) }
                }
            }
        }

        FloatingActionButton(
            onClick = { showDialog = true },
            containerColor = KartiniColors.BrandGreen,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Ajukan izin")
        }
    }

    if (showDialog) {
        LeaveDialog(
            onDismiss = { showDialog = false },
            onSubmit = { category, start, end, reason, attachment ->
                scope.launch {
                    try {
                        api.createLeave(category, start, end, reason, attachment)
                        showDialog = false
                        showMessage("Pengajuan izin terkirim. Menunggu persetujuan superadmin.")
                        refresh()
                    } catch (e: kotlinx.coroutines.CancellationException) {

                        throw e

                    } catch (e: Exception) {
                        showMessage(e.message ?: "Gagal mengirim")
                    }
                }
            },
        )
    }
}

/* ---------------- Ringkasan ---------------- */

@Composable
private fun LeaveSummary(pending: Int, approved: Int, rejected: Int) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        LeaveStat("Menunggu", "$pending", KartiniColors.BrandOrangeDeep, Modifier.weight(1f))
        LeaveStat("Disetujui", "$approved", KartiniColors.StatusOkFg, Modifier.weight(1f))
        LeaveStat("Ditolak", "$rejected", KartiniColors.StatusBadFg, Modifier.weight(1f))
    }
}

@Composable
private fun LeaveStat(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = KartiniColors.CreamSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, color = KartiniColors.OnSurfaceMuted, fontSize = 10.5.sp, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
        }
    }
}

@Composable
private fun LeaveSectionTitle(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier.size(width = 4.dp, height = 18.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(KartiniColors.BrandGreen),
        )
        Spacer(Modifier.width(8.dp))
        Text(text, color = KartiniColors.OnSurface, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/* ---------------- Kartu pengajuan ---------------- */

@Composable
private fun LeaveCard(item: LeaveItem) {
    val isSick = item.category == CAT_SICK
    val accent = when (item.status) {
        "APPROVED" -> KartiniColors.BrandGreen
        "REJECTED" -> KartiniColors.StatusBadFg
        else -> KartiniColors.BrandOrange
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            Box(modifier = Modifier.width(5.dp).fillMaxHeight().background(accent))
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (isSick) KartiniColors.BrandOrangeSoft else KartiniColors.BrandGreenSoft),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = painterResource(if (isSick) R.drawable.ic_leave_sick else R.drawable.ic_leave_private),
                            contentDescription = null,
                            tint = if (isSick) KartiniColors.BrandOrangeDeep else KartiniColors.BrandGreen,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            labelCategory(item.category),
                            color = KartiniColors.OnSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            durasiLabel(item.startDate, item.endDate),
                            color = KartiniColors.OnSurfaceMuted,
                            fontSize = 11.5.sp,
                        )
                    }
                    LeaveStatusChip(item.status)
                }

                Spacer(Modifier.height(11.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(KartiniColors.CreamBg)
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_tab_jadwal),
                        contentDescription = null,
                        tint = KartiniColors.BrandGreen,
                        modifier = Modifier.size(15.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${prettyDate(item.startDate)}  →  ${prettyDate(item.endDate)}",
                        color = KartiniColors.OnSurface,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.5.sp,
                    )
                }

                if (!item.reason.isNullOrBlank()) {
                    Spacer(Modifier.height(9.dp))
                    Text(
                        item.reason,
                        color = KartiniColors.OnSurfaceMuted,
                        fontSize = 12.sp,
                        maxLines = 2,
                    )
                }

                if (item.hasAttachment) {
                    Spacer(Modifier.height(9.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painter = painterResource(R.drawable.ic_add_doc),
                            contentDescription = null,
                            tint = KartiniColors.Olive,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "Lampiran surat terlampir",
                            color = KartiniColors.Olive,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LeaveStatusChip(status: String) {
    val fg: Color
    val bg: Color
    val label: String
    when (status) {
        "APPROVED" -> { fg = KartiniColors.StatusOkFg; bg = KartiniColors.StatusOkBg; label = "Disetujui" }
        "REJECTED" -> { fg = KartiniColors.StatusBadFg; bg = KartiniColors.StatusBadBg; label = "Ditolak" }
        else -> { fg = KartiniColors.StatusWarnFg; bg = KartiniColors.StatusWarnBg; label = "Menunggu" }
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun LeaveEmptyCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = KartiniColors.CreamSurface),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier.size(52.dp).clip(CircleShape).background(KartiniColors.BrandGreenSoft),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_tab_izin),
                    contentDescription = null,
                    tint = KartiniColors.BrandGreen,
                    modifier = Modifier.size(26.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            Text("Belum ada pengajuan", color = KartiniColors.OnSurface, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(
                "Tekan tombol + untuk mengajukan izin atau cuti.",
                color = KartiniColors.OnSurfaceMuted, fontSize = 12.sp, textAlign = TextAlign.Center,
            )
        }
    }
}

/* ---------------- Dialog pengajuan (tidak berubah) ---------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LeaveDialog(
    onDismiss: () -> Unit,
    onSubmit: (category: String, start: String, end: String, reason: String?, attachmentBase64: String?) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var category by remember { mutableStateOf(CAT_SICK) }
    var typeMenu by remember { mutableStateOf(false) }
    var start by remember { mutableStateOf(LocalDate.now().toString()) }
    var end by remember { mutableStateOf(LocalDate.now().toString()) }
    var reason by remember { mutableStateOf("") }

    var attachmentB64 by remember { mutableStateOf<String?>(null) }
    var attachmentBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var attaching by remember { mutableStateOf(false) }

    val isSick = category == CAT_SICK

    val pickImage = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        attaching = true
        scope.launch {
            val result = withContext(Dispatchers.IO) { loadCompressed(uri, context.contentResolver) }
            attaching = false
            if (result == null) return@launch
            attachmentBitmap = result.first
            attachmentB64 = result.second
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            val canSubmit = !attaching && (!isSick || attachmentB64 != null)
            TextButton(
                enabled = canSubmit,
                onClick = {
                    onSubmit(category, start, end, reason.ifBlank { null }, if (isSick) attachmentB64 else null)
                },
            ) { Text(if (isSick && attachmentB64 == null) "Lampiran wajib" else "Kirim Pengajuan", color = if (canSubmit) KartiniColors.BrandGreen else KartiniColors.OnSurfaceMuted, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Ajukan Izin/Cuti", color = KartiniColors.OnSurface, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Jenis (dropdown)
                Text("Jenis", color = KartiniColors.OnSurfaceMuted, fontSize = 12.sp)
                Box {
                    OutlinedTextField(
                        value = labelCategory(category),
                        onValueChange = {},
                        readOnly = true,
                        enabled = false,
                        trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                    )
                    Box(Modifier.matchParentSize().clickable { typeMenu = true })
                    DropdownMenu(expanded = typeMenu, onDismissRequest = { typeMenu = false }) {
                        DropdownMenuItem(text = { Text(labelCategory(CAT_SICK)) }, onClick = { category = CAT_SICK; typeMenu = false })
                        DropdownMenuItem(text = { Text(labelCategory(CAT_PRIVATE)) }, onClick = { category = CAT_PRIVATE; typeMenu = false })
                    }
                }

                // Tanggal mulai & sampai
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateField(label = "Dari", value = start, onChange = { start = it }, modifier = Modifier.weight(1f))
                    DateField(label = "Sampai", value = end, onChange = { end = it }, modifier = Modifier.weight(1f))
                }

                // Alasan
                OutlinedTextField(
                    value = reason, onValueChange = { reason = it },
                    label = { Text("Alasan") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    shape = RoundedCornerShape(12.dp),
                )

                // Lampiran (hanya untuk Izin Sakit)
                if (isSick) {
                    Text(
                        "Lampiran surat/dokumen (wajib saat sakit)",
                        color = KartiniColors.BrandOrangeDeep, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 120.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, KartiniColors.Outline, RoundedCornerShape(12.dp))
                            .background(KartiniColors.CreamSurface),
                        contentAlignment = Alignment.Center,
                    ) {
                        val bmp = attachmentBitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Lampiran surat sakit",
                                modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).padding(6.dp),
                            )
                        } else if (attaching) {
                            LinearProgressIndicator(color = KartiniColors.BrandGreen)
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.ic_add_doc),
                                contentDescription = null,
                                tint = KartiniColors.OnSurfaceMuted,
                                modifier = Modifier.size(44.dp),
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = { pickImage.launch("image/*") },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KartiniColors.BrandGreen),
                    ) {
                        Icon(painterResource(R.drawable.ic_camera), contentDescription = null, tint = KartiniColors.BrandGreen, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Pilih / Ambil Foto", color = KartiniColors.BrandGreen, fontWeight = FontWeight.SemiBold)
                    }
                    Text(
                        "Foto surat sakit diperlukan sebagai bukti.",
                        color = KartiniColors.OnSurfaceMuted, fontSize = 11.sp,
                    )
                }
            }
        },
        shape = RoundedCornerShape(18.dp),
        containerColor = Color.White,
    )
}

@Composable
private fun DateField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        leadingIcon = { Icon(painterResource(R.drawable.ic_tab_izin), contentDescription = null, tint = KartiniColors.Olive, modifier = Modifier.size(18.dp)) },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier,
    )
}

private fun loadCompressed(uri: Uri, resolver: android.content.ContentResolver): Pair<Bitmap, String>? {
    return try {
        val input = resolver.openInputStream(uri) ?: return null
        val original = BitmapFactory.decodeStream(input)
        input.close()
        if (original == null) return null
        val maxDim = 1280
        val scale = minOf(1f, maxDim.toFloat() / maxOf(original.width, original.height))
        val bmp = if (scale < 1f) {
            Bitmap.createScaledBitmap(original, (original.width * scale).toInt(), (original.height * scale).toInt(), true)
        } else original
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 75, out)
        bmp to Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    } catch (_: Exception) { null }
}

private fun prettyDate(iso: String): String = runCatching {
    val d = LocalDate.parse(iso)
    val month = d.month.getDisplayName(java.time.format.TextStyle.SHORT, Locale("id", "ID"))
    "${d.dayOfMonth} $month ${d.year}"
}.getOrElse { iso }

private fun durasiLabel(startIso: String, endIso: String): String = runCatching {
    val s = LocalDate.parse(startIso)
    val e = LocalDate.parse(endIso)
    val n = (ChronoUnit.DAYS.between(s, e) + 1).coerceAtLeast(1).toInt()
    if (n == 1) "1 hari" else "$n hari"
}.getOrElse { "—" }
