package com.absensiku.app.face.engine.core

import android.content.SharedPreferences

/**
 * Manajer enrolment wajah: menyimpan & mengambil sample wajah multi-sample
 * serta foto dasar (base photo) per pengguna.
 *
 * Padanan `AuthProvider.saveFaceSignature` / `saveFaceBasePhoto` pada Flutter,
 * diringkas ke penyimpanan lokal (SharedPreferences). Bila aplikasi Anda
 * memakai backend (Firestore/Supabase), ganti implementasi [Store] ini.
 */
class EnrollmentManager(private val prefs: SharedPreferences) {

    /**
     * Menyimpan daftar sample signature untuk [userId].
     * Digabung menjadi satu string JSON array (multi-sample) seperti Dart.
     */
    fun saveSamples(userId: String, samples: List<String>) {
        prefs.edit().putString(keySamples(userId), FaceMatcher.joinSamples(samples)).apply()
    }

    /** Mengambil daftar sample signature tersimpan (boleh kosong). */
    fun getSamples(userId: String): List<String> =
        FaceMatcher.splitSamples(prefs.getString(keySamples(userId), null))

    /** Menyimpan path foto dasar (referensi visual ala GreatDay HR). */
    fun saveBasePhoto(userId: String, path: String) {
        prefs.edit().putString(keyBasePhoto(userId), path).apply()
    }

    /** Mengambil path foto dasar terakhir. */
    fun getBasePhoto(userId: String): String? =
        prefs.getString(keyBasePhoto(userId), null)

    /** Menyimpan foto dasar sebagai base64 (dipakai thumbnail di layar kamera). */
    fun saveBasePhotoBase64(userId: String, b64: String) {
        prefs.edit().putString(keyBasePhotoB64(userId), b64).apply()
    }

    /** Mengambil foto dasar base64 tersimpan (boleh null). */
    fun getBasePhotoBase64(userId: String): String? =
        prefs.getString(keyBasePhotoB64(userId), null)

    /** Menghapus seluruh data wajah untuk pengguna (re-enroll). */
    fun clear(userId: String) {
        prefs.edit()
            .remove(keySamples(userId))
            .remove(keyBasePhoto(userId))
            .remove(keyBasePhotoB64(userId))
            .apply()
    }

    /** True jika ada minimal satu sample tersimpan. */
    fun hasEnrollment(userId: String): Boolean = getSamples(userId).isNotEmpty()

    /**
     * True jika salah satu sample memakai format lama (v1/v2) sehingga harus
     * direkam ulang demi akurasi & keamanan.
     */
    fun hasLegacySample(userId: String): Boolean =
        getSamples(userId).any { FaceMatcher.isLegacySignature(it) }

    private fun keySamples(userId: String) = "face_samples_$userId"
    private fun keyBasePhoto(userId: String) = "face_base_photo_$userId"
    private fun keyBasePhotoB64(userId: String) = "face_base_photo_b64_$userId"
}
