package com.absensiku.app.face.engine.util

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.PointF
import com.absensiku.app.face.engine.model.FaceLandmarkType
import com.absensiku.app.face.engine.model.FaceResult
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.sqrt

/**
 * =====================================================================
 *  FACE TEMPLATE EXTRACTOR (v5) — tekstur keabuan ala GreatDay HR
 * =====================================================================
 *
 * Menghasilkan *template* wajah berupa grid keabuan [GRID]×[GRID] yang:
 *  - di-**align mata** (eye-aligned) supaya tahan terhadap sedikit kemiringan,
 *  - dinormalisasi pencahayaan (mean → 128, std → ~48),
 *  - disimpan sebagai JSON `{"v":5,"t":[1024 nilai int 0..255]}`.
 *
 * Format IDENTIK dengan server (`server/src/faceMatcher.js` →
 * `isTemplate/decodeTemplate/templateScore`) sehingga skor NCC di
 * perangkat dan server menghasilkan angka yang sama.
 *
 * Catatan: pada versi lama template dikodekan base64; kini memakai array
 * int JSON agar konsisten lintas platform dan mudah di-skore dengan NCC.
 */
object FaceTemplateExtractor {

    /** Resolusi grid (sisi). 32 → 1024 nilai. */
    const val GRID = 32

    /** Panjang vektor template = GRID * GRID. */
    const val LENGTH = GRID * GRID

    /** Versi skema template. */
    private const val VERSION = 5

    /** Target simpangan baku setelah normalisasi pencahayaan. */
    private const val TARGET_STD = 48.0

    /** True bila signature adalah template v5. */
    fun isTemplate(sig: String?): Boolean {
        if (sig.isNullOrBlank()) return false
        return try {
            val o = JSONObject(sig)
            o.optInt("v", -1) == VERSION && o.optJSONArray("t")?.length() == LENGTH
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Mengekstrak template dari [bitmap] untuk wajah [face].
     * Mengembalikan JSON v5, atau null bila region wajah tidak valid.
     */
    fun extract(bitmap: Bitmap, face: FaceResult): String? {
        val region = face.boundingBox
        if (region.width() <= 0 || region.height() <= 0) return null

        // ---- Align mata: putar bitmap agar garis mata horizontal ----
        val leftEye = face.landmarks[FaceLandmarkType.LEFT_EYE]
        val rightEye = face.landmarks[FaceLandmarkType.RIGHT_EYE]
        var working = bitmap
        var box = region
        if (leftEye != null && rightEye != null) {
            val angle = Math.toDegrees(
                atan2((rightEye.y - leftEye.y).toDouble(), (rightEye.x - leftEye.x).toDouble())
            ).toFloat()
            if (kotlin.math.abs(angle) > 1f) {
                val m = Matrix().apply { postRotate(-angle, bitmap.width / 2f, bitmap.height / 2f) }
                val rotated = try {
                    Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, m, true)
                } catch (_: Exception) {
                    bitmap
                }
                if (rotated !== bitmap) {
                    working = rotated
                    // Perkirakan ulang kotak wajah ter-rotasi dari titik tengah box.
                    val cx = region.exactCenterX()
                    val cy = region.exactCenterY()
                    val w = region.width()
                    val h = region.height()
                    box = android.graphics.Rect(
                        (cx - w / 2f).toInt(), (cy - h / 2f).toInt(),
                        (cx + w / 2f).toInt(), (cy + h / 2f).toInt(),
                    )
                }
            }
        }

        // ---- Crop kotak wajah + sedikit margin, lalu resample ke GRID×GRID ----
        val margin = 0.12f
        val mw = box.width() * margin
        val mh = box.height() * margin
        val sx = (box.left - mw).toInt().coerceAtLeast(0)
        val sy = (box.top - mh).toInt().coerceAtLeast(0)
        val ex = (box.right + mw).toInt().coerceAtMost(working.width)
        val ey = (box.bottom + mh).toInt().coerceAtMost(working.height)
        val cw = ex - sx
        val ch = ey - sy
        if (cw <= 2 || ch <= 2) return null

        val src = try {
            Bitmap.createBitmap(working, sx, sy, cw, ch)
        } catch (_: Exception) {
            return null
        }

        val grid = FloatArray(LENGTH)
        val sw = src.width
        val sh = src.height
        val pixels = IntArray(sw * sh)
        src.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        for (gy in 0 until GRID) {
            for (gx in 0 until GRID) {
                // Nearest-neighbour sampling.
                val px = ((gx + 0.5f) / GRID * sw).toInt().coerceIn(0, sw - 1)
                val py = ((gy + 0.5f) / GRID * sh).toInt().coerceIn(0, sh - 1)
                val c = pixels[py * sw + px]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                // Luminance (Rec.601).
                grid[gy * GRID + gx] = (0.299f * r + 0.587f * g + 0.114f * b)
            }
        }
        if (src !== working && src !== bitmap) src.recycle()
        if (working !== bitmap) working.recycle()

        val normalized = normalizeIllumination(grid)
        val arr = JSONArray()
        for (v in normalized) arr.put(v)
        val root = JSONObject()
        root.put("v", VERSION)
        root.put("t", arr)
        return root.toString()
    }

    /**
     * Normalisasi pencahayaan: kurangi rata-rata, bagi simpangan baku,
     * geser ke rata-rata 128 dengan target std [TARGET_STD]. Hasil di-clamp 0..255.
     */
    private fun normalizeIllumination(grid: FloatArray): IntArray {
        val n = grid.size
        var mean = 0.0
        for (v in grid) mean += v
        mean /= n
        var varSum = 0.0
        for (v in grid) {
            val d = v - mean
            varSum += d * d
        }
        var std = sqrt(varSum / n)
        if (std < 1e-3) std = 1e-3
        val out = IntArray(n)
        for (i in 0 until n) {
            val v = 128.0 + (grid[i] - mean) / std * TARGET_STD
            out[i] = Math.round(v).toInt().coerceIn(0, 255)
        }
        return out
    }
}
