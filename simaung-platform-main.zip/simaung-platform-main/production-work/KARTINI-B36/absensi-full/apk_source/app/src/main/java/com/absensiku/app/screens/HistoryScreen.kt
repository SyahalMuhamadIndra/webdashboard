package com.absensiku.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.R
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.HistoryItem
import com.absensiku.app.ui.components.BrandTopBar
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private data class DayRow(
    val dateKey: String,
    val weekday: String,
    val dateLabel: String,
    val checkIn: HistoryItem?,
    val checkOut: HistoryItem?,
)

/** Riwayat absensi harian — tampilan profesional (kartu beraksen + ringkasan). */
@Composable
fun HistoryScreen(
    api: ApiClient,
    showMessage: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<HistoryItem>>(emptyList()) }
    var busy by remember { mutableStateOf(true) }

    fun refresh() {
        scope.launch {
            busy = true
            try {
                items = api.getHistory(60)
            } catch (e: kotlinx.coroutines.CancellationException) {

                throw e

            } catch (e: Exception) {
                showMessage(e.message ?: "Gagal memuat")
            }
            busy = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    // Kelompokkan per tanggal -> satu kartu per hari
    val days: List<DayRow> = remember(items) {
        items.groupBy { it.serverTimestamp.take(10) }
            .toSortedMap(reverseOrder())
            .map { (dateKey, list) ->
                DayRow(
                    dateKey = dateKey,
                    weekday = weekdayOf(dateKey),
                    dateLabel = dateLongOf(dateKey),
                    checkIn = list.firstOrNull { it.type.contains("CHECK_IN") },
                    checkOut = list.firstOrNull { it.type.contains("CHECK_OUT") },
                )
            }
    }

    val todayIso = LocalDate.now().toString()
    val complete = days.count { it.checkIn != null && it.checkOut != null }
    val late = days.count { it.checkIn?.status == "TERLAMBAT" }
    val totalMinutes = days.sumOf {
        workMinutes(it.checkIn?.serverTimestamp, it.checkOut?.serverTimestamp)
    }

    Column(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        BrandTopBar(
            title = "Riwayat Absensi",
            subtitle = "Rekap kehadiran harian Anda",
            action = {
                IconButton(onClick = { refresh() }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Refresh", tint = Color.White)
                }
            },
        )
        if (busy) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = KartiniColors.BrandGreen,
                trackColor = KartiniColors.BrandGreenSoft,
            )
        }

        if (!busy && days.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.Center,
            ) {
                EmptyCard(
                    title = "Belum ada data absensi",
                    subtitle = "Riwayat akan muncul setelah Anda melakukan check-in.",
                )
            }
            return@Column
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 22.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { HistorySummary(days.size, complete, late, totalMinutes) }
            item { Spacer(Modifier.height(2.dp)) }
            item { SectionTitle("Riwayat Harian") }
            item { Spacer(Modifier.height(2.dp)) }
            items(days, key = { it.dateKey }) { day ->
                HistoryDayCard(day, isToday = day.dateKey == todayIso)
            }
        }
    }
}

/* ---------------- Ringkasan ---------------- */

@Composable
private fun HistorySummary(days: Int, complete: Int, late: Int, totalMinutes: Int) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MiniStat("Hari", "$days", KartiniColors.BrandGreen, Modifier.weight(1f))
        MiniStat("Lengkap", "$complete", KartiniColors.Olive, Modifier.weight(1f))
        MiniStat("Terlambat", "$late", KartiniColors.BrandOrangeDeep, Modifier.weight(1f))
        MiniStat("Jam Kerja", hoursLabel(totalMinutes), KartiniColors.BrandGreenDeep, Modifier.weight(1f))
    }
}

@Composable
private fun MiniStat(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = KartiniColors.CreamSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 11.dp)) {
            Text(label, color = KartiniColors.OnSurfaceMuted, fontSize = 10.sp, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier.size(width = 4.dp, height = 18.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(KartiniColors.BrandGreen),
        )
        Spacer(Modifier.width(8.dp))
        Text(text, color = KartiniColors.OnSurface, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/* ---------------- Kartu hari ---------------- */

@Composable
private fun HistoryDayCard(day: DayRow, isToday: Boolean) {
    val filled = day.checkIn != null && day.checkOut != null
    val lateDay = day.checkIn?.status == "TERLAMBAT"
    val accent = when {
        lateDay -> KartiniColors.BrandOrange
        filled -> KartiniColors.BrandGreen
        else -> KartiniColors.Olive
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isToday) 4.dp else 2.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            Box(modifier = Modifier.width(5.dp).fillMaxHeight().background(accent))
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                day.weekday,
                                color = KartiniColors.OnSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                            )
                            if (isToday) {
                                Spacer(Modifier.width(8.dp))
                                TagChip("Hari ini", KartiniColors.BrandGreen, KartiniColors.BrandGreenSoft)
                            }
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(day.dateLabel, color = KartiniColors.OnSurfaceMuted, fontSize = 12.sp)
                    }
                    StatusChip(day)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TimeBox(
                        label = "Masuk",
                        time = shortTime(day.checkIn?.serverTimestamp),
                        accent = KartiniColors.BrandGreen,
                        modifier = Modifier.weight(1f),
                    )
                    TimeBox(
                        label = "Keluar",
                        time = shortTime(day.checkOut?.serverTimestamp),
                        accent = KartiniColors.BrandOrangeDeep,
                        modifier = Modifier.weight(1f),
                    )
                }
                val detail = buildDetail(day)
                if (detail.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painter = painterResource(R.drawable.ic_clock_line),
                            contentDescription = null,
                            tint = KartiniColors.OnSurfaceMuted,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(detail, color = KartiniColors.OnSurfaceMuted, fontSize = 11.5.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeBox(label: String, time: String, accent: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(KartiniColors.CreamBg)
            .padding(horizontal = 12.dp, vertical = 9.dp),
    ) {
        Column {
            Text(label, color = KartiniColors.OnSurfaceMuted, fontSize = 10.5.sp)
            Spacer(Modifier.height(2.dp))
            Text(time, color = accent, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

@Composable
private fun StatusChip(day: DayRow) {
    val (label, fg, bg) = when {
        day.checkIn?.status == "TERLAMBAT" -> Triple("Terlambat", KartiniColors.StatusWarnFg, KartiniColors.StatusWarnBg)
        day.checkIn != null && day.checkOut != null -> Triple("Hadir", KartiniColors.StatusOkFg, KartiniColors.StatusOkBg)
        day.checkIn != null -> Triple("Belum Check-out", KartiniColors.StatusInfoFg, KartiniColors.StatusInfoBg)
        else -> Triple("Absen", KartiniColors.StatusBadFg, KartiniColors.StatusBadBg)
    }
    TagChip(label, fg, bg)
}

@Composable
private fun TagChip(text: String, fg: Color, bg: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(text, color = fg, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun EmptyCard(title: String, subtitle: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = KartiniColors.CreamSurface),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier.size(52.dp).clip(CircleShape).background(KartiniColors.BrandGreenSoft),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_tab_riwayat),
                    contentDescription = null,
                    tint = KartiniColors.BrandGreen,
                    modifier = Modifier.size(26.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(title, color = KartiniColors.OnSurface, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = KartiniColors.OnSurfaceMuted, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}

/* ---------------- Helper data/tampilan ---------------- */

private fun buildDetail(day: DayRow): String {
    val parts = ArrayList<String>()
    val dur = workDurationLabel(day.checkIn?.serverTimestamp, day.checkOut?.serverTimestamp)
    if (dur.isNotBlank()) parts += "Durasi $dur"
    val face = day.checkOut?.faceScore ?: day.checkIn?.faceScore
    if (face != null && face > 0) parts += "Wajah $face%"
    val dist = (day.checkOut ?: day.checkIn)?.distanceMeters
    if (dist != null) parts += "Jarak ${dist.toInt()} m"
    return parts.joinToString("  •  ")
}

private fun workDurationLabel(inIso: String?, outIso: String?): String {
    val mins = workMinutes(inIso, outIso)
    if (mins <= 0) return ""
    val h = mins / 60
    val m = mins % 60
    return if (h > 0) "${h}j ${m}m" else "${m}m"
}

private fun workMinutes(inIso: String?, outIso: String?): Int {
    if (inIso.isNullOrBlank() || outIso.isNullOrBlank()) return 0
    return runCatching {
        val zin = OffsetDateTime.parse(inIso)
        val zout = OffsetDateTime.parse(outIso)
        java.time.Duration.between(zin, zout).toMinutes().coerceAtLeast(0).toInt()
    }.getOrElse { 0 }
}

private fun hoursLabel(minutes: Int): String {
    if (minutes <= 0) return "0j"
    val h = minutes / 60
    val m = minutes % 60
    return if (h > 0) "${h}j" else "${m}m"
}

private fun shortTime(iso: String?): String {
    if (iso.isNullOrBlank()) return "--:--"
    return runCatching {
        OffsetDateTime.parse(iso).atZoneSameInstant(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("HH:mm"))
    }.getOrElse { "--:--" }
}

private fun weekdayOf(isoDate: String): String = runCatching {
    LocalDate.parse(isoDate)
        .dayOfWeek.getDisplayName(TextStyle.FULL, Locale("id", "ID"))
        .replaceFirstChar { it.uppercase() }
}.getOrElse { isoDate }

private fun dateLongOf(isoDate: String): String = runCatching {
    val date = LocalDate.parse(isoDate)
    val month = date.month.getDisplayName(TextStyle.FULL, Locale("id", "ID"))
    "${date.dayOfMonth} $month ${date.year}"
}.getOrElse { isoDate }
