package com.absensiku.app.face.engine.core

import android.graphics.PointF
import android.graphics.Rect
import com.absensiku.app.face.engine.model.FaceContourType
import com.absensiku.app.face.engine.model.FaceLandmarkType
import com.absensiku.app.face.engine.model.FaceMatchDecision
import com.absensiku.app.face.engine.model.FaceResult
import com.absensiku.app.face.engine.util.FaceShapeDescriptor
import com.absensiku.app.face.engine.util.GeoUtils
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * =====================================================================
 *  FACE MATCHING ENGINE (versi Kotlin)
 * =====================================================================
 *
 * Konversi 1:1 dari `FaceMatchingService` (Flutter). Bagian ini murni
 * ALGORITMA (tanpa Android UI): ekstraksi fitur geometris dari landmark &
 * kontur wajah menjadi *signature* (embedding), lalu skoring kemiripan.
 *
 * Alur:
 *  1. Deteksi wajah (lihat [com.absensiku.app.face.engine.core.MlKitFaceDetector]).
 *  2. [extractSignature] -> JSON v3 `{"v":3,"f":{"nama_fitur":nilai}}`.
 *  3. [similarityScore] -> persentase kemiripan (0-100) dengan penalti
 *     dispersi + outlier.
 *  4. [robustMatch] -> keputusan cocok/tidak berbasis MAYORITAS sample.
 *
 * Seluruh catatan keamanan pada versi Dart (anti false-accept) dipertahankan
 * persis agar hasil identik.
 */
object FaceFeatureExtractor {

    // ---------------------------------------------------------------------
    //  KONSTANTA TOLERANSI (identik dengan Dart)
    // ---------------------------------------------------------------------

    /** Selisih <= nilai ini -> kontribusi penuh (1.0). */
    const val TIGHT_DIFF = 5

    /** Selisih <= nilai ini -> turun linear 1.0 s/d 0.5. */
    const val LOOSE_DIFF = 11

    /** Selisih <= nilai ini -> turun linear 0.5 s/d 0.0. */
    const val REJECT_DIFF = 22

    /** Ambang outlier: selisih > nilai ini dihitung sebagai penyimpangan besar. */
    const val OUTLIER_DIFF_THRESHOLD = 24

    /** Jumlah minimum fitur beririsan agar skor dianggap valid. */
    const val MIN_COMMON_FEATURES = 14

    /** Margin konservatif (persen) di atas ambang dasar. */
    const val CONSERVATIVE_MARGIN_PERCENT = 5

    // ---------------------------------------------------------------------
    //  EKSTRAKSI SIGNATURE
    // ---------------------------------------------------------------------

    /**
     * Mengekstrak signature (embedding) dari wajah hasil deteksi.
     * Mengembalikan JSON v3 atau null jika tidak ada fitur.
     */
    fun extractSignature(face: FaceResult): String? {
        val features = LinkedHashMap<String, Int>()
        features.putAll(extractLandmarkFeatures(face))
        features.putAll(extractContourFeatures(face))
        // Deskriptor bentuk (profil radial kontur wajah) — peningkat diskriminasi.
        features.putAll(FaceShapeDescriptor.radialProfile(face))
        if (features.isEmpty()) return null

        val f = JSONObject()
        for ((k, v) in features) f.put(k, v)
        val root = JSONObject()
        // v4: menambahkan deskriptor bentuk 36-bin di atas fitur geometris v3.
        root.put("v", 4)
        root.put("f", f)
        return root.toString()
    }

    /** Fitur berbasis landmark (rasio jarak antar landmark, skala-independent). */
    fun extractLandmarkFeatures(face: FaceResult): Map<String, Int> {
        val features = LinkedHashMap<String, Int>()
        val lm = face.landmarks

        fun p(t: FaceLandmarkType): PointF? = lm[t]

        val leftEye = p(FaceLandmarkType.LEFT_EYE)
        val rightEye = p(FaceLandmarkType.RIGHT_EYE)
        val nose = p(FaceLandmarkType.NOSE_BASE)
        val mouthL = p(FaceLandmarkType.LEFT_MOUTH)
        val mouthR = p(FaceLandmarkType.RIGHT_MOUTH)
        val bottomMouth = p(FaceLandmarkType.BOTTOM_MOUTH)
        val cheekL = p(FaceLandmarkType.LEFT_CHEEK)
        val cheekR = p(FaceLandmarkType.RIGHT_CHEEK)
        val earL = p(FaceLandmarkType.LEFT_EAR)
        val earR = p(FaceLandmarkType.RIGHT_EAR)

        val eyeDist = GeoUtils.dist(leftEye, rightEye)

        if (eyeDist > 0) {
            if (leftEye != null && nose != null) {
                features["eye_l_nose"] = GeoUtils.bounded(GeoUtils.dist(leftEye, nose) / eyeDist * 150)
            }
            if (rightEye != null && nose != null) {
                features["eye_r_nose"] = GeoUtils.bounded(GeoUtils.dist(rightEye, nose) / eyeDist * 150)
            }
            if (earL != null && earR != null) {
                features["ear_width_ratio"] = GeoUtils.bounded(GeoUtils.dist(earL, earR) / eyeDist * 100)
            }
            if (cheekL != null && cheekR != null) {
                features["cheek_width_ratio"] = GeoUtils.bounded(GeoUtils.dist(cheekL, cheekR) / eyeDist * 100)
            }
            if (leftEye != null && cheekL != null) {
                features["eye_l_cheek_l"] = GeoUtils.bounded(GeoUtils.dist(leftEye, cheekL) / eyeDist * 100)
            }
            if (rightEye != null && cheekR != null) {
                features["eye_r_cheek_r"] = GeoUtils.bounded(GeoUtils.dist(rightEye, cheekR) / eyeDist * 100)
            }
        }

        if (mouthL != null && mouthR != null) {
            val mouthWidth = GeoUtils.dist(mouthL, mouthR)
            if (mouthWidth > 0) {
                if (eyeDist > 0) {
                    features["mouth_width_eye_ratio"] = GeoUtils.bounded(mouthWidth / eyeDist * 100)
                }
                if (nose != null) {
                    val noseToMouthMid = GeoUtils.dist(nose, GeoUtils.midpoint(mouthL, mouthR))
                    if (noseToMouthMid > 0) {
                        features["mouth_width_nose_ratio"] = GeoUtils.bounded(mouthWidth / noseToMouthMid * 100)
                    }
                }
                if (bottomMouth != null) {
                    val mouthHeight = GeoUtils.dist(GeoUtils.midpoint(mouthL, mouthR), bottomMouth)
                    features["mouth_height_width_ratio"] = GeoUtils.bounded(mouthHeight / mouthWidth * 100)
                }
            }
        }

        if (nose != null && bottomMouth != null && mouthL != null && mouthR != null) {
            val mouthWidth = GeoUtils.dist(mouthL, mouthR)
            if (mouthWidth > 0) {
                features["nose_chin_mouth_ratio"] = GeoUtils.bounded(GeoUtils.dist(nose, bottomMouth) / mouthWidth * 100)
            }
        }

        return features
    }

    /** Fitur berbasis kontur wajah (lebih robust terhadap kacamata & rambut). */
    fun extractContourFeatures(face: FaceResult): Map<String, Int> {
        val features = LinkedHashMap<String, Int>()
        val ct = face.contours

        fun pts(t: FaceContourType): List<PointF>? {
            val c = ct[t]
            if (c.isNullOrEmpty()) return null
            return c
        }

        val faceContour = pts(FaceContourType.FACE)
        val noseBridge = pts(FaceContourType.NOSE_BRIDGE)
        val noseBottom = pts(FaceContourType.NOSE_BOTTOM)
        val leftEyeC = pts(FaceContourType.LEFT_EYE)
        val rightEyeC = pts(FaceContourType.RIGHT_EYE)
        val leftBrowTop = pts(FaceContourType.LEFT_EYEBROW_TOP)
        val rightBrowTop = pts(FaceContourType.RIGHT_EYEBROW_TOP)
        val upperLip = pts(FaceContourType.UPPER_LIP_TOP)
        val lowerLip = pts(FaceContourType.LOWER_LIP_BOTTOM)

        if (faceContour == null || faceContour.size < 4) return features

        val faceW = GeoUtils.width(faceContour)
        val faceH = GeoUtils.height(faceContour)
        if (faceW <= 0 || faceH <= 0) return features

        features["face_aspect_ratio"] = GeoUtils.bounded(faceH / faceW * 100)

        if (!noseBridge.isNullOrEmpty()) {
            val noseTop = noseBridge.first()
            features["nose_top_rel"] = GeoUtils.bounded((noseTop.y - GeoUtils.top(faceContour)) / faceH * 100)
        }
        if (!noseBottom.isNullOrEmpty()) {
            val noseBottomY = noseBottom.map { it.y }.max()
            features["nose_bottom_rel"] = GeoUtils.bounded((noseBottomY - GeoUtils.top(faceContour)) / faceH * 100)
            val noseW = GeoUtils.width(noseBottom)
            if (noseW > 0) features["nose_width_rel"] = GeoUtils.bounded(noseW / faceW * 100)
        }
        if (!leftEyeC.isNullOrEmpty()) {
            features["eye_l_width_rel"] = GeoUtils.bounded(GeoUtils.width(leftEyeC) / faceW * 100)
        }
        if (!rightEyeC.isNullOrEmpty()) {
            features["eye_r_width_rel"] = GeoUtils.bounded(GeoUtils.width(rightEyeC) / faceW * 100)
        }
        if (!leftBrowTop.isNullOrEmpty()) {
            val browY = leftBrowTop.map { it.y }.min()
            features["brow_l_rel"] = GeoUtils.bounded((browY - GeoUtils.top(faceContour)) / faceH * 100)
        }
        if (!rightBrowTop.isNullOrEmpty()) {
            val browY = rightBrowTop.map { it.y }.min()
            features["brow_r_rel"] = GeoUtils.bounded((browY - GeoUtils.top(faceContour)) / faceH * 100)
        }
        if (!upperLip.isNullOrEmpty()) {
            features["lip_upper_width_rel"] = GeoUtils.bounded(GeoUtils.width(upperLip) / faceW * 100)
        }
        if (!lowerLip.isNullOrEmpty()) {
            features["lip_lower_width_rel"] = GeoUtils.bounded(GeoUtils.width(lowerLip) / faceW * 100)
        }

        return features
    }
}
