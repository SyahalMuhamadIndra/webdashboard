package com.absensiku.app.face.engine.core

import android.content.Context
import com.absensiku.app.face.engine.model.FaceMatchResult
import com.absensiku.app.face.engine.model.FrameQualityResult
import com.absensiku.app.face.engine.model.LivenessCheckResult
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * =====================================================================
 *  FACE MATCHING SERVICE — Orkestrator utama (versi Kotlin)
 * =====================================================================
 *
 * Konversi dari `FaceMatchingService` (Flutter). Menyatukan:
 *  - Deteksi wajah (delegasi ke [MlKitFaceDetector]).
 *  - Liveness pasif anti-spoofing ([checkLiveness]).
 *  - Kualitas frame untuk auto-capture ([assessFrameQuality]).
 *  - Verifikasi single/multi-sample ([verifyFace], [verifyFaceMultiSample]).
 *
 * Gunakan [reset] untuk melepas resource ML Kit.
 */
class FaceMatchingService(context: Context) {

    private val detector = MlKitFaceDetector(context)

    // =====================================================================
    //  LIVENESS (anti-spoofing, tanpa kedipan)
    // =====================================================================

    /**
     * Memeriksa keliveness pasif: tepat SATU wajah, kedua mata terbuka, dan
     * kepala menghadap frontal (Euler X & Y dalam toleransi).
     */
    suspend fun checkLiveness(
        bitmap: android.graphics.Bitmap,
        rotationDegrees: Int = 0,
        eyeOpenThreshold: Double = 0.4,
        maxEulerAngleDeg: Double = 20.0,
    ): LivenessCheckResult {
        val detection = detector.detect(bitmap, rotationDegrees)
        val face = detection.face
        if (!detection.faceDetected || face == null) {
            return LivenessCheckResult(
                faceDetected = false,
                message = detection.error ?: "Wajah tidak terdeteksi.",
            )
        }

        if (detection.faceCount != 1) {
            return LivenessCheckResult(
                faceDetected = true,
                faceCount = detection.faceCount,
                message = "Pastikan hanya satu wajah yang terlihat di kamera.",
            )
        }

        val leftOpen = face.leftEyeOpenProbability ?: 0.5f
        val rightOpen = face.rightEyeOpenProbability ?: 0.5f
        val eyesOpen = leftOpen >= eyeOpenThreshold && rightOpen >= eyeOpenThreshold

        val eulerX = face.headEulerAngleX
        val eulerY = face.headEulerAngleY
        val eulerZ = face.headEulerAngleZ

        val xOk = abs(eulerX ?: 0f) <= maxEulerAngleDeg
        val yOk = abs(eulerY ?: 0f) <= maxEulerAngleDeg
        val isFrontal = xOk && yOk
        val isLive = eyesOpen && isFrontal

        val message: String = when {
            !eyesOpen -> "Buka kedua mata Anda menghadap kamera."
            !isFrontal -> "Hadapkan wajah lurus ke kamera (bukan menoleh / miring)."
            else -> "Wajah terverifikasi — terdeteksi hidup & frontal."
        }

        return LivenessCheckResult(
            faceDetected = true,
            faceCount = detection.faceCount,
            eyesOpen = eyesOpen,
            isFrontal = isFrontal,
            headAngleX = eulerX,
            headAngleY = eulerY,
            headAngleZ = eulerZ,
            isLive = isLive,
            message = message,
        )
    }

    /**
     * Deteksi wajah sederhana (TANPA liveness). Dipakai alur yang hanya butuh
     * memastikan ada wajah di frame (mis. enrollment tanpa anti-spoofing).
     */
    suspend fun detectFace(
        bitmap: android.graphics.Bitmap,
        rotationDegrees: Int = 0,
    ): com.absensiku.app.face.engine.model.FaceDetectionResult =
        detector.detect(bitmap, rotationDegrees)

    // =====================================================================
    //  KUALITAS FRAME (auto-capture ala GreatDay HR)
    // =====================================================================

    /**
     * Menilai kualitas frame: terdeteksi, lurus/tengah, cukup besar, mata
     * terbuka. Skor kontribusi: posisi 40%, ukuran 30%, mata 20%, detail 10%.
     */
    suspend fun assessFrameQuality(
        bitmap: android.graphics.Bitmap,
        rotationDegrees: Int = 0,
        eyeOpenThreshold: Double = 0.4,
        targetCenterDistance: Double = 0.22,
        minFaceSizeRatio: Double = 0.28,
    ): FrameQualityResult {
        val detection = detector.detect(bitmap, rotationDegrees)
        val face = detection.face
        if (!detection.faceDetected || face == null) {
            return FrameQualityResult(
                faceDetected = false,
                message = "Posisikan wajah Anda di dalam bingkai.",
            )
        }

        val hasLandmarks = face.landmarks.isNotEmpty()
        val hasContours = face.contours.isNotEmpty()

        val imgW = bitmap.width.toDouble()
        val imgH = bitmap.height.toDouble()

        val faceCx = face.boundingBox.exactCenterX().toDouble()
        val faceCy = face.boundingBox.exactCenterY().toDouble()
        val centerDx = abs(faceCx / imgW - 0.5)
        val centerDy = abs(faceCy / imgH - 0.5)
        val centerDist = sqrt(centerDx * centerDx + centerDy * centerDy)

        val wRatio = face.boundingBox.width() / imgW
        val hRatio = face.boundingBox.height() / imgH
        val sizeRatio = max(wRatio, hRatio)

        val centered = centerDist <= targetCenterDistance
        val largeEnough = sizeRatio >= minFaceSizeRatio

        val leftOpen = face.leftEyeOpenProbability ?: 0.5f
        val rightOpen = face.rightEyeOpenProbability ?: 0.5f
        val eyesOpen = leftOpen >= eyeOpenThreshold && rightOpen >= eyeOpenThreshold

        val posScore = (1 - (centerDist / 0.5)).coerceIn(0.0, 1.0) * 45
        val sizeScore = (sizeRatio / 0.6).coerceIn(0.0, 1.0) * 35
        val eyeScore = if (eyesOpen) 12.0 else 6.0
        val detailScore = if (hasLandmarks && hasContours) 8.0 else if (hasLandmarks) 5.0 else 2.0
        val quality = posScore + sizeScore + eyeScore + detailScore

        // Tanpa liveness: "siap ambil" cukup wajah di tengah & cukup besar.
        val capturable = centered && largeEnough

        val message: String = when {
            !centered -> "Posisikan wajah Anda di tengah bingkai."
            !largeEnough -> "Dekatkan wajah Anda ke kamera."
            !eyesOpen -> "Wajah siap! Buka mata Anda agar terlihat jelas."
            else -> "Wajah siap! Tekan tombol untuk mengambil."
        }

        return FrameQualityResult(
            faceDetected = true,
            qualityScore = Math.round(quality).toDouble(),
            eyesOpen = eyesOpen,
            centered = centered,
            largeEnough = largeEnough,
            capturable = capturable,
            message = message,
        )
    }

    // =====================================================================
    //  VERIFIKASI
    // =====================================================================

    /** Verifikasi wajah terhadap sample tunggal yang tersimpan. */
    suspend fun verifyFace(
        bitmap: android.graphics.Bitmap,
        storedSignature: String,
        thresholdPercent: Int,
        rotationDegrees: Int = 0,
    ): FaceMatchResult {
        val detection = detector.detect(bitmap, rotationDegrees)
        val face = detection.face
        if (!detection.faceDetected || face == null) {
            return FaceMatchResult(
                faceDetected = false,
                message = detection.error ?: "Wajah tidak terdeteksi.",
            )
        }

        val signature = FaceFeatureExtractor.extractSignature(face)
            ?: return FaceMatchResult(
                faceDetected = true,
                message = "Kualitas wajah kurang baik. Coba posisikan wajah lebih dekat.",
            )

        val ps = FaceMatcher.pairScore(signature, storedSignature, thresholdPercent)
        val score = ps.unified
        val effThreshold = FaceMatcher.effectiveThreshold(thresholdPercent)
            .coerceAtLeast(FaceMatcher.MATCH_UNIFIED.toInt())
        val match = ps.matched
        val isNearMatch = !match && score >= effThreshold

        val msg = when {
            match -> "Wajah cocok (${score.toInt()}% • bentuk ${ps.intrinsic.toInt()}% / geometri ${ps.geometric.toInt()}%)"
            isNearMatch -> "Wajah hanya agak mirip (${score.toInt()}%) — bentuk/geometri belum identik. Butuh bentuk≥${FaceMatcher.MATCH_INTRINSIC.toInt()}% & geometri≥${FaceMatcher.MATCH_GEOMETRIC.toInt()}%."
            else -> "Wajah tidak cocok (${score.toInt()}%). Dibutuhkan minimal $effThreshold% (bentuk≥${FaceMatcher.MATCH_INTRINSIC.toInt()}% & geometri≥${FaceMatcher.MATCH_GEOMETRIC.toInt()}%)."
        }

        return FaceMatchResult(
            similarityScore = score,
            isMatch = match,
            isNearMatch = isNearMatch,
            faceDetected = true,
            message = msg,
        )
    }

    /** Verifikasi wajah terhadap banyak sample (robust terhadap false-accept). */
    suspend fun verifyFaceMultiSample(
        bitmap: android.graphics.Bitmap,
        storedSignatures: List<String>,
        thresholdPercent: Int,
        rotationDegrees: Int = 0,
    ): FaceMatchResult {
        val detection = detector.detect(bitmap, rotationDegrees)
        val face = detection.face
        if (!detection.faceDetected || face == null) {
            return FaceMatchResult(
                faceDetected = false,
                message = detection.error ?: "Wajah tidak terdeteksi.",
            )
        }

        val signature = FaceFeatureExtractor.extractSignature(face)
            ?: return FaceMatchResult(
                faceDetected = true,
                message = "Kualitas wajah kurang baik. Coba posisikan wajah lebih dekat.",
            )

        val decision = FaceMatcher.robustMatch(signature, storedSignatures, thresholdPercent)
        val score = decision.score
        val match = decision.isMatch
        val isNearMatch = decision.isNearMatch
        val effThreshold = decision.effectiveThreshold

        val msg = when {
            match -> "Wajah cocok (${score.toInt()}%)"
            isNearMatch -> "Wajah hanya agak mirip (${score.toInt()}%) — belum cukup identik. Butuh minimal $effThreshold%."
            else -> "Wajah tidak cocok (${score.toInt()}%). Dibutuhkan minimal $effThreshold%."
        }

        return FaceMatchResult(
            similarityScore = score,
            isMatch = match,
            isNearMatch = isNearMatch,
            faceDetected = true,
            message = msg,
        )
    }

    /**
     * Mengembalikan sudut YAW kepala (derajat) dari wajah pertama, atau null
     * bila tidak ada wajah. Dipakai untuk liveness tantangan (menoleh).
     */
    suspend fun headYaw(bitmap: android.graphics.Bitmap, rotationDegrees: Int = 0): Float? {
        val detection = detector.detect(bitmap, rotationDegrees)
        return detection.face?.headEulerAngleY
    }

    /**
     * Analisis SATU KALI untuk verifikasi: deteksi sekali lalu hitung
     * jumlah wajah, mata terbuka, arah hadap (yaw), dan template sekaligus.
     * Menggantikan 3x pemanggilan deteksi terpisah (jauh lebih cepat).
     */
    data class ProbeResult(
        val faceDetected: Boolean,
        val faceCount: Int,
        val eyesOpen: Boolean,
        val yaw: Float?,
        val template: String?,
        val message: String?,
    )

    suspend fun buildProbe(
        bitmap: android.graphics.Bitmap,
        rotationDegrees: Int = 0,
        eyeOpenThreshold: Double = 0.4,
    ): ProbeResult {
        val det = detector.detect(bitmap, rotationDegrees)
        val face = det.face
        if (!det.faceDetected || face == null) {
            return ProbeResult(false, det.faceCount, false, null, null, det.error ?: "Wajah tidak terdeteksi.")
        }
        val leftOpen = face.leftEyeOpenProbability ?: 0.5f
        val rightOpen = face.rightEyeOpenProbability ?: 0.5f
        val eyesOpen = leftOpen >= eyeOpenThreshold && rightOpen >= eyeOpenThreshold
        val template = com.absensiku.app.face.engine.util.FaceTemplateExtractor.extract(bitmap, face)
        return ProbeResult(
            faceDetected = true,
            faceCount = det.faceCount,
            eyesOpen = eyesOpen,
            yaw = face.headEulerAngleY,
            template = template,
            message = null,
        )
    }

    /** Mengekstrak signature dari satu frame (untuk enrolment). */
    suspend fun captureSignature(
        bitmap: android.graphics.Bitmap,
        rotationDegrees: Int = 0,
    ): String? {
        val detection = detector.detect(bitmap, rotationDegrees)
        val face = detection.face ?: return null
        return FaceFeatureExtractor.extractSignature(face)
    }

    // =====================================================================
    //  VERIFIKASI BERBASIS TEMPLATE TEKSTUR (ala GreatDay HR)
    // =====================================================================

    /**
     * Mengekstrak TEMPLATE TEKSTUR wajah dari frame (eye-aligned, normalized).
     * Ini adalah fitur utama verifikasi — jauh lebih diskriminatif daripada
     * rasio landmark.
     */
    suspend fun captureTemplate(
        bitmap: android.graphics.Bitmap,
        rotationDegrees: Int = 0,
    ): String? {
        val detection = detector.detect(bitmap, rotationDegrees)
        val face = detection.face ?: return null
        return com.absensiku.app.face.engine.util.FaceTemplateExtractor.extract(bitmap, face)
    }

    /**
     * Ekstraksi template dari hasil deteksi yang SUDAH ada — menghindari
     * deteksi ML Kit kedua. Mempercepat alur enrollment/verifikasi.
     */
    fun captureTemplateWithFace(
        bitmap: android.graphics.Bitmap,
        face: com.absensiku.app.face.engine.model.FaceResult,
    ): String? = com.absensiku.app.face.engine.util.FaceTemplateExtractor.extract(bitmap, face)

    /**
     * Verifikasi template terhadap banyak sample tersimpan (mayoritas).
     * Skor = NCC (0..100). Cocok bila MAYORITAS sample melampaui [TPL_MATCH].
     */
    suspend fun verifyTemplateMultiSample(
        bitmap: android.graphics.Bitmap,
        storedTemplates: List<String>,
        threshold: Int = TPL_MATCH,
        rotationDegrees: Int = 0,
    ): FaceMatchResult {
        val detection = detector.detect(bitmap, rotationDegrees)
        val face = detection.face
        if (!detection.faceDetected || face == null) {
            return FaceMatchResult(
                faceDetected = false,
                message = detection.error ?: "Wajah tidak terdeteksi.",
            )
        }
        val probe = com.absensiku.app.face.engine.util.FaceTemplateExtractor.extract(bitmap, face)
            ?: return FaceMatchResult(
                faceDetected = true,
                message = "Template wajah gagal dibentuk. Posisikan wajah lebih jelas & dekat.",
            )

        val scores = storedTemplates.map {
            com.absensiku.app.face.engine.util.FaceTemplateMatcher.matchScore(probe, it)
        }
        val valid = scores.filter { it >= 0.0 }
        if (valid.isEmpty()) {
            return FaceMatchResult(
                faceDetected = true,
                message = "Data wajah tersimpan tidak valid. Rekam ulang wajah.",
            )
        }
        val required = if (valid.size == 1) 1 else Math.ceil(valid.size / 2.0).toInt()
        val matchCount = valid.count { it >= threshold }
        val sorted = valid.sortedDescending()
        val representative = sorted.take(required).sum() / required

        val match = matchCount >= required
        val nearMatch = !match && sorted.firstOrNull()?.let { it >= TPL_NEAR } == true

        val msg = when {
            match -> "Wajah cocok (${representative.toInt()}%)"
            nearMatch -> "Wajah hanya agak mirip (${representative.toInt()}%) — belum identik. Butuh minimal $threshold%."
            else -> "Wajah tidak cocok (${representative.toInt()}%). Dibutuhkan minimal $threshold%."
        }
        return FaceMatchResult(
            similarityScore = representative,
            isMatch = match,
            isNearMatch = nearMatch,
            faceDetected = true,
            message = msg,
        )
    }

    companion object {
        /**
         * Ambang NCC untuk dianggap cocok (%).
         *
         * v0.9.9 "ANTI-SPOOF LONGGAR": diturunkan dari 72 -> 40. Tujuan verifikasi
         * bukan lagi mencocokkan identitas secara ketat, melainkan memastikan
         * wajah yang difoto MASIH mirip dengan sample terdaftar (anti-spoof),
         * sehingga absensi jauh lebih mudah lolos.
         */
        const val TPL_MATCH = 40
        /** Ambang NCC untuk "hampir mirip" (peringatan lembut). */
        const val TPL_NEAR = 28
    }

    fun reset() {
        detector.close()
    }
}
