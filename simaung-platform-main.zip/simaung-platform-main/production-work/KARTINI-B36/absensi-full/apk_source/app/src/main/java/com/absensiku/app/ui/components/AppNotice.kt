package com.absensiku.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.delay

/**
 * Jenis notifikasi aplikasi (tema warna + ikon).
 */
enum class NoticeKind { SUCCESS, ERROR, WARNING, INFO }

/**
 * Data notifikasi yang aman disimpan di state Compose.
 */
data class AppNotice(
    val id: Long = System.nanoTime(),
    val kind: NoticeKind,
    val title: String,
    val message: String? = null,
)

/** Warna aksen + ikon sesuai jenis notifikasi. */
private data class NoticeStyle(val accent: Color, val icon: ImageVector)

private fun styleFor(kind: NoticeKind): NoticeStyle = when (kind) {
    NoticeKind.SUCCESS -> NoticeStyle(KartiniColors.StatusOkFg, Icons.Filled.CheckCircle)
    NoticeKind.ERROR -> NoticeStyle(KartiniColors.StatusBadFg, Icons.Filled.ErrorOutline)
    NoticeKind.WARNING -> NoticeStyle(KartiniColors.StatusWarnFg, Icons.Filled.WarningAmber)
    NoticeKind.INFO -> NoticeStyle(KartiniColors.StatusInfoFg, Icons.Filled.Info)
}

/**
 * Banner notifikasi profesional (menggantikan snackbar polos).
 * Muncul di atas dengan animasi, ikon status, judul tebal, pesan pendukung,
 * dan bisa ditutup. Auto-hilang setelah [autoDismissMillis].
 */
@Composable
fun AppNoticeHost(
    notice: AppNotice?,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    autoDismissMillis: Long = 4200L,
) {
    AnimatedVisibility(
        visible = notice != null,
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        modifier = modifier,
    ) {
        val n = notice ?: return@AnimatedVisibility
        LaunchedEffect(n.id) {
            delay(autoDismissMillis)
            onDismiss()
        }
        val style = styleFor(n.kind)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(KartiniColors.CreamSurface)
                .border(1.dp, style.accent.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                .padding(start = 6.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(style.accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(style.icon, contentDescription = null, tint = style.accent, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    n.title,
                    color = KartiniColors.OnSurface,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                )
                if (!n.message.isNullOrBlank()) {
                    Spacer(Modifier.size(2.dp))
                    Text(
                        n.message,
                        color = KartiniColors.OnSurfaceMuted,
                        fontSize = 12.5.sp,
                        lineHeight = 17.sp,
                    )
                }
            }
            IconButton(onClick = onDismiss) {
                Icon(Icons.Filled.Close, contentDescription = "Tutup", tint = KartiniColors.OnSurfaceMuted, modifier = Modifier.size(18.dp))
            }
        }
    }
}
