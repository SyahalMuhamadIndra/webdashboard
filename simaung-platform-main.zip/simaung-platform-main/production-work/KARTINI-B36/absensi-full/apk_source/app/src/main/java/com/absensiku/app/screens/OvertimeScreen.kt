package com.absensiku.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.R
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.OvertimeItem
import com.absensiku.app.ui.components.BrandTopBar
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Pengajuan & riwayat lembur — tampilan profesional (ringkasan + kartu beraksen). */
@Composable
fun OvertimeScreen(
    api: ApiClient,
    showMessage: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<OvertimeItem>>(emptyList()) }
    var busy by remember { mutableStateOf(true) }
    var showDialog by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch {
            busy = true
            try {
                items = api.listOvertimes()
            } catch (e: kotlinx.coroutines.CancellationException) {

                throw e

            } catch (e: Exception) {
                showMessage(e.message ?: "Gagal memuat")
            }
            busy = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    val pending = items.count { it.status != "APPROVED" && it.status != "REJECTED" }
    val approvedMinutes = items.filter { it.status == "APPROVED" }.sumOf { it.durationMinutes }

    Box(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        Column(modifier = Modifier.fillMaxSize()) {
            BrandTopBar(title = "Lembur", subtitle = "Pengajuan & riwayat lembur")
            if (busy) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = KartiniColors.BrandGreen,
                    trackColor = KartiniColors.BrandGreenSoft,
                )
            }
            if (!busy && items.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.Center,
                ) {
                    OvertimeEmptyCard()
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 84.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    item { OvertimeSummary(pending, approvedMinutes, items.size) }
                    item { Spacer(Modifier.height(2.dp)) }
                    item { OvertimeSectionTitle("Riwayat Pengajuan") }
                    item { Spacer(Modifier.height(2.dp)) }
                    items(items, key = { it.id }) { OvertimeCard(it) }
                }
            }
        }
        FloatingActionButton(
            onClick = { showDialog = true },
            containerColor = KartiniColors.BrandGreen,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
        ) { Icon(Icons.Filled.Add, contentDescription = "Ajukan lembur") }
    }

    if (showDialog) {
        OvertimeDialog(
            onDismiss = { showDialog = false },
            onSubmit = { date, start, end, reason ->
                scope.launch {
                    try {
                        val minutes = api.createOvertime(date, start, end, reason)
                        showDialog = false
                        showMessage("Pengajuan lembur terkirim • $minutes menit")
                        refresh()
                    } catch (e: kotlinx.coroutines.CancellationException) {

                        throw e

                    } catch (e: Exception) {
                        showMessage(e.message ?: "Gagal mengirim")
                    }
                }
            },
        )
    }
}

/* ---------------- Ringkasan ---------------- */

@Composable
private fun OvertimeSummary(pending: Int, approvedMinutes: Int, total: Int) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OvertimeStat("Total", "$total", KartiniColors.BrandGreenDeep, Modifier.weight(1f))
        OvertimeStat("Menunggu", "$pending", KartiniColors.BrandOrangeDeep, Modifier.weight(1f))
        OvertimeStat("Jam Disetujui", jamLabel(approvedMinutes), KartiniColors.BrandGreen, Modifier.weight(1f))
    }
}

@Composable
private fun OvertimeStat(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = KartiniColors.CreamSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, color = KartiniColors.OnSurfaceMuted, fontSize = 10.5.sp, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
        }
    }
}

@Composable
private fun OvertimeSectionTitle(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier.size(width = 4.dp, height = 18.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(KartiniColors.BrandGreen),
        )
        Spacer(Modifier.width(8.dp))
        Text(text, color = KartiniColors.OnSurface, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/* ---------------- Kartu lembur ---------------- */

@Composable
private fun OvertimeCard(item: OvertimeItem) {
    val accent = when (item.status) {
        "APPROVED" -> KartiniColors.BrandGreen
        "REJECTED" -> KartiniColors.StatusBadFg
        else -> KartiniColors.BrandOrange
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            Box(modifier = Modifier.width(5.dp).fillMaxHeight().background(accent))
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Badge durasi
                    Box(
                        modifier = Modifier.size(48.dp).clip(RoundedCornerShape(13.dp))
                            .background(KartiniColors.BrandGreenSoft),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            val total = item.durationMinutes
                            val txt = if (total >= 60) {
                                val h = total / 60
                                val m = total % 60
                                if (m == 0) "${h}j" else "${h}j${m}"
                            } else "$total"
                            Text(txt, color = KartiniColors.BrandGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(if (total >= 60) "jam" else "menit", color = KartiniColors.OnSurfaceMuted, fontSize = 9.sp)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            dateLabel(item.date),
                            color = KartiniColors.OnSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "${item.startTime.take(5)} → ${item.endTime.take(5)}",
                            color = KartiniColors.OnSurfaceMuted,
                            fontSize = 12.sp,
                        )
                    }
                    OvertimeStatusChip(item.status)
                }

                if (!item.reason.isNullOrBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painter = painterResource(R.drawable.ic_tab_lembur),
                            contentDescription = null,
                            tint = KartiniColors.Olive,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(Modifier.width(7.dp))
                        Text(item.reason, color = KartiniColors.OnSurfaceMuted, fontSize = 11.5.sp, maxLines = 2)
                    }
                }
            }
        }
    }
}

@Composable
private fun OvertimeStatusChip(status: String) {
    val fg: Color
    val bg: Color
    val label: String
    when (status) {
        "APPROVED" -> { fg = KartiniColors.StatusOkFg; bg = KartiniColors.StatusOkBg; label = "Disetujui" }
        "REJECTED" -> { fg = KartiniColors.StatusBadFg; bg = KartiniColors.StatusBadBg; label = "Ditolak" }
        else -> { fg = KartiniColors.StatusWarnFg; bg = KartiniColors.StatusWarnBg; label = "Menunggu" }
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun OvertimeEmptyCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = KartiniColors.CreamSurface),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier.size(52.dp).clip(CircleShape).background(KartiniColors.BrandGreenSoft),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_tab_lembur),
                    contentDescription = null,
                    tint = KartiniColors.BrandGreen,
                    modifier = Modifier.size(26.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            Text("Belum ada pengajuan lembur", color = KartiniColors.OnSurface, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(
                "Tekan tombol + untuk mengajukan lembur.",
                color = KartiniColors.OnSurfaceMuted, fontSize = 12.sp, textAlign = TextAlign.Center,
            )
        }
    }
}

/* ---------------- Dialog pengajuan (tidak berubah) ---------------- */

@Composable
private fun OvertimeDialog(
    onDismiss: () -> Unit,
    onSubmit: (date: String, start: String, end: String, reason: String?) -> Unit,
) {
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var start by remember { mutableStateOf("18:00") }
    var end by remember { mutableStateOf("20:00") }
    var reason by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onSubmit(date, start, end, reason.ifBlank { null }) }) {
                Text("Kirim", color = KartiniColors.BrandGreen, fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Ajukan Lembur", color = KartiniColors.OnSurface, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = date, onValueChange = { date = it },
                    label = { Text("Tanggal (YYYY-MM-DD)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = start, onValueChange = { start = it }, label = { Text("Mulai") }, singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                    OutlinedTextField(value = end, onValueChange = { end = it }, label = { Text("Selesai") }, singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                }
                OutlinedTextField(
                    value = reason, onValueChange = { reason = it },
                    label = { Text("Keperluan (opsional)") },
                    modifier = Modifier.fillMaxWidth(), minLines = 2, shape = RoundedCornerShape(12.dp),
                )
            }
        },
        shape = RoundedCornerShape(18.dp),
        containerColor = Color.White,
    )
}

/* ---------------- Helper ---------------- */

private fun jamLabel(minutes: Int): String {
    if (minutes <= 0) return "0j"
    val h = minutes / 60
    val m = minutes % 60
    return if (h == 0) "${m}m" else if (m == 0) "${h}j" else "${h}j ${m}m"
}

private fun dateLabel(iso: String): String = runCatching {
    LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale("id", "ID")))
}.getOrElse { iso }
