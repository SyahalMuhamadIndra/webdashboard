package com.absensiku.app.screens.ops

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.api.ApiClient
import com.absensiku.app.api.MeResponse
import com.absensiku.app.api.OpnameDraftInput
import com.absensiku.app.api.OpnameItem
import com.absensiku.app.api.OpnameLog
import com.absensiku.app.api.OpnameLogRow
import com.absensiku.app.api.OpnameSession
import com.absensiku.app.api.OpsProduct
import com.absensiku.app.ui.components.OpsBadge
import com.absensiku.app.ui.components.OpsCard
import com.absensiku.app.ui.components.OpsEmpty
import com.absensiku.app.ui.components.OpsGhostButton
import com.absensiku.app.ui.components.OpsKeyValue
import com.absensiku.app.ui.components.OpsPrimaryButton
import com.absensiku.app.ui.components.OpsSectionTitle
import com.absensiku.app.ui.components.OpsStatCard
import com.absensiku.app.ui.components.OpsTextField
import com.absensiku.app.ui.components.OpsTopBar
import com.absensiku.app.ui.theme.KartiniColors
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Stock Opname (B11 / B35) — modern & fungsional:
 *  - Tab "Opname" : catat mutasi barang (Masuk / Keluar / Rusak) & ajukan sesi opname.
 *  - Tab "Rekap"  : rekap mutasi harian (flat) ala Allstock + total.
 *  - PRAMUNIAGA   : hitung stok per area (hasil dikirim untuk di-crosscek).
 *  - KEPALA_GUDANG: opname FULL + crosscek (Setujui / Tolak) hasil pramuniaga + hapus.
 */
@Composable
fun OpnameScreen(
    api: ApiClient,
    me: MeResponse,
    showMessage: (String) -> Unit,
    onBack: () -> Unit,
) {
    val isKepala = me.hasRole("KEPALA_GUDANG")
    val isPramuniaga = me.hasRole("PRAMUNIAGA")

    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Opname", "Rekap")

    Box(modifier = Modifier.fillMaxSize().background(KartiniColors.CreamBg)) {
        Column(modifier = Modifier.fillMaxSize()) {
            OpsTopBar(
                title = if (isKepala) "Stock Opname & Crosscek" else "Stock Opname",
                subtitle = if (isKepala) "Opname full, mutasi stok & verifikasi pramuniaga"
                else "Hitung stok fisik, catat masuk / keluar / rusak",
                onBack = onBack,
            )
            TabRow(
                selectedTabIndex = tab,
                containerColor = KartiniColors.CreamSurface,
                contentColor = KartiniColors.BrandGreen,
                indicator = { positions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(positions[tab]),
                        color = KartiniColors.BrandGreen,
                    )
                },
                divider = {},
            ) {
                tabs.forEachIndexed { i, title ->
                    Tab(
                        selected = tab == i,
                        onClick = { tab = i },
                        text = {
                            Text(
                                title,
                                fontSize = 13.5.sp,
                                fontWeight = if (tab == i) FontWeight.ExtraBold else FontWeight.SemiBold,
                            )
                        },
                    )
                }
            }

            if (tab == 0) {
                OpnameEntryTab(api = api, isKepala = isKepala, isPramuniaga = isPramuniaga, showMessage = showMessage)
            } else {
                OpnameRekapTab(api = api, showMessage = showMessage)
            }
        }
    }
}

// =====================================================================
//  TAB 1 — OPNAME (input mutasi + riwayat/crosscek)
// =====================================================================

@Composable
private fun OpnameEntryTab(
    api: ApiClient,
    isKepala: Boolean,
    @Suppress("UNUSED_PARAMETER") isPramuniaga: Boolean,
    showMessage: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(true) }
    var sessions by remember { mutableStateOf<List<OpnameSession>>(emptyList()) }
    var showForm by remember { mutableStateOf(false) }

    fun load() {
        scope.launch {
            busy = true
            try {
                sessions = api.listOpnames(mine = !isKepala)
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { showMessage(e.message ?: "Gagal memuat opname") }
            busy = false
        }
    }
    LaunchedEffect(Unit) { load() }

    if (showForm) {
        OpnameForm(
            api = api,
            isKepala = isKepala,
            showMessage = showMessage,
            onDone = { showForm = false; load() },
            onCancel = { showForm = false },
        )
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        // Ringkasan peran
        OpsCard {
            Text(
                if (isKepala) "Mode Kepala Gudang" else "Mode Pramuniaga",
                fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = KartiniColors.OnSurface,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (isKepala)
                    "Lakukan opname FULL seluruh gudang, catat barang masuk / keluar / rusak, lalu crosscek sesi dari pramuniaga."
                else "Hitung stok fisik area Anda dan catat barang masuk / keluar / rusak. Hasil dikirim untuk di-crosscek Kepala Gudang.",
                fontSize = 12.5.sp, color = KartiniColors.OnSurfaceMuted,
            )
        }
        Spacer(Modifier.height(14.dp))
        OpsPrimaryButton(
            text = if (isKepala) "Mulai Opname Full" else "Mulai Stock Opname",
            onClick = { showForm = true },
        )
        Spacer(Modifier.height(18.dp))
        OpsSectionTitle(if (isKepala) "Riwayat & Crosscek (${sessions.size})" else "Riwayat Opname Saya (${sessions.size})")
        Spacer(Modifier.height(12.dp))
        if (busy) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp), color = KartiniColors.BrandGreen)
        } else if (sessions.isEmpty()) {
            OpsEmpty("Belum ada sesi opname.")
        } else {
            sessions.forEach { s ->
                OpnameRow(
                    api = api,
                    s = s,
                    isKepala = isKepala,
                    showMessage = showMessage,
                    onChanged = { load() },
                )
                Spacer(Modifier.height(10.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

private data class QDraft(
    val productId: String,
    val name: String,
    val sku: String?,
    val unit: String?,
    val stock: Int,
    val qtyIn: Int,
    val qtyOut: Int,
    val qtyReject: Int,
    val note: String,
)

@Composable
private fun OpnameForm(
    api: ApiClient,
    isKepala: Boolean,
    showMessage: (String) -> Unit,
    onDone: () -> Unit,
    onCancel: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(true) }
    var products by remember { mutableStateOf<List<OpsProduct>>(emptyList()) }
    var area by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }

    val inMap = remember { mutableStateMapOf<String, String>() }
    val outMap = remember { mutableStateMapOf<String, String>() }
    val rejMap = remember { mutableStateMapOf<String, String>() }
    val noteMap = remember { mutableStateMapOf<String, String>() }

    LaunchedEffect(Unit) {
        try {
            products = api.listProducts()
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { showMessage(e.message ?: "Gagal memuat barang") }
        busy = false
    }

    fun draftOf(p: OpsProduct): QDraft {
        val qi = inMap[p.id]?.toIntOrNull() ?: 0
        val qo = outMap[p.id]?.toIntOrNull() ?: 0
        val qr = rejMap[p.id]?.toIntOrNull() ?: 0
        return QDraft(p.id, p.name, p.sku, p.unit, p.stock, qi, qo, qr, noteMap[p.id] ?: "")
    }

    val filtered = if (query.isBlank()) products
    else products.filter {
        it.name.contains(query, true) || (it.sku?.contains(query, true) == true)
    }
    val draftCount = products.count { p ->
        val d = draftOf(p); d.qtyIn + d.qtyOut + d.qtyReject > 0
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        OpsSectionTitle(if (isKepala) "Form Opname Full" else "Form Stock Opname")
        Spacer(Modifier.height(12.dp))

        OpsCard {
            Text(
                "Cara isi: masukkan jumlah barang MASUK / KELUAR / RUSAK. Stok fisik dihitung otomatis (Stok Sistem + Masuk − Keluar − Rusak) dan langsung diterapkan ke stok master saat disimpan.",
                fontSize = 12.sp, color = KartiniColors.OnSurfaceMuted,
            )
        }
        Spacer(Modifier.height(12.dp))

        OpsTextField(area, { area = it }, if (isKepala) "Area / keterangan (opsional)" else "Area rak (mis. Rak Sembako)")
        Spacer(Modifier.height(10.dp))
        OpsTextField(note, { note = it }, "Catatan sesi (opsional)")
        Spacer(Modifier.height(14.dp))

        // Panel ringkas
        Surface(
            color = KartiniColors.BrandGreenSoft,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Barang dengan mutasi", fontSize = 12.sp, color = KartiniColors.StatusOkFg)
                    Text("$draftCount barang siap dikirim", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = KartiniColors.OnSurface)
                }
                Text(
                    if (isKepala) "FULL" else "AREA",
                    fontSize = 11.sp, fontWeight = FontWeight.Bold, color = KartiniColors.StatusOkFg,
                )
            }
        }
        Spacer(Modifier.height(16.dp))

        OpsSectionTitle("Daftar Barang (${products.size})")
        Spacer(Modifier.height(10.dp))
        OpsTextField(query, { query = it }, "Cari barang / SKU…")
        Spacer(Modifier.height(12.dp))

        if (busy) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp), color = KartiniColors.BrandGreen)
        } else if (products.isEmpty()) {
            OpsEmpty("Belum ada barang. Minta admin menambahkan master barang.")
        } else if (filtered.isEmpty()) {
            OpsEmpty("Barang tidak ditemukan.")
        } else {
            filtered.forEach { p ->
                OpnameProductCard(
                    product = p,
                    qtyIn = inMap[p.id] ?: "",
                    qtyOut = outMap[p.id] ?: "",
                    qtyReject = rejMap[p.id] ?: "",
                    note = noteMap[p.id] ?: "",
                    onIn = { inMap[p.id] = it.filter { c -> c.isDigit() } },
                    onOut = { outMap[p.id] = it.filter { c -> c.isDigit() } },
                    onReject = { rejMap[p.id] = it.filter { c -> c.isDigit() } },
                    onNote = { noteMap[p.id] = it },
                )
                Spacer(Modifier.height(10.dp))
            }
        }

        Spacer(Modifier.height(8.dp))
        fun submit() {
            val items = products.mapNotNull { p ->
                val d = draftOf(p)
                if (d.qtyIn + d.qtyOut + d.qtyReject <= 0) null
                else OpnameDraftInput(
                    productId = d.productId, productName = d.name,
                    qtyIn = d.qtyIn, qtyOut = d.qtyOut, qtyReject = d.qtyReject,
                    useCounted = false, note = d.note,
                )
            }
            if (items.isEmpty()) { showMessage("Isi minimal satu mutasi barang"); return }
            saving = true
            scope.launch {
                try {
                    api.submitOpname(area.ifBlank { null }, note.ifBlank { null }, items, kindFull = isKepala)
                    showMessage("Opname tersimpan")
                    onDone()
                } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                catch (e: Exception) { showMessage(e.message ?: "Gagal menyimpan") }
                saving = false
            }
        }
        OpsPrimaryButton(
            text = if (saving) "Menyimpan…" else "Simpan Opname ($draftCount)",
            enabled = !saving && draftCount > 0,
            onClick = { submit() },
        )
        Spacer(Modifier.height(10.dp))
        OpsGhostButton(text = "Batal", onClick = onCancel, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun OpnameProductCard(
    product: OpsProduct,
    qtyIn: String,
    qtyOut: String,
    qtyReject: String,
    note: String,
    onIn: (String) -> Unit,
    onOut: (String) -> Unit,
    onReject: (String) -> Unit,
    onNote: (String) -> Unit,
) {
    val qi = qtyIn.toIntOrNull() ?: 0
    val qo = qtyOut.toIntOrNull() ?: 0
    val qr = qtyReject.toIntOrNull() ?: 0
    val hasMutation = qi + qo + qr > 0
    val physical = product.stock + qi - qo - qr

    OpsCard {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text(product.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = KartiniColors.OnSurface)
                Text(
                    "Sistem: ${product.stock} ${product.unit ?: ""}" + (if (product.sku != null) " • ${product.sku}" else ""),
                    fontSize = 11.5.sp, color = KartiniColors.OnSurfaceMuted,
                )
            }
            if (hasMutation) {
                Surface(color = KartiniColors.BrandGreenSoft, shape = RoundedCornerShape(20.dp)) {
                    Text(
                        "Fisik $physical",
                        fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        color = KartiniColors.StatusOkFg,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.weight(1f)) {
                OpsTextField(qtyIn, onIn, "➕ Masuk", keyboardType = KeyboardType.Number)
            }
            Box(modifier = Modifier.weight(1f)) {
                OpsTextField(qtyOut, onOut, "➖ Keluar", keyboardType = KeyboardType.Number)
            }
            Box(modifier = Modifier.weight(1f)) {
                OpsTextField(qtyReject, onReject, "⚠ Rusak", keyboardType = KeyboardType.Number)
            }
        }
        if (hasMutation) {
            Spacer(Modifier.height(10.dp))
            OpsTextField(note, onNote, "Catatan barang (opsional)")
        }
    }
}

@Composable
private fun OpnameRow(
    api: ApiClient,
    s: OpnameSession,
    isKepala: Boolean,
    showMessage: (String) -> Unit,
    onChanged: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var expanded by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<List<OpnameItem>?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val canReview = isKepala && s.status.equals("SUBMITTED", true)

    OpsCard {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    s.employeeName ?: "Petugas",
                    fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = KartiniColors.OnSurface,
                )
                Text(
                    (if (s.kind == "KEPALA_GUDANG") "Opname Full" else "Pramuniaga") + " • " + (s.area ?: "Semua area"),
                    fontSize = 12.sp, color = KartiniColors.OnSurfaceMuted,
                )
                if (!s.createdAt.isNullOrBlank()) {
                    Text(s.createdAt.take(16).replace("T", " "), fontSize = 11.sp, color = KartiniColors.OnSurfaceMuted)
                }
            }
            OpsBadge(s.status)
        }
        Spacer(Modifier.height(10.dp))
        OpsKeyValue("Jumlah item", "${s.totalItems}")
        OpsKeyValue("Total selisih", if (s.totalDiff == 0) "Pas" else "${s.totalDiff}")
        if (!s.reviewedBy.isNullOrBlank()) OpsKeyValue("Crosscek oleh", s.reviewedBy)
        if (!s.reviewNote.isNullOrBlank()) OpsKeyValue("Catatan crosscek", s.reviewNote)

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.weight(1f)) {
                OpsGhostButton(
                    text = if (expanded) "Tutup Detail" else "Detail",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        expanded = !expanded
                        if (expanded && detail == null) {
                            scope.launch {
                                try { detail = api.getOpnameDetail(s.id).second }
                                catch (e: kotlinx.coroutines.CancellationException) { throw e }
                                catch (e: Exception) { showMessage(e.message ?: "Gagal memuat detail") }
                            }
                        }
                    },
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                fun doDelete() {
                    if (!confirmDelete) { confirmDelete = true; return }
                    scope.launch {
                        try {
                            api.deleteOpname(s.id)
                            showMessage("Sesi opname dihapus")
                            onChanged()
                        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                        catch (e: Exception) { showMessage(e.message ?: "Gagal menghapus") }
                    }
                }
                OpsGhostButton(
                    text = if (confirmDelete) "Yakin hapus?" else "Hapus",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { doDelete() },
                )
            }
        }

        if (expanded) {
            Spacer(Modifier.height(10.dp))
            val rows = detail
            if (rows == null) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp), color = KartiniColors.BrandGreen)
            } else if (rows.isEmpty()) {
                OpsEmpty("Tidak ada item.")
            } else {
                rows.forEach { it ->
                    Surface(
                        color = KartiniColors.CreamBg,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(it.productName, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = KartiniColors.OnSurface)
                            Text(
                                "Sistem ${it.systemStock} → Fisik ${it.countedStock}" +
                                    (if (it.diff == 0) " • Pas" else " • Selisih ${it.diff}"),
                                fontSize = 11.sp, color = KartiniColors.OnSurfaceMuted,
                            )
                            if (it.qtyIn + it.qtyOut + it.qtyReject > 0) {
                                Text(
                                    buildString {
                                        if (it.qtyIn > 0) append("+${it.qtyIn} masuk  ")
                                        if (it.qtyOut > 0) append("−${it.qtyOut} keluar  ")
                                        if (it.qtyReject > 0) append("${it.qtyReject} rusak")
                                    }.trim(),
                                    fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = KartiniColors.BrandOrangeDeep,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (canReview) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OpsPrimaryButton(
                    text = "Setujui",
                    onClick = {
                        scope.launch {
                            try {
                                api.reviewOpname(s.id, "APPROVED", null)
                                showMessage("Opname disetujui")
                                onChanged()
                            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                            catch (e: Exception) { showMessage(e.message ?: "Gagal crosscek") }
                        }
                    },
                    modifier = Modifier.weight(1f),
                )
                OpsGhostButton(
                    text = "Tolak",
                    onClick = {
                        scope.launch {
                            try {
                                api.reviewOpname(s.id, "REJECTED", null)
                                showMessage("Opname ditolak")
                                onChanged()
                            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                            catch (e: Exception) { showMessage(e.message ?: "Gagal crosscek") }
                        }
                    },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

// =====================================================================
//  TAB 2 — REKAP MUTASI HARIAN (ala Allstock)
// =====================================================================

@Composable
private fun OpnameRekapTab(api: ApiClient, showMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var date by remember { mutableStateOf(todayIso()) }
    var mine by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(true) }
    var log by remember { mutableStateOf<OpnameLog?>(null) }

    fun load() {
        scope.launch {
            busy = true
            try { log = api.getOpnameLog(date = date, mine = mine) }
            catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { showMessage(e.message ?: "Gagal memuat rekap") }
            busy = false
        }
    }
    LaunchedEffect(date, mine) { load() }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        OpsSectionTitle("Rekap Mutasi Harian")
        Spacer(Modifier.height(12.dp))

        // Navigasi tanggal
        OpsCard {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                DateNavButton("◀") { date = shiftIso(date, -1) }
                Column(
                    modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(humanDate(date), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = KartiniColors.OnSurface)
                    Text(
                        if (mine) "Hanya sesi saya" else "Semua petugas",
                        fontSize = 11.sp, color = KartiniColors.OnSurfaceMuted,
                    )
                }
                DateNavButton("▶") { date = shiftIso(date, 1) }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.weight(1f)) {
                    OpsGhostButton(text = "Hari ini", onClick = { date = todayIso() }, modifier = Modifier.fillMaxWidth())
                }
                Box(modifier = Modifier.weight(1f)) {
                    OpsGhostButton(
                        text = if (mine) "Semua petugas" else "Saya saja",
                        onClick = { mine = !mine },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
        Spacer(Modifier.height(14.dp))

        val l = log
        if (busy && l == null) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp), color = KartiniColors.BrandGreen)
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OpsStatCard(
                    label = "Masuk",
                    value = "+${l?.totalIn ?: 0}",
                    accent = KartiniColors.BrandGreen,
                    modifier = Modifier.weight(1f),
                )
                OpsStatCard(
                    label = "Keluar",
                    value = "−${l?.totalOut ?: 0}",
                    accent = KartiniColors.BrandOrange,
                    modifier = Modifier.weight(1f),
                )
                OpsStatCard(
                    label = "Rusak",
                    value = "${l?.totalReject ?: 0}",
                    accent = Color(0xFFB0322E),
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(16.dp))
            OpsSectionTitle("Rincian (${l?.items?.size ?: 0} baris)")
            Spacer(Modifier.height(10.dp))
            if (l == null || l.items.isEmpty()) {
                OpsEmpty("Tidak ada mutasi pada tanggal ini.")
            } else {
                l.items.forEach { row ->
                    OpnameLogCard(row)
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun DateNavButton(text: String, onClick: () -> Unit) {
    Surface(
        color = KartiniColors.StatusInfoBg,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.size(38.dp).clickable { onClick() },
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = KartiniColors.StatusInfoFg)
        }
    }
}

@Composable
private fun OpnameLogCard(row: OpnameLogRow) {
    OpsCard {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text(row.productName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = KartiniColors.OnSurface)
                Text(
                    (row.employeeName ?: "Petugas") + (if (!row.area.isNullOrBlank()) " • ${row.area}" else ""),
                    fontSize = 11.5.sp, color = KartiniColors.OnSurfaceMuted,
                )
            }
            if (row.status.isNotBlank()) OpsBadge(row.status)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val statements = buildList {
                if (row.qtyIn > 0) add("+${row.qtyIn} masuk" to KartiniColors.StatusOkFg)
                if (row.qtyOut > 0) add("−${row.qtyOut} keluar" to KartiniColors.BrandOrangeDeep)
                if (row.qtyReject > 0) add("${row.qtyReject} rusak" to Color(0xFFB0322E))
            }
            if (statements.isEmpty()) {
                Text("Tanpa mutasi", fontSize = 11.5.sp, color = KartiniColors.OnSurfaceMuted)
            } else {
                statements.forEach { (label, color) ->
                    Surface(color = KartiniColors.CreamBg, shape = RoundedCornerShape(20.dp)) {
                        Text(
                            label, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = color,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                    }
                }
            }
        }
    }
}

// =====================================================================
//  Util tanggal
// =====================================================================

private fun todayIso(): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

private fun shiftIso(iso: String, days: Int): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return try {
        val d = sdf.parse(iso) ?: Date()
        val c = Calendar.getInstance().apply { time = d; add(Calendar.DAY_OF_MONTH, days) }
        sdf.format(c.time)
    } catch (e: Exception) { iso }
}

private fun humanDate(iso: String): String {
    val inF = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val outF = SimpleDateFormat("EEE, d MMM yyyy", Locale("id", "ID"))
    return try {
        val d = inF.parse(iso)
        if (d != null) outF.format(d) else iso
    } catch (e: Exception) { iso }
}
