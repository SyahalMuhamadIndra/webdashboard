package com.absensiku.app.face.engine.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.Rect
import com.absensiku.app.face.engine.model.FaceContourType
import com.absensiku.app.face.engine.model.FaceDetectionResult
import com.absensiku.app.face.engine.model.FaceLandmarkType
import com.absensiku.app.face.engine.model.FaceResult
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Pembungkus Google ML Kit Face Detection (setara `FaceDetector` di Flutter).
 *
 * Mengonfigurasi detektor dengan kontur/landmark/klasifikasi aktif, mode
 * akurat, dan ukuran wajah minimum 0.12 — persis seperti versi Dart.
 */
class MlKitFaceDetector(context: Context) {

    private val detector: FaceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setMinFaceSize(0.12f)
            .build()
    )

    /** Mendeteksi wajah dari bitmap. Mengembalikan wajah pertama (jika ada). */
    suspend fun detect(bitmap: Bitmap, rotationDegrees: Int = 0): FaceDetectionResult {
        return try {
            val image = InputImage.fromBitmap(bitmap, rotationDegrees)
            val faces = processImage(image)
            if (faces.isEmpty()) {
                FaceDetectionResult(
                    faceDetected = false,
                    faceCount = 0,
                    error = "Tidak ada wajah terdeteksi. Pastikan wajah menghadap kamera.",
                )
            } else {
                FaceDetectionResult(
                    faceDetected = true,
                    faceCount = faces.size,
                    face = faces.first().toFaceResult(),
                )
            }
        } catch (e: Exception) {
            FaceDetectionResult(
                faceDetected = false,
                faceCount = 0,
                error = "Gagal mendeteksi wajah: ${e.message}",
            )
        }
    }

    private suspend fun processImage(image: InputImage): List<Face> =
        suspendCancellableCoroutine { cont ->
            detector.process(image)
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resume(emptyList()) }
        }

    /** Mengubah `Face` ML Kit menjadi model internal [FaceResult]. */
    private fun Face.toFaceResult(): FaceResult {
        val lm = LinkedHashMap<FaceLandmarkType, PointF>()
        getLandmark(FaceLandmark.LEFT_EYE)?.let { lm[FaceLandmarkType.LEFT_EYE] = it.position }
        getLandmark(FaceLandmark.RIGHT_EYE)?.let { lm[FaceLandmarkType.RIGHT_EYE] = it.position }
        getLandmark(FaceLandmark.NOSE_BASE)?.let { lm[FaceLandmarkType.NOSE_BASE] = it.position }
        getLandmark(FaceLandmark.MOUTH_LEFT)?.let { lm[FaceLandmarkType.LEFT_MOUTH] = it.position }
        getLandmark(FaceLandmark.MOUTH_RIGHT)?.let { lm[FaceLandmarkType.RIGHT_MOUTH] = it.position }
        getLandmark(FaceLandmark.MOUTH_BOTTOM)?.let { lm[FaceLandmarkType.BOTTOM_MOUTH] = it.position }
        getLandmark(FaceLandmark.LEFT_CHEEK)?.let { lm[FaceLandmarkType.LEFT_CHEEK] = it.position }
        getLandmark(FaceLandmark.RIGHT_CHEEK)?.let { lm[FaceLandmarkType.RIGHT_CHEEK] = it.position }
        getLandmark(FaceLandmark.LEFT_EAR)?.let { lm[FaceLandmarkType.LEFT_EAR] = it.position }
        getLandmark(FaceLandmark.RIGHT_EAR)?.let { lm[FaceLandmarkType.RIGHT_EAR] = it.position }

        val ct = LinkedHashMap<FaceContourType, List<PointF>>()
        mapContour(ct, FaceContour.FACE, FaceContourType.FACE)
        mapContour(ct, FaceContour.NOSE_BRIDGE, FaceContourType.NOSE_BRIDGE)
        mapContour(ct, FaceContour.NOSE_BOTTOM, FaceContourType.NOSE_BOTTOM)
        mapContour(ct, FaceContour.LEFT_EYE, FaceContourType.LEFT_EYE)
        mapContour(ct, FaceContour.RIGHT_EYE, FaceContourType.RIGHT_EYE)
        mapContour(ct, FaceContour.LEFT_EYEBROW_TOP, FaceContourType.LEFT_EYEBROW_TOP)
        mapContour(ct, FaceContour.RIGHT_EYEBROW_TOP, FaceContourType.RIGHT_EYEBROW_TOP)
        mapContour(ct, FaceContour.UPPER_LIP_TOP, FaceContourType.UPPER_LIP_TOP)
        mapContour(ct, FaceContour.LOWER_LIP_BOTTOM, FaceContourType.LOWER_LIP_BOTTOM)

        return FaceResult(
            boundingBox = boundingBox,
            landmarks = lm,
            contours = ct,
            leftEyeOpenProbability = leftEyeOpenProbability,
            rightEyeOpenProbability = rightEyeOpenProbability,
            headEulerAngleX = headEulerAngleX,
            headEulerAngleY = headEulerAngleY,
            headEulerAngleZ = headEulerAngleZ,
        )
    }

    private fun Face.mapContour(
        out: MutableMap<FaceContourType, List<PointF>>,
        src: Int,
        type: FaceContourType,
    ) {
        val c = getContour(src) ?: return
        val pts = c.points
        if (pts.isNotEmpty()) out[type] = pts
    }

    fun close() = detector.close()
}
