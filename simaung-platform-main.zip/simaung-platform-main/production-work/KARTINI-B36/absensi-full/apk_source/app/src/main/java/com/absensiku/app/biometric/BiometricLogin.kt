package com.absensiku.app.biometric

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.absensiku.app.ui.theme.KartiniColors

/**
 * Tombol "Masuk dengan Biometrik" untuk layar login.
 *
 * Hanya tampil bila perangkat mendukung, fitur sudah diaktifkan dari tab Profil,
 * dan kredensial tersimpan tersedia. Saat berhasil, [onLogin] dipanggil dengan
 * kode karyawan & PIN tersimpan untuk melakukan login jaringan.
 */
@Composable
fun BiometricLoginButton(
    prefs: BiometricPrefs,
    onLogin: (code: String, pin: String) -> Unit,
    onError: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = remember { prefs }
    if (!scope.canQuickLogin()) return

    OutlinedButton(
        onClick = {
            val code = scope.savedEmployeeCode()
            val pin = scope.savedPin()
            if (code == null || pin == null) {
                onError("Data login tersimpan tidak ditemukan.")
                return@OutlinedButton
            }
            val activity = context.findFragmentActivity()
            if (activity == null) {
                onError("Tidak dapat membuka biometrik di perangkat ini.")
                return@OutlinedButton
            }
            promptBiometric(context = context, activity = activity, onSuccess = { onLogin(code, pin) }, onError = onError)
        },
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, KartiniColors.BrandGreen),
    ) {
        Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = KartiniColors.BrandGreen)
        Spacer(Modifier.width(8.dp))
        Text("Masuk dengan Biometrik", color = KartiniColors.BrandGreen, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Tampilkan dialog autentikasi biometrik sistem. */
private fun promptBiometric(
    context: Context,
    activity: FragmentActivity,
    onSuccess: () -> Unit,
    onError: (String) -> Unit,
) {
    val executor = ContextCompat.getMainExecutor(context)
    val manager = BiometricManager.from(context)
    val allowed = BiometricManager.Authenticators.BIOMETRIC_WEAK
    if (manager.canAuthenticate(allowed) != BiometricManager.BIOMETRIC_SUCCESS) {
        onError("Sensor biometrik tidak tersedia atau belum didaftarkan di perangkat.")
        return
    }
    val prompt = BiometricPrompt(
        activity,
        executor,
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                // Abaikan pesan "dibatalkan" saat pengguna menutup dialog.
                if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                    errorCode != BiometricPrompt.ERROR_CANCELED
                ) {
                    onError(errString.toString())
                }
            }
        },
    )
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Masuk dengan Biometrik")
        .setSubtitle("Verifikasi sidik jari atau wajah Anda untuk masuk")
        .setNegativeButtonText("Gunakan Kode & Password")
        .setAllowedAuthenticators(allowed)
        .build()
    prompt.authenticate(info)
}

/** Naikkan Context ke FragmentActivity (dibutuhkan BiometricPrompt). */
private fun Context.findFragmentActivity(): FragmentActivity? {
    var ctx: Context? = this
    while (ctx is android.content.ContextWrapper) {
        if (ctx is FragmentActivity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
