package com.absensiku.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absensiku.app.ui.theme.KartiniColors
import java.text.NumberFormat
import java.util.Locale

/** Format rupiah: Rp 12.500. */
fun formatRp(v: Double): String {
    val nf = NumberFormat.getInstance(Locale("id", "ID"))
    return "Rp " + nf.format(Math.round(v).toLong())
}

/** Nada warna badge status (memetakan ke tema Kartini). */
enum class OpsTone { OK, WARN, BAD, INFO, NEUTRAL }

fun opsToneFor(status: String): OpsTone {
    return when (status.uppercase()) {
        "COMPLETED", "DELIVERED", "APPROVED", "PAID", "FINAL", "CLOSED" -> OpsTone.OK
        "ON_THE_WAY", "ARRIVED", "ASSIGNED", "OPEN" -> OpsTone.INFO
        "SUBMITTED", "ISSUED" -> OpsTone.WARN
        "CANCELLED", "REJECTED" -> OpsTone.NEUTRAL
        else -> OpsTone.NEUTRAL
    }
}

fun opsStatusLabel(status: String): String = when (status.uppercase()) {
    "ASSIGNED" -> "Ditugaskan"
    "ON_THE_WAY" -> "Di Perjalanan"
    "ARRIVED" -> "Tiba"
    "COMPLETED" -> "Selesai"
    "CANCELLED" -> "Dibatalkan"
    "ISSUED" -> "Diterbitkan"
    "DELIVERED" -> "Terkirim"
    "SUBMITTED" -> "Menunggu Crosscek"
    "APPROVED" -> "Disetujui"
    "REJECTED" -> "Ditolak"
    "FINAL" -> "Final"
    "OPEN" -> "Terbuka"
    "CLOSED" -> "Ditutup"
    "PAID" -> "Lunas"
    else -> status
}

private data class ToneColors(val bg: Color, val fg: Color)

private fun toneColors(t: OpsTone): ToneColors = when (t) {
    OpsTone.OK -> ToneColors(KartiniColors.StatusOkBg, KartiniColors.StatusOkFg)
    OpsTone.WARN -> ToneColors(KartiniColors.StatusWarnBg, KartiniColors.StatusWarnFg)
    OpsTone.BAD -> ToneColors(KartiniColors.StatusBadBg, KartiniColors.StatusBadFg)
    OpsTone.INFO -> ToneColors(KartiniColors.StatusInfoBg, KartiniColors.StatusInfoFg)
    OpsTone.NEUTRAL -> ToneColors(Color(0xFFEDE5D6), KartiniColors.OnSurfaceMuted)
}

/** Badge status bulat. */
@Composable
fun OpsBadge(text: String, tone: OpsTone) {
    val c = toneColors(tone)
    Surface(color = c.bg, shape = RoundedCornerShape(20.dp)) {
        Text(
            text,
            color = c.fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}

@Composable
fun OpsBadge(status: String) = OpsBadge(opsStatusLabel(status), opsToneFor(status))

/** Kartu putih standar. */
@Composable
fun OpsCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(
        color = KartiniColors.CreamSurface,
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, KartiniColors.Outline),
        modifier = modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(16.dp)) { content() }
    }
}

/** Top bar modul operasional dengan tombol kembali. */
@Composable
fun OpsTopBar(title: String, subtitle: String, onBack: (() -> Unit)? = null) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    listOf(KartiniColors.BrandGreenDeep, KartiniColors.BrandGreen)
                )
            )
            .padding(start = 6.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = Color.White)
                }
            } else {
                Spacer(Modifier.width(10.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                Text(subtitle, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
    }
}

/** Judul bagian dengan aksen batang hijau. */
@Composable
fun OpsSectionTitle(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(width = 4.dp, height = 18.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(KartiniColors.BrandGreen)
        )
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = KartiniColors.OnSurface)
    }
}

@Composable
fun OpsEmpty(text: String) {
    Box(
        modifier = Modifier.fillMaxWidth().padding(vertical = 28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = KartiniColors.OnSurfaceMuted, fontSize = 13.sp)
    }
}

@Composable
private fun opsFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = KartiniColors.BrandGreen,
    unfocusedBorderColor = KartiniColors.Outline,
    focusedTextColor = KartiniColors.OnSurface,
    unfocusedTextColor = KartiniColors.OnSurface,
    focusedLabelColor = KartiniColors.BrandGreen,
    unfocusedLabelColor = KartiniColors.OnSurfaceMuted,
    cursorColor = KartiniColors.BrandGreen,
    focusedContainerColor = Color.White,
    unfocusedContainerColor = Color.White,
)

@Composable
fun OpsTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    minLines: Int = 1,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 12.5.sp) },
        singleLine = singleLine,
        minLines = minLines,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = opsFieldColors(),
        modifier = modifier.fillMaxWidth(),
    )
}

@Composable
fun OpsPrimaryButton(text: String, onClick: () -> Unit, enabled: Boolean = true, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = KartiniColors.BrandGreen, contentColor = Color.White),
        modifier = modifier.fillMaxWidth().height(46.dp),
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
fun OpsGhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = KartiniColors.StatusInfoBg,
            contentColor = KartiniColors.StatusInfoFg,
        ),
        modifier = modifier,
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

/** Kartu statistik ringkas. */
@Composable
fun OpsStatCard(label: String, value: String, sub: String? = null, accent: Color = KartiniColors.BrandGreen, modifier: Modifier = Modifier) {
    Surface(
        color = KartiniColors.CreamSurface,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, KartiniColors.Outline),
        modifier = modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(width = 26.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(accent)
            )
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = KartiniColors.OnSurface)
            Text(
                label.uppercase(),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = KartiniColors.OnSurfaceMuted,
                letterSpacing = 0.4.sp,
            )
            if (sub != null) Text(sub, fontSize = 11.sp, color = KartiniColors.OnSurfaceMuted)
        }
    }
}

/** Baris label–nilai. */
@Composable
fun OpsKeyValue(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, color = KartiniColors.OnSurfaceMuted, modifier = Modifier.width(120.dp))
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = KartiniColors.OnSurface)
    }
}

/** Baris menu (hub operasional) yang bisa diklik. */
@Composable
fun OpsMenuTile(title: String, desc: String, badge: String? = null, onClick: () -> Unit) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, KartiniColors.Outline),
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(KartiniColors.BrandGreenSoft),
                contentAlignment = Alignment.Center,
            ) {
                Text(title.take(1), color = KartiniColors.BrandGreen, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = KartiniColors.OnSurface)
                Text(desc, fontSize = 12.sp, color = KartiniColors.OnSurfaceMuted)
            }
            if (badge != null) {
                Spacer(Modifier.width(8.dp))
                Surface(color = KartiniColors.BrandGreenSoft, shape = RoundedCornerShape(20.dp)) {
                    Text(badge, color = KartiniColors.BrandGreenDark, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                }
            }
        }
    }
}

/**
 * Kartu fasilitas operasional yang MODERN & profesional: ikon bulat berwarna,
 * judul tebal, deskripsi ringkas, chip peran, dan panah. Dipakai di hub
 * Operasional agar tampil fungsional dan konsisten.
 */
@Composable
fun OpsFacilityCard(
    title: String,
    desc: String,
    roleChips: List<String>,
    accent: Color,
    onClick: () -> Unit,
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, KartiniColors.Outline),
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accent),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    title.take(1),
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = KartiniColors.OnSurface)
                Spacer(Modifier.height(2.dp))
                Text(desc, fontSize = 12.sp, color = KartiniColors.OnSurfaceMuted, lineHeight = 16.sp)
                if (roleChips.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Row {
                        roleChips.forEach { r ->
                            Surface(
                                color = accent.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.padding(end = 6.dp),
                            ) {
                                Text(
                                    r,
                                    color = KartiniColors.OnSurface,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = KartiniColors.OnSurfaceMuted,
            )
        }
    }
}

/** Header hub operasional dengan gradien brand + ringkasan peran. */
@Composable
fun OpsHeroHeader(roleLabels: List<String>) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(listOf(KartiniColors.BrandGreenDeep, KartiniColors.BrandGreen))
            )
            .padding(horizontal = 20.dp, vertical = 20.dp),
    ) {
        Column {
            Text("Pusat Operasional", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Jalankan tugas sesuai jabatan Anda",
                color = Color.White.copy(alpha = 0.88f),
                fontSize = 12.5.sp,
            )
            if (roleLabels.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Row {
                    roleLabels.forEach { r ->
                        Surface(
                            color = Color.White.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.padding(end = 6.dp),
                        ) {
                            Text(
                                r,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 11.dp, vertical = 4.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
