# Keep WebView / CameraX defaults
-dontwarn okhttp3.**
-dontwarn okio.**
