// =====================================================================
//  Kerangka Express untuk fitur WAJAH + ABSENSI server-side.
//
//  Modul ini sengaja menyediakan `createFaceApp({ auth })` agar dapat
//  DIPASANG ke backend AbsensiKu yang sudah ada (project Vercel Anda):
//
//     const { createFaceApp } = require('absensiku-face/server');
//     app.use('/api', createFaceApp({ auth: yourAuthMiddleware }));
//
//  dan juga bisa dijalankan mandiri untuk pengujian:
//     node server/src/index.js      (menyediakan /api/health + /api/face/*)
// =====================================================================

const express = require('express');
const { createFaceRouter } = require('./faceRoutes');

/** Middleware auth default (memakai header X-Employee-Code) untuk uji lokal. */
function demoAuth(req, res, next) {
  const code = req.header('X-Employee-Code') || 'demo_karyawan';
  req.user = { employeeCode: code };
  next();
}

/**
 * Membuat Express app berisi rute wajah.
 * @param {object} opts
 * @param {Function} [opts.auth] middleware auth (req.user.employeeCode)
 */
function createFaceApp(opts = {}) {
  const app = express();
  app.use(express.json({ limit: '4mb' }));
  const auth = opts.auth || demoAuth;

  app.get('/health', (req, res) =>
    res.json({ ok: true, service: 'absensiku-face', time: new Date().toISOString() })
  );
  app.use('/face', createFaceRouter({ auth }));
  return app;
}

module.exports = { createFaceApp, demoAuth };

// Jalankan mandiri bila dieksekusi langsung.
if (require.main === module) {
  const port = process.env.PORT || 3001;
  createFaceApp().listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`absensiku-face listening on :${port}`);
  });
}
