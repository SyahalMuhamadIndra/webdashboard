// =====================================================================
//  Rute wajah: enrollment & verifikasi DIKELOLA SERVER.
//
//  Model keamanan:
//   1. Enrollment: karyawan merekam N sample di HP -> dikirim ke server.
//      Server memvalidasi, menyimpan (satu record per karyawan).
//   2. Verifikasi: HP hanya mengirim PROBE (signature dari frame live).
//      Server yang menghitung skor kemiripan & memutuskan cocok/tidak.
//      -> keputusan tetap otoritatif walau HP dimodifikasi.
//
//  Penyimpanan: abstraksi "store" (lihat faceStore.js).
//  Autentikasi: middleware auth yang di-inject app (req.user).
// =====================================================================

const express = require('express');
const matcher = require('./faceMatcher');
const { getStore } = require('./faceStore');

/** Normalisasi payload enrollment {samples, basePhotoBase64}. */
function parseEnrollPayload(body) {
  let samples = body.samples;
  if (typeof samples === 'string') samples = matcher.splitSamples(samples);
  if (!Array.isArray(samples) || samples.length < 1) {
    throw new Error('Butuh minimal 1 sample wajah (disarankan 3).');
  }
  samples = samples.filter((s) => typeof s === 'string' && s.trim() !== '');
  if (samples.length === 0) throw new Error('Sample wajah tidak valid.');

  // Tolak format lama (v1/v2).
  if (samples.some((s) => matcher.isLegacySignature(s))) {
    throw new Error('Sample memakai format lama. Rekam ulang wajah.');
  }
  // Wajib TEMPLATE TEKSTUR v5 (fitur utama verifikasi ala GreatDay).
  const templates = samples.filter((s) => matcher.isTemplate(s) && matcher.decodeTemplate(s) !== null);
  if (templates.length === 0) {
    throw new Error('Sample wajah versi lama (tanpa tektur). Rekam ulang wajah.');
  }
  // Bila ada sample geometris v3/v4, validasi minimal fiturnya.
  for (const s of samples) {
    if (matcher.isTemplate(s)) continue;
    const feats = matcher.decodeFeatures(s);
    if (Object.keys(feats).length < matcher.MIN_COMMON_FEATURES) {
      throw new Error('Sample wajah tidak valid. Rekam ulang wajah.');
    }
  }
  let basePhotoBase64 = null;
  if (typeof body.basePhotoBase64 === 'string' && body.basePhotoBase64.length > 0) {
    // Batasi ukuran (~1.5 MB base64) agar tidak membebani server.
    if (body.basePhotoBase64.length > 2_000_000) {
      throw new Error('Foto dasar terlalu besar.');
    }
    basePhotoBase64 = body.basePhotoBase64;
  }
  return { samples, basePhotoBase64, templates };
}

/**
 * @param {object} deps
 * @param {Function} deps.auth  middleware Express (memasang req.user.employeeCode)
 */
function createFaceRouter({ auth }) {
  const router = express.Router();
  const store = getStore();

  // ---------- status enrollment ----------
  // GET /face/enrollment -> { enrolled, sampleCount, hasBasePhoto, updatedAt }
  router.get('/enrollment', auth, async (req, res) => {
    try {
      const rec = await store.get(req.user.employeeCode);
      if (!rec) return res.json({ enrolled: false, sampleCount: 0, hasBasePhoto: false, outdated: false });
      const samples = matcher.splitSamples(rec.samples);
      // "outdated" = tersimpan, tapi belum punya template tektur v5 -> wajib rekam ulang.
      const templates = samples.filter((s) => matcher.isTemplate(s) && matcher.decodeTemplate(s) !== null);
      const outdated = samples.length > 0 && templates.length === 0;
      res.json({
        enrolled: samples.length > 0,
        sampleCount: samples.length,
        hasBasePhoto: !!rec.basePhotoBase64,
        outdated,
        updatedAt: rec.updatedAt || null,
      });
    } catch (e) {
      res.status(500).json({ message: 'Gagal memuat status wajah.' });
    }
  });

  // ---------- enrollment ----------
  // POST /face/enrollment { samples:[sig..], basePhotoBase64? }
  router.post('/enrollment', auth, async (req, res) => {
    try {
      const { samples, basePhotoBase64 } = parseEnrollPayload(req.body || {});
      await store.save(req.user.employeeCode, {
        samples,
        basePhotoBase64,
        updatedAt: new Date().toISOString(),
      });
      res.json({ ok: true, sampleCount: samples.length, hasBasePhoto: !!basePhotoBase64 });
    } catch (e) {
      res.status(400).json({ message: e.message || 'Enrollment gagal.' });
    }
  });

  // ---------- verifikasi ----------
  // POST /face/verify { probe: signature, threshold?: 85 }
  // -> { match, score, nearMatch, effectiveThreshold, sampleCount, message }
  router.post('/verify', auth, async (req, res) => {
    try {
      const probe = req.body && req.body.probe;
      if (typeof probe !== 'string' || probe.trim() === '') {
        return res.status(400).json({ message: 'Probe wajah diperlukan.' });
      }
      if (matcher.isLegacySignature(probe)) {
        return res.status(400).json({ message: 'Probe memakai format lama.' });
      }
      const threshold = Number.isFinite(req.body.threshold) ? Math.trunc(req.body.threshold) : 85;
      const rec = await store.get(req.user.employeeCode);
      const samples = matcher.splitSamples(rec && rec.samples);
      if (samples.length === 0) {
        return res.status(409).json({ message: 'Belum ada data wajah. Lakukan enrollment dulu.' });
      }

      // Prioritas: verifikasi TEMPLATE TEKSTUR (v5) ala GreatDay.
      // Fallback: geometris v4 (bila hanya probe v3/v4 dikirim).
      const storedTemplates = samples.filter((s) => matcher.isTemplate(s));
      let decision;
      let mode = 'TEMPLATE';
      if (matcher.isTemplate(probe) && storedTemplates.length > 0) {
        decision = matcher.robustMatchTemplate(probe, storedTemplates, matcher.TPL_MATCH);
      } else {
        mode = 'GEOMETRIC';
        decision = matcher.robustMatch(probe, samples, threshold);
      }

      const score = Math.round(decision.score);
      const message = decision.isMatch
        ? `Wajah cocok (${score}%)`
        : decision.isNearMatch
        ? `Wajah hanya agak mirip (${score}%) — belum cukup identik. Butuh ${decision.effectiveThreshold}%.`
        : `Wajah tidak cocok (${score}%). Dibutuhkan minimal ${decision.effectiveThreshold}%.`;

      res.json({
        match: decision.isMatch,
        score,
        nearMatch: decision.isNearMatch,
        effectiveThreshold: decision.effectiveThreshold,
        sampleCount: samples.length,
        mode,
        message,
      });
    } catch (e) {
      res.status(500).json({ message: 'Verifikasi wajah gagal.' });
    }
  });

  // ---------- hapus (re-enroll) ----------
  // DELETE /face/enrollment
  router.delete('/enrollment', auth, async (req, res) => {
    try {
      await store.remove(req.user.employeeCode);
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ message: 'Gagal menghapus data wajah.' });
    }
  });

  // ---------- kelola panic/reset (admin) ----------
  // POST /face/panic-reset { employeeCode }  (opsional; butuh admin)
  router.post('/panic-reset', auth, async (req, res) => {
    try {
      const code = (req.body && req.body.employeeCode) || '';
      if (!code) return res.status(400).json({ message: 'employeeCode diperlukan.' });
      await store.remove(code);
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ message: 'Gagal mereset wajah karyawan.' });
    }
  });

  return router;
}

module.exports = { createFaceRouter };
