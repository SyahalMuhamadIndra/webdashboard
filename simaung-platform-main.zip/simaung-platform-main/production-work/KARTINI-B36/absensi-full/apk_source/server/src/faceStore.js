// =====================================================================
//  Store data wajah (abstraksi penyimpanan server).
//
//  Default: in-memory (cocok untuk uji lokal). Di produksi (Vercel),
//  gunakan penyimpanan persisten. Modul ini otomatis memakai Upstash Redis
//  REST bila env berikut tersedia:
//     UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN
//  (Vercel KV juga mengekspos var ini otomatis.)
//
//  Format record per karyawan (key: face:enroll:<employeeCode>):
//     { samples: [sigV3,...], basePhotoBase64: string|null, updatedAt: iso }
// =====================================================================

/** Store in-memory sederhana (untuk pengujian / fallback). */
class MemoryStore {
  constructor() {
    this.map = new Map();
  }
  async get(key) {
    return this.map.get(key) || null;
  }
  async save(key, record) {
    this.map.set(key, record);
  }
  async remove(key) {
    this.map.delete(key);
  }
}

/** Store Upstash Redis REST. */
class UpstashStore {
  constructor(url, token) {
    this.url = url.replace(/\/$/, '');
    this.token = token;
  }
  key(k) {
    return `face:enroll:${k}`;
  }
  async cmd(args) {
    const res = await fetch(this.url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(args),
    });
    if (!res.ok) throw new Error(`Upstash error ${res.status}`);
    return res.json();
  }
  async get(key) {
    const r = await this.cmd(['GET', this.key(key)]);
    if (!r || r.result == null) return null;
    try {
      return JSON.parse(r.result);
    } catch (_) {
      return null;
    }
  }
  async save(key, record) {
    await this.cmd(['SET', this.key(key), JSON.stringify(record)]);
  }
  async remove(key) {
    await this.cmd(['DEL', this.key(key)]);
  }
}

let singleton = null;

/** Dapatkan store aktif (dipilih berdasarkan env). */
function getStore() {
  if (singleton) return singleton;
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  singleton = url && token ? new UpstashStore(url, token) : new MemoryStore();
  return singleton;
}

module.exports = { getStore, MemoryStore, UpstashStore };
