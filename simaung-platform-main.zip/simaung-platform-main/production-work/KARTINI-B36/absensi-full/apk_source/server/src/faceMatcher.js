// =====================================================================
//  Mesin verifikasi wajah (port 1:1 dari FaceMatcher.kt v4)
//  v4 = 20 fitur geometris + 36-bin deskriptor bentuk (profil radial kontur).
//
//  Keputusan cocok memakai GERBANG GANDA:
//    - skor unifikasi (0.6·bentuk + 0.4·geometris) >= ambang efektif
//    - skor BENTUK (intrinsik) >= MATCH_INTRINSIC
//    - skor GEOMETRIS            >= MATCH_GEOMETRIC
//  Menekan false-accept (mis. pria pakai kacamata lolos sebagai wanita lain).
// =====================================================================

const TIGHT_DIFF = 5;
const LOOSE_DIFF = 11;
const REJECT_DIFF = 22;
const OUTLIER_DIFF_THRESHOLD = 24;
const MIN_COMMON_FEATURES = 14;
const CONSERVATIVE_MARGIN_PERCENT = 5;

const MATCH_UNIFIED = 90.0;
const MATCH_INTRINSIC = 88.0;
const MATCH_GEOMETRIC = 87.0;
const INTRINSIC_MIN_COMMON = 30;
const SHAPE_PREFIX = 'shape_';

/** Kontribusi skor (0..1) untuk satu fitur berdasarkan selisih absolut. */
function featureScore(diff) {
  if (diff <= TIGHT_DIFF) return 1.0;
  if (diff <= LOOSE_DIFF) {
    return 1.0 - 0.5 * (diff - TIGHT_DIFF) / (LOOSE_DIFF - TIGHT_DIFF);
  }
  if (diff <= REJECT_DIFF) {
    return 0.5 - 0.5 * (diff - LOOSE_DIFF) / (REJECT_DIFF - LOOSE_DIFF);
  }
  return 0.0;
}

/** Ambang efektif = ambang dasar + margin konservatif. */
function effectiveThreshold(baseThreshold) {
  return Math.max(0, Math.min(99, baseThreshold + CONSERVATIVE_MARGIN_PERCENT));
}

/** Decode signature JSON v3/v4 -> Map fitur. */
function decodeFeatures(sig) {
  try {
    const obj = typeof sig === 'string' ? JSON.parse(sig) : sig;
    if (!obj || (obj.v !== 3 && obj.v !== 4) || typeof obj.f !== 'object' || obj.f === null) return {};
    const out = {};
    for (const k of Object.keys(obj.f)) out[k] = Math.trunc(Number(obj.f[k]));
    return out;
  } catch (_) {
    return {};
  }
}

function isShapeAware(sig) {
  try {
    const o = typeof sig === 'string' ? JSON.parse(sig) : sig;
    return o && o.v === 4;
  } catch (_) {
    return false;
  }
}

function shapeFeatureCount(sig) {
  const f = decodeFeatures(sig);
  return Object.keys(f).filter((k) => k.startsWith(SHAPE_PREFIX)).length;
}

/** True bila signature memakai format lama (v1/v2). */
function isLegacySignature(sig) {
  if (sig == null) return false;
  const s = String(sig).trim();
  if (s.startsWith('[')) return true; // v1
  try {
    const o = JSON.parse(s);
    return o && o.v === 2;
  } catch (_) {
    return false;
  }
}

/** Skor (0..100) untuk himpunan kunci tertentu; -1 bila kosong. */
function scoreForKeys(keys, a, b) {
  if (keys.length === 0) return -1.0;
  let total = 0.0;
  let outliers = 0;
  const diffs = [];
  for (const k of keys) {
    const d = Math.abs(a[k] - b[k]);
    total += featureScore(d);
    if (d > OUTLIER_DIFF_THRESHOLD) outliers++;
    diffs.push(d);
  }
  let score = (total / keys.length) * 100;

  const outlierRatio = outliers / keys.length;
  if (outlierRatio > 0.20) score = Math.min(score, 55.0);
  else if (outlierRatio > 0.10) score = Math.min(score, 75.0);
  else if (outlierRatio > 0.05) score = Math.min(score, 83.0);

  diffs.sort((x, y) => x - y);
  const n = diffs.length;
  const median = n % 2 === 1 ? diffs[(n - 1) / 2] : (diffs[n / 2 - 1] + diffs[n / 2]) / 2.0;
  const mean = diffs.reduce((s, v) => s + v, 0) / n;

  if (mean > 9) score = Math.min(score, Math.max(0, Math.min(100, 100 - (mean - 9) * 4.0)));
  if (median > 6) score = Math.min(score, Math.max(0, Math.min(92, 92 - (median - 6) * 5.0)));

  return Math.max(0.0, Math.min(100.0, score));
}

/** Persentase kemiripan dua signature (0..100), skor unifikasi. */
function similarityScore(sigA, sigB) {
  const a = decodeFeatures(sigA);
  const b = decodeFeatures(sigB);
  const ka = Object.keys(a);
  if (ka.length === 0) return 0.0;
  const common = ka.filter((k) => Object.prototype.hasOwnProperty.call(b, k));
  if (common.length < MIN_COMMON_FEATURES) return 0.0;
  return scoreForKeys(common, a, b);
}

/** Rincian skor + keputusan gerbang ganda. */
function pairScore(sigA, sigB, baseThreshold) {
  const eff = Math.max(effectiveThreshold(baseThreshold), Math.trunc(MATCH_UNIFIED));
  const a = decodeFeatures(sigA);
  const b = decodeFeatures(sigB);
  if (Object.keys(a).length === 0 || Object.keys(b).length === 0) {
    return { unified: 0.0, intrinsic: 0.0, geometric: 0.0, matched: false };
  }
  const common = Object.keys(a).filter((k) => Object.prototype.hasOwnProperty.call(b, k));
  if (common.length < MIN_COMMON_FEATURES) {
    return { unified: 0.0, intrinsic: 0.0, geometric: 0.0, matched: false };
  }
  const intrinsicKeys = common.filter((k) => k.startsWith(SHAPE_PREFIX));
  const geometricKeys = common.filter((k) => !k.startsWith(SHAPE_PREFIX));

  const intrinsic = intrinsicKeys.length >= INTRINSIC_MIN_COMMON ? scoreForKeys(intrinsicKeys, a, b) : -1.0;
  const geometric = geometricKeys.length >= MIN_COMMON_FEATURES ? scoreForKeys(geometricKeys, a, b) : -1.0;
  const full = scoreForKeys(common, a, b);

  let unified;
  if (intrinsic >= 0 && geometric >= 0) unified = 0.6 * intrinsic + 0.4 * geometric;
  else if (intrinsic >= 0) unified = intrinsic;
  else unified = full;

  let matched;
  if (intrinsic >= 0 && geometric >= 0) {
    matched = unified >= eff && intrinsic >= MATCH_INTRINSIC && geometric >= MATCH_GEOMETRIC;
  } else if (intrinsic >= 0) {
    matched = unified >= eff && intrinsic >= MATCH_INTRINSIC;
  } else {
    matched = full >= eff;
  }
  return {
    unified,
    intrinsic: intrinsic < 0 ? full : intrinsic,
    geometric: geometric < 0 ? full : geometric,
    matched,
  };
}

function isMatchDecision(sigA, sigB, baseThreshold) {
  return pairScore(sigA, sigB, baseThreshold).matched;
}

function scoresAgainstSamples(signature, samples, baseThreshold = 85) {
  return (samples || []).map((s) => pairScore(signature, s, baseThreshold).unified);
}

/**
 * Verifikasi multi-sample robust dengan gerbang ganda.
 */
function robustMatch(signature, samples, thresholdPercent) {
  if (!samples || samples.length === 0) {
    return { isMatch: false, score: 0.0, isNearMatch: false, effectiveThreshold: 0 };
  }
  const eff = Math.max(effectiveThreshold(thresholdPercent), Math.trunc(MATCH_UNIFIED));
  const pairs = samples.map((s) => pairScore(signature, s, thresholdPercent));
  const scores = pairs.map((p) => p.unified);
  const required = samples.length === 1 ? 1 : Math.ceil(samples.length / 2);

  const matchCount = pairs.filter((p) => p.matched).length;
  const baseMatchCount = scores.filter((s) => s >= eff).length;

  const sorted = [...scores].sort((a, b) => b - a);
  const representative = sorted.slice(0, required).reduce((s, v) => s + v, 0) / required;

  return {
    isMatch: matchCount >= required,
    score: representative,
    isNearMatch: matchCount < required && baseMatchCount >= required,
    effectiveThreshold: eff,
  };
}

/** Pisahkan string multi-sample (JSON array) menjadi list. */
function splitSamples(stored) {
  if (stored == null || stored === '') return [];
  if (Array.isArray(stored)) return stored;
  const s = String(stored).trim();
  try {
    const arr = JSON.parse(s);
    if (Array.isArray(arr)) return arr.map(String);
  } catch (_) {}
  return [s];
}

// =====================================================================
//  TEMPLATE TEKSTUR (v5) — NCC, ala GreatDay HR.
//  Template = grid 32x32 keabuan (base64) yang sudah dinormalisasi pencahayaan.
// =====================================================================

const TEMPLATE_GRID = 32;
const TEMPLATE_LEN = TEMPLATE_GRID * TEMPLATE_GRID;
const TEMPLATE_LARGE_DIFF = 46;
const TPL_MATCH = 78;
const TPL_NEAR = 62;

/** True bila signature adalah template v5. */
function isTemplate(sig) {
  if (sig == null) return false;
  try {
    const o = typeof sig === 'string' ? JSON.parse(sig) : sig;
    return o && o.v === 5 && Array.isArray(o.t);
  } catch (_) {
    return false;
  }
}

/** Decode template JSON v5 -> array int 0..255 (panjang TEMPLATE_LEN). Null bila invalid. */
function decodeTemplate(sig) {
  try {
    const o = typeof sig === 'string' ? JSON.parse(sig) : sig;
    if (!o || o.v !== 5 || !Array.isArray(o.t)) return null;
    if (o.t.length !== TEMPLATE_LEN) return null;
    return o.t.map((v) => Math.max(0, Math.min(255, Math.trunc(Number(v)))));
  } catch (_) {
    return null;
  }
}

/** Skor NCC 0..100 antara dua template v5; -1 bila invalid. */
function templateScore(sigA, sigB) {
  const a = decodeTemplate(sigA);
  const b = decodeTemplate(sigB);
  if (!a || !b || a.length !== b.length) return -1.0;
  let dot = 0.0, na = 0.0, nb = 0.0, large = 0;
  for (let i = 0; i < a.length; i++) {
    const x = a[i], y = b[i];
    dot += x * y;
    na += x * x;
    nb += y * y;
    if (Math.abs(x - y) > TEMPLATE_LARGE_DIFF) large++;
  }
  if (na <= 0 || nb <= 0) return -1.0;
  let score = (dot / (Math.sqrt(na) * Math.sqrt(nb))) * 100.0;
  score -= (large / a.length) * 140.0;
  return Math.max(0.0, Math.min(100.0, score));
}

/** Verifikasi template terhadap banyak sample tersimpan (mayoritas). */
function robustMatchTemplate(probeTemplate, storedTemplates, threshold = TPL_MATCH) {
  if (!storedTemplates || storedTemplates.length === 0) {
    return { isMatch: false, score: 0.0, isNearMatch: false, effectiveThreshold: threshold, sampleCount: 0 };
  }
  const scores = storedTemplates.map((t) => templateScore(probeTemplate, t)).filter((s) => s >= 0);
  if (scores.length === 0) {
    return { isMatch: false, score: 0.0, isNearMatch: false, effectiveThreshold: threshold, sampleCount: 0 };
  }
  const required = scores.length === 1 ? 1 : Math.ceil(scores.length / 2);
  const matchCount = scores.filter((s) => s >= threshold).length;
  const sorted = [...scores].sort((a, b) => b - a);
  const representative = sorted.slice(0, required).reduce((s, v) => s + v, 0) / required;
  return {
    isMatch: matchCount >= required,
    score: representative,
    isNearMatch: matchCount < required && sorted[0] >= TPL_NEAR,
    effectiveThreshold: threshold,
    sampleCount: scores.length,
  };
}

module.exports = {
  TIGHT_DIFF,
  LOOSE_DIFF,
  REJECT_DIFF,
  OUTLIER_DIFF_THRESHOLD,
  MIN_COMMON_FEATURES,
  CONSERVATIVE_MARGIN_PERCENT,
  MATCH_UNIFIED,
  MATCH_INTRINSIC,
  MATCH_GEOMETRIC,
  INTRINSIC_MIN_COMMON,
  TEMPLATE_GRID,
  TEMPLATE_LEN,
  TPL_MATCH,
  TPL_NEAR,
  featureScore,
  effectiveThreshold,
  decodeFeatures,
  isShapeAware,
  shapeFeatureCount,
  isLegacySignature,
  similarityScore,
  pairScore,
  isMatchDecision,
  scoresAgainstSamples,
  robustMatch,
  splitSamples,
  isTemplate,
  decodeTemplate,
  templateScore,
  robustMatchTemplate,
};
