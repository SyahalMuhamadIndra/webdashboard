# Modul Server — Enrollment & Verifikasi Wajah (AbsensiKu)

Modul Express ini memindahkan **enrollment wajah** dan **keputusan verifikasi
wajah** ke sisi server, sehingga verifikasi absensi bersifat **otoritatif di
backend** (bukan hanya dipercaya dari aplikasi).

## Kontrak API (di bawah prefix `/api`)

| Metode | Endpoint | Body | Balasan |
|--------|----------|------|---------|
| GET    | `/face/enrollment` | – | `{ enrolled, sampleCount, hasBasePhoto }` |
| POST   | `/face/enrollment` | `{ samples:[sigV5...], basePhotoBase64? }` | `{ ok, sampleCount, hasBasePhoto }` |
| POST   | `/face/verify`     | `{ probe:sigV3, threshold }` | `{ match, score, nearMatch, effectiveThreshold, sampleCount, message }` |
| DELETE | `/face/enrollment` | – | `{ ok }` |

`sigV5` adalah signature JSON **template tektur wajah**:
`{"v":5,"t":[nilai 0..255, 1024 buah]}` (grid 32×32 keabuan yang sudah
disejajarkan mata & dinormalisasi pencahayaan). Server menyimpan sample &
menghitung skor — **tidak menerima gambar mentah**.

### v5 = template tektur (utama, ala GreatDay HR)
Verifikasi memakai **NCC (normalized cross-correlation)** antar grid template.
Pola terang-gelap bagian dalam wajah (mata, hidung, alis, mulut, tulang pipi)
unik per individu → sulit dicapai orang berbeda. Ambang cocok: **NCC ≥ 78%**
(dengan mayoritas sample).

### v4 = geometris + deskriptor bentuk (fallback)
Signature v4 menambahkan **36-bin deskriptor bentuk** (`shape_0..shape_35`,
profil radial kontur wajah) di atas 20 fitur geometris. Keputusan cocok memakai
**GERBANG GANDA**:

| Gerbang | Ambang |
|---------|--------|
| Skor unifikasi `0.6·bentuk + 0.4·geometris` | ≥ ambang efektif (≥90) |
| Skor **bentuk** (intrinsik) | ≥ 88 |
| Skor **geometris** | ≥ 87 |

Wajah hanya dianggap cocok bila mirip pada **bentuk** *dan* **proporsi**.
Ini menutup bug v3 (geometris saja) yang membuat orang berbeda (mis. pria
berkacamata) bisa lolos terhadap sample wanita lain.

> **Signature v3/legacy ditolak** saat enrollment → memicu **re-enroll wajah**
> demi keamanan. Endpoint `GET /face/enrollment` mengembalikan `outdated: true`
> bila data tersimpan masih v3 sehingga aplikasi meminta rekam ulang.

## 1. Pasang ke backend Vercel yang sudah ada

Backend Anda (Express) cukup menambahkan rute modul ini. Di `index.js`/`app.js`
backend Vercel:

```js
const { createFaceRouter } = require('./server/src/faceRoutes');

// middleware auth Anda yang memasang req.user.employeeCode dari Bearer token
app.use('/api/face', createFaceRouter({ auth: yourAuthMiddleware }));
```

Sesuaikan `auth` dengan middleware token milik backend Anda (yang saat ini
melindungi `/api/config`, `/api/attendance`, dsb.). Modul menganggap
`req.user.employeeCode` sudah terisi.

## 2. Penyimpanan

Default **in-memory** (untuk uji). Di produksi gunakan penyimpanan persisten.
Modul otomatis memakai **Upstash Redis REST / Vercel KV** bila env berikut ada:

```
UPSTASH_REDIS_REST_URL=...
UPSTASH_REDIS_REST_TOKEN=...
```

Alternatif: ganti `server/src/faceStore.js` dengan implementasi database Anda
(Postgres/MySQL/Firestore). Interface store cukup 3 method: `get`, `save`,
`remove`.

> Catatan privasi: `basePhotoBase64` adalah foto referensi wajah. Simpan di
> storage privat & hormati kebijakan privasi. Field ini opsional; jika tak
> dikirim, hanya signature yang disimpan.

## 3. Uji lokal

```bash
cd server
npm install
npm test              # 14 test (mesin + endpoint)
npm start             # jalankan di :3001 untuk uji manual
```

Uji manual (auth demo memakai header `X-Employee-Code`):

```bash
curl -s localhost:3001/face/enrollment -H 'X-Employee-Code: emp_001'
```

## 4. Sisi aplikasi (Android)

Aplikasi (`FaceRepository.kt`) memakai endpoint di atas:
- Enrollment  -> `POST /api/face/enrollment`
- Verifikasi  -> `POST /api/face/verify` (server memutuskan `match`)
- Fallback    -> bila server tak terjangkau, verifikasi dihitung lokal
  (ditandai `faceVerifySource = "LOKAL"`), lalu tetap dikirim ke
  `/api/attendance` untuk dicatat.

Hasil verifikasi server juga diteruskan ke absensi (`faceScore`,
`faceVerifySource`) sehingga backend dapat menolak absensi tanpa verifikasi wajah.
