// Uji mesin verifikasi wajah v4 (geometris+gerbang ganda) & v5 (template tektur/NCC).
const test = require('node:test');
const assert = require('node:assert');
const matcher = require('../src/faceMatcher');
const { makeSig, makeV3, makeTemplate } = require('./sigHelpers');

test('NCC: template identik -> skor 100 & cocok', () => {
  const t = makeTemplate(1234);
  const s = matcher.templateScore(t, t);
  assert.ok(s >= 99.0, `skor ${s}`);
  assert.ok(matcher.robustMatchTemplate(t, [t, t, t], matcher.TPL_MATCH).isMatch);
});

test('NCC: template sama + noise kecil tetap di atas ambang', () => {
  const a = makeTemplate(1234, 0);
  const b = makeTemplate(1234, 8);
  const s = matcher.templateScore(a, b);
  assert.ok(s >= matcher.TPL_MATCH, `skor ${s} harus >= ${matcher.TPL_MATCH}`);
});

test('NCC: template berbeda (orang lain) DITOLAK', () => {
  const a = makeTemplate(10);
  const b = makeTemplate(9999);
  const s = matcher.templateScore(a, b);
  assert.ok(s < matcher.TPL_MATCH, `skor ${s} harus < ${matcher.TPL_MATCH}`);
  assert.ok(!matcher.robustMatchTemplate(b, [a, a, a], matcher.TPL_MATCH).isMatch);
});

test('isTemplate membedakan v5 vs v4', () => {
  assert.ok(matcher.isTemplate(makeTemplate(1)));
  assert.ok(!matcher.isTemplate(makeSig(80, 90)));
});

// ---------- v4 geometris ----------

test('identical v4 signature scores 100 & matches', () => {
  const a = makeSig(80, 90);
  assert.strictEqual(matcher.similarityScore(a, a), 100.0);
  assert.ok(matcher.pairScore(a, a, 85).matched);
});

test('REGRESI v4: geometri mirip tapi bentuk beda ditolak', () => {
  const enrolled = makeSig(80, 90);
  const impostor = makeSig(80, 165);
  assert.ok(!matcher.isMatchDecision(impostor, enrolled, 85));
});

test('legacy signature detected', () => {
  assert.ok(matcher.isLegacySignature('[1,2,3]'));
  assert.ok(matcher.isLegacySignature('{"v":2,"f":[1,2]}'));
  assert.ok(!matcher.isLegacySignature(makeSig(80, 90)));
});

test('splitSamples round trip', () => {
  const list = [makeTemplate(1), makeTemplate(2)];
  assert.deepStrictEqual(matcher.splitSamples(JSON.stringify(list)), list);
});
