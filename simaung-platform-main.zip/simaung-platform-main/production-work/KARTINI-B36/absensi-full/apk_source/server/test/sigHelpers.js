// Helper pembuat signature untuk pengujian.
// v4 = 20 fitur geometris + 36 bin deskriptor bentuk (profil radial).

const GEO_KEYS = [
  'eye_l_nose', 'eye_r_nose', 'ear_width_ratio', 'cheek_width_ratio',
  'eye_l_cheek_l', 'eye_r_cheek_r', 'mouth_width_eye_ratio',
  'mouth_width_nose_ratio', 'mouth_height_width_ratio', 'nose_chin_mouth_ratio',
  'face_aspect_ratio', 'nose_top_rel', 'nose_bottom_rel', 'nose_width_rel',
  'eye_l_width_rel', 'eye_r_width_rel', 'brow_l_rel', 'brow_r_rel',
  'lip_upper_width_rel', 'lip_lower_width_rel',
];

/** Signature v4 dengan nilai geometris = geoBase dan bentuk = shapeBase. */
function makeSig(geoBase, shapeBase, jitter = 0) {
  const f = {};
  GEO_KEYS.forEach((k, i) => (f[k] = geoBase + i + jitter));
  for (let b = 0; b < 36; b++) f['shape_' + b] = shapeBase + b + jitter;
  return JSON.stringify({ v: 4, f });
}

/** Signature lama (v3, tanpa bentuk) — untuk menguji penolakan. */
function makeV3(geoBase, jitter = 0) {
  const f = {};
  GEO_KEYS.forEach((k, i) => (f[k] = geoBase + i + jitter));
  return JSON.stringify({ v: 3, f });
}

module.exports = { GEO_KEYS, makeSig, makeV3 };

/** Template tektur v5 dari seed deterministik (grid 32x32, array int). */
function makeTemplate(seed, noise = 0) {
  const N = 32 * 32;
  const arr = new Array(N);
  let s = seed >>> 0;
  for (let i = 0; i < N; i++) {
    s = (s * 1664525 + 1013904223) >>> 0;
    const base = (Math.sin(i * 0.35 + seed) * 60 + 128);
    const n = noise ? ((s % (2 * noise + 1)) - noise) : 0;
    arr[i] = Math.max(0, Math.min(255, Math.round(base + n)));
  }
  return JSON.stringify({ v: 5, t: arr });
}

module.exports.makeTemplate = makeTemplate;
