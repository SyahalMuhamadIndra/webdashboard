// Uji endpoint wajah (enrollment + verifikasi template) via HTTP.
const test = require('node:test');
const assert = require('node:assert');
const { createFaceApp } = require('../src/index');
const { makeSig, makeV3, makeTemplate } = require('./sigHelpers');

function startServer() {
  return new Promise((resolve) => {
    const server = createFaceApp().listen(0, () => resolve(server));
  });
}
function base(server) {
  return `http://127.0.0.1:${server.address().port}`;
}
const H = { 'Content-Type': 'application/json', 'X-Employee-Code': 'emp_001' };

test('enrollment (template v5) lalu verify -> cocok', async () => {
  const server = await startServer();
  const b = base(server);
  try {
    let r = await fetch(`${b}/face/enrollment`, { headers: H });
    assert.strictEqual((await r.json()).enrolled, false);

    r = await fetch(`${b}/face/enrollment`, {
      method: 'POST', headers: H,
      body: JSON.stringify({ samples: [makeTemplate(111), makeTemplate(111, 4), makeTemplate(111, 6)], basePhotoBase64: 'AAAA' }),
    });
    assert.strictEqual(r.status, 200);
    assert.strictEqual((await r.json()).sampleCount, 3);

    r = await fetch(`${b}/face/verify`, {
      method: 'POST', headers: H,
      body: JSON.stringify({ probe: makeTemplate(111, 5) }),
    });
    const j = await r.json();
    assert.strictEqual(j.match, true);
    assert.strictEqual(j.mode, 'TEMPLATE');
    assert.ok(j.score >= 70);
  } finally {
    server.close();
  }
});

test('REGRESI: impostor (template orang lain) DITOLAK server', async () => {
  const server = await startServer();
  const b = base(server);
  const who = { 'Content-Type': 'application/json', 'X-Employee-Code': 'emp_impostor' };
  try {
    await fetch(`${b}/face/enrollment`, {
      method: 'POST', headers: who,
      body: JSON.stringify({ samples: [makeTemplate(10), makeTemplate(10, 3)] }),
    });
    const r = await fetch(`${b}/face/verify`, {
      method: 'POST', headers: who,
      body: JSON.stringify({ probe: makeTemplate(9999) }),
    });
    const j = await r.json();
    assert.strictEqual(j.match, false);
  } finally {
    server.close();
  }
});

test('enrollment menolak sample tanpa template (v3/v4)', async () => {
  const server = await startServer();
  const b = base(server);
  try {
    const r = await fetch(`${b}/face/enrollment`, {
      method: 'POST', headers: H,
      body: JSON.stringify({ samples: [makeV3(80)] }),
    });
    assert.strictEqual(r.status, 400);
  } finally {
    server.close();
  }
});

test('enrollment menolak template invalid', async () => {
  const server = await startServer();
  const b = base(server);
  try {
    const bad = JSON.stringify({ v: 5, t: [1, 2, 3] });
    const r = await fetch(`${b}/face/enrollment`, {
      method: 'POST', headers: H,
      body: JSON.stringify({ samples: [bad] }),
    });
    assert.strictEqual(r.status, 400);
  } finally {
    server.close();
  }
});

test('status menandai data lama (v4) sebagai outdated', async () => {
  const server = await startServer();
  const b = base(server);
  const hdr = { 'Content-Type': 'application/json', 'X-Employee-Code': 'emp_old' };
  try {
    // Kirim template (valid) -> outdated=false.
    await fetch(`${b}/face/enrollment`, {
      method: 'POST', headers: hdr,
      body: JSON.stringify({ samples: [makeTemplate(55), makeTemplate(55), makeTemplate(55)] }),
    });
    const j = await (await fetch(`${b}/face/enrollment`, { headers: hdr })).json();
    assert.strictEqual(j.enrolled, true);
    assert.strictEqual(j.outdated, false);
  } finally {
    server.close();
  }
});

test('verify tanpa enrollment -> 409', async () => {
  const server = await startServer();
  const b = base(server);
  try {
    const r = await fetch(`${b}/face/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Employee-Code': 'no_one' },
      body: JSON.stringify({ probe: makeTemplate(1) }),
    });
    assert.strictEqual(r.status, 409);
  } finally {
    server.close();
  }
});

test('delete enrollment membersihkan data', async () => {
  const server = await startServer();
  const b = base(server);
  try {
    await fetch(`${b}/face/enrollment`, {
      method: 'POST', headers: H,
      body: JSON.stringify({ samples: [makeTemplate(1), makeTemplate(2), makeTemplate(3)] }),
    });
    let r = await fetch(`${b}/face/enrollment`, { method: 'DELETE', headers: H });
    assert.strictEqual((await r.json()).ok, true);
    r = await fetch(`${b}/face/enrollment`, { headers: H });
    assert.strictEqual((await r.json()).enrolled, false);
  } finally {
    server.close();
  }
});
