/* Shared by the Kartini websites, including cached tablet pages. */
(() => {
  if (window.__kartiniMaintenanceGuard) return;
  window.__kartiniMaintenanceGuard = true;
  const endpoint = 'https://api.simaung.com/api/maintenance/status';
  let overlay, text, running = false, verified = false;
  function mount() {
    if (overlay) return;
    overlay = document.createElement('div');
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', 'Status layanan Simaung Corporation');
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:#102a23;color:#edf5f0;display:flex;align-items:center;justify-content:center;padding:28px;font:16px system-ui;text-align:center';
    const card = document.createElement('section'); card.style.maxWidth = '460px';
    const brand = document.createElement('div'); brand.textContent = 'SIMAUNG CORPORATION'; brand.style.cssText = 'letter-spacing:3px;font-size:12px;color:#b7f1bf';
    const title = document.createElement('h1'); title.textContent = 'Sedang maintenance'; title.style.fontSize = '32px';
    text = document.createElement('p'); text.style.cssText = 'line-height:1.8;color:#c1d4c6';
    const button = document.createElement('button'); button.textContent = 'Periksa kembali'; button.style.cssText = 'border:0;border-radius:12px;padding:14px 22px;background:#b7f1bf;color:#102a23;font:600 15px system-ui';
    button.onclick = check;
    card.append(brand, title, text, button); overlay.append(card); document.documentElement.append(overlay);
  }
  function show(message, maintenance) {
    mount(); overlay.style.display = 'flex';
    overlay.querySelector('h1').textContent = maintenance ? 'Sedang maintenance' : 'Layanan belum dapat diperiksa';
    text.textContent = message;
    document.body?.setAttribute('inert', '');
    // Overlay lives outside body, so background buttons cannot receive keyboard input.
  }
  function open() {
    verified = true;
    if (document.querySelector('[data-maintenance-page]')) { location.reload(); return; }
    if (overlay) overlay.style.display = 'none';
    document.body?.removeAttribute('inert');
  }
  async function check() {
    if (running) return; running = true;
    try {
      const response = await fetch(endpoint, { cache: 'no-store', signal: AbortSignal.timeout(6000) });
      if (!response.ok) throw new Error('status');
      const state = await response.json();
      if (typeof state.enabled !== 'boolean') throw new Error('contract');
      verified = true;
      if (state.enabled) show(state.message || 'Sistem sedang maintenance. Silakan coba kembali nanti.', true);
      else open();
    } catch {
      // Keep a known maintenance screen closed until a successful OFF response.
      // An unavailable status check does not block the page.
      // An already-confirmed maintenance screen remains until an explicit OFF response.
    } finally { running = false; }
  }
  // Check silently; mount the overlay only after maintenance is confirmed.
  document.addEventListener('DOMContentLoaded', () => {
    if (overlay && overlay.style.display !== 'none') document.body?.setAttribute('inert', '');
  }, { once: true });
  const originalFetch = window.fetch.bind(window);
  window.fetch = async (...args) => {
    const response = await originalFetch(...args);
    // Only the API's explicit maintenance code should trigger maintenance UI.
    if (response.status === 503) {
      response.clone().json().then(body => {
        if (body.code === 'MAINTENANCE') { verified = true; show(body.message, true); }
      }).catch(() => {});
    }
    return response;
  };
  check();
  setInterval(() => { if (!document.hidden) check(); }, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
  window.addEventListener('online', check);
})();
