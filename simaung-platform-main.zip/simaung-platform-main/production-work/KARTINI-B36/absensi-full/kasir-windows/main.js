const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
const fs = require('fs');

const exeDir = path.dirname(process.execPath);
const cetakLangsung = fs.existsSync(path.join(exeDir, 'cetak-langsung.txt')) || process.argv.includes('--cetak-langsung');
if (cetakLangsung) app.commandLine.appendSwitch('kiosk-printing'); // cetak struk tanpa dialog

let win = null;
function buatJendela() {
  win = new BrowserWindow({
    width: 1366, height: 768, minWidth: 1024, minHeight: 620,
    backgroundColor: '#232935', autoHideMenuBar: true, title: 'Kasir Simaung',
    icon: path.join(__dirname, 'icon.ico'), show: false,
    webPreferences: { contextIsolation: true, nodeIntegration: false, spellcheck: false, devTools: false }
  });
  Menu.setApplicationMenu(null);
  const posUrl = 'https://pos.simaung.com/';
  win.webContents.on('will-navigate', (event, url) => {
    if (new URL(url).origin !== new URL(posUrl).origin) {
      event.preventDefault();
      if (/^https:/.test(url)) shell.openExternal(url);
    }
  });
  win.loadURL(posUrl).catch(() => {
    const message = '<meta charset="utf-8"><title>Kasir Simaung</title><h1>POS tidak dapat dibuka</h1><p>Periksa koneksi internet, lalu buka ulang Kasir Simaung.</p>';
    if (win && !win.isDestroyed()) win.loadURL('data:text/html,' + encodeURIComponent(message));
  });
  win.once('ready-to-show', () => { win.show(); if (process.argv.includes('--layar-penuh')) win.setFullScreen(true); });
  win.webContents.on('before-input-event', (e, inp) => {
    if (inp.type !== 'keyDown') return;
    if (inp.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    if (inp.key === 'F12' || (inp.control && inp.shift && String(inp.key).toLowerCase() === 'i')) e.preventDefault();
  });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.on('closed', () => { win = null; });
}
app.whenReady().then(buatJendela);
app.on('window-all-closed', () => app.quit());
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) buatJendela(); });
