(() => {
  const original = window.fetch.bind(window);
  let session = '', ready, available = [], endpoint = '', authorization = '', canManage = false;
  const storage = 'kartini.branchId';
  function render() {
    if (!document.body) return;
    let panel = document.getElementById('kartini-branch-picker');
    if (!panel) {
      panel = document.createElement('div'); panel.id = 'kartini-branch-picker';
      Object.assign(panel.style, {position:'fixed',right:'12px',bottom:'12px',zIndex:'9990',padding:'8px',background:'#fff',color:'#163127',border:'1px solid #bccfc5',borderRadius:'10px',boxShadow:'0 2px 8px #0002',font:'13px system-ui'});
      document.body.append(panel);
    }
    panel.replaceChildren();
    const label = document.createElement('label'); label.textContent = 'Cabang '; const select = document.createElement('select');
    for (const branch of available) { const option = document.createElement('option'); option.value=branch.id; option.textContent=branch.name; select.append(option); }
    select.value=localStorage.getItem(storage)||'';
    select.onchange=()=>{
      if(localStorage.getItem('kartini.pendingCheckout')){alert('Selesaikan atau periksa transaksi tertunda sebelum mengganti cabang.');select.value=localStorage.getItem(storage);return;}
      if(typeof S!=='undefined' && S.cart && S.cart.length){alert('Kosongkan keranjang sebelum mengganti cabang.');select.value=localStorage.getItem(storage);return;}
      localStorage.setItem(storage,select.value);location.reload();
    };
    label.append(select); panel.append(label);
    if(canManage){const button=document.createElement('button');button.textContent='Kelola';button.style.marginLeft='8px';button.onclick=manage;panel.append(button);}
  }
  async function manage(){
    const dialog=document.createElement('dialog');dialog.style.cssText='max-width:440px;width:90%;border:1px solid #bccfc5;border-radius:12px;padding:20px;font:15px system-ui';
    dialog.innerHTML='<form><h2>Kelola cabang</h2><p><label>Tindakan <select name="action"><option value="access">Atur akses akun</option><option value="new">Tambah cabang</option></select></label></p><section data-access><p><label>Cabang <select name="branch"></select></label></p><p><label>Akun <select name="actor" required></select></label></p><p><label>Akses <select name="enabled"><option value="yes">Berikan akses</option><option value="no">Cabut akses</option></select></label></p></section><section data-new hidden><p><label>Kode cabang <input name="code" maxlength="24" placeholder="SUMEDANG02"></label></p><p><label>Nama cabang <input name="name" maxlength="120"></label></p></section><p role="status"></p><button type="submit">Simpan</button> <button type="button" data-close>Tutup</button></form>';
    document.body.append(dialog);dialog.showModal();const form=dialog.querySelector('form'),status=dialog.querySelector('[role=status]');
    const branchSelect=form.elements.branch,actorSelect=form.elements.actor;
    for(const branch of available){const option=document.createElement('option');option.value=branch.id;option.textContent=branch.name;branchSelect.append(option);}branchSelect.value=localStorage.getItem(storage);
    dialog.querySelector('[data-close]').onclick=()=>{dialog.close();dialog.remove();};
    form.elements.action.onchange=()=>{const create=form.elements.action.value==='new';dialog.querySelector('[data-access]').hidden=create;dialog.querySelector('[data-new]').hidden=!create;actorSelect.required=!create;form.elements.code.required=create;form.elements.name.required=create;};
    try{const response=await original(endpoint+'/admin/branch-members',{headers:{Authorization:authorization}});if(!response.ok)throw Error('Daftar akun tidak tersedia.');const result=await response.json();for(const member of result.items){const option=document.createElement('option');option.value=member.id;option.textContent=member.name+' ('+member.kind+')';actorSelect.append(option);}}catch(error){status.textContent=error.message;}
    form.onsubmit=async event=>{
      event.preventDefault();const button=form.querySelector('[type=submit]');button.disabled=true;status.textContent='Menyimpan…';
      const create=form.elements.action.value==='new';const path=endpoint+'/admin/branches'+(create?'':'/'+branchSelect.value+'/access');
      const body=create?{code:form.elements.code.value,name:form.elements.name.value}:{actorId:actorSelect.value,enabled:form.elements.enabled.value==='yes'};
      try{const response=await original(path,{method:'POST',headers:{Authorization:authorization,'Content-Type':'application/json'},body:JSON.stringify(body)});const result=await response.json();if(!response.ok)throw Error(result.message||'Perubahan gagal.');location.reload();}catch(error){status.textContent=error.message;button.disabled=false;}
    };
  }
  window.fetch = async function(input, options){
    const url = new URL(typeof input==='string'||input instanceof URL?input:input.url,location.href);
    if(!url.pathname.startsWith('/api/ops/'))return original(input,options);
    const headers=new Headers(options?.headers||(input instanceof Request?input.headers:undefined));
    const token=headers.get('Authorization');if(!token)return original(input,options);
    const base=url.origin+'/api/ops';
    if(session!==token||endpoint!==base){session=token;endpoint=base;authorization=token;ready=null;}
    if(!ready)ready=(async()=>{
      const response=await original(base+'/branches',{headers:{Authorization:token}});if(!response.ok)throw Error('Daftar cabang tidak tersedia.');
      const result=await response.json();available=result.items||[];canManage=result.canManage===true;if(!available.length)throw Error('Akun belum memiliki penugasan cabang.');
      if(!available.some(b=>b.id===localStorage.getItem(storage)))localStorage.setItem(storage,available[0].id);render();
    })();
    try{await ready;}catch(error){ready=null;return Response.json({message:error.message},{status:503});}
    let branch=localStorage.getItem(storage);
    try{const body=typeof options?.body==='string'?JSON.parse(options.body):null;if(body?.branchId)branch=body.branchId;}catch{}
    headers.set('X-Branch-Id',branch);
    return original(input,{...options,headers});
  };
})();
