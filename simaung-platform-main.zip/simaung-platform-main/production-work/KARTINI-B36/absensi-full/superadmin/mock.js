/* Simaung Corporation Superadmin — mock.js
   Mode pratinjau (data contoh) agar UI/UX bisa dinilai tanpa backend live.
   Dipakai hanya bila API live tidak dapat dihubungi, atau lewat tombol "Pratinjau". */
(function () {
  let state = { token: '' };
  let lastRole = 'SUPERADMIN';
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const addD = (s, n) => { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + n); return iso(d); };
  const today = iso(new Date());
  const monday = (() => { const d = new Date(today + 'T00:00:00'); const g = d.getDay(); d.setDate(d.getDate() + (g === 0 ? -6 : 1 - g)); return iso(d); })();

  const ADMIN = { adminId: 'demo', name: 'Super Admin', email: 'admin@tokokartini.com', role: 'SUPERADMIN', companyName: 'Simaung Corporation', officeName: 'Kantor Simaung Corporation' };
  const ADMIN_DEV = { adminId: 'demo-dev', name: 'Developer', email: 'dev@tokokartini.com', role: 'DEV', companyName: 'Simaung Corporation', officeName: 'Kantor Simaung Corporation' };

  const COMPANY = {
    name: 'Simaung Corporation', officeName: 'Kantor Pusat', phone: '+62 22-1234-5678',
    address: 'Jalan Cut Nyak Dien, Sukajaya, Sumedang, Jawa Barat, 45321, Indonesia',
    officeLatitude: -6.863499, officeLongitude: 107.922027, officeRadiusMeters: 100, minimumLocationAccuracyMeters: 80,
    lateGraceMinutes: 0, timezone: 'Asia/Jakarta', logoBase64: null,
  };

  const SHIFTS = [
    { id: 'sh-pagi', name: 'Pagi', startTime: '08:00', endTime: '16:00', color: '#036D19', active: true, officeLocationId: 'loc1' },
    { id: 'sh-siang', name: 'Siang', startTime: '13:00', endTime: '21:00', color: '#1D6FB8', active: true, officeLocationId: null },
  ];

  // Pratinjau (hanya memori): pengaturan yang tak tersimpan ke DB — B7.
  const TEMP_SETTINGS = { employeeDefaultPassword: 'abc123456' };

  // Multi lokasi kantor (demo).
  let OFFICE_LOCATIONS = [
    { id: 'loc1', name: 'Kantor Pusat', address: 'Jalan Cut Nyak Dien, Sukajaya, Sumedang, Jawa Barat', latitude: -6.863499, longitude: 107.922027, radiusMeters: 100, minimumLocationAccuracyMeters: 80, isDefault: true, active: true, employeeCount: 3 },
    { id: 'loc2', name: 'Toko Cabang Cimalaka', address: 'Jalan Raya Cimalaka No. 12, Sumedang', latitude: -6.82511, longitude: 107.95311, radiusMeters: 150, minimumLocationAccuracyMeters: 80, isDefault: false, active: true, employeeCount: 2 },
  ];

  // B75: pengaturan per lokasi (pratinjau). Kosong = warisi pengaturan perusahaan.
  // Contoh: cabang Cimalaka punya jam masuk lebih longgar & zona waktu sama.
  let LOCATION_SETTINGS = {
    loc2: { lateGraceMinutes: 15, timezone: 'Asia/Jakarta', gpsDriftToleranceMeters: 90, minimumAccuracyMeters: 60 },
  };
  function locSettingsEff(locId) {
    const o = LOCATION_SETTINGS[locId] || {};
    return {
      lateGraceMinutes: o.lateGraceMinutes != null ? o.lateGraceMinutes : COMPANY.lateGraceMinutes,
      timezone: o.timezone || COMPANY.timezone || 'Asia/Jakarta',
      gpsDriftToleranceMeters: o.gpsDriftToleranceMeters != null ? o.gpsDriftToleranceMeters : 75,
      minimumAccuracyMeters: o.minimumAccuracyMeters != null ? o.minimumAccuracyMeters : (officeById(locId) ? officeById(locId).minimumLocationAccuracyMeters : 80),
      overrides: {
        lateGraceMinutes: o.lateGraceMinutes != null,
        timezone: !!o.timezone,
        gpsDriftToleranceMeters: o.gpsDriftToleranceMeters != null,
        minimumAccuracyMeters: o.minimumAccuracyMeters != null,
      },
    };
  }

  // Desain aplikasi (APK) per lokasi (B67) — mode pratinjau (hanya memori).
  const BRANDING_DEFAULTS = {
    brandName: 'Simaung Corporation', displayName: 'Simaung Corporation', tagline: 'Absensi Karyawan',
    primaryColor: '#036D19', primaryDarkColor: '#0A3D14', accentColor: '#F85800',
    bgColor: '#FBF7F1', surfaceColor: '#FFFDF9', textColor: '#1A1A1A', mutedColor: '#6C6C6C',
    logoUrl: null, logoBase64: null, logoWhiteUrl: null, logoWhiteBase64: null,
    headerImageUrl: null, splashImageUrl: null, loginImageUrl: null,
  };
  let BRANDING = {
    loc2: { brandName: 'Simaung Corporation Cimalaka', displayName: 'Kartini Cimalaka', tagline: 'Absen Cabang Cimalaka', primaryColor: '#1B5E20', accentColor: '#FF6F00', bgColor: '#F5F5F0' },
  };

  const EMPLOYEES = [
    { id: 'e1', employeeCode: 'EMP001', fullName: 'Andi Saputra', position: 'Kasir', phone: '0812-1111-2001', active: true, shiftId: 'sh-pagi', avatarColor: '#0B6B2E', officeLocationId: 'loc1' },
    { id: 'e2', employeeCode: 'EMP002', fullName: 'Budi Santoso', position: 'Staf Gudang', phone: '0812-1111-2002', active: true, shiftId: 'sh-siang', avatarColor: '#C74700', officeLocationId: null },
    { id: 'e3', employeeCode: 'EMP003', fullName: 'Citra Dewi', position: 'Kasir', phone: '0812-1111-2003', active: true, shiftId: 'sh-pagi', avatarColor: '#1D6FB8', officeLocationId: 'loc2' },
    { id: 'e4', employeeCode: 'EMP004', fullName: 'Dewi Lestari', position: 'Admin Toko', phone: '0812-1111-2004', active: true, shiftId: 'sh-pagi', avatarColor: '#7A3FB5', officeLocationId: 'loc1' },
    { id: 'e5', employeeCode: 'EMP005', fullName: 'Eko Prasetyo', position: 'Kurir', phone: '0812-1111-2005', active: true, shiftId: 'sh-siang', avatarColor: '#0E7490', officeLocationId: 'loc2' },
    { id: 'e6', employeeCode: 'EMP006', fullName: 'Fitri Handayani', position: 'Kasir', phone: '0812-1111-2006', active: false, shiftId: null, avatarColor: '#B34A6B', officeLocationId: null },
  ];

  // ---- Opsi via URL: ?demo=1 (aktifkan pratinjau), ?many=1 (tambah banyak karyawan), ?mobile=1 (paksa tampilan HP) ----
  try {
    const qs = new URLSearchParams(location.search || '');
    if (qs.has('demo') || qs.has('many') || qs.has('mobile')) window.__MOCK__ = true;
    if (qs.has('many')) {
      const extra = [
        ['Gita Puspita', 'Kasir', 'sh-pagi'], ['Hadi Nugroho', 'Staf Gudang', 'sh-siang'],
        ['Indah Permata', 'Kasir', 'sh-pagi'], ['Joko Widodo', 'Kurir', 'sh-siang'],
        ['Kartika Sari', 'Admin Toko', 'sh-pagi'], ['Lukman Hakim', 'Staf Gudang', 'sh-siang'],
        ['Maya Anggraini', 'Kasir', 'sh-pagi'], ['Nanda Pratama', 'Kurir', 'sh-siang'],
        ['Oki Setiana', 'Kasir', 'sh-siang'], ['Putri Ayu', 'Admin Toko', 'sh-pagi'],
        ['Rangga Wibowo', 'Staf Gudang', 'sh-siang'], ['Sari Melati', 'Kasir', 'sh-pagi'],
      ];
      const colors = ['#0B6B2E', '#C74700', '#1D6FB8', '#7A3FB5', '#0E7490', '#B34A6B'];
      extra.forEach((row, k) => {
        EMPLOYEES.push({
          id: 'x' + (k + 1), employeeCode: 'EMP' + String(k + 7).padStart(3, '0'),
          fullName: row[0], position: row[1], phone: '0812-2222-' + String(3001 + k),
          active: true, shiftId: row[2], avatarColor: colors[k % colors.length],
        });
      });
    }
  } catch (e) { /* ignore */ }

  function shiftName(id) { const s = SHIFTS.find((x) => x.id === id); return s ? s.name : null; }
  const ROLE_CATALOG = [
    { key: 'DRIVER', label: 'Driver', desc: 'Tracking perjalanan & surat jalan' },
    { key: 'PRAMUNIAGA', label: 'Pramuniaga', desc: 'Sistem stock opname' },
    { key: 'KEPALA_GUDANG', label: 'Kepala Gudang', desc: 'Opname full & crosscek hasil opname' },
    { key: 'KASIR', label: 'Kasir', desc: 'Sistem POS (kasir)' },
    { key: 'PENJAGA', label: 'Penjaga', desc: 'Jaga lokasi/toko & pantau keamanan' },
  ];
  const EMP_ROLES = { e1: ['KASIR'], e2: ['PRAMUNIAGA'], e3: ['KASIR', 'PRAMUNIAGA'], e4: ['KEPALA_GUDANG'], e5: ['DRIVER', 'PRAMUNIAGA'], e6: ['PENJAGA'] };

  /* ---- B11: data contoh modul operasional (Driver/Opname/POS) ---- */
  const OPS_PRODUCTS = [
    { id: 'p1', sku: 'BRG-001', barcode: '8991002100011', name: 'Beras Premium 5kg', category: 'Sembako', unit: 'sak', price: 68000, cost: 60000, stock: 42, minStock: 10, active: true },
    { id: 'p2', sku: 'BRG-002', barcode: '8991002100028', name: 'Minyak Goreng 2L', category: 'Sembako', unit: 'pouch', price: 36000, cost: 32000, stock: 8, minStock: 12, active: true },
    { id: 'p3', sku: 'BRG-003', barcode: '8991002100035', name: 'Gula Pasir 1kg', category: 'Sembako', unit: 'pcs', price: 16000, cost: 14000, stock: 55, minStock: 15, active: true },
    { id: 'p4', sku: 'MKN-010', barcode: '8991002100042', name: 'Mie Instan Goreng', category: 'Makanan', unit: 'dus', price: 125000, cost: 112000, stock: 20, minStock: 8, active: true },
    { id: 'p5', sku: 'MNM-021', barcode: '8991002100059', name: 'Air Mineral 600ml', category: 'Minuman', unit: 'dus', price: 55000, cost: 48000, stock: 30, minStock: 10, active: true },
    { id: 'p6', sku: 'SBN-005', barcode: '8991002100066', name: 'Sabun Mandi Batang', category: 'Kebersihan', unit: 'pcs', price: 4500, cost: 3500, stock: 120, minStock: 30, active: true },
  ];
  const OPS_TRIPS = [
    { id: 'tr1', code: 'TRP-20250101-0001', driverId: 'e5', driverName: 'Eko Prasetyo', vehicle: 'L 1234 AB', destination: 'Pasar Sentral', note: 'Antar sembako', status: 'ON_THE_WAY', lastLat: -5.1, lastLng: 105.3, noteCount: 1, createdAt: new Date().toISOString() },
    { id: 'tr2', code: 'TRP-20250101-0002', driverId: 'e5', driverName: 'Eko Prasetyo', vehicle: 'L 1234 AB', destination: 'Toko Cabang Babarsari', note: 'Restock mingguan', status: 'COMPLETED', lastLat: -5.12, lastLng: 105.32, noteCount: 2, createdAt: new Date(Date.now() - 86400e3).toISOString() },
  ];
  const OPS_NOTES = [
    { id: 'sj1', code: 'SJ-20250101-0001', tripId: 'tr1', driverName: 'Eko Prasetyo', recipientName: 'Pasar Sentral', address: 'Jl. Pasar Baru No. 5', status: 'ISSUED', totalItems: 3, createdAt: new Date().toISOString() },
    { id: 'sj2', code: 'SJ-20250101-0002', tripId: 'tr2', driverName: 'Eko Prasetyo', recipientName: 'Toko Babarsari', address: 'Jl. Babarsari No. 88', status: 'DELIVERED', totalItems: 2, createdAt: new Date(Date.now() - 86400e3).toISOString() },
  ];
  const OPS_OPNAMES = [
    { id: 'op1', employeeName: 'Budi Santoso', kind: 'PRAMUNIAGA', area: 'Rak Sembako', totalItems: 6, totalDiff: 3, status: 'SUBMITTED', reviewedBy: null, createdAt: new Date().toISOString() },
    { id: 'op2', employeeName: 'Dewi Lestari', kind: 'KEPALA_GUDANG', area: 'Semua', totalItems: 6, totalDiff: 0, status: 'FINAL', reviewedBy: null, createdAt: new Date(Date.now() - 3600e3).toISOString() },
  ];
  const OPS_SALES = [
    { id: 'sl1', code: 'INV-20250101-1001', cashierName: 'Andi Saputra', customerName: 'Ibu Sari', subtotal: 104000, discount: 4000, tax: 0, memberDiscount: 10000, total: 90000, paid: 100000, change: 10000, paymentMethod: 'CASH', status: 'PAID', createdAt: new Date().toISOString() },
    { id: 'sl2', code: 'INV-20250101-1002', cashierName: 'Citra Dewi', subtotal: 55000, discount: 0, total: 55000, paid: 55000, change: 0, paymentMethod: 'NON_CASH', status: 'PAID', createdAt: new Date(Date.now() - 1800e3).toISOString() },
  ];
  const OPS_CUSTOMERS = [
    { id: 'c1', name: 'Pelanggan Umum', phone: '', tier: 'regular', discountPercent: 0, points: 0, active: true },
    { id: 'c2', name: 'Ibu Sari', phone: '081234567890', tier: 'gold', discountPercent: 10, points: 320, active: true },
    { id: 'c3', name: 'Pak Budi', phone: '081298765432', tier: 'silver', discountPercent: 5, points: 120, active: true },
  ];
  const OPS_SETTINGS = { taxRate: 11, taxEnabled: false, splitPaymentEnabled: true, lowStockThreshold: 5, storeName: 'Simaung Corporation' };
  const OPS_SESSIONS = [
    { id: 'se1', cashierName: 'Andi Saputra', openingCash: 0, closingCash: null, expectedCash: null, cashDiff: null, status: 'OPEN', openedAt: new Date().toISOString() },
    { id: 'se2', cashierName: 'Citra Dewi', openingCash: 0, closingCash: 205000, expectedCash: 205000, cashDiff: 0, status: 'CLOSED', openedAt: new Date(Date.now() - 86400e3).toISOString() },
  ];
  function opsBase(name) { return String(name || '').split('/').pop(); }
  function opsOverview() {
    const today = new Date().toISOString().slice(0, 10);
    return {
      date: today,
      trips: { total: OPS_TRIPS.length, active: OPS_TRIPS.filter((t) => ['ASSIGNED', 'ON_THE_WAY', 'ARRIVED'].includes(t.status)).length, completed: OPS_TRIPS.filter((t) => t.status === 'COMPLETED').length },
      deliveryNotes: { total: OPS_NOTES.length, delivered: OPS_NOTES.filter((n) => n.status === 'DELIVERED').length },
      opnames: { total: OPS_OPNAMES.length, pending: OPS_OPNAMES.filter((o) => o.status === 'SUBMITTED').length, approved: OPS_OPNAMES.filter((o) => o.status === 'APPROVED').length, rejected: 0 },
      pos: { count: OPS_SALES.length, total: OPS_SALES.reduce((a, b) => a + b.total, 0), cash: OPS_SALES.filter((s) => s.paymentMethod === 'CASH').reduce((a, b) => a + b.total, 0), openSessions: OPS_SESSIONS.filter((s) => s.status === 'OPEN').length },
      products: { total: OPS_PRODUCTS.length, low: OPS_PRODUCTS.filter((p) => p.stock <= p.minStock).length },
    };
  }
  function opsOpnameDetail(id) {
    const o = OPS_OPNAMES.find((x) => x.id === id) || OPS_OPNAMES[0];
    const items = OPS_PRODUCTS.map((p, i) => ({ id: 'oi' + i, productId: p.id, productName: p.name, sku: p.sku, systemStock: p.stock, countedStock: p.stock - (i === 1 ? 2 : i === 3 ? -1 : 0), diff: i === 1 ? -2 : i === 3 ? 1 : 0, note: null }));
    return { opname: o, items };
  }
  function opsSaleDetail(id) {
    const s = OPS_SALES.find((x) => x.id === id) || OPS_SALES[0];
    const items = OPS_PRODUCTS.slice(0, 2).map((p, i) => ({ id: 'si' + i, productId: p.id, productName: p.name, sku: p.sku, price: p.price, qty: i + 1, total: p.price * (i + 1) }));
    return { sale: s, items };
  }
  function opsNoteDetail(id) {
    const n = OPS_NOTES.find((x) => x.id === id) || OPS_NOTES[0];
    const t = OPS_TRIPS.find((x) => x.id === n.tripId) || {};
    const items = OPS_PRODUCTS.slice(0, 2).map((p, i) => ({ id: 'ni' + i, productId: p.id, productName: p.name, sku: p.sku, qty: i + 1, unit: p.unit }));
    return { note: { ...n, tripCode: t.code, destination: t.destination, vehicle: t.vehicle, note: t.note }, items };
  }
  function officeById(id) { return OFFICE_LOCATIONS.find((x) => x.id === id) || null; }
  function officeLocationsResponse() {
    return { items: OFFICE_LOCATIONS.map((l) => ({ ...l, employeeCount: EMPLOYEES.filter((e) => e.officeLocationId === l.id).length })), officeLocations: OFFICE_LOCATIONS };
  }
  function empList() {
    return EMPLOYEES.map((e) => ({
      ...e, shiftName: shiftName(e.shiftId),
      officeName: officeById(e.officeLocationId) ? officeById(e.officeLocationId).name : null,
      officeIsDefault: !!officeById(e.officeLocationId) && officeById(e.officeLocationId).isDefault,
      roles: EMP_ROLES[e.id] || [],
      shiftStart: e.shiftId ? SHIFTS.find((s) => s.id === e.shiftId).startTime : null,
      shiftEnd: e.shiftId ? SHIFTS.find((s) => s.id === e.shiftId).endTime : null,
    }));
  }
  function shiftList() {
    return SHIFTS.map((s) => ({
      ...s,
      officeLocationName: s.officeLocationId ? (officeById(s.officeLocationId) ? officeById(s.officeLocationId).name : null) : null,
      employeeCount: EMPLOYEES.filter((e) => e.shiftId === s.id).length,
    }));
  }

  // --- attendance for a given date (deterministic demo) ---
  function attendance(date) {
    const seed = date.split('-').reduce((a, b) => a + parseInt(b, 10), 0);
    const items = EMPLOYEES.map((e, i) => {
      if (!e.active) return { employeeId: e.id, employeeCode: e.employeeCode, fullName: e.fullName, position: e.position, checkInAt: null, checkOutAt: null, checkInDistanceMeters: null, checkOutDistanceMeters: null, faceScore: null, status: 'ALFA', workMinutes: null };
      const r = (seed + i * 7) % 10;
      if (r < 1) return { employeeId: e.id, employeeCode: e.employeeCode, fullName: e.fullName, position: e.position, checkInAt: null, checkOutAt: null, checkInDistanceMeters: null, checkOutDistanceMeters: null, faceScore: null, status: 'ALFA', workMinutes: null };
      const ci = `${date}T0${e.shiftId === 'sh-siang' ? '8' : '7'}:${pad(((seed + i * 13) % 30) + 25)}:00Z`;
      const open = r >= 7;
      const co = open ? null : `${date}T0${e.shiftId === 'sh-siang' ? 16 : 15}:${pad(((seed + i * 11) % 40) + 5)}:00Z`;
      const dist = 8 + ((seed + i * 17) % 55);
      const sh = e.shiftId ? SHIFTS.find((s) => s.id === e.shiftId) : null;
      return {
        employeeId: e.id, employeeCode: e.employeeCode, fullName: e.fullName, position: e.position,
        checkInAt: ci, checkOutAt: co, checkInDistanceMeters: dist, checkOutDistanceMeters: co ? dist - 3 : null,
        faceScore: 82 + ((seed + i * 5) % 17), status: open ? 'BELUM_CHECKOUT' : 'HADIR',
        shiftName: sh ? sh.name : null, shiftStart: sh ? sh.startTime : null, shiftEnd: sh ? sh.endTime : null,
        lateMinutes: (!open && !sh) || !sh ? 0 : (((seed + i * 13) % 4) === 0 ? 12 : 0),
        workMinutes: open ? null : 430 + ((seed + i * 9) % 70),
      };
    });
    return {
      date,
      summary: {
        date, total: EMPLOYEES.length,
        hadir: items.filter((x) => x.status === 'HADIR').length,
        terlambat: items.filter((x) => x.status === 'TERLAMBAT' || x.status === 'TERLAMBAT_BELUM_CHECKOUT').length,
        belumCheckout: items.filter((x) => x.status === 'BELUM_CHECKOUT').length,
        alfa: items.filter((x) => x.status === 'ALFA').length,
      },
      items,
    };
  }

  function report(from, to) {
    const items = EMPLOYEES.filter((e) => e.active).map((e, i) => {
      const present = 12 + ((i * 5 + 7) % 9);
      return {
        employeeId: e.id, employeeCode: e.employeeCode, fullName: e.fullName, position: e.position,
        avatarColor: e.avatarColor, daysPresent: present, checkIns: present + (i % 2),
        avgDistance: 12 + ((i * 9) % 40), avgFaceScore: 84 + ((i * 3) % 14),
        overtimeApprovedMinutes: (i % 3 === 0) ? (60 + (i * 30) % 180) : 0,
        overtimeApprovedCount: (i % 3 === 0) ? 1 + (i % 2) : 0,
        overtimePendingCount: (i % 4 === 1) ? 1 : 0,
      };
    });
    return { from, to, items };
  }

  // --- pengajuan lembur (demo) ---
  let OVERTIMES = [
    { id: 'ot1', employeeId: 'e1', employeeCode: 'EMP001', fullName: 'Andi Saputra', position: 'Kasir', date: addD(today, -1), startTime: '18:00', endTime: '20:30', durationMinutes: 150, reason: 'Menutup kasir & rekap penjualan', status: 'PENDING', decisionNote: null, createdAt: today + 'T02:00:00Z' },
    { id: 'ot2', employeeId: 'e2', employeeCode: 'EMP002', fullName: 'Budi Santoso', position: 'Gudang', date: addD(today, -2), startTime: '17:00', endTime: '20:00', durationMinutes: 180, reason: 'Penerimaan stok barang', status: 'PENDING', decisionNote: null, createdAt: addD(today, -2) + 'T03:00:00Z' },
    { id: 'ot3', employeeId: 'e3', employeeCode: 'EMP003', fullName: 'Citra Dewi', position: 'Kasir', date: addD(today, -3), startTime: '18:00', endTime: '21:00', durationMinutes: 180, reason: 'Stock opname', status: 'APPROVED', decisionNote: 'Disetujui', createdAt: addD(today, -4) + 'T01:00:00Z' },
    { id: 'ot4', employeeId: 'e5', employeeCode: 'EMP005', fullName: 'Eko Prasetyo', position: 'Kurir', date: addD(today, -5), startTime: '16:00', endTime: '18:30', durationMinutes: 150, reason: 'Pengiriman mendesak', status: 'REJECTED', decisionNote: 'Tidak ada persetujuan awal', createdAt: addD(today, -6) + 'T02:00:00Z' },
  ];

  // --- pengajuan izin (demo) ---
  let LEAVES = [
    { id: 'lv1', employeeId: 'e1', employeeCode: 'EMP001', fullName: 'Andi Saputra', position: 'Kasir', category: 'SAKIT', startDate: addD(today, -1), endDate: addD(today, -1), reason: 'Demam, disertai surat dokter', status: 'PENDING', decisionNote: null, hasAttachment: true, hasAttachmentImage: true, createdAt: today + 'T02:10:00Z' },
    { id: 'lv2', employeeId: 'e3', employeeCode: 'EMP003', fullName: 'Citra Dewi', position: 'Kasir', category: 'IZIN', startDate: addD(today, 2), endDate: addD(today, 3), reason: 'Acara keluarga di luar kota', status: 'PENDING', decisionNote: null, hasAttachment: false, hasAttachmentImage: false, createdAt: today + 'T04:30:00Z' },
    { id: 'lv3', employeeId: 'e4', employeeCode: 'EMP004', fullName: 'Dewi Lestari', position: 'Admin Toko', category: 'IZIN', startDate: addD(today, -3), endDate: addD(today, -3), reason: 'Urusan administrasi bank', status: 'APPROVED', decisionNote: 'Disetujui', hasAttachment: false, hasAttachmentImage: false, createdAt: addD(today, -4) + 'T01:00:00Z' },
    { id: 'lv4', employeeId: 'e5', employeeCode: 'EMP005', fullName: 'Eko Prasetyo', position: 'Kurir', category: 'SAKIT', startDate: addD(today, -5), endDate: addD(today, -5), reason: 'Cek kesehatan', status: 'REJECTED', decisionNote: 'Surat tidak terbaca', hasAttachment: true, hasAttachmentImage: true, createdAt: addD(today, -6) + 'T03:00:00Z' },
  ];

  // --- rilis aplikasi (demo) ---
  let RELEASES = [
    { id: 'rel1', versionName: '0.9.12', versionCode: 24, apkUrl: 'https://example.com/absensiku-0.9.12.apk', mandatory: false, notes: 'Perbaikan absen, fitur izin & jadwal', active: true, downloadCount: 0, createdAt: today + 'T01:00:00Z' },
  ];
  // Data contoh untuk Alat Developer (Paket B + C11).
  let BROADCASTS = [
    { id: 'bc1', title: 'Selamat bekerja!', body: 'Tetap jaga kebersihan toko.', kind: 'INFO', readCount: 3, recipients: 6, createdAt: today + 'T00:00:00Z' },
  ];
  const FLAG_DEFS = [
    { key: 'attendance_photo', label: 'Foto Selfie saat Absen', description: 'Wajibkan verifikasi foto saat absen masuk/keluar.' },
    { key: 'overtime', label: 'Pengajuan Lembur', description: 'Izinkan karyawan mengajukan lembur dari aplikasi.' },
    { key: 'leave', label: 'Pengajuan Izin', description: 'Izinkan karyawan mengajukan izin/cuti dari aplikasi.' },
    { key: 'biometric_login', label: 'Login Biometrik', description: 'Aktifkan opsi login sidik jari/wajah di aplikasi.' },
    { key: 'self_change_password', label: 'Ganti Password Mandiri', description: 'Izinkan karyawan mengganti password sendiri di tab Profil.' },
  ];
  let FLAGS = { attendance_photo: true, overtime: true, leave: true, biometric_login: true, self_change_password: true };
  function durLabelMock(m) { const v = Math.max(0, Math.round(Number(m) || 0)); const h = Math.floor(v / 60); const r = v % 60; return h > 0 ? (r > 0 ? h + 'j ' + r + 'm' : h + 'j') : r + 'm'; }
  let USERS = [
    { id: 'u1', name: 'Super Admin', email: 'admin@tokokartini.com', role: 'SUPERADMIN', active: true, self: true },
    { id: 'u2', name: 'Rina HR', email: 'hr@tokokartini.com', role: 'HR', active: true, self: false },
    { id: 'u3', name: 'Bagus Manajer', email: 'manager@tokokartini.com', role: 'MANAGER', active: true, self: false },
    { id: 'u4', name: 'Developer', email: 'dev@tokokartini.com', role: 'DEV', active: true, self: false },
  ];
  let IMPERSONATIONS = [];

  function schedule(weekStart) {    const ws = weekStart || monday;
    const items = EMPLOYEES.filter((e) => e.active).map((e) => {
      const days = {};
      [0, 1, 2, 3, 4, 5, 6].forEach((i) => {
        const d = addD(ws, i);
        if (i === 6) days[d] = { shiftId: null, note: 'OFF' };
        else if ((e.id.charCodeAt(1) + i) % 4 !== 0) days[d] = { shiftId: e.shiftId || 'sh-pagi', note: null };
      });
      return {
        employeeId: e.id, employeeCode: e.employeeCode, fullName: e.fullName, position: e.position, avatarColor: e.avatarColor,
        defaultShiftId: e.shiftId, defaultShiftName: shiftName(e.shiftId),
        defaultShiftStart: e.shiftId ? SHIFTS.find((s) => s.id === e.shiftId).startTime : '',
        defaultShiftEnd: e.shiftId ? SHIFTS.find((s) => s.id === e.shiftId).endTime : '',
        days,
      };
    });
    return { weekStart: ws, weekEnd: addD(ws, 6), items };
  }

  // Keluhan & saran anonim dari karyawan (halaman publik tokokartini.com).
  let COMPLAINTS = [
    { id: 'c1', category: 'JADWAL', subject: 'Jadwal shift sering berubah mendadak', message: 'Mohon jadwal shift diinfokan lebih awal, minimal 3 hari sebelum, agar bisa atur urusan pribadi.', status: 'BARU', adminNote: null, createdAt: new Date(Date.now() - 2 * 864e5).toISOString() },
    { id: 'c2', category: 'GAJI', subject: 'Keterlambatan upah lembur', message: 'Upah lembur bulan lalu belum masuk. Mohon dicek, terima kasih.', status: 'DIBACA', adminNote: null, createdAt: new Date(Date.now() - 4 * 864e5).toISOString() },
    { id: 'c3', category: 'FASILITAS', subject: 'AC ruang kasir kurang dingin', message: 'AC di dekat meja kasir 1 sudah tidak dingin sejak seminggu lalu.', status: 'DITINDAKLANJUTI', adminNote: 'Sudah dipanggil teknisi, dijadwalkan Kamis.', createdAt: new Date(Date.now() - 6 * 864e5).toISOString() },
    { id: 'c4', category: 'LINGKUNGAN', subject: 'Kebersihan gudang belakang', message: 'Gudang belakang mulai berdebu dan ada tumpukan kardus kosong.', status: 'SELESAI', adminNote: 'Sudah dibersihkan tim kebersihan.', createdAt: new Date(Date.now() - 9 * 864e5).toISOString() },
  ];
  function complaintStats() {
    const s = { total: COMPLAINTS.length, baru: 0, dibaca: 0, ditindak: 0, selesai: 0 };
    COMPLAINTS.forEach((c) => {
      if (c.status === 'BARU') s.baru++;
      else if (c.status === 'DIBACA') s.dibaca++;
      else if (c.status === 'DITINDAKLANJUTI') s.ditindak++;
      else if (c.status === 'SELESAI') s.selesai++;
    });
    return s;
  }

  function route(path, opts) {
    const method = (opts && opts.method) || 'GET';
    const body = opts && opts.body;
    const [p, qs] = path.split('?');
    const q = {};
    (qs || '').split('&').forEach((kv) => { const [k, v] = kv.split('='); if (k) q[k] = decodeURIComponent(v || ''); });

    if (p === 'admin/login') {
      const email = String((body && body.email) || '').toLowerCase();
      if (email === 'dev@tokokartini.com') { lastRole = 'DEV'; return { token: 'demo-token-dev', ...ADMIN_DEV }; }
      lastRole = 'SUPERADMIN';
      return { token: 'demo-token', ...ADMIN };
    }
    if (p === 'admin/me') {
      const tok = (state && state.token) || '';
      return (lastRole === 'DEV' || tok.indexOf('dev') >= 0) ? ADMIN_DEV : ADMIN;
    }
    if (p === 'admin/company') {
      if (method === 'PUT') Object.assign(COMPANY, body || {});
      return { ...COMPANY, officeLocations: OFFICE_LOCATIONS, locations: OFFICE_LOCATIONS };
    }
    // Desain aplikasi (APK) per lokasi (B67) — mode pratinjau.
    if (p === 'admin/branding') {
      const items = OFFICE_LOCATIONS.map((l) => ({
        locationId: l.id, locationName: l.name, address: l.address || null, isDefault: !!l.isDefault,
        branding: BRANDING[l.id] || null,
        effective: Object.assign({}, BRANDING_DEFAULTS, BRANDING[l.id] || {}),
      }));
      return { items, locations: items, defaults: BRANDING_DEFAULTS };
    }
    if (p.startsWith('admin/branding/')) {
      const parts = p.split('/');
      const locId = parts[2];
      const field = parts[3];
      if (field) { if (BRANDING[locId]) { if (field === 'logo') { BRANDING[locId].logoUrl = null; BRANDING[locId].logoBase64 = null; } if (field === 'logoWhite') { BRANDING[locId].logoWhiteUrl = null; BRANDING[locId].logoWhiteBase64 = null; } if (field === 'header') BRANDING[locId].headerImageUrl = null; if (field === 'splash') BRANDING[locId].splashImageUrl = null; if (field === 'login') BRANDING[locId].loginImageUrl = null; } return { ok: true, message: 'Gambar dihapus (pratinjau).' }; }
      if (method === 'PUT') { BRANDING[locId] = Object.assign({}, BRANDING[locId] || {}, body || {}); return { ok: true, message: 'Desain tersimpan (pratinjau).', data: BRANDING[locId] }; }
      return { locationId: locId, effective: Object.assign({}, BRANDING_DEFAULTS, BRANDING[locId] || {}), data: Object.assign({}, BRANDING_DEFAULTS, BRANDING[locId] || {}) };
    }
    if (p === 'admin/settings') {
      if (method === 'PUT') { if (body && body.employeeDefaultPassword) TEMP_SETTINGS.employeeDefaultPassword = body.employeeDefaultPassword; return { ok: true, message: 'Pengaturan tersimpan (pratinjau).' }; }
      return { employeeDefaultPassword: TEMP_SETTINGS.employeeDefaultPassword };
    }
    if (p === 'admin/employees') {
      if (method === 'POST') {
        const id = 'e' + (EMPLOYEES.length + 1);
        EMPLOYEES.push({ id, employeeCode: body.employeeCode, fullName: body.fullName, position: body.position || '', phone: body.phone || '', active: true, shiftId: body.shiftId || null, avatarColor: '#036D19', officeLocationId: body.officeLocationId || null });
        EMP_ROLES[id] = Array.isArray(body.roles) ? body.roles : [];
      }
      return { items: empList(), employees: empList() };
    }
    if (p.startsWith('admin/employees/')) {
      const id = p.split('/')[2];
      const e = EMPLOYEES.find((x) => x.id === id);
      if (p.endsWith('/reset-password')) return { ok: true, defaultPassword: 'abc123456' };
      if (method === 'DELETE') { const idx = EMPLOYEES.indexOf(e); if (idx >= 0) EMPLOYEES.splice(idx, 1); delete EMP_ROLES[id]; return { hard: true }; }
      if (e && body) { ['fullName', 'position', 'phone', 'active', 'shiftId'].forEach((k) => { if (k in body) e[k] = body[k]; }); if ('officeLocationId' in body) e.officeLocationId = body.officeLocationId || null; if (Array.isArray(body.roles)) EMP_ROLES[id] = body.roles; }
      return { ok: true };
    }
    if (p === 'admin/shifts') {
      if (method === 'POST') SHIFTS.push({ id: 'sh' + (SHIFTS.length + 1), name: body.name, startTime: body.startTime, endTime: body.endTime, color: body.color || null, active: body.active !== false, officeLocationId: body.officeLocationId || null });
      return { items: shiftList(), shifts: shiftList() };
    }
    if (p.startsWith('admin/shifts/')) {
      const id = p.split('/')[2];
      const s = SHIFTS.find((x) => x.id === id);
      if (method === 'DELETE') { const i = SHIFTS.indexOf(s); if (i >= 0) SHIFTS.splice(i, 1); return { ok: true }; }
      if (s && body) { if ('officeLocationId' in body) s.officeLocationId = body.officeLocationId || null; Object.assign(s, body); }
      return { ok: true };
    }
    if (p === 'admin/schedule') {
      if (method === 'PUT') return { ok: true };
      return schedule(q.weekStart);
    }
    if (p === 'admin/schedule/fill-default') {
      // Pratinjau: hitung slot yang akan diisi (Senin–Sabtu dari shift default)
      const workdays = 6;
      let n = 0;
      EMPLOYEES.filter((e) => e.active).forEach((e) => { if (e.shiftId) n += workdays; });
      return { ok: true, written: n };
    }
    if (p === 'admin/schedule/copy-week') {
      // Pratinjau: asumsikan menyalin pola minggu lalu
      const workdays = 6;
      return { ok: true, written: EMPLOYEES.filter((e) => e.active).length * workdays };
    }
    if (p === 'admin/schedule/import') {
      // Pratinjau: hitung slot dari matriks { name, days:{iso:code} }
      const rows = (body && body.rows) || [];
      let count = 0;
      rows.forEach((r) => { count += Object.keys(r.days || {}).length; });
      return { ok: true, count, matched: rows.length, unmatched: [] };
    }
    if (p === 'admin/office-locations') {
      if (method === 'POST') {
        const id = 'loc' + (OFFICE_LOCATIONS.length + 1);
        if (body && body.isDefault) OFFICE_LOCATIONS.forEach((l) => { l.isDefault = false; });
        OFFICE_LOCATIONS.push({ id, name: body.name || 'Lokasi Baru', address: body.address || '', latitude: Number(body.latitude) || 0, longitude: Number(body.longitude) || 0, radiusMeters: Number(body.radiusMeters) || 100, minimumLocationAccuracyMeters: Number(body.minimumLocationAccuracyMeters) || 80, isDefault: !!body.isDefault, active: true });
        return { id, message: 'Lokasi ditambahkan' };
      }
      return officeLocationsResponse();
    }
    if (p.startsWith('admin/office-locations/')) {
      const id = p.split('/')[2];
      const l = OFFICE_LOCATIONS.find((x) => x.id === id);
      if (method === 'DELETE') { const i = OFFICE_LOCATIONS.indexOf(l); if (i >= 0) OFFICE_LOCATIONS.splice(i, 1); EMPLOYEES.forEach((e) => { if (e.officeLocationId === id) e.officeLocationId = null; }); return { message: 'Lokasi dihapus' }; }
      if (l && body) {
        if (body.isDefault) OFFICE_LOCATIONS.forEach((x) => { x.isDefault = false; });
        ['name', 'address'].forEach((k) => { if (k in body) l[k] = body[k]; });
        ['latitude', 'longitude', 'radiusMeters', 'minimumLocationAccuracyMeters'].forEach((k) => { if (k in body) l[k] = Number(body[k]); });
        if ('isDefault' in body) l.isDefault = !!body.isDefault;
      }
      return { message: 'Lokasi diperbarui' };
    }
    // B75: pengaturan per lokasi (pratinjau).
    if (p === 'admin/location-settings') {
      const items = OFFICE_LOCATIONS.map((l) => ({
        locationId: l.id, locationName: l.name, isDefault: !!l.isDefault,
        lateGraceMinutes: locSettingsEff(l.id).lateGraceMinutes,
        timezone: locSettingsEff(l.id).timezone,
        gpsDriftToleranceMeters: locSettingsEff(l.id).gpsDriftToleranceMeters,
        minimumAccuracyMeters: locSettingsEff(l.id).minimumAccuracyMeters,
        overrides: locSettingsEff(l.id).overrides,
      }));
      return { items, locations: items };
    }
    if (p.startsWith('admin/location-settings/')) {
      const locId = p.split('/')[2];
      if (method === 'DELETE') { delete LOCATION_SETTINGS[locId]; return { ok: true, message: 'Pengaturan lokasi dikembalikan ke bawaan perusahaan (pratinjau).' }; }
      if (method === 'PUT') {
        const b = body || {};
        LOCATION_SETTINGS[locId] = {
          lateGraceMinutes: b.lateGraceMinutes === '' || b.lateGraceMinutes == null ? null : Number(b.lateGraceMinutes),
          timezone: b.timezone || null,
          gpsDriftToleranceMeters: b.gpsDriftToleranceMeters === '' || b.gpsDriftToleranceMeters == null ? null : Number(b.gpsDriftToleranceMeters),
          minimumAccuracyMeters: b.minimumAccuracyMeters === '' || b.minimumAccuracyMeters == null ? null : Number(b.minimumAccuracyMeters),
        };
        return { ok: true, message: 'Pengaturan lokasi disimpan (pratinjau).', data: locSettingsEff(locId) };
      }
      return locSettingsEff(locId);
    }
    if (p === 'admin/location-setup') {
      const items = OFFICE_LOCATIONS.map((l) => {
        const eff = locSettingsEff(l.id);
        return {
          locationId: l.id, locationName: l.name, address: l.address || null, isDefault: !!l.isDefault,
          radiusMeters: l.radiusMeters, minimumAccuracyMeters: eff.minimumAccuracyMeters,
          lateGraceMinutes: eff.lateGraceMinutes, timezone: eff.timezone,
          gpsDriftToleranceMeters: eff.gpsDriftToleranceMeters,
          shiftCount: SHIFTS.filter((s) => s.officeLocationId === l.id).length,
          employeeCount: EMPLOYEES.filter((e) => e.officeLocationId === l.id && e.active).length,
          overrides: eff.overrides,
        };
      });
      return { items, locations: items };
    }
    if (p.startsWith('admin/location-setup/') && p.endsWith('/apply')) {
      const locId = p.split('/')[2];
      const shiftId = body && body.defaultShiftId ? String(body.defaultShiftId) : null;
      let n = 0;
      if (shiftId) EMPLOYEES.forEach((e) => { if (e.officeLocationId === locId && e.active) { e.shiftId = shiftId; n++; } });
      return { ok: true, updated: n, message: n > 0 ? `Shift default diterapkan ke ${n} karyawan (pratinjau)` : 'Tidak ada perubahan' };
    }
    if (p === 'admin/employees' && method === 'POST') {
      // (ditangani di blok admin/employees di bawah — tetap simpan field lokasi)
    }
    if (p.startsWith('admin/employees/') && p.endsWith('/office')) {
      const id = p.split('/')[2];
      const e = EMPLOYEES.find((x) => x.id === id);
      if (e) e.officeLocationId = (body && body.officeLocationId) || null;
      return { message: 'Lokasi karyawan diperbarui' };
    }
    if (p === 'admin/complaints') {
      return { items: COMPLAINTS, stats: complaintStats() };
    }
    if (p.startsWith('admin/complaints/')) {
      const id = p.split('/')[2];
      const c = COMPLAINTS.find((x) => x.id === id);
      if (method === 'DELETE') { const i = COMPLAINTS.indexOf(c); if (i >= 0) COMPLAINTS.splice(i, 1); return { ok: true }; }
      if (c && body) { c.status = body.status || c.status; c.adminNote = body.adminNote !== undefined ? body.adminNote : c.adminNote; }
      return { ok: true };
    }
    if (p === 'admin/attendance') return attendance(q.date || today);
    if (p === 'admin/hr-dashboard') {
      const hdToday = q.date || today;
      const totalEmp = EMPLOYEES.filter((e) => e.active).length || 1;
      const hadir = Math.max(0, totalEmp - 1);
      const trend = [];
      for (let i = 29; i >= 0; i--) {
        const d = new Date(Date.now() - i * 864e5);
        const iso = d.toISOString().slice(0, 10);
        const p = Math.max(1, Math.round(totalEmp * (0.72 + 0.22 * Math.abs(Math.sin(i * 1.7)))));
        const l = Math.max(0, Math.round(p * (0.08 + 0.18 * Math.abs(Math.cos(i * 1.3)))));
        trend.push({ date: iso, present: Math.min(p, totalEmp), late: Math.min(l, p), absent: Math.max(0, totalEmp - p) });
      }
      const sumPresent = trend.reduce((a, x) => a + x.present, 0);
      const pendL = LEAVES.filter((x) => x.status === 'PENDING');
      const pendO = OVERTIMES.filter((x) => x.status === 'PENDING');
      const apprMin = OVERTIMES.filter((x) => x.status === 'APPROVED').reduce((a, x) => a + (x.durationMinutes || 0), 0);
      const pendMin = pendO.reduce((a, x) => a + (x.durationMinutes || 0), 0);
      const pendingItems = [
        ...pendL.slice(0, 4).map((x) => ({ id: x.id, kind: 'LEAVE', fullName: x.fullName, employeeCode: x.employeeCode, avatarColor: x.avatarColor, label: x.category, startDate: x.startDate, endDate: x.endDate, reason: x.reason, createdAt: x.createdAt || new Date().toISOString() })),
        ...pendO.slice(0, 4).map((x) => ({ id: x.id, kind: 'OVERTIME', fullName: x.fullName, employeeCode: x.employeeCode, avatarColor: x.avatarColor, label: durLabelMock(x.durationMinutes) + ' • ' + (x.startTime || '') + '→' + (x.endTime || ''), startDate: x.date, endDate: x.date, reason: x.reason, createdAt: x.createdAt || new Date().toISOString() })),
      ];
      const topLate = EMPLOYEES.slice(0, 5).map((e, i) => ({ employeeId: e.id, employeeCode: e.employeeCode, fullName: e.fullName, position: e.position, avatarColor: e.avatarColor, lateMinutes: 90 - i * 12, lateCount: 6 - i }));
      return {
        date: hdToday,
        range: { from: trend[0].date, to: hdToday },
        kpi: { totalEmployees: totalEmp, hadir, terlambat: Math.max(0, totalEmp - 2), totalLateMinutes: 128, alfa: Math.max(0, totalEmp - hadir), libur: 1, absentRate: Math.round((hadir / totalEmp) * 100) },
        pending: { leaves: pendL.length, overtimes: pendO.length, total: pendL.length + pendO.length },
        overtime: { approvedMinutes: apprMin, pendingMinutes: pendMin, approvedCount: OVERTIMES.filter((x) => x.status === 'APPROVED').length, pendingCount: pendO.length },
        leave: { approvedDays: 12 },
        avgPresent30: Math.round((sumPresent / (totalEmp * 30)) * 100),
        trend,
        pendingItems,
        topLate,
      };
    }
    if (p === 'admin/report') return report(q.from, q.to);
    if (p === 'admin/pending-counts') {
      const leaves = LEAVES.filter((x) => x.status === 'PENDING').length;
      const overtimes = OVERTIMES.filter((x) => x.status === 'PENDING').length;
      const complaints = COMPLAINTS.filter((x) => x.status === 'BARU').length;
      return { leaves, overtimes, complaints, total: leaves + overtimes + complaints, ts: new Date().toISOString() };
    }
    if (p === 'admin/overtimes') return { items: OVERTIMES, overtimes: OVERTIMES };
    if (p.startsWith('admin/overtimes/')) {
      const id = p.split('/')[2];
      const ot = OVERTIMES.find((x) => x.id === id);
      if (ot && body) { ot.status = body.status || ot.status; ot.decisionNote = body.note || null; }
      return { ok: true };
    }
    if (p === 'admin/leaves') return { items: LEAVES, leaves: LEAVES };
    if (p.startsWith('admin/leaves/') && p.endsWith('/attachment')) {
      return { attachmentBase64: '', attachmentType: 'image/jpeg' };
    }
    if (p.startsWith('admin/leaves/')) {
      const id = p.split('/')[2];
      const lv = LEAVES.find((x) => x.id === id);
      if (lv && body) { lv.status = body.status || lv.status; lv.decisionNote = body.note || null; }
      return { ok: true };
    }
    if (p === 'admin/releases') {
      if (method === 'POST') {
        RELEASES.forEach((r) => { r.active = false; });
        RELEASES.unshift({ id: 'rel' + (RELEASES.length + 1), versionName: body.versionName, versionCode: body.versionCode, apkUrl: body.apkUrl, mandatory: !!body.mandatory, notes: body.notes || null, active: true, downloadCount: 0, createdAt: today + 'T00:00:00Z' });
      }
      return { items: RELEASES, releases: RELEASES };
    }
    if (p.startsWith('admin/releases/')) {
      const id = p.split('/')[2];
      const i = RELEASES.findIndex((x) => x.id === id);
      if (i >= 0) RELEASES.splice(i, 1);
      return { ok: true };
    }
    /* --- Alat Developer (Paket B + C11) — data contoh --- */
    if (p === 'admin/system-status') {
      return {
        ok: true, serverTime: new Date().toISOString(), dbLatencyMs: 42, uptimeAcceptable: true,
        api: { service: 'absensiku-api', version: '0.9.22' },
        employees: { total: EMPLOYEES.length, active: EMPLOYEES.filter((e) => e.active).length },
        devices: { total: EMPLOYEES.length, employees: EMPLOYEES.length, revoked: 0, recent: EMPLOYEES.length },
        todayAttendance: Math.max(1, EMPLOYEES.length - 1),
        pendingLeaves: LEAVES.filter((x) => x.status === 'PENDING').length,
        pendingOvertimes: OVERTIMES.filter((x) => x.status === 'PENDING').length,
        latestRelease: RELEASES[0] ? { versionName: RELEASES[0].versionName, versionCode: RELEASES[0].versionCode, active: RELEASES[0].active } : null,
        audit: { total: 12, lastAction: 'FLAGS_UPDATE', lastActor: 'Developer', lastAt: new Date().toISOString() },
      };
    }
    if (p === 'admin/audit') {
      if (method === 'DELETE') return { ok: true };
      return { items: [
        { id: 'a1', actorName: 'Developer', actorRole: 'DEV', action: 'FLAGS_UPDATE', target: null, detail: 'attendance_photo=ON', ip: '103.20.1.5', createdAt: new Date().toISOString() },
        { id: 'a2', actorName: 'Developer', actorRole: 'DEV', action: 'BROADCAST_SEND', target: 'Libur nasional', detail: 'Pengumuman dikirim ke ' + EMPLOYEES.length + ' karyawan', ip: '103.20.1.5', createdAt: new Date(Date.now() - 3600e3).toISOString() },
        { id: 'a3', actorName: 'Developer', actorRole: 'DEV', action: 'RELEASE_CREATE', target: '0.9.22', detail: 'Rilis aplikasi dipublikasikan', ip: '103.20.1.5', createdAt: new Date(Date.now() - 86400e3).toISOString() },
      ] };
    }
    if (p === 'admin/broadcasts') {
      return { items: (BROADCASTS || []), broadcasts: (BROADCASTS || []) };
    }
    if (p === 'admin/broadcast') {
      if (method === 'POST') { BROADCASTS.unshift({ id: 'bc' + (BROADCASTS.length + 1), title: body.title, body: body.body, kind: body.kind || 'INFO', readCount: 0, recipients: EMPLOYEES.length, createdAt: new Date().toISOString() }); return { ok: true, recipients: EMPLOYEES.length }; }
      return { ok: true };
    }
    if (p.startsWith('admin/broadcast/')) { const i = BROADCASTS.findIndex((x) => x.id === p.split('/')[2]); if (i >= 0) BROADCASTS.splice(i, 1); return { ok: true }; }
    if (p === 'admin/devices') {
      return { items: EMPLOYEES.map((e, i) => ({ id: 'dv' + (i + 1), deviceKey: 'dev-' + e.employeeCode.toLowerCase(), platform: 'android', employeeId: e.id, employeeCode: e.employeeCode, fullName: e.fullName, avatarColor: e.avatarColor, photoBase64: e.photoBase64 || null, lastLoginAt: new Date().toISOString(), lastSeenAt: new Date().toISOString(), revokedAt: null, appVersionCode: 33, createdAt: today + 'T00:00:00Z' })), devices: [] };
    }
    if (p.startsWith('admin/devices/')) return { ok: true };
    /* --- B9: Konsol Developer --- */
    if (p === 'admin/diagnostics') {
      return {
        ok: true, serverTime: new Date().toISOString(), uptimeSeconds: 4231, env: 'production', nodeVersion: 'v22.0.0', region: 'sin1', apiVersion: '0.9.22',
        db: { latencyMs: 38, queryLatencyMs: 12, poolTotal: 3, poolIdle: 2, poolWaiting: 0 },
        memory: { rssMB: 128, heapUsedMB: 54 },
        counts: { employees: EMPLOYEES.length, devices: EMPLOYEES.length, attendance: 412, leaves: LEAVES.length, overtimes: OVERTIMES.length, notifications: (BROADCASTS || []).length, auditLog: 12, impersonations: (IMPERSONATIONS || []).length },
        activeImpersonations: (IMPERSONATIONS || []).filter((x) => x.active).length,
        recentErrors: [],
      };
    }
    if (p === 'admin/data/repair') {
      const a = (body && body.action) || '';
      if (a === 'recompute-late') return { ok: true, action: a, processed: 128, changed: 6, grace: COMPANY.lateGraceMinutes || 0, message: '128 baris absensi diproses, 6 diperbarui.' };
      if (a === 'backfill-schedule') return { ok: true, action: a, inserted: 42, skipped: 10, message: '42 jadwal baru dibuat, 10 sudah ada.' };
      return { message: 'Aksi tidak dikenal' };
    }
    if (p === 'admin/impersonations') {
      if (method === 'POST') {
        const emp = EMPLOYEES.find((e) => e.id === body.employeeId) || EMPLOYEES[0];
        const it = { id: 'imp' + ((IMPERSONATIONS || []).length + 1), employeeId: emp.id, fullName: emp.fullName, employeeCode: emp.employeeCode, adminName: 'Developer', note: body.note || null, createdAt: new Date().toISOString(), expiresAt: new Date(Date.now() + (body.minutes || 30) * 60000).toISOString(), active: true };
        IMPERSONATIONS.unshift(it);
        return { ok: true, token: 'demo' + Date.now().toString(16), employee: { id: emp.id, fullName: emp.fullName, employeeCode: emp.employeeCode }, expiresAt: it.expiresAt, minutes: body.minutes || 30, viewOnly: true };
      }
      return { items: (IMPERSONATIONS || []) };
    }
    if (p.startsWith('admin/impersonations/')) {
      const id = p.split('/')[2]; const it = (IMPERSONATIONS || []).find((x) => x.id === id); if (it) it.active = false; return { ok: true };
    }
    if (p === 'admin/flags') {
      if (method === 'PUT') { Object.assign(FLAGS, body.flags || {}); return { ok: true, changed: [] }; }
      return { items: FLAG_DEFS.map((f) => ({ key: f.key, label: f.label, description: f.description, enabled: FLAGS[f.key] !== false, updatedBy: 'Developer', updatedAt: new Date().toISOString() })) };
    }
    /* --- B6: Pengguna & Akses --- */
    if (p === 'admin/users') {
      if (method === 'POST') { USERS.push({ id: 'u' + (USERS.length + 1), name: body.name, email: body.email, role: body.role || 'HR', active: true, self: false }); return { ok: true }; }
      return { items: USERS, users: USERS };
    }
    if (p.startsWith('admin/users/')) {
      const id = p.split('/')[2];
      const u = USERS.find((x) => x.id === id);
      if (method === 'DELETE') { const i = USERS.indexOf(u); if (i >= 0) USERS.splice(i, 1); return { ok: true }; }
      if (u && body) { ['name', 'role', 'active'].forEach((k) => { if (k in body) u[k] = body[k]; }); }
      return { ok: true };
    }
    /* --- B11: MODUL OPERASIONAL (Driver/Opname/POS) — data contoh --- */
    if (p.startsWith('ops/')) {
      const tail = p.slice(4);
      if (tail === 'admin/ops/overview') return opsOverview();
      if (tail === 'admin/trips') {
        if (method === 'POST') { OPS_TRIPS.unshift({ id: 'tr' + (OPS_TRIPS.length + 1), code: 'TRP-DEMO-' + (OPS_TRIPS.length + 1), driverName: 'Driver', vehicle: body.vehicle || '', destination: body.destination || '', status: 'ASSIGNED', noteCount: 0, createdAt: new Date().toISOString() }); return { ok: true }; }
        return { items: OPS_TRIPS, trips: OPS_TRIPS };
      }
      if (tail === 'admin/delivery-notes') return { items: OPS_NOTES, notes: OPS_NOTES };
      if (tail.startsWith('admin/delivery-notes/')) return opsNoteDetail(opsBase(tail));
      if (tail === 'admin/opnames') return { items: OPS_OPNAMES, opnames: OPS_OPNAMES };
      if (tail.startsWith('admin/opnames/')) return opsOpnameDetail(opsBase(tail));
      if (tail === 'admin/pos/sales') return { items: OPS_SALES, sales: OPS_SALES, total: OPS_SALES.reduce((a, b) => a + b.total, 0) };
      if (tail.startsWith('admin/pos/sales/')) return opsSaleDetail(opsBase(tail));
      if (tail === 'admin/pos/sessions') return { items: OPS_SESSIONS, sessions: OPS_SESSIONS };
      if (tail === 'admin/pos/summary') return { count: OPS_SALES.length, total: OPS_SALES.reduce((a, b) => a + b.total, 0), cash: 0, nonCash: 0, openSessions: 1 };
      if (tail === 'admin/customers' || tail === 'customers') {
        if (method === 'POST') {
          const id = 'c' + (OPS_CUSTOMERS.length + 1) + Math.floor(Math.random() * 100);
          OPS_CUSTOMERS.push({ id, name: body.name || 'Pelanggan', phone: body.phone || '', tier: body.tier || 'regular', discountPercent: Number(body.discountPercent) || 0, points: 0, active: true });
          return { id, message: 'Pelanggan ditambahkan' };
        }
        return { items: OPS_CUSTOMERS, customers: OPS_CUSTOMERS };
      }
      if (tail.startsWith('admin/customers/') || tail.startsWith('customers/')) {
        const id = opsBase(tail);
        const c = OPS_CUSTOMERS.find((x) => x.id === id);
        if (c) { if (method === 'DELETE') c.active = false; else Object.assign(c, { name: body.name ?? c.name, phone: body.phone ?? c.phone, tier: body.tier ?? c.tier, discountPercent: body.discountPercent ?? c.discountPercent }); }
        return { message: 'ok' };
      }
      if ((tail === 'admin/pos/settings' || tail === 'pos/settings') && method === 'PUT') {
        Object.assign(OPS_SETTINGS, { taxRate: Number(body.taxRate) || 0, taxEnabled: !!body.taxEnabled, splitPaymentEnabled: body.splitPaymentEnabled !== false, lowStockThreshold: parseInt(body.lowStockThreshold, 10) || 5 });
        return { settings: OPS_SETTINGS, message: 'Pengaturan disimpan' };
      }
      if (tail === 'pos/settings' || tail === 'admin/pos/settings') return { settings: OPS_SETTINGS };
      if (tail === 'pos/holds') return { items: [], holds: [] };
      if (tail === 'products/lookup') return { product: OPS_PRODUCTS[0] || null };
      // Kelola barang (katalog) — data contoh yang bisa diubah di mode demo.
      if (tail === 'admin/products') {
        if (method === 'POST') {
          const id = 'pr' + (OPS_PRODUCTS.length + 1) + Math.floor(Math.random() * 100);
          OPS_PRODUCTS.push({ id, sku: body.sku || null, barcode: body.barcode || null, name: body.name || 'Barang Baru', category: body.category || null, unit: body.unit || 'pcs', price: Number(body.price) || 0, cost: Number(body.cost) || 0, stock: Number(body.stock) || 0, minStock: Number(body.minStock) || 0, active: body.active !== false });
          return { id, message: 'Barang ditambahkan' };
        }
        return { items: OPS_PRODUCTS, products: OPS_PRODUCTS };
      }
      if (tail.startsWith('admin/products/') && method === 'PUT') {
        const id = opsBase(tail);
        const p = OPS_PRODUCTS.find((x) => x.id === id);
        if (p) Object.assign(p, { sku: body.sku ?? p.sku, barcode: body.barcode ?? p.barcode, name: body.name ?? p.name, category: body.category ?? p.category, unit: body.unit ?? p.unit, price: body.price ?? p.price, cost: body.cost ?? p.cost, stock: body.stock ?? p.stock, minStock: body.minStock ?? p.minStock, active: typeof body.active === 'boolean' ? body.active : p.active });
        return { message: 'Barang diperbarui' };
      }
      if (tail.startsWith('admin/products/') && method === 'DELETE') {
        const id = opsBase(tail);
        const i = OPS_PRODUCTS.findIndex((x) => x.id === id);
        if (i >= 0) OPS_PRODUCTS.splice(i, 1);
        return { message: 'Barang dihapus' };
      }
      // Rute karyawan (aplikasi) — dipakai bila perlu pratinjau.
      if (tail === 'products') return { items: OPS_PRODUCTS, products: OPS_PRODUCTS };
      if (tail === 'opnames') return { items: OPS_OPNAMES, opnames: OPS_OPNAMES };
      if (tail === 'pos/session') return { session: OPS_SESSIONS.find((s) => s.status === 'OPEN') || null };
      if (tail === 'pos/summary') return { count: OPS_SALES.length, total: OPS_SALES.reduce((a, b) => a + b.total, 0), cash: 0, nonCash: 0 };
      return {};
    }
    return {};
  }

  window.__MOCK__ = window.__MOCK__ || false;
  window.MOCKAPI = {
    isDemo: () => !!window.__MOCK__,
    enable: () => { window.__MOCK__ = true; },
    disable: () => { window.__MOCK__ = false; },
    route: (path, opts) => Promise.resolve(route(path, opts)),
  };
})();
