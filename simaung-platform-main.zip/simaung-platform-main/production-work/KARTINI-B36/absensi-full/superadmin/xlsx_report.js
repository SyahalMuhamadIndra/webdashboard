/* =========================================================================
 * xlsx_report.js — pembuat berkas .xlsx ASLI (OpenXML) untuk laporan
 * absensi Simaung Corporation. Memakai JSZip (window.JSZip / global.JSZip).
 *
 * Menghasilkan objek JSZip; pemanggil menjalankan .generateAsync() lalu
 * mengunduhnya sebagai Blob. Dapat diuji di Node (JSZip disuntik global).
 *
 * Desain (v2, rapi & profesional):
 *   - Kop: logo (gambar asli) + nama toko + subjudul di kiri, periode di kanan.
 *   - Kartu ringkasan (KPI) 4 kolom data.
 *   - Tabel: No | Nama | Hari Hadir | Lembur (Jam) | Izin (Hari) | Keterlambatan (menit)
 *   - Header tabel rata-tengah, wrap text, tinggi baris cukup.
 *   - Footer cetak.
 * ========================================================================= */

function xlsxEsc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function xlsxColLetter(n) {
  let s = '';
  n += 1;
  while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
  return s;
}

/* ---- Nomor format bawaan Excel ---- */
const FMT = { GENERAL: 0, TEXT: 49 };
/* Warna aksen */
const C_GREEN = '036D19';
const C_GREEN_DARK = '0A3D14';
const C_ORANGE = 'F85800';
const C_INK = '1F2937';
const C_MUTED = '6B7280';
const C_BORDER = 'D8E3D6';
const C_KPI_BG = 'F3F7F2';
const C_HEAD_BG = C_GREEN;

/**
 * @param {{items:Array, summary:Object, fromLabel:string, toLabel:string,
 *          printedAt:string, logoDataUrl?:string, storeName?:string, subtitle?:string,
 *          storeAddress?:string}} o
 * @returns {Promise<Object>} objek JSZip
 */
async function buildXlsxZip(o) {
  const JSZipRef = (typeof JSZip !== 'undefined') ? JSZip : (typeof globalThis !== 'undefined' ? globalThis.JSZip : null);
  if (!JSZipRef) throw new Error('JSZip tidak tersedia');

  const items = o.items || [];
  const summary = o.summary || {};
  const storeName = o.storeName || 'SIMAUNG CORPORATION';
  const subtitle = o.subtitle || 'Laporan Absensi Karyawan';
  const storeAddress = o.storeAddress ||
    'Jl. R.A. Kartini No.08, RT.001/RW.006, Regol Wetan, Kec. Sumedang Sel., Kabupaten Sumedang, Jawa Barat 45311';
  const logo = o.logoDataUrl || '';
  const jamLembur = (m) => Math.round(((m || 0) / 60) * 100) / 100;

  /* ===== Gaya (cellXfs index) =====
     0 = default
     1 = brand (nama toko, 16 bold hijau)
     2 = sub   (subjudul, 10 abu)
     3 = period-label (9.5 abu, kanan)
     4 = period-value (11 bold, kanan)
     5 = kpi-label (9.5 abu, tengah)
     6 = kpi-value (14 bold hijau, tengah)
     7 = table-head (11 bold putih, tengah, wrap, bg hijau)
     8 = text (11, kiri, wrap)
     9 = num (11, kanan kecil → dipakai angka)
     10 = center (11, tengah)
     11 = center-bold-orange (keterlambatan > 0)
     12 = footer (9 abu)
     13 = kpi-box (border hijau muda, bg) untuk sel label+value container
     14 = section (10 bold hijau, kiri)
     15 = addr (9 abu, rata kiri, wrap) — alamat toko di sisi kanan Ringkasan
     16 = pin (10 bold orange, rata tengah) — ikon pin 🏠 alamat
  */
  const stylesXml =
`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="13">
  <font><sz val="11"/><color rgb="FF${C_INK}"/><name val="Calibri"/></font>
  <font><b/><sz val="18"/><color rgb="FF${C_GREEN_DARK}"/><name val="Calibri"/></font>
  <font><sz val="10.5"/><color rgb="FF${C_MUTED}"/><name val="Calibri"/></font>
  <font><sz val="9"/><color rgb="FF${C_MUTED}"/><name val="Calibri"/></font>
  <font><b/><sz val="10.5"/><color rgb="FF${C_INK}"/><name val="Calibri"/></font>
  <font><sz val="9.5"/><color rgb="FF${C_MUTED}"/><name val="Calibri"/></font>
  <font><b/><sz val="14"/><color rgb="FF${C_GREEN}"/><name val="Calibri"/></font>
  <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
  <font><sz val="11"/><color rgb="FF${C_INK}"/><name val="Calibri"/></font>
  <font><b/><sz val="11"/><color rgb="FF${C_ORANGE}"/><name val="Calibri"/></font>
  <font><b/><sz val="11"/><color rgb="FF${C_GREEN_DARK}"/><name val="Calibri"/></font>
  <font><sz val="9"/><color rgb="FF${C_MUTED}"/><name val="Calibri"/></font>
  <font><b/><sz val="10"/><color rgb="FF${C_ORANGE}"/><name val="Calibri"/></font>
</fonts>
<fills count="5">
  <fill><patternFill patternType="none"/></fill>
  <fill><patternFill patternType="gray125"/></fill>
  <fill><patternFill patternType="solid"><fgColor rgb="FF${C_KPI_BG}"/><bgColor indexed="64"/></patternFill></fill>
  <fill><patternFill patternType="solid"><fgColor rgb="FF${C_HEAD_BG}"/><bgColor indexed="64"/></patternFill></fill>
  <fill><patternFill patternType="solid"><fgColor rgb="FF${C_ORANGE}"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="4">
  <border><left/><right/><top/><bottom/><diagonal/></border>
  <border><left style="thin"><color rgb="FF${C_BORDER}"/></left><right style="thin"><color rgb="FF${C_BORDER}"/></right><top style="thin"><color rgb="FF${C_BORDER}"/></top><bottom style="thin"><color rgb="FF${C_BORDER}"/></bottom><diagonal/></border>
  <border><left style="thin"><color rgb="FF${C_GREEN}"/></left><right style="thin"><color rgb="FF${C_GREEN}"/></right><top style="thin"><color rgb="FF${C_GREEN}"/></top><bottom style="thin"><color rgb="FF${C_GREEN}"/></bottom><diagonal/></border>
  <border><left/><right/><top/><bottom style="medium"><color rgb="FF${C_GREEN}"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="19">
  <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center"/></xf>
  <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
  <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
  <xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
  <xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
  <xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
  <xf numFmtId="0" fontId="6" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
  <xf numFmtId="0" fontId="7" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
  <xf numFmtId="0" fontId="8" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>
  <xf numFmtId="0" fontId="8" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
  <xf numFmtId="0" fontId="8" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
  <xf numFmtId="0" fontId="9" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
  <xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
  <xf numFmtId="0" fontId="5" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
  <xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
  <xf numFmtId="0" fontId="10" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
  <xf numFmtId="0" fontId="0" fillId="0" borderId="3" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>
  <xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf>
  <xf numFmtId="0" fontId="12" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

  /* ===== Kolom: A(No) B(Nama) C(Hari) D(Lembur) E(Izin) F(Terlambat) ===== */
  const cols = [
    { w: 11 },    // A No (lebar penuh agar logo + nomor rapi, tidak menimpa nama)
    { w: 25 },    // B Nama
    { w: 13.5 },  // C Hari Hadir (muat label KPI "Total Hari Hadir" 1 baris)
    { w: 12 },    // D Lembur (Jam)
    { w: 11 },    // E Izin (Hari)
    { w: 23 },    // F Keterlambatan (menit)
  ];

  const cellRef = (r, ci) => xlsxColLetter(ci) + r;
  const cell = (r, ci, s, v, asText) => {
    const ref = cellRef(r, ci);
    if (v == null || v === '') return `<c r="${ref}" s="${s}"/>`;
    return asText
      ? `<c r="${ref}" s="${s}" t="inlineStr"><is><t xml:space="preserve">${xlsxEsc(v)}</t></is></c>`
      : `<c r="${ref}" s="${s}"><v>${v}</v></c>`;
  };
  const rowX = (r, cells, ht) =>
    `<row r="${r}"${ht ? ` ht="${ht}" customHeight="1"` : ''}>${cells.join('')}</row>`;

  const rows = [];
  let i = 1;

  /* ---- Baris 1-2: KOP (logo di A1:A2, nama+subjudul di B1/B2) ---- */
  rows.push(rowX(1, [
    cell(1, 0, 0, ''),                    // A1 (tempat logo, merge A1:A2)
    cell(1, 1, 1, storeName, true),       // B1 nama toko
    cell(1, 2, 0, ''), cell(1, 3, 0, ''), cell(1, 4, 0, ''),
    cell(1, 5, 3, 'Periode Laporan', true), // F1
  ], 22));
  rows.push(rowX(2, [
    cell(2, 0, 0, ''),
    cell(2, 1, 2, subtitle, true),        // B2 subjudul
    cell(2, 2, 0, ''), cell(2, 3, 0, ''), cell(2, 4, 0, ''),
    cell(2, 5, 4, `${o.fromLabel} – ${o.toLabel}`, true), // F2 nilai periode
  ], 20));
  /* Baris 3: garis pembatas hijau elegan di bawah kop */
  rows.push(rowX(3, [0, 1, 2, 3, 4, 5].map((c) => cell(3, c, 16, '')), 7));

  /* ---- Baris 4: judul section "Ringkasan" + ALAMAT TOKO di sisi kanan ---- */
  rows.push(rowX(4, [
    cell(4, 0, 14, 'Ringkasan', true),
    cell(4, 1, 17, storeAddress, true), // B4:F4 (merge) rata kanan, abu, wrap
    cell(4, 2, 0, ''), cell(4, 3, 0, ''), cell(4, 4, 0, ''), cell(4, 5, 0, ''),
  ], 30));

  /* ---- Baris 5-6: kartu KPI (label + nilai) ---- */
  const kpis = [
    ['Total Karyawan', `${summary.totalEmp || 0} orang`],
    ['Total Hari Hadir', `${summary.totalDays || 0} hari`],
    ['Total Lembur', `${jamLembur(summary.totalLembur)} jam`],
    ['Total Izin', `${summary.totalIzin || 0} hari`],
    ['Total Keterlambatan', `${summary.totalLate || 0} menit`],
  ];
  const kpiCellsA = [], kpiCellsB = [];
  // Mulai dari kolom B (1)..: 4 kartu (B..E) agar rapi dalam lebar laporan.
  const kpiStart = 1;
  kpis.forEach((k, idx) => {
    const ci = kpiStart + idx;
    kpiCellsA.push(cell(5, ci, 5, k[0], true));
    kpiCellsB.push(cell(6, ci, 6, k[1], true));
  });
  rows.push(rowX(5, [cell(5, 0, 0, '')].concat(kpiCellsA), 26));
  rows.push(rowX(6, [cell(6, 0, 0, '')].concat(kpiCellsB), 26));
  /* Baris 7: jarak */
  rows.push(rowX(7, [cell(7, 0, 0, ''), cell(7, 1, 0, ''), cell(7, 2, 0, ''), cell(7, 3, 0, ''), cell(7, 4, 0, ''), cell(7, 5, 0, '')], 8));

  /* ---- Baris 8: header tabel ---- */
  const headers = ['No', 'Nama Karyawan', 'Hari Hadir', 'Lembur (Jam)', 'Izin (Hari)', 'Keterlambatan (menit)'];
  rows.push(rowX(8, headers.map((h, ci) => cell(8, ci, 7, h, true)), 30));

  /* ---- Data ---- */
  const dataStart = 9;
  items.forEach((it, idx) => {
    const r = dataStart + idx;
    const late = it.totalLateMinutes || 0;
    rows.push(rowX(r, [
      cell(r, 0, 10, idx + 1, false),
      cell(r, 1, 8, it.fullName || '', true),
      cell(r, 2, 10, it.daysPresent || 0, false),
      cell(r, 3, 9, jamLembur(it.overtimeApprovedMinutes), false),
      cell(r, 4, 10, it.leaveApprovedDays || 0, false),
      cell(r, 5, late > 0 ? 11 : 10, late, false),
    ], 16));
  });
  let lastData = dataStart + Math.max(1, items.length) - 1;
  if (!items.length) {
    rows.push(rowX(dataStart, [cell(dataStart, 0, 10, '-', true), cell(dataStart, 1, 8, 'Tidak ada data pada periode ini.', true), cell(dataStart, 2, 0, ''), cell(dataStart, 3, 0, ''), cell(dataStart, 4, 0, ''), cell(dataStart, 5, 0, '')], 16));
    lastData = dataStart;
  }

  /* ---- Footer ---- */
  const footR = lastData + 2;
  rows.push(rowX(footR, [cell(footR, 0, 12, `Dicetak: ${o.printedAt}  •  Sistem Absensi Simaung Corporation`, true)], 14));

  const lastRow = footR;

  /* ===== Worksheet ===== */
  const mergeXml = logo
    ? '<mergeCells count="2"><mergeCell ref="A1:A2"/><mergeCell ref="B4:F4"/></mergeCells>'
    : '<mergeCells count="1"><mergeCell ref="B4:F4"/></mergeCells>';
  const sheetXml =
`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>
<dimension ref="A1:F${lastRow}"/>
<sheetViews><sheetView tabSelected="1" workbookViewId="0" showGridLines="0"><selection activeCell="A1" sqref="A1"/></sheetView></sheetViews>
<sheetFormatPr defaultRowHeight="15"/>
<cols>${cols.map((c, idx) => `<col min="${idx + 1}" max="${idx + 1}" width="${c.w}" customWidth="1"/>`).join('')}</cols>
<sheetData>${rows.join('')}</sheetData>
${mergeXml}
<pageMargins left="0.3" right="0.3" top="0.4" bottom="0.4" header="0.2" footer="0.2"/>
<pageSetup orientation="portrait" paperSize="9" fitToWidth="1" fitToHeight="1"/>
${logo ? '<drawing r:id="rId1"/>' : ''}
</worksheet>`;

  /* ===== Logo ke A1 (ukuran pas 2 baris: ~62 px = 595000 EMU) ===== */
  let sheetRels = '';
  let drawingRels = '';
  let drawingXml = '';
  if (logo) {
    const EMU_W = 419100; // ~44px (rasio asli 188x200 dipertahankan)
    const EMU_H = 445851; // ~47px — pas di A1:A2 (2 baris)
    drawingXml =
`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<xdr:oneCellAnchor>
<xdr:from><xdr:col>0</xdr:col><xdr:colOff>47625</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>47625</xdr:rowOff></xdr:from>
<xdr:ext cx="${EMU_W}" cy="${EMU_H}"/>
<xdr:pic>
<xdr:nvPicPr><xdr:cNvPr id="1" name="Logo"/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr>
<xdr:blipFill><a:blip r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>
<xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${EMU_W}" cy="${EMU_H}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr>
</xdr:pic>
<xdr:clientData/>
</xdr:oneCellAnchor>
</xdr:wsDr>`;
    sheetRels =
`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/>
</Relationships>`;
    drawingRels =
`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.png"/>
</Relationships>`;
  }

  const contentTypes =
`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Default Extension="png" ContentType="image/png"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
${logo ? '<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>' : ''}
</Types>`;

  const rootRels =
`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;

  const workbook =
`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="Laporan Absensi" sheetId="1" r:id="rId1"/></sheets>
</workbook>`;

  const wbRels =
`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

  const zip = new JSZipRef();
  zip.file('[Content_Types].xml', contentTypes);
  zip.folder('_rels').file('.rels', rootRels);
  const xl = zip.folder('xl');
  xl.file('workbook.xml', workbook);
  xl.folder('_rels').file('workbook.xml.rels', wbRels);
  xl.file('styles.xml', stylesXml);
  xl.folder('worksheets').file('sheet1.xml', sheetXml);
  if (logo) {
    xl.folder('worksheets').folder('_rels').file('sheet1.xml.rels', sheetRels);
    xl.folder('drawings').folder('_rels').file('drawing1.xml.rels', drawingRels);
    xl.folder('drawings').file('drawing1.xml', drawingXml);
    xl.folder('media').file('image1.png', logo.split(',')[1] || '', { base64: true });
  }
  return zip;
}

if (typeof window !== 'undefined') window.buildXlsxZip = buildXlsxZip;
if (typeof module !== 'undefined' && module.exports) module.exports = { buildXlsxZip };
