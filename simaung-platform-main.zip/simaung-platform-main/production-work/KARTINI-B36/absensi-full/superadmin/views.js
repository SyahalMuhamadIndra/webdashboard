/* Simaung Corporation Superadmin — views.js (5 tab, redesain v0.9.9) */

let DASH_DATE = todayISO();
let MODAL = null;

function openModal(html, opts) {
  closeModal();
  MODAL = document.createElement('div');
  MODAL.className = 'modal-bg';
  const wide = opts && opts.wide ? ' wide' : '';
  MODAL.innerHTML = `<div class="modal${wide}" onclick="event.stopPropagation()">${html}</div>`;
  MODAL.addEventListener('click', closeModal);
  document.body.appendChild(MODAL);
}
function closeModal() { if (MODAL) { MODAL.remove(); MODAL = null; } }
window.openModal = openModal; window.closeModal = closeModal;

/* ============ IKON SVG (pengganti emoji — pasti tampil di semua perangkat) ============ */
const SVG = (p, extra) => `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ${extra || ''}>${p}</svg>`;
const I = {
  pin: SVG('<path d="M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/>'),
  search: SVG('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.2-3.2"/>'),
  compass: SVG('<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5 5-2z"/>'),
  building: SVG('<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M9 8h.01M15 8h.01M9 12h.01M15 12h.01M10 21v-3h4v3"/>'),
  users: SVG('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="3.5"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'),
  check: SVG('<path d="M20 6L9 17l-5-5"/>'),
  trend: SVG('<path d="M3 17l6-6 4 4 8-8"/><path d="M21 7v5h-5"/>'),
  smile: SVG('<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><path d="M9 9h.01M15 9h.01"/>'),
  chart: SVG('<path d="M3 3v18h18"/><rect x="7" y="11" width="3" height="6" rx="1"/><rect x="12.5" y="7" width="3" height="10" rx="1"/><rect x="18" y="13" width="3" height="4" rx="1"/>'),
  list: SVG('<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>'),
  cal: SVG('<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>'),
  clock: SVG('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>'),
  download: SVG('<path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M5 21h14"/>'),
  alert: SVG('<path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9L2.4 18a2 2 0 0 0 1.7 3h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>'),
  info: SVG('<circle cx="12" cy="12" r="9"/><path d="M12 16v-4"/><path d="M12 8h.01"/>'),
  shift: SVG('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>'),
  system: SVG('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>'),
  tool: SVG('<path d="M14.7 6.3a4 4 0 0 0-5.6 5.6l-6 6a1.5 1.5 0 0 0 2.1 2.1l6-6a4 4 0 0 0 5.6-5.6l-2.3 2.3-2.1-2.1z"/>'),
};


/* ============ WARNA SHIFT (konsisten di seluruh UI) ============ */
const SHIFT_COLORS = ['#036D19', '#1D6FB8', '#F85800', '#7A3FB5', '#B8860B', '#0E7490', '#2E8B57', '#B34A6B'];

/* ============ PERAN JABATAN KARYAWAN (B10) ============ */
const ROLE_CATALOG = [
  { key: 'DRIVER', label: 'Driver', desc: 'Tracking perjalanan & surat jalan', tone: 'b-blue' },
  { key: 'PRAMUNIAGA', label: 'Pramuniaga', desc: 'Sistem stock opname', tone: 'b-orange' },
  { key: 'KEPALA_GUDANG', label: 'Kepala Gudang', desc: 'Opname full & crosscek hasil opname', tone: 'b-purple' },
  { key: 'KASIR', label: 'Kasir', desc: 'Sistem POS (kasir)', tone: 'b-green' },
  { key: 'PENJAGA', label: 'Penjaga', desc: 'Jaga lokasi/toko & pantau keamanan', tone: 'b-blue' },
];
function roleLabel(key) { const r = ROLE_CATALOG.find((x) => x.key === key); return r ? r.label : key; }
function roleTone(key) { const r = ROLE_CATALOG.find((x) => x.key === key); return r ? r.tone : 'b-grey'; }
function roleBadges(roles) {
  if (!roles || !roles.length) return '<span class="ttl">—</span>';
  return roles.map((k) => `<span class="badge ${roleTone(k)}" style="font-size:10.5px">${esc(roleLabel(k))}</span>`).join(' ');
}

/* Fasilitas (modul) yang diaktifkan tiap peran — jabatan RANGKAP otomatis
   menggabungkan fasilitas dari seluruh perannya. */
const ROLE_FACILITIES = {
  DRIVER: ['Perjalanan & Tracking', 'Surat Jalan'],
  PRAMUNIAGA: ['Stock Opname'],
  KEPALA_GUDANG: ['Opname Full', 'Crosscek Opname'],
  KASIR: ['POS Kasir'],
  PENJAGA: ['Jaga Lokasi & Keamanan'],
};
function roleFacilities(roles) {
  const out = [];
  (roles || []).forEach((r) => (ROLE_FACILITIES[r] || []).forEach((f) => { if (!out.includes(f)) out.push(f); }));
  return out;
}
function roleFacilityBadges(roles) {
  const f = roleFacilities(roles);
  if (!f.length) return '<span class="ttl">—</span>';
  return f.map((x) => `<span class="badge" style="font-size:10.5px;background:#EEF3EC;color:#42533F">${esc(x)}</span>`).join(' ');
}
function shiftColor(id) {
  if (!id) return '#8a8f80';
  const s = (SHIFTS || []).find((x) => x.id === id);
  if (s && s.color) return s.color;            // warna tersimpan (B4)
  const i = (SHIFTS || []).findIndex((x) => x.id === id);
  return SHIFT_COLORS[(i >= 0 ? i : Math.abs(hashCode(String(id)))) % SHIFT_COLORS.length];
}
function hashCode(str) { let h = 0; for (let i = 0; i < str.length; i++) { h = (h * 31 + str.charCodeAt(i)) | 0; } return h; }
function shiftById(id) { return (SHIFTS || []).find((s) => s.id === id) || null; }

/* ===================== 3. DASHBOARD ===================== */
function dashRowCard(r) {
  return `
    <div class="mcard">
      <div class="mcard-top">
        <div class="row-user">${avatarHtml(r)}
          <div><b>${esc(r.fullName)}</b><span>${esc(r.employeeCode)}${r.position ? ' • ' + esc(r.position) : ''}</span></div></div>
        ${statusBadge(r.status)}
      </div>
      <div class="mcard-grid">
        <div class="kv"><label>Check-in</label><b>${r.checkInAt ? hhmm(r.checkInAt) : '--:--'}${r.lateMinutes ? ` <span class="ttl">(+${r.lateMinutes}m)</span>` : ''}</b></div>
        <div class="kv"><label>Check-out</label><b>${r.checkOutAt ? hhmm(r.checkOutAt) : '--:--'}</b></div>
        <div class="kv"><label>Shift</label><b>${r.shiftName ? esc(r.shiftName) + (r.shiftStart ? ` ${esc(r.shiftStart)}-${esc(r.shiftEnd || '')}` : '') : '-'}</b></div>
        <div class="kv"><label>Jarak</label><b>${r.checkInDistanceMeters != null ? Math.round(r.checkInDistanceMeters) + ' m' : '-'}</b></div>
        <div class="kv"><label>Skor Wajah</label><b>${r.faceScore != null ? r.faceScore + '%' : '-'}</b></div>
        <div class="kv"><label>Durasi</label><b>${durLabel(r.workMinutes)}</b></div>
      </div>
    </div>`;
}

async function viewDashboard() {
  $('top-actions').innerHTML = `
    <div class="toolbar" style="margin:0">
      <div class="field" style="margin:0">
        <label>Tanggal</label>
        <input type="date" id="dash-date" value="${DASH_DATE}" onchange="dashChange(this.value)">
      </div>
      <button class="btn btn-ghost btn-sm" onclick="route()">Muat Ulang</button>
    </div>`;

  // Ambil data absensi harian + ringkasan HR secara paralel (satu tampilan).
  const [d, hrRes] = await Promise.all([
    api('admin/attendance?date=' + DASH_DATE),
    api('admin/hr-dashboard?date=' + DASH_DATE).catch(() => null),
  ]);
  const s = d.summary || {};
  const rows = d.items || [];
  const hr = hrRes || {};
  const hrKpi = (hr && hr.kpi) || {};
  const hrPending = (hr && hr.pending) || {};
  const hrOt = (hr && hr.overtime) || {};
  const trend = (hr && hr.trend) || [];
  const pendingItems = (hr && hr.pendingItems) || [];
  const topLate = (hr && hr.topLate) || [];

  // KPI memakai ringkasan HR bila tersedia; jika tidak, fallback ke ringkasan harian.
  const kpiTotal = hrKpi.totalEmployees != null ? hrKpi.totalEmployees : (s.total || 0);
  const kpiHadir = hrKpi.hadir != null ? hrKpi.hadir : (s.hadir || 0);
  const kpiTerlambat = hrKpi.terlambat != null ? hrKpi.terlambat : (s.terlambat || 0);
  const kpiAlfa = hrKpi.alfa != null ? hrKpi.alfa : (s.alfa || 0);
  const kpiLibur = hrKpi.libur != null ? hrKpi.libur : (s.libur || 0);
  const attendanceRate = kpiTotal > 0 ? Math.round((kpiHadir / kpiTotal) * 100) : 0;

  $('view').innerHTML = `
    <div class="kpi-grid">
      <div class="kpi">
        <div class="kpi-ic">${I.users}</div>
        <span class="kpi-lb">Karyawan Aktif</span>
        <b>${kpiTotal}</b>
        <small>Hadir <b style="color:var(--brand)">${kpiHadir}</b> • ${attendanceRate}% kehadiran</small>
      </div>
      <div class="kpi o">
        <div class="kpi-ic o">${I.clock}</div>
        <span class="kpi-lb">Terlambat</span>
        <b>${kpiTerlambat}</b>
        <small>Total keterlambatan ${durLabel((hrKpi.totalLateMinutes != null ? hrKpi.totalLateMinutes : 0))}</small>
      </div>
      <div class="kpi">
        <div class="kpi-ic">${I.alert}</div>
        <span class="kpi-lb">Alfa / Belum Absen</span>
        <b>${kpiAlfa}</b>
        <small>Libur terjadwal: ${kpiLibur}</small>
      </div>
      <div class="kpi o">
        <div class="kpi-ic o">${I.check}</div>
        <span class="kpi-lb">Menunggu Persetujuan</span>
        <b>${hrPending.total != null ? hrPending.total : 0}</b>
        <small>Izin ${hrPending.leaves != null ? hrPending.leaves : 0} • Lembur ${hrPending.overtimes != null ? hrPending.overtimes : 0}</small>
      </div>
    </div>

    <div class="grid g2" style="margin-bottom:18px">
      <div class="card" style="margin:0">
        <div class="hr-panel-head">
          <h3 style="margin:0">Tren Kehadiran — 30 Hari</h3>
          <span class="ttl">Rata-rata ${hr.avgPresent30 != null ? hr.avgPresent30 : 0}%</span>
        </div>
        ${hrTrendChart(trend)}
      </div>
      <div class="card" style="margin:0">
        <h3 style="margin-top:0">Ringkasan (30 Hari)</h3>
        <div class="hr-stat-row"><span>Lembur disetujui</span><b style="color:var(--brand)">${durLabel(hrOt.approvedMinutes || 0)}</b></div>
        <div class="hr-stat-row"><span>Lembur menunggu</span><b style="color:var(--accent)">${durLabel(hrOt.pendingMinutes || 0)}</b></div>
        <div class="hr-stat-row"><span>Pengajuan lembur</span><b>${hrOt.approvedCount || 0} disetujui • ${hrOt.pendingCount || 0} menunggu</b></div>
        <div class="hr-stat-row"><span>Izin disetujui</span><b>${hr.leave ? (hr.leave.approvedDays || 0) : 0} hari</b></div>
        <div class="actions" style="margin-top:12px">
          <button class="btn btn-sm btn-primary" onclick="go('izin')">Tinjau Izin${hrPending.leaves ? ' (' + hrPending.leaves + ')' : ''}</button>
          <button class="btn btn-sm btn-primary" onclick="go('lembur')">Tinjau Lembur${hrPending.overtimes ? ' (' + hrPending.overtimes + ')' : ''}</button>
        </div>
      </div>
    </div>

    <div class="grid g2" style="margin-bottom:18px">
      <div class="card" style="margin:0">
        <h3 style="margin-top:0">Pengajuan Menunggu (Terbaru)</h3>
        ${pendingItems.length === 0 ? '<div class="empty">Tidak ada pengajuan menunggu. 🎉</div>' : `
        <div class="hr-list">
          ${pendingItems.map((x) => `
            <div class="hr-list-row">
              ${avatarHtml(x)}
              <div class="hr-list-info">
                <b>${esc(x.fullName)}</b>
                <span>${x.kind === 'LEAVE' ? 'Izin: ' + esc(x.label || '') : 'Lembur: ' + esc(x.label || '')}</span>
                <div class="ttl">${esc(x.kind === 'LEAVE' ? dateRange(x.startDate, x.endDate) : dayLabel(x.startDate))} • ${esc(relTime(x.createdAt))}</div>
              </div>
              <button class="btn btn-sm btn-ghost" onclick="go('${x.kind === 'LEAVE' ? 'izin' : 'lembur'}')">Tinjau</button>
            </div>`).join('')}
        </div>`}
      </div>
      <div class="card" style="margin:0">
        <h3 style="margin-top:0">Perlu Perhatian — Keterlambatan (30 hari)</h3>
        ${topLate.length === 0 ? '<div class="empty">Tidak ada keterlambatan tercatat. 👍</div>' : `
        <div class="hr-list">
          ${topLate.map((x, i) => `
            <div class="hr-list-row">
              <span class="hr-rank">${i + 1}</span>
              ${avatarHtml(x)}
              <div class="hr-list-info">
                <b>${esc(x.fullName)}</b>
                <span>${esc(x.position || 'Karyawan')} • ${x.lateCount} kali terlambat</span>
              </div>
              <b style="color:var(--accent);white-space:nowrap">${durLabel(x.lateMinutes)}</b>
            </div>`).join('')}
        </div>`}
      </div>
    </div>

    <div class="card">
      <div class="hr-panel-head">
        <h3 style="margin:0">Absensi Harian — ${esc(dayLabel(DASH_DATE))}</h3>
        <span class="ttl">${rows.length} karyawan</span>
      </div>
      ${rows.length === 0 ? '<div class="empty">Belum ada karyawan.</div>' : `
      <div class="only-desk table-wrap">
        <table>
          <thead><tr><th>Karyawan</th><th>Jabatan</th><th>Shift</th><th>Check-in</th><th>Check-out</th><th>Jarak</th><th>Wajah</th><th>Durasi</th><th>Lembur</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
          ${rows.map((r) => `
            <tr>
              <td><div class="row-user">${avatarHtml(r)}<div><b>${esc(r.fullName)}</b><span>${esc(r.employeeCode)}</span></div></div></td>
              <td>${esc(r.position || '-')}</td>
              <td>${r.shiftName ? `<span class="badge b-green">${esc(r.shiftName)}</span> <span class="ttl">${esc(r.shiftStart || '')}${r.shiftEnd ? '-' + esc(r.shiftEnd) : ''}</span>` : '<span class="ttl">-</span>'}</td>
              <td>${r.checkInAt ? hhmm(r.checkInAt) : '<span class="ttl">--:--</span>'}${r.lateMinutes ? ` <span class="ttl">(+${r.lateMinutes}m)</span>` : ''}</td>
              <td>${r.checkOutAt ? hhmm(r.checkOutAt) : '<span class="ttl">--:--</span>'}</td>
              <td>${r.checkInDistanceMeters != null ? Math.round(r.checkInDistanceMeters) + ' m' : '-'}</td>
              <td>${r.faceScore != null ? r.faceScore + '%' : '-'}</td>
              <td>${durLabel(r.workMinutes)}</td>
              <td>${r.overtimeApprovedMinutes > 0 ? `<b style="color:var(--brand)">${durLabel(r.overtimeApprovedMinutes)}</b>` : '<span class="ttl">-</span>'}${r.overtimePendingCount > 0 ? ` <span class="badge b-orange">${r.overtimePendingCount} menunggu</span>` : ''}</td>
              <td>${statusBadge(r.status)}</td>
              <td>${r.checkInAt ? `<button class="btn btn-sm btn-ghost" onclick="editStatusAbsen('${r.employeeId}','${esc(r.employeeCode)}','${esc(r.fullName)}','${r.status || ''}',${r.lateMinutes || 0})">Ubah</button>` : '<span class="ttl">-</span>'}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="only-mob mlist">${rows.map(dashRowCard).join('')}</div>`}
    </div>`;
}
function dashChange(v) { DASH_DATE = v; route(); }

/**
 * Dialog ubah status absensi karyawan secara MANUAL (koreksi keterlambatan).
 * Memerlukan password SUPERADMIN. Status "Tidak Terlambat" akan menandai
 * absensi sebagai dikoreksi permanen sehingga tidak ditimpa recompute otomatis.
 */
function editStatusAbsen(employeeId, code, name, status, lateMinutes) {
  const isLate = /TERLAMBAT/.test(status);
  const bg = document.createElement('div');
  bg.className = 'dialog-bg';
  bg.innerHTML = `
    <div class="dialog tone-brand" role="dialog" aria-modal="true">
      <span class="dialog-accent"></span>
      <button class="dialog-x" type="button" aria-label="Tutup">&times;</button>
      <div class="dialog-head"><span class="dialog-ic">${I.clock}</span>
        <div class="dialog-tt"><h3>Ubah Status Absensi</h3><p>${esc(name)} • ${esc(code)} • ${esc(dayLabel(DASH_DATE))}</p></div>
      </div>
      <div class="dialog-body">
        <div class="field"><label>Status Kehadiran</label>
          <select id="es-status" class="dlg-input">
            <option value="APPROVED" ${!isLate ? 'selected' : ''}>Tepat Waktu (tidak terlambat)</option>
            <option value="TERLAMBAT" ${isLate ? 'selected' : ''}>Terlambat</option>
          </select>
        </div>
        <div class="field"><label>Menit Keterlambatan</label>
          <input id="es-late" class="dlg-input" type="number" min="0" max="600" value="${Number(lateMinutes) || 0}">
          <div class="ttl">Diisi bila status "Terlambat". Kosongkan/0 untuk tepat waktu.</div>
        </div>
        <div class="field"><label>Password SUPERADMIN</label>
          <input id="es-pass" class="dlg-input" type="password" autocomplete="off" placeholder="Wajib untuk konfirmasi">
        </div>
        <div id="es-msg"></div>
      </div>
      <div class="dialog-actions">
        <button class="btn btn-ghost" type="button" data-act="cancel">Batal</button>
        <button class="btn btn-primary" type="button" data-act="ok">Simpan Perubahan</button>
      </div>
    </div>`;
  // PENTING: kelas "show" WAJIB di elemen .dialog-bg (bukan .dialog) agar dialog
  // terlihat — .dialog-bg default opacity:0 dan hanya .dialog-bg.show yang tampil.
  // Tanpa ini, overlay transparan tetap menutup layar -> halaman tampak "stuck".
  const onKey = (e) => { if (e.key === 'Escape') { e.preventDefault(); close(); } };
  const close = () => {
    document.removeEventListener('keydown', onKey);
    bg.classList.remove('show');
    bg.classList.add('out');
    setTimeout(() => bg.remove(), 180);
  };
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  bg.querySelector('.dialog-x').addEventListener('click', close);
  bg.querySelector('[data-act="cancel"]').addEventListener('click', close);
  bg.querySelector('[data-act="ok"]').addEventListener('click', async () => {
    const st = bg.querySelector('#es-status').value;
    const late = Math.max(0, parseInt(bg.querySelector('#es-late').value, 10) || 0);
    const pass = bg.querySelector('#es-pass').value;
    const msg = bg.querySelector('#es-msg');
    if (!pass) { msg.innerHTML = '<div class="err-box">Masukkan password SUPERADMIN.</div>'; return; }
    const btn = bg.querySelector('[data-act="ok"]'); btn.disabled = true; btn.textContent = 'Menyimpan...';
    try {
      await api('admin/attendance/repair', { method: 'POST', body: {
        employeeId, date: DASH_DATE, mode: 'override',
        status: st === 'TERLAMBAT' ? 'TERLAMBAT' : 'APPROVED',
        lateMinutes: st === 'TERLAMBAT' ? late : 0, password: pass,
      } });
      close();
      toast('Status Diperbarui', 'ok', `Status absensi ${name} berhasil diubah.`);
      route();
    } catch (err) {
      btn.disabled = false; btn.textContent = 'Simpan Perubahan';
      msg.innerHTML = `<div class="err-box">${esc(err.message)}</div>`;
    }
  });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(bg);
  requestAnimationFrame(() => bg.classList.add('show'));
}
window.editStatusAbsen = editStatusAbsen;
function statusBadge(st) {
  if (st === 'HADIR') return '<span class="badge b-green">Hadir</span>';
  if (st === 'TERLAMBAT') return '<span class="badge b-orange">Terlambat</span>';
  if (st === 'BELUM_CHECKOUT') return '<span class="badge b-orange">Belum Check-out</span>';
  if (st === 'TERLAMBAT_BELUM_CHECKOUT') return '<span class="badge b-orange">Terlambat • Belum Check-out</span>';
  if (st === 'LIBUR') return '<span class="badge">Libur</span>';
  return '<span class="badge b-red">Alfa</span>';
}
window.dashChange = dashChange;

/* ===================== 1. LOKASI KANTOR (MULTI LOKASI) ===================== */
// B64: perusahaan dapat memiliki BEBERAPA lokasi/cabang kantor. Setiap karyawan
// dapat ditugaskan ke salah satu lokasi (diatur di tab Karyawan). Bila tidak
// ditugaskan, karyawan memakai lokasi Default.
let OFFICE_CACHE = [];
let OFFICE_EDITING = 'new';
const DEFAULT_OFFICE_LAT = -6.863486, DEFAULT_OFFICE_LNG = 107.922021;

async function viewLokasi() {
  $('top-actions').innerHTML = `<button class="btn btn-ghost btn-sm" onclick="lokasiUseMyLocation()">${I.pin} Pakai Lokasi Saya</button>`;
  const c = await api('admin/company');
  OFFICE_CACHE = c.officeLocations || c.locations || [];
  if (!OFFICE_CACHE.length) {
    // Fallback: bangun satu lokasi dari kolom lama bila server belum mengirim daftar.
    OFFICE_CACHE = [{ id: null, name: c.officeName || 'Kantor Pusat', address: c.address || '', latitude: c.officeLatitude, longitude: c.officeLongitude, radiusMeters: c.officeRadiusMeters, minimumLocationAccuracyMeters: c.minimumLocationAccuracyMeters, isDefault: true, active: true }];
  }
  const firstDefault = OFFICE_CACHE.find((l) => l.isDefault) || OFFICE_CACHE[0];
  OFFICE_EDITING = (firstDefault && firstDefault.id) ? firstDefault.id : 'new';
  const editing = OFFICE_CACHE.find((l) => l.id === OFFICE_EDITING) || firstDefault;
  $('view').innerHTML = `
    <div class="card" style="margin-bottom:16px">
      <div class="toolbar" style="justify-content:space-between;align-items:center">
        <h3 style="margin:0">Daftar Lokasi Kantor (${OFFICE_CACHE.length})</h3>
        <button class="btn btn-primary btn-sm" onclick="lokasiFormNew()">+ Tambah Lokasi</button>
      </div>
      <div class="ttl" style="margin:-4px 0 12px">Kelola beberapa cabang/outlet. Karyawan memakai lokasi <b>Default</b> kecuali ditugaskan ke lokasi lain di tab <b>Karyawan</b>.</div>
      ${lokasiListHTML()}
    </div>
    <div class="loc-wrap">
      <!-- KIRI: peta interaktif -->
      <div class="card loc-map-card">
        <div class="loc-search">
          <div class="search-row">
            <input id="lk-q" placeholder="Cari nama tempat / alamat / gedung lalu tekan Enter"
              onkeydown="if(event.key==='Enter'){event.preventDefault();lokasiSearch();}">
            <button type="button" class="btn btn-ghost" onclick="lokasiSearch()">Cari</button>
          </div>
          <div id="lk-results" class="results" style="display:none"></div>
        </div>
        <div id="lk-map" class="map"></div>
        <div class="map-toolbar">
          <span class="chipgps">${I.compass} Klik peta atau geser <b>pin</b> — koordinat & alamat terisi otomatis</span>
          <span class="chipgps">Lat: <b id="lk-lat-view">${Number(editing.latitude).toFixed(6)}</b></span>
          <span class="chipgps">Lng: <b id="lk-lng-view">${Number(editing.longitude).toFixed(6)}</b></span>
        </div>
      </div>

      <!-- KANAN: form pengaturan lokasi -->
      <div class="card">
        <div class="section-title"><span class="ic">${I.building}</span> <span id="lk-form-title">${lokasiFormTitle()}</span></div>
        <form onsubmit="saveLokasi(event)">
          <fieldset class="loc-fieldset">
            <legend>Identitas Lokasi</legend>
            <div class="field"><label>Nama Lokasi / Cabang</label><input id="lk-office" value="${esc(editing.name || '')}" placeholder="mis. Simaung Corporation Pusat" required></div>
            <div class="field" style="margin-bottom:0"><label>No. Telepon</label><input id="lk-phone" value="${esc(c.phone || '')}" placeholder="mis. 0812xxxx"></div>
          </fieldset>

          <fieldset class="loc-fieldset">
            <legend>Titik Koordinat</legend>
            <div class="field" style="margin-bottom:10px">
              <label>Alamat <button type="button" class="copy-btn" onclick="copyAddr()">Salin</button></label>
              <input id="lk-addr" value="${esc(editing.address || '')}">
            </div>
            <div class="coordpair">
              <div class="field" style="margin:0"><label>Latitude</label><input id="lk-lat" type="number" step="any" value="${editing.latitude}" oninput="syncMapFromInputs()"></div>
              <div class="field" style="margin:0"><label>Longitude</label><input id="lk-lng" type="number" step="any" value="${editing.longitude}" oninput="syncMapFromInputs()"></div>
            </div>
          </fieldset>

          <fieldset class="loc-fieldset">
            <legend>Radius & Akurasi GPS</legend>
            <div class="field" style="margin-bottom:6px">
              <label>Radius Absen</label>
              <div class="radius-row">
                <input id="lk-radius-range" type="range" min="20" max="1000" step="10" value="${editing.radiusMeters}" oninput="onRadiusInput(this.value)">
                <input id="lk-radius" type="number" value="${editing.radiusMeters}" style="width:96px" oninput="onRadiusInput(this.value)">
                <span class="radius-badge">${Math.round(editing.radiusMeters)} m</span>
              </div>
              <div class="ttl">Karyawan harus berada di dalam radius ini untuk absen di lokasi ini.</div>
            </div>
            <div class="field" style="margin-bottom:0">
              <label>Akurasi GPS Maksimum</label>
              <div class="radius-row">
                <input id="lk-acc-range" type="range" min="10" max="300" step="5" value="${editing.minimumLocationAccuracyMeters}" oninput="onAccInput(this.value)">
                <input id="lk-acc" type="number" value="${editing.minimumLocationAccuracyMeters}" style="width:96px" oninput="onAccInput(this.value)">
                <span class="radius-badge" id="lk-acc-badge">±${Math.round(editing.minimumLocationAccuracyMeters)} m</span>
              </div>
              <div class="ttl">Sinyal GPS lebih buruk dari ini akan ditandai untuk verifikasi saat absensi.</div>
              <div class="acc-warning" id="lk-acc-warn"></div>
            </div>
          </fieldset>

          <fieldset class="loc-fieldset">
            <legend>Status</legend>
            <label class="role-pick" style="margin-bottom:10px">
              <input type="checkbox" id="lk-def" ${editing.isDefault ? 'checked' : ''}>
              <span class="rp-lb">Jadikan lokasi Default</span><span class="rp-ds">Dipakai karyawan yang belum ditugaskan ke lokasi tertentu.</span>
            </label>
            <label class="role-pick">
              <input type="checkbox" id="lk-active" ${editing.active === false ? '' : 'checked'}>
              <span class="rp-lb">Lokasi Aktif</span><span class="rp-ds">Nonaktifkan bila cabang sedang tutup / dipindahkan.</span>
            </label>
          </fieldset>

          <div class="pg-actions">
            <button class="btn btn-primary" style="width:auto;padding:12px 26px" type="submit">${OFFICE_EDITING === 'new' ? 'Tambah Lokasi' : 'Simpan Lokasi'}</button>
            ${OFFICE_EDITING === 'new' ? '' : `<button class="btn btn-ghost" style="width:auto;padding:12px 22px" type="button" onclick="lokasiFormNew()">+ Lokasi Baru</button>`}
          </div>
        </form>
      </div>
    </div>`;
  initLokasiMap(editing.latitude, editing.longitude);
  onAccInput(editing.minimumLocationAccuracyMeters);
}

function lokasiFormTitle() {
  if (OFFICE_EDITING === 'new') return 'Tambah Lokasi Kantor';
  const l = OFFICE_CACHE.find((x) => x.id === OFFICE_EDITING);
  return 'Edit Lokasi: ' + esc(l ? l.name : '');
}

function lokasiListHTML() {
  if (!OFFICE_CACHE.length) return `<div class="empty">Belum ada lokasi kantor.</div>`;
  const rows = OFFICE_CACHE.map((l) => `
    <tr>
      <td><b>${esc(l.name)}</b>${l.isDefault ? ' <span class="badge b-blue">Default</span>' : ''}</td>
      <td><span class="ttl">${esc(l.address || '—')}</span></td>
      <td>${Math.round(l.radiusMeters)} m</td>
      <td>±${Math.round(l.minimumLocationAccuracyMeters)} m</td>
      <td>${l.employeeCount != null ? l.employeeCount : '—'}</td>
      <td>${l.active === false ? '<span class="badge b-grey">Nonaktif</span>' : '<span class="badge b-green">Aktif</span>'}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-sm btn-ghost" onclick="lokasiSelect('${l.id}')">Edit</button>
        ${l.isDefault ? '' : `<button class="btn btn-sm btn-ghost" onclick="lokasiSetDefault('${l.id}')" title="Jadikan lokasi default">Jadikan Default</button>`}
        <button class="btn btn-sm btn-danger" onclick="lokasiHapus('${l.id}')" title="Hapus lokasi">Hapus</button>
      </td>
    </tr>`).join('');
  const cards = OFFICE_CACHE.map((l) => `
    <div class="mcard" style="margin-bottom:10px">
      <div class="mcard-top">
        <div><b>${esc(l.name)}</b>${l.isDefault ? ' <span class="badge b-blue">Default</span>' : ''}</div>
        ${l.active === false ? '<span class="badge b-grey">Nonaktif</span>' : '<span class="badge b-green">Aktif</span>'}
      </div>
      <div class="mcard-grid">
        <div class="kv"><label>Alamat</label><b>${esc(l.address || '—')}</b></div>
        <div class="kv"><label>Radius</label><b>${Math.round(l.radiusMeters)} m</b></div>
        <div class="kv"><label>Akurasi GPS</label><b>±${Math.round(l.minimumLocationAccuracyMeters)} m</b></div>
        <div class="kv"><label>Karyawan</label><b>${l.employeeCount != null ? l.employeeCount : '—'}</b></div>
      </div>
      <div class="mcard-actions">
        <button class="btn btn-sm btn-ghost" onclick="lokasiSelect('${l.id}')">Edit</button>
        ${l.isDefault ? '' : `<button class="btn btn-sm btn-ghost" onclick="lokasiSetDefault('${l.id}')">Default</button>`}
        <button class="btn btn-sm btn-danger" onclick="lokasiHapus('${l.id}')">Hapus</button>
      </div>
    </div>`).join('');
  return `<div class="only-desk table-wrap"><table>
      <thead><tr><th>Nama Lokasi</th><th>Alamat</th><th>Radius</th><th>Akurasi</th><th>Karyawan</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>${rows}</tbody></table></div>
    <div class="only-mob">${cards}</div>`;
}

function lokasiFormNew() {
  OFFICE_EDITING = 'new';
  // Reset form tanpa reload penuh.
  $('lk-form-title').textContent = 'Tambah Lokasi Kantor';
  $('lk-office').value = '';
  $('lk-addr').value = '';
  $('lk-lat').value = DEFAULT_OFFICE_LAT;
  $('lk-lng').value = DEFAULT_OFFICE_LNG;
  if ($('lk-radius')) $('lk-radius').value = 100;
  if ($('lk-radius-range')) $('lk-radius-range').value = 100;
  if ($('lk-acc')) $('lk-acc').value = 80;
  if ($('lk-acc-range')) $('lk-acc-range').value = 80;
  if ($('lk-def')) $('lk-def').checked = false;
  if ($('lk-active')) $('lk-active').checked = true;
  onRadiusInput(100); onAccInput(80);
  if (LK_MARKER) LK_MARKER.setLatLng([DEFAULT_OFFICE_LAT, DEFAULT_OFFICE_LNG]);
  if (LK_RADIUS) LK_RADIUS.setLatLng([DEFAULT_OFFICE_LAT, DEFAULT_OFFICE_LNG]);
  if (LK_MAP) LK_MAP.setView([DEFAULT_OFFICE_LAT, DEFAULT_OFFICE_LNG], 16);
  if ($('lk-lat-view')) $('lk-lat-view').textContent = DEFAULT_OFFICE_LAT.toFixed(6);
  if ($('lk-lng-view')) $('lk-lng-view').textContent = DEFAULT_OFFICE_LNG.toFixed(6);
}
function lokasiSelect(id) {
  const l = OFFICE_CACHE.find((x) => x.id === id);
  if (!l) return;
  OFFICE_EDITING = id;
  $('lk-form-title').textContent = 'Edit Lokasi: ' + l.name;
  $('lk-office').value = l.name || '';
  $('lk-addr').value = l.address || '';
  $('lk-lat').value = l.latitude;
  $('lk-lng').value = l.longitude;
  if ($('lk-radius')) $('lk-radius').value = l.radiusMeters;
  if ($('lk-radius-range')) $('lk-radius-range').value = l.radiusMeters;
  if ($('lk-acc')) $('lk-acc').value = l.minimumLocationAccuracyMeters;
  if ($('lk-acc-range')) $('lk-acc-range').value = l.minimumLocationAccuracyMeters;
  if ($('lk-def')) $('lk-def').checked = !!l.isDefault;
  if ($('lk-active')) $('lk-active').checked = l.active !== false;
  onRadiusInput(l.radiusMeters); onAccInput(l.minimumLocationAccuracyMeters);
  if (LK_MARKER) LK_MARKER.setLatLng([l.latitude, l.longitude]);
  if (LK_RADIUS) LK_RADIUS.setLatLng([l.latitude, l.longitude]);
  if (LK_MAP) LK_MAP.setView([l.latitude, l.longitude], 16);
  if ($('lk-lat-view')) $('lk-lat-view').textContent = Number(l.latitude).toFixed(6);
  if ($('lk-lng-view')) $('lk-lng-view').textContent = Number(l.longitude).toFixed(6);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
async function lokasiSetDefault(id) {
  try {
    await api('admin/office-locations/' + id, { method: 'PUT', body: { isDefault: true } });
    toast('Lokasi Default Diubah', 'ok', 'Karyawan tanpa penugasan akan memakai lokasi ini.');
    route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
async function lokasiHapus(id) {
  const l = OFFICE_CACHE.find((x) => x.id === id);
  const ok = await confirmDialog({
    title: 'Hapus Lokasi Kantor?', tone: 'danger', icon: 'trash',
    message: 'Lokasi "' + (l ? l.name : '') + '" akan dihapus. Karyawan yang ditugaskan ke lokasi ini otomatis kembali ke lokasi Default.' +
      (l && l.isDefault ? ' Karena ini lokasi Default, lokasi lain akan dijadikan Default.' : ''),
    confirmLabel: 'Ya, Hapus',
  });
  if (!ok) return;
  try {
    await api('admin/office-locations/' + id, { method: 'DELETE' });
    toast('Lokasi Dihapus', 'ok', 'Lokasi kantor berhasil dihapus.');
    route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.lokasiFormNew = lokasiFormNew; window.lokasiSelect = lokasiSelect;
window.lokasiSetDefault = lokasiSetDefault; window.lokasiHapus = lokasiHapus;

/* ===== PETA INTERAKTIF ===== */
let LK_MAP = null, LK_MARKER = null, LK_RADIUS = null, LK_TO = null;
function initLokasiMap(lat, lng) {
  const el = $('lk-map');
  if (!el || typeof L === 'undefined') {
    if (el) el.innerHTML = '<div class="map-fallback">Peta tidak dapat dimuat (butuh internet). Anda masih bisa mengisi Latitude &amp; Longitude manual.</div>';
    return;
  }
  if (LK_MAP) { try { LK_MAP.remove(); } catch (e) {} LK_MAP = null; }
  const center = [Number(lat) || -6.863486, Number(lng) || 107.922021];
  LK_MAP = L.map('lk-map').setView(center, 16);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(LK_MAP);
  LK_MARKER = L.marker(center, { draggable: true }).addTo(LK_MAP);
  LK_RADIUS = drawRadius(center[0], center[1]);
  LK_MARKER.on('dragend', () => { const p = LK_MARKER.getLatLng(); setLokasi(p.lat, p.lng, true); });
  LK_MAP.on('click', (e) => setLokasi(e.latlng.lat, e.latlng.lng, true));
  setTimeout(() => { try { LK_MAP.invalidateSize(); } catch (e) {} }, 200);
}
function drawRadius(lat, lng) {
  const r = parseFloat(($('lk-radius') && $('lk-radius').value) || 100) || 100;
  return L.circle([lat, lng], { radius: r, color: '#036D19', weight: 1.5, fillColor: '#036D19', fillOpacity: 0.12 }).addTo(LK_MAP);
}
function setLokasi(lat, lng, reverse) {
  lat = Number(lat); lng = Number(lng);
  if (isNaN(lat) || isNaN(lng)) return;
  if ($('lk-lat')) $('lk-lat').value = lat.toFixed(6);
  if ($('lk-lng')) $('lk-lng').value = lng.toFixed(6);
  if ($('lk-lat-view')) $('lk-lat-view').textContent = lat.toFixed(6);
  if ($('lk-lng-view')) $('lk-lng-view').textContent = lng.toFixed(6);
  if (LK_MARKER) LK_MARKER.setLatLng([lat, lng]);
  if (LK_RADIUS) LK_RADIUS.setLatLng([lat, lng]);
  if (reverse) reverseGeocode(lat, lng);
}
function syncMapFromInputs() {
  const lat = parseFloat($('lk-lat').value), lng = parseFloat($('lk-lng').value);
  if (isNaN(lat) || isNaN(lng)) return;
  if (LK_MARKER) LK_MARKER.setLatLng([lat, lng]);
  if (LK_RADIUS) LK_RADIUS.setLatLng([lat, lng]);
  if ($('lk-lat-view')) $('lk-lat-view').textContent = lat.toFixed(6);
  if ($('lk-lng-view')) $('lk-lng-view').textContent = lng.toFixed(6);
  if (LK_MAP) LK_MAP.panTo([lat, lng]);
}
async function reverseGeocode(lat, lng) {
  if (!$('lk-addr')) return;
  $('lk-addr').dataset.lat = lat; $('lk-addr').dataset.lng = lng;
  $('lk-addr').value = 'Mencari alamat…';
  try {
    const url = 'https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=' + lat + '&lon=' + lng + '&accept-language=id';
    const r = await fetch(url, { headers: { 'Accept': 'application/json' } });
    const d = await r.json();
    if (String($('lk-addr').dataset.lat) !== String(lat)) return;
    $('lk-addr').value = d.display_name || ($('lk-lat').value + ', ' + $('lk-lng').value);
  } catch (e) {
    if ($('lk-addr')) $('lk-addr').value = ($('lk-lat') ? $('lk-lat').value : lat) + ', ' + ($('lk-lng') ? $('lk-lng').value : lng);
  }
}
async function lokasiSearch() {
  const q = ($('lk-q') && $('lk-q').value || '').trim();
  const box = $('lk-results');
  if (!q) { if (box) box.style.display = 'none'; return; }
  box.style.display = 'block';
  box.innerHTML = '<div class="rrow">Mencari…</div>';
  try {
    const url = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&accept-language=id&q=' + encodeURIComponent(q);
    const r = await fetch(url, { headers: { 'Accept': 'application/json' } });
    const list = await r.json();
    if (!list.length) { box.innerHTML = '<div class="rrow">Lokasi tidak ditemukan.</div>'; return; }
    LK_RESULTS = list;
    box.innerHTML = list.map((it, i) => `<div class="rrow" onclick="pickResult(${i})">${esc(it.display_name)}</div>`).join('');
  } catch (e) { box.innerHTML = '<div class="rrow">Gagal mencari lokasi (periksa koneksi).</div>'; }
}
let LK_RESULTS = [];
function pickResult(i) {
  const it = LK_RESULTS[i];
  if (!it) return;
  const lat = parseFloat(it.lat), lng = parseFloat(it.lon);
  setLokasi(lat, lng, false);
  if ($('lk-addr')) $('lk-addr').value = it.display_name || '';
  if (LK_MAP) LK_MAP.setView([lat, lng], 17);
  if ($('lk-results')) { $('lk-results').innerHTML = ''; $('lk-results').style.display = 'none'; }
}
window.lokasiSearch = lokasiSearch; window.pickResult = pickResult; window.syncMapFromInputs = syncMapFromInputs;

function lokasiUseMyLocation() {
  if (!navigator.geolocation) return toast('GPS Tidak Didukung', 'err', 'Perangkat ini tidak menyediakan layanan lokasi.');
  toast('Mendeteksi Lokasi', 'info', 'Mohon tunggu sebentar…');
  navigator.geolocation.getCurrentPosition(
    (pos) => { setLokasi(pos.coords.latitude, pos.coords.longitude, true); toast('Lokasi Diterapkan', 'ok', 'Koordinat kantor diambil dari GPS.'); },
    () => toast('Gagal Mengambil Lokasi', 'err', 'Izin GPS ditolak atau sinyal tidak tersedia.'),
    { enableHighAccuracy: true, timeout: 10000 }
  );
}
window.lokasiUseMyLocation = lokasiUseMyLocation;
function copyAddr() { const v = $('lk-addr').value || ''; if (navigator.clipboard) navigator.clipboard.writeText(v).then(() => toast('Alamat Disalin', 'ok', 'Teks alamat tersalin ke papan klip.')); }
window.copyAddr = copyAddr;

function onRadiusInput(v) {
  const r = parseFloat(v) || 0;
  if ($('lk-radius-range')) $('lk-radius-range').value = Math.min(1000, r);
  if ($('lk-radius') && document.activeElement !== $('lk-radius')) $('lk-radius').value = r;
  const badge = document.querySelector('.radius-badge'); if (badge) badge.textContent = Math.round(r) + ' m';
  if (LK_RADIUS) LK_RADIUS.setRadius(r);
}
function onAccInput(v) {
  const a = parseFloat(v) || 0;
  if ($('lk-acc-range')) $('lk-acc-range').value = Math.min(300, a);
  if ($('lk-acc') && document.activeElement !== $('lk-acc')) $('lk-acc').value = a;
  if ($('lk-acc-badge')) $('lk-acc-badge').textContent = '±' + Math.round(a) + ' m';
  const warn = $('lk-acc-warn');
  if (warn) {
    if (a > 150) { warn.style.display = 'block'; warn.textContent = '⚠ Akurasi >150 m terlalu longgar — absensi bisa lolos di luar area. Disarankan 50–100 m.'; }
    else { warn.style.display = 'none'; }
  }
}
window.onRadiusInput = onRadiusInput; window.onAccInput = onAccInput;

async function saveLokasi(e) {
  e.preventDefault();
  const body = {
    name: ($('lk-office').value || '').trim(),
    address: ($('lk-addr').value || '').trim(),
    latitude: parseFloat($('lk-lat').value),
    longitude: parseFloat($('lk-lng').value),
    radiusMeters: parseFloat($('lk-radius').value),
    minimumLocationAccuracyMeters: parseFloat($('lk-acc').value),
    isDefault: !!(document.getElementById('lk-def') && document.getElementById('lk-def').checked),
    active: !(document.getElementById('lk-active') && !document.getElementById('lk-active').checked),
  };
  if (!body.name) { toast('Nama Lokasi Wajib', 'err', 'Isi nama lokasi/cabang kantor.'); return; }
  if (![body.latitude, body.longitude].every(Number.isFinite)) { toast('Koordinat Tidak Valid', 'err', 'Tentukan titik lokasi di peta terlebih dahulu.'); return; }
  try {
    if (OFFICE_EDITING === 'new') {
      await api('admin/office-locations', { method: 'POST', body });
    } else {
      await api('admin/office-locations/' + OFFICE_EDITING, { method: 'PUT', body });
    }
    // No. telepon tetap disimpan di tingkat perusahaan.
    const phone = ($('lk-phone') ? $('lk-phone').value.trim() : '');
    if (phone) { try { await api('admin/company', { method: 'PUT', body: { phone } }); } catch (e) { /* opsional */ } }
    toast('Lokasi Tersimpan', 'ok', 'Lokasi kantor berhasil disimpan.');
    route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.saveLokasi = saveLokasi;

/* ===================== PENGATURAN PERUSAHAAN (B7) ===================== */
let PG_COMPANY = null;
let PG_LOGO_CHANGED = false;
let PG_SETTINGS = null;
const PG_ZONES = [
  { v: 'Asia/Jakarta', label: 'Asia/Jakarta (WIB · UTC+7)' },
  { v: 'Asia/Makassar', label: 'Asia/Makassar (WITA · UTC+8)' },
  { v: 'Asia/Jayapura', label: 'Asia/Jayapura (WIT · UTC+9)' },
  { v: 'Asia/Singapore', label: 'Asia/Singapore (UTC+8)' },
  { v: 'UTC', label: 'UTC (UTC+0)' },
];
async function viewPengaturan() {
  $('top-actions').innerHTML = '';
  PG_LOGO_CHANGED = false;
  $('view').innerHTML = `<div class="pg-wrap"><div class="card"><div class="section-title"><span class="ic">${I.clock}</span> Memuat pengaturan…</div><div class="skeleton" style="height:16px;margin-top:10px"></div><div class="skeleton" style="height:16px;margin-top:8px;width:70%"></div></div></div>`;
  let c, s;
  try {
    c = await api('admin/company');
    s = await api('admin/settings').catch(() => ({}));
  } catch (err) {
    $('view').innerHTML = `<div class="pg-wrap"><div class="card">
      <div class="section-title"><span class="ic">${I.building}</span> Gagal Memuat Pengaturan</div>
      <div class="err-box" style="margin:10px 0">${esc(err.message || 'Tidak dapat menghubungi server.')}</div>
      <button class="btn btn-primary" style="width:auto" onclick="route()">Coba Lagi</button></div></div>`;
    return;
  }
  PG_COMPANY = c || {};
  PG_SETTINGS = s || {};
  const logo = c.logoBase64 || '';
  const tz = c.timezone || 'Asia/Jakarta';
  const tzOptions = PG_ZONES.slice();
  if (!tzOptions.some((z) => z.v === tz)) tzOptions.unshift({ v: tz, label: tz + ' (kustom)' });
  const grace = Number(c.lateGraceMinutes || 0);
  $('view').innerHTML = `
    <div class="pg-wrap">
      <!-- KOP / LOGO -->
      <div class="card">
        <div class="section-title"><span class="ic">${I.building}</span> Kop & Logo Perusahaan</div>
        <div class="ttl" style="margin:-6px 0 14px">Logo ini ditampilkan pada <b>kop laporan</b> (PDF/Excel) & pratinjau. Gunakan PNG berlatarbelakang transparan, maks 512px.</div>
        <div class="logo-row">
          <div class="logo-prev" id="pg-logo-prev">${logo ? `<img src="${logo}" alt="logo">` : `<span class="logo-ph">${I.building}</span>`}</div>
          <div class="logo-actions">
            <label class="btn btn-ghost btn-sm" style="cursor:pointer">${I.download} Pilih Logo
              <input id="pg-logo" type="file" accept="image/*" style="display:none" onchange="pengLogoPick(this)">
            </label>
            <button type="button" class="btn btn-sm btn-danger" onclick="pengLogoRemove()">Hapus Logo</button>
            <div class="ttl" id="pg-logo-note" style="margin:8px 0 0">${logo ? 'Logo aktif.' : 'Belum ada logo.'}</div>
          </div>
        </div>
      </div>

      <!-- ATURAN ABSENSI -->
      <div class="card">
        <div class="section-title"><span class="ic">${I.clock}</span> Aturan Absensi & Keterlambatan</div>
        <form onsubmit="savePengaturan(event)">
          <fieldset class="loc-fieldset">
            <legend>Identitas Perusahaan</legend>
            <div class="field"><label>Nama Perusahaan</label><input id="pg-name" value="${esc(c.name || '')}" placeholder="mis. Simaung Corporation"></div>
            <div class="field"><label>Nama Kantor / Cabang (Default)</label><input id="pg-office" value="${esc(c.officeName || '')}" placeholder="mis. Simaung Corporation Pusat"></div>
            <div class="grid g2">
              <div class="field" style="margin:0"><label>Alamat Kantor (Default)</label><input id="pg-addr" value="${esc(c.address || '')}" placeholder="Alamat lokasi default"></div>
              <div class="field" style="margin:0"><label>No. Telepon</label><input id="pg-phone" value="${esc(c.phone || '')}" placeholder="mis. 0812xxxx"></div>
            </div>
            <div class="ttl" style="margin-top:8px">Nama & alamat kantor default ini juga dipakai pada kop laporan. Untuk menambah <b>cabang lain</b>, gunakan tab <b>Lokasi Kantor</b>.</div>
          </fieldset>
          <fieldset class="loc-fieldset">
            <legend>Keterlambatan</legend>
            <div class="field" style="margin-bottom:6px">
              <label>Toleransi Keterlambatan (menit)</label>
              <div class="radius-row">
                <input id="pg-grace" type="number" min="0" max="120" step="1" style="width:110px" value="${grace}" oninput="onGraceInput(this.value)">
                <span class="radius-badge" id="pg-grace-badge">${grace} menit</span>
              </div>
              <div class="ttl">Karyawan yang check-in setelah jam mulai shift tetapi masih dalam rentang toleransi ini dianggap <b>tepat waktu</b>. Mis. shift 08:00 + toleransi 10 menit → masuk 08:10 masih tepat waktu. 0 = tanpa toleransi.</div>
            </div>
            <div class="acc-warning" id="pg-grace-warn"></div>
          </fieldset>

          <fieldset class="loc-fieldset">
            <legend>Zona Waktu</legend>
            <div class="field" style="margin-bottom:0">
              <label>Zona Waktu Perusahaan</label>
              <select id="pg-tz">
                ${tzOptions.map((z) => `<option value="${z.v}" ${tz === z.v ? 'selected' : ''}>${esc(z.label)}</option>`).join('')}
              </select>
              <div class="ttl">Dipakai server untuk menghitung <b>tanggal kerja</b> & status keterlambatan absensi. Keterlambatan kini dihitung dari <b>waktu scan di perangkat</b> (bukan waktu server memproses), agar server yang sempat lambat/down tidak membuat karyawan tertandai telat.</div>
            </div>
          </fieldset>

          <fieldset class="loc-fieldset">
            <legend>Akun Karyawan</legend>
            <div class="field" style="margin-bottom:0">
              <label>Kata Sandi Default Karyawan Baru</label>
              <input id="pg-pw" type="text" value="${esc(s.employeeDefaultPassword || 'abc123456')}" minlength="6" maxlength="20" autocomplete="off">
              <div class="ttl">Dipakai saat admin membuat karyawan baru & saat reset kata sandi (6–20 karakter). Tersimpan permanen per-perusahaan (tahan restart server).</div>
            </div>
          </fieldset>

          <div class="pg-actions">
            <button class="btn btn-primary" style="width:auto;padding:12px 26px" type="submit">Simpan Pengaturan</button>
            <button class="btn btn-outline" style="width:auto;padding:12px 22px" type="button" onclick="route()">Batalkan Perubahan</button>
          </div>
        </form>
      </div>

      <!-- PRATINJAU KOP -->
      <div class="card">
        <div class="section-title"><span class="ic">${I.list}</span> Pratinjau Kop Laporan</div>
        <div class="kop-prev">
          ${logo ? `<img src="${logo}" alt="logo" class="kop-logo">` : ''}
          <div>
            <b>${esc(c.name || 'Nama Perusahaan')}</b>
            <span>${esc(c.officeName || '')}${c.address ? ' • ' + esc(c.address) : ''}</span>
            <span>${c.phone ? 'Telp: ' + esc(c.phone) : ''}</span>
          </div>
        </div>
      </div>

      <!-- PERBAIKAN DATA ABSENSI -->
      <div class="card">
        <div class="section-title"><span class="ic">${I.alert}</span> Perbaikan Data Absensi (Terlambat Palsu)</div>
        <div class="ttl" style="margin:-6px 0 14px">Bila karyawan tertandai <b>terlambat</b> padahal absen tepat waktu (mis. server sempat down / jadwal belum diatur), gunakan alat ini untuk <b>menghitung ulang</b> status berdasarkan waktu scan perangkat. Memerlukan <b>password SUPERADMIN</b>.</div>
        <div class="pg-repair-grid">
          <div class="field" style="margin:0">
            <label>Karyawan</label>
            <select id="rp-emp"><option value="">Semua karyawan (aktif)</option></select>
          </div>
          <div class="field" style="margin:0">
            <label>Tanggal (opsional)</label>
            <input id="rp-date" type="date">
          </div>
          <div class="field" style="margin:0">
            <label>Password SUPERADMIN</label>
            <input id="rp-pass" type="password" autocomplete="off" placeholder="Wajib untuk konfirmasi">
          </div>
        </div>
        <div class="pg-actions" style="margin-top:6px">
          <button class="btn btn-primary" style="width:auto;padding:12px 26px" type="button" onclick="pgRepair()">Hitung Ulang Keterlambatan</button>
          <button class="btn btn-ghost" style="width:auto;padding:12px 22px" type="button" onclick="pgRepairAll()">Hitung Ulang SEMUA (60 hari)</button>
        </div>
        <div id="rp-result"></div>
      </div>
    </div>`;
  onGraceInput(grace);
  pgLoadEmployees();
}
window.viewPengaturan = viewPengaturan;

function onGraceInput(v) {
  const g = Math.max(0, Math.round(parseFloat(v) || 0));
  const b = $('pg-grace-badge'); if (b) b.textContent = g + ' menit';
  const warn = $('pg-grace-warn');
  if (warn) {
    if (g > 30) { warn.style.display = 'block'; warn.textContent = '⚠ Toleransi >30 menit cukup longgar — keterlambatan bisa tidak terlacak. Disarankan 0–15 menit.'; }
    else { warn.style.display = 'none'; }
  }
}
window.onGraceInput = onGraceInput;

function pengLogoPick(input) {
  const f = input.files && input.files[0];
  if (!f) return;
  if (!/^image\//.test(f.type)) { toast('Format Tidak Didukung', 'err', 'Pilih berkas gambar (PNG/JPG).'); return; }
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const maxW = 512;
      const scale = Math.min(1, maxW / img.width);
      const w = Math.round(img.width * scale), h = Math.round(img.height * scale);
      const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
      cv.getContext('2d').drawImage(img, 0, 0, w, h);
      const data = cv.toDataURL('image/png');
      PG_COMPANY.logoBase64 = data; PG_LOGO_CHANGED = true;
      const prev = $('pg-logo-prev'); if (prev) prev.innerHTML = `<img src="${data}" alt="logo">`;
      const note = $('pg-logo-note'); if (note) note.textContent = 'Logo dipilih — klik "Simpan Pengaturan" untuk menerapkan.';
      toast('Logo Dipilih', 'ok', 'Jangan lupa simpan pengaturan.');
    };
    img.onerror = () => toast('Gagal', 'err', 'Tidak dapat membaca gambar.');
    img.src = reader.result;
  };
  reader.readAsDataURL(f);
}
window.pengLogoPick = pengLogoPick;

function pengLogoRemove() {
  PG_COMPANY.logoBase64 = null; PG_LOGO_CHANGED = true;
  const prev = $('pg-logo-prev'); if (prev) prev.innerHTML = `<span class="logo-ph">${I.building}</span>`;
  const note = $('pg-logo-note'); if (note) note.textContent = 'Logo akan dihapus — klik "Simpan Pengaturan".';
}
window.pengLogoRemove = pengLogoRemove;

async function savePengaturan(e) {
  e.preventDefault();
  const graceVal = parseFloat($('pg-grace').value);
  if (isNaN(graceVal) || graceVal < 0 || graceVal > 120) { toast('Nilai Tidak Valid', 'err', 'Toleransi keterlambatan harus 0–120 menit.'); return; }
  const pw = ($('pg-pw').value || '').trim();
  if (pw && (pw.length < 6 || pw.length > 20)) { toast('Kata Sandi Tidak Valid', 'err', 'Kata sandi harus 6–20 karakter.'); return; }
  const btn = e.target.querySelector('button[type="submit"]');
  if (btn) { btn.disabled = true; btn.textContent = 'Menyimpan...'; }
  try {
    const body = {
      lateGraceMinutes: Math.round(graceVal),
      timezone: $('pg-tz').value,
    };
    // Identitas perusahaan (B64)
    if ($('pg-name')) { const v = $('pg-name').value.trim(); if (v) body.name = v; }
    if ($('pg-office')) { const v = $('pg-office').value.trim(); if (v) body.officeName = v; }
    if ($('pg-addr')) { const v = $('pg-addr').value.trim(); if (v) body.address = v; }
    if ($('pg-phone')) { const v = $('pg-phone').value.trim(); if (v) body.phone = v; }
    if (PG_LOGO_CHANGED) {
      if (PG_COMPANY.logoBase64) body.logoBase64 = PG_COMPANY.logoBase64;
      else body.clearLogo = true;
    }
    await api('admin/company', { method: 'PUT', body });
    if (pw) await api('admin/settings', { method: 'PUT', body: { employeeDefaultPassword: pw } });
    PG_LOGO_CHANGED = false;
    toast('Pengaturan Tersimpan', 'ok', 'Pengaturan perusahaan berhasil diperbarui.');
    route();
  } catch (err) {
    if (btn) { btn.disabled = false; btn.textContent = 'Simpan Pengaturan'; }
    toast('Gagal Menyimpan', 'err', err.message);
  }
}
window.savePengaturan = savePengaturan;

/* ---- Alat perbaikan data absensi (terlambat palsu) ---- */
async function pgLoadEmployees() {
  const sel = $('rp-emp');
  if (!sel) return;
  try {
    const r = await api('admin/employees');
    const list = r.items || r.employees || [];
    sel.innerHTML = '<option value="">Semua karyawan (aktif)</option>' +
      list.filter((e) => e.active !== false).map((e) => `<option value="${esc(e.id)}">${esc(e.fullName || e.employeeCode || e.id)}</option>`).join('');
  } catch (e) { /* biarkan opsi default */ }
}
window.pgLoadEmployees = pgLoadEmployees;

async function pgRepair() {
  const emp = $('rp-emp') ? $('rp-emp').value : '';
  const date = $('rp-date') ? $('rp-date').value : '';
  const pass = $('rp-pass') ? $('rp-pass').value : '';
  const out = $('rp-result');
  if (!emp) { toast('Pilih Karyawan', 'info', 'Pilih karyawan untuk perbaikan tertarget, atau gunakan "Hitung Ulang SEMUA".'); return; }
  if (!pass) { toast('Password Diperlukan', 'err', 'Masukkan password SUPERADMIN untuk konfirmasi.'); return; }
  const ok = await confirmDialog({ title: 'Hitung ulang keterlambatan?', html: 'Status <b>terlambat/tepat waktu</b> akan dihitung ulang dari waktu scan perangkat. Data yang sudah benar tidak berubah.', tone: 'warn', icon: 'reset', confirmLabel: 'Ya, Hitung Ulang' });
  if (!ok) return;
  if (out) out.innerHTML = '<div class="ttl" style="margin-top:8px">Memproses…</div>';
  try {
    const body = { employeeId: emp, password: pass, mode: 'recompute', days: 120 };
    if (date) body.date = date;
    const r = await api('admin/attendance/repair', { method: 'POST', body });
    if (out) out.innerHTML = `<div class="ok-box" style="margin-top:8px">${r.fixed} data diperbaiki dari ${r.checked} yang diperiksa.</div>`;
    toast('Selesai', 'ok', `${r.fixed} data diperbaiki dari ${r.checked} diperiksa.`);
    if ($('rp-pass')) $('rp-pass').value = '';
  } catch (err) {
    if (out) out.innerHTML = `<div class="err-box" style="margin-top:8px">${esc(err.message)}</div>`;
    toast('Gagal', 'err', err.message);
  }
}
window.pgRepair = pgRepair;

async function pgRepairAll() {
  const pass = $('rp-pass') ? $('rp-pass').value : '';
  const out = $('rp-result');
  if (!pass) { toast('Password Diperlukan', 'err', 'Masukkan password SUPERADMIN untuk konfirmasi.'); return; }
  const ok = await confirmDialog({ title: 'Hitung ulang SEMUA absensi (60 hari)?', html: 'Seluruh data check-in aktif akan dihitung ulang berdasarkan waktu scan perangkat. Aksi ini aman & tidak menghapus data.', tone: 'warn', icon: 'reset', confirmLabel: 'Ya, Hitung Ulang Semua' });
  if (!ok) return;
  if (out) out.innerHTML = '<div class="ttl" style="margin-top:8px">Memproses semua karyawan… mohon tunggu.</div>';
  try {
    const r = await api('admin/attendance/repair', { method: 'POST', body: { all: true, password: pass, mode: 'recompute', days: 60 } });
    if (out) out.innerHTML = `<div class="ok-box" style="margin-top:8px">${r.fixed} data diperbaiki dari ${r.checked} yang diperiksa.</div>`;
    toast('Selesai', 'ok', `${r.fixed} data diperbaiki dari ${r.checked} diperiksa.`);
    if ($('rp-pass')) $('rp-pass').value = '';
  } catch (err) {
    if (out) out.innerHTML = `<div class="err-box" style="margin-top:8px">${esc(err.message)}</div>`;
    toast('Gagal', 'err', err.message);
  }
}
window.pgRepairAll = pgRepairAll;

/* ===================== 2. KARYAWAN ===================== */
let EMP_CACHE = [], SHIFT_CACHE = [];
let EMP_FILTER = 'all';
function empCard(e) {
  return `
    <div class="mcard">
      <div class="mcard-top">
        <div class="row-user">${avatarHtml(e)}
          <div><b>${esc(e.fullName)}</b><span>Kode: ${esc(e.employeeCode)}</span></div></div>
        ${e.active ? '<span class="badge b-green">Aktif</span>' : '<span class="badge b-grey">Nonaktif</span>'}
      </div>
      <div class="mcard-grid">
        <div class="kv"><label>Jabatan</label><b>${esc(e.position || '-')}</b></div>
        <div class="kv"><label>Peran</label><b>${roleBadges(e.roles)}</b></div>
        <div class="kv"><label>Fasilitas</label><b>${roleFacilityBadges(e.roles)}</b></div>
        <div class="kv"><label>No. HP</label><b>${esc(e.phone || '-')}</b></div>
        <div class="kv"><label>Shift</label><b>${e.shiftName ? esc(e.shiftName) + ' (' + e.shiftStart + '-' + e.shiftEnd + ')' : 'Belum diatur'}</b></div>
        <div class="kv"><label>Lokasi Kantor</label><b>${officeLabelBadge(e)}</b></div>
      </div>
      <div class="mcard-actions">
        <button class="btn btn-sm btn-ghost" onclick="openEmpModal('${e.id}')">Edit</button>
        <button class="btn btn-sm btn-ghost" onclick="openEmpOffice('${e.id}')" title="Atur lokasi kantor karyawan">Lokasi Kantor</button>
        ${e.active
          ? `<button class="btn btn-sm btn-warn" onclick="toggleEmpActive('${e.id}', false)">Nonaktifkan</button>`
          : `<button class="btn btn-sm btn-ghost" onclick="toggleEmpActive('${e.id}', true)">Aktifkan</button>`}
        <button class="btn btn-sm btn-ghost" onclick="resetEmpPassword('${e.id}', '${esc(e.fullName).replace(/'/g, '')}')">Reset Password</button>
        <button class="btn btn-sm btn-danger" onclick="delEmp('${e.id}', '${esc(e.fullName).replace(/'/g, '')}')">Hapus</button>
      </div>
    </div>`;
}

async function viewKaryawan() {
  $('top-actions').innerHTML = `<button class="btn btn-orange" onclick="openEmpModal()">+ Tambah Karyawan</button>`;
  const [emp, shifts, offices] = await Promise.all([api('admin/employees'), api('admin/shifts'), api('admin/office-locations').catch(() => ({ items: [] }))]);
  EMP_CACHE = emp.items || [];
  SHIFT_CACHE = shifts.items || [];
  OFFICE_CACHE = offices.items || offices.locations || [];
  SHIFTS = SHIFT_CACHE;
  const total = EMP_CACHE.length;
  const nActive = EMP_CACHE.filter((e) => e.active).length;
  const nInactive = total - nActive;
  const shown = EMP_CACHE.filter((e) =>
    EMP_FILTER === 'active' ? e.active : EMP_FILTER === 'inactive' ? !e.active : true
  );
  $('view').innerHTML = `
    <div class="card">
      <div class="toolbar" style="justify-content:space-between;align-items:center">
        <h3 style="margin:0">Daftar Karyawan (${shown.length}/${total})</h3>
        <div class="seg">
          <button class="${EMP_FILTER === 'all' ? 'on' : ''}" onclick="empFilter('all')">Semua ${total}</button>
          <button class="${EMP_FILTER === 'active' ? 'on' : ''}" onclick="empFilter('active')">Aktif ${nActive}</button>
          <button class="${EMP_FILTER === 'inactive' ? 'on' : ''}" onclick="empFilter('inactive')">Nonaktif ${nInactive}</button>
        </div>
      </div>
      ${shown.length === 0 ? `<div class="empty">${total === 0 ? 'Belum ada karyawan. Klik “Tambah Karyawan”.' : 'Tidak ada karyawan pada filter ini.'}</div>` : `
      <div class="only-desk table-wrap">
        <table>
          <thead><tr><th>Karyawan</th><th>Jabatan</th><th>Peran</th><th>Fasilitas</th><th>No. HP</th><th>Shift</th><th>Lokasi Kantor</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
          ${shown.map((e) => `
            <tr>
              <td><div class="row-user">${avatarHtml(e)}<div><b>${esc(e.fullName)}</b><span>Kode: ${esc(e.employeeCode)}</span></div></div></td>
              <td>${esc(e.position || '-')}</td>
              <td>${roleBadges(e.roles)}</td>
              <td>${roleFacilityBadges(e.roles)}</td>
              <td>${esc(e.phone || '-')}</td>
              <td>${e.shiftName ? `<span class="badge b-green">${esc(e.shiftName)}</span> <span class="ttl">${e.shiftStart}-${e.shiftEnd}</span>` : '<span class="ttl">Belum diatur</span>'}</td>
              <td>${officeLabelBadge(e)}</td>
              <td>${e.active ? '<span class="badge b-green">Aktif</span>' : '<span class="badge b-grey">Nonaktif</span>'}</td>
              <td style="white-space:nowrap">
                <button class="btn btn-sm btn-ghost" onclick="openEmpModal('${e.id}')">Edit</button>
                <button class="btn btn-sm btn-ghost" onclick="openEmpOffice('${e.id}')" title="Atur lokasi kantor karyawan">Lokasi Kantor</button>
                <button class="btn btn-sm btn-ghost" onclick="resetEmpPassword('${e.id}', '${esc(e.fullName).replace(/'/g, '')}')" title="Reset password ke default">Reset Password</button>
                ${e.active
                  ? `<button class="btn btn-sm btn-warn" onclick="toggleEmpActive('${e.id}', false)" title="Nonaktifkan akun">Nonaktifkan</button>`
                  : `<button class="btn btn-sm btn-ghost" onclick="toggleEmpActive('${e.id}', true)" title="Aktifkan kembali akun">Aktifkan</button>`}
                <button class="btn btn-sm btn-danger" onclick="delEmp('${e.id}', '${esc(e.fullName).replace(/'/g, '')}')" title="Hapus akun karyawan">Hapus</button>
              </td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="only-mob mlist">${shown.map(empCard).join('')}</div>`}
    </div>`;
}
function empFilter(f) { EMP_FILTER = f; route(); }
window.empFilter = empFilter;

async function toggleEmpActive(id, active) {
  const verb = active ? 'Aktifkan' : 'Nonaktifkan';
  const e = (typeof EMP_CACHE !== 'undefined' ? EMP_CACHE : []).find((x) => x.id === id);
  const nm = e ? e.fullName : '';
  const ok = await confirmDialog({
    title: `${verb} Akun Karyawan`,
    subtitle: nm ? `“${nm}”` : undefined,
    icon: 'power',
    tone: active ? 'brand' : 'warn',
    message: active
      ? 'Karyawan dapat kembali login dan melakukan absensi seperti biasa.'
      : 'Karyawan tidak akan bisa login sampai akunnya diaktifkan kembali. Data absensi tetap tersimpan.',
    confirmLabel: active ? 'Ya, Aktifkan' : 'Ya, Nonaktifkan',
  });
  if (!ok) return;
  try {
    await api('admin/employees/' + id, { method: 'PUT', body: { active } });
    toast(active ? 'Karyawan diaktifkan' : 'Karyawan dinonaktifkan', 'ok',
      nm ? `Akun “${nm}” berhasil ${active ? 'diaktifkan' : 'dinonaktifkan'}.` : undefined);
    route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.toggleEmpActive = toggleEmpActive;

async function resetEmpPassword(id, name) {
  const nm = name ? `“${name}”` : 'ini';
  const ok = await confirmDialog({
    title: 'Reset Password Karyawan',
    subtitle: name || undefined,
    icon: 'reset',
    tone: 'brand',
    html:
      `<p>Password akun ${esc(nm)} akan dikembalikan ke password default.</p>` +
      `<div class="dialog-note">${DIALOG_ICONS.protect}<span>Password default: <b>abc123456</b><br>Karyawan dapat menggantinya sendiri kapan saja di aplikasi <b>tab Profil → Ganti Password</b>.</span></div>`,
    confirmLabel: 'Reset Password',
  });
  if (!ok) return;
  try {
    const res = await api('admin/employees/' + id + '/reset-password', { method: 'PUT', body: {} });
    const pw = res && res.defaultPassword ? res.defaultPassword : null;
    toast('Password Direset', 'ok',
      pw ? `Password ${name ? `“${name}”` : 'karyawan'} kini: ${pw}` : 'Password karyawan berhasil direset.');
  } catch (err) { toast('Gagal Reset Password', 'err', err.message); }
}
window.resetEmpPassword = resetEmpPassword;

async function delEmp(id, name) {
  const nm = name ? `“${name}”` : 'ini';
  const ok = await confirmDialog({
    title: 'Hapus Akun Karyawan',
    subtitle: name || undefined,
    icon: 'trash',
    tone: 'danger',
    html:
      `<p>Tindakan ini akan menghapus <b>permanen</b> akun ${esc(nm)} dari server.</p>` +
      `<div class="dialog-note">${DIALOG_ICONS.trash}<span>Seluruh data karyawan ini — <b>akun, absensi, izin, lembur, dan perangkat</b> — akan dihapus dari database dan <b>tidak bisa dikembalikan</b>.</span></div>`,
    confirmLabel: 'Hapus Permanen',
    cancelLabel: 'Batal',
  });
  if (!ok) return;
  try {
    const res = await api('admin/employees/' + id, { method: 'DELETE' });
    toast(res && res.hard ? 'Akun Dihapus Permanen' : 'Karyawan Dihapus', 'ok',
      name ? `Akun “${name}” telah dihapus.` : undefined);
    route();
  } catch (err) { toast('Gagal Menghapus', 'err', err.message); }
}
window.delEmp = delEmp;

/* ---- Pengaturan lokasi kantor per karyawan (B64) ---- */
function officeLabelBadge(e) {
  if (!e) return '<span class="ttl">—</span>';
  if (e.officeLocationId && e.officeName) return `<span class="badge b-blue">${esc(e.officeName)}</span>`;
  if (e.officeName) return `<span class="badge b-grey">${esc(e.officeName)}</span> <span class="ttl">(default)</span>`;
  return '<span class="ttl">Default perusahaan</span>';
}
function openEmpOffice(id) {
  const e = EMP_CACHE.find((x) => x.id === id);
  if (!e) return;
  const opts = OFFICE_CACHE.map((l) => `<option value="${l.id}" ${e.officeLocationId === l.id ? 'selected' : ''}>${esc(l.name)}${l.isDefault ? ' (Default)' : ''}</option>`).join('');
  const cur = e.officeLocationId ? (OFFICE_CACHE.find((l) => l.id === e.officeLocationId) || {}).name : null;
  openModal(`
    <h3>Lokasi Kantor Karyawan</h3>
    <div class="ttl" style="margin:-6px 0 12px">${esc(e.fullName)} — <span>${esc(e.employeeCode)}</span><br>Tentukan cabang kantor tempat karyawan ini melakukan absensi.</div>
    <form onsubmit="saveEmpOffice(event, '${e.id}')">
      <div class="field">
        <label>Lokasi Kantor</label>
        <select id="ef-office">
          <option value="">— Ikuti lokasi Default perusahaan —</option>
          ${opts}
        </select>
        <div class="ttl">Pilih salah satu cabang, atau biarkan kosong agar mengikuti lokasi <b>Default</b> perusahaan${cur ? ` (saat ini: <b>${esc(cur)}</b>)` : ''}.</div>
      </div>
      <div class="actions">
        <button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button>
        <button type="submit" class="btn btn-primary" style="width:auto">Simpan</button>
      </div>
    </form>`);
}
async function saveEmpOffice(ev, id) {
  ev.preventDefault();
  const val = ($('ef-office') && $('ef-office').value) || null;
  try {
    await api('admin/employees/' + id + '/office', { method: 'PUT', body: { officeLocationId: val } });
    // Perbarui cache lokal agar tampilan langsung konsisten.
    const e = EMP_CACHE.find((x) => x.id === id);
    if (e) {
      const loc = val ? OFFICE_CACHE.find((l) => l.id === val) : null;
      e.officeLocationId = val;
      e.officeName = loc ? loc.name : ((OFFICE_CACHE.find((l) => l.isDefault) || {}).name || e.officeName);
    }
    closeModal();
    toast('Lokasi Kantor Diperbarui', 'ok', 'Penugasan lokasi kantor karyawan berhasil disimpan.');
    route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.openEmpOffice = openEmpOffice; window.saveEmpOffice = saveEmpOffice;
function openEmpModal(id) {
  const e = id ? EMP_CACHE.find((x) => x.id === id) : null;
  const shiftOpts = SHIFT_CACHE.map((s) => `<option value="${s.id}" ${e && e.shiftId === s.id ? 'selected' : ''}>${esc(s.name)} (${s.startTime}-${s.endTime})</option>`).join('');
  const curRoles = (e && e.roles) ? e.roles : [];
      const roleCards = ROLE_CATALOG.map((r) => `
    <label class="role-pick ${curRoles.includes(r.key) ? 'on' : ''}">
      <input type="checkbox" class="em-role" value="${r.key}" ${curRoles.includes(r.key) ? 'checked' : ''} onchange="this.closest('.role-pick').classList.toggle('on', this.checked)">
      <span class="rp-lb">${esc(r.label)}</span><span class="rp-ds">${esc(r.desc)}</span>
    </label>`).join('');
  const officeOpts = (OFFICE_CACHE || []).map((l) => `<option value="${l.id}" ${e && e.officeLocationId === l.id ? 'selected' : ''}>${esc(l.name)}${l.isDefault ? ' (Default)' : ''}</option>`).join('');
  openModal(`
    <h3>${e ? 'Edit Karyawan' : 'Tambah Karyawan'}</h3>
    <form onsubmit="saveEmp(event, ${e ? `'${e.id}'` : 'null'})">
      <div class="grid g2">
        <div class="field"><label>Kode Karyawan</label><input id="em-code" value="${e ? esc(e.employeeCode) : ''}" ${e ? 'disabled' : ''} placeholder="mis. EMP002" required></div>
        <div class="field"><label>Nama Lengkap</label><input id="em-name" value="${e ? esc(e.fullName) : ''}" placeholder="Nama karyawan" required></div>
      </div>
      <div class="grid g2">
        <div class="field"><label>Jabatan</label><input id="em-pos" value="${e ? esc(e.position || '') : ''}" placeholder="mis. Kasir"></div>
        <div class="field"><label>No. HP</label><input id="em-phone" value="${e ? esc(e.phone || '') : ''}" placeholder="mis. 0812..."></div>
      </div>
      <div class="field"><label>Peran Jabatan (boleh lebih dari satu)</label>
        <div class="role-picks">${roleCards}</div>
        <div class="ttl">Centang sesuai jabatan. Jabatan <b>rangkap</b> (mis. Driver + Pramuniaga) cukup pilih keduanya — fasilitas keduanya akan aktif di aplikasi.</div></div>
      <div class="field"><label>${e ? 'Password Baru (kosongkan jika tidak diubah)' : 'Password'}</label><input id="em-pin" ${e ? '' : 'required'} placeholder="min. 6 karakter (huruf + angka)" autocomplete="new-password">
        <div class="ttl">Minimal 6 karakter, kombinasi huruf dan angka. Default: <b>abc123456</b> (karyawan dapat menggantinya sendiri di aplikasi → tab Profil → Ganti Password).</div></div>
      <div class="field"><label>Shift Default</label><select id="em-shift"><option value="">— Tidak ada —</option>${shiftOpts}</select>
        <div class="ttl">Shift default dipakai bila hari itu tidak diatur di Jadwal Mingguan.</div></div>
      <div class="field"><label>Lokasi Kantor</label><select id="em-office">
        <option value="">— Ikuti lokasi Default perusahaan —</option>${officeOpts}</select>
        <div class="ttl">Tentukan cabang tempat karyawan ini absen (multi lokasi kantor). Kosongkan untuk mengikuti lokasi <b>Default</b>.</div></div>
      ${e ? `<div class="field"><label>Status Akun</label><select id="em-active">
        <option value="true" ${e.active ? 'selected' : ''}>Aktif</option>
        <option value="false" ${!e.active ? 'selected' : ''}>Nonaktif</option>
      </select></div>` : ''}
      <div class="actions">
        <button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button>
        <button type="submit" class="btn btn-primary" style="width:auto">Simpan</button>
      </div>
    </form>`);
}
async function saveEmp(ev, id) {
  ev.preventDefault();
  const roles = Array.from(document.querySelectorAll('.em-role:checked')).map((x) => x.value);
  const body = {
    fullName: $('em-name').value.trim(),
    position: $('em-pos').value.trim(),
    phone: $('em-phone').value.trim(),
    shiftId: $('em-shift').value || null,
    officeLocationId: ($('em-office') ? ($('em-office').value || null) : null),
    roles,
  };
  const pin = $('em-pin').value.trim();
  if (pin) body.pin = pin;
  const actEl = $('em-active');
  if (actEl) body.active = actEl.value === 'true';
  try {
    if (id) { await api('admin/employees/' + id, { method: 'PUT', body }); toast('Data Karyawan Diperbarui', 'ok', 'Perubahan data karyawan berhasil disimpan.'); }
    else { body.employeeCode = $('em-code').value.trim(); await api('admin/employees', { method: 'POST', body }); toast('Karyawan Ditambahkan', 'ok', 'Akun karyawan baru berhasil dibuat.'); }
    closeModal(); route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.viewKaryawan = viewKaryawan; window.openEmpModal = openEmpModal; window.saveEmp = saveEmp;

/* ===================== 4. LAPORAN (redesain) ===================== */
let REP_FROM = new Date(Date.now() - 29 * 864e5).toISOString().slice(0, 10);
let REP_TO = todayISO();
let REP_SORT = { key: 'daysPresent', dir: 'desc' };
let REP_QUERY = '';
function repSearch(v) {
  REP_QUERY = (v || '').trim().toLowerCase();
  const body = document.getElementById('rep-body');
  if (body) body.innerHTML = repRowsHtml();
}
function repRowsHtml() {
  const items = repSearchApply(REP_CACHE);
  if (items.length === 0) return '<tr><td colspan="9"><div class="empty">Tidak ada karyawan yang cocok.</div></td></tr>';
  const days = REP_DAYS();
  return items.map((r) => {
    const pct = Math.min(100, Math.round((r.daysPresent / days) * 100));
    return `<tr>
      <td><div class="row-user">${avatarHtml(r)}<div><b>${esc(r.fullName)}</b><span>${esc(r.employeeCode)} • ${esc(r.position || '-')}</span></div></div></td>
      <td><b>${r.daysPresent}</b> hari</td>
      <td>${r.checkIns}</td>
      <td>${r.avgDistance != null ? r.avgDistance + ' m' : '-'}</td>
      <td>${r.avgFaceScore != null ? facePill(r.avgFaceScore) : '-'}</td>
      <td>${r.overtimeApprovedMinutes > 0 ? `<b style="color:var(--brand)">${durLabel(r.overtimeApprovedMinutes)}</b>` : '<span class="ttl">-</span>'}${r.overtimePendingCount > 0 ? ` <span class="badge b-orange">${r.overtimePendingCount} menunggu</span>` : ''}</td>
      <td>${(r.leaveApprovedDays || 0) > 0 ? `<b>${r.leaveApprovedDays} hari</b>` : '<span class="ttl">-</span>'}</td>
      <td>${(r.totalLateMinutes || 0) > 0 ? `<b style="color:var(--accent)">${r.totalLateMinutes} mnt</b>` : '<span class="ttl">-</span>'}${(r.lateCount || 0) > 0 ? ` <span class="ttl">(${r.lateCount}×)</span>` : ''}</td>
      <td><div style="display:flex;align-items:center;gap:8px"><div class="hbar" style="flex:1"><i style="width:${pct}%"></i></div><span class="ttl" style="min-width:34px">${pct}%</span></div></td>
    </tr>`;
  }).join('');
}
function REP_DAYS() { return Math.max(1, Math.round((new Date(REP_TO) - new Date(REP_FROM)) / 864e5) + 1); }
function repSearchApply(items) {
  if (!REP_QUERY) return items;
  return items.filter((x) =>
    String(x.fullName || '').toLowerCase().includes(REP_QUERY) ||
    String(x.employeeCode || '').toLowerCase().includes(REP_QUERY) ||
    String(x.position || '').toLowerCase().includes(REP_QUERY));
}
let REP_CACHE = [];
async function viewLaporan() {
  $('top-actions').innerHTML = `
    <button class="btn btn-ghost btn-sm" id="rep-pdf" onclick="exportReportPdf()">${I.download} Ekspor PDF</button>
    <button class="btn btn-orange btn-sm" id="rep-export" onclick="exportReport()">${I.download} Ekspor Excel</button>`;
  const d = await api('admin/report?from=' + REP_FROM + '&to=' + REP_TO);
  const items = d.items || [];
  REP_CACHE = items;
  const days = Math.max(1, Math.round((new Date(REP_TO) - new Date(REP_FROM)) / 864e5) + 1);
  const totalDays = items.reduce((a, x) => a + x.daysPresent, 0);
  const totalCheckIns = items.reduce((a, x) => a + x.checkIns, 0);
  const withFace = items.filter((x) => x.avgFaceScore != null);
  const avgFace = withFace.length ? Math.round(withFace.reduce((a, x) => a + x.avgFaceScore, 0) / withFace.length) : null;
  const avgPresent = items.length ? (totalDays / items.length) : 0;
  const rate = items.length ? Math.round((avgPresent / days) * 100) : 0;
  const best = items.slice().sort((a, b) => b.daysPresent - a.daysPresent)[0];
  const totalOvertimeMin = items.reduce((a, x) => a + (x.overtimeApprovedMinutes || 0), 0);
  const totalOvertimePending = items.reduce((a, x) => a + (x.overtimePendingCount || 0), 0);
  const totalLateMin = items.reduce((a, x) => a + (x.totalLateMinutes || 0), 0);
  const totalLateCount = items.reduce((a, x) => a + (x.lateCount || 0), 0);
  const totalLeaveDays = items.reduce((a, x) => a + (x.leaveApprovedDays || 0), 0);

  const sorted = items.slice().sort((a, b) => {
    const k = REP_SORT.key;
    const va = a[k] == null ? -1 : a[k], vb = b[k] == null ? -1 : b[k];
    const c = typeof va === 'string' ? String(va).localeCompare(String(vb)) : va - vb;
    return REP_SORT.dir === 'asc' ? c : -c;
  });
  const maxDays = Math.max(1, ...items.map((x) => x.daysPresent));

  $('view').innerHTML = `
    <div class="card">
      <div class="rep-head">
        <div class="rep-range">
          <div class="field" style="margin:0"><label>Dari</label><input type="date" id="rep-from" value="${REP_FROM}"></div>
          <div class="field" style="margin:0"><label>Sampai</label><input type="date" id="rep-to" value="${REP_TO}"></div>
          <button class="btn btn-ghost btn-sm" onclick="applyReport()">Terapkan</button>
        </div>
        <div class="rep-pills">
          <button onclick="repQuick(7)">7 Hari</button>
          <button onclick="repQuick(30)" class="on">30 Hari</button>
          <button onclick="repQuick(90)">90 Hari</button>
        </div>
      </div>
      <div class="field" style="margin:14px 0 0">
        <label>Cari Karyawan</label>
        <input id="rep-search" value="${esc(REP_QUERY)}" placeholder="Nama, kode karyawan, atau jabatan…" oninput="repSearch(this.value)">
      </div>
    </div>

    <div class="kpi-grid">
      <div class="kpi"><div class="ic">${I.users}</div><span>Total Karyawan</span><b>${items.length}</b><small>aktif</small></div>
      <div class="kpi"><div class="ic">${I.check}</div><span>Total Hari Hadir</span><b>${totalDays}</b><small>${totalCheckIns} kali check-in</small></div>
      <div class="kpi"><div class="ic o">${I.trend}</div><span>Rata Kehadiran</span><b>${rate}%</b><small>≈ ${avgPresent.toFixed(1)} hari / karyawan</small>
        <div class="kpi-bar" style="height:6px;border-radius:6px;background:var(--bg);margin-top:6px;overflow:hidden"><i style="display:block;height:100%;width:${rate}%;background:linear-gradient(90deg,var(--accent),#ff8a3d)"></i></div>
      </div>
      <div class="kpi"><div class="ic">${I.smile}</div><span>Rata Skor Wajah</span><b>${avgFace != null ? avgFace + '%' : '-'}</b><small>${best ? 'Terbanyak: ' + esc(best.fullName) : '—'}</small></div>
      <div class="kpi"><div class="ic">${I.check}</div><span>Total Lembur Disetujui</span><b>${durLabel(totalOvertimeMin)}</b><small>${totalOvertimePending} pengajuan menunggu</small></div>
      <div class="kpi"><div class="ic o">${I.clock || I.trend}</div><span>Total Keterlambatan</span><b>${totalLateMin} mnt</b><small>${totalLateCount} kali terlambat</small></div>
      <div class="kpi"><div class="ic">${I.list}</div><span>Total Izin Disetujui</span><b>${totalLeaveDays} hari</b><small>${items.reduce((a, x) => a + (x.leaveApprovedCount || 0), 0)} pengajuan</small></div>
    </div>

    <div class="card">
      <div class="section-title"><span class="ic">${I.chart}</span> Peringkat Kehadiran (Top 5)</div>
      ${items.length === 0 ? '<div class="empty">Belum ada data pada rentang tanggal ini.</div>' : `
      <div style="display:flex;flex-direction:column;gap:10px">
        ${items.slice().sort((a, b) => b.daysPresent - a.daysPresent).slice(0, 5).map((r) => `
          <div style="display:flex;align-items:center;gap:12px">
            ${avatarHtml(r)}
            <div style="flex:1;min-width:0">
              <div style="display:flex;justify-content:space-between;gap:10px">
                <b style="font-size:13px">${esc(r.fullName)}</b>
                <span class="ttl">${r.daysPresent} hari</span>
              </div>
              <div class="hbar" style="margin-top:5px"><i style="width:${Math.round((r.daysPresent / maxDays) * 100)}%"></i></div>
            </div>
          </div>`).join('')}
      </div>`}
    </div>

    <div class="card">
      <div class="section-title"><span class="ic">${I.list}</span> Rincian Per Karyawan</div>
      ${items.length === 0 ? '<div class="empty">Belum ada data pada rentang tanggal ini.</div>' : `
      <div class="only-desk table-wrap">
      <table>
        <thead><tr>
          <th>Karyawan</th>
          <th class="rep-sort ${REP_SORT.key === 'daysPresent' ? 'on' : ''}" onclick="repSort('daysPresent')">Hari Hadir <span class="ar">${REP_SORT.key === 'daysPresent' ? (REP_SORT.dir === 'asc' ? '▲' : '▼') : '↕'}</span></th>
          <th class="rep-sort ${REP_SORT.key === 'checkIns' ? 'on' : ''}" onclick="repSort('checkIns')">Check-in <span class="ar">${REP_SORT.key === 'checkIns' ? (REP_SORT.dir === 'asc' ? '▲' : '▼') : '↕'}</span></th>
          <th class="rep-sort ${REP_SORT.key === 'avgDistance' ? 'on' : ''}" onclick="repSort('avgDistance')">Rata Jarak <span class="ar">${REP_SORT.key === 'avgDistance' ? (REP_SORT.dir === 'asc' ? '▲' : '▼') : '↕'}</span></th>
          <th class="rep-sort ${REP_SORT.key === 'avgFaceScore' ? 'on' : ''}" onclick="repSort('avgFaceScore')">Rata Wajah <span class="ar">${REP_SORT.key === 'avgFaceScore' ? (REP_SORT.dir === 'asc' ? '▲' : '▼') : '↕'}</span></th>
          <th class="rep-sort ${REP_SORT.key === 'overtimeApprovedMinutes' ? 'on' : ''}" onclick="repSort('overtimeApprovedMinutes')">Lembur <span class="ar">${REP_SORT.key === 'overtimeApprovedMinutes' ? (REP_SORT.dir === 'asc' ? '▲' : '▼') : '↕'}</span></th>
          <th class="rep-sort ${REP_SORT.key === 'leaveApprovedDays' ? 'on' : ''}" onclick="repSort('leaveApprovedDays')">Izin <span class="ar">${REP_SORT.key === 'leaveApprovedDays' ? (REP_SORT.dir === 'asc' ? '▲' : '▼') : '↕'}</span></th>
          <th class="rep-sort ${REP_SORT.key === 'totalLateMinutes' ? 'on' : ''}" onclick="repSort('totalLateMinutes')">Terlambat <span class="ar">${REP_SORT.key === 'totalLateMinutes' ? (REP_SORT.dir === 'asc' ? '▲' : '▼') : '↕'}</span></th>
          <th>Tingkat Kehadiran</th>
        </tr></thead>
        <tbody id="rep-body">${repRowsHtml()}</tbody>
      </table>
      </div>
      <div class="only-mob mlist">
        ${sorted.map((r) => {
          const pct = Math.min(100, Math.round((r.daysPresent / days) * 100));
          return `<div class="mcard">
            <div class="mcard-top">
              <div class="row-user">${avatarHtml(r)}<div><b>${esc(r.fullName)}</b><span>${esc(r.employeeCode)}${r.position ? ' • ' + esc(r.position) : ''}</span></div></div>
              ${r.avgFaceScore != null ? facePill(r.avgFaceScore) : ''}
            </div>
            <div class="mcard-grid">
              <div class="kv"><label>Hari Hadir</label><b>${r.daysPresent} hari</b></div>
              <div class="kv"><label>Check-in</label><b>${r.checkIns} kali</b></div>
              <div class="kv"><label>Rata Jarak</label><b>${r.avgDistance != null ? r.avgDistance + ' m' : '-'}</b></div>
              <div class="kv"><label>Rata Wajah</label><b>${r.avgFaceScore != null ? r.avgFaceScore + '%' : '-'}</b></div>
              <div class="kv"><label>Lembur</label><b>${r.overtimeApprovedMinutes > 0 ? durLabel(r.overtimeApprovedMinutes) : '-'}${r.overtimePendingCount > 0 ? ' (' + r.overtimePendingCount + ' menunggu)' : ''}</b></div>
              <div class="kv"><label>Izin</label><b>${(r.leaveApprovedDays || 0) > 0 ? r.leaveApprovedDays + ' hari' : '-'}</b></div>
              <div class="kv"><label>Terlambat</label><b>${(r.totalLateMinutes || 0) > 0 ? r.totalLateMinutes + ' mnt' + ((r.lateCount || 0) > 0 ? ' (' + r.lateCount + '×)' : '') : '-'}</b></div>
            </div>
            <div style="display:flex;align-items:center;gap:8px;margin-top:10px">
              <div class="hbar" style="flex:1"><i style="width:${pct}%"></i></div>
              <span class="ttl" style="min-width:34px">${pct}%</span>
            </div>
          </div>`;
        }).join('')}
      </div>
      <div style="margin-top:14px" class="muted-box">Rentang: <b>${esc(dayLabel(REP_FROM))}</b> → <b>${esc(dayLabel(REP_TO))}</b> (${days} hari). Tingkat kehadiran = hari hadir ÷ jumlah hari pada rentang.</div>`}
    </div>`;
}
function facePill(score) {
  const cls = score >= 85 ? 'b-green' : score >= 70 ? 'b-orange' : 'b-red';
  return `<span class="badge ${cls}">${score}%</span>`;
}
function repSort(key) {
  if (REP_SORT.key === key) REP_SORT.dir = REP_SORT.dir === 'desc' ? 'asc' : 'desc';
  else { REP_SORT.key = key; REP_SORT.dir = 'desc'; }
  route();
}
function repQuick(n) {
  REP_TO = todayISO();
  REP_FROM = new Date(Date.now() - (n - 1) * 864e5).toISOString().slice(0, 10);
  route();
}
function applyReport() { REP_FROM = $('rep-from').value; REP_TO = $('rep-to').value; route(); }

/* Ambil logo laporan sebagai PNG data-URL KECIL (<=180px). */
async function logoThumbDataUrl() {
  try {
    // B7: utamakan LOGO dari Pengaturan Perusahaan; fallback ke assets/logo_report.png.
    const comp = await api('admin/company').catch(() => null);
    let bmp;
    if (comp && comp.logoBase64) {
      bmp = await new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = comp.logoBase64;
      });
    } else {
      const res = await fetch('assets/logo_report.png', { cache: 'force-cache' });
      if (!res.ok) return '';
      const blob = await res.blob();
      bmp = await new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = URL.createObjectURL(blob);
      });
    }
    const max = 180;
    const scale = Math.min(1, max / Math.max(bmp.width || max, bmp.height || max));
    const w = Math.max(1, Math.round((bmp.width || max) * scale));
    const h = Math.max(1, Math.round((bmp.height || max) * scale));
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bmp, 0, 0, w, h);
    if (bmp.src && bmp.src.indexOf('blob:') === 0) URL.revokeObjectURL(bmp.src);
    return canvas.toDataURL('image/png');
  } catch (e) { return ''; }
}

function repSummary(items) {
  return {
    totalEmp: items.length,
    totalDays: items.reduce((a, x) => a + (x.daysPresent || 0), 0),
    totalLembur: items.reduce((a, x) => a + (x.overtimeApprovedMinutes || 0), 0),
    totalIzin: items.reduce((a, x) => a + (x.leaveApprovedDays || 0), 0),
    totalLate: items.reduce((a, x) => a + (x.totalLateMinutes || 0), 0),
  };
}

/* Tanggal ringkas untuk kop laporan: "23 Agu 2026". */
function compactDate(iso) {
  if (!iso) return '-';
  try {
    const d = new Date(iso + 'T00:00:00');
    if (isNaN(d)) return iso;
    return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch (e) { return iso; }
}

/* ===== Ekspor Laporan (.xlsx ASLI, profesional, nama toko + logo) ===== */
async function exportReport() {
  const btn = $('rep-export');
  try {
    if (btn) { btn.disabled = true; btn.innerHTML = 'Menyiapkan…'; }
    const d = await api('admin/report?from=' + REP_FROM + '&to=' + REP_TO);
    const items = d.items || [];
    const summary = repSummary(items);
    const printedAt = new Date().toLocaleString('id-ID', { dateStyle: 'long', timeStyle: 'short' });
    const logo = await logoThumbDataUrl();
    const comp = await api('admin/company').catch(() => null);
    const storeName = (comp && comp.name ? comp.name : 'Simaung Corporation').toUpperCase();
    const storeAddress = (comp && comp.address) ? comp.address : '';
    const zip = await buildXlsxZip({
      items,
      summary,
      fromLabel: compactDate(REP_FROM),
      toLabel: compactDate(REP_TO),
      printedAt,
      logoDataUrl: logo,
      storeName,
      subtitle: 'Laporan Absensi Karyawan',
      storeAddress,
    });
    const blob = await zip.generateAsync({
      type: 'blob',
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      compression: 'DEFLATE',
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `Laporan-Absensi-${storeName.replace(/[^A-Za-z0-9]+/g, '')}-${REP_FROM}_${REP_TO}.xlsx`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Laporan Diekspor', 'ok', 'File Excel berhasil diunduh.');
  } catch (e) { toast('Gagal', 'err', e.message); }
  finally { if (btn) { btn.disabled = false; btn.innerHTML = I.download + ' Ekspor Laporan'; } }
}
window.viewLaporan = viewLaporan; window.applyReport = applyReport; window.exportReport = exportReport;
window.repSort = repSort; window.repQuick = repQuick; window.repSearch = repSearch;

/**
 * Ekspor laporan ke PDF melalui dialog cetak peramban (Simpan sebagai PDF).
 * Menghasilkan dokumen rapi dengan kop toko, ringkasan KPI, dan tabel rincian.
 * Tidak memerlukan pustaka tambahan sehingga ringan & andal di semua perangkat.
 */
async function exportReportPdf() {
  const btn = $('rep-pdf');
  try {
    if (btn) { btn.disabled = true; btn.innerHTML = 'Menyiapkan…'; }
    const d = await api('admin/report?from=' + REP_FROM + '&to=' + REP_TO);
    const items = (d.items || []).slice().sort((a, b) => b.daysPresent - a.daysPresent);
    const days = REP_DAYS();
    const tot = {
      days: items.reduce((a, x) => a + x.daysPresent, 0),
      otMin: items.reduce((a, x) => a + (x.overtimeApprovedMinutes || 0), 0),
      leave: items.reduce((a, x) => a + (x.leaveApprovedDays || 0), 0),
      lateMin: items.reduce((a, x) => a + (x.totalLateMinutes || 0), 0),
      lateCnt: items.reduce((a, x) => a + (x.lateCount || 0), 0),
    };
    const now = new Date().toLocaleString('id-ID', { dateStyle: 'long', timeStyle: 'short' });
    const logo = await logoThumbDataUrl().catch(() => '');
    const comp = await api('admin/company').catch(() => null);
    const storeName = (comp && comp.name ? comp.name : 'Simaung Corporation').toUpperCase();
    const storeAddress = (comp && comp.address) ? comp.address : '';
    const storePhone = (comp && comp.phone) ? comp.phone : '';
    const rows = items.map((r, i) => {
      const pct = Math.min(100, Math.round((r.daysPresent / days) * 100));
      return `<tr>
        <td class="c">${i + 1}</td>
        <td><b>${esc(r.fullName)}</b><div class="mut">${esc(r.employeeCode)} • ${esc(r.position || '-')}</div></td>
        <td class="c">${r.daysPresent}</td>
        <td class="c">${r.checkIns}</td>
        <td class="c">${r.overtimeApprovedMinutes > 0 ? (Math.round((r.overtimeApprovedMinutes / 60) * 10) / 10) + ' jam' : '-'}</td>
        <td class="c">${(r.leaveApprovedDays || 0) > 0 ? r.leaveApprovedDays + ' hari' : '-'}</td>
        <td class="c">${(r.totalLateMinutes || 0) > 0 ? r.totalLateMinutes + ' mnt' + ((r.lateCount || 0) > 0 ? ' (' + r.lateCount + '×)' : '') : '-'}</td>
        <td class="c">${pct}%</td>
      </tr>`;
    }).join('');
    const html = `<!doctype html><html lang="id"><head><meta charset="utf-8"><title>Laporan Absensi ${esc(storeName)}</title>
      <style>
        *{box-sizing:border-box} body{font-family:'Segoe UI',Roboto,Arial,sans-serif;color:#1F2937;margin:0;padding:26px}
        .head{display:flex;align-items:center;gap:16px;border-bottom:3px solid #036D19;padding-bottom:14px}
        .head img{height:60px} .head h1{margin:0;font-size:21px;color:#036D19;letter-spacing:-.02em}
        .head .sub{font-size:12px;color:#6B7280;margin-top:2px}
        .meta{margin-left:auto;text-align:right;font-size:12px;color:#374151}
        .kpis{display:flex;gap:12px;margin:18px 0}
        .kpi{flex:1;border:1px solid #D8E3D6;border-radius:12px;padding:12px 14px;background:#F3F7F2}
        .kpi span{display:block;font-size:10.5px;color:#6B7280;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
        .kpi b{font-size:22px;color:#036D19}
        table{width:100%;border-collapse:collapse;margin-top:6px}
        th,td{padding:8px 9px;border-bottom:1px solid #E6EAE3;font-size:12.5px;text-align:left;vertical-align:middle}
        th{background:#036D19;color:#fff;font-size:11.5px;text-transform:uppercase;letter-spacing:.03em}
        .c{text-align:center} .mut{color:#6B7280;font-size:11px}
        tbody tr:nth-child(even){background:#FAFCF9}
        .foot{margin-top:18px;font-size:11px;color:#6B7280;display:flex;justify-content:space-between}
        @media print{body{padding:8px} .kpis{page-break-inside:avoid} tr{page-break-inside:avoid}}
      </style></head><body>
      <div class="head">
        ${logo ? `<img src="${logo}" alt="Logo">` : ''}
        <div><h1>${esc(storeName)}</h1><div class="sub">Laporan Absensi Karyawan</div>
        ${storeAddress ? `<div class="sub" style="margin-top:3px">${esc(storeAddress)}</div>` : ''}
        ${storePhone ? `<div class="sub" style="margin-top:2px">Telp: ${esc(storePhone)}</div>` : ''}</div>
        <div class="meta"><div><b>Periode</b></div><div>${esc(compactDate(REP_FROM))} — ${esc(compactDate(REP_TO))}</div><div style="margin-top:4px">${days} hari</div><div style="margin-top:4px">Dicetak: ${esc(now)}</div></div>
      </div>
      <div class="kpis">
        <div class="kpi"><span>Karyawan</span><b>${items.length}</b></div>
        <div class="kpi"><span>Total Hari Hadir</span><b>${tot.days}</b></div>
        <div class="kpi"><span>Lembur Disetujui</span><b>${durLabel(tot.otMin)}</b></div>
        <div class="kpi"><span>Izin Disetujui</span><b>${tot.leave} hari</b></div>
        <div class="kpi"><span>Keterlambatan</span><b>${tot.lateMin} mnt</b></div>
      </div>
      <table>
        <thead><tr><th class="c">No</th><th>Karyawan</th><th class="c">Hadir</th><th class="c">Check-in</th><th class="c">Lembur</th><th class="c">Izin</th><th class="c">Terlambat</th><th class="c">Kehadiran</th></tr></thead>
        <tbody>${rows || '<tr><td colspan="8" class="c">Tidak ada data.</td></tr>'}</tbody>
      </table>
      <div class="foot"><span>${esc(storeName)} • Sistem Absensi</span><span>Dokumen dibuat otomatis oleh panel superadmin.</span></div>
      <script>window.onload=function(){setTimeout(function(){window.print();},350);};</script>
      </body></html>`;
    const w = window.open('', '_blank');
    if (!w) { toast('Popup diblokir', 'err', 'Izinkan popup untuk mengekspor PDF, atau gunakan Ekspor Excel.'); return; }
    w.document.open(); w.document.write(html); w.document.close();
    toast('Siap Cetak/PDF', 'ok', 'Jendela cetak terbuka — pilih “Simpan sebagai PDF”.');
  } catch (e) { toast('Gagal', 'err', e.message); }
  finally { if (btn) { btn.disabled = false; btn.innerHTML = I.download + ' Ekspor PDF'; } }
}
window.exportReportPdf = exportReportPdf;

/* ===================== 5. SHIFT & JADWAL (redesain + mingguan) ===================== */
let SHIFTS = [];
let SHIFT_LOCS = [];   // B75: lokasi kantor untuk dropdown shift
let WEEK_START = mondayOfISO(todayISO());
let WEEK_ITEMS = [];                 // hasil server
let WEEK_DIRTY = {};                 // key `${empId}|${date}` -> {shiftId, note}
const DOW = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];

/* --- state tampilan jadwal (mobile) & pencarian --- */
let SCH_DAY = null;                  // hari terpilih (tanggal ISO) pada tampilan mobile
let SCH_QUERY = '';                  // kata kunci pencarian karyawan
let SCH_FILTER = 'all';              // all | set | empty
function pickSchDay(date) { SCH_DAY = date; renderShiftPage(); }
function schSearchInput(v) {
  SCH_QUERY = v || '';
  const box = document.getElementById('sch-list-body');
  if (box) box.innerHTML = schDayBody();
}
function schClearSearch() { SCH_QUERY = ''; const i = document.getElementById('sch-q'); if (i) i.value = ''; renderShiftPage(); }
function schSetFilter(f) { SCH_FILTER = f; renderShiftPage(); }
window.pickSchDay = pickSchDay; window.schSearchInput = schSearchInput;
window.schClearSearch = schClearSearch; window.schSetFilter = schSetFilter;

/* Baris hari (1 karyawan) pada tampilan mobile berbasis-hari */
function schDayRow(it, date) {
  const sid = effectiveShiftId(it, date);
  const note = effectiveNote(it, date);
  const isOff = note === 'OFF';
  const sh = sid ? shiftById(sid) : null;
  let cls = 'sdr-val', txt = 'Belum diatur', dot = 'background:#8a8f80';
  if (isOff) { cls += ' off'; txt = 'Libur / Off'; dot = 'background:#FDECEC;border:1px solid #e6b9b9'; }
  else if (sid && sh) { cls += ' has'; txt = `${esc(sh.name)} · ${sh.startTime}–${sh.endTime}`; dot = `background:${shiftColor(sid)}`; }
  return `<button class="sdr" onclick="openSlotEditor('${it.employeeId}','${date}')">
      ${avatarHtml(it)}
      <span class="sdr-main"><b>${esc(it.fullName)}</b><span>${esc(it.employeeCode)}${it.defaultShiftName ? ' • ' + esc(it.defaultShiftName) : ''}</span></span>
      <span class="sdr-right"><i class="sdr-dot" style="${dot}"></i><span class="${cls}">${txt}</span></span>
    </button>`;
}

/* Isi daftar hari terpilih (dipakai ulang oleh pencarian tanpa render penuh) */
function schDayBody() {
  return schDayListHTML(SCH_DAY || dateOfIdx(0));
}

/* Daftar karyawan untuk satu hari */
function schDayListHTML(date) {
  const items = filteredWeekItems(date);
  if (items.length === 0) {
    return '<div class="empty">Tidak ada karyawan yang cocok.</div>';
  }
  const set = items.filter((it) => effectiveShiftId(it, date)).length;
  const off = items.filter((it) => effectiveNote(it, date) === 'OFF').length;
  return `<div class="sdr-head">
      <span class="sdr-sum"><b>${items.length}</b> karyawan • <b>${set}</b> terisi • <b>${off}</b> libur</span>
    </div>
    <div class="sdr-list">${items.map((it) => schDayRow(it, date)).join('')}</div>`;
}

/* Terapkan pencarian + filter pada daftar karyawan */
function filteredWeekItems(date) {
  const q = (SCH_QUERY || '').trim().toLowerCase();
  let list = WEEK_ITEMS;
  if (q) list = list.filter((it) => (it.fullName || '').toLowerCase().includes(q) || (it.employeeCode || '').toLowerCase().includes(q));
  if (SCH_FILTER === 'set') list = list.filter((it) => effectiveShiftId(it, date) || effectiveNote(it, date) === 'OFF');
  else if (SCH_FILTER === 'empty') list = list.filter((it) => !effectiveShiftId(it, date) && effectiveNote(it, date) !== 'OFF');
  return list;
}

async function viewShift() {
  $('top-actions').innerHTML = `<button class="btn btn-ghost" onclick="openImportJadwal()">📥 Import Excel</button> <button class="btn btn-orange" onclick="openShiftModal()">+ Tambah Shift</button>`;
  const [sh, emp, comp] = await Promise.all([api('admin/shifts'), api('admin/employees'), api('admin/company')]);
  SHIFTS = sh.items || [];
  SHIFT_CACHE = SHIFTS;
  EMP_CACHE = emp.items || [];
  // B75: daftar lokasi kantor untuk dropdown shift.
  SHIFT_LOCS = (comp && (comp.officeLocations || comp.locations)) || [];
  await loadWeek();
  renderShiftPage();
}
async function loadWeek() {
  const d = await api('admin/schedule?weekStart=' + WEEK_START);
  WEEK_START = d.weekStart;
  WEEK_ITEMS = d.items || [];
  WEEK_DIRTY = {};
}

function totalWeekSlots() { return WEEK_ITEMS.length * 7; }
function countUnscheduled() { return WEEK_ITEMS.reduce((a, it) => a + DOW.filter((_, i) => !effectiveShiftId(it, dateOfIdx(i))).length, 0); }
function dateOfIdx(i) { return addDaysISO(WEEK_START, i); }
function effectiveShiftId(it, date) {
  const dirty = WEEK_DIRTY[it.employeeId + '|' + date];
  const base = dirty ? dirty.shiftId : (it.days[date] ? it.days[date].shiftId : null);
  return base || null;
}
function effectiveNote(it, date) {
  const dirty = WEEK_DIRTY[it.employeeId + '|' + date];
  return dirty ? dirty.note : (it.days[date] ? it.days[date].note : null);
}
function weekLabel() {
  return `${dayShort(WEEK_START)} – ${dayShort(addDaysISO(WEEK_START, 6))}`;
}

/* Deteksi otomatis apakah perangkat layar kecil (HP). Ambang 820px. */
function isMobile() {
  return (window.matchMedia && window.matchMedia('(max-width: 820px)').matches) || window.innerWidth <= 820;
}
window.isMobile = isMobile;

/* Sel jadwal (dipakai tabel desktop) */
function slotButton(it, date) {
  const sid = effectiveShiftId(it, date);
  const note = effectiveNote(it, date);
  const isOff = note === 'OFF';
  const sh = sid ? shiftById(sid) : null;
  let cls = 'sch-slot', style = '';
  if (isOff) cls += ' off';
  else if (sid) { cls += ' has'; style = `background:${shiftColor(sid)};border-color:${shiftColor(sid)}`; }
  const label = isOff ? 'Libur' : (sh ? esc(sh.name) : '—');
  const time = sh && !isOff ? `${sh.startTime}-${sh.endTime}` : (isOff ? 'OFF' : 'atur');
  return `<button class="${cls}" style="${style}" onclick="openSlotEditor('${it.employeeId}','${date}')" title="${esc(it.fullName)} • ${dayLabel(date)}">${label}<span class="t">${time}</span></button>`;
}

/* Kartu jadwal 1 karyawan (dipakai tampilan HP) */
function shiftCard(it) {
  const unsched = DOW.filter((_, i) => !effectiveShiftId(it, dateOfIdx(i))).length;
  const dayRow = (d, i) => {
    const date = dateOfIdx(i);
    const sid = effectiveShiftId(it, date);
    const note = effectiveNote(it, date);
    const isOff = note === 'OFF';
    const sh = sid ? shiftById(sid) : null;
    const today = date === todayISO();
    let valCls = 'dc-val none', valTxt = 'Kosong';
    if (isOff) { valCls = 'dc-val off'; valTxt = 'Libur'; }
    else if (sid) { valCls = 'dc-val'; valTxt = esc(sh ? sh.name : '—') + (sh ? ` · ${sh.startTime}-${sh.endTime}` : ''); }
    const dotStyle = isOff ? 'background:#FDECEC;border:1px solid #e6b9b9' : (sid ? `background:${shiftColor(sid)}` : 'background:#8a8f80');
    return `<button class="dc-day ${today ? 'today' : ''} ${isOff ? 'off' : (sid ? 'has' : '')}" onclick="openSlotEditor('${it.employeeId}','${date}')">
        <span class="dc-when"><span class="dc-wd">${d}${today ? ' <em>• hari ini</em>' : ''}</span><span class="dc-dt">${dayShort(date)}</span></span>
        <span class="dc-shift"><i class="dc-dot" style="${dotStyle}"></i><span class="${valCls}">${valTxt}</span></span>
      </button>`;
  };
  return `
    <div class="sched-card">
      <div class="sched-card-h">
        <div class="row-user">${avatarHtml(it)}
          <div><b>${esc(it.fullName)}</b><span>${esc(it.employeeCode)}${it.defaultShiftName ? ' • default: ' + esc(it.defaultShiftName) : ''}</span></div></div>
        ${unsched ? `<span class="badge b-orange">${unsched} kosong</span>` : `<span class="badge b-green">penuh</span>`}
      </div>
      <div class="dc-list">${DOW.map(dayRow).join('')}</div>
    </div>`;
}

/* Rangkaian kartu mingguan (tabel) di atas — header minggu */
function weekNavHTML() {
  return `
    <div class="week-nav">
      <button class="btn btn-ghost btn-sm" onclick="weekShift(-1)" aria-label="Minggu sebelumnya">‹</button>
      <button class="btn btn-ghost btn-sm" onclick="weekToToday()">Minggu Ini</button>
      <span class="wk-label">${weekLabel()}</span>
      <button class="btn btn-ghost btn-sm" onclick="weekShift(1)" aria-label="Minggu berikutnya">›</button>
    </div>`;
}

function shiftLegendHTML() {
  return `
    <div class="sch-legend">
      <span><i style="background:#8a8f80"></i> Belum diatur</span>
      <span><i style="background:#FDECEC;border:1px solid #e6b9b9"></i> Libur / Off</span>
      ${SHIFTS.map((s) => `<span><i style="background:${shiftColor(s.id)}"></i> ${esc(s.name)} (${s.startTime}-${s.endTime})</span>`).join('')}
    </div>`;
}

function saveBarHTML() {
  const n = Object.keys(WEEK_DIRTY).length;
  return `
    <div class="save-bar">
      <span class="sb-status">${n ? n + ' perubahan belum disimpan' : 'Tidak ada perubahan'}</span>
      <div class="sb-actions">
        <button class="btn btn-ghost" onclick="clearWeekEdits()">Reset</button>
        <button class="btn btn-primary" style="width:auto;padding:12px 24px" onclick="saveWeek()">Simpan Jadwal</button>
      </div>
    </div>`;
}

function renderShiftDesktop() {
  return `
    <div class="only-desk">
      <div class="section-title" style="justify-content:space-between;align-items:center">
        <span style="display:flex;align-items:center;gap:9px"><span class="ic">${I.cal}</span> Jadwal Mingguan per Karyawan</span>
        ${weekNavHTML()}
      </div>
      <div class="sch-tools" style="margin:0 0 8px">
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-sm btn-ghost" onclick="fillDefaultPrompt()">Isi Otomatis (Shift Default)</button>
          <button class="btn btn-sm btn-ghost" onclick="copyPrevWeek()">Salin Minggu Lalu</button>
          <button class="btn btn-sm btn-ghost" onclick="openImportJadwal()">Impor Excel</button>
        </div>
      </div>
      <div class="ttl" style="margin:-6px 0 12px">Klik kotak <b>tanggal</b> pada baris karyawan untuk menetapkan shift hari itu. Jadwal ini <b>menimpa</b> shift default dan otomatis dipakai di aplikasi karyawan.</div>
      ${shiftLegendHTML()}
      ${WEEK_ITEMS.length === 0 ? '<div class="empty">Belum ada karyawan aktif.</div>' : `
      <div class="sch-scroll">
        <table class="sch-table">
          <thead><tr>
            <th class="emp">Karyawan</th>
            ${DOW.map((d, i) => {
              const iso = dateOfIdx(i);
              const today = iso === todayISO();
              return `<th style="${today ? 'background:var(--brand-050)' : ''}"><span class="dow">${d}</span><span class="dt">${dayShort(iso)}</span></th>`;
            }).join('')}
          </tr></thead>
          <tbody>
          ${WEEK_ITEMS.map((it) => `
            <tr>
              <td>
                <div class="row-user">${avatarHtml(it)}
                  <div><b>${esc(it.fullName)}</b><span>${esc(it.employeeCode)}${it.defaultShiftName ? ' • default: ' + esc(it.defaultShiftName) : ''}</span></div></div>
              </td>
              ${DOW.map((_, i) => {
                const date = dateOfIdx(i);
                const today = date === todayISO();
                return `<td class="sch-cell ${today ? 'today' : ''}">${slotButton(it, date)}</td>`;
              }).join('')}
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      ${saveBarHTML()}`}
    </div>`;
}

function renderShiftMobile() {
  if (WEEK_ITEMS.length === 0) {
    return `<div class="only-mob">
      <div class="section-title"><span class="ic">${I.cal}</span> Jadwal Mingguan</div>
      ${weekNavHTML()}
      <div class="empty">Belum ada karyawan aktif.</div>
    </div>`;
  }
  const todayIdx = DOW.findIndex((_, i) => dateOfIdx(i) === todayISO());
  if (!SCH_DAY || !DOW.some((_, i) => dateOfIdx(i) === SCH_DAY)) SCH_DAY = dateOfIdx(todayIdx >= 0 ? todayIdx : 0);
  const active = SCH_DAY;
  const dayChips = DOW.map((d, i) => {
    const date = dateOfIdx(i);
    const on = date === active;
    const isToday = date === todayISO();
    return `<button class="day-chip ${on ? 'on' : ''} ${isToday ? 'today' : ''}" onclick="pickSchDay('${date}')">
        <span class="dc-wd">${d.slice(0, 3)}</span><span class="dc-dt">${dayShort(date)}</span>
      </button>`;
  }).join('');
  const filters = [['all', 'Semua'], ['set', 'Sudah diatur'], ['empty', 'Belum diatur']]
    .map(([k, lbl]) => `<button class="fchip ${SCH_FILTER === k ? 'on' : ''}" onclick="schSetFilter('${k}')">${lbl}</button>`).join('');
  return `
    <div class="only-mob">
      <div class="section-title"><span class="ic">${I.cal}</span> Jadwal Mingguan</div>
      <div class="week-head">
        <button class="wk-arrow" onclick="weekShift(-1)" aria-label="Minggu sebelumnya">‹</button>
        <button class="wk-pill" onclick="weekToToday()">${weekLabel()}</button>
        <button class="wk-arrow" onclick="weekShift(1)" aria-label="Minggu berikutnya">›</button>
      </div>
      <div class="day-chips">${dayChips}</div>
      <div class="sch-tools">
        <div class="sch-search">
          <span class="s-ic"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"></circle><path d="M21 21l-4.3-4.3"></path></svg></span>
          <input id="sch-q" type="search" placeholder="Cari karyawan…" value="${esc(SCH_QUERY)}" oninput="schSearchInput(this.value)">
        </div>
        <div class="fchips">${filters}</div>
      </div>
      <div class="sch-tools" style="margin:-4px 0 8px">
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-sm btn-ghost" onclick="fillDefaultPrompt()">Isi Otomatis</button>
          <button class="btn btn-sm btn-ghost" onclick="copyPrevWeek()">Salin Minggu Lalu</button>
          <button class="btn btn-sm btn-ghost" onclick="openImportJadwal()">Impor Excel</button>
        </div>
      </div>
      <div id="sch-list-body">${schDayListHTML(active)}</div>
      ${saveBarHTML()}
    </div>`;
}

function shiftListCard() {
  const activeBadge = (s) => (s.active === false ? '<span class="badge b-grey">Nonaktif</span>' : '<span class="badge b-green">Aktif</span>');
  const locBadge = (s) => (s.officeLocationId
    ? `<span class="badge b-blue" title="Shift khusus lokasi">${esc(s.officeLocationName || 'Lokasi')}</span>`
    : '<span class="badge b-grey" title="Berlaku di semua lokasi">Semua Lokasi</span>');
  const listMobile = `<div class="only-mob"><div class="shift-list">${SHIFTS.map((s) => `
        <div class="shift-row" style="${s.active === false ? 'opacity:.55' : ''}">
          <span class="sr-dot" style="background:${shiftColor(s.id)}"></span>
          <div class="sr-main"><b>${esc(s.name)} ${activeBadge(s)}</b><span>${esc(s.startTime)} – ${esc(s.endTime)} • ${durLabel(diffMins(s.startTime, s.endTime))} • ${locBadge(s)}</span></div>
          <div class="sr-actions">
            <button class="btn btn-sm btn-ghost" onclick="openShiftModal('${s.id}')">Edit</button>
            <button class="btn btn-sm btn-danger" onclick="delShift('${s.id}')">Hapus</button>
          </div>
        </div>`).join('')}</div></div>`;
  const tableDesktop = `<div class="only-desk table-wrap">
      <table>
        <thead><tr><th>Nama Shift</th><th>Jam Masuk</th><th>Jam Keluar</th><th>Durasi</th><th>Lokasi Kantor</th><th>Karyawan (default)</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
        ${SHIFTS.map((s) => `
          <tr style="${s.active === false ? 'opacity:.55' : ''}">
            <td><span style="display:inline-flex;align-items:center;gap:8px"><i style="width:12px;height:12px;border-radius:4px;background:${shiftColor(s.id)};display:inline-block"></i><b>${esc(s.name)}</b></span></td>
            <td>${esc(s.startTime)}</td>
            <td>${esc(s.endTime)}</td>
            <td>${durLabel(diffMins(s.startTime, s.endTime))}</td>
            <td>${locBadge(s)}</td>
            <td><span class="badge b-blue">${s.employeeCount} orang</span></td>
            <td>${activeBadge(s)}</td>
            <td style="white-space:nowrap">
              <button class="btn btn-sm btn-ghost" onclick="openShiftModal('${s.id}')">Edit</button>
              <button class="btn btn-sm btn-danger" onclick="delShift('${s.id}')">Hapus</button>
            </td>
          </tr>`).join('')}
        </tbody>
      </table></div>`;
  return `
    <div class="card">
      <div class="section-title" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <span style="display:flex;align-items:center;gap:9px"><span class="ic">${I.clock}</span> Daftar Shift Kerja</span>
      </div>
      <div class="ttl" style="margin:-4px 0 12px">Shift &amp; jadwal mengikuti <b>lokasi kantor</b>. Tetapkan shift ke lokasi agar jam kerjanya khusus cabang tersebut.</div>
      ${SHIFTS.length === 0 ? '<div class="empty">Belum ada shift. Tambahkan shift terlebih dahulu.</div>' : (listMobile + tableDesktop)}
    </div>`;
}

function renderShiftPage() {
  $('view').innerHTML = `<div class="card" style="padding:0;border:none;background:transparent;box-shadow:none;margin:0">
      ${renderShiftDesktop()}${renderShiftMobile()}
    </div>` + shiftListCard() + `<div id="loc-settings-section" style="margin-top:16px"><div class="card"><div class="skeleton" style="height:16px"></div><div class="skeleton" style="height:16px;margin-top:8px;width:60%"></div></div></div>`;
  lsReload();
}
window.renderShiftPage = renderShiftPage;

function weekShift(delta) { WEEK_START = addDaysISO(WEEK_START, 7 * delta); reloadWeek(); }
function weekToToday() { WEEK_START = mondayOfISO(todayISO()); reloadWeek(); }
async function reloadWeek() {
  const v = $('view'); if (v) v.innerHTML = '<div class="loading">Memuat…</div>';
  try { await loadWeek(); renderShiftPage(); } catch (e) { toast('Gagal', 'err', e.message); }
}
window.weekShift = weekShift; window.weekToToday = weekToToday;

/* Editor sel jadwal */
let SLOT_CTX = null;
function openSlotEditor(empId, date) {
  const it = WEEK_ITEMS.find((x) => x.employeeId === empId);
  if (!it) return;
  const cur = effectiveShiftId(it, date);
  const note = effectiveNote(it, date);
  const isOff = note === 'OFF';
  SLOT_CTX = { empId, date };
  const opts = SHIFTS.map((s) => `
    <button type="button" class="shift-opt ${cur === s.id && !isOff ? 'on' : ''}" onclick="pickSlot('${s.id}')">
      <span class="dot" style="background:${shiftColor(s.id)}"></span>
      <span><span class="nm">${esc(s.name)}</span><br><span class="tm">${s.startTime} – ${s.endTime}</span></span>
    </button>`).join('');
  openModal(`
    <h3>Atur Jadwal</h3>
    <div class="muted-box" style="margin-bottom:14px">
      <b>${esc(it.fullName)}</b><br>${dayLabel(date)}
    </div>
    <div class="sch-editor">
      ${opts}
      <button type="button" class="shift-opt ${isOff ? 'on' : ''}" onclick="pickSlotOff()">
        <span class="dot" style="background:#FDECEC;border:1px solid #e6b9b9"></span>
        <span><span class="nm">Libur / Off</span><br><span class="tm">Tandai karyawan tidak masuk</span></span>
      </button>
      <button type="button" class="shift-opt ${!cur && !isOff ? 'on' : ''}" onclick="pickSlot(null)">
        <span class="dot" style="background:#8a8f80"></span>
        <span><span class="nm">Ikuti Shift Default</span><br><span class="tm">${it.defaultShiftName ? esc(it.defaultShiftName) + ' (' + it.defaultShiftStart + '-' + it.defaultShiftEnd + ')' : 'tidak ada default'}</span></span>
      </button>
    </div>
    <label style="display:flex;align-items:center;gap:8px;margin-top:14px;font-size:12.5px;color:var(--mut)">
      <input type="checkbox" id="slot-applyweek" style="width:auto"> Terapkan ke Senin–Sabtu minggu ini
    </label>
    <div class="actions">
      <button type="button" class="btn btn-ghost" onclick="closeModal()">Tutup</button>
    </div>`);
}
function pickSlot(shiftId) { commitSlot(shiftId, false); }
function pickSlotOff() { commitSlot(null, true); }
function commitSlot(shiftId, off) {
  if (!SLOT_CTX) return;
  const { empId, date } = SLOT_CTX;
  const applyWeek = $('slot-applyweek') && $('slot-applyweek').checked;
  const dates = applyWeek ? DOW.map((_, i) => dateOfIdx(i)).slice(0, 6) : [date];
  dates.forEach((dd) => { WEEK_DIRTY[empId + '|' + dd] = { shiftId, note: off ? 'OFF' : null }; });
  closeModal();
  renderShiftPage();
}
window.openSlotEditor = openSlotEditor; window.pickSlot = pickSlot; window.pickSlotOff = pickSlotOff;

function clearWeekEdits() { WEEK_DIRTY = {}; renderShiftPage(); }
window.clearWeekEdits = clearWeekEdits;

async function saveWeek() {
  const entries = Object.keys(WEEK_DIRTY).map((k) => {
    const [employeeId, date] = k.split('|');
    return { employeeId, date, shiftId: WEEK_DIRTY[k].shiftId, note: WEEK_DIRTY[k].note };
  });
  if (entries.length === 0) { toast('Tidak ada perubahan untuk disimpan'); return; }
  try {
    await api('admin/schedule', { method: 'PUT', body: { entries } });
    toast('Jadwal Tersimpan', 'ok', 'Jadwal mingguan berhasil diperbarui.');
    await loadWeek();
    renderShiftPage();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.saveWeek = saveWeek;

/* B4: Isi otomatis jadwal minggu ini dari shift default tiap karyawan */
async function fillDefaultPrompt() {
  const ok = await confirmDialog({
    title: 'Isi Otomatis Jadwal',
    icon: 'shift',
    tone: 'info',
    html:
      `<p>Isi jadwal <b>Senin–Sabtu</b> minggu ini dengan <b>shift default</b> tiap karyawan.</p>` +
      `<div class="dialog-note">${DIALOG_ICONS.shift || DIALOG_ICONS.check || ''}<span>Jadwal yang sudah ada di minggu ini akan <b>ditimpa</b>. Hari Minggu dibiarkan kosong. Karyawan tanpa shift default dilewati.</span></div>`,
    confirmLabel: 'Isi Otomatis',
  });
  if (!ok) return;
  try {
    const r = await api('admin/schedule/fill-default', { method: 'POST', body: { weekStart: WEEK_START, replace: true } });
    const n = (r && (r.written ?? r.count)) || 0;
    toast('Jadwal Terisi', 'ok', `${n} slot jadwal diisi dari shift default.`);
    await loadWeek(); renderShiftPage();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.fillDefaultPrompt = fillDefaultPrompt;

/* B4: Salin jadwal dari minggu sebelumnya ke minggu ini */
async function copyPrevWeek() {
  const prev = addDaysISO(WEEK_START, -7);
  const ok = await confirmDialog({
    title: 'Salin Minggu Lalu',
    icon: 'calendar',
    tone: 'info',
    html:
      `<p>Salin semua jadwal dari minggu <b>${dayShort(prev)} – ${dayShort(addDaysISO(prev, 6))}</b> ke minggu ini <b>${weekLabel()}</b>.</p>` +
      `<div class="dialog-note">${DIALOG_ICONS.calendar || ''}<span>Jadwal minggu ini akan <b>ditimpa</b> sesuai pola minggu lalu (hari yang sama).</span></div>`,
    confirmLabel: 'Salin',
  });
  if (!ok) return;
  try {
    const r = await api('admin/schedule/copy-week', { method: 'POST', body: { fromWeek: prev, toWeek: WEEK_START, replace: true } });
    const n = (r && (r.written ?? r.count)) || 0;
    toast('Jadwal Tersalin', 'ok', `${n} slot jadwal disalin dari minggu lalu.`);
    await loadWeek(); renderShiftPage();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.copyPrevWeek = copyPrevWeek;

/* Shift CRUD */
let SHIFT_COLOR_SEL = null;
function pickShiftColor(c) {
  SHIFT_COLOR_SEL = c;
  document.querySelectorAll('#sh-colors .swatch').forEach((el) => el.classList.toggle('on', el.dataset.color === c));
}
window.pickShiftColor = pickShiftColor;
function openShiftModal(id) {
  const s = id ? SHIFTS.find((x) => x.id === id) : null;
  SHIFT_COLOR_SEL = s ? (s.color || shiftColor(s.id)) : SHIFT_COLORS[SHIFTS.length % SHIFT_COLORS.length];
  const swatches = SHIFT_COLORS.map((c) => `<button type="button" class="swatch ${c === SHIFT_COLOR_SEL ? 'on' : ''}" data-color="${c}" style="background:${c}" onclick="pickShiftColor('${c}')" aria-label="Warna ${c}"></button>`).join('');
  // B75: shift dapat ditugaskan ke lokasi kantor tertentu (kosong = semua lokasi).
  const curLoc = s ? (s.officeLocationId || '') : '';
  const locOpts = `<option value=""${curLoc === '' ? ' selected' : ''}>🌐 Semua Lokasi (berlaku di mana saja)</option>` +
    (SHIFT_LOCS || []).map((l) => `<option value="${l.id}"${curLoc === l.id ? ' selected' : ''}>${esc(l.name)}${l.isDefault ? ' (Default)' : ''}</option>`).join('');
  openModal(`
    <h3>${s ? 'Edit Shift' : 'Tambah Shift'}</h3>
    <form onsubmit="saveShift(event, ${s ? `'${s.id}'` : 'null'})">
      <div class="field"><label>Nama Shift</label><input id="sh-name" value="${s ? esc(s.name) : ''}" placeholder="mis. Shift Pagi" required></div>
      <div class="grid g2">
        <div class="field"><label>Jam Masuk</label><input id="sh-start" type="time" value="${s ? s.startTime : '08:00'}" required></div>
        <div class="field"><label>Jam Keluar</label><input id="sh-end" type="time" value="${s ? s.endTime : '16:00'}" required></div>
      </div>
      <div class="field">
        <label>Lokasi Kantor</label>
        <select id="sh-loc">${locOpts}</select>
        <div class="ttl">Shift ini mengikuti lokasi kantor. Pilih lokasi agar jam kerjanya hanya berlaku di cabang tersebut, atau "Semua Lokasi" bila berlaku di mana saja.</div>
      </div>
      <div class="field"><label>Warna</label><div class="swatches" id="sh-colors">${swatches}</div></div>
      <label style="display:flex;align-items:center;gap:8px;margin:4px 0 8px;font-size:12.5px;color:var(--mut)">
        <input type="checkbox" id="sh-active" style="width:auto" ${!s || s.active !== false ? 'checked' : ''}> Aktif (tampil di pilihan jadwal)
      </label>
      <div class="actions">
        <button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button>
        <button type="submit" class="btn btn-primary" style="width:auto">Simpan</button>
      </div>
    </form>`);
}
async function saveShift(ev, id) {
  ev.preventDefault();
  const body = {
    name: $('sh-name').value.trim(),
    startTime: $('sh-start').value,
    endTime: $('sh-end').value,
    color: SHIFT_COLOR_SEL || null,
    active: $('sh-active') ? $('sh-active').checked : true,
    officeLocationId: ($('sh-loc') && $('sh-loc').value) ? $('sh-loc').value : null,
  };
  try {
    if (id) { await api('admin/shifts/' + id, { method: 'PUT', body }); toast('Shift Diperbarui', 'ok', 'Pengaturan shift berhasil disimpan.'); }
    else { await api('admin/shifts', { method: 'POST', body }); toast('Shift Ditambahkan', 'ok', 'Shift baru berhasil dibuat.'); }
    closeModal(); route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
async function delShift(id) {
  const ok = await confirmDialog({
    title: 'Hapus Shift',
    icon: 'trash',
    tone: 'danger',
    html:
      `<p>Shift ini akan dihapus dari daftar.</p>` +
      `<div class="dialog-note">${DIALOG_ICONS.trash}<span>Jadwal mingguan yang terkait dengan shift ini <b>ikut terhapus</b>.</span></div>`,
    confirmLabel: 'Hapus Shift',
  });
  if (!ok) return;
  try { await api('admin/shifts/' + id, { method: 'DELETE' }); toast('Shift Dihapus', 'ok'); route(); }
  catch (err) { toast('Gagal Menghapus', 'err', err.message); }
}
window.viewShift = viewShift; window.openShiftModal = openShiftModal; window.saveShift = saveShift;
window.delShift = delShift;

/* ===================== IMPORT JADWAL DARI EXCEL ===================== */
/* Mengurai berkas Excel (.xlsx/.xls/.csv) berisi matriks jadwal bulanan:
     Baris 1 : header hari  (Senin, Selasa, …) — opsional
     Baris 2 : angka tanggal (1, 2, 3, …)
     Baris 3+: Nama | sel-sel shift (P / S / OFF / kosong)
   Sel dipetakan: OFF/L -> libur, lainnya -> shift (Pagi/Siang) sesuai pilihan.
   Format contoh: "Shifting Tk Kartini". */
let IMP_ROWS = null;       // hasil parsing
let IMP_MONTH = null;      // {year, month} terdeteksi
let IMP_MONTHS = [];       // daftar bulan tersedia di berkas

function openImportJadwal() {
  IMP_ROWS = null; IMP_MONTH = null; IMP_MONTHS = [];
  openModal(`
    <h3>Import Jadwal dari Excel</h3>
    <div class="muted-box" style="margin-bottom:12px;line-height:1.6">
      Unggah berkas jadwal shift bulanan (format <b>Shifting</b>). Baris = nama karyawan,
      kolom = tanggal. Isi sel: <b>P</b> (Pagi), <b>S</b> (Siang), <b>OFF/L</b> (libur).
      Nama karyawan dicocokkan otomatis dengan data karyawan.
    </div>
    <div class="field">
      <label>Berkas Excel / CSV</label>
      <input type="file" id="imp-file" accept=".xlsx,.xls,.csv">
    </div>
    <div id="imp-status" class="ttl"></div>
    <div class="actions">
      <button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button>
      <button type="button" class="btn btn-primary" id="imp-go" style="width:auto" disabled onclick="importJadwalSubmit()">Import</button>
    </div>`);
  const f = $('imp-file');
  if (f) f.addEventListener('change', () => importJadwalParse());
}
window.openImportJadwal = openImportJadwal;

async function importJadwalParse() {
  const f = $('imp-file');
  const st = $('imp-status');
  if (!f || !f.files || !f.files.length) return;
  const go = $('imp-go'); if (go) go.disabled = true;
  if (st) st.textContent = 'Membaca berkas…';
  try {
    if (typeof XLSX === 'undefined') throw new Error('Pustaka Excel belum siap, muat ulang halaman.');
    const buf = await f.files[0].arrayBuffer();
    const wb = XLSX.read(buf, { type: 'array' });
    const parsed = parseShiftWorkbook(wb);
    if (!parsed.rows.length) throw new Error('Tidak menemukan data jadwal pada berkas ini.');
    IMP_ROWS = parsed.rows; IMP_MONTH = parsed.month; IMP_MONTHS = parsed.months || [];
    if (st) st.innerHTML = `✅ Terbaca: <b>${IMP_ROWS.length}</b> baris karyawan${IMP_MONTH ? ' • periode ' + IMP_MONTH.monthLabel + ' ' + IMP_MONTH.year : ''}. Pilih bulan &amp; opsi lalu klik <b>Import</b>.`;
    if (go) go.disabled = false;
    // Sisipkan pilihan bulan & shift bila belum ada.
    if (!$('imp-opts')) {
      const monthSel = IMP_MONTHS.length > 1
        ? `<div class="field"><label>Bulan</label><select id="imp-month">${IMP_MONTHS.map((m, i) => `<option value="${i}" ${i === 0 ? 'selected' : ''}>${m.monthLabel} ${m.year} (${m.rows.length} karyawan)</option>`).join('')}</select></div>`
        : '';
      const shiftOpts = (SHIFTS || []).map((s) => `<option value="${s.id}">${esc(s.name)} (${s.startTime}-${s.endTime})</option>`).join('');
      const div = document.createElement('div');
      div.id = 'imp-opts';
      div.innerHTML = `
        ${monthSel}
        <div class="grid g2">
          <div class="field"><label>Kode "P" → Shift</label><select id="imp-codeP">${shiftOpts}</select></div>
          <div class="field"><label>Kode "S" → Shift</label><select id="imp-codeS">${shiftOpts}</select></div>
        </div>
        <label style="display:flex;align-items:center;gap:8px;margin:4px 0 8px;font-size:12.5px;color:var(--mut)">
          <input type="checkbox" id="imp-replace" style="width:auto"> Timpa jadwal lama pada tanggal yang diimpor
        </label>`;
      const actions = document.querySelector('#modal .actions') || document.querySelector('.actions');
      if (actions && actions.parentNode) actions.parentNode.insertBefore(div, actions);
      // Ganti bulan aktif -> ganti baris yang akan diimpor.
      const mSel = $('imp-month');
      if (mSel) mSel.addEventListener('change', () => {
        const mm = IMP_MONTHS[parseInt(mSel.value, 10)];
        if (!mm) return;
        IMP_ROWS = mm.rows; IMP_MONTH = { year: mm.year, month: mm.month, monthLabel: mm.monthLabel };
        if (st) st.innerHTML = `✅ Terbaca: <b>${IMP_ROWS.length}</b> baris karyawan • periode ${mm.monthLabel} ${mm.year}.`;
      });
    }
    // Pra-isi pilihan P/S bila nama shift cocok.
    const pSel = $('imp-codeP'), sSel = $('imp-codeS');
    if (pSel) { const m = (SHIFTS || []).find((x) => /pagi|^p$/i.test(x.name)); if (m) pSel.value = m.id; }
    if (sSel) { const m = (SHIFTS || []).find((x) => /siang|^s$/i.test(x.name)); if (m) sSel.value = m.id; }
  } catch (e) {
    IMP_ROWS = null;
    if (st) st.innerHTML = `❌ ${esc(e.message)}`;
  }
}
window.importJadwalParse = importJadwalParse;

const MONTH_LABELS = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const MONTH_LOWER = MONTH_LABELS.map((m) => m.toLowerCase());
function daysInMonth(y, m) { return new Date(y, m + 1, 0).getDate(); }
function dowIndex(raw) {
  const s = String(raw || '').toLowerCase().replace(/[^a-z]/g, '');
  if (s.startsWith('min')) return 0;
  if (s.startsWith('sen')) return 1;
  if (s.startsWith('sel')) return 2;
  if (s.startsWith('rab')) return 3;
  if (s.startsWith('kam')) return 4;
  if (s.startsWith('jum')) return 5;
  if (s.startsWith('sab')) return 6;
  return -1;
}
/* Tentukan TAHUN dari baris nama-hari (Senin..Minggu) + baris angka tanggal. */
function detectYear(dayNames, dayNums, monthIdx) {
  const now = new Date();
  let bestYear = now.getFullYear(), best = -1;
  for (let yy = now.getFullYear() - 2; yy <= now.getFullYear() + 2; yy++) {
    const dim = daysInMonth(yy, monthIdx);
    let score = 0, checked = 0;
    for (let i = 0; i < dayNums.length; i++) {
      const dn = dayNums[i];
      if (!dn || dn < 1 || dn > dim) continue;
      const want = dowIndex(dayNames && dayNames[i]);
      if (want < 0) continue;
      checked++;
      if (new Date(yy, monthIdx, dn).getDay() === want) score++;
    }
    const val = checked ? (score / checked) * 1000 + score : -1;
    if (val > best) { best = val; bestYear = yy; }
  }
  return bestYear;
}

/* Urai satu sheet (matriks) berdasarkan indeks bulan target (0=Jan .. 11=Des). */
function parseMonthSheet(aoa, monthIdx) {
  let dayRowIdx = -1, dayRow = null;
  for (let i = 0; i < Math.min(aoa.length, 14); i++) {
    const row = aoa[i] || [];
    const nums = row.map((v) => { const n = parseInt(String(v).replace(/[^0-9]/g, ''), 10); return Number.isFinite(n) ? n : null; });
    const cnt = nums.filter((n) => n && n >= 1 && n <= 31).length;
    if (cnt >= 8) { dayRowIdx = i; dayRow = nums; break; }
  }
  if (dayRowIdx < 0) return null;
  const wdRow = aoa[dayRowIdx - 1] || [];
  const year = wdRow.filter((v) => dowIndex(v) >= 0).length >= 3 ? detectYear(wdRow, dayRow, monthIdx) : new Date().getFullYear();
  // Kolom pertama yang bernilai 1 = awal bulan target.
  let c1 = -1;
  for (let i = 1; i < dayRow.length; i++) { if (dayRow[i] === 1) { c1 = i; break; } }
  if (c1 < 0) c1 = 1;
  // Peta kolom -> tanggal ISO (mendukung ekor bulan sebelumnya & awal bulan berikutnya).
  const colIso = {};
  let curMonth = monthIdx, curYear = year, lastDn = null;
  for (let i = c1; i < dayRow.length; i++) {
    const dn = dayRow[i];
    if (!dn || dn < 1 || dn > 31) continue;
    if (lastDn != null && dn < lastDn) { curMonth++; if (curMonth > 11) { curMonth = 0; curYear++; } }
    const dim = daysInMonth(curYear, curMonth);
    if (dn <= dim) colIso[i] = `${curYear}-${String(curMonth + 1).padStart(2, '0')}-${String(dn).padStart(2, '0')}`;
    lastDn = dn;
  }
  // Baris karyawan: dari baris setelah tanggal hingga baris "Pagi/Siang".
  const rows = [];
  for (let i = dayRowIdx + 1; i < aoa.length; i++) {
    const row = aoa[i] || [];
    const name = String(row[0] == null ? '' : row[0]).trim();
    if (!name) continue;
    if (['pagi', 'siang', 'malam', 'sore', 'nama', 'shift'].includes(name.toLowerCase())) break;
    const days = {};
    for (let c = 1; c < row.length; c++) {
      if (!colIso[c]) continue;
      const code = String(row[c] == null ? '' : row[c]).trim();
      if (!code) continue;
      days[colIso[c]] = code;
    }
    if (Object.keys(days).length) rows.push({ name, days });
  }
  return { year, rows };
}

/* Urai seluruh workbook: setiap sheet bernama bulan (Januari..Desember) -> satu periode.
   Bila tidak ada sheet bulan, pakai sheet pertama dengan deteksi bulan otomatis. */
function parseShiftWorkbook(wb) {
  const months = [];
  for (const name of wb.SheetNames) {
    const ln = String(name).toLowerCase().trim();
    const mi = MONTH_LOWER.indexOf(ln);
    if (mi < 0) continue;
    const aoa = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, raw: true, defval: '' });
    const p = parseMonthSheet(aoa, mi);
    if (p && p.rows.length) months.push({ year: p.year, month: mi, monthLabel: MONTH_LABELS[mi], rows: p.rows });
  }
  if (!months.length) {
    const mi = new Date().getMonth();
    const aoa = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: true, defval: '' });
    const p = parseMonthSheet(aoa, mi);
    if (!p || !p.rows.length) throw new Error('Tidak menemukan data jadwal pada berkas ini.');
    months.push({ year: p.year, month: mi, monthLabel: MONTH_LABELS[mi], rows: p.rows });
  }
  const def = months[0];
  return { rows: def.rows, month: { year: def.year, month: def.month, monthLabel: def.monthLabel }, months, sheet: wb.SheetNames[0] };
}

async function importJadwalSubmit() {
  if (!IMP_ROWS || !IMP_ROWS.length) { toast('Gagal', 'err', 'Belum ada data terbaca.'); return; }
  const codeP = ($('imp-codeP') || {}).value || null;
  const codeS = ($('imp-codeS') || {}).value || null;
  const replace = $('imp-replace') ? $('imp-replace').checked : false;
  const codes = {};
  if (codeP) codes['P'] = codeP;
  if (codeS) codes['S'] = codeS;
  const btn = $('imp-go'); if (btn) { btn.disabled = true; btn.textContent = 'Mengimpor…'; }
  try {
    const r = await api('admin/schedule/import', { method: 'POST', body: { rows: IMP_ROWS, codes, replace } });
    const n = r.count || 0;
    toast('Import Berhasil', 'ok', r.message || `${n} slot jadwal diimpor.`);
    closeModal();
    await loadWeek(); renderShiftPage();
    if (r.unmatched && r.unmatched.length) {
      setTimeout(() => toast('Nama Tak Cocok', 'warn', `${r.unmatched.length} nama tidak ditemukan: ${r.unmatched.slice(0, 6).join(', ')}${r.unmatched.length > 6 ? '…' : ''}`), 700);
    }
  } catch (e) {
    toast('Gagal Import', 'err', e.message);
    if (btn) { btn.disabled = false; btn.textContent = 'Import'; }
  }
}
window.importJadwalSubmit = importJadwalSubmit;

/* ===================== TAB: KELUHAN KARYAWAN ===================== */
let KELUHAN_CACHE = [];
let KELUHAN_FILTER = 'ALL';
let KELUHAN_STATS = { total: 0, baru: 0, dibaca: 0, ditindak: 0, selesai: 0 };

const KELUHAN_CAT_LABEL = {
  GAJI: 'Gaji / Upah', JADWAL: 'Jadwal / Shift', LINGKUNGAN: 'Lingkungan Kerja',
  REKAN_KERJA: 'Rekan Kerja', ATASAN: 'Atasan', FASILITAS: 'Fasilitas', LAINNYA: 'Lainnya',
};
function keluhanCatLabel(c) { return KELUHAN_CAT_LABEL[c] || (c || 'Lainnya'); }
function keluhanCatIcon(c) {
  const map = {
    GAJI: '💰', JADWAL: '🗓️', LINGKUNGAN: '🏢', REKAN_KERJA: '👥',
    ATASAN: '👔', FASILITAS: '🛠️', LAINNYA: '💬',
  };
  return map[c] || '💬';
}
function keluhanStatusBadge(st) {
  if (st === 'SELESAI') return '<span class="badge b-green">Selesai</span>';
  if (st === 'DITINDAKLANJUTI') return '<span class="badge b-blue">Ditindaklanjuti</span>';
  if (st === 'DIBACA') return '<span class="badge b-grey">Dibaca</span>';
  return '<span class="badge b-orange">Baru</span>';
}
function keluhanWhen(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  if (isNaN(d)) return iso;
  return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) + ' • ' +
    d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
}

async function viewKeluhan() {
  $('top-actions').innerHTML = `<button class="btn btn-ghost" onclick="reloadKeluhan()">Muat ulang</button>`;
  const res = await api('admin/complaints');
  KELUHAN_CACHE = res.items || [];
  KELUHAN_STATS = res.stats || KELUHAN_STATS;
  renderKeluhan();
}
function renderKeluhan() {
  const list = KELUHAN_FILTER === 'ALL' ? KELUHAN_CACHE : KELUHAN_CACHE.filter((x) => x.status === KELUHAN_FILTER);
  const st = KELUHAN_STATS;
  const kpi = `
    <div class="kpis" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:12px;margin-bottom:16px">
      <div class="kpi"><span>Total</span><b>${st.total}</b></div>
      <div class="kpi"><span>Baru</span><b>${st.baru}</b></div>
      <div class="kpi"><span>Dibaca</span><b>${st.dibaca}</b></div>
      <div class="kpi"><span>Ditindaklanjuti</span><b>${st.ditindak}</b></div>
      <div class="kpi"><span>Selesai</span><b>${st.selesai}</b></div>
    </div>`;
  const seg = `
    <div class="seg">
      <button class="${KELUHAN_FILTER === 'ALL' ? 'on' : ''}" onclick="keluhanFilter('ALL')">Semua ${st.total}</button>
      <button class="${KELUHAN_FILTER === 'BARU' ? 'on' : ''}" onclick="keluhanFilter('BARU')">Baru ${st.baru}</button>
      <button class="${KELUHAN_FILTER === 'DIBACA' ? 'on' : ''}" onclick="keluhanFilter('DIBACA')">Dibaca ${st.dibaca}</button>
      <button class="${KELUHAN_FILTER === 'DITINDAKLANJUTI' ? 'on' : ''}" onclick="keluhanFilter('DITINDAKLANJUTI')">Ditindak ${st.ditindak}</button>
      <button class="${KELUHAN_FILTER === 'SELESAI' ? 'on' : ''}" onclick="keluhanFilter('SELESAI')">Selesai ${st.selesai}</button>
    </div>`;
  const empty = `<div class="empty">Belum ada keluhan pada filter ini.<br><span class="ttl">Karyawan dapat mengirim keluhan lewat halaman <b>tokokartini.com</b> → bagian “Kirim Keluhan”.</span></div>`;
  $('view').innerHTML = `
    <div class="card">
      <div class="toolbar" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
        <h3 style="margin:0">Keluhan &amp; Saran Karyawan (${list.length}/${KELUHAN_CACHE.length})</h3>
        ${seg}
      </div>
      ${kpi}
      ${list.length === 0 ? empty : `
      <div class="only-desk table-wrap">
        <table>
          <thead><tr><th>Tanggal</th><th>Kategori</th><th>Pengirim</th><th>Subjek / Isi</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
          ${list.map((x) => `
            <tr>
              <td style="white-space:nowrap">${esc(keluhanWhen(x.createdAt))}</td>
              <td style="white-space:nowrap">${keluhanCatIcon(x.category)} ${esc(keluhanCatLabel(x.category))}</td>
              <td style="overflow-wrap:anywhere">${esc(x.senderName || 'Anonim')}</td>
              <td style="max-width:420px">
                ${x.subject ? `<b>${esc(x.subject)}</b><div class="ttl">${esc((x.message || '').slice(0, 140))}${(x.message || '').length > 140 ? '…' : ''}</div>` : esc((x.message || '').slice(0, 160)) + ((x.message || '').length > 160 ? '…' : '')}
                ${x.adminNote ? `<div class="ttl">Catatan: ${esc(x.adminNote)}</div>` : ''}
              </td>
              <td>${keluhanStatusBadge(x.status)}</td>
              <td style="white-space:nowrap">
                <button class="btn btn-sm btn-primary" onclick="keluhanOpen('${x.id}')">Buka</button>
                <button class="btn btn-sm btn-danger" onclick="keluhanDel('${x.id}')">Hapus</button>
              </td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="only-mob mlist">${list.map(keluhanCard).join('')}</div>`}
      <div class="ttl" style="margin-top:14px">Nama hanya tampil jika pengirim memilih Pakai nama.</div>
    </div>`;
}
function keluhanCard(x) {
  return `<div class="mcard">
    <div style="display:flex;justify-content:space-between;gap:8px;align-items:center">
      <b>${keluhanCatIcon(x.category)} ${esc(keluhanCatLabel(x.category))}</b>
      ${keluhanStatusBadge(x.status)}
    </div>
    <div class="ttl" style="margin:6px 0">${esc(keluhanWhen(x.createdAt))} • ${esc(x.senderName || 'Anonim')}</div>
    ${x.subject ? `<div style="margin:6px 0"><b>${esc(x.subject)}</b></div>` : ''}
    <div style="margin:6px 0;white-space:pre-wrap">${esc(x.message)}</div>
    ${x.adminNote ? `<div class="ttl">Catatan: ${esc(x.adminNote)}</div>` : ''}
    <div class="actions" style="margin-top:10px">
      <button class="btn btn-sm btn-primary" onclick="keluhanOpen('${x.id}')">Buka &amp; Tindak</button>
      <button class="btn btn-sm btn-danger" onclick="keluhanDel('${x.id}')">Hapus</button>
    </div>
  </div>`;
}
function keluhanFilter(f) { KELUHAN_FILTER = f; renderKeluhan(); }
async function reloadKeluhan() {
  const v = $('view'); if (v) v.innerHTML = '<div class="loading">Memuat…</div>';
  try { await viewKeluhan(); } catch (e) { toast('Gagal', 'err', e.message); }
}
function keluhanOpen(id) {
  const x = KELUHAN_CACHE.find((c) => c.id === id);
  if (!x) return;
  openModal(`
    <h3>Keluhan ${keluhanCatIcon(x.category)} ${esc(keluhanCatLabel(x.category))}</h3>
    <div class="muted-box" style="margin-bottom:12px">
      <b>Dikirim:</b> ${esc(keluhanWhen(x.createdAt))}<br>
      <b>Pengirim:</b> ${esc(x.senderName || 'Anonim')}<br>
      <b>Sumber:</b> tokokartini.com
    </div>
    ${x.subject ? `<div style="margin-bottom:8px"><b>${esc(x.subject)}</b></div>` : ''}
    <div class="muted-box" style="white-space:pre-wrap;line-height:1.6">${esc(x.message)}</div>
    <div class="field" style="margin-top:14px">
      <label>Status</label>
      <select id="kel-status">
        <option value="BARU" ${x.status === 'BARU' ? 'selected' : ''}>Baru</option>
        <option value="DIBACA" ${x.status === 'DIBACA' ? 'selected' : ''}>Dibaca</option>
        <option value="DITINDAKLANJUTI" ${x.status === 'DITINDAKLANJUTI' ? 'selected' : ''}>Ditindaklanjuti</option>
        <option value="SELESAI" ${x.status === 'SELESAI' ? 'selected' : ''}>Selesai</option>
      </select>
    </div>
    <div class="field">
      <label>Catatan internal (opsional)</label>
      <textarea id="kel-note" rows="3" placeholder="mis. Sudah dibahas dengan kepala toko, jadwal diperbaiki.">${esc(x.adminNote || '')}</textarea>
    </div>
    <div class="actions">
      <button class="btn btn-ghost" onclick="closeModal()">Tutup</button>
      <button class="btn btn-primary" onclick="keluhanSave('${x.id}')">Simpan</button>
    </div>`);
}
async function keluhanSave(id) {
  const status = ($('kel-status') || {}).value;
  const note = ($('kel-note') || {}).value || null;
  try {
    await api('admin/complaints/' + id, { method: 'PATCH', body: { status, adminNote: note } });
    toast('Keluhan Diperbarui', 'ok', 'Status keluhan berhasil disimpan.');
    closeModal();
    await reloadKeluhan();
  } catch (e) { toast('Gagal', 'err', e.message); }
}
async function keluhanDel(id) {
  const ok = await confirmDialog({
    title: 'Hapus Keluhan',
    subtitle: 'Keluhan akan dihapus permanen.',
    icon: 'trash', tone: 'danger',
    html: '<p>Keluhan anonim ini akan <b>dihapus permanen</b> dan tidak dapat dikembalikan.</p>',
    confirmLabel: 'Hapus',
  });
  if (!ok) return;
  try {
    await api('admin/complaints/' + id, { method: 'DELETE' });
    toast('Keluhan Dihapus', 'ok');
    await reloadKeluhan();
  } catch (e) { toast('Gagal Menghapus', 'err', e.message); }
}
window.viewKeluhan = viewKeluhan; window.keluhanFilter = keluhanFilter;
window.keluhanOpen = keluhanOpen; window.keluhanSave = keluhanSave;
window.keluhanDel = keluhanDel; window.reloadKeluhan = reloadKeluhan;


/* ===================== DATE / NUM HELPERS (lokal views) ===================== */
function pad2(n) { return String(n).padStart(2, '0'); }
function toISO(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
function addDaysISO(dateStr, n) { const d = new Date(dateStr + 'T00:00:00'); d.setDate(d.getDate() + n); return toISO(d); }
function mondayOfISO(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  const day = d.getDay();
  d.setDate(d.getDate() + (day === 0 ? -6 : 1 - day));
  return toISO(d);
}
function dayShort(dateStr) { const d = new Date(dateStr + 'T00:00:00'); return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }); }
function diffMins(a, b) {
  const [ah, am] = a.split(':').map(Number), [bh, bm] = b.split(':').map(Number);
  if ([ah, am, bh, bm].some((n) => !Number.isFinite(n))) return 0;
  let m = (bh * 60 + bm) - (ah * 60 + am);
  if (m < 0) m += 1440;
  return m;
}

/* ===================== TAB: PERSETUJUAN IZIN ===================== */
let IZIN_FILTER = 'PENDING';
let IZIN_CACHE = [];

function izinCatLabel(c) { return c === 'SAKIT' ? 'Izin Sakit' : (c === 'IZIN' ? 'Izin' : (c || 'Izin')); }
function izinStatusBadge(st) {
  if (st === 'APPROVED') return '<span class="badge b-green">Disetujui</span>';
  if (st === 'REJECTED') return '<span class="badge b-red">Ditolak</span>';
  return '<span class="badge b-orange">Menunggu</span>';
}
function dateRange(a, b) {
  if (!a) return '-';
  if (!b || a === b) return dayLabel(a);
  return dayLabel(a) + ' — ' + dayLabel(b);
}

async function viewIzin() {
  $('top-actions').innerHTML = '';
  const res = await api('admin/leaves');
  IZIN_CACHE = res.items || [];
  const nPending = IZIN_CACHE.filter((x) => x.status === 'PENDING').length;
  const nAppr = IZIN_CACHE.filter((x) => x.status === 'APPROVED').length;
  const nRej = IZIN_CACHE.filter((x) => x.status === 'REJECTED').length;
  const shown = IZIN_FILTER === 'ALL' ? IZIN_CACHE : IZIN_CACHE.filter((x) => x.status === IZIN_FILTER);
  $('view').innerHTML = `
    <div class="card">
      <div class="toolbar" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
        <h3 style="margin:0">Pengajuan Izin (${shown.length}/${IZIN_CACHE.length})</h3>
        <div class="seg">
          <button class="${IZIN_FILTER === 'PENDING' ? 'on' : ''}" onclick="izinFilter('PENDING')">Menunggu ${nPending}</button>
          <button class="${IZIN_FILTER === 'APPROVED' ? 'on' : ''}" onclick="izinFilter('APPROVED')">Disetujui ${nAppr}</button>
          <button class="${IZIN_FILTER === 'REJECTED' ? 'on' : ''}" onclick="izinFilter('REJECTED')">Ditolak ${nRej}</button>
          <button class="${IZIN_FILTER === 'ALL' ? 'on' : ''}" onclick="izinFilter('ALL')">Semua ${IZIN_CACHE.length}</button>
        </div>
      </div>
      ${shown.length === 0 ? `<div class="empty">Tidak ada pengajuan izin pada filter ini.</div>` : `
      <div class="only-desk table-wrap">
        <table>
          <thead><tr><th>Karyawan</th><th>Jenis</th><th>Tanggal</th><th>Alasan</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
          ${shown.map((x) => `
            <tr>
              <td><div class="row-user">${avatarHtml(x)}<div><b>${esc(x.fullName)}</b><span>Kode: ${esc(x.employeeCode)}</span></div></div></td>
              <td>${esc(izinCatLabel(x.category))}${x.hasAttachment ? `<div><button class="btn btn-sm btn-ghost" onclick="izinViewAttachment('${x.id}')">Lihat Surat</button></div>` : ''}</td>
              <td>${esc(dateRange(x.startDate, x.endDate))}</td>
              <td style="max-width:260px">${esc(x.reason || '-')}${x.decisionNote ? `<div class="ttl">Catatan: ${esc(x.decisionNote)}</div>` : ''}</td>
              <td>${izinStatusBadge(x.status)}</td>
              <td style="white-space:nowrap">
                ${x.status === 'PENDING' ? `
                  <button class="btn btn-sm btn-primary" onclick="izinDecide('${x.id}','APPROVED')">Setujui</button>
                  <button class="btn btn-sm btn-danger" onclick="izinDecide('${x.id}','REJECTED')">Tolak</button>` : `<span class="ttl">Selesai</span>`}
              </td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="only-mob mlist">${shown.map(izinCard).join('')}</div>`}
    </div>`;
}
function izinCard(x) {
  return `<div class="mcard">
    <div class="row-user">${avatarHtml(x)}<div><b>${esc(x.fullName)}</b><span>${esc(izinCatLabel(x.category))}</span></div></div>
    <div style="margin:10px 0"><b>${esc(dateRange(x.startDate, x.endDate))}</b><div class="ttl">${esc(x.reason || '-')}</div></div>
    <div>${izinStatusBadge(x.status)}</div>
    ${x.hasAttachment ? `<div style="margin-top:8px"><button class="btn btn-sm btn-ghost" onclick="izinViewAttachment('${x.id}')">Lihat Surat</button></div>` : ''}
    ${x.status === 'PENDING' ? `<div class="actions" style="margin-top:10px">
      <button class="btn btn-sm btn-primary" onclick="izinDecide('${x.id}','APPROVED')">Setujui</button>
      <button class="btn btn-sm btn-danger" onclick="izinDecide('${x.id}','REJECTED')">Tolak</button>
    </div>` : ''}
  </div>`;
}
function izinFilter(f) { IZIN_FILTER = f; route(); }
async function izinDecide(id, status) {
  const item = IZIN_CACHE.find((x) => x.id === id) || {};
  const approve = status === 'APPROVED';
  const note = await promptDialog({
    title: approve ? 'Setujui Pengajuan Izin' : 'Tolak Pengajuan Izin',
    subtitle: item.fullName ? `${item.fullName}${item.leaveType ? ' • ' + item.leaveType : ''}` : undefined,
    icon: approve ? 'protect' : 'trash',
    tone: approve ? 'brand' : 'danger',
    html: approve
      ? `<p>Pengajuan izin ini akan <b>disetujui</b>. Karyawan menerima notifikasi persetujuan.</p>`
      : `<p>Pengajuan izin ini akan <b>ditolak</b>. Karyawan menerima notifikasi penolakan.</p>`,
    label: approve ? 'Catatan (opsional)' : 'Alasan penolakan (opsional)',
    placeholder: approve ? 'mis. Disetujui, harap tetap konfirmasi ke atasan.' : 'mis. Kuota izin belum mencukupi.',
    confirmLabel: approve ? 'Setujui' : 'Tolak',
  });
  if (note === null) return;
  try {
    await api('admin/leaves/' + id, { method: 'PUT', body: { status, note: note || null } });
    toast(approve ? 'Izin Disetujui' : 'Izin Ditolak', 'ok',
      item.fullName ? `Pengajuan izin dari “${item.fullName}” telah ${approve ? 'disetujui' : 'ditolak'}.` : undefined);
    route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.izinViewAttachment = izinViewAttachment;
async function izinViewAttachment(id) {
  try {
    const r = await api('admin/leaves/' + id + '/attachment');
    openModal(`
      <h3>Lampiran Surat</h3>
      <div style="text-align:center;margin:8px 0">
        <img src="data:${esc(r.attachmentType || 'image/jpeg')};base64,${r.attachmentBase64}" style="max-width:100%;max-height:60vh;border-radius:12px" alt="Lampiran">
      </div>
      <div class="actions"><button class="btn btn-ghost" onclick="closeModal()">Tutup</button></div>`);
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.viewIzin = viewIzin; window.izinFilter = izinFilter; window.izinDecide = izinDecide;

/* ===================== TAB: PERSETUJUAN LEMBUR ===================== */
let LEMBUR_CACHE = [];
let LEMBUR_FILTER = 'PENDING';
async function viewLembur() {
  $('top-actions').innerHTML = '';
  const res = await api('admin/overtimes');
  LEMBUR_CACHE = res.items || [];
  const nPending = LEMBUR_CACHE.filter((x) => x.status === 'PENDING').length;
  const nAppr = LEMBUR_CACHE.filter((x) => x.status === 'APPROVED').length;
  const nRej = LEMBUR_CACHE.filter((x) => x.status === 'REJECTED').length;
  const shown = LEMBUR_FILTER === 'ALL' ? LEMBUR_CACHE : LEMBUR_CACHE.filter((x) => x.status === LEMBUR_FILTER);
  const totalApprovedMin = LEMBUR_CACHE.filter((x) => x.status === 'APPROVED').reduce((a, x) => a + (x.durationMinutes || 0), 0);
  $('view').innerHTML = `
    <div class="grid g4" style="margin-bottom:18px">
      <div class="stat"><span>Menunggu</span><b style="color:var(--accent)">${nPending}</b></div>
      <div class="stat"><span>Disetujui</span><b style="color:var(--brand)">${nAppr}</b></div>
      <div class="stat"><span>Ditolak</span><b>${nRej}</b></div>
      <div class="stat o"><span>Total Jam Disetujui</span><b>${durLabel(totalApprovedMin)}</b></div>
    </div>
    <div class="card">
      <div class="toolbar" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
        <h3 style="margin:0">Pengajuan Lembur (${shown.length}/${LEMBUR_CACHE.length})</h3>
        <div class="seg">
          <button class="${LEMBUR_FILTER === 'PENDING' ? 'on' : ''}" onclick="lemburFilter('PENDING')">Menunggu ${nPending}</button>
          <button class="${LEMBUR_FILTER === 'APPROVED' ? 'on' : ''}" onclick="lemburFilter('APPROVED')">Disetujui ${nAppr}</button>
          <button class="${LEMBUR_FILTER === 'REJECTED' ? 'on' : ''}" onclick="lemburFilter('REJECTED')">Ditolak ${nRej}</button>
          <button class="${LEMBUR_FILTER === 'ALL' ? 'on' : ''}" onclick="lemburFilter('ALL')">Semua ${LEMBUR_CACHE.length}</button>
        </div>
      </div>
      ${shown.length === 0 ? `<div class="empty">Tidak ada pengajuan lembur pada filter ini.</div>` : `
      <div class="only-desk table-wrap">
        <table>
          <thead><tr><th>Karyawan</th><th>Tanggal</th><th>Jam Lembur</th><th>Durasi</th><th>Keperluan</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
          ${shown.map((x) => `
            <tr>
              <td><div class="row-user">${avatarHtml(x)}<div><b>${esc(x.fullName)}</b><span>Kode: ${esc(x.employeeCode)}</span></div></div></td>
              <td>${esc(dayLabel(x.date))}</td>
              <td>${esc((x.startTime || '').slice(0, 5))} → ${esc((x.endTime || '').slice(0, 5))}</td>
              <td><b>${durLabel(x.durationMinutes)}</b></td>
              <td style="max-width:240px">${esc(x.reason || '-')}${x.decisionNote ? `<div class="ttl">Catatan: ${esc(x.decisionNote)}</div>` : ''}</td>
              <td>${lemburStatusBadge(x.status)}</td>
              <td style="white-space:nowrap">
                ${x.status === 'PENDING' ? `
                  <button class="btn btn-sm btn-primary" onclick="lemburDecide('${x.id}','APPROVED')">Setujui</button>
                  <button class="btn btn-sm btn-danger" onclick="lemburDecide('${x.id}','REJECTED')">Tolak</button>` : `<span class="ttl">Selesai</span>`}
              </td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="only-mob mlist">${shown.map(lemburCard).join('')}</div>`}
    </div>`;
}
function lemburCard(x) {
  return `<div class="mcard">
    <div class="row-user">${avatarHtml(x)}<div><b>${esc(x.fullName)}</b><span>Kode: ${esc(x.employeeCode)}</span></div></div>
    <div class="mcard-grid">
      <div class="kv"><label>Tanggal</label><b>${esc(dayLabel(x.date))}</b></div>
      <div class="kv"><label>Durasi</label><b>${durLabel(x.durationMinutes)}</b></div>
      <div class="kv"><label>Jam</label><b>${esc((x.startTime || '').slice(0, 5))} → ${esc((x.endTime || '').slice(0, 5))}</b></div>
      <div class="kv"><label>Status</label><b>${lemburStatusBadge(x.status)}</b></div>
    </div>
    ${x.reason ? `<div class="ttl" style="margin-top:8px">${esc(x.reason)}</div>` : ''}
    ${x.status === 'PENDING' ? `<div class="actions" style="margin-top:10px">
      <button class="btn btn-sm btn-primary" onclick="lemburDecide('${x.id}','APPROVED')">Setujui</button>
      <button class="btn btn-sm btn-danger" onclick="lemburDecide('${x.id}','REJECTED')">Tolak</button>
    </div>` : ''}
  </div>`;
}
function lemburStatusBadge(status) {
  if (status === 'APPROVED') return '<span class="badge b-green">Disetujui</span>';
  if (status === 'REJECTED') return '<span class="badge b-red">Ditolak</span>';
  return '<span class="badge b-orange">Menunggu</span>';
}
function lemburFilter(f) { LEMBUR_FILTER = f; route(); }
async function lemburDecide(id, status) {
  const item = LEMBUR_CACHE.find((x) => x.id === id) || {};
  const approve = status === 'APPROVED';
  const note = await promptDialog({
    title: approve ? 'Setujui Pengajuan Lembur' : 'Tolak Pengajuan Lembur',
    subtitle: item.fullName ? `${item.fullName} • ${durLabel(item.durationMinutes)}` : undefined,
    icon: approve ? 'protect' : 'trash',
    tone: approve ? 'brand' : 'danger',
    html: approve
      ? `<p>Pengajuan lembur ini akan <b>disetujui</b> dan tercatat pada laporan.</p>`
      : `<p>Pengajuan lembur ini akan <b>ditolak</b>. Karyawan menerima notifikasi penolakan.</p>`,
    label: approve ? 'Catatan (opsional)' : 'Alasan penolakan (opsional)',
    placeholder: approve ? 'mis. Disetujui sesuai kebutuhan toko.' : 'mis. Lembur tidak diperlukan hari ini.',
    confirmLabel: approve ? 'Setujui' : 'Tolak',
  });
  if (note === null) return;
  try {
    await api('admin/overtimes/' + id, { method: 'PUT', body: { status, note: note || null } });
    toast(approve ? 'Lembur Disetujui' : 'Lembur Ditolak', 'ok',
      item.fullName ? `Pengajuan lembur dari “${item.fullName}” telah ${approve ? 'disetujui' : 'ditolak'}.` : undefined);
    route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.viewLembur = viewLembur; window.lemburFilter = lemburFilter; window.lemburDecide = lemburDecide;

/* ===================== TAB: UPDATE APLIKASI ===================== */
let REL_CACHE = [];
async function viewUpdate() {
  $('top-actions').innerHTML = `<button class="btn btn-orange" onclick="openRelModal()">+ Rilis Versi Baru</button>`;
  const res = await api('admin/releases');
  REL_CACHE = res.items || [];
  $('view').innerHTML = `
    <div class="card" style="margin-bottom:16px">
      <h3 style="margin-top:0">Cara Kerja</h3>
      <p class="ttl" style="margin:0">Saat Anda mempublikasikan versi baru, seluruh karyawan menerima notifikasi di aplikasi. Bila ditandai <b>Wajib</b>, popup tidak dapat ditutup sebelum diperbarui. APK yang diunduh karyawan otomatis dihapus setelah berhasil dipasang.</p>
    </div>
    <div class="card">
      <h3 style="margin-top:0">Riwayat Rilis (${REL_CACHE.length})</h3>
      ${REL_CACHE.length === 0 ? `<div class="empty">Belum ada rilis. Klik “Rilis Versi Baru”.</div>` : `
      <div class="only-desk table-wrap">
        <table>
          <thead><tr><th>Versi</th><th>Kode</th><th>Wajib</th><th>Status</th><th>URL APK</th><th>Aksi</th></tr></thead>
          <tbody>
          ${REL_CACHE.map((r) => `
            <tr>
              <td><b>${esc(r.versionName)}</b>${r.notes ? `<div class="ttl">${esc(r.notes)}</div>` : ''}</td>
              <td>${esc(String(r.versionCode))}</td>
              <td>${r.mandatory ? '<span class="badge b-orange">Wajib</span>' : '<span class="badge b-grey">Opsional</span>'}</td>
              <td>${r.active ? '<span class="badge b-green">Aktif</span>' : '<span class="badge b-grey">Arsip</span>'}</td>
              <td style="max-width:260px"><a href="${esc(r.apkUrl)}" target="_blank" rel="noopener">${esc(r.apkUrl)}</a></td>
              <td><button class="btn btn-sm btn-danger" onclick="delRel('${r.id}')">Hapus</button></td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="only-mob mlist">${REL_CACHE.map((r) => `
        <div class="mcard">
          <div style="display:flex;justify-content:space-between"><b>Versi ${esc(r.versionName)}</b>${r.active ? '<span class="badge b-green">Aktif</span>' : '<span class="badge b-grey">Arsip</span>'}</div>
          <div class="ttl">Kode ${esc(String(r.versionCode))} • ${r.mandatory ? 'Wajib' : 'Opsional'}</div>
          ${r.notes ? `<div class="ttl">${esc(r.notes)}</div>` : ''}
          <div style="margin-top:8px"><a href="${esc(r.apkUrl)}" target="_blank" rel="noopener">Buka APK</a></div>
          <div class="actions" style="margin-top:10px"><button class="btn btn-sm btn-danger" onclick="delRel('${r.id}')">Hapus</button></div>
        </div>`).join('')}</div>`}
    </div>`;
}
function openRelModal() {
  const nextCode = REL_CACHE.reduce((m, r) => Math.max(m, r.versionCode || 0), 23) + 1;
  openModal(`
    <h3>Rilis Versi Baru</h3>
    <form onsubmit="saveRel(event)">
      <div class="grid g2">
        <div class="field"><label>Nama Versi</label><input id="rel-name" placeholder="mis. 0.9.13" required></div>
        <div class="field"><label>Kode Versi (number)</label><input id="rel-code" type="number" value="${nextCode}" required></div>
      </div>
      <div class="field"><label>URL Unduhan APK</label><input id="rel-url" placeholder="https://.../app-release.apk" required>
        <div class="ttl">Tautan publik langsung ke berkas APK (mis. hasil unggahan atau rilis GitHub).</div></div>
      <div class="field"><label>Catatan Rilis (opsional)</label><input id="rel-notes" placeholder="mis. Perbaikan absen & fitur izin"></div>
      <div class="field"><label><input type="checkbox" id="rel-mandatory"> Wajib diperbarui (popup tidak bisa ditutup)</label></div>
      <div class="actions">
        <button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button>
        <button type="submit" class="btn btn-primary" style="width:auto">Publikasikan</button>
      </div>
    </form>`);
}
async function saveRel(ev) {
  ev.preventDefault();
  const body = {
    versionName: $('rel-name').value.trim(),
    versionCode: Number($('rel-code').value),
    apkUrl: $('rel-url').value.trim(),
    notes: $('rel-notes').value.trim() || null,
    mandatory: $('rel-mandatory').checked,
  };
  try {
    await api('admin/releases', { method: 'POST', body });
    toast('Rilis Dipublikasikan', 'ok', 'Notifikasi update telah dikirim ke seluruh karyawan.');
    closeModal(); route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
async function delRel(id) {
  const ok = await confirmDialog({
    title: 'Hapus Rilis Versi',
    icon: 'trash',
    tone: 'danger',
    html:
      `<p>Rilis versi ini akan dihapus dari daftar update.</p>` +
      `<div class="dialog-note">${DIALOG_ICONS.trash}<span>Karyawan <b>tidak akan menerima</b> pemberitahuan versi ini lagi. Versi APK yang sudah terpasang tidak terpengaruh.</span></div>`,
    confirmLabel: 'Hapus Rilis',
  });
  if (!ok) return;
  try { await api('admin/releases/' + id, { method: 'DELETE' }); toast('Rilis Dihapus', 'ok'); route(); }
  catch (err) { toast('Gagal Menghapus', 'err', err.message); }
}
window.viewUpdate = viewUpdate; window.openRelModal = openRelModal; window.saveRel = saveRel; window.delRel = delRel;

/* ===================== TAB DEV: DASHBOARD SISTEM (B6) ===================== */
function relTime(iso) {
  if (!iso) return '-';
  const t = new Date(iso).getTime();
  if (isNaN(t)) return '-';
  const s = Math.max(0, Math.floor((Date.now() - t) / 1000));
  if (s < 60) return s + ' detik lalu';
  const m = Math.floor(s / 60); if (m < 60) return m + ' menit lalu';
  const h = Math.floor(m / 60); if (h < 24) return h + ' jam lalu';
  const d = Math.floor(h / 24); if (d < 30) return d + ' hari lalu';
  return new Date(iso).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}
async function viewSystem() {
  $('top-actions').innerHTML = `<button class="btn btn-orange" onclick="route()">Segarkan</button>`;
  const s = await api('admin/system-status');
  const big = (label, value, sub, icon) => `
    <div class="kpi"><span class="kpi-ic">${icon || ''}</span><b>${esc(String(value))}</b><span class="kpi-lb">${esc(label)}</span>${sub ? `<span class="ttl">${esc(sub)}</span>` : ''}</div>`;
  $('view').innerHTML = `
    <div class="card" style="display:flex;align-items:center;gap:14px;justify-content:space-between;flex-wrap:wrap">
      <div style="display:flex;align-items:center;gap:13px">
        <span class="status-dot ${s.ok ? 'on' : 'off'}"></span>
        <div><h3 style="margin:0">Status Layanan ${s.ok ? 'Normal' : 'Gangguan'}</h3>
        <div class="ttl">API ${esc(s.api?.service || '-')} v${esc(s.api?.version || '-')} • Basis data respons ${s.dbLatencyMs} ms</div></div>
      </div>
      <div class="ttl">Waktu server: ${esc(new Date(s.serverTime).toLocaleString('id-ID'))}</div>
    </div>
    <div class="kpi-grid">
      ${big('Total Karyawan', s.employees.total, s.employees.active + ' aktif', I.users)}
      ${big('Absensi Hari Ini', s.todayAttendance, 'check-in tercatat', I.check)}
      ${big('Perangkat Terdaftar', s.devices.total, s.devices.recent + ' aktif 7 hari', I.list)}
      ${big('Menunggu Izin', s.pendingLeaves, 'perlu ditinjau', I.info || '')}
      ${big('Menunggu Lembur', s.pendingOvertimes, 'perlu ditinjau', I.trend)}
      ${big('Total Log Aktivitas', s.audit.total, s.audit.lastAt ? ('terakhir ' + relTime(s.audit.lastAt)) : 'belum ada', I.chart)}
    </div>
    <div class="card">
      <h3 style="margin-top:0">Informasi Sistem</h3>
      <div class="grid g2">
        <div class="kv"><label>Versi API</label><b>${esc(s.api?.service || '-')} ${esc(s.api?.version || '')}</b></div>
        <div class="kv"><label>Latensi Basis Data</label><b>${s.dbLatencyMs} ms ${s.uptimeAcceptable ? '✅' : '⚠️'}</b></div>
        <div class="kv"><label>Rilis Terbaru</label><b>${s.latestRelease ? esc(s.latestRelease.versionName) + ' (kode ' + s.latestRelease.versionCode + ')' : 'Belum ada'}</b></div>
        <div class="kv"><label>Status Rilis</label><b>${s.latestRelease ? (s.latestRelease.active ? 'Aktif' : 'Arsip') : '-'}</b></div>
        <div class="kv"><label>Perangkat Dicabut</label><b>${s.devices.revoked}</b></div>
        <div class="kv"><label>Aksi Terakhir</label><b>${s.audit.lastAction ? esc(s.audit.lastAction) + (s.audit.lastActor ? ' oleh ' + esc(s.audit.lastActor) : '') : '-'}</b></div>
      </div>
    </div>`;
}
window.viewSystem = viewSystem;

/* ===================== TAB DEV: LOG AKTIVITAS (B7 + B9) ===================== */
let AU_FILTER = { q: '', actor: '', action: '', from: '', to: '' };
const AU_ACTIONS = ['', 'LOGIN', 'IMPERSONATE_START', 'IMPERSONATE_END', 'DATA_REPAIR_RECOMPUTE', 'DATA_REPAIR_BACKFILL', 'DEVICE_REVOKE', 'DEVICE_RESTORE', 'FLAGS_UPDATE', 'BROADCAST_SEND', 'BROADCAST_DELETE', 'AUDIT_CLEAR', 'RELEASE_CREATE', 'RELEASE_DELETE', 'USER_CREATE', 'USER_UPDATE', 'USER_DELETE', 'SHIFT', 'SCHEDULE'];
const AU_LABEL = {
  BROADCAST_SEND: 'Kirim Pengumuman', BROADCAST_DELETE: 'Hapus Pengumuman',
  FLAGS_UPDATE: 'Ubah Feature Flags', DEVICE_REVOKE: 'Cabut Perangkat',
  DEVICE_RESTORE: 'Pulihkan Perangkat', AUDIT_CLEAR: 'Bersihkan Log',
  RELEASE_CREATE: 'Publikasi Rilis', RELEASE_DELETE: 'Hapus Rilis',
  IMPERSONATE_START: 'Mulai Sesi Dukungan', IMPERSONATE_END: 'Akhiri Sesi Dukungan',
  DATA_REPAIR_RECOMPUTE: 'Hitung Ulang Keterlambatan', DATA_REPAIR_BACKFILL: 'Backfill Jadwal',
};
function auQuery() {
  const p = [];
  p.push('limit=200');
  if (AU_FILTER.q) p.push('q=' + encodeURIComponent(AU_FILTER.q));
  if (AU_FILTER.actor) p.push('actor=' + encodeURIComponent(AU_FILTER.actor));
  if (AU_FILTER.action) p.push('action=' + encodeURIComponent(AU_FILTER.action));
  if (AU_FILTER.from) p.push('from=' + encodeURIComponent(AU_FILTER.from));
  if (AU_FILTER.to) p.push('to=' + encodeURIComponent(AU_FILTER.to));
  return p.join('&');
}
async function viewAudit() {
  $('top-actions').innerHTML =
    `<button class="btn btn-ghost" onclick="exportAudit()">Ekspor CSV</button>
     <button class="btn btn-ghost" onclick="clearAudit()">Bersihkan Log</button>
     <button class="btn btn-orange" onclick="route()">Segarkan</button>`;
  const res = await api('admin/audit?' + auQuery());
  const items = res.items || [];
  $('view').innerHTML = `
    <div class="card">
      <div class="toolbar" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <h3 style="margin:0">Riwayat Aktivitas (${items.length})</h3>
      </div>
      <div class="au-filters">
        <div class="au-q"><span class="s-ic">${I.search}</span><input id="au-q" placeholder="Cari aksi / nama / detail…" value="${esc(AU_FILTER.q)}" onkeydown="if(event.key==='Enter')auditApply()"></div>
        <input id="au-actor" class="au-in" placeholder="Aktor…" value="${esc(AU_FILTER.actor)}">
        <select id="au-action" class="au-in">${AU_ACTIONS.map((a) => `<option value="${a}" ${AU_FILTER.action === a ? 'selected' : ''}>${a ? (AU_LABEL[a] || a) : 'Semua Aksi'}</option>`).join('')}</select>
        <input id="au-from" class="au-in" type="date" value="${esc(AU_FILTER.from)}">
        <input id="au-to" class="au-in" type="date" value="${esc(AU_FILTER.to)}">
        <button class="btn btn-primary" style="width:auto" onclick="auditApply()">Terapkan</button>
        <button class="btn btn-ghost" style="width:auto" onclick="auditReset()">Reset</button>
      </div>
      ${items.length === 0 ? `<div class="empty">Tidak ada aktivitas yang cocok.</div>` : `
      <div class="only-desk table-wrap">
        <table><thead><tr><th>Waktu</th><th>Aktor</th><th>Aksi</th><th>Target</th><th>Detail</th><th>IP</th></tr></thead>
        <tbody>${items.map((x) => `<tr>
          <td style="white-space:nowrap"><b>${esc(relTime(x.createdAt))}</b><div class="ttl">${esc(x.createdAt ? new Date(x.createdAt).toLocaleString('id-ID') : '')}</div></td>
          <td><b>${esc(x.actorName || '-')}</b><div class="ttl">${esc(x.actorRole || '')}</div></td>
          <td><span class="badge b-green">${esc(AU_LABEL[x.action] || AU_LABEL[x.action.replace(/_/g, '_')] || x.action)}</span></td>
          <td>${esc(x.target || '-')}</td>
          <td style="max-width:280px">${esc(x.detail || '-')}</td>
          <td class="ttl">${esc(x.ip || '-')}</td>
        </tr>`).join('')}</tbody></table>
      </div>
      <div class="only-mob mlist">${items.map((x) => `
        <div class="mcard">
          <div style="display:flex;justify-content:space-between;gap:8px"><b>${esc(AU_LABEL[x.action] || x.action)}</b><span class="ttl">${esc(relTime(x.createdAt))}</span></div>
          <div class="ttl" style="margin-top:4px">${esc(x.actorName || '-')} ${x.target ? '• ' + esc(x.target) : ''}</div>
          ${x.detail ? `<div class="ttl">${esc(x.detail)}</div>` : ''}
        </div>`).join('')}</div>`}
    </div>`;
}
function auditApply() {
  AU_FILTER.q = ($('au-q').value || '').trim();
  AU_FILTER.actor = ($('au-actor').value || '').trim();
  AU_FILTER.action = $('au-action').value || '';
  AU_FILTER.from = $('au-from').value || '';
  AU_FILTER.to = $('au-to').value || '';
  route();
}
function auditReset() { AU_FILTER = { q: '', actor: '', action: '', from: '', to: '' }; route(); }
window.auditApply = auditApply; window.auditReset = auditReset;
async function exportAudit() {
  if (isDemo()) { toast('Tidak Tersedia', 'info', 'Ekspor tidak tersedia pada mode pratinjau.'); return; }
  try {
    const res = await fetch(API + 'admin/audit/export?' + auQuery(), { headers: S.token ? { Authorization: 'Bearer ' + S.token } : {} });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const blob = await res.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'log-aktivitas-' + todayISO() + '.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Log Diekspor', 'ok', 'Berkas CSV diunduh.');
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.exportAudit = exportAudit;
async function clearAudit() {
  const ok = await confirmDialog({
    title: 'Bersihkan Log Aktivitas', icon: 'trash', tone: 'danger',
    html: `<p>Seluruh riwayat aktivitas akan <b>dihapus permanen</b>.</p><div class="dialog-note">${DIALOG_ICONS.trash}<span>Tindakan ini tidak memengaruhi data absensi/karyawan, hanya log audit.</span></div>`,
    confirmLabel: 'Bersihkan',
  });
  if (!ok) return;
  try { await api('admin/audit', { method: 'DELETE' }); toast('Log Dibersihkan', 'ok', 'Riwayat aktivitas telah dihapus.'); route(); }
  catch (err) { toast('Gagal', 'err', err.message); }
}
window.viewAudit = viewAudit; window.clearAudit = clearAudit;

/* ===================== TAB DEV: BROADCAST PENGUMUMAN (B8) ===================== */
async function viewBroadcast() {
  $('top-actions').innerHTML = `<button class="btn btn-orange" onclick="openBroadcastModal()">+ Kirim Pengumuman</button>`;
  const res = await api('admin/broadcasts');
  const items = res.items || [];
  $('view').innerHTML = `
    <div class="card" style="margin-bottom:16px">
      <h3 style="margin-top:0">Cara Kerja</h3>
      <p class="ttl" style="margin:0">Pengumuman dikirim ke <b>seluruh karyawan aktif</b> dan tampil di menu notifikasi aplikasi. Pengumuman tidak muncul lagi setelah karyawan menutupnya.</p>
    </div>
    <div class="card">
      <h3 style="margin-top:0">Riwayat Pengumuman (${items.length})</h3>
      ${items.length === 0 ? `<div class="empty">Belum ada pengumuman.</div>` : `
      <div class="only-desk table-wrap"><table>
        <thead><tr><th>Judul</th><th>Jenis</th><th>Dibaca</th><th>Waktu</th><th>Aksi</th></tr></thead>
        <tbody>${items.map((x) => `<tr>
          <td><b>${esc(x.title)}</b>${x.body ? `<div class="ttl">${esc(x.body)}</div>` : ''}</td>
          <td><span class="badge ${x.kind === 'URGENT' ? 'b-orange' : 'b-green'}">${esc(x.kind)}</span></td>
          <td>${x.readCount}/${x.recipients}</td>
          <td class="ttl">${esc(relTime(x.createdAt))}</td>
          <td><button class="btn btn-sm btn-danger" onclick="delBroadcast('${x.id}')">Hapus</button></td>
        </tr>`).join('')}</tbody></table></div>
      <div class="only-mob mlist">${items.map((x) => `
        <div class="mcard"><div style="display:flex;justify-content:space-between"><b>${esc(x.title)}</b><span class="badge ${x.kind === 'URGENT' ? 'b-orange' : 'b-green'}">${esc(x.kind)}</span></div>
        ${x.body ? `<div class="ttl">${esc(x.body)}</div>` : ''}
        <div class="ttl">Dibaca ${x.readCount}/${x.recipients} • ${esc(relTime(x.createdAt))}</div>
        <div class="actions" style="margin-top:10px"><button class="btn btn-sm btn-danger" onclick="delBroadcast('${x.id}')">Hapus</button></div></div>`).join('')}</div>`}
    </div>`;
}
function openBroadcastModal() {
  openModal(`
    <h3>Kirim Pengumuman</h3>
    <form onsubmit="saveBroadcast(event)">
      <div class="field"><label>Judul</label><input id="bc-title" placeholder="mis. Libur nasional besok" required></div>
      <div class="field"><label>Pesan (opsional)</label><textarea id="bc-body" rows="3" placeholder="Tulis isi pengumuman…" style="width:100%;border:1px solid var(--line);border-radius:11px;padding:10px 12px;font:inherit"></textarea></div>
      <div class="field"><label>Jenis</label><select id="bc-kind"><option value="INFO">Info biasa</option><option value="ANNOUNCEMENT">Pengumuman</option><option value="URGENT">Penting / Urgent</option></select></div>
      <div class="actions"><button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button><button type="submit" class="btn btn-primary" style="width:auto">Kirim</button></div>
    </form>`);
}
async function saveBroadcast(ev) {
  ev.preventDefault();
  const body = { title: $('bc-title').value.trim(), body: $('bc-body').value.trim(), kind: $('bc-kind').value };
  if (!body.title) return toast('Judul Wajib', 'err', 'Judul pengumuman tidak boleh kosong.');
  try {
    const r = await api('admin/broadcast', { method: 'POST', body });
    toast('Pengumuman Terkirim', 'ok', `Dikirim ke ${r.recipients || 0} karyawan aktif.`);
    closeModal(); route();
  } catch (err) { toast('Gagal Mengirim', 'err', err.message); }
}
async function delBroadcast(id) {
  const ok = await confirmDialog({ title: 'Hapus Pengumuman', icon: 'trash', tone: 'danger',
    html: `<p>Pengumuman ini akan dihapus dari aplikasi karyawan.</p>`, confirmLabel: 'Hapus' });
  if (!ok) return;
  try { await api('admin/broadcast/' + id, { method: 'DELETE' }); toast('Pengumuman Dihapus', 'ok'); route(); }
  catch (err) { toast('Gagal', 'err', err.message); }
}
window.viewBroadcast = viewBroadcast; window.openBroadcastModal = openBroadcastModal; window.saveBroadcast = saveBroadcast; window.delBroadcast = delBroadcast;

/* ===================== TAB DEV: MANAJEMEN PERANGKAT (B9) ===================== */
async function viewDevices() {
  $('top-actions').innerHTML = `<button class="btn btn-orange" onclick="route()">Segarkan</button>`;
  const res = await api('admin/devices');
  const items = res.items || [];
  $('view').innerHTML = `
    <div class="card">
      <div class="toolbar" style="justify-content:space-between;align-items:center">
        <h3 style="margin:0">Perangkat Terdaftar (${items.length})</h3>
        <div style="position:relative"><input id="dv-q" placeholder="Cari nama / kode…" style="padding-left:36px" oninput="devFilter()">
        <span style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--mut)">${I.search}</span></div>
      </div>
      ${items.length === 0 ? `<div class="empty">Belum ada perangkat terdaftar.</div>` : `
      <div class="only-desk table-wrap"><table>
        <thead><tr><th>Karyawan</th><th>Device Key</th><th>Versi</th><th>Login Terakhir</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody id="dv-tbody">${items.map(devRow).join('')}</tbody></table></div>
      <div class="only-mob mlist" id="dv-mlist">${items.map(devCard).join('')}</div>`}
    </div>`;
}
function devRow(d) {
  return `<tr>
    <td><div class="row-user">${avatarHtml({ fullName: d.fullName, avatarColor: d.avatarColor, photoBase64: d.photoBase64 })}<div><b>${esc(d.fullName)}</b><span>Kode: ${esc(d.employeeCode)}</span></div></div></td>
    <td class="ttl" style="max-width:180px;overflow:hidden;text-overflow:ellipsis">${esc(d.deviceKey)}</td>
    <td>${d.appVersionCode ? 'kode ' + d.appVersionCode : '-'}</td>
    <td class="ttl">${esc(relTime(d.lastLoginAt))}</td>
    <td>${d.revokedAt ? '<span class="badge b-orange">Dicabut</span>' : '<span class="badge b-green">Aktif</span>'}</td>
    <td style="white-space:nowrap">${d.revokedAt ? `<button class="btn btn-sm btn-ghost" onclick="restoreDevice('${d.id}','${esc(d.fullName)}')">Pulihkan</button>` : `<button class="btn btn-sm btn-danger" onclick="revokeDevice('${d.id}','${esc(d.fullName)}')">Cabut</button>`}</td>
  </tr>`;
}
function devCard(d) {
  return `<div class="mcard">
    <div style="display:flex;align-items:center;gap:10px">${avatarHtml({ fullName: d.fullName, avatarColor: d.avatarColor, photoBase64: d.photoBase64 })}<div><b>${esc(d.fullName)}</b><div class="ttl">${esc(d.employeeCode)}</div></div>
      <span class="badge ${d.revokedAt ? 'b-orange' : 'b-green'}" style="margin-left:auto">${d.revokedAt ? 'Dicabut' : 'Aktif'}</span></div>
    <div class="ttl" style="margin-top:8px">Login ${esc(relTime(d.lastLoginAt))} ${d.appVersionCode ? '• versi kode ' + d.appVersionCode : ''}</div>
    <div class="actions" style="margin-top:10px">${d.revokedAt ? `<button class="btn btn-sm btn-ghost" onclick="restoreDevice('${d.id}','${esc(d.fullName)}')">Pulihkan</button>` : `<button class="btn btn-sm btn-danger" onclick="revokeDevice('${d.id}','${esc(d.fullName)}')">Cabut Akses</button>`}</div></div>`;
}
function devFilter() {
  const q = ($('dv-q').value || '').toLowerCase();
  document.querySelectorAll('#dv-tbody tr, #dv-mlist .mcard').forEach((el) => {
    el.style.display = el.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}
async function revokeDevice(id, name) {
  const ok = await confirmDialog({ title: 'Cabut Akses Perangkat', subtitle: name || undefined, icon: 'power', tone: 'danger',
    html: `<p>Perangkat ini akan <b>tidak bisa login</b> ke aplikasi sampai dipulihkan.</p><div class="dialog-note">${DIALOG_ICONS.protect}<span>Gunakan bila perangkat hilang/dicuri atau saat pergantian HP karyawan.</span></div>`,
    confirmLabel: 'Cabut Akses' });
  if (!ok) return;
  try { await api('admin/devices/' + id, { method: 'DELETE' }); toast('Perangkat Dicabut', 'ok', name ? `Akses "${name}" dicabut.` : undefined); route(); }
  catch (err) { toast('Gagal', 'err', err.message); }
}
async function restoreDevice(id, name) {
  try { await api('admin/devices/' + id + '/restore', { method: 'PUT', body: {} }); toast('Perangkat Dipulihkan', 'ok', name ? `Akses "${name}" kembali aktif.` : undefined); route(); }
  catch (err) { toast('Gagal', 'err', err.message); }
}
window.viewDevices = viewDevices; window.devFilter = devFilter; window.revokeDevice = revokeDevice; window.restoreDevice = restoreDevice;

/* ===================== TAB DEV: FEATURE FLAGS / REMOTE CONFIG (C11) ===================== */
async function viewFlags() {
  $('top-actions').innerHTML = `<button class="btn btn-primary" onclick="saveFlags()">Simpan Perubahan</button>`;
  const res = await api('admin/flags');
  const items = res.items || [];
  $('view').innerHTML = `
    <div class="card" style="margin-bottom:16px">
      <h3 style="margin-top:0">Feature Flags (Remote Config)</h3>
      <p class="ttl" style="margin:0">Nyalakan/matikan fitur aplikasi karyawan <b>tanpa merilis APK baru</b>. Perubahan berlaku saat karyawan membuka aplikasi (maksimal 1×24 jam).</p>
    </div>
    <div class="card">
      ${items.length === 0 ? `<div class="empty">Belum ada flag.</div>` : `<div class="flag-list">${items.map((f) => `
        <div class="flag-row">
          <div class="flag-info"><b>${esc(f.label || f.key)}</b><span>${esc(f.description || '')}</span><div class="ttl">Kunci: <code>${esc(f.key)}</code>${f.updatedAt ? ' • diubah ' + esc(relTime(f.updatedAt)) + (f.updatedBy ? ' oleh ' + esc(f.updatedBy) : '') : ''}</div></div>
          <label class="switch"><input type="checkbox" data-flag="${esc(f.key)}" ${f.enabled ? 'checked' : ''}><span class="slider"></span></label>
        </div>`).join('')}</div>`}
    </div>`;
}
async function saveFlags() {
  const flags = {};
  document.querySelectorAll('input[data-flag]').forEach((el) => { flags[el.getAttribute('data-flag')] = el.checked; });
  try { await api('admin/flags', { method: 'PUT', body: { flags } }); toast('Pengaturan Disimpan', 'ok', 'Feature flags berhasil diperbarui.'); route(); }
  catch (err) { toast('Gagal', 'err', err.message); }
}
window.viewFlags = viewFlags; window.saveFlags = saveFlags;

/* ===================== KOMPONEN DASHBOARD (tren kehadiran) ===================== */
// Ringkasan operasional harian untuk tim HR: KPI kehadiran, pengajuan yang
// menunggu persetujuan, jam lembur, serta tren kehadiran 30 hari.
function hrTrendChart(trend) {
  if (!trend || !trend.length) return '<div class="empty">Belum ada data tren.</div>';
  const max = Math.max(1, ...trend.map((d) => d.present));
  const bars = trend.map((d) => {
    const hPresent = Math.round((d.present / max) * 100);
    const hLate = Math.round((d.late / max) * 100);
    const dt = new Date(d.date + 'T00:00:00');
    const lbl = isNaN(dt) ? d.date : dt.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
    return `<div class="hr-bar" title="${esc(lbl)} — Hadir: ${d.present}, Terlambat: ${d.late}">
      <div class="hr-bar-track">
        <div class="hr-bar-fill" style="height:${hPresent}%"></div>
        <div class="hr-bar-late" style="height:${hLate}%"></div>
      </div>
      <span class="hr-bar-lb">${esc(String(dt.getDate ? dt.getDate() : ''))}</span>
    </div>`;
  }).join('');
  return `<div class="hr-chart">
    <div class="hr-chart-legend">
      <span><i class="dot" style="background:var(--brand)"></i> Hadir</span>
      <span><i class="dot" style="background:var(--accent)"></i> Terlambat</span>
    </div>
    <div class="hr-bars">${bars}</div>
  </div>`;
}


/* ===================== TAB: PENGGUNA & AKSES (B6 — RBAC) ===================== */
// Kelola akun admin/operator (SUPERADMIN / HR / MANAGER / DEV) beserta perannya.
const ROLE_LABEL = { SUPERADMIN: 'Superadmin', HR: 'HR', MANAGER: 'Manajer', DEV: 'Developer' };
const ROLE_TONE = { SUPERADMIN: 'b-green', HR: 'b-blue', MANAGER: 'b-orange', DEV: 'b-purple' };
const ROLE_DESC = {
  SUPERADMIN: 'Akses penuh operasional toko (absensi, karyawan, izin, lembur, laporan, pengaturan).',
  HR: 'Fokus kepegawaian: dashboard, karyawan, izin/lembur, laporan. Tidak bisa mengubah pengaturan sistem.',
  MANAGER: 'Pengawasan: dashboard, izin/lembur, laporan, perangkat. Tidak mengubah lokasi/pengguna.',
  DEV: 'Akses developer: rilis aplikasi, audit, perangkat, pengumuman, fitur (Remote Config).',
};
let USER_CACHE = [];
async function viewPengguna() {
  $('top-actions').innerHTML = `<button class="btn btn-primary btn-sm" onclick="openUserModal()">Tambah Pengguna</button>`;
  const res = await api('admin/users');
  USER_CACHE = res.items || [];
  const canDev = isDev();
  const pending = USER_CACHE.filter((u) => u.pending);
  $('view').innerHTML = `
    ${pending.length ? `
    <div class="card" style="margin-bottom:16px;border:1px solid #f2d9bd;background:linear-gradient(180deg,#fdf7ef,#fff)">
      <div class="hr-panel-head" style="margin-bottom:4px"><h3 style="margin:0">🔔 Menunggu Persetujuan (${pending.length})</h3></div>
      <p class="ttl" style="margin:0 0 12px">Akun berikut mendaftar mandiri dari halaman Jurnal. Setujui untuk mengaktifkan, atau tolak untuk menghapus.</p>
      ${pending.map((u) => `
        <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;padding:10px 0;border-top:1px solid var(--line)">
          <div><b>${esc(u.name)}</b> <span class="ttl">· ${esc(u.email)}</span></div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-sm btn-green" onclick="approveUser('${u.id}','${esc(u.name)}')">Setujui</button>
            <button class="btn btn-sm btn-danger" onclick="rejectUser('${u.id}','${esc(u.name)}')">Tolak</button>
          </div>
        </div>`).join('')}
    </div>` : ''}
    <div class="card" style="margin-bottom:16px">
      <h3 style="margin-top:0">Peran & Hak Akses</h3>
      <p class="ttl" style="margin:0 0 12px">Setiap akun memiliki peran yang menentukan tab & aksi yang tersedia. Aturan pengaman: tidak dapat menonaktifkan/menghapus akun sendiri, dan harus tersisa minimal satu <b>Superadmin</b> aktif.</p>
      <div class="grid g4">
        ${Object.keys(ROLE_LABEL).map((r) => `
          <div class="role-card">
            <span class="badge ${ROLE_TONE[r]}">${ROLE_LABEL[r]}</span>
            <p class="ttl" style="margin:8px 0 0">${ROLE_DESC[r]}</p>
          </div>`).join('')}
      </div>
    </div>
    <div class="card">
      <div class="hr-panel-head"><h3 style="margin:0">Daftar Pengguna (${USER_CACHE.length})</h3></div>
      ${USER_CACHE.length === 0 ? '<div class="empty">Belum ada pengguna.</div>' : `
      <div class="only-desk table-wrap">
        <table>
          <thead><tr><th>Nama</th><th>Email</th><th>Peran</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
          ${USER_CACHE.map((u) => `
            <tr>
              <td><b>${esc(u.name)}</b>${u.self ? ' <span class="badge b-blue">Anda</span>' : ''}</td>
              <td>${esc(u.email)}</td>
              <td><span class="badge ${ROLE_TONE[u.role] || 'b-blue'}">${esc(ROLE_LABEL[u.role] || u.role)}</span></td>
              <td>${u.pending ? '<span class="badge b-orange">Menunggu</span>' : (u.active ? '<span class="badge b-green">Aktif</span>' : '<span class="badge b-red">Nonaktif</span>')}</td>
              <td style="white-space:nowrap">
                ${u.pending
                  ? `<button class="btn btn-sm btn-green" onclick="approveUser('${u.id}','${esc(u.name)}')">Setujui</button>
                     <button class="btn btn-sm btn-danger" onclick="rejectUser('${u.id}','${esc(u.name)}')">Tolak</button>
                     <button class="btn btn-sm btn-ghost" onclick="openUserModal('${u.id}')">Edit</button>`
                  : `<button class="btn btn-sm btn-ghost" onclick="openUserModal('${u.id}')">Edit</button>
                     <button class="btn btn-sm btn-ghost" onclick="resetUserPassword('${u.id}')">Reset Password</button>
                     ${!u.self && (canDev || u.role !== 'DEV') ? `<button class="btn btn-sm btn-danger" onclick="delUser('${u.id}','${esc(u.name)}')">Hapus</button>` : ''}`}
              </td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="only-mob mlist">
        ${USER_CACHE.map((u) => `
          <div class="mcard">
            <div class="mcard-top">
              <div class="row-user"><span class="avatar" style="background:var(--brand-700)">${esc(initials(u.name))}</span>
                <div><b>${esc(u.name)}${u.self ? ' (Anda)' : ''}</b><span>${esc(u.email)}</span></div></div>
              <span class="badge ${ROLE_TONE[u.role] || 'b-blue'}">${esc(ROLE_LABEL[u.role] || u.role)}</span>
            </div>
            <div class="mcard-grid">
              <div class="kv"><label>Status</label><b>${u.pending ? 'Menunggu' : (u.active ? 'Aktif' : 'Nonaktif')}</b></div>
              <div class="kv"><label>Peran</label><b>${esc(ROLE_LABEL[u.role] || u.role)}</b></div>
            </div>
            <div class="actions" style="margin-top:10px">
              ${u.pending
                ? `<button class="btn btn-sm btn-green" onclick="approveUser('${u.id}','${esc(u.name)}')">Setujui</button>
                   <button class="btn btn-sm btn-danger" onclick="rejectUser('${u.id}','${esc(u.name)}')">Tolak</button>`
                : `<button class="btn btn-sm btn-ghost" onclick="openUserModal('${u.id}')">Edit</button>
                   <button class="btn btn-sm btn-ghost" onclick="resetUserPassword('${u.id}')">Reset Password</button>
                   ${!u.self && (canDev || u.role !== 'DEV') ? `<button class="btn btn-sm btn-danger" onclick="delUser('${u.id}','${esc(u.name)}')">Hapus</button>` : ''}`}
            </div>
          </div>`).join('')}
      </div>`}
    </div>`;
}
function openUserModal(id) {
  const u = id ? USER_CACHE.find((x) => x.id === id) : null;
  const mine = isDev();
  const roles = ['SUPERADMIN', 'HR', 'MANAGER', 'DEV'].filter((r) => r !== 'DEV' || mine || (u && u.role === 'DEV'));
  openModal(`
    <h3>${u ? 'Edit Pengguna' : 'Tambah Pengguna'}</h3>
    <form onsubmit="saveUser(event, ${u ? `'${u.id}'` : 'null'})">
      <div class="field"><label>Nama Lengkap</label><input id="us-name" value="${u ? esc(u.name) : ''}" placeholder="mis. Budi Hartono" required></div>
      <div class="field"><label>Email</label><input id="us-email" type="email" value="${u ? esc(u.email) : ''}" placeholder="nama@tokokartini.com" required>
        <div class="ttl">${u ? 'Email dipakai untuk login — dapat diubah bila perlu.' : 'Email ini dipakai untuk login akun.'}</div></div>
      <div class="field"><label>Peran</label><select id="us-role">
        ${roles.map((r) => `<option value="${r}" ${u && u.role === r ? 'selected' : ''}>${ROLE_LABEL[r]}</option>`).join('')}
      </select><div class="ttl">${ROLE_DESC.SUPERADMIN}</div></div>
      <div class="field"><label>${u ? 'Password Baru (kosongkan jika tidak diubah)' : 'Password'}</label>
        <input id="us-pass" type="password" minlength="6" ${u ? '' : 'required'} placeholder="min. 6 karakter" autocomplete="new-password"></div>
      ${u ? `<div class="field"><label>Status Akun</label><select id="us-active">
        <option value="true" ${u.active ? 'selected' : ''}>Aktif</option>
        <option value="false" ${!u.active ? 'selected' : ''}>Nonaktif</option>
      </select></div>` : ''}
      <div class="actions">
        <button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button>
        <button type="submit" class="btn btn-primary" style="width:auto">Simpan</button>
      </div>
    </form>`);
}
async function saveUser(ev, id) {
  ev.preventDefault();
  const body = { name: $('us-name').value.trim(), role: $('us-role').value };
  const pass = $('us-pass').value;
  if (pass) body.password = pass;
  const emailEl = $('us-email'); if (emailEl && emailEl.value.trim()) body.email = emailEl.value.trim();
  const actEl = $('us-active'); if (actEl) body.active = actEl.value === 'true';
  try {
    if (id) { await api('admin/users/' + id, { method: 'PUT', body }); toast('Pengguna Diperbarui', 'ok', 'Perubahan akun berhasil disimpan.'); }
    else { await api('admin/users', { method: 'POST', body }); toast('Pengguna Ditambahkan', 'ok', 'Akun pengguna baru berhasil dibuat.'); }
    closeModal(); route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
async function resetUserPassword(id) {
  const u = USER_CACHE.find((x) => x.id === id) || {};
  const np = await promptDialog({ title: 'Reset Password', subtitle: u.name || undefined, icon: 'reset', tone: 'brand',
    html: `<p>Atur password baru untuk akun <b>${esc(u.name || '')}</b> (${esc(u.email || '')}).</p>`,
    label: 'Password baru', placeholder: 'min. 6 karakter', confirmLabel: 'Ubah Password' });
  if (np === null) return;
  if (String(np).length < 6) { toast('Gagal', 'err', 'Password minimal 6 karakter'); return; }
  try { await api('admin/users/' + id, { method: 'PUT', body: { password: np } }); toast('Password Diubah', 'ok', 'Password pengguna berhasil diganti.'); }
  catch (err) { toast('Gagal', 'err', err.message); }
}
async function delUser(id, name) {
  const ok = await confirmDialog({ title: 'Hapus Pengguna', subtitle: name || undefined, icon: 'trash', tone: 'danger',
    html: `<p>Akun <b>${esc(name || '')}</b> akan dihapus permanen dan tidak dapat login lagi.</p>`,
    confirmLabel: 'Hapus', cancelLabel: 'Batal' });
  if (!ok) return;
  try { await api('admin/users/' + id, { method: 'DELETE' }); toast('Pengguna Dihapus', 'ok', name ? `Akun “${name}” telah dihapus.` : undefined); route(); }
  catch (err) { toast('Gagal', 'err', err.message); }
}
async function approveUser(id, name) {
  try {
    await api('admin/users/' + id + '/approve', { method: 'POST', body: { action: 'approve' } });
    toast('Disetujui', 'ok', name ? `Akun “${name}” kini dapat masuk.` : 'Akun disetujui.');
    route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
async function rejectUser(id, name) {
  const ok = await confirmDialog({ title: 'Tolak Pendaftaran', subtitle: name || undefined, icon: 'trash', tone: 'danger',
    html: `<p>Pendaftaran akun <b>${esc(name || '')}</b> akan ditolak dan akun dihapus permanen.</p>`,
    confirmLabel: 'Tolak', cancelLabel: 'Batal' });
  if (!ok) return;
  try {
    await api('admin/users/' + id + '/approve', { method: 'POST', body: { action: 'reject' } });
    toast('Ditolak', 'ok', name ? `Pendaftaran “${name}” ditolak.` : 'Pendaftaran ditolak.');
    route();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.viewPengguna = viewPengguna; window.openUserModal = openUserModal; window.saveUser = saveUser;
window.resetUserPassword = resetUserPassword; window.delUser = delUser;
window.approveUser = approveUser; window.rejectUser = rejectUser;

/* ===================== KONSOL DEVELOPER (B9) ===================== */
let DC_DIAG = null, DC_DEVICES = [], DC_IMPS = [];

async function viewDevConsole() {
  $('top-actions').innerHTML = `<button class="btn btn-orange" onclick="route()">Segarkan</button>`;
  const [diag, dev, imps] = await Promise.all([
    api('admin/diagnostics').catch((e) => ({ ok: false, error: e.message })),
    api('admin/devices').catch(() => ({ items: [] })),
    api('admin/impersonations').catch(() => ({ items: [] })),
  ]);
  DC_DIAG = diag || {}; DC_DEVICES = dev.items || []; DC_IMPS = imps.items || [];
  renderDevConsole();
}
function renderDevConsole() {
  const d = DC_DIAG || {};
  const dk = (label, v, sub) => `<div class="kpi"><b>${esc(String(v))}</b><span class="kpi-lb">${esc(label)}</span>${sub ? `<span class="ttl">${esc(sub)}</span>` : ''}</div>`;
  const cnt = d.counts || {};
  const mem = d.memory || {};
  const poolInfo = d.db || {};
  const ok = d.ok !== false;
  $('view').innerHTML = `
    <div class="card" style="display:flex;align-items:center;gap:14px;justify-content:space-between;flex-wrap:wrap">
      <div style="display:flex;align-items:center;gap:13px">
        <span class="status-dot ${ok ? 'on' : 'off'}"></span>
        <div><h3 style="margin:0">Konsol Developer ${ok ? 'Siap' : 'Gangguan'}</h3>
        <div class="ttl">API v${esc(d.apiVersion || '-')} • ${esc(d.env || '-')} • ${esc(d.nodeVersion || '-')} ${d.region ? '• ' + esc(d.region) : ''}</div></div>
      </div>
      <div class="ttl">Uptime ${d.uptimeSeconds != null ? durLabel(d.uptimeSeconds * 1000) || (d.uptimeSeconds + ' s') : '-'} • ${esc(d.serverTime ? new Date(d.serverTime).toLocaleString('id-ID') : '')}</div>
    </div>
    <div class="kpi-grid">
      ${dk('Latensi DB', (poolInfo.latencyMs ?? '-') + ' ms', 'query ' + (poolInfo.queryLatencyMs ?? '-') + ' ms')}
      ${dk('Pool DB', (poolInfo.poolTotal ?? '-') + ' total', (poolInfo.poolIdle ?? '-') + ' idle, ' + (poolInfo.poolWaiting ?? '-') + ' antre')}
      ${dk('Memori RSS', (mem.rssMB ?? '-') + ' MB', 'heap ' + (mem.heapUsedMB ?? '-') + ' MB')}
      ${dk('Sesi Dukungan Aktif', d.activeImpersonations ?? 0, 'impersonation')}
    </div>
    <div class="card">
      <div class="section-title"><span class="ic">${I.chart}</span> Baris Tabel (Database)</div>
      <div class="count-grid">
        ${Object.keys(cnt).map((k) => `<div class="count-chip"><b>${Number(cnt[k] || 0).toLocaleString('id-ID')}</b><span>${esc(k)}</span></div>`).join('')}
      </div>
      ${(d.recentErrors && d.recentErrors.length) ? `<div class="ttl" style="margin-top:14px"><b>Error terakhir:</b> ${d.recentErrors.map((e) => esc(e.action + ' · ' + (e.detail || e.target || ''))).join(' — ')}</div>` : ''}
      ${!ok ? `<div class="err-box" style="margin-top:12px">${esc(d.error || 'Diagnostik tidak tersedia')}</div>` : ''}
    </div>

    <div class="card">
      <div class="section-title"><span class="ic">${I.users}</span> Imitasi Karyawan (Mode Dukungan · Hanya Baca)</div>
      <div class="ttl" style="margin:-4px 0 12px">Buat sesi dukungan untuk melihat data seorang karyawan <b>tanpa dapat menulis</b>. Semua sesi dicatat & otomatis berakhir.</div>
      <div class="dc-tools">
        <div class="dc-search">
          <span class="s-ic">${I.search}</span>
          <input id="dc-imp-q" placeholder="Cari karyawan (nama / kode)…" oninput="dcFillEmployees()">
        </div>
        <select id="dc-imp-emp" class="dc-select" size="1"></select>
        <input id="dc-imp-note" class="dc-note" placeholder="Catatan (opsional, mis. No. tiket)" maxlength="80">
        <select id="dc-imp-min" class="dc-select" style="max-width:130px">
          <option value="15">15 menit</option><option value="30" selected>30 menit</option>
          <option value="60">60 menit</option><option value="120">120 menit</option>
        </select>
        <button class="btn btn-primary" style="width:auto" onclick="dcStartImpersonation()">Mulai Sesi</button>
      </div>
      <div id="dc-imp-result"></div>
      ${DC_IMPS.length === 0 ? `<div class="empty">Belum ada sesi dukungan.</div>` : `
      <div class="table-wrap" style="margin-top:8px"><table><thead><tr><th>Karyawan</th><th>Oleh</th><th>Mulai</th><th>Berakhir</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>${DC_IMPS.map((it) => `<tr>
        <td><b>${esc(it.fullName || '-')}</b><div class="ttl">${esc(it.employeeCode || '')}</div></td>
        <td>${esc(it.adminName || '-')}${it.note ? `<div class="ttl">${esc(it.note)}</div>` : ''}</td>
        <td class="ttl">${esc(it.createdAt ? new Date(it.createdAt).toLocaleString('id-ID') : '-')}</td>
        <td class="ttl">${esc(it.expiresAt ? new Date(it.expiresAt).toLocaleString('id-ID') : '-')}</td>
        <td>${it.active ? '<span class="badge b-green">Aktif</span>' : '<span class="badge b-grey">Berakhir</span>'}</td>
        <td>${it.active ? `<button class="btn btn-sm btn-danger" onclick="dcEndImpersonation('${it.id}')">Akhiri</button>` : '-'}</td>
      </tr>`).join('')}</tbody></table></div>`}
    </div>

    <div class="card">
      <div class="section-title"><span class="ic">${I.tool || I.system || ''}</span> Perbaikan Data</div>
      <div class="ttl" style="margin:-4px 0 12px">Utilitas pemeliharaan (dev only). Tindakan tercatat di log aktivitas.</div>
      <div class="dc-repair">
        <div class="field"><label>Dari Tanggal</label><input id="dc-from" type="date" value="${dateNDaysAgo(7)}"></div>
        <div class="field"><label>Sampai Tanggal</label><input id="dc-to" type="date" value="${todayISO()}"></div>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:6px">
        <button class="btn btn-ghost" onclick="dcRepair('recompute-late')">Hitung Ulang Keterlambatan</button>
        <button class="btn btn-ghost" onclick="dcRepair('backfill-schedule')">Backfill Jadwal (Shift Default)</button>
      </div>
      <div id="dc-repair-result"></div>
    </div>`;
  dcFillEmployees();
}
window.viewDevConsole = viewDevConsole; window.renderDevConsole = renderDevConsole;

function dcFillEmployees() {
  const sel = $('dc-imp-emp'); if (!sel) return;
  const q = ($('dc-imp-q') ? $('dc-imp-q').value : '').trim().toLowerCase();
  const list = DC_DEVICES.filter((dv) => !q || (dv.fullName || '').toLowerCase().includes(q) || (dv.employeeCode || '').toLowerCase().includes(q));
  const seen = {};
  sel.innerHTML = list.map((dv) => {
    if (seen[dv.employeeCode]) return '';
    seen[dv.employeeCode] = 1;
    return `<option value="${dv.employeeId || ''}" data-name="${esc(dv.fullName)}">${esc(dv.fullName)} (${esc(dv.employeeCode)})</option>`;
  }).join('') || '<option value="">Tidak ada karyawan</option>';
}
window.dcFillEmployees = dcFillEmployees;

async function dcStartImpersonation() {
  const sel = $('dc-imp-emp'); if (!sel || !sel.value) { toast('Pilih Karyawan', 'err', 'Pilih karyawan dulu.'); return; }
  try {
    const r = await api('admin/impersonations', { method: 'POST', body: { employeeId: sel.value, note: ($('dc-imp-note').value || '').trim(), minutes: Number($('dc-imp-min').value || 30) } });
    const link = API + 'impersonate/' + r.token + '?format=json';
    const box = $('dc-imp-result');
    if (box) box.innerHTML = `
      <div class="dc-result">
        <div><b>Sesi dibuat</b> untuk ${esc(r.employee.fullName)} (${esc(r.employee.employeeCode)}) — kedaluwarsa ${esc(new Date(r.expiresAt).toLocaleTimeString('id-ID'))}.</div>
        <div class="ttl" style="word-break:break-all;margin:6px 0">${esc(link)}</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-sm btn-ghost" onclick="dcCopy('${esc(link)}')">Salin Tautan</button>
        </div>
      </div>`;
    toast('Sesi Dukungan Dimulai', 'ok', 'Mode hanya baca — semua aktivitas dicatat.');
    const imps = await api('admin/impersonations').catch(() => ({ items: [] }));
    DC_IMPS = imps.items || [];
    renderDevConsole();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.dcStartImpersonation = dcStartImpersonation;

async function dcEndImpersonation(id) {
  try { await api('admin/impersonations/' + id, { method: 'DELETE' }); toast('Sesi Diakhiri', 'ok'); const imps = await api('admin/impersonations').catch(() => ({ items: [] })); DC_IMPS = imps.items || []; renderDevConsole(); }
  catch (err) { toast('Gagal', 'err', err.message); }
}
window.dcEndImpersonation = dcEndImpersonation;

async function dcRepair(action) {
  const from = $('dc-from').value, to = $('dc-to').value;
  if (!from || !to) { toast('Lengkapi Tanggal', 'err', 'Isi rentang tanggal.'); return; }
  const label = action === 'recompute-late' ? 'Hitung Ulang Keterlambatan' : 'Backfill Jadwal';
  const ok = await confirmDialog({
    title: label, icon: 'system', tone: 'warn',
    html: `<p>Jalankan <b>${esc(label)}</b> untuk rentang <b>${esc(from)}</b> s/d <b>${esc(to)}</b>?</p>
      <div class="dialog-note">${DIALOG_ICONS.info || ''}<span>Operasi dapat mengubah data absensi/jadwal. Pastikan rentang benar.</span></div>`,
    confirmLabel: 'Jalankan',
  });
  if (!ok) return;
  try {
    const r = await api('admin/data/repair', { method: 'POST', body: { action, from, to } });
    const box = $('dc-repair-result');
    if (box) box.innerHTML = `<div class="dc-result">✅ ${esc(r.message || 'Selesai')}</div>`;
    toast('Selesai', 'ok', r.message || 'Operasi berhasil.');
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.dcRepair = dcRepair;

function dcCopy(text) { if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => toast('Ditautkan Disalin', 'ok', 'Tautan sesi disalin.')); }
window.dcCopy = dcCopy;

function dateNDaysAgo(n) { const d = new Date(); d.setDate(d.getDate() - n); return toISO(d); }

/* ===================================================================== */
/*  TAB OPERASIONAL (B11) — Driver, Pramuniaga, Kepala Gudang, Kasir.     */
/*  Karyawan berjabatan RANGKAP otomatis mendapat fasilitas gabungan.     */
/* ===================================================================== */
let OPS_DATE = todayISO();
let OPS_SEG = 'ringkasan';
let OPS_OV = {}; let OPS_TRIPS = []; let OPS_NOTES = []; let OPS_OPNAMES = []; let OPS_SALES = []; let OPS_SESSIONS = []; let OPS_PRODUCTS = []; let OPS_CUSTOMERS = []; let OPS_SETTINGS = {};
// Foto produk yang sedang diedit (data-URL base64). '' = kosong/hapus.
let PF_IMAGE = null;

/**
 * Baca file gambar → kompres ke maks 900px (JPEG) → simpan sebagai data-URL
 * di PF_IMAGE, lalu tampilkan pratinjau. Dipakai form Barang (katalog POS).
 */
function pfPickImage(input) {
  const f = input && input.files && input.files[0];
  if (!f) return;
  if (!/^image\//.test(f.type)) { toast('Gagal', 'err', 'File harus berupa gambar (JPG/PNG).'); return; }
  const r = new FileReader();
  r.onload = () => {
    const im = new Image();
    im.onload = () => {
      const max = 900;
      let w = im.width, h = im.height;
      if (w > max || h > max) { const s = max / Math.max(w, h); w = Math.round(w * s); h = Math.round(h * s); }
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      c.getContext('2d').drawImage(im, 0, 0, w, h);
      PF_IMAGE = c.toDataURL('image/jpeg', 0.82);
      const prev = $('pf-img-prev');
      if (prev) prev.innerHTML = '<img src="' + PF_IMAGE + '" alt="" style="width:100%;height:100%;object-fit:cover">';
    };
    im.onerror = () => toast('Gagal', 'err', 'Gambar tidak dapat dibaca.');
    im.src = r.result;
  };
  r.readAsDataURL(f);
}
window.pfPickImage = pfPickImage;

function pfClearImage() {
  PF_IMAGE = '';
  const prev = $('pf-img-prev');
  if (prev) prev.innerHTML = '<span class="ttl" style="font-size:11px">Tanpa foto</span>';
}
window.pfClearImage = pfClearImage;

/* B22 — Shifting & Penghasilan (POS) */
let OPS_SHIFTS = []; let OPS_SHIFT_KPI = {}; let OPS_REV = {}; let OPS_REV_DAILY = []; let OPS_TARGET = {};
let OPS_SHIFT_FROM = addDaysISO(todayISO(), -6); let OPS_SHIFT_TO = todayISO();
let OPS_REV_FROM = addDaysISO(todayISO(), -29); let OPS_REV_TO = todayISO();
let OPS_SHIFT_FILTER = { status: '', cashier: '' };

function rp(n) { return 'Rp ' + (Math.round(Number(n) || 0)).toLocaleString('id-ID'); }
function opsTone(status) {
  const s = String(status || '').toUpperCase();
  if (['COMPLETED', 'DELIVERED', 'APPROVED', 'PAID', 'FINAL', 'CLOSED'].includes(s)) return 'b-green';
  if (['ON_THE_WAY', 'ARRIVED', 'ASSIGNED', 'OPEN'].includes(s)) return 'b-blue';
  if (['SUBMITTED', 'ISSUED'].includes(s)) return 'b-orange';
  if (['CANCELLED', 'REJECTED'].includes(s)) return 'b-grey';
  return 'b-grey';
}
function opsStatusLabel(s) {
  const map = {
    ASSIGNED: 'Ditugaskan', ON_THE_WAY: 'Di Perjalanan', ARRIVED: 'Tiba di Tujuan',
    COMPLETED: 'Selesai', CANCELLED: 'Dibatalkan', ISSUED: 'Diterbitkan', DELIVERED: 'Terkirim',
    SUBMITTED: 'Menunggu Crosscek', APPROVED: 'Disetujui', REJECTED: 'Ditolak', FINAL: 'Final',
    OPEN: 'Terbuka', CLOSED: 'Ditutup', PAID: 'Lunas',
  };
  return map[String(s || '').toUpperCase()] || s || '-';
}
function opsBadge(s) { return `<span class="badge ${opsTone(s)}">${esc(opsStatusLabel(s))}</span>`; }

function opsSegBar() {
  const segs = [['ringkasan', 'Ringkasan'], ['barang', 'Kelola Barang'], ['pelanggan', 'Pelanggan'], ['driver', 'Driver & Perjalanan'], ['suratjalan', 'Surat Jalan'], ['opname', 'Stock Opname'], ['pos', 'POS Kasir'], ['shifting', 'Shifting Kasir'], ['penghasilan', 'Penghasilan']];
  return `<div class="seg" style="flex-wrap:wrap">${segs.map(([k, l]) => `<button class="${OPS_SEG === k ? 'on' : ''}" onclick="OPS_SEG='${k}';renderOperasional()">${esc(l)}</button>`).join('')}</div>`;
}

async function viewOperasional() {
  $('top-actions').innerHTML = `
    <div class="toolbar" style="margin:0;align-items:center">
      <div class="field" style="margin:0"><label>Tanggal POS/Opname</label>
        <input id="ops-date" type="date" value="${OPS_DATE}" onchange="OPS_DATE=this.value;renderOperasional()"></div>
      <button class="btn btn-orange" onclick="renderOperasional()">Segarkan</button>
    </div>`;
  renderOperasional();
}
window.viewOperasional = viewOperasional;

async function renderOperasional() {
  $('view').innerHTML = `<div class="card"><div class="empty">Memuat data operasional…</div></div>`;
  try {
    const [ov, t, n, op, sl, se, pr, cu, st] = await Promise.all([
      api('ops/admin/ops/overview?date=' + OPS_DATE).catch(() => ({})),
      api('ops/admin/trips').catch(() => ({ items: [] })),
      api('ops/admin/delivery-notes').catch(() => ({ items: [] })),
      api('ops/admin/opnames').catch(() => ({ items: [] })),
      api('ops/admin/pos/sales?date=' + OPS_DATE).catch(() => ({ items: [] })),
      api('ops/admin/pos/sessions').catch(() => ({ items: [] })),
      api('ops/admin/products').catch(() => ({ items: [] })),
      api('ops/admin/customers').catch(() => ({ items: [] })),
      api('ops/admin/pos/settings').catch(() => ({ settings: {} })),
    ]);
    OPS_OV = ov || {}; OPS_TRIPS = t.items || []; OPS_NOTES = n.items || [];
    OPS_OPNAMES = op.items || []; OPS_SALES = sl.items || []; OPS_SESSIONS = se.items || [];
    OPS_PRODUCTS = pr.items || pr.products || [];
    OPS_CUSTOMERS = cu.items || cu.customers || [];
    OPS_SETTINGS = st.settings || {};
  } catch (e) { toast('Gagal Memuat', 'err', e.message); }
  try { await loadOpsShiftRevenue(); } catch (e) { /* diabaikan; segmen menampilkan pesan sendiri */ }
  $('view').innerHTML = opsSegBar() + opsOverviewKpis() + opsSectionHtml();
}
window.renderOperasional = renderOperasional;

/* Muat data Shifting Kasir & Penghasilan (endpoint admin POS). */
async function loadOpsShiftRevenue() {
  const q = (from, to, extra) => 'from=' + from + '&to=' + to + (extra || '');
  const filt = (OPS_SHIFT_FILTER.status ? '&status=' + encodeURIComponent(OPS_SHIFT_FILTER.status) : '')
    + (OPS_SHIFT_FILTER.cashier ? '&cashier=' + encodeURIComponent(OPS_SHIFT_FILTER.cashier) : '');
  const [sh, rv, rd, tg] = await Promise.all([
    api('ops/admin/pos/shifts?' + q(OPS_SHIFT_FROM, OPS_SHIFT_TO, filt)).catch(() => ({ items: [], kpi: {} })),
    api('ops/admin/pos/revenue?' + q(OPS_REV_FROM, OPS_REV_TO)).catch(() => ({ summary: {} })),
    api('ops/admin/pos/revenue/daily?' + q(addDaysISO(todayISO(), -29), todayISO())).catch(() => ({ series: [] })),
    api('ops/admin/pos/target').catch(() => ({ settings: {} })),
  ]);
  OPS_SHIFTS = sh.items || sh.shifts || []; OPS_SHIFT_KPI = sh.kpi || {};
  OPS_REV = rv || {}; OPS_REV_DAILY = rd.series || []; OPS_TARGET = tg.settings || {};
}
window.loadOpsShiftRevenue = loadOpsShiftRevenue;

function opsOverviewKpis() {
  const o = OPS_OV || {};
  const kpi = (label, val, sub, tone) => `
    <div class="kpi"><b>${esc(String(val))}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700;text-transform:uppercase;letter-spacing:.05em">${esc(label)}</span>${sub ? `<small>${esc(sub)}</small>` : ''}</div>`;
  const t = o.trips || {}; const dn = o.deliveryNotes || {}; const op = o.opnames || {}; const pos = o.pos || {}; const pr = o.products || {};
  return `<div class="kpi-grid">
    ${kpi('Perjalanan Aktif', t.active || 0, (t.total || 0) + ' total • ' + (t.completed || 0) + ' selesai')}
    ${kpi('Surat Jalan', dn.total || 0, (dn.delivered || 0) + ' terkirim')}
    ${kpi('Opname Hari Ini', op.total || 0, (op.pending || 0) + ' menunggu crosscek')}
    ${kpi('Penjualan POS', rp(pos.total || 0), (pos.count || 0) + ' transaksi • ' + (pos.openSessions || 0) + ' sesi terbuka')}
    ${kpi('Barang Aktif', pr.total || 0, (pr.low || 0) + ' stok menipis')}
  </div>`;
}

function opsSectionHtml() {
  if (OPS_SEG === 'barang') return opsBarangHtml();
  if (OPS_SEG === 'pelanggan') return opsPelangganHtml();
  if (OPS_SEG === 'driver') return opsDriverHtml();
  if (OPS_SEG === 'suratjalan') return opsNotesHtml();
  if (OPS_SEG === 'opname') return opsOpnameHtml();
  if (OPS_SEG === 'pos') return opsPosHtml();
  if (OPS_SEG === 'shifting') return opsShiftingHtml();
  if (OPS_SEG === 'penghasilan') return opsPenghasilanHtml();
  return opsRingkasanHtml();
}

/* =====================================================================
   B22 — SHIFTING KASIR (X/Z-Report, kas, selisih) & PENGHASILAN / OMZET
   Data dari /api/ops/admin/pos/shifts dan /api/ops/admin/pos/revenue.
   ===================================================================== */
function opsMethodRows(list) {
  return (list || []).map((m) => `<div class="kv"><label>${esc(m.method || '-')}</label><b class="num">${rp(m.amount)} <span class="ttl">(${m.count})</span></b></div>`).join('');
}
function opsBarPct(v, max) { return max > 0 ? Math.max(2, Math.round((v / max) * 100)) : 0; }
function opsMiniBars(rows, labelKey, valKey) {
  const max = Math.max(1, ...rows.map((r) => Number(r[valKey]) || 0));
  return rows.map((r) => `<div class="kv"><label>${esc(r[labelKey])}</label>
    <span style="flex:1;display:flex;align-items:center;gap:8px;justify-content:flex-end">
      <i style="height:8px;border-radius:5px;background:var(--accent,#0f7a3d);display:inline-block;width:${opsBarPct(Number(r[valKey]) || 0, max)}%"></i>
      <b class="num">${rp(r[valKey])}</b></span></div>`).join('');
}

function opsShiftingHtml() {
  const k = OPS_SHIFT_KPI || {};
  const items = OPS_SHIFTS || [];
  const open = items.filter((s) => s.status === 'OPEN');
  const pend = items.filter((s) => s.status === 'PENDING_APPROVAL');
  const kpi = (label, val, sub, tone) => `<div class="kpi${tone ? ' ' + tone : ''}"><b>${esc(String(val))}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700;text-transform:uppercase;letter-spacing:.05em">${esc(label)}</span>${sub ? `<small>${esc(sub)}</small>` : ''}</div>`;
  return `
  <div class="toolbar" style="flex-wrap:wrap;gap:10px;align-items:end;margin-bottom:14px">
    <div class="field" style="margin:0"><label>Dari</label><input type="date" value="${OPS_SHIFT_FROM}" onchange="OPS_SHIFT_FROM=this.value;renderOperasional()"></div>
    <div class="field" style="margin:0"><label>Sampai</label><input type="date" value="${OPS_SHIFT_TO}" onchange="OPS_SHIFT_TO=this.value;renderOperasional()"></div>
    <div class="field" style="margin:0"><label>Status</label><select onchange="OPS_SHIFT_FILTER.status=this.value;renderOperasional()">
      ${[['', 'Semua'], ['OPEN', 'Terbuka'], ['PENDING_APPROVAL', 'Menunggu persetujuan'], ['CLOSED', 'Ditutup'], ['FORCE_CLOSED', 'Ditutup paksa']].map(([v, l]) => `<option value="${v}"${OPS_SHIFT_FILTER.status === v ? ' selected' : ''}>${l}</option>`).join('')}</select></div>
    <div class="field" style="margin:0"><label>Kasir</label><input value="${esc(OPS_SHIFT_FILTER.cashier)}" placeholder="nama kasir" onchange="OPS_SHIFT_FILTER.cashier=this.value;renderOperasional()"></div>
    <div class="field" style="margin:0"><label>&nbsp;</label><button class="btn btn-orange" onclick="renderOperasional()">Terapkan</button></div>
  </div>
  <div class="kpi-grid">
    ${kpi('Shift', k.totalShifts || items.length || 0, (k.openShifts || open.length || 0) + ' terbuka • ' + (k.pendingApproval || pend.length || 0) + ' menunggu')}
    ${kpi('Omzet Shift', rp(k.revenue || 0), 'total penjualan')}
    ${kpi('Laba (estimasi)', rp(k.profit || 0), 'setelah HPP', 'o')}
    ${kpi('Selisih Kas', rp(k.cashVariance || 0), (k.varianceShifts || 0) + ' shift berselisih')}
    ${kpi('Durasi Rata-rata', (k.avgDurationMinutes || 0) + ' mnt', 'per shift')}
  </div>
  ${pend.length ? `<div class="card" style="border-color:#f0c37a"><h3 style="margin-top:0">Menunggu Persetujuan Selisih Kas</h3>
    <div class="table-wrap"><table><thead><tr><th>Kasir</th><th>Terminal</th><th>Selisih</th><th>Dibuka</th><th>Aksi</th></tr></thead><tbody>
    ${pend.map((s) => `<tr><td><b>${esc(s.cashierName || '-')}</b></td><td>${esc(s.terminal || '-')}</td>
      <td><b style="color:${(s.cashDiff || 0) < 0 ? 'var(--danger)' : 'var(--accent)'}">${rp(s.cashDiff || 0)}</b></td>
      <td class="ttl">${esc((s.openedAt || '').replace('T', ' ').slice(0, 16))}</td>
      <td><button class="btn btn-sm btn-green" onclick="opsApproveShift('${s.id}')">Setujui</button>
          <button class="btn btn-sm btn-ghost" onclick="opsOpenShift('${s.id}')">Detail</button></td></tr>`).join('')}
    </tbody></table></div></div>` : ''}
  <div class="card">
    <h3 style="margin-top:0">Daftar Shift Kasir</h3>
    ${items.length ? `<div class="table-wrap"><table>
      <thead><tr><th>Kasir</th><th>Terminal</th><th>Buka</th><th>Tutup</th><th>Transaksi</th><th>Omzet</th><th>Laba</th><th>Tunai Awal</th><th>Laci (akhir)</th><th>Seharusnya</th><th>Selisih</th><th>Kas In/Out</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>${items.map((s) => {
        const t = s.totals || {};
        const diff = s.cashDiff;
        const diffCell = diff == null ? '<span class="ttl">-</span>' : (Math.abs(diff) < 1 ? '<span class="badge b-green">Pas</span>' : `<b style="color:${diff < 0 ? 'var(--danger)' : 'var(--accent)'}">${rp(diff)}</b>`);
        return `<tr>
          <td><b>${esc(s.cashierName || '-')}</b><div class="ttl">${esc(s.shiftLabel || s.code || '')}</div></td>
          <td>${esc(s.terminal || '-')}</td>
          <td class="ttl">${esc(hhmm(s.openedAt))}<br>${esc((s.openedAt || '').slice(0, 10))}</td>
          <td class="ttl">${s.closedAt ? esc(hhmm(s.closedAt)) + '<br>' + esc((s.closedAt || '').slice(0, 10)) : '-'}</td>
          <td class="num">${t.count || 0}</td>
          <td class="num"><b>${rp(t.total || 0)}</b></td>
          <td class="num">${rp(t.profit || 0)}</td>
          <td class="num">${rp(s.openingCash || 0)}</td>
          <td class="num">${s.closingCash != null ? rp(s.closingCash) : '<span class="ttl">-</span>'}</td>
          <td class="num">${s.expectedCash != null ? rp(s.expectedCash) : '<span class="ttl">-</span>'}</td>
          <td>${diffCell}</td>
          <td class="ttl">+${rp(t.cashIn || 0)} / -${rp(t.cashOut || 0)}</td>
          <td>${opsBadge(s.status)}</td>
          <td><button class="btn btn-sm btn-ghost" onclick="opsOpenShift('${s.id}')">Z-Report</button></td>
        </tr>`;
      }).join('')}</tbody></table></div>` : '<div class="empty">Belum ada shift pada rentang tanggal ini. Data muncul setelah kasir membuka shift di aplikasi POS.</div>'}
  </div>`;
}

function opsPenghasilanHtml() {
  const rev = OPS_REV || {};
  const s = rev.summary || {};
  const prev = rev.previous || {};
  const growth = (a, b) => (b > 0 ? ((a - b) / b) * 100 : (a > 0 ? 100 : 0));
  const g = growth(Number(s.total) || 0, Number(prev.total) || 0);
  const gTone = g >= 0 ? 'var(--accent)' : 'var(--danger)';
  const kpi = (label, val, sub, tone) => `<div class="kpi${tone ? ' ' + tone : ''}"><b>${val}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700;text-transform:uppercase;letter-spacing:.05em">${esc(label)}</span>${sub ? `<small>${sub}</small>` : ''}</div>`;
  const byMethod = rev.byMethod || []; const byCashier = rev.byCashier || []; const byCat = rev.byCategory || [];
  const byDay = rev.byDay || []; const top = rev.topProducts || []; const byHour = rev.byHour || [];
  const days = OPS_REV_DAILY || [];
  const tgt = (OPS_TARGET && OPS_TARGET.dailyTarget) || 0;
  const maxDay = Math.max(1, ...days.map((d) => Number(d.total) || 0));
  return `
  <div class="toolbar" style="flex-wrap:wrap;gap:10px;align-items:end;margin-bottom:14px">
    <div class="field" style="margin:0"><label>Dari</label><input type="date" value="${OPS_REV_FROM}" onchange="OPS_REV_FROM=this.value;renderOperasional()"></div>
    <div class="field" style="margin:0"><label>Sampai</label><input type="date" value="${OPS_REV_TO}" onchange="OPS_REV_TO=this.value;renderOperasional()"></div>
    <div class="field" style="margin:0"><label>&nbsp;</label><button class="btn btn-orange" onclick="renderOperasional()">Terapkan</button></div>
    <div class="field" style="margin:0"><label>&nbsp;</label><button class="btn btn-ghost" onclick="opsExportRevenue()">Ekspor CSV</button></div>
  </div>
  <div class="kpi-grid">
    ${kpi('Omzet Bersih', rp(s.netSales || 0), (s.count || 0) + ' transaksi')}
    ${kpi('Penjualan Kotor', rp(s.gross || 0), 'sebelum diskon')}
    ${kpi('Diskon', rp(s.discount || 0), 'potongan')}
    ${kpi('HPP', rp(s.cogs || 0), 'harga pokok')}
    ${kpi('Laba', rp(s.profit || 0), 'margin ' + (Math.round((Number(s.marginPct) || 0) * 10) / 10) + '%', 'o')}
    ${kpi('Pertumbuhan', (g >= 0 ? '+' : '') + (Math.round(g * 10) / 10) + '%', 'vs periode sebelumnya')}
    ${kpi('Rata-rata/Nota', rp(s.avgBasket || 0), 'per transaksi')}
    ${kpi('Item Terjual', (s.itemsSold || 0), (s.voidCount || 0) + ' void')}
  </div>
  <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
    <div class="card"><h3 style="margin-top:0">Omzet Harian (30 hari)</h3>
      ${days.length ? days.map((d) => `<div class="kv"><label>${esc(d.date)}</label>
        <span style="flex:1;display:flex;align-items:center;gap:8px;justify-content:flex-end">
          <i style="height:8px;border-radius:5px;background:${d.target && d.total >= d.target ? 'var(--accent,#0f7a3d)' : '#cfe3d6'};display:inline-block;width:${opsBarPct(Number(d.total) || 0, maxDay)}%"></i>
          <b class="num">${rp(d.total)}</b></span></div>`).join('') : '<div class="empty">Belum ada data.</div>'}
      <div class="ttl" style="margin-top:8px">Target harian: <b>${rp(tgt)}</b> ${tgt ? '(diatur admin)' : '(belum diatur)'}</div>
    </div>
    <div class="card"><h3 style="margin-top:0">Penjualan per Metode</h3>
      ${byMethod.length ? opsMethodRows(byMethod) : '<div class="empty">Belum ada data.</div>'}
      <h3 style="margin:16px 0 8px">Penjualan per Kategori</h3>
      ${byCat.length ? opsMiniBars(byCat.slice(0, 8), 'name', 'total') : '<div class="empty">Belum ada data.</div>'}
    </div>
    <div class="card"><h3 style="margin-top:0">Omzet per Kasir</h3>
      ${byCashier.length ? `<div class="table-wrap"><table><thead><tr><th>Kasir</th><th>Transaksi</th><th>Omzet</th><th>Laba</th></tr></thead>
        <tbody>${byCashier.map((c) => `<tr><td><b>${esc(c.name)}</b></td><td class="num">${c.count}</td><td class="num"><b>${rp(c.total)}</b></td><td class="num">${rp(c.profit)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">Belum ada data.</div>'}
    </div>
    <div class="card"><h3 style="margin-top:0">Produk Terlaris</h3>
      ${top.length ? `<div class="table-wrap"><table><thead><tr><th>Produk</th><th>Qty</th><th>Omzet</th><th>Laba</th></tr></thead>
        <tbody>${top.slice(0, 10).map((p) => `<tr><td>${esc(p.name || '-')}<div class="ttl">${esc(p.sku || '')}</div></td><td class="num">${p.qty || 0}</td><td class="num">${rp(p.total)}</td><td class="num">${rp(p.profit)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">Belum ada data.</div>'}
    </div>
  </div>
  <div class="card"><h3 style="margin-top:0">Omzet per Jam (pola jam sibuk)</h3>
    ${byHour.length ? byHour.map((h) => `<div class="kv"><label>${String(h.hour).padStart(2, '0')}:00</label>
      <span style="flex:1;display:flex;align-items:center;gap:8px;justify-content:flex-end">
        <i style="height:8px;border-radius:5px;background:var(--accent,#0f7a3d);display:inline-block;width:${opsBarPct(Number(h.total) || 0, Math.max(1, ...byHour.map((x) => Number(x.total) || 0)))}%"></i>
        <b class="num">${rp(h.total)}</b> <span class="ttl">(${h.count})</span></span></div>`).join('') : '<div class="empty">Belum ada data.</div>'}
  </div>`;
}

async function opsOpenShift(id) {
  try {
    const r = await api('ops/admin/pos/shifts/' + id);
    const s = r.shift || {}; const t = s.totals || {};
    const mv = r.movements || []; const sales = r.sales || [];
    const diffNote = s.varianceNote ? `<div class="dialog-note">Catatan: ${esc(s.varianceNote)}</div>` : '';
    const row = (l, v) => `<div class="kv"><label>${l}</label><b class="num">${v}</b></div>`;
    openModal(`
      <h3>Z-Report — ${esc(s.cashierName || '-')}</h3>
      <div class="ttl" style="margin-bottom:10px">${esc(s.terminal || '')} • ${esc(s.shiftLabel || s.code || '')} • ${esc(s.status || '')}</div>
      <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
        <div>
          ${row('Dibuka', esc((s.openedAt || '').replace('T', ' ').slice(0, 16)))}
          ${row('Ditutup', s.closedAt ? esc((s.closedAt || '').replace('T', ' ').slice(0, 16)) : '-')}
          ${row('Durasi', durLabel(s.durationMinutes))}
          ${row('Kas Awal', rp(s.openingCash || 0))}
          ${row('Total Omzet', rp(t.total || 0))}
          ${row('Jumlah Transaksi', t.count || 0)}
          ${row('Penjualan Tunai', rp(t.cashSales || 0))}
          ${row('Penjualan Non-Tunai', rp(t.nonCashSales || 0))}
        </div>
        <div>
          ${row('Bruto', rp(t.gross || 0))}
          ${row('Diskon', rp(t.discount || 0))}
          ${row('Pajak', rp(t.tax || 0))}
          ${row('HPP', rp(t.cogs || 0))}
          ${row('Laba', rp(t.profit || 0))}
          ${row('Kas Masuk', rp(t.cashIn || 0))}
          ${row('Kas Keluar', rp(t.cashOut || 0))}
          ${row('Laci (akhir)', s.closingCash != null ? rp(s.closingCash) : '-')}
          ${row('Kas Seharusnya', s.expectedCash != null ? rp(s.expectedCash) : '-')}
          ${row('Selisih', s.cashDiff != null ? rp(s.cashDiff) : '-')}
        </div>
      </div>
      ${diffNote}
      <h4 style="margin:14px 0 6px">Gerakan Kas</h4>
      ${mv.length ? `<div class="table-wrap" style="max-height:24vh;overflow:auto"><table><thead><tr><th>Jenis</th><th>Jumlah</th><th>Alasan</th><th>Waktu</th></tr></thead><tbody>
        ${mv.map((m) => `<tr><td>${m.kind === 'IN' ? '<span class="badge b-green">Masuk</span>' : '<span class="badge b-orange">Keluar</span>'}</td><td class="num">${rp(m.amount)}</td><td>${esc(m.reason || '-')}</td><td class="ttl">${esc(hhmm(m.createdAt))}</td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty">Tidak ada gerakan kas.</div>'}
      <h4 style="margin:14px 0 6px">Transaksi (${sales.length})</h4>
      ${sales.length ? `<div class="table-wrap" style="max-height:26vh;overflow:auto"><table><thead><tr><th>Kode</th><th>Total</th><th>Laba</th><th>Bayar</th><th>Status</th><th>Waktu</th></tr></thead><tbody>
        ${sales.map((x) => `<tr><td><b>${esc(x.code || '-')}</b></td><td class="num">${rp(x.total)}</td><td class="num">${rp(x.profit)}</td><td>${esc(x.paymentMethod || '-')}</td><td>${opsBadge(x.status)}</td><td class="ttl">${esc(hhmm(x.createdAt))}</td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty">Tidak ada transaksi pada shift ini.</div>'}
      <div style="margin-top:12px;text-align:right">
        ${s.status === 'OPEN' ? `<button class="btn btn-ghost" onclick="opsForceClose('${s.id}')">Tutup Paksa</button>` : ''}
        ${s.status === 'PENDING_APPROVAL' ? `<button class="btn btn-green" onclick="opsApproveShift('${s.id}')">Setujui Selisih</button>` : ''}
        <button class="btn btn-ghost" onclick="closeModal()">Tutup</button>
      </div>`);
  } catch (e) { toast('Gagal Memuat', 'err', e.message); }
}
window.opsOpenShift = opsOpenShift;

async function opsApproveShift(id) {
  try { const r = await api('ops/admin/pos/shifts/' + id + '/approve', { method: 'POST', body: { note: 'Disetujui dari panel' } }); toast('Disetujui', 'ok', r.message || ''); closeModal(); renderOperasional(); }
  catch (e) { toast('Gagal', 'err', e.message); }
}
window.opsApproveShift = opsApproveShift;

async function opsForceClose(id) {
  const counted = prompt('Jumlah uang di laci saat ini (angka saja):');
  if (counted == null) return;
  try { const r = await api('ops/admin/pos/shifts/' + id + '/force-close', { method: 'POST', body: { countedCash: Number(String(counted).replace(/[^0-9]/g, '')) || 0, note: 'Ditutup paksa dari panel' } }); toast('Ditutup paksa', 'ok', 'Selisih: ' + rp(r.cashDiff)); closeModal(); renderOperasional(); }
  catch (e) { toast('Gagal', 'err', e.message); }
}
window.opsForceClose = opsForceClose;

function opsExportRevenue() {
  const base = (window.__API_BASE__ || 'https://api.simaung.com/api/').replace(/\/+$/, '');
  const url = base + '/ops/admin/pos/revenue/export.csv?from=' + OPS_REV_FROM + '&to=' + OPS_REV_TO;
  // Sertakan token admin agar unduhan lolos otorisasi.
  fetch(url, { headers: { Authorization: 'Bearer ' + (S.token || '') } })
    .then((r) => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.blob(); })
    .then((b) => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'penghasilan-' + OPS_REV_FROM + '_' + OPS_REV_TO + '.csv'; a.click(); URL.revokeObjectURL(a.href); })
    .catch((e) => toast('Ekspor gagal', 'err', e.message));
}
window.opsExportRevenue = opsExportRevenue;

function opsRingkasanHtml() {
  const active = OPS_TRIPS.filter((t) => ['ASSIGNED', 'ON_THE_WAY', 'ARRIVED'].includes(t.status));
  const pend = OPS_OPNAMES.filter((o) => o.status === 'SUBMITTED');
  const open = OPS_SESSIONS.filter((s) => s.status === 'OPEN');
  const list = (items, empty, rowFn) => items.length ? `<div class="mlist">${items.slice(0, 6).map(rowFn).join('')}</div>` : `<div class="empty">${empty}</div>`;
  return `
  <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
    <div class="card"><h3 style="margin-top:0">Perjalanan Berjalan</h3>
      ${list(active, 'Tidak ada perjalanan aktif.', (t) => `
        <div class="mcard"><div class="mcard-top"><div class="row-user"><div><b>${esc(t.driverName || 'Driver')}</b><span>${esc(t.code || '')} • ${esc(t.vehicle || '-')}</span></div></div>${opsBadge(t.status)}</div>
        <div class="mcard-grid"><div class="kv"><label>Tujuan</label><b>${esc(t.destination || '-')}</b></div>
        <div class="kv"><label>Posisi</label><b>${t.lastLat != null ? `<a href="https://maps.google.com/?q=${t.lastLat},${t.lastLng}" target="_blank">Peta</a>` : '-'}</b></div></div></div>`)}
    </div>
    <div class="card"><h3 style="margin-top:0">Opname Menunggu Crosscek</h3>
      ${list(pend, 'Tidak ada opname yang menunggu crosscek.', (o) => `
        <div class="mcard"><div class="mcard-top"><div class="row-user"><div><b>${esc(o.employeeName || '-')}</b><span>${esc(o.kind)} • ${esc(o.area || 'semua area')}</span></div></div>${opsBadge(o.status)}</div>
        <div class="mcard-grid"><div class="kv"><label>Item</label><b>${o.totalItems}</b></div><div class="kv"><label>Selisih</label><b>${o.totalDiff}</b></div></div>
        <div style="margin-top:8px"><button class="btn btn-sm btn-ghost" onclick="openOpnameDetail('${o.id}')">Lihat & Crosscek</button></div></div>`)}
    </div>
    <div class="card"><h3 style="margin-top:0">Sesi Kasir Terbuka</h3>
      ${list(open, 'Tidak ada sesi kasir terbuka.', (s) => `
        <div class="mcard"><div class="mcard-top"><div class="row-user"><div><b>${esc(s.cashierName || 'Kasir')}</b><span>Dibuka ${esc(hhmm(s.openedAt))} • ${esc((s.openedAt||'').slice(0,10))}</span></div></div>${opsBadge(s.status)}</div></div>`)}
    </div>
    <div class="card"><h3 style="margin-top:0">Surat Jalan Terbaru</h3>
      ${list(OPS_NOTES, 'Belum ada surat jalan.', (n) => `
        <div class="mcard"><div class="mcard-top"><div class="row-user"><div><b>${esc(n.code || '-')}</b><span>${esc(n.driverName || '-')} → ${esc(n.recipientName || '-')}</span></div></div>${opsBadge(n.status)}</div>
        <div style="margin-top:8px"><button class="btn btn-sm btn-ghost" onclick="printDeliveryNote('${n.id}')">Cetak</button></div></div>`)}
    </div>
  </div>`;
}

function opsBarangHtml() {
  const items = OPS_PRODUCTS || [];
  const low = items.filter((p) => p.active !== false && (p.stock || 0) <= (p.minStock || 0)).length;
  const active = items.filter((p) => p.active !== false).length;
  return `
  <div class="kpi-grid">
    <div class="kpi"><b>${items.length}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700;text-transform:uppercase">Total Barang</span></div>
    <div class="kpi"><b>${active}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700;text-transform:uppercase">Aktif</span></div>
    <div class="kpi o"><b>${low}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700;text-transform:uppercase">Stok Menipis</span></div>
    <div class="kpi"><button class="btn btn-green" onclick="openProductForm()">+ Tambah Barang</button></div>
  </div>
  <div class="card">
    <div class="toolbar" style="margin-top:0"><div class="field" style="margin:0;flex:1;max-width:320px">
      <label>Cari barang</label><input id="prod-search" placeholder="Nama / SKU / kategori" oninput="filterProductTable()"></div></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Foto</th><th>Nama</th><th>SKU</th><th>Barcode</th><th>Kategori</th><th>Harga Jual</th><th>Harga Pokok</th><th>Stok</th><th>Min</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody id="prod-body">${items.map(productRow).join('')}</tbody>
    </table></div>
    ${items.length ? '' : '<div class="empty">Belum ada barang. Klik + Tambah Barang untuk mengisi katalog. Master ini dipakai bersama oleh POS dan Stock Opname.</div>'}
  </div>`;
}

function productRow(p) {
  const isLow = p.active !== false && (p.stock || 0) <= (p.minStock || 0);
  const thumb = p.image
    ? `<img src="${p.image}" alt="" loading="lazy" style="width:38px;height:38px;border-radius:8px;object-fit:cover;border:1px solid var(--line)">`
    : `<span class="ttl" style="font-size:16px">🖼️</span>`;
  return `<tr data-search="${esc(((p.name || '') + ' ' + (p.sku || '') + ' ' + (p.barcode || '') + ' ' + (p.category || '')).toLowerCase())}">
    <td>${thumb}</td>
    <td><b>${esc(p.name || '-')}</b></td>
    <td class="ttl">${esc(p.sku || '-')}</td>
    <td class="ttl">${esc(p.barcode || '-')}</td>
    <td>${esc(p.category || '-')}</td>
    <td><b>${rp(p.price || 0)}</b></td>
    <td class="ttl">${rp(p.cost || 0)}</td>
    <td>${isLow ? `<span class="badge b-orange">${p.stock || 0}</span>` : (p.stock || 0)} <span class="ttl">${esc(p.unit || 'pcs')}</span></td>
    <td class="ttl">${p.minStock || 0}</td>
    <td>${p.active !== false ? '<span class="badge b-green">Aktif</span>' : '<span class="badge">Nonaktif</span>'}</td>
    <td style="white-space:nowrap">
      <button class="btn btn-sm btn-ghost" onclick="openProductForm('${p.id}')">Ubah</button>
      <button class="btn btn-sm btn-ghost" onclick="toggleProduct('${p.id}')">${p.active !== false ? 'Nonaktifkan' : 'Aktifkan'}</button>
      <button class="btn btn-sm btn-ghost" onclick="deleteProduct('${p.id}')">Hapus</button>
    </td>
  </tr>`;
}

function filterProductTable() {
  const q = (($('prod-search') || {}).value || '').toLowerCase().trim();
  document.querySelectorAll('#prod-body tr').forEach((tr) => {
    tr.style.display = !q || (tr.getAttribute('data-search') || '').includes(q) ? '' : 'none';
  });
}
window.filterProductTable = filterProductTable;

function openProductForm(id) {
  const p = (OPS_PRODUCTS || []).find((x) => x.id === id) || {};
  const editing = !!id;
  PF_IMAGE = editing && p.image ? p.image : '';
  const fprev = PF_IMAGE
    ? '<img src="' + PF_IMAGE + '" alt="" style="width:100%;height:100%;object-fit:cover">'
    : '<span class="ttl" style="font-size:11px">Tanpa foto</span>';
  openModal(`
    <h3>${editing ? 'Ubah Barang' : 'Tambah Barang'}</h3>
    <div class="ttl" style="margin-bottom:12px">Master barang dipakai bersama oleh POS kasir & Stock Opname.</div>
    <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;align-items:start">
      <div class="field">
        <label>Foto produk</label>
        <div id="pf-img-prev" style="width:120px;height:120px;border:1px dashed var(--line);border-radius:12px;overflow:hidden;display:flex;align-items:center;justify-content:center;background:var(--bg);margin-bottom:8px">${fprev}</div>
        <input id="pf-img" type="file" accept="image/*" onchange="pfPickImage(this)" style="font-size:12px">
        <button type="button" class="btn btn-sm btn-ghost" style="margin-top:6px" onclick="pfClearImage()">Hapus foto</button>
      </div>
      <div>
        <div class="field"><label>Nama barang *</label><input id="pf-name" value="${esc(p.name || '')}"></div>
        <div class="field"><label>SKU / kode</label><input id="pf-sku" value="${esc(p.sku || '')}"></div>
        <div class="field"><label>Barcode (scan kasir)</label><input id="pf-barcode" value="${esc(p.barcode || '')}"></div>
      </div>
    </div>
    <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="field"><label>Kategori</label><input id="pf-cat" value="${esc(p.category || '')}"></div>
    </div>
    <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="field"><label>Satuan</label><input id="pf-unit" value="${esc(p.unit || 'pcs')}"></div>
      <div class="field"><label>Status</label>
        <select id="pf-active"><option value="true" ${p.active !== false ? 'selected' : ''}>Aktif</option><option value="false" ${p.active === false ? 'selected' : ''}>Nonaktif</option></select></div>
    </div>
    <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="field"><label>Harga jual (Rp)</label><input id="pf-price" type="number" min="0" value="${Math.round(p.price || 0)}"></div>
      <div class="field"><label>Harga pokok (Rp)</label><input id="pf-cost" type="number" min="0" value="${Math.round(p.cost || 0)}"></div>
    </div>
    <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="field"><label>Stok</label><input id="pf-stock" type="number" min="0" value="${p.stock || 0}"></div>
      <div class="field"><label>Stok minimum</label><input id="pf-min" type="number" min="0" value="${p.minStock || 0}"></div>
    </div>
    <div class="toolbar" style="justify-content:flex-end;margin-top:14px">
      <button class="btn btn-outline" onclick="closeModal()">Batal</button>
      <button class="btn btn-green" onclick="saveProduct(${editing ? `'${id}'` : 'null'})">Simpan</button>
    </div>
  `, { wide: true });
}
window.openProductForm = openProductForm;

async function saveProduct(id) {
  const val = (el) => (($(el) || {}).value || '').trim();
  const name = val('pf-name');
  if (!name) { toast('Perlu dilengkapi', 'err', 'Nama barang wajib diisi.'); return; }
  const body = {
    name,
    sku: val('pf-sku') || null,
    barcode: val('pf-barcode') || null,
    category: val('pf-cat') || null,
    unit: val('pf-unit') || 'pcs',
    price: Number(val('pf-price')) || 0,
    cost: Number(val('pf-cost')) || 0,
    stock: parseInt(val('pf-stock'), 10) || 0,
    minStock: parseInt(val('pf-min'), 10) || 0,
    active: val('pf-active') === 'true',
    image: PF_IMAGE == null ? undefined : (PF_IMAGE || ''),
  };
  try {
    if (id) await api('ops/admin/products/' + id, { method: 'PUT', body });
    else await api('ops/admin/products', { method: 'POST', body });
    closeModal();
    toast('Berhasil', 'ok', id ? 'Barang diperbarui.' : 'Barang ditambahkan.');
    await renderOperasional();
  } catch (e) { toast('Gagal', 'err', e.message); }
}
window.saveProduct = saveProduct;

async function toggleProduct(id) {
  const p = (OPS_PRODUCTS || []).find((x) => x.id === id);
  if (!p) return;
  try {
    await api('ops/admin/products/' + id, { method: 'PUT', body: { active: p.active === false } });
    toast('Berhasil', 'ok', p.active === false ? 'Barang diaktifkan.' : 'Barang dinonaktifkan.');
    await renderOperasional();
  } catch (e) { toast('Gagal', 'err', e.message); }
}
window.toggleProduct = toggleProduct;

async function deleteProduct(id) {
  const p = (OPS_PRODUCTS || []).find((x) => x.id === id) || {};
  if (!confirm(`Hapus barang “${p.name || ''}”? Tindakan ini tidak bisa dibatalkan.`)) return;
  try {
    await api('ops/admin/products/' + id, { method: 'DELETE' });
    toast('Berhasil', 'ok', 'Barang dihapus.');
    await renderOperasional();
  } catch (e) { toast('Gagal', 'err', e.message); }
}
window.deleteProduct = deleteProduct;

// ---- Pelanggan / Member (POS) ----
function opsPelangganHtml() {
  const items = OPS_CUSTOMERS || [];
  const members = items.filter((c) => (c.tier || 'regular') !== 'regular').length;
  const s = OPS_SETTINGS || {};
  return `
  <div class="kpi-grid">
    <div class="kpi"><b>${items.length}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700;text-transform:uppercase">Total Pelanggan</span></div>
    <div class="kpi o"><b>${members}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700;text-transform:uppercase">Member</span></div>
    <div class="kpi"><button class="btn btn-green" onclick="openCustomerForm()">+ Tambah Pelanggan</button></div>
    <div class="kpi"><button class="btn btn-outline" onclick="openPosSettings()">Pengaturan POS</button></div>
  </div>
  <div class="card">
    <div class="ttl" style="margin-bottom:10px">Pelanggan & member dipakai di kasir POS untuk diskon otomatis sesuai tier. Pajak: <b>${Number(s.taxRate || 0)}%</b> (${s.taxEnabled ? 'aktif' : 'nonaktif'}) • Split payment: <b>${s.splitPaymentEnabled === false ? 'nonaktif' : 'aktif'}</b></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Nama</th><th>No. HP</th><th>Tier</th><th>Diskon</th><th>Poin</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>${items.map(customerRow).join('')}</tbody>
    </table></div>
    ${items.length ? '' : '<div class="empty">Belum ada pelanggan. Klik + Tambah Pelanggan.</div>'}
  </div>`;
}

function customerRow(c) {
  const tier = (c.tier || 'regular');
  const badge = tier === 'gold' ? 'b-orange' : tier === 'silver' ? 'b-blue' : tier === 'platinum' ? 'b-green' : '';
  return `<tr>
    <td><b>${esc(c.name || '-')}</b></td>
    <td class="ttl">${esc(c.phone || '-')}</td>
    <td><span class="badge ${badge}">${esc(tier.toUpperCase())}</span></td>
    <td>${c.discountPercent > 0 ? '-' + Number(c.discountPercent) + '%' : '-'}</td>
    <td class="ttl">${c.points || 0}</td>
    <td>${c.active !== false ? '<span class="badge b-green">Aktif</span>' : '<span class="badge">Nonaktif</span>'}</td>
    <td style="white-space:nowrap">
      <button class="btn btn-sm btn-ghost" onclick="openCustomerForm('${c.id}')">Ubah</button>
      <button class="btn btn-sm btn-ghost" onclick="deleteCustomer('${c.id}')">Nonaktifkan</button>
    </td>
  </tr>`;
}

function openCustomerForm(id) {
  const c = (OPS_CUSTOMERS || []).find((x) => x.id === id) || {};
  const editing = !!id;
  const tiers = ['regular', 'silver', 'gold', 'platinum'];
  openModal(`
    <h3>${editing ? 'Ubah Pelanggan' : 'Tambah Pelanggan'}</h3>
    <div class="field"><label>Nama pelanggan *</label><input id="cf-name" value="${esc(c.name || '')}"></div>
    <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="field"><label>No. HP</label><input id="cf-phone" value="${esc(c.phone || '')}"></div>
      <div class="field"><label>Tier</label><select id="cf-tier">${tiers.map((t) => `<option value="${t}" ${(c.tier || 'regular') === t ? 'selected' : ''}>${t[0].toUpperCase() + t.slice(1)}</option>`).join('')}</select></div>
    </div>
    <div class="field"><label>Diskon member (%)</label><input id="cf-disc" type="number" min="0" max="100" value="${Number(c.discountPercent || 0)}"></div>
    <div class="toolbar" style="justify-content:flex-end;margin-top:14px">
      <button class="btn btn-outline" onclick="closeModal()">Batal</button>
      <button class="btn btn-green" onclick="saveCustomer(${editing ? `'${id}'` : 'null'})">Simpan</button>
    </div>
  `, { wide: true });
}
window.openCustomerForm = openCustomerForm;

async function saveCustomer(id) {
  const val = (el) => (($(el) || {}).value || '').trim();
  const name = val('cf-name');
  if (!name) { toast('Perlu dilengkapi', 'err', 'Nama pelanggan wajib diisi.'); return; }
  const body = { name, phone: val('cf-phone') || null, tier: val('cf-tier') || 'regular', discountPercent: Number(val('cf-disc')) || 0 };
  try {
    if (id) await api('ops/admin/customers/' + id, { method: 'PUT', body });
    else await api('ops/admin/customers', { method: 'POST', body });
    closeModal();
    toast('Berhasil', 'ok', id ? 'Pelanggan diperbarui.' : 'Pelanggan ditambahkan.');
    await renderOperasional();
  } catch (e) { toast('Gagal', 'err', e.message); }
}
window.saveCustomer = saveCustomer;

async function deleteCustomer(id) {
  const c = (OPS_CUSTOMERS || []).find((x) => x.id === id) || {};
  if (!confirm(`Nonaktifkan pelanggan “${c.name || ''}”?`)) return;
  try {
    await api('ops/admin/customers/' + id, { method: 'DELETE' });
    toast('Berhasil', 'ok', 'Pelanggan dinonaktifkan.');
    await renderOperasional();
  } catch (e) { toast('Gagal', 'err', e.message); }
}
window.deleteCustomer = deleteCustomer;

// ---- Pengaturan POS (pajak, split, stok rendah) ----
function openPosSettings() {
  const s = OPS_SETTINGS || {};
  openModal(`
    <h3>Pengaturan POS</h3>
    <div class="ttl" style="margin-bottom:12px">Pajak diterapkan ke total setelah diskon. Split payment memungkinkan bayar multi-metode.</div>
    <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="field"><label>Pajak (%)</label><input id="ps-tax" type="number" min="0" value="${Number(s.taxRate || 0)}"></div>
      <div class="field"><label>Pajak aktif</label><select id="ps-taxon"><option value="true" ${s.taxEnabled ? 'selected' : ''}>Aktif</option><option value="false" ${!s.taxEnabled ? 'selected' : ''}>Nonaktif</option></select></div>
    </div>
    <div class="grid g2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="field"><label>Split payment</label><select id="ps-split"><option value="true" ${s.splitPaymentEnabled !== false ? 'selected' : ''}>Aktif</option><option value="false" ${s.splitPaymentEnabled === false ? 'selected' : ''}>Nonaktif</option></select></div>
      <div class="field"><label>Ambang stok rendah</label><input id="ps-low" type="number" min="0" value="${Number(s.lowStockThreshold || 5)}"></div>
    </div>
    <div class="toolbar" style="justify-content:flex-end;margin-top:14px">
      <button class="btn btn-outline" onclick="closeModal()">Batal</button>
      <button class="btn btn-green" onclick="savePosSettings()">Simpan</button>
    </div>
  `, { wide: true });
}
window.openPosSettings = openPosSettings;

async function savePosSettings() {
  const val = (el) => (($(el) || {}).value || '').trim();
  const body = {
    taxRate: Number(val('ps-tax')) || 0,
    taxEnabled: val('ps-taxon') === 'true',
    splitPaymentEnabled: val('ps-split') !== 'false',
    lowStockThreshold: parseInt(val('ps-low'), 10) || 5,
  };
  try {
    await api('ops/admin/pos/settings', { method: 'PUT', body });
    closeModal();
    toast('Berhasil', 'ok', 'Pengaturan POS disimpan.');
    await renderOperasional();
  } catch (e) { toast('Gagal', 'err', e.message); }
}
window.savePosSettings = savePosSettings;


function opsDriverHtml() {
  if (!OPS_TRIPS.length) return `<div class="card"><div class="empty">Belum ada perjalanan tercatat. Driver membuat perjalanan dari aplikasi Android (tab Operasional → Perjalanan).</div></div>`;
  return `<div class="card"><h3 style="margin-top:0">Pantau Perjalanan Driver (${OPS_TRIPS.length})</h3>
    <div class="table-wrap"><table>
      <thead><tr><th>Kode</th><th>Driver</th><th>Kendaraan</th><th>Tujuan</th><th>Status</th><th>Posisi Terakhir</th><th>Surat Jalan</th><th>Waktu</th></tr></thead>
      <tbody>${OPS_TRIPS.map((t) => `<tr>
        <td><b>${esc(t.code || '-')}</b></td>
        <td><div class="row-user"><span class="avatar" style="width:28px;height:28px;font-size:11px;background:#0B6B2E">${esc((t.driverName || 'D')[0])}</span><b>${esc(t.driverName || '-')}</b></div></td>
        <td>${esc(t.vehicle || '-')}</td>
        <td>${esc(t.destination || '-')}</td>
        <td>${opsBadge(t.status)}</td>
        <td>${t.lastLat != null ? `<a href="https://maps.google.com/?q=${t.lastLat},${t.lastLng}" target="_blank">Buka Peta</a>` : '<span class="ttl">-</span>'}</td>
        <td>${t.noteCount ? `<span class="badge b-blue">${t.noteCount}</span>` : '<span class="ttl">0</span>'}</td>
        <td class="ttl">${esc(hhmm(t.createdAt))} • ${esc(dayLabel((t.createdAt || '').slice(0, 10)))}</td>
      </tr>`).join('')}</tbody>
    </table></div></div>`;
}

function opsNotesHtml() {
  if (!OPS_NOTES.length) return `<div class="card"><div class="empty">Belum ada surat jalan. Driver membuat surat jalan dari aplikasi.</div></div>`;
  return `<div class="card"><h3 style="margin-top:0">Surat Jalan (${OPS_NOTES.length})</h3>
    <div class="table-wrap"><table>
      <thead><tr><th>Kode</th><th>Driver</th><th>Penerima</th><th>Alamat</th><th>Item</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>${OPS_NOTES.map((n) => `<tr>
        <td><b>${esc(n.code || '-')}</b></td>
        <td>${esc(n.driverName || '-')}</td>
        <td>${esc(n.recipientName || '-')}</td>
        <td>${esc(n.address || '-')}</td>
        <td>${n.totalItems}</td>
        <td>${opsBadge(n.status)}</td>
        <td><button class="btn btn-sm btn-ghost" onclick="printDeliveryNote('${n.id}')">Cetak</button></td>
      </tr>`).join('')}</tbody>
    </table></div></div>`;
}

function opsOpnameHtml() {
  if (!OPS_OPNAMES.length) return `<div class="card"><div class="empty">Belum ada sesi opname.</div></div>`;
  return `<div class="card"><h3 style="margin-top:0">Sesi Stock Opname (${OPS_OPNAMES.length})</h3>
    <div class="table-wrap"><table>
      <thead><tr><th>Tanggal</th><th>Petugas</th><th>Jenis</th><th>Area</th><th>Item</th><th>Total Selisih</th><th>Status</th><th>Crosscek Oleh</th><th>Aksi</th></tr></thead>
      <tbody>${OPS_OPNAMES.map((o) => `<tr>
        <td class="ttl">${esc((o.createdAt || '').slice(0, 10))}</td>
        <td><b>${esc(o.employeeName || '-')}</b></td>
        <td><span class="badge ${o.kind === 'KEPALA_GUDANG' ? 'b-purple' : 'b-orange'}">${esc(o.kind === 'KEPALA_GUDANG' ? 'Opname Full' : 'Pramuniaga')}</span></td>
        <td>${esc(o.area || 'Semua')}</td>
        <td>${o.totalItems}</td>
        <td>${o.totalDiff > 0 ? `<b style="color:var(--accent)">${o.totalDiff}</b>` : '<span class="ttl">0</span>'}</td>
        <td>${opsBadge(o.status)}</td>
        <td>${esc(o.reviewedBy || '-')}</td>
        <td><button class="btn btn-sm btn-ghost" onclick="openOpnameDetail('${o.id}', true)">Detail</button></td>
      </tr>`).join('')}</tbody>
    </table></div></div>`;
}

function opsPosHtml() {
  const total = OPS_SALES.reduce((a, b) => a + (b.total || 0), 0);
  const cash = OPS_SALES.filter((s) => s.paymentMethod === 'CASH').reduce((a, b) => a + (b.total || 0), 0);
  const nonCash = total - cash;
  return `
  <div class="kpi-grid">
    <div class="kpi"><b>${rp(total)}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700">Penjualan ${esc(OPS_DATE)}</span><small>${OPS_SALES.length} transaksi</small></div>
    <div class="kpi"><b>${rp(cash)}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700">Tunai</span></div>
    <div class="kpi o"><b>${rp(nonCash)}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700">Non-Tunai</span></div>
    <div class="kpi"><b>${OPS_SESSIONS.filter((s) => s.status === 'OPEN').length}</b><span class="kpi-lb" style="font-size:11.5px;color:var(--mut);font-weight:700">Sesi Terbuka</span></div>
  </div>
  <div class="card"><h3 style="margin-top:0">Transaksi POS (${esc(OPS_DATE)})</h3>
    ${OPS_SALES.length ? `<div class="table-wrap"><table>
      <thead><tr><th>Kode</th><th>Kasir</th><th>Subtotal</th><th>Diskon</th><th>Total</th><th>Pembayaran</th><th>Waktu</th><th>Aksi</th></tr></thead>
      <tbody>${OPS_SALES.map((s) => `<tr>
        <td><b>${esc(s.code || '-')}</b></td>
        <td>${esc(s.cashierName || '-')}</td>
        <td>${rp(s.subtotal)}</td>
        <td>${s.discount ? rp(s.discount) : '<span class="ttl">-</span>'}</td>
        <td><b>${rp(s.total)}</b></td>
        <td><span class="badge ${s.paymentMethod === 'CASH' ? 'b-green' : 'b-blue'}">${s.paymentMethod === 'CASH' ? 'Tunai' : 'Non-Tunai'}</span></td>
        <td class="ttl">${esc(hhmm(s.createdAt))}</td>
        <td><button class="btn btn-sm btn-ghost" onclick="openSaleDetail('${s.id}')">Struk</button></td>
      </tr>`).join('')}</tbody></table></div>` : `<div class="empty">Belum ada transaksi pada tanggal ini.</div>`}
  </div>
  <div class="card"><h3 style="margin-top:0">Sesi Kasir</h3>
    ${OPS_SESSIONS.length ? `<div class="table-wrap"><table>
      <thead><tr><th>Kasir</th><th>Tunai di Laci (akhir)</th><th>Kas Seharusnya</th><th>Selisih</th><th>Status</th><th>Dibuka</th></tr></thead>
      <tbody>${OPS_SESSIONS.map((s) => `<tr>
        <td><b>${esc(s.cashierName || '-')}</b></td>
        <td>${s.closingCash != null ? rp(s.closingCash) : '<span class="ttl">-</span>'}</td>
        <td>${s.expectedCash != null ? rp(s.expectedCash) : '<span class="ttl">-</span>'}</td>
        <td>${s.cashDiff != null ? (Math.abs(s.cashDiff) < 1 ? '<span class="badge b-green">Pas</span>' : `<b style="color:${s.cashDiff < 0 ? 'var(--danger)' : 'var(--accent)'}">${rp(s.cashDiff)}</b>`) : '<span class="ttl">-</span>'}</td>
        <td>${opsBadge(s.status)}</td>
        <td class="ttl">${esc(hhmm(s.openedAt))} • ${esc((s.openedAt || '').slice(0, 10))}</td>
      </tr>`).join('')}</tbody></table></div>` : `<div class="empty">Belum ada sesi kasir.</div>`}
  </div>`;
}

async function openOpnameDetail(id, admin) {
  const base = admin ? 'ops/admin/opnames/' : 'ops/opnames/';
  try {
    const r = await api(base + id);
    const o = r.opname || {}; const items = r.items || [];
    const diffCell = (d) => d === 0 ? '<span class="badge b-green">Pas</span>' : `<b style="color:${d < 0 ? 'var(--danger)' : 'var(--accent)'}">${d > 0 ? '+' : ''}${d}</b>`;
    openModal(`
      <h3>Detail Opname — ${esc(o.employeeName || '-')}</h3>
      <div class="ttl" style="margin-bottom:10px">${esc(o.kind === 'KEPALA_GUDANG' ? 'Opname Full (Kepala Gudang)' : 'Opname Pramuniaga')} • ${esc(o.area || 'Semua area')} • ${esc((o.createdAt || '').replace('T', ' ').slice(0, 16))}</div>
      <div class="table-wrap" style="max-height:46vh;overflow:auto"><table>
        <thead><tr><th>Barang</th><th>Sistem</th><th>Hitungan</th><th>Selisih</th></tr></thead>
        <tbody>${items.map((it) => `<tr><td>${esc(it.productName)}<div class="ttl">${esc(it.sku || '')}</div></td><td>${it.systemStock}</td><td>${it.countedStock}</td><td>${diffCell(it.diff)}</td></tr>`).join('')}</tbody>
      </table></div>
      <div class="toolbar" style="justify-content:flex-end;margin-top:14px"><button class="btn btn-outline" onclick="closeModal()">Tutup</button></div>
    `, { wide: true });
  } catch (e) { toast('Gagal', 'err', e.message); }
}
window.openOpnameDetail = openOpnameDetail;

async function openSaleDetail(id) {
  try {
    const r = await api('ops/admin/pos/sales/' + id);
    const s = r.sale || {}; const items = r.items || [];
    openModal(`
      <h3>Struk ${esc(s.code || '')}</h3>
      <div class="ttl" style="margin-bottom:10px">${esc(s.cashierName || '')} • ${esc((s.createdAt || '').replace('T', ' ').slice(0, 16))}</div>
      <div class="table-wrap"><table>
        <thead><tr><th>Barang</th><th>Harga</th><th>Qty</th><th>Total</th></tr></thead>
        <tbody>${items.map((it) => `<tr><td>${esc(it.productName)}</td><td>${rp(it.price)}</td><td>${it.qty}</td><td>${rp(it.total)}</td></tr>`).join('')}</tbody>
      </table></div>
      <div style="margin-top:12px;text-align:right">
        <div class="ttl">Subtotal: ${rp(s.subtotal)} • Diskon: ${rp(s.discount)}</div>
        <div style="font-size:20px;font-weight:800">${rp(s.total)}</div>
        <div class="ttl">Bayar: ${rp(s.paid)} • Kembali: ${rp(s.change)}</div>
      </div>
      <div class="toolbar" style="justify-content:flex-end;margin-top:14px"><button class="btn btn-outline" onclick="closeModal()">Tutup</button></div>
    `);
  } catch (e) { toast('Gagal', 'err', e.message); }
}
window.openSaleDetail = openSaleDetail;

async function printDeliveryNote(id) {
  try {
    const r = await api('ops/admin/delivery-notes/' + id);
    const n = r.note || {}; const items = r.items || [];
    const w = window.open('', '_blank', 'width=800,height=900');
    if (!w) { toast('Popup Diblokir', 'err', 'Izinkan popup untuk mencetak surat jalan.'); return; }
    w.document.write(`<!DOCTYPE html><html><head><title>Surat Jalan ${esc(n.code || '')}</title>
      <style>body{font-family:'Plus Jakarta Sans',Arial,sans-serif;padding:28px;color:#131A13}h1{font-size:20px;margin:0}
      .hd{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #0B6B2E;padding-bottom:12px;margin-bottom:16px}
      table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #d5ddd2;padding:8px;font-size:13px;text-align:left}
      th{background:#EAF5EC}.meta{margin:6px 0;font-size:13px}.ttl{color:#6C7468;font-size:12px}</style></head><body>
      <div class="hd"><div><h1>Surat Jalan</h1><div class="ttl">No. ${esc(n.code || '')}</div></div>
      <div class="ttl" style="text-align:right">${esc(new Date().toLocaleString('id-ID'))}</div></div>
      <div class="meta"><b>Driver:</b> ${esc(n.driverName || '-')}</div>
      <div class="meta"><b>Tujuan/Perjalanan:</b> ${esc(n.destination || '-')}</div>
      <div class="meta"><b>Kendaraan:</b> ${esc(n.vehicle || '-')}</div>
      <div class="meta"><b>Penerima:</b> ${esc(n.recipientName || '-')}</div>
      <div class="meta"><b>Alamat:</b> ${esc(n.address || '-')}</div>
      <table><thead><tr><th>No</th><th>Barang</th><th>SKU</th><th>Qty</th><th>Satuan</th></tr></thead>
      <tbody>${items.map((it, i) => `<tr><td>${i + 1}</td><td>${esc(it.productName)}</td><td>${esc(it.sku || '')}</td><td>${it.qty}</td><td>${esc(it.unit || 'pcs')}</td></tr>`).join('')}</tbody></table>
      <div style="margin-top:40px;display:flex;justify-content:space-between"><div class="ttl">Pengirim,<br><br><br>______________</div><div class="ttl">Penerima,<br><br><br>______________</div></div>
      </body></html>`);
    w.document.close();
    setTimeout(() => { try { w.focus(); w.print(); } catch (e) { /* ignore */ } }, 350);
  } catch (e) { toast('Gagal', 'err', e.message); }
}
window.printDeliveryNote = printDeliveryNote;

/* ===================== DESAIN APLIKASI (APK) PER LOKASI (B67) =====================
 * Level 1: warna brand + logo + nama tampilan.  Level 2: gambar header/splash/login.
 * Semua diatur dari panel ini, disimpan ke server, dan dibaca oleh APK lewat
 * GET /api/config (blok `theme`) sesuai LOKASI KANTOR karyawan -> tanpa update APK.
 * CATATAN Android: nama & ikon di HOME SCREEN tidak bisa diubah jarak jauh.
 * ------------------------------------------------------------------------------ */
let DS_ITEMS = [];
let DS_LOC = null;              // lokasi yang sedang diedit
let DS_CUR = {};                // nilai efektif (gabungan default + tersimpan)
let DS_DEFAULTS = {};
let DS_PREV_TPL = 'absensi';
const DS_COLOR_KEYS = [
  ['primaryColor', 'Warna Utama (Primary)'],
  ['primaryDarkColor', 'Warna Utama Gelap'],
  ['accentColor', 'Warna Aksen'],
  ['bgColor', 'Latar Belakang'],
  ['surfaceColor', 'Permukaan Kartu'],
  ['textColor', 'Warna Teks'],
  ['mutedColor', 'Teks Sekunder'],
];
const DS_IMG_KEYS = [
  ['logo', 'Logo Utama', 'Tampil di halaman masuk & bilah atas aplikasi (latar terang).'],
  ['logoWhite', 'Logo Versi Putih', 'Untuk latar gelap / header berwarna (opsional).'],
  ['header', 'Gambar Header', 'Bilah atas aplikasi (Level 2). Rasio lebar disarankan 16:9.'],
  ['splash', 'Gambar Splash', 'Tampil saat aplikasi dibuka (Level 2). Rasio kotak/portrait.'],
  ['login', 'Gambar Latar Masuk', 'Latar halaman login (Level 2).'],
];

async function viewDesain() {
  $('top-actions').innerHTML = '';
  $('view').innerHTML = `<div class="card"><div class="section-title"><span class="ic">${ICON.desain || ''}</span> Memuat desain…</div>
    <div class="skeleton" style="height:16px;margin-top:10px"></div><div class="skeleton" style="height:16px;margin-top:8px;width:60%"></div></div>`;
  try {
    const d = await api('admin/branding');
    DS_ITEMS = d.items || d.locations || [];
    DS_DEFAULTS = d.defaults || {};
    if (!DS_ITEMS.length) {
      $('view').innerHTML = `<div class="card"><div class="empty">Belum ada lokasi kantor. Tambahkan lokasi di tab <b>Lokasi Kantor</b> terlebih dahulu.</div></div>`;
      return;
    }
    const want = (DS_LOC && DS_ITEMS.find((x) => x.locationId === DS_LOC)) ? DS_LOC : (DS_ITEMS.find((x) => x.isDefault) || DS_ITEMS[0]).locationId;
    dsSelect(want);
  } catch (err) {
    $('view').innerHTML = `<div class="card"><div class="err-box">${esc(err.message)}</div></div>`;
  }
}
window.viewDesain = viewDesain; window.dsSelect = dsSelect; window.dsLocOptions = dsLocOptions;

function dsSelect(locId) {
  DS_LOC = locId;
  const it = DS_ITEMS.find((x) => x.locationId === locId) || {};
  DS_CUR = Object.assign({}, DS_DEFAULTS, it.effective || {}, (it.branding && it.branding.__noop) || {});
  // Simpan nilai tersimpan (bukan efektif) agar tahu mana yang diwarisi default.
  DS_CUR._saved = it.branding || null;
  renderDesain();
}

function dsLocOptions() {
  return DS_ITEMS.map((l) => `<option value="${l.locationId}"${l.locationId === DS_LOC ? ' selected' : ''}>${esc(l.locationName)}${l.isDefault ? ' (Default)' : ''}</option>`).join('');
}

function renderDesain() {
  const it = DS_ITEMS.find((x) => x.locationId === DS_LOC) || {};
  const saved = it.branding || {};
  const c = DS_CUR;
  const colorRows = DS_COLOR_KEYS.map(([k, label]) => {
    const val = c[k] || '#000000';
    const inherited = !saved[k];
    return `<div class="ds-color">
        <label>${label}${inherited ? ' <span class="badge b-grey">Default</span>' : ''}</label>
        <div class="ds-color-row">
          <input type="color" id="ds-${k}" value="${esc(val)}" oninput="dsColorLive('${k}', this.value)">
          <input type="text" id="ds-${k}-hex" value="${esc(val)}" oninput="dsColorHex('${k}', this.value)" spellcheck="false">
        </div>
      </div>`;
  }).join('');
  const imgRows = DS_IMG_KEYS.map(([k, label, hint]) => {
    const url = dsImageSrc(k);
    return `<div class="ds-img">
        <div class="ds-img-prev" id="ds-prev-${k}">${url ? `<img src="${url}" alt="${esc(label)}">` : `<span class="ds-ph">Belum ada</span>`}</div>
        <div class="ds-img-body">
          <b>${label}</b>
          <div class="ttl">${esc(hint)}</div>
          <div class="ds-img-actions">
            <input id="ds-file-${k}" type="file" accept="image/*" style="display:none" onchange="dsPickImage('${k}', this)">
            <button class="btn btn-sm btn-ghost" type="button" onclick="document.getElementById('ds-file-${k}').click()">Pilih Gambar</button>
            ${url ? `<button class="btn btn-sm btn-danger" type="button" onclick="dsRemoveImage('${k}')">Hapus</button>` : ''}
            ${saved[k] || saved[k + 'Url'] || saved[k + 'Base64'] ? '' : '<span class="badge b-grey">Default</span>'}
          </div>
        </div>
      </div>`;
  }).join('');

  $('view').innerHTML = `
    <div class="card" style="margin-bottom:16px">
      <div class="toolbar" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <h3 style="margin:0">Desain Aplikasi Absen</h3>
          <select id="ds-loc" class="ds-locsel" onchange="dsSelect(this.value)">${dsLocOptions()}</select>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-ghost btn-sm" type="button" onclick="dsResetColors()">Reset Warna ke Default</button>
          <button class="btn btn-primary btn-sm" type="button" onclick="dsSave()">Simpan Desain</button>
        </div>
      </div>
      <div class="ttl" style="margin:-2px 0 12px">Desain ini berlaku untuk karyawan yang ditugaskan ke <b>${esc(it.locationName || '')}</b>.
        Perubahan langsung terlihat di aplikasi karyawan saat mereka membuka aplikasi (tanpa update APK). <b>Nama & ikon di layar utama HP tidak dapat diubah dari sini</b> (batasan Android).</div>
      <div class="ds-cols">
        <div class="ds-form">
          <fieldset class="loc-fieldset"><legend>Identitas</legend>
            <div class="field"><label>Nama Merek (brand)</label><input id="ds-brand" value="${esc(c.brandName || '')}" placeholder="mis. Simaung Corporation"></div>
            <div class="field" style="margin-bottom:0"><label>Nama Tampilan di Aplikasi</label><input id="ds-display" value="${esc(c.displayName || '')}" placeholder="mis. Absensi Cabang Sumedang"></div>
            <div class="field" style="margin:10px 0 0"><label>Slogan / Subjudul</label><input id="ds-tagline" value="${esc(c.tagline || '')}" placeholder="mis. Absensi Karyawan"></div>
          </fieldset>
          <fieldset class="loc-fieldset"><legend>Warna (Level 1)</legend><div class="ds-colors">${colorRows}</div></fieldset>
          <fieldset class="loc-fieldset"><legend>Gambar (Level 2)</legend>${imgRows}</fieldset>
          <div class="pg-actions">
            <button class="btn btn-primary" style="width:auto;padding:12px 26px" type="button" onclick="dsSave()">Simpan Desain</button>
          </div>
        </div>
        <div class="ds-side">
          <div class="section-title"><span class="ic"></span> Pratinjau Aplikasi</div>
          <div id="ds-phone" class="ds-phone">${dsPhoneHTML()}</div>
          <div class="ttl" style="text-align:center;margin-top:10px">Pratinjau perkiraan tampilan di HP karyawan.</div>
        </div>
      </div>
    </div>`;
  dsLive();
}

/* --- Ambil sumber gambar utk 1 field (data URI unggahan menang atas URL) --- */
function dsImageSrc(k) {
  const c = DS_CUR;
  if (k === 'logo') return c.logoBase64 || c.logoUrl || '';
  if (k === 'logoWhite') return c.logoWhiteBase64 || c.logoWhiteUrl || '';
  if (k === 'header') return c.headerImageUrl || '';
  if (k === 'splash') return c.splashImageUrl || '';
  if (k === 'login') return c.loginImageUrl || '';
  return '';
}
function dsSetImage(k, dataUri) {
  if (k === 'logo') { DS_CUR.logoBase64 = dataUri; DS_CUR.logoUrl = null; }
  else if (k === 'logoWhite') { DS_CUR.logoWhiteBase64 = dataUri; DS_CUR.logoWhiteUrl = null; }
  else if (k === 'header') { DS_CUR.headerImageUrl = dataUri; }
  else if (k === 'splash') { DS_CUR.splashImageUrl = dataUri; }
  else if (k === 'login') { DS_CUR.loginImageUrl = dataUri; }
}
function dsClearImage(k) {
  if (k === 'logo') { DS_CUR.logoBase64 = null; DS_CUR.logoUrl = null; }
  else if (k === 'logoWhite') { DS_CUR.logoWhiteBase64 = null; DS_CUR.logoWhiteUrl = null; }
  else if (k === 'header') { DS_CUR.headerImageUrl = null; }
  else if (k === 'splash') { DS_CUR.splashImageUrl = null; }
  else if (k === 'login') { DS_CUR.loginImageUrl = null; }
}

function dsPickImage(k, input) {
  const f = input.files && input.files[0];
  if (!f) return;
  if (!/^image\//.test(f.type)) { toast('Format Tidak Didukung', 'err', 'Pilih berkas gambar (PNG/JPG).'); return; }
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const maxW = k === 'logo' || k === 'logoWhite' ? 512 : 1280;
      const scale = Math.min(1, maxW / img.width);
      const w = Math.max(1, Math.round(img.width * scale)), h = Math.max(1, Math.round(img.height * scale));
      const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
      cv.getContext('2d').drawImage(img, 0, 0, w, h);
      const isLogo = (k === 'logo' || k === 'logoWhite');
      let data = cv.toDataURL(isLogo ? 'image/png' : 'image/jpeg', 0.85);
      if (data.length > 1400000) { data = cv.toDataURL(isLogo ? 'image/png' : 'image/jpeg', 0.6); }
      if (data.length > 1450000) { toast('Gambar Terlalu Besar', 'err', 'Pilih gambar berukuran lebih kecil.'); return; }
      dsSetImage(k, data);
      renderDesain();
      toast('Gambar Dipilih', 'ok', 'Klik "Simpan Desain" untuk menerapkan.');
    };
    img.onerror = () => toast('Gagal', 'err', 'Tidak dapat membaca gambar.');
    img.src = reader.result;
  };
  reader.readAsDataURL(f);
}
window.dsPickImage = dsPickImage;

async function dsRemoveImage(k) {
  const ok = await confirmDialog({
    title: 'Hapus Gambar?', tone: 'danger', icon: 'trash',
    message: 'Gambar ini akan dihapus dari desain lokasi ini (kembali ke bawaan/Default).',
    confirmLabel: 'Ya, Hapus',
  });
  if (!ok) return;
  dsClearImage(k);
  try {
    if (DS_LOC) await api('admin/branding/' + DS_LOC + '/' + k, { method: 'DELETE' });
    const d = await api('admin/branding');
    DS_ITEMS = d.items || []; DS_DEFAULTS = d.defaults || {};
    dsSelect(DS_LOC);
    toast('Gambar Dihapus', 'ok', 'Gambar desain berhasil dihapus.');
  } catch (err) { renderDesain(); toast('Gagal', 'err', err.message); }
}
window.dsRemoveImage = dsRemoveImage;

function dsColorLive(k, v) {
  DS_CUR[k] = String(v).toUpperCase();
  const hex = $('ds-' + k + '-hex'); if (hex) hex.value = DS_CUR[k];
  dsLive();
}
function dsColorHex(k, v) {
  let s = String(v || '').trim();
  if (s && !s.startsWith('#')) s = '#' + s;
  if (!/^#([0-9a-fA-F]{6})$/.test(s)) return;
  DS_CUR[k] = s.toUpperCase();
  const inp = $('ds-' + k); if (inp) inp.value = DS_CUR[k];
  dsLive();
}
window.dsColorLive = dsColorLive; window.dsColorHex = dsColorHex;

function dsResetColors() {
  DS_COLOR_KEYS.forEach(([k]) => { DS_CUR[k] = DS_DEFAULTS[k] || DS_CUR[k]; });
  renderDesain();
  toast('Warna Direset', 'info', 'Warna dikembalikan ke bawaan. Klik "Simpan Desain" untuk menerapkan.');
}
window.dsResetColors = dsResetColors;

function dsPhoneHTML() {
  const c = DS_CUR;
  const logo = dsImageSrc('logo');
  const bg = dsImageSrc('login');
  const brand = c.brandName || 'Simaung Corporation';
  const display = c.displayName || brand;
  const tag = c.tagline || 'Absensi Karyawan';
  const logoHtml = logo ? `<img src="${logo}" alt="logo">` : `<span class="ds-ph">Logo</span>`;
  return `
    <div class="ds-stage" style="background:${esc(c.bgColor || '#FBF7F1')}${bg ? `;background-image:url('${bg}');background-size:cover;background-position:center` : ''}">
      <div class="ds-topbar" style="background:linear-gradient(90deg, ${esc(c.primaryDarkColor || '#0A3D14')}, ${esc(c.primaryColor || '#036D19')})">
        <span class="ds-tb-logo">${logoHtml}</span>
        <span class="ds-tb-tt"><b style="color:#fff">${esc(display)}</b><i style="color:rgba(255,255,255,.8)">${esc(tag)}</i></span>
      </div>
      <div class="ds-accent" style="background:linear-gradient(90deg, ${esc(c.primaryColor || '#036D19')}, ${esc(c.accentColor || '#F85800')})"></div>
      <div class="ds-body">
        <div class="ds-card" style="background:${esc(c.surfaceColor || '#FFFDF9')}">
          <div class="ds-h1" style="color:${esc(c.textColor || '#1A1A1A')}">Selamat pagi 👋</div>
          <div class="ds-h2" style="color:${esc(c.mutedColor || '#6C6C6C')}">${esc(brand)} · ${esc(display)}</div>
          <div class="ds-btn" style="background:${esc(c.primaryColor || '#036D19')}">Absen Masuk</div>
          <div class="ds-btn2" style="color:${esc(c.accentColor || '#F85800')};border-color:${esc(c.accentColor || '#F85800')}">Absen Keluar</div>
        </div>
      </div>
    </div>`;
}
function dsLive() {
  const ph = $('ds-phone');
  if (ph) ph.innerHTML = dsPhoneHTML();
}
window.dsLive = dsLive;

async function dsSave() {
  if (!DS_LOC) return;
  const c = DS_CUR;
  const body = {
    brandName: ($('ds-brand') ? $('ds-brand').value.trim() : (c.brandName || '')),
    displayName: ($('ds-display') ? $('ds-display').value.trim() : (c.displayName || '')),
    tagline: ($('ds-tagline') ? $('ds-tagline').value.trim() : (c.tagline || '')),
  };
  DS_COLOR_KEYS.forEach(([k]) => { if (c[k]) body[k] = c[k]; });
  if (c.logoBase64) body.logoBase64 = c.logoBase64; else if (c.logoUrl) body.logoUrl = c.logoUrl;
  if (c.logoWhiteBase64) body.logoWhiteBase64 = c.logoWhiteBase64; else if (c.logoWhiteUrl) body.logoWhiteUrl = c.logoWhiteUrl;
  if (c.headerImageUrl) body.headerImageUrl = c.headerImageUrl;
  if (c.splashImageUrl) body.splashImageUrl = c.splashImageUrl;
  if (c.loginImageUrl) body.loginImageUrl = c.loginImageUrl;
  try {
    await api('admin/branding/' + DS_LOC, { method: 'PUT', body });
    const d = await api('admin/branding');
    DS_ITEMS = d.items || []; DS_DEFAULTS = d.defaults || {};
    dsSelect(DS_LOC);
    toast('Desain Tersimpan', 'ok', 'Aplikasi karyawan akan memakai desain ini (berlaku saat aplikasi dibuka).');
  } catch (err) { toast('Gagal Menyimpan', 'err', err.message); }
}
window.dsSave = dsSave;


/* ===================== PENGATURAN PER LOKASI (B75) =====================
 * Bagian dari tab SHIFT & JADWAL. Mengatur pengaturan operasional per LOKASI
 * KANTOR: toleransi telat, zona waktu, drift GPS, akurasi GPS. Kosong = warisi
 * pengaturan Perusahaan. Juga menerapkan shift default ke seluruh karyawan
 * cabang sekaligus. Dipakai APK lewat GET /api/config.
 * --------------------------------------------------------------------- */
let LS_ITEMS = [];    // ringkasan lokasi dari admin/location-setup
const LS_TZ = ['Asia/Jakarta', 'Asia/Makassar', 'Asia/Jayapura', 'Asia/Pontianak', 'Asia/Singapore'];

async function lsReload() {
  try {
    const d = await api('admin/location-setup');
    LS_ITEMS = d.items || d.locations || [];
    renderLocationSettingsSection();
  } catch (err) {
    const el = $('loc-settings-section');
    if (el) el.innerHTML = `<div class="err-box">Gagal memuat pengaturan lokasi: ${esc(err.message)}</div>`;
  }
}
window.lsReload = lsReload;

function lsTzOptions(cur) {
  const list = LS_TZ.concat(cur ? [cur] : []).filter((v, i, a) => v && a.indexOf(v) === i);
  return list.map((t) => `<option value="${t}"${t === cur ? ' selected' : ''}>${t}</option>`).join('');
}

function renderLocationSettingsSection() {
  const host = $('loc-settings-section');
  if (!host) return;
  if (!LS_ITEMS.length) {
    host.innerHTML = `<div class="card"><div class="empty">Belum ada lokasi kantor. Tambahkan lokasi di tab <b>Lokasi Kantor</b> untuk mengatur pengaturan per cabang.</div></div>`;
    return;
  }
  const cards = LS_ITEMS.map((it) => {
    const o = it.overrides || {};
    const hasOverride = !!(o.lateGraceMinutes || o.timezone || o.gpsDriftToleranceMeters || o.minimumAccuracyMeters);
    const applyOpts = (SHIFTS || []).length
      ? SHIFTS.map((s) => `<option value="${s.id}">${esc(s.name)} (${esc(s.startTime)}-${esc(s.endTime)})${s.officeLocationId === it.locationId ? ' • shift lokasi ini' : ''}</option>`).join('')
      : '<option value="">— belum ada shift —</option>';
    return `<div class="card" style="margin-bottom:14px">
      <div class="section-title" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <span style="display:flex;align-items:center;gap:9px"><span class="ic">${I.building}</span> ${esc(it.locationName)} ${it.isDefault ? '<span class="badge b-blue">Default</span>' : ''}${hasOverride ? '<span class="badge b-green">Pengaturan Khusus</span>' : '<span class="badge b-grey">Bawaan Perusahaan</span>'}</span>
        <span class="badge b-blue">${it.shiftCount} shift • ${it.employeeCount} karyawan</span>
      </div>
      <div class="ttl" style="margin:-4px 0 12px">${esc(it.address || '—')} • Radius absen ${Math.round(it.radiusMeters)} m</div>

      <fieldset class="loc-fieldset">
        <legend>Pengaturan Operasional Cabang</legend>
        <div class="grid g2">
          <div class="field">
            <label style="display:flex;align-items:center;gap:8px;font-weight:700">
              <input type="checkbox" id="ls-grace-on-${it.locationId}" style="width:auto" ${o.lateGraceMinutes ? 'checked' : ''} onchange="lsToggle('${it.locationId}')">
              Toleransi Keterlambatan (menit)
            </label>
            <input type="number" min="0" max="120" id="ls-grace-${it.locationId}" value="${it.lateGraceMinutes}" ${o.lateGraceMinutes ? '' : 'disabled'}>
          </div>
          <div class="field">
            <label style="display:flex;align-items:center;gap:8px;font-weight:700">
              <input type="checkbox" id="ls-tz-on-${it.locationId}" style="width:auto" ${o.timezone ? 'checked' : ''} onchange="lsToggle('${it.locationId}')">
              Zona Waktu
            </label>
            <select id="ls-tz-${it.locationId}" ${o.timezone ? '' : 'disabled'}>${lsTzOptions(it.timezone)}</select>
          </div>
          <div class="field">
            <label style="display:flex;align-items:center;gap:8px;font-weight:700">
              <input type="checkbox" id="ls-drift-on-${it.locationId}" style="width:auto" ${o.gpsDriftToleranceMeters ? 'checked' : ''} onchange="lsToggle('${it.locationId}')">
              Toleransi Drift GPS (meter)
            </label>
            <input type="number" min="0" max="300" id="ls-drift-${it.locationId}" value="${it.gpsDriftToleranceMeters}" ${o.gpsDriftToleranceMeters ? '' : 'disabled'}>
          </div>
          <div class="field">
            <label style="display:flex;align-items:center;gap:8px;font-weight:700">
              <input type="checkbox" id="ls-acc-on-${it.locationId}" style="width:auto" ${o.minimumAccuracyMeters ? 'checked' : ''} onchange="lsToggle('${it.locationId}')">
              Akurasi GPS Maksimum (meter)
            </label>
            <input type="number" min="10" max="300" id="ls-acc-${it.locationId}" value="${it.minimumAccuracyMeters}" ${o.minimumAccuracyMeters ? '' : 'disabled'}>
          </div>
        </div>
        <div class="ttl">Centang untuk mengatur nilai khusus cabang ini. Bila tidak dicentang, cabang memakai pengaturan <b>Perusahaan</b>.</div>
      </fieldset>

      <fieldset class="loc-fieldset">
        <legend>Shift Default Cabang</legend>
        <div class="ttl" style="margin-bottom:8px">Terapkan satu shift sebagai default ke seluruh karyawan aktif di cabang ini sekaligus. Jadwal harian yang sudah diatur tetap dihormati.</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
          <select id="ls-applyshift-${it.locationId}" style="flex:1;min-width:200px">${applyOpts}</select>
          <button class="btn btn-orange" style="width:auto" type="button" onclick="lsApplyShift('${it.locationId}')">Terapkan ke Karyawan</button>
        </div>
      </fieldset>

      <div class="pg-actions" style="margin-top:6px">
        <button class="btn btn-primary" style="width:auto;padding:12px 26px" type="button" onclick="lsSave('${it.locationId}')">Simpan Pengaturan</button>
        ${hasOverride ? `<button class="btn btn-ghost" style="width:auto;padding:12px 22px" type="button" onclick="lsReset('${it.locationId}')">Kembalikan ke Bawaan</button>` : ''}
      </div>
    </div>`;
  }).join('');
  host.innerHTML = `<div class="card" style="margin-bottom:14px">
      <div class="section-title"><span class="ic">${I.building}</span> Pengaturan per Lokasi Kantor</div>
      <div class="ttl" style="margin:-4px 0 6px"><b>Shift &amp; jadwal mengikuti lokasi kantor.</b> Atur jam kerja tiap shift (tabel di atas), lalu tetapkan pengaturan operasional tiap cabang di bawah ini. Semua berlaku langsung di aplikasi karyawan tanpa update APK.</div>
      <div class="ttl">Jumlah lokasi: <b>${LS_ITEMS.length}</b> • total karyawan aktif: <b>${LS_ITEMS.reduce((a, x) => a + (x.employeeCount || 0), 0)}</b></div>
    </div>${cards}`;
}

function lsToggle(locId) {
  const pairs = [['ls-grace-on-', 'ls-grace-'], ['ls-tz-on-', 'ls-tz-'], ['ls-drift-on-', 'ls-drift-'], ['ls-acc-on-', 'ls-acc-']];
  pairs.forEach(([cb, inp]) => {
    const c = $(cb + locId), f = $(inp + locId);
    if (c && f) f.disabled = !c.checked;
  });
}
window.lsToggle = lsToggle;

async function lsSave(locId) {
  const val = (onId, inId) => { const c = $(onId + locId); return (c && c.checked) ? $(inId + locId).value : null; };
  const body = {
    lateGraceMinutes: val('ls-grace-on-', 'ls-grace-'),
    timezone: val('ls-tz-on-', 'ls-tz-'),
    gpsDriftToleranceMeters: val('ls-drift-on-', 'ls-drift-'),
    minimumAccuracyMeters: val('ls-acc-on-', 'ls-acc-'),
  };
  try {
    await api('admin/location-settings/' + locId, { method: 'PUT', body });
    toast('Pengaturan Tersimpan', 'ok', 'Pengaturan lokasi berhasil disimpan & berlaku di aplikasi karyawan.');
    await lsReload();
  } catch (err) { toast('Gagal Menyimpan', 'err', err.message); }
}
window.lsSave = lsSave;

async function lsReset(locId) {
  const ok = await confirmDialog({
    title: 'Kembalikan ke Bawaan', icon: 'trash', tone: 'danger',
    message: 'Pengaturan khusus lokasi ini akan dihapus. Cabang akan memakai pengaturan Perusahaan.',
    confirmLabel: 'Kembalikan',
  });
  if (!ok) return;
  try {
    await api('admin/location-settings/' + locId, { method: 'DELETE' });
    toast('Dikembalikan', 'ok', 'Lokasi kembali memakai pengaturan Perusahaan.');
    await lsReload();
  } catch (err) { toast('Gagal', 'err', err.message); }
}
window.lsReset = lsReset;

async function lsApplyShift(locId) {
  const sel = $('ls-applyshift-' + locId);
  const shiftId = sel ? sel.value : '';
  if (!shiftId) { toast('Pilih shift terlebih dahulu', 'err'); return; }
  const it = LS_ITEMS.find((x) => x.locationId === locId) || {};
  const ok = await confirmDialog({
    title: 'Terapkan Shift Default', icon: 'shift', tone: 'info',
    html: `<p>Terapkan shift default ke <b>seluruh karyawan aktif</b> di <b>${esc(it.locationName || 'lokasi ini')}</b> (${it.employeeCount || 0} karyawan)?</p>` +
      `<div class="dialog-note">${DIALOG_ICONS.shift || ''}<span>Shift default karyawan di cabang ini akan <b>ditimpa</b>. Jadwal harian yang sudah diatur tidak berubah.</span></div>`,
    confirmLabel: 'Terapkan',
  });
  if (!ok) return;
  try {
    const r = await api('admin/location-setup/' + locId + '/apply', { method: 'POST', body: { defaultShiftId: shiftId } });
    toast('Shift Diterapkan', 'ok', (r && r.message) ? r.message : 'Shift default diterapkan.');
  } catch (err) { toast('Gagal Menerapkan', 'err', err.message); }
}
window.lsApplyShift = lsApplyShift;
