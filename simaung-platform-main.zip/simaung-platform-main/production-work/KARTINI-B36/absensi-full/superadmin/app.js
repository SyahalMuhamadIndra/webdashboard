/* Simaung Corporation Superadmin — app.js  (v2.0) */

// ============ CONFIG ============
const API = ((window.__API_BASE__ || 'https://api.simaung.com/api/').replace(/\/+$/, '')) + '/';

// ============ STATE ============
const S = {
  token: localStorage.getItem('tk_admin_token') || null,
  admin: null,
  tab: 'dashboard',
  toastTimer: null,
  demo: false,
  pending: null,
};

// ============ HELPERS ============
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const TOAST_ICONS = {
  ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>',
  err: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v4M12 16h.01"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/></svg>',
};

/**
 * Notifikasi layang (toast) profesional: kartu putih dengan ikon status,
 * aksen warna, judul, pesan pendukung, tombol tutup, dan bilah durasi.
 * @param {string} title judul singkat
 * @param {'ok'|'err'|'info'} [kind] jenis (warna + ikon)
 * @param {string} [message] pesan pendukung (opsional)
 */
function toast(title, kind, message) {
  const el = $('toast');
  if (!el) return;
  const k = (kind === 'ok' || kind === 'err' || kind === 'info') ? kind : 'info';
  clearTimeout(S.toastTimer);
  const msgHtml = message ? `<div class="toast-msg">${esc(message)}</div>` : '';
  el.innerHTML =
    `<div class="toast-card ${k}" role="status" aria-live="polite">` +
      `<span class="toast-accent"></span>` +
      `<span class="toast-ic">${TOAST_ICONS[k]}</span>` +
      `<div class="toast-body">` +
        `<div class="toast-title">${esc(title)}</div>${msgHtml}` +
      `</div>` +
      `<button class="toast-x" type="button" aria-label="Tutup">&times;</button>` +
      `<span class="toast-bar"></span>` +
    `</div>`;
  const card = el.querySelector('.toast-card');
  const close = () => { if (!card) return; card.classList.add('out'); clearTimeout(S.toastTimer); S.toastTimer = setTimeout(() => { el.innerHTML = ''; }, 220); };
  el.querySelector('.toast-x')?.addEventListener('click', close);
  S.toastTimer = setTimeout(close, 4200);
}

const DIALOG_ICONS = {
  question: TOAST_ICONS.info,
  info: TOAST_ICONS.info,
  reset: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2"/><path d="M7.6 13.4a5 5 0 1 0 3 3l1.2-1.2"/><circle cx="5" cy="19" r="2.6"/><path d="M13 10l6.5-6.5"/></svg>',
  trash: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>',
  power: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><path d="M12 2v10"/></svg>',
  protect: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.4 8.4-8 10-4.6-1.6-8-5-8-10V6z"/><path d="M9.5 12l1.8 1.8L15 10"/></svg>',
  shift: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M12 6v6l4 2"/><circle cx="12" cy="12" r="9"/></svg>',
  calendar: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/><path d="M9 15l2 2 4-4"/></svg>',
};

/**
 * Dialog konfirmasi kustom yang elegan & profesional — pengganti window.confirm()
 * bawaan browser (yang tampilannya kasar/tidak konsisten).
 * Mengembalikan Promise<boolean>: true bila dikonfirmasi, false bila dibatalkan.
 *
 * @param {{title:string, message?:string, html?:string, confirmLabel?:string,
 *   cancelLabel?:string, tone?:'brand'|'danger'|'warn', icon?:string}} opts
 */
function confirmDialog(opts) {
  const o = opts || {};
  const tone = (o.tone === 'danger' || o.tone === 'warn') ? o.tone : 'brand';
  const icon = DIALOG_ICONS[o.icon] || DIALOG_ICONS.question;
  const bodyHtml = o.html
    ? o.html
    : (o.message ? esc(o.message).replace(/\n/g, '<br>') : '');
  const confirmLabel = o.confirmLabel || 'Ya, Lanjutkan';
  const cancelLabel = o.cancelLabel || 'Batal';

  return new Promise((resolve) => {
    const bg = document.createElement('div');
    bg.className = 'dialog-bg';
    bg.innerHTML =
      `<div class="dialog tone-${tone}" role="alertdialog" aria-modal="true">` +
        `<span class="dialog-accent"></span>` +
        `<button class="dialog-x" type="button" aria-label="Tutup">&times;</button>` +
        `<div class="dialog-head">` +
          `<span class="dialog-ic">${icon}</span>` +
          `<div class="dialog-tt">` +
            `<h3>${esc(o.title || 'Konfirmasi')}</h3>` +
            (o.subtitle ? `<p>${esc(o.subtitle)}</p>` : '') +
          `</div>` +
        `</div>` +
        (bodyHtml ? `<div class="dialog-body">${bodyHtml}</div>` : '') +
        `<div class="dialog-actions">` +
          `<button class="btn btn-ghost" type="button" data-act="cancel">${esc(cancelLabel)}</button>` +
          `<button class="btn btn-${tone === 'brand' ? 'primary' : (tone === 'danger' ? 'danger' : 'orange')}" type="button" data-act="ok">${esc(confirmLabel)}</button>` +
        `</div>` +
      `</div>`;

    let done = false;
    const close = (val) => {
      if (done) return;
      done = true;
      document.removeEventListener('keydown', onKey);
      bg.classList.add('out');
      setTimeout(() => bg.remove(), 180);
      resolve(val);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); close(false); }
      else if (e.key === 'Enter') { e.preventDefault(); close(true); }
    };

    bg.addEventListener('click', (e) => { if (e.target === bg) close(false); });
    bg.querySelector('.dialog-x')?.addEventListener('click', () => close(false));
    bg.querySelector('[data-act="cancel"]')?.addEventListener('click', () => close(false));
    bg.querySelector('[data-act="ok"]')?.addEventListener('click', () => close(true));
    document.addEventListener('keydown', onKey);

    document.body.appendChild(bg);
    requestAnimationFrame(() => {
      bg.classList.add('show');
      bg.querySelector('[data-act="ok"]')?.focus();
    });
  });
}
window.confirmDialog = confirmDialog;

/**
 * Dialog input kustom yang elegan — pengganti window.prompt() bawaan browser.
 * Mengembalikan Promise<string|null>: string (boleh kosong) bila dikonfirmasi,
 * null bila dibatalkan.
 *
 * @param {{title:string, subtitle?:string, html?:string, label?:string,
 *   placeholder?:string, tone?:'brand'|'warn'|'danger', icon?:string,
 *   confirmLabel?:string, cancelLabel?:string, required?:boolean}} opts
 */
function promptDialog(opts) {
  const o = opts || {};
  const tone = (o.tone === 'danger' || o.tone === 'warn') ? o.tone : 'brand';
  const icon = DIALOG_ICONS[o.icon] || DIALOG_ICONS.info;
  const confirmLabel = o.confirmLabel || 'Simpan';
  const cancelLabel = o.cancelLabel || 'Batal';
  const label = o.label || 'Catatan (opsional)';

  return new Promise((resolve) => {
    const bg = document.createElement('div');
    bg.className = 'dialog-bg';
    bg.innerHTML =
      `<div class="dialog tone-${tone}" role="dialog" aria-modal="true">` +
        `<span class="dialog-accent"></span>` +
        `<button class="dialog-x" type="button" aria-label="Tutup">&times;</button>` +
        `<div class="dialog-head">` +
          `<span class="dialog-ic">${icon}</span>` +
          `<div class="dialog-tt"><h3>${esc(o.title || 'Masukkan Catatan')}</h3>` +
          (o.subtitle ? `<p>${esc(o.subtitle)}</p>` : '') + `</div>` +
        `</div>` +
        (o.html ? `<div class="dialog-body">${o.html}</div>` : '') +
        `<div class="field" style="margin-top:14px"><label>${esc(label)}</label>` +
          `<textarea class="dlg-input" rows="3" placeholder="${esc(o.placeholder || 'Tulis catatan di sini…')}"></textarea>` +
        `</div>` +
        `<div class="dialog-actions">` +
          `<button class="btn btn-ghost" type="button" data-act="cancel">${esc(cancelLabel)}</button>` +
          `<button class="btn btn-${tone === 'brand' ? 'primary' : (tone === 'danger' ? 'danger' : 'orange')}" type="button" data-act="ok">${esc(confirmLabel)}</button>` +
        `</div>` +
      `</div>`;

    let done = false;
    const ta = bg.querySelector('.dlg-input');
    const close = (val) => {
      if (done) return;
      done = true;
      document.removeEventListener('keydown', onKey);
      bg.classList.add('out');
      setTimeout(() => bg.remove(), 180);
      resolve(val);
    };
    const submit = () => {
      const v = (ta.value || '').trim();
      if (o.required && !v) {
        ta.classList.add('invalid');
        ta.focus();
        return;
      }
      close(v);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); close(null); }
      else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); submit(); }
    };

    bg.addEventListener('click', (e) => { if (e.target === bg) close(null); });
    bg.querySelector('.dialog-x')?.addEventListener('click', () => close(null));
    bg.querySelector('[data-act="cancel"]')?.addEventListener('click', () => close(null));
    bg.querySelector('[data-act="ok"]')?.addEventListener('click', submit);
    document.addEventListener('keydown', onKey);

    document.body.appendChild(bg);
    requestAnimationFrame(() => { bg.classList.add('show'); ta?.focus(); });
  });
}
window.promptDialog = promptDialog;

function isDemo() { return S.demo || (window.MOCKAPI && window.MOCKAPI.isDemo()); }

async function api(path, { method = 'GET', body, auth = true } = {}) {
  // Mode pratinjau (data contoh) — tidak menyentuh server.
  if (isDemo()) return window.MOCKAPI.route(path, { method, body });
  // Cache-buster HANYA ditambahkan pada GET tanpa query, agar Vercel/CDN tidak
  // menyajikan balasan basi. PENTING: bila path sudah punya query (mis.
  // "admin/schedule?weekStart=..." atau "admin/attendance?date=..."), cukup
  // tambahkan parameter netral "&_ts=" — JANGAN menambahkan "?" lagi karena
  // akan merusak query (menyebabkan "Cannot GET").
  let finalPath = path;
  if (method === 'GET') {
    const bust = '_ts=' + Date.now();
    finalPath = path.includes('?') ? (path + '&' + bust) : (path + '?' + bust);
  }
  const headers = { 'Accept': 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth && S.token) headers['Authorization'] = 'Bearer ' + S.token;
  let res, raw;
  try {
    res = await fetch(API + finalPath, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  } catch (e) {
    throw new Error('Tidak dapat menghubungi server. Periksa koneksi internet.');
  }
  raw = await res.text();
  let data = {};
  try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message: raw }; }
  if (!res.ok) {
    if (res.status === 401 && auth) { logout(); throw new Error(data.message || 'Sesi berakhir, silakan login ulang'); }
    throw new Error(data.message || ('HTTP ' + res.status));
  }
  return data;
}

// ============ FORMAT ============
function initials(name) {
  const p = String(name || '?').trim().split(/\s+/);
  return ((p[0]?.[0] || '?') + (p[1]?.[0] || '')).toUpperCase();
}
function hhmm(iso) {
  if (!iso) return '--:--';
  const d = new Date(iso);
  if (isNaN(d)) return '--:--';
  return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
}
function dayLabel(isoDate) {
  if (!isoDate) return '-';
  const d = new Date(isoDate + 'T00:00:00');
  if (isNaN(d)) return isoDate;
  return d.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}
function durLabel(mins) {
  if (mins == null) return '-';
  const h = Math.floor(mins / 60), m = mins % 60;
  return h > 0 ? `${h}j ${m}m` : `${m}m`;
}
function todayISO() {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}
function colorOf(emp) { return emp.avatarColor || '#0B6B2E'; }

/* Avatar karyawan: pakai FOTO PROFIL bila ada, jika tidak pakai inisial + warna. */
function avatarHtml(emp, size) {
  const s = size || 34;
  const photo = emp && emp.photoBase64;
  if (photo) {
    const src = photo.startsWith('data:') ? photo : ('data:image/jpeg;base64,' + photo);
    const style = `width:${s}px;height:${s}px;`;
    return `<span class="avatar avatar-photo" style="${style}"><img src="${src}" alt="${esc(initials(emp.fullName))}" loading="lazy"></span>`;
  }
  const style = `background:${colorOf(emp)};` + (size ? `width:${s}px;height:${s}px;font-size:${Math.max(10, Math.round(s * 0.38))}px;` : '');
  return `<span class="avatar" style="${style}">${esc(initials(emp && emp.fullName))}</span>`;
}

// ============ AUTH ============
function logout() {
  S.token = null; S.admin = null; S.demo = false; S.pending = null;
  if (window.MOCKAPI) window.MOCKAPI.disable();
  stopPolling();
  localStorage.removeItem('tk_admin_token');
  renderLogin();
}

async function doLogin(e) {
  e.preventDefault();
  const email = $('lg-email').value.trim();
  const password = $('lg-pass').value;
  const btn = $('lg-btn');
  $('lg-err').innerHTML = '';
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Masuk...';
  try {
    const r = await api('admin/login', { method: 'POST', auth: false, body: { email, password } });
    S.token = r.token;
    S.admin = r;
    localStorage.setItem('tk_admin_token', r.token);
    S.tab = (String(r.role || '').toUpperCase() === 'DEV') ? 'update' : 'dashboard';
    await boot();
  } catch (err) {
    $('lg-err').innerHTML = `<div class="err-box">${esc(err.message)}</div>`;
  } finally {
    btn.disabled = false; btn.textContent = 'Masuk';
  }
}

function enterDemo() {
  S.demo = true;
  if (window.MOCKAPI) window.MOCKAPI.enable();
  S.admin = { name: 'Super Admin (Pratinjau)', email: 'admin@tokokartini.com' };
  S.tab = 'dashboard';
  renderShell();
  startPolling();
  toast('Mode pratinjau: menggunakan data contoh', 'ok');
}
window.enterDemo = enterDemo;

function renderLogin() {
  document.body.className = '';
  $('app').innerHTML = `
    <div class="login-wrap">
      <form class="login-card" onsubmit="doLogin(event)">
        <div class="login-logo"><img src="assets/logo.png" alt="Logo Simaung Corporation"></div>
        <h1>Superadmin Simaung Corporation</h1>
        <p class="sub">Panel pengaturan absensi</p>
        <div id="lg-err"></div>
        <div class="field">
          <label>Email Admin</label>
          <input id="lg-email" type="email" placeholder="Masukkan email admin" autocomplete="off" required>
        </div>
        <div class="field">
          <label>Password</label>
          <input id="lg-pass" type="password" placeholder="Masukkan password" autocomplete="new-password" required>
        </div>
        <button id="lg-btn" class="btn btn-primary btn-block" type="submit">Masuk</button>
        <button type="button" class="btn btn-outline btn-block" style="margin-top:10px" onclick="enterDemo()">Lihat Pratinjau (Data Contoh)</button>
      </form>
    </div>`;
}

// ============ SHELL ============
const ICON = {
  dashboard: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1.8"/><rect x="14" y="3" width="7" height="5" rx="1.8"/><rect x="14" y="12" width="7" height="9" rx="1.8"/><rect x="3" y="16" width="7" height="5" rx="1.8"/></svg>',
  lokasi: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/></svg>',
  karyawan: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="3.5"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  laporan: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 14l3.5-4 3 2.5L20 6"/></svg>',
  shift: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>',
  izin: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h6M9 17h4"/></svg>',
  update: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M5 21h14"/></svg>',
  lembur: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8v4l3 2"/><circle cx="12" cy="12" r="9"/><path d="M12 3v2M21 12h-2M12 21v-2M3 12h2"/></svg>',
  system: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2.4"/><path d="M9 9h6v6H9z"/><path d="M9 2v2M15 2v2M9 20v2M15 20v2M2 9h2M2 15h2M20 9h2M20 15h2"/></svg>',
  audit: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h.01M12.5 13h.01M16 13h.01M9 17h.01M12.5 17h.01"/></svg>',
  broadcast: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10v4a1 1 0 0 0 1 1h2l4 4V5L6 9H4a1 1 0 0 0-1 1z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 6a9 9 0 0 1 0 12"/></svg>',
  devices: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2" width="12" height="20" rx="2.4"/><path d="M11 18h2"/></svg>',
  flags: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 21V4"/><path d="M4 5h11l-1.5 3L15 11H4z"/></svg>',
  hr: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><circle cx="9" cy="8" r="2.4"/><path d="M5.5 20a3.5 3.5 0 0 1 7 0"/><path d="M14.5 10.5l2.5 2.5 4-4"/></svg>',
  pengguna: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l7 3v6c0 4.5-3 7.7-7 9-4-1.3-7-4.5-7-9V5z"/><circle cx="12" cy="10" r="2.2"/><path d="M8.5 16a3.5 3.5 0 0 1 7 0"/></svg>',
  pengaturan: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  konsol: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2.4"/><path d="M7 9l3 3-3 3"/><path d="M13 15h4"/></svg>',
  operasional: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-6 9 6"/><path d="M5 9v10h14V9"/><rect x="9" y="13" width="6" height="6" rx="1"/></svg>',
  keluhan: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 9h8M8 13h5"/></svg>',
  desain: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a9 9 0 1 0 0 18c1.1 0 2-.9 2-2 0-.5-.2-.9-.5-1.3-.3-.4-.5-.8-.5-1.2 0-1.1.9-2 2-2h2.4A4.6 4.6 0 0 0 22 9.9C22 6.1 17.5 3 12 3z"/><circle cx="7.5" cy="10.5" r="1.2" fill="currentColor" stroke="none"/><circle cx="12" cy="7.5" r="1.2" fill="currentColor" stroke="none"/><circle cx="16.5" cy="10.5" r="1.2" fill="currentColor" stroke="none"/></svg>',
  setuplokasi: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>',
};
const TABS = [
  { id: 'dashboard', label: 'Dashboard', short: 'Dashboard', title: 'Dashboard', sub: 'Ringkasan HR & absensi harian karyawan' },
  { id: 'lokasi', label: 'Lokasi Kantor', short: 'Lokasi', title: 'Lokasi Kantor', sub: 'Atur titik kantor, radius, dan akurasi GPS' },
  { id: 'desain', label: 'Desain Aplikasi (APK)', short: 'Desain', title: 'Desain Aplikasi (APK)', sub: 'Warna, logo & gambar aplikasi absen — per lokasi kantor, tanpa update APK' },
  { id: 'pengaturan', label: 'Pengaturan Perusahaan', short: 'Pengaturan', title: 'Pengaturan Perusahaan', sub: 'Profil perusahaan, toleransi keterlambatan & logo' },
  { id: 'karyawan', label: 'Karyawan', short: 'Karyawan', title: 'Akun Karyawan', sub: 'Tambah & kelola akun karyawan' },
  { id: 'pengguna', label: 'Pengguna & Akses', short: 'Pengguna', title: 'Pengguna & Akses', sub: 'Kelola akun admin/operator dan perannya (RBAC)' },
  { id: 'izin', label: 'Izin', short: 'Izin', title: 'Persetujuan Izin', sub: 'Setujui / tolak pengajuan izin karyawan' },
  { id: 'lembur', label: 'Lembur', short: 'Lembur', title: 'Persetujuan Lembur', sub: 'Setujui / tolak pengajuan lembur karyawan' },
  { id: 'laporan', label: 'Laporan', short: 'Laporan', title: 'Laporan', sub: 'Ringkasan kehadiran & lembur per karyawan' },
  { id: 'shift', label: 'Shift & Jadwal', short: 'Shift', title: 'Shift & Jadwal', sub: 'Atur shift kerja dan jadwal karyawan' },
  { id: 'keluhan', label: 'Keluhan Karyawan', short: 'Keluhan', title: 'Keluhan Karyawan', sub: 'Keluhan & saran dari karyawan (via tokokartini.com)' },
  { id: 'operasional', label: 'Operasional', short: 'Operasional', title: 'Operasional Toko', sub: 'Driver, surat jalan, stock opname & POS kasir (peran jabatan karyawan)' },
  { id: 'update', label: 'Update Aplikasi', short: 'Update', title: 'Update Aplikasi', sub: 'Publikasikan versi APK terbaru ke karyawan' },
  { id: 'system', label: 'Dashboard Sistem', short: 'Sistem', title: 'Dashboard Sistem', sub: 'Status server, basis data & statistik toko' },
  { id: 'konsol', label: 'Konsol Developer', short: 'Konsol', title: 'Konsol Developer', sub: 'Diagnostik, imitasi karyawan, perbaikan data & audit lanjutan' },
  { id: 'audit', label: 'Log Aktivitas', short: 'Log', title: 'Log Aktivitas', sub: 'Riwayat aksi admin & developer' },
  { id: 'broadcast', label: 'Pengumuman', short: 'Umum', title: 'Broadcast Pengumuman', sub: 'Kirim pengumuman ke seluruh karyawan' },
  { id: 'devices', label: 'Perangkat', short: 'Device', title: 'Manajemen Perangkat', sub: 'Kelola perangkat yang terdaftar' },
  { id: 'flags', label: 'Fitur App (Remote Config)', short: 'Fitur', title: 'Feature Flags / Remote Config', sub: 'Nyalakan/matikan fitur tanpa rilis APK' },
];

// Akun DEV melihat tab "Update Aplikasi" + seluruh Alat Developer; superadmin
// melihat semua KECUALI tab-tab developer. Tab "Pengguna & Akses" (B6) tampil
// untuk KEDUA peran karena keduanya boleh mengelola pengguna.
const DEV_ROLE = 'DEV';
const DEV_TABS = ['update', 'system', 'audit', 'broadcast', 'devices', 'flags', 'konsol'];
const SHARED_TABS = ['pengguna'];
function isDev() { return !!(S.admin && String(S.admin.role || '').toUpperCase() === DEV_ROLE); }
function visibleTabs() {
  return isDev()
    ? TABS.filter((x) => DEV_TABS.includes(x.id) || SHARED_TABS.includes(x.id))
    : TABS.filter((x) => !DEV_TABS.includes(x.id));
}

// ============ NOTIFIKASI REALTIME (badge jumlah pengajuan) ============
// S.pending = { leaves, overtimes, total } — disegarkan berkala.
function badgeFor(tabId) {
  if (!S.pending) return '';
  const n = tabId === 'lembur' ? S.pending.overtimes : tabId === 'izin' ? S.pending.leaves : tabId === 'keluhan' ? (S.pending.complaints || 0) : 0;
  return n > 0 ? `<span class="nav-badge">${n > 99 ? '99+' : n}</span>` : '';
}
function refreshBadges() {
  const map = { izin: S.pending ? S.pending.leaves : 0, lembur: S.pending ? S.pending.overtimes : 0, keluhan: S.pending ? (S.pending.complaints || 0) : 0 };
  ['izin', 'lembur', 'keluhan'].forEach((id) => {
    document.querySelectorAll(`[data-tab="${id}"] .nav-badge`).forEach((el) => {
      const n = map[id] || 0;
      el.textContent = n > 99 ? '99+' : String(n);
      el.style.display = n > 0 ? '' : 'none';
    });
  });
}
async function pollPending() {
  if (!S.token && !isDemo()) return;
  if (!S.admin) return;
  try {
    const r = await api('admin/pending-counts');
    const prev = S.pending;
    S.pending = r;
    refreshBadges();
    // Notifikasi lonjakan (pengajuan baru masuk) -> toast realtime.
    if (prev) {
      if (r.leaves > prev.leaves) toast(`Pengajuan izin baru (${r.leaves} menunggu)`, 'ok');
      if (r.overtimes > prev.overtimes) toast(`Pengajuan lembur baru (${r.overtimes} menunggu)`, 'ok');
    }
  } catch (e) { /* diamkan bila jaringan bermasalah */ }
}
let _pollTimer = null;
function startPolling() {
  if (_pollTimer) return;
  pollPending();
  _pollTimer = setInterval(pollPending, 20000);
}
function stopPolling() { if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; } }
window.startPolling = startPolling; window.pollPending = pollPending;

function renderShell() {
  const tabs = visibleTabs();
  if (!tabs.find((x) => x.id === S.tab)) S.tab = tabs[0].id;
  const t = tabs.find((x) => x.id === S.tab) || tabs[0];
  document.body.className = '';
  $('app').innerHTML = `
    <div class="shell">
      <aside class="side">
        <div class="brand">
          <div class="logo"><img src="assets/logo.png" alt="Logo Simaung Corporation"></div>
          <div><b>Simaung Corporation</b><span>Superadmin Panel</span></div>
        </div>
        <nav class="nav">
          ${tabs.map((x) => `<button class="${x.id === S.tab ? 'on' : ''}" data-tab="${x.id}" title="${x.label}" onclick="go('${x.id}')"><span class="ic">${ICON[x.id]}</span><span>${x.label}</span>${badgeFor(x.id)}</button>`).join('')}
        </nav>
        <div class="me">
          <b>${esc(S.admin ? S.admin.name : 'Admin')}</b>
          <div class="email">${esc(S.admin ? S.admin.email : '')}</div>
          <div style="margin-top:11px"><button class="btn btn-sm btn-block" style="background:rgba(255,255,255,.16);color:#fff" onclick="logout()">Keluar</button></div>
        </div>
      </aside>

      <main class="main">
        <header class="mob-top">
          <div class="mt-brand"><span class="mt-logo"><img src="assets/logo.png" alt="Logo Simaung Corporation"></span><div><b>Simaung Corporation</b><span>Superadmin Panel</span></div></div>
          <button class="mt-out" onclick="logout()">Keluar</button>
        </header>
        <div class="top">
          <div><h2>${esc(t.title)}</h2><p>${esc(t.sub)}</p></div>
          <div id="top-actions"></div>
        </div>
        <div id="view"><div class="loading">Memuat…</div></div>
      </main>

      <nav class="bottom-nav">
        ${tabs.map((x) => `<button class="${x.id === S.tab ? 'on' : ''}" data-tab="${x.id}" onclick="go('${x.id}')"><span class="ic">${ICON[x.id]}</span><span class="lbl">${x.short}</span>${badgeFor(x.id)}</button>`).join('')}
      </nav>
    </div>`;
  route();
  refreshBadges();
}

function go(tab) { S.tab = tab; renderShell(); window.scrollTo({ top: 0, behavior: 'smooth' }); }

async function route() {
  try {
    if (S.tab === 'dashboard') await viewDashboard();
    else if (S.tab === 'lokasi') await viewLokasi();
    else if (S.tab === 'desain') await viewDesain();
    else if (S.tab === 'pengaturan') await viewPengaturan();
    else if (S.tab === 'karyawan') await viewKaryawan();
    else if (S.tab === 'pengguna') await viewPengguna();
    else if (S.tab === 'izin') await viewIzin();
    else if (S.tab === 'lembur') await viewLembur();
    else if (S.tab === 'laporan') await viewLaporan();
    else if (S.tab === 'shift') await viewShift();
    else if (S.tab === 'keluhan') await viewKeluhan();
    else if (S.tab === 'operasional') await viewOperasional();
    else if (S.tab === 'update') await viewUpdate();
    else if (S.tab === 'system') await viewSystem();
    else if (S.tab === 'konsol') await viewDevConsole();
    else if (S.tab === 'audit') await viewAudit();
    else if (S.tab === 'broadcast') await viewBroadcast();
    else if (S.tab === 'devices') await viewDevices();
    else if (S.tab === 'flags') await viewFlags();
  } catch (e) {
    const v = $('view');
    if (v) v.innerHTML = `<div class="card"><div class="err-box">${esc(e.message)}</div></div>`;
  }
}

// ============ BOOT ============
async function boot() {
  // Deep-link pratinjau (QA/tangkap layar): /?demo=1 atau /?demo=1&tab=keluhan
  try {
    const qs = new URLSearchParams(location.search || '');
    if (qs.has('demo') && !S.token) {
      S.demo = true;
      if (window.MOCKAPI) window.MOCKAPI.enable();
      S.admin = { name: 'Super Admin (Pratinjau)', email: 'admin@tokokartini.com', role: 'SUPERADMIN' };
      const wantTab = (qs.get('tab') || '').trim();
      S.tab = (wantTab && TABS.some((x) => x.id === wantTab)) ? wantTab : 'dashboard';
      renderShell();
      startPolling();
      return;
    }
  } catch (e) { /* abaikan */ }
  if (!S.token) { renderLogin(); return; }
  try {
    const me = await api('admin/me');
    S.admin = me;
    renderShell();
    startPolling();
  } catch (e) {
    logout();
  }
}

// ============ VIEWPORT AUTO-DETECT ============
let _lastW = window.innerWidth, _rz = null;
function isMobileView() {
  return (window.matchMedia && window.matchMedia('(max-width: 900px)').matches) || window.innerWidth <= 900;
}
window.isMobileView = isMobileView;
function onViewport() {
  const w = window.innerWidth;
  if (Math.abs(w - _lastW) < 2) return;
  const crossed = (_lastW > 900) !== (w > 900);
  _lastW = w;
  if (!document.querySelector('.shell')) return;
  clearTimeout(_rz);
  _rz = setTimeout(() => { crossed ? renderShell() : route(); }, 160);
}
window.addEventListener('resize', onViewport);
window.addEventListener('orientationchange', () => setTimeout(onViewport, 260));

window.go = go;
window.logout = logout;
window.doLogin = doLogin;
window.boot = boot;
document.addEventListener('DOMContentLoaded', boot);
