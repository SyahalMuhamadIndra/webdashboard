window.__API_BASE__ = 'https://api.simaung.com/api/';
