/* Local-only reader for the plain XLSX exports observed from Olsera. No workbook editing. */
window.OlseraXlsx=(()=>{
 const decoder=new TextDecoder('utf-8');
 async function bytesLimited(stream,max){const reader=stream.getReader(),chunks=[];let length=0;for(;;){const {value,done}=await reader.read();if(done)break;length+=value.byteLength;if(length>max){await reader.cancel();throw Error('Isi Excel melebihi batas aman.');}chunks.push(value);}const all=new Uint8Array(length);let at=0;for(const c of chunks){all.set(c,at);at+=c.length;}return all;}
 function xml(bytes){const text=decoder.decode(bytes);if(/<!DOCTYPE|<!ENTITY/i.test(text))throw Error('XML dengan deklarasi entitas tidak didukung.');const d=new DOMParser().parseFromString(text,'application/xml');if(d.querySelector('parsererror'))throw Error('XML Excel tidak valid.');return d;}
 async function read(file){
  if(!file||file.size>12000000)throw Error('Pilih file Excel sumber maksimal 12 MB.');
  const data=new Uint8Array(await file.arrayBuffer()),v=new DataView(data.buffer);let e=-1;
  for(let i=data.length-22;i>=Math.max(0,data.length-65557);i--)if(v.getUint32(i,true)===0x06054b50){e=i;break;}
  if(e<0)throw Error('File bukan XLSX ZIP yang didukung.');
  if(v.getUint16(e+4,true)||v.getUint16(e+6,true))throw Error('ZIP multi-volume tidak didukung.');
  const count=v.getUint16(e+10,true),entries=new Map();let at=v.getUint32(e+16,true);
  if(count>2000)throw Error('Terlalu banyak berkas di dalam Excel.');
  for(let i=0;i<count;i++){
   if(at+46>data.length||v.getUint32(at,true)!==0x02014b50)throw Error('Direktori Excel rusak.');
   const flags=v.getUint16(at+8,true),method=v.getUint16(at+10,true),packed=v.getUint32(at+20,true),size=v.getUint32(at+24,true),nl=v.getUint16(at+28,true),el=v.getUint16(at+30,true),cl=v.getUint16(at+32,true),offset=v.getUint32(at+42,true),name=decoder.decode(data.subarray(at+46,at+46+nl));
   if(flags&1)throw Error('Excel terenkripsi tidak didukung.');if(size>60000000)throw Error('Isi Excel terlalu besar.');
   entries.set(name,{method,packed,size,offset});at+=46+nl+el+cl;
  }
  async function entry(name){const x=entries.get(name);if(!x)return null;const o=x.offset;if(o+30>data.length||v.getUint32(o,true)!==0x04034b50)throw Error('Struktur Excel tidak valid.');const begin=o+30+v.getUint16(o+26,true)+v.getUint16(o+28,true),end=begin+x.packed;if(end>data.length)throw Error('Isi Excel terpotong.');const packed=data.subarray(begin,end);let out;if(x.method===0)out=packed;else if(x.method===8){let ds;try{ds=new DecompressionStream('deflate-raw');}catch{throw Error('Browser belum mendukung pembacaan XLSX ini. Gunakan Chrome/Safari terbaru atau bundle hasil konverter.');}out=await bytesLimited(new Blob([packed]).stream().pipeThrough(ds),60000000);}else throw Error('Kompresi Excel tidak didukung.');if(out.length!==x.size)throw Error('Ukuran isi Excel tidak cocok.');return out;}
  const stringsBytes=await entry('xl/sharedStrings.xml'),strings=stringsBytes?[...xml(stringsBytes).getElementsByTagName('si')].map(si=>[...si.getElementsByTagName('t')].map(t=>t.textContent).join('')):[];
  const sheet=await entry('xl/worksheets/sheet1.xml');if(!sheet)throw Error('Lembar utama sheet1.xml tidak tersedia.');
  const document=xml(sheet),rows=[];
  for(const r of document.getElementsByTagName('row')){
   const cells={};for(const c of r.getElementsByTagName('c')){const column=(c.getAttribute('r')||'').replace(/\d/g,''),value=c.getElementsByTagName('v')[0]?.textContent??'';cells[column]=c.getAttribute('t')==='s'?strings[Number(value)]??'':c.getAttribute('t')==='inlineStr'?[...c.getElementsByTagName('t')].map(t=>t.textContent).join(''):value;}rows.push(cells);
  }
  if(rows.length>65000)throw Error('Lembar berisi terlalu banyak baris.');
  const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',data))].map(x=>x.toString(16).padStart(2,'0')).join('');
  return {rows,source:{name:file.name,sha256:hash,bytes:file.size}};
 }
 function table(sheet,required=[]){const header=sheet.rows[0]||{};for(const key of required)if(!Object.values(header).includes(key))throw Error('Kolom '+key+' tidak ditemukan pada '+sheet.source.name);return sheet.rows.slice(1).map(r=>Object.fromEntries(Object.entries(header).map(([column,name])=>[name,r[column]??''])));}
 function decimal(value,scale=2){const s=String(value??'').trim()||'0';if(!/^-?\d+(?:\.\d+)?$/.test(s))throw Error('Angka sumber bukan desimal biasa: '+s);const neg=s.startsWith('-'),[whole,frac='']=(neg?s.slice(1):s).split('.');if(frac.slice(scale).replace(/0/g,''))throw Error('Presisi nominal sumber melampaui '+scale+' desimal.');return String((BigInt(whole)*10n**BigInt(scale)+BigInt((frac+'0'.repeat(scale)).slice(0,scale)))*(neg?-1n:1n));}
 const add=(...values)=>String(values.reduce((n,v)=>n+BigInt(decimal(v)),0n));
 const day=x=>String(x||'').slice(0,10);
 const sum=(rows,key='amount')=>String(rows.reduce((n,r)=>n+BigInt(r[key]),0n));
 async function compress(d){const raw=new TextEncoder().encode(JSON.stringify(d));if(raw.length>18000000)throw Error('Bundle terlalu besar. Pecah per outlet dan bulan.');const gzip=await bytesLimited(new Blob([raw]).stream().pipeThrough(new CompressionStream('gzip')),2900000);return {bytes:gzip,payload:d};}
 async function reports(files,{sourceAccount,branchCode,period}){
  const sheets={};for(const [key,file]of Object.entries(files))sheets[key]=await read(file);
  const paid=table(sheets.paid,['order no','total amount','paid']),all=table(sheets.all,['order no','total amount','paid']),paidIds=new Set(paid.map(r=>r['order no'].trim()));
  const receipts=all.map((r,i)=>{const ret=!!r['return date']?.trim();return {reference:r['order no'].trim(),day:day(ret?r['return date']:r['order date']),orderDay:day(r['order date']),time:ret?r['return time']:r['order time'],cashier:r['sales name']||r['served by']||'Tidak tercatat',kind:ret?'RETURN':'SALE',amount:decimal(r['total amount']),cogs:add(r['product cost'],r['addons cost']),rounding:decimal(r.rounding),discount:decimal(r.discount),paymentMode:r['payment mode']||'',paid:r.paid==='1',includedInSettledReport:paidIds.has(r['order no'].trim()),paymentDay:day(r['payment date']),row:i+2};});
  const items=table(sheets.items,['order no','item name','amount','qty']).map((r,i)=>({reference:r['order no'].trim(),day:day(r['return date']||r['order date']),sku:(r['item sku']||'').trim(),name:r['item name'],unit:r['item uom']||r.uom||'',qty:String(r.qty||'0'),baseQty:String(r.qty_with_converter||'0'),amount:decimal(r.amount),cogs:add(r['total cost'],r['total cost addons']),row:i+2}));
  const daily=table(sheets.daily,['order_date','total_amount']).filter(r=>/^20\d\d-\d\d-\d\d/.test(r.order_date)).map(r=>({day:day(r.order_date),amount:decimal(r.total_amount)}));
  const returns=table(sheets.returns,['return no','return date','total amount']).filter(r=>r['return no']?.trim()).map(r=>({reference:r['return no'].trim(),day:day(r['return date']),amount:decimal(r['total amount']),cogs:decimal(r['total cost'])}));
  const repayments=table(sheets.repayments,['order no','payment date','payment amount']).filter(r=>r['order no']?.trim()).map(r=>({reference:r['order no'].trim(),day:day(r['payment date']),mode:r['payment mode'],amount:decimal(r['payment amount'])}));
  const cancellations=table(sheets.cancellations,['order no','total amount','close date']).filter(r=>r['order no']?.trim()).map(r=>({reference:r['order no'].trim(),day:day(r['close date']||r['order date']),amount:decimal(r['total amount']),cashier:r['sales name']||'',reason:r.notes||''}));
  const settled=receipts.filter(r=>r.includedInSettledReport),sales=receipts.filter(r=>r.kind==='SALE'),settledSales=settled.filter(r=>r.kind==='SALE');
  const metrics={settledNet:sum(settled),settledGross:sum(settledSales),billedGross:sum(sales),billedNet:sum(receipts),returns:sum(returns),unsettled:sum(receipts.filter(r=>!r.includedInSettledReport)),rounding:sum(settled,'rounding'),itemNet:sum(items),itemCogs:sum(items,'cogs'),creditRepayments:sum(repayments)};
  const checks=[{key:'daily_net_matches_settled_report',ok:sum(daily)===metrics.settledNet},{key:'item_plus_rounding',ok:String(BigInt(metrics.itemNet)+BigInt(metrics.rounding))===metrics.settledNet},{key:'returns_match_negative_receipts',ok:String(-BigInt(sum(receipts.filter(r=>r.kind==='RETURN'))))===metrics.returns},{key:'credit_repayments_not_added_twice',ok:sum(settledSales.filter(r=>r.paymentMode==='TEMPO'))===metrics.creditRepayments}];
  if(checks.some(c=>!c.ok))throw Error('Angka file belum cocok: '+checks.filter(c=>!c.ok).map(c=>c.key).join(', '));
  return compress({format:'simaung.olsera.archive.v1',sourceAccount,branchCode,period,basis:'Olsera exports: Telah Bayar with returns and credit repayments already included',sources:Object.values(sheets).map(s=>s.source),receipts,items,daily,returns,repayments,cancellations,metrics,checks});
 }
 async function catalog(masterFiles,recipeFile,{sourceAccount,branchCode,asOfDate}){
  const sheets=[];for(const f of masterFiles)sheets.push(await read(f));const recipe=await read(recipeFile);
  const productRows=sheets.flatMap(s=>table(s,['name','variant_names','sku','uom','track_inventory'])),recipeRows=table(recipe,['product','variant','sku','material','qty','uom conversion']);
  return compress({format:'simaung.olsera.catalog-staging.v1',mode:'STAGING_ONLY',sourceAccount,branchCode,asOfDate,sources:[...sheets,recipe].map(s=>s.source),productRows,recipeRows});
 }
 return {read,reports,catalog};
})();
