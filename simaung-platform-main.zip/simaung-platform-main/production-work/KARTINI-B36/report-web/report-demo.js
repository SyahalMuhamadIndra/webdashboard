/* Synthetic public demo only; never contains company records. */
window.reportDemo=(()=>{
 const units=[['tk-kartini','Toko Kartini','Retail'],['maja-koffie','Maja Koffie','F&B'],['sweet-escape','Sweet Escape','F&B'],['cherry-bakes-house','Cherry Bakes House','F&B'],['rm-sindang-hurip','RM Sindang Hurip','F&B'],['mitra-water','Mitra Water','Retail'],['river-inn','River Inn','Penginapan']];
 const selected=s=>units.filter(u=>s.outlets==='all'||s.outlets===u[0]);
 const factor=s=>s.mode==='year'?12:1+(s.month-11)*.025;
 function summary(s){
  const rows=selected(s).map((u,i)=>{const omzet=(45000000+(units.indexOf(u)*13500000))*factor(s);return {id:u[0],name:u[1],category:u[2],emoji:'🏪',omzet,laba:omzet*.23,margin:.23,labaConfidence:1,weeks:s.mode==='year'?48:4,expectedWeeks:s.mode==='year'?48:4,issues:i===0?1:0,deltaOmzet:.08,avgBasket:65000};});
  const omzet=rows.reduce((a,r)=>a+r.omzet,0),laba=omzet*.23;
  rows.forEach(r=>r.share=r.omzet/omzet);
  const label=(s.mode==='year'?'Tahun ':('Bulan '+s.month+' / '))+s.year;
  return {totals:{omzet,laba,margin:.23,labaCoverageOmzet:1,transaksi:Math.round(omzet/65000),weeks:rows.reduce((a,r)=>a+r.weeks,0)},previous:{omzet:omzet/1.08,laba:laba/1.06},period:{label,prevLabel:'periode sebelumnya (dummy)'},rows,issues:{critical:0,warning:1},asks:[{sev:'warning',emoji:'🏪',outlet:rows[0]?.name||'Outlet',title:'Tinjau beban operasional',detail:'Contoh dummy: beban meningkat saat omzet tumbuh.',ask:'Apakah biaya promosi dan lembur sudah dievaluasi?'}],trend:Array.from({length:s.mode==='year'?12:4},(_,i)=>({label:String(i+1),full:'Periode dummy '+(i+1),omzet:omzet/(s.mode==='year'?12:4)*(0.85+i*.025),laba:laba/(s.mode==='year'?12:4)})),outletsDetail:rows.map(r=>({id:r.id,name:r.name,weeks:Array.from({length:4},(_,i)=>({start:`${s.year}-${String(s.month).padStart(2,'0')}-${String(1+i*7).padStart(2,'0')}`,end:`${s.year}-${String(s.month).padStart(2,'0')}-${String(7+i*7).padStart(2,'0')}`,omzet:r.omzet/4,laba:r.laba/4,beban:r.omzet*.15/4,transaksi:Math.round(r.omzet/260000),issues:[]}))}))};
 }
 function cashiers(s){return selected(s).flatMap((u,i)=>Array.from({length:3},(_,j)=>({day:`${s.year}-${String(s.month).padStart(2,'0')}-${String(1+j).padStart(2,'0')}`,code:u[0],outlet:u[1],cashier:'Kasir Demo '+(i+1),receipts:24+j*3,sales:1560000+j*195000,voids:j===1?1:0,refunds:0})));}
 return {summary,cashiers,analysis:s=>{const d=summary(s);return d.period.label+': omzet simulasi meningkat 8% dibanding periode sebelumnya, dengan margin 23%. Contoh evaluasi: periksa rincian biaya promosi dan lembur sebelum menyimpulkan penyebab kenaikan beban. Semua nilai hanya ilustrasi.';}};
})();
