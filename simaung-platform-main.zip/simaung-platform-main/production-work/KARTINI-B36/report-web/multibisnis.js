(function(W){
  'use strict';
  const esc=W.__esc, labels={all:'Seluruh Unit',retail:'Retail',fnb:'F&B',kosan:'Kosan',penginapan:'Penginapan'};
  const now=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit'}).formatToParts(new Date());
  const part=t=>Number(now.find(p=>p.type===t).value);
  const currentYear=part('year'), currentMonth=part('month');
  const state={unit:'all',mode:'month',year:currentYear,month:currentMonth,location:''};
  const months=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
  const geminiDemoTemplates={"below": "Omzet sebesar {omzet} masih di bawah target {target} dengan selisih {selisih}; pencapaian {persen}.", "equal": "Omzet mencapai {omzet} dan tepat memenuhi target {target} ({persen}).", "above": "Omzet sebesar {omzet} telah melampaui target {target} dengan selisih {selisih}; pencapaian {persen}."};
  const properties=['kosan','penginapan'];
  const grantLabels={SYSTEM_ADMIN:'Admin Sistem',OWNER:'Owner Grup',UNIT_MANAGER:'Manajer Unit',FINANCE:'Keuangan',PROPERTY_STAFF:'Petugas Properti',KITCHEN:'Dapur',RECEPTION:'Resepsionis',RENTAL_MANAGER:'Pengelola Kos'};
  let data, filtered=[], activeTargets=[], requestId=0, ops=null, kitchenOutlets=[];
  const opt=(v,n,s)=>'<option value="'+esc(v)+'"'+(String(s)===String(v)?' selected':'')+'>'+esc(n)+'</option>';
  const fmt=new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR'});
  // Data dan semua perubahan demo berada di memori tab ini.
  let demo;
  const samplePeriod=(y,m)=>y+'-'+String(m).padStart(2,'0');
  function seedDemo(){
    const branches=[
      {id:'demo-retail',name:'Toko Contoh',unit:'retail'},
      {id:'demo-fnb',name:'Outlet Contoh',unit:'fnb'},
      {id:'demo-new',name:'Cabang Contoh Baru',unit:null},
    ];
    const rows=[], targets=[], receipts=[];
    for(const year of [currentYear-1,currentYear])for(let month=1;month<=12;month++){
      const period=samplePeriod(year,month);
      for(const [unit,amount] of [['retail',10000000],['fnb',8000000],['kosan',5000000],['penginapan',6000000]]) {
        targets.push({unit,period,amount});
        if(year===currentYear&&month>currentMonth)continue;
        const rate={retail:1.08,fnb:.72,kosan:.85,penginapan:.43}[unit];
        const sales=Math.round(amount*(rate+(month%3)*.01));
        if(properties.includes(unit)){
          receipts.push({id:'demo-'+unit+'-'+period,unit,property:unit==='kosan'?'Kosan Contoh':'Penginapan Contoh',
            reference:'DEMO-'+unit.toUpperCase()+'-'+period,paid_on:period+'-01',amount:sales,voided:false});
        }else rows.push({branch_id:'demo-'+unit,period,receipts:Math.round(sales/65000),sales});
      }
    }
    return {branches,rows,targets,receipts};
  }
  async function reportApi(path,opts){
    if(!W.__isDemo())return W.__api(path,opts);
    demo??=seedDemo();
    const body=opts?.body||{};
    if(path.endsWith('/target')){
      const period=samplePeriod(body.year,body.month);
      demo.targets=demo.targets.filter(t=>t.period!==period||t.unit!==body.unit);
      demo.targets.push({unit:body.unit,period,amount:body.amount});return {ok:true};
    }
    if(path.endsWith('/branch')){
      const branch=demo.branches.find(b=>b.id===body.branchId&&!b.unit);
      if(!branch)throw Error('Cabang contoh tidak tersedia.');
      branch.unit=body.unit;return {ok:true};
    }
    if(path.endsWith('/property-receipts')){
      const reference=body.reference.trim().toUpperCase(),property=body.property.trim();
      if(!reference||!property||!body.paidOn||!Number.isSafeInteger(body.amount)||body.amount<1)
        throw Error('Lengkapi bukti, properti, tanggal, dan nominal.');
      const prior=demo.receipts.find(r=>r.unit===body.unit&&r.reference===reference);
      if(prior){
        if(!prior.voided&&prior.property===property&&prior.paid_on===body.paidOn&&prior.amount===body.amount)return {ok:true};
        throw Error('Nomor bukti contoh sudah dipakai.');
      }
      demo.receipts.unshift({id:'demo-entry-'+demo.receipts.length,unit:body.unit,property,reference,paid_on:body.paidOn,amount:body.amount,voided:false});
      return {ok:true};
    }
    const voidId=path.match(/property-receipts\/([^/]+)\/void$/)?.[1];
    if(voidId){
      const receipt=demo.receipts.find(r=>r.id===voidId&&!r.voided);
      if(!receipt||body.reason.trim().length<3||body.reason.trim().length>300)throw Error('Isi alasan pembatalan (3–300 karakter).');
      receipt.voided=true;return {ok:true};
    }
    const q=new URLSearchParams(path.split('?')[1]),year=Number(q.get('year')),month=Number(q.get('month')),unit=q.get('unit');
    const start=samplePeriod(year,month||1)+'-01';
    const end=(month&&month<12?samplePeriod(year,month+1):samplePeriod(year+1,1))+'-01';
    const matches=(u,period)=>(unit==='all'||unit===u)&&period>=start.slice(0,7)&&period<end.slice(0,7);
    const receipts=demo.receipts.filter(r=>matches(r.unit,r.paid_on.slice(0,7))).sort((a,b)=>b.paid_on.localeCompare(a.paid_on));
    const propertyRows=new Map();
    for(const r of receipts.filter(r=>!r.voided)){
      const period=r.paid_on.slice(0,7),key=JSON.stringify([r.unit,r.property,period]);
      const row=propertyRows.get(key)||{unit:r.unit,branch_id:'property:'+r.property,branch:r.property,period,sales:0,receipts:0};
      row.sales+=r.amount;row.receipts++;propertyRows.set(key,row);
    }
    const pos=demo.rows.map(r=>{
      const b=demo.branches.find(b=>b.id===r.branch_id);
      return {...r,unit:b.unit,branch:b.name};
    }).filter(r=>matches(r.unit,r.period));
    const daily=pos.flatMap(r=>{
      const dates=['01','03','06','09','12'];
      const take=(n,i)=>Math.floor(n/dates.length)+(i<n%dates.length?1:0);
      return dates.map((d,i)=>{
        const receipts=take(r.receipts,i), cash=Math.ceil(receipts*.55), qris=Math.floor((receipts-cash)*.8);
        return {unit:r.unit,branch_id:r.branch_id,branch:r.branch,day:r.period+'-'+d,receipts,sales:take(r.sales,i),methods:{CASH:cash,QRIS:qris,TRANSFER:receipts-cash-qris}};
      });
    }).sort((a,b)=>b.day.localeCompare(a.day));
    const sample=demo.branches.filter(b=>['retail','fnb'].includes(b.unit)&&(unit==='all'||b.unit===unit));
    const summary=sample.map(b=>{
      const rows=pos.filter(p=>p.branch_id===b.id);
      return {unit:b.unit,branch_id:b.id,branch:b.name,sales:rows.reduce((n,p)=>n+p.sales,0),receipts:rows.reduce((n,p)=>n+p.receipts,0)};
    });
    const products=summary.flatMap(b=>[[b.unit==='retail'?'Produk Toko':'Menu Utama',.7],[b.unit==='retail'?'Aksesori':'Minuman',.3]].map(([product,share])=>({...b,product,category:share===.7?'Utama':'Pelengkap',quantity:Math.ceil(b.receipts*share),item_total:Math.round(b.sales*share),item_cost:Math.round(b.sales*share*.4),no_cost:0})));
    const shifts=summary.map(b=>({...b,cashier:'Kasir Contoh',shift_opened:samplePeriod(year,month||1)+'-01 08:00',discounts:0,voids:0,refunds:0,refunded_sale_value:0}));
    const paymentTotals=summary.flatMap(b=>[['CASH',.6],['QRIS',.4]].map(([method,share])=>({...b,method,amount:Math.round(b.sales*share)})));
    const propertyDaily=receipts.filter(r=>!r.voided).map(r=>({unit:r.unit,branch_id:'property:'+r.property,day:r.paid_on,sales:r.amount}));
    const propertyMetrics=properties.filter(u=>unit==='all'||u===unit).map(u=>{
      const name=u==='kosan'?'Kosan Contoh':'Penginapan Contoh';
      return {unit:u,property:name,branch_id:'property:'+name,active_rooms:u==='kosan'?18:14,occupied_rooms:u==='kosan'?14:9,
        reserved:u==='kosan'?2:4,unpaid_count:2,overdue_count:u==='kosan'?1:0,overdue_30:u==='kosan'?800000:0,overdue_60:0,overdue_older:0,undated:0,measured_nights:u==='penginapan'?73:0,unknown_stays:0,ending:u==='kosan'?2:0,unpaid_amount:u==='kosan'?2400000:1000000,held_deposit:1300000};
    });
    const stockSignals=sample.filter(b=>b.unit==='fnb'||b.unit==='retail').map(b=>({
      unit:b.unit,branch_id:b.id,location:b.name,kind:b.unit==='fnb'?'Bahan':'Barang',name:b.unit==='fnb'?'Beras Contoh':'Produk Contoh',
      stock_unit:b.unit==='fnb'?'g':'pcs',balance:b.unit==='fnb'?250:0,minimum:b.unit==='fnb'?1000:5
    }));
    const cashSignals=summary.filter(b=>b.unit==='retail').map(b=>({...b,location:b.branch,code:'SHIFT-CONTOH',day:start,counted:470000,expected:500000,difference:-30000}));
    return {unit,start,end,daily,propertyDaily,propertyMetrics,stockSignals,cashSignals,wasteMetrics:summary.filter(b=>b.unit==='fnb').map(b=>({...b,material:'Beras Contoh',quantity:150,stock_unit:'g',waste_cost:1800})),kitchenMetrics:summary.filter(b=>b.unit==='fnb').map(b=>({...b,kind:'DINE_IN',tickets:64,open:4,cancelled:1,timed:47,mean_ready:12.3})),calculatedAt:new Date().toISOString(),products,shifts,paymentTotals,branches:demo.branches,rows:[...pos,...propertyRows.values()],receipts:receipts.slice(0,200),targets:demo.targets.filter(t=>matches(t.unit,t.period))};
  }
  const methodNames={CASH:'Tunai',QRIS:'QRIS',TRANSFER:'Transfer',SPLIT:'Gabungan',DEBIT:'Debit',CREDIT:'Kredit',UNKNOWN:'Tidak tercatat'};
  const methods=r=>Object.entries(r.methods||{}).filter(([,count])=>count>0)
    .map(([k,v])=>(Object.hasOwn(methodNames,k)?methodNames[k]:k)+' '+v).join(' · ');
  W.__pages.multibisnis=async function(){
    const id=++requestId;
    const access=W.__isDemo()?{grant:{role:'OWNER',unit:'all',property:null},accounts:[]}:await W.__api('admin/business-reports/access');
    if(id!==requestId)return '';
    const grant=access.grant;
    const work=W.__operationsWorkspace===true;
    if(!W.__isDemo()){const badge=document.getElementById('u-role');if(badge)badge.textContent=grantLabels[grant.role]||grant.role;}
    ops=null;
    const dedicated=document.body.dataset;
    if(work&&dedicated.propertyName){
      const unit=dedicated.propertyUnit, property=dedicated.propertyName, name=dedicated.propertyLabel;
      if(grant.role==='KITCHEN'||(grant.unit!=='all'&&grant.unit!==unit)||(grant.property&&grant.property!==property)){
        return '<section class="card"><div class="card-b"><p>Akun ini tidak memiliki akses ke '+W.__esc(name)+'.</p><a class="btn ghost sm" href="/operasional">Buka Operasional Unit</a></div></section>';
      }
      const scoped={...grant,property};
      ops={unit,grant:scoped};
      return '<div class="br-report">'+W.__pagehead(W.__IC.bag,name,'Operasional properti')+W.__brOpsContainer(unit,scoped)+'</div>';
    }
    if(grant.role==='KITCHEN'){
      if(!work)return '<section class="card"><div class="card-b"><p>Akun Dapur digunakan di ruang kerja operasional.</p><a class="btn ghost sm" href="/operasional">Buka Operasional Unit</a></div></section>';
      ops={unit:'fnb',grant};
      return '<div class="br-report">'+W.__pagehead(W.__IC.bag,'Dapur F&B','Antrean pesanan outlet yang ditugaskan')+W.__brOpsContainer('fnb',grant)+'</div>';
    }
    const group=['OWNER','SYSTEM_ADMIN'].includes(grant.role);
    const canEnter=work&&(group||['FINANCE','PROPERTY_STAFF'].includes(grant.role));
    const canVoid=work&&(group||grant.role==='FINANCE');
    if(grant.unit!=='all'&&state.unit!==grant.unit){state.unit=grant.unit;state.location='';}
    const q=new URLSearchParams({unit:state.unit,year:state.year});
    if(state.mode==='month')q.set('month',state.month);
    if(!work){q.set('daily','1');q.set('alerts','1');if(['all','retail','fnb'].includes(state.unit))q.set('breakdown','1');}
    const result=await reportApi('admin/business-reports'+(work&&!W.__isDemo()?'/operations/overview':'')+'?'+q);
    let previousRows=[];
    if(W.__isDemo()){
      const previous=new URLSearchParams(q);
      if(state.mode==='month'){
        previous.set('year',String(state.year-(state.month===1?1:0)));
        previous.set('month',String(state.month===1?12:state.month-1));
      }else previous.set('year',String(state.year-1));
      previousRows=(await reportApi('admin/business-reports?'+previous)).rows;
      if(state.mode==='year'&&state.year===currentYear)previousRows=previousRows.filter(r=>Number(r.period.slice(5))<=currentMonth);
    }

    if(id!==requestId)return '';
    kitchenOutlets=result.branches.filter(b=>b.unit==='fnb');
    const property=properties.includes(state.unit);
    const canOps=work&&(group||grant.role==='UNIT_MANAGER'||['RECEPTION','RENTAL_MANAGER'].includes(grant.role)||grant.role==='FINANCE');
    const branches=property
      ? [...new Map([...result.rows,...(result.propertyMetrics||[]).map(r=>({...r,branch:r.property}))].filter(r=>r.unit===state.unit).map(r=>[r.branch_id,{id:r.branch_id,name:r.branch}])).values()]
      : result.branches.filter(b=>b.unit===state.unit);
    if(!branches.some(b=>b.id===state.location))state.location='';
    filtered=result.rows.filter(r=>!state.location||r.branch_id===state.location);
    data=result;
    const daily=(result.daily||[]).filter(r=>!state.location||r.branch_id===state.location);
    const icons=W.__IC;
    const unitIcon={retail:icons.bag,fnb:icons.sales,kosan:icons.user,penginapan:icons.clock};
    const card=(title,body,icon=icons.trend)=>'<section class="card br-card"><div class="card-h"><h3><span class="hh">'+icon+'</span>'+esc(title)+'</h3></div><div class="card-b">'+body+'</div></section>';
    const empty=msg=>'<p class="br-empty">'+esc(msg)+'</p>';
    function table(rows){
      if(!rows.length)return empty('Belum ada pembayaran tercatat dalam periode ini.');
      return '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Bulan</th><th>Cabang / properti</th><th class="num">Pembayaran</th><th class="num">Omzet</th></tr></thead><tbody>'+rows.map(r=>'<tr><td>'+esc(r.period)+'</td><td>'+esc(r.branch||'Cabang belum diketahui')+'</td><td class="num">'+esc(r.receipts)+'</td><td class="num">'+esc(fmt.format(Number(r.sales)))+'</td></tr>').join('')+'</tbody></table></div>';
    }
    function dailyTable(unit){
      const rows=daily.filter(r=>r.unit===unit);
      if(!rows.length)return empty('Belum ada struk POS lunas dari cabang terpetakan pada periode ini.');
      const monthGroups=new Map();
      for(const row of rows){
        const month=row.day.slice(0,7);
        if(!monthGroups.has(month))monthGroups.set(month,[]);
        monthGroups.get(month).push(row);
      }
      return '<p class="br-caption">Tanggal transaksi (WIB). Metode bayar dihitung per struk; pembayaran gabungan tampil sebagai satu metode.</p>'+
        [...monthGroups.entries()].map(([period,items],i)=>'<details class="br-op-detail"'+(i===0?' open':'')+'><summary>'+
        esc(months[Number(period.slice(5))-1]+' '+period.slice(0,4))+' · '+items.length+' baris</summary>'+
        '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Tanggal</th><th>Cabang / outlet</th><th class="num">Struk lunas</th><th class="num">Omzet</th><th class="num">Rata-rata struk</th><th>Metode bayar (struk)</th><th></th></tr></thead><tbody>'+
        items.map(r=>'<tr><td>'+esc(r.day)+'</td><td>'+esc(r.branch)+'</td><td class="num">'+esc(r.receipts)+'</td><td class="num">'+esc(fmt.format(Number(r.sales)))+'</td><td class="num">'+esc(fmt.format(Number(r.sales)/Number(r.receipts)))+'</td><td>'+esc(methods(r))+'</td><td><button type="button" class="btn ghost sm" data-br-proof="'+esc(JSON.stringify({u:r.unit,l:r.branch_id,d:r.day}))+'">Bukti</button></td></tr>').join('')+
        '</tbody></table></div></details>').join('');
    }
    function detailsTable(title,headers,rows,fields){
      return '<details class="br-op-detail"><summary>'+esc(title)+' · '+rows.length+' baris</summary>'+
      (!rows.length?empty('Belum ada data untuk cakupan ini.'):'<div class="tbl-wrap"><table class="tbl"><thead><tr>'+headers.map(x=>'<th>'+esc(x)+'</th>').join('')+
      '</tr></thead><tbody>'+rows.slice(0,250).map(r=>'<tr>'+fields(r).map(x=>'<td>'+esc(x??'—')+'</td>').join('')+'</tr>').join('')+
      '</tbody></table></div>'+(rows.length>250?'<p class="br-caption">Menampilkan 250 baris pertama. Unduh CSV untuk data lengkap.</p>':''))+'</details>';
    }
    const amountCell=v=>fmt.format(Number(v));
    const narrow=(rows,unit)=>(rows||[]).filter(r=>(!unit||r.unit===unit)&&(!state.location||r.branch_id===state.location));
    const productColumns=['Cabang','Produk','Kategori','Jumlah','Nilai item','HPP item','Margin item'];
    const productFields=r=>[r.branch,r.product,r.category,r.quantity,amountCell(r.item_total),r.no_cost>0?'Belum lengkap':amountCell(r.item_cost),r.no_cost>0?'—':amountCell(Number(r.item_total)-Number(r.item_cost))];
    const shiftColumns=['Cabang','Kasir','Shift dibuka (WIB)','Struk lunas','Omzet','Diskon nota','Void','Refund','Nilai nota refund'];
    const shiftFields=r=>[r.branch,r.cashier,r.shift_opened?.slice(0,16),r.receipts,amountCell(r.sales),amountCell(r.discounts),r.voids,r.refunds,amountCell(r.refunded_sale_value)];
    const payColumns=['Cabang','Metode','Nilai tercatat'];
    const payFields=r=>[r.branch,Object.hasOwn(methodNames,r.method)?methodNames[r.method]:r.method,amountCell(r.amount)];
    const label=(name,id,options)=>'<label class="br-field">'+name+'<select id="'+id+'">'+options+'</select></label>';
    const filters='<div class="br-form">'+
      label('Unit bisnis','br-unit',Object.entries(labels).filter(([v])=>grant.unit==='all'||v===grant.unit).map(([v,n])=>opt(v,n,state.unit)).join(''))+
      label('Periode','br-mode',opt('month','Bulanan',state.mode)+opt('year','Tahunan',state.mode))+
      (state.mode==='month'?label('Bulan','br-month',months.map((n,i)=>opt(i+1,n,state.month)).join('')):'')+
      label('Tahun','br-year',Array.from({length:currentYear-1999},(_,i)=>opt(currentYear-i,currentYear-i,state.year)).join(''))+
      (branches.length?label(property?'Properti':'Cabang','br-location',opt('',property?'Semua properti':'Semua cabang',state.location)+branches.map(b=>opt(b.id,b.name,state.location)).join('')):'')+
      (work?'':'<button type="button" class="btn ghost br-export" id="br-csv" '+(!filtered.length&&!result.shifts?.length?'disabled':'')+'>Unduh CSV</button><button type="button" class="btn ghost br-export" id="br-print">Cetak ringkasan</button>')+'</div>';
    const missing=state.mode==='year'?state.year===currentYear:state.year===currentYear&&state.month===currentMonth;
    const periodTitle=state.mode==='month'?months[state.month-1]+' '+state.year:'Tahun '+state.year;
    let html='<div class="br-report">'+W.__pagehead(icons.trend,work?'Operasional Unit':'Laporan Multibisnis',work?'Ruang kerja transaksi, pengaturan dan akun':'Pantau omzet dan target Simaung Corporation','<b>'+esc(periodTitle)+'</b><span>'+esc(labels[state.unit])+'</span>')+
      card(work?'Unit dan Periode':'Cakupan Laporan',filters+'<div class="br-note"><span class="pill">'+esc(grantLabels[grant.role]||grant.role)+'</span><span>'+esc(periodTitle)+' · WIB'+(missing?' · Periode berjalan':'')+'</span>'+
      (W.__isDemo()?'<span class="pill">'+(work?'Demo · Perubahan hanya di tab ini':'Demo · Data contoh')+'</span>':'')+'</div>',icons.clock);
    if(canOps&&state.unit==='all')html+='<div class="br-op-shortcuts">'+[
      ['fnb','Antrean Dapur'],['kosan','Operasional Kosan'],['penginapan','Operasional Penginapan']
    ].filter(([u])=>grant.role!=='FINANCE'||u!=='fnb').map(([u,l])=>'<button type="button" class="btn ghost sm" data-br-open-op="'+u+'">'+l+'</button>').join('')+'</div>';
    if(canOps&&(property||(state.unit==='fnb'&&grant.role!=='FINANCE'))){
      html+='<p class="br-caption"><a class="btn sm ghost" href="/owner-settings">Pengelolaan Target Outlet &amp; Tindak Lanjut</a></p>';
      ops={unit:state.unit,grant};
      html+=W.__brOpsContainer(state.unit,grant);
    }
    const supported=['retail','fnb',...properties];
    const evaluate=(keys)=>{
      const targets=result.targets.filter(t=>keys.includes(t.unit));
      const actual=result.rows.filter(r=>keys.includes(r.unit)).reduce((n,r)=>n+Number(r.sales),0);
      const expected=(state.mode==='month'?1:12)*keys.length;
      const configured=keys.every(k=>properties.includes(k)||result.branches.some(b=>b.unit===k));
      const target=targets.reduce((n,t)=>n+Number(t.amount),0);
      if(!configured||targets.length!==expected)return {actual,target,expected,count:targets.length,configured,p:null};
      return {actual,target,expected,count:targets.length,configured,p:actual/target*100,band:actual>=.8*target?'Aman':actual>=.5*target?'Ideal':'Bahaya'};
    };
    const statusClass=band=>({Aman:'s-ok',Ideal:'s-warn',Bahaya:'s-danger'}[band]||'s-mut');
    const percent=v=>v.toLocaleString('id-ID',{maximumFractionDigits:2})+'%';
    const badge=band=>'<span class="badge-status '+statusClass(band)+'">'+esc(band||'Belum dinilai')+'</span>';
    function attainment(a,hide){
      if(hide)return empty('Target dinilai pada cakupan semua lokasi unit.');
      const status=a.p===null?(!a.configured?'Cabang belum dipetakan':'Target belum lengkap ('+a.count+'/'+a.expected+')')
        :(a.actual<a.target?'Target belum tercapai':'Target tercapai');
      return '<div class="br-attainment"><div><span>Omzet</span><b>'+esc(fmt.format(a.actual))+'</b></div>'+
        '<div><span>Target</span><b>'+(a.p===null?'&mdash;':esc(fmt.format(a.target)))+'</b></div>'+
        '<div><span>Pencapaian</span><b>'+(a.p===null?'&mdash;':esc(percent(a.p)))+'</b></div></div>'+
        '<div class="br-status">'+badge(a.band)+'<span>'+esc(status)+'</span></div>'+
        (a.p===null?'':'<div class="br-progress '+statusClass(a.band)+'" aria-hidden="true"><i style="width:'+Math.min(100,Math.max(0,a.p))+'%"></i></div>');
    }
    activeTargets=(state.unit==='all'?supported:[state.unit]).filter(u=>supported.includes(u)).map(u=>({u,...evaluate([u])}));
    if(state.unit==='all')activeTargets.unshift({u:'all',...evaluate(supported)});
    function insight(unit,a){
      if(state.location||grant.property)return '';
      const reason=!a.configured?'Cabang belum dipetakan.':a.p===null?'Target periode belum lengkap.':
        a.actual<a.target?'Omzet masih kurang '+fmt.format(a.target-a.actual)+' dari target.':
        a.actual>a.target?'Omzet melampaui target sebesar '+fmt.format(a.actual-a.target)+'.':'Omzet tepat mencapai target.';
      const demoGemini=W.__isDemo()&&a.p!==null;
      const values=demoGemini?{omzet:fmt.format(a.actual),target:fmt.format(a.target),persen:percent(a.p),selisih:fmt.format(Math.abs(a.actual-a.target))}:null;
      const demoReason=demoGemini?geminiDemoTemplates[a.actual<a.target?'below':a.actual>a.target?'above':'equal']
        .replace(/\{(omzet|target|persen|selisih)\}/g,(_,key)=>values[key]):reason;
      let caveat=a.p===null?' Pencapaian belum bisa dinilai.':' Data ini belum menunjukkan penyebab operasionalnya.';
      if(demoGemini){
        const sum=(rows,key)=>rows.filter(r=>r.unit===unit).reduce((n,r)=>n+Number(r[key]),0);
        const count=sum(result.rows,'receipts'), previousCount=sum(previousRows,'receipts');
        if(count&&previousCount){
          const oldAverage=sum(previousRows,'sales')/previousCount, currentAverage=a.actual/count;
          const volume=(count-previousCount)*oldAverage, value=count*(currentAverage-oldAverage);
          const effect=n=>(n>=0?'+':'−')+fmt.format(Math.abs(n));
          caveat=' Dibanding periode sebelumnya, pembayaran '+previousCount+' → '+count+' dan rata-rata '+fmt.format(oldAverage)+' → '+fmt.format(currentAverage)+'. Dampak jumlah: '+effect(volume)+'; dampak nilai rata-rata: '+effect(value)+'.';
        }else caveat=' Belum ada data pembanding yang cukup untuk menjelaskan perubahan omzet.';
      }
      return '<div class="br-insight" data-br-insight="'+unit+'"><strong>Penjelasan pencapaian</strong>'+
        '<p>'+esc(demoReason+caveat)+'</p><small>'+ (demoGemini?'Template Gemini · Data contoh':W.__isDemo()?'Simulasi dari data contoh':'Berdasarkan angka laporan')+'</small></div>';
    }
    if(!work){
    const summary=evaluate(state.unit==='all'?supported:[state.unit]);
    const targetVisible=summary.p!==null&&!state.location;
    const amount=state.location?filtered.reduce((n,r)=>n+Number(r.sales),0):summary.actual;
    const visible=state.unit==='all'?supported:[state.unit];
    const totals={pos:filtered.filter(r=>r.unit==='retail'||r.unit==='fnb').reduce((n,r)=>n+Number(r.sales),0),
      property:filtered.filter(r=>properties.includes(r.unit)).reduce((n,r)=>n+Number(r.sales),0)};
    const time=result.calculatedAt?new Intl.DateTimeFormat('id-ID',{timeZone:'Asia/Jakarta',dateStyle:'medium',timeStyle:'short'}).format(new Date(result.calculatedAt)):'—';
    const gaps=visible.filter(u=>!evaluate([u]).configured);
    const unmapped=state.unit==='all'&&filtered.some(r=>!r.unit);
    html+='<div class="br-owner-summary"><div class="br-print-head"><h2>Simaung Corporation · Ringkasan Owner</h2><p>'+esc(labels[state.unit])+' · '+esc(periodTitle)+' · WIB</p></div>';
    html+='<div class="kpis br-kpis">'+[
      {icon:icons.money,label:'Aktual laporan',value:esc(fmt.format(amount)),sub:'POS lunas dan penerimaan properti'},
      {icon:icons.sales,label:'Target omzet',value:targetVisible?esc(fmt.format(summary.target)):'&mdash;',sub:state.location?'Pilih semua lokasi untuk melihat target':summary.p===null?'Target atau pemetaan belum lengkap':'Target periode terpilih',cls:'k-info'},
      {icon:icons.trend,label:'Pencapaian',value:targetVisible?esc(percent(summary.p)):'&mdash;',sub:targetVisible?badge(summary.band)+' '+(summary.actual<summary.target?'Target belum tercapai':'Target tercapai'):'Belum dinilai',cls:targetVisible?({Ideal:'k-warn',Bahaya:'k-danger'}[summary.band]||''):''},
    ].map(W.__kpi).join('')+'</div>';
    const smRows=visible.map(u=>{
      const a=evaluate([u]);
      const scoped=state.location?filtered.filter(r=>r.unit===u).reduce((n,r)=>n+Number(r.sales),0):a.actual;
      const shown=a.p!==null&&!state.location;
      const hasData=filtered.some(r=>r.unit===u);
      const reason=!a.configured?'Cabang belum dipetakan':!hasData?'Belum ada transaksi tercatat':state.location?'Target dinilai per unit':!shown?'Target belum lengkap':a.actual>=a.target?'Target tercapai':'Target belum tercapai';
      return '<tr><td><strong>'+esc(labels[u])+'</strong></td><td class="num">'+esc(fmt.format(scoped))+'</td><td class="num">'+
        (shown?esc(fmt.format(a.target)):'—')+'</td><td class="num">'+(shown?esc(percent(a.p)):'—')+'</td><td class="num">'+
        (shown?esc(fmt.format(a.actual-a.target)):'—')+'</td><td>'+badge(shown?a.band:null)+'<div class="tsub">'+esc(reason)+'</div></td><td class="br-print-hide">'+
        (state.unit==='all'?'<button type="button" class="btn ghost sm" data-br-owner-unit="'+u+'">Rincian</button>':'')+' <button type="button" class="btn ghost sm" data-br-proof="'+esc(JSON.stringify({u,l:state.location}))+'">Bukti</button>'+'</td></tr>';
    }).join('');
    html+=card('Perbandingan Unit','<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Unit</th><th class="num">Aktual</th><th class="num">Target</th><th class="num">Capaian</th><th class="num">Selisih</th><th>Status</th><th class="br-print-hide"></th></tr></thead><tbody>'+smRows+
      '</tbody></table></div><div class="br-note"><span>Penjualan POS lunas: <b>'+esc(fmt.format(totals.pos))+'</b></span><span>Penerimaan properti: <b>'+esc(fmt.format(totals.property))+'</b></span></div>'+
      '<p class="br-caption">POS memakai tanggal nota; properti memakai tanggal penerimaan. Angka gabungan adalah indikator operasional, bukan saldo kas atau laba. Deposit tidak masuk.</p>',icons.money);
    const alertRows=[];
    const wibDay=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
    const startMs=Date.parse(result.start),endMs=Date.parse(result.end),todayMs=Date.parse(wibDay);
    const elapsed=Math.max(0,Math.min(endMs,todayMs+86400000)-startMs);
    const expected=max=>max*Math.min(1,elapsed/(endMs-startMs));
    if(!state.location&&elapsed>0){
      for(const u of visible){
        const a=evaluate([u]),pace=a.target>0&&a.p!==null?expected(a.target):0;
        if(pace>a.actual)alertRows.push({u,title:labels[u]+' di bawah laju target',text:'Aktual '+fmt.format(a.actual)+'; kurang '+fmt.format(pace-a.actual)+' dari target proporsional kalender.',tone:'s-warn',spot:'trend'});
      }
    }
    const propertyOpen=narrow(result.propertyMetrics).filter(r=>Number(r.unpaid_count)>0);
    for(const r of propertyOpen)alertRows.push({u:r.unit,title:r.property+' · tagihan belum lunas',text:r.unpaid_count+' tagihan periode ini · '+fmt.format(Number(r.unpaid_amount))+'. Belum berarti lewat jatuh tempo.',tone:'s-warn',spot:'property',proof:{u:r.unit,l:r.branch_id,kind:'bills'}});
    for(const r of propertyOpen)if(Number(r.overdue_count)>0)
      alertRows.push({u:r.unit,title:r.property+' · tagihan lewat jatuh tempo',text:r.overdue_count+' tagihan · '+fmt.format(Number(r.overdue_30)+Number(r.overdue_60)+Number(r.overdue_older))+'.',tone:'s-danger',spot:'property',proof:{u:r.unit,l:r.branch_id,kind:'bills'}});
    for(const r of narrow(result.propertyMetrics,'kosan'))if(Number(r.ending)>0)
      alertRows.push({u:r.unit,title:r.property+' · kontrak segera berakhir',text:r.ending+' kontrak aktif berakhir dalam 30 hari kalender.',tone:'s-warn',spot:'property'});
    const stock=narrow(Array.isArray(result.stockSignals)?result.stockSignals:[]);
    for(const r of stock)alertRows.push({u:r.unit,title:r.location+' · '+r.name,text:r.kind+' tersisa '+r.balance+' '+(r.stock_unit||'')+' (minimum '+r.minimum+'). Posisi saat ini.',tone:Number(r.balance)<=0?'s-danger':'s-warn',spot:'stock'});
    const cash=narrow(Array.isArray(result.cashSignals)?result.cashSignals:[]);
    for(const r of cash)alertRows.push({u:r.unit,title:r.location+' · selisih kas shift',text:(r.code||r.day)+' · fisik '+fmt.format(Number(r.counted))+'; seharusnya '+fmt.format(Number(r.expected))+'; selisih '+fmt.format(Number(r.difference))+'.',tone:Number(r.difference)<0?'s-danger':'s-warn',spot:'cash',proof:{u:r.unit,l:r.branch_id,d:r.day,shift:r.shift_id}});
    alertRows.sort((a,b)=>Number(b.tone==='s-danger')-Number(a.tone==='s-danger'));
    const alertList=alertRows.slice(0,12).map(a=>'<li><span class="badge-status '+a.tone+'">'+esc(labels[a.u])+'</span><div><strong>'+esc(a.title)+'</strong><p>'+esc(a.text)+'</p></div>'+
      (a.proof?'<button class="btn ghost sm br-print-hide" type="button" data-br-proof="'+esc(JSON.stringify(a.proof))+'">Bukti</button>':state.unit==='all'?'<button class="btn ghost sm br-print-hide" type="button" data-br-owner-unit="'+a.u+'">Lihat unit</button>':'')+'</li>').join('');
    html+=card('Pusat Peringatan Bisnis',(alertRows.length?
      '<ul class="br-alert-list">'+alertList+'</ul>'+(alertRows.length>12?'<p class="br-caption">Menampilkan 12 peringatan pertama.</p>':''):
      empty('Tidak ada peringatan dari sumber yang tersedia pada pilihan ini.'))+
      '<p class="br-caption">Laju target memakai pembagian rata per hari kalender. Stok menampilkan kondisi saat ini, bukan saldo historis.'+
      (visible.some(u=>u==='retail'||u==='fnb')&&!Array.isArray(result.stockSignals)?' Pemeriksaan stok belum tersedia.':'')+
      (result.stockSignals?.[0]?.matched>100?' Hasil stok dibatasi 100 baris.':'')+(visible.some(u=>u==='retail'||u==='fnb')&&!Array.isArray(result.cashSignals)?' Data selisih kas belum tersedia.':'')+'</p>',icons.alert);
    const timeline=new Map();
    const trendRows=state.mode==='year'?filtered:[...daily,...(result.propertyDaily||[]).filter(r=>!state.location||r.branch_id===state.location)];
    for(const row of trendRows){
      const key=state.mode==='year'?row.period:row.day;
      if(!key||!visible.includes(row.unit))continue;
      timeline.set(key,(timeline.get(key)||0)+Number(row.sales));
    }
    if(timeline.size){
      const bars=[...timeline.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([key,value])=>({label:state.mode==='year'?months[Number(key.slice(5))-1].slice(0,3):key.slice(-2),value}));
      html+=card(state.mode==='year'?'Tren per Bulan':'Tren per Hari',
        '<p class="br-caption">Menampilkan tanggal atau bulan dengan transaksi dalam pilihan ini.</p>'+
        '<div class="br-owner-chart">'+W.__vbars(bars,{fmt:W.__rpK})+'</div>',icons.trend);
    }
    const flags=[missing?'Periode masih berjalan; target adalah target penuh.':'',gaps.length?'Cabang belum terpetakan: '+gaps.map(u=>labels[u]).join(', ')+'.':'',unmapped?'Ada nota yang belum terpetakan dan tidak masuk ringkasan grup.':'',!filtered.length?'Belum ada transaksi tercatat untuk pilihan ini.':''].filter(Boolean);
    html+=card('Cakupan Data','<div class="br-note"><span>Dihitung: '+esc(time)+' WIB</span><span>'+esc(periodTitle)+'</span></div>'+
      (flags.length?'<ul class="br-owner-flags">'+flags.map(f=>'<li>'+esc(f)+'</li>').join('')+'</ul>':'<p class="br-caption">Hanya transaksi yang tercatat dalam cakupan yang dipilih.</p>'),icons.clock);
    html+='</div>';
    if(state.unit==='all')html+='<details class="br-op-detail br-owner-detail"><summary>Lihat rincian seluruh unit dan lampiran</summary>';
    html+='<div class="grid br-units'+(state.unit==='all'?' br-units-all':'')+'">';
    for(const unit of state.unit==='all'?supported:[state.unit]){
      html+=card(labels[unit],attainment(evaluate([unit]),!!state.location)+insight(unit,evaluate([unit]))+
        (!properties.includes(unit)&&!result.branches.some(b=>b.unit===unit)?empty('Belum ada cabang yang dipetakan ke unit ini.'):table(filtered.filter(r=>r.unit===unit))),unitIcon[unit]);
    }
    html+='</div><p class="br-caption">Omzet dari nota POS lunas dan penerimaan properti. Nota yang belum terpetakan ditampilkan terpisah.</p>';
    }
    if(!work){
      for(const unit of ['retail','fnb'].filter(u=>state.unit==='all'||state.unit===u))
        html+=card('Penjualan Kasir Harian · '+labels[unit],dailyTable(unit)+
          detailsTable('Produk dan kategori',productColumns,narrow(result.products,unit),productFields)+
          detailsTable('Kasir, shift dan koreksi',shiftColumns,narrow(result.shifts,unit),shiftFields)+
          detailsTable('Nilai bayar per metode',payColumns,narrow(result.paymentTotals,unit),payFields)+
          '<p class="br-caption">Margin item memakai HPP yang tersimpan di nota sebelum alokasi diskon nota dan pajak. HPP nol atau kosong ditandai belum lengkap. Nilai bayar berasal dari rincian nota lunas, bukan settlement bank. Void dan refund dikelompokkan menurut tanggal nota asal.</p>',icons.sales);
    }
    if(!work&&['all','fnb'].includes(state.unit))html+=card('Pesanan F&B dan Kecepatan Dapur',
      '<p class="br-caption">Tiket berbeda dari jumlah struk. Rata-rata durasi dihitung dari tiket dengan waktu siap tercatat.</p>'+
      detailsTable('Tiket per jenis layanan',['Outlet','Jenis','Tiket','Belum lunas','Batal','Tiket terukur','Rata-rata ke siap'],
        narrow(result.kitchenMetrics,'fnb'),r=>[r.branch,r.kind==='DINE_IN'?'Makan di tempat':'Bungkus',r.tickets,r.open,r.cancelled,r.timed,r.mean_ready===null?'—':r.mean_ready+' menit'])+
      (Array.isArray(result.wasteMetrics)?detailsTable('Bahan terbuang',['Outlet','Bahan','Jumlah','Satuan','Biaya tercatat'],narrow(result.wasteMetrics,'fnb'),
        r=>[r.branch,r.material,r.quantity,r.stock_unit,amountCell(r.waste_cost)]):empty('Data bahan terbuang belum tersedia.')),icons.clock);
    if(!work){
      for(const unit of properties.filter(u=>state.unit==='all'||state.unit===u)){
        const rows=narrow(result.propertyMetrics,unit);
        html+=card('Kamar dan Tagihan · '+labels[unit],
          '<p class="br-caption">Kamar terisi dan deposit adalah posisi saat ini. Reservasi belum aktif serta tagihan belum lunas mengikuti periode pilihan.</p>'+
          detailsTable('Per properti',['Properti','Kamar aktif','Kamar terisi saat ini','Reservasi belum aktif','Tagihan belum lunas','Sisa tagihan','Deposit dipegang'],
            rows,r=>[r.property,r.active_rooms,r.occupied_rooms,r.reserved,r.unpaid_count,amountCell(r.unpaid_amount),amountCell(r.held_deposit)])+
          detailsTable('Umur tagihan belum lunas',['Properti','Lewat tempo','1–30 hari','31–60 hari','>60 hari','Tanpa jatuh tempo','Kontrak berakhir ≤30 hari'],rows,
            r=>[r.property,r.overdue_count,amountCell(r.overdue_30||0),amountCell(r.overdue_60||0),amountCell(r.overdue_older||0),r.undated,r.unit==='kosan'?r.ending:'—'])+
          (unit==='penginapan'?detailsTable('Malam inap terukur',['Properti','Malam dengan check-in tercatat','Inap tanpa waktu check-in'],
            rows,r=>[r.property,r.measured_nights,r.unknown_stays])+'<p class="br-caption">Malam dihitung dari tanggal check-in dan checkout aktual. Riwayat tanpa waktu check-in tidak diperkirakan.</p>':''),icons.user);
      }
    }
    if(state.unit==='all'&&(!work||group)){
      const unassigned=result.branches.filter(b=>!b.unit);
      html+=card('Belum terpetakan',table(filtered.filter(r=>!r.unit))+
        (work&&group&&unassigned.length?'<p>Pilih unit untuk cabang. Seluruh riwayat cabang akan dilaporkan di unit itu dan pemetaan tidak dapat diubah dari halaman ini.</p>'+
          '<div class="br-form">'+label('Cabang','br-map-branch',unassigned.map(b=>opt(b.id,b.name,'')).join(''))+
          label('Unit','br-map-unit',opt('','Pilih unit','')+opt('retail','Retail','')+opt('fnb','F&B',''))+
          '<button type="button" class="btn" id="br-map">Simpan pemetaan</button></div><p id="br-message" role="status"></p>':''));
    }
    if(work&&group&&state.mode==='month'&&(state.unit==='all'||supported.includes(state.unit))){
      html+=card('Target omzet bulanan','<p>Bahaya: kurang dari 50%. Ideal: 50% hingga kurang dari 80%. Aman: mulai 80%. Target tercapai pada 100%.</p>'+
        '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Unit</th><th>Target (rupiah)</th><th></th></tr></thead><tbody>'+
        supported.filter(u=>state.unit==='all'||state.unit===u).map(u=>'<tr><td>'+esc(labels[u])+'</td><td><input aria-label="Target '+esc(labels[u])+'" id="br-target-'+u+'" type="number" min="1" step="1" max="999999999999999" value="'+esc(result.targets.find(t=>t.unit===u)?.amount??'')+'"></td><td><button class="btn" type="button" id="br-save-'+u+'">Simpan</button></td></tr>').join('')+
        '</tbody></table></div><p role="status" id="br-target-message"></p>');
    }
    if(state.unit==='all'||property){
      const rows=(result.receipts||[]).filter(r=>!state.location||'property:'+r.property===state.location);
      const input=(name,id,attrs)=>'<label class="br-field">'+name+'<input id="'+id+'" '+attrs+' required></label>';
      html+=card(work?'Penerimaan Kosan dan Penginapan':'Riwayat Penerimaan Kosan dan Penginapan',(work?'<p>Catat pembayaran sewa atau inap yang sudah diterima. Deposit dan tagihan belum dibayar tidak masuk omzet. Gunakan nomor bukti unik dalam unit.</p>':'')+
      (canEnter?'<form id="br-property-form"><div class="br-form">'+
      label('Unit','br-property-unit',(property?[state.unit]:properties).map(u=>opt(u,labels[u],state.unit)).join(''))+
      input('Nama properti','br-property-name','maxlength="100"'+(grant.property?' readonly value="'+esc(grant.property)+'"':''))+
      input('Nomor bukti','br-property-reference','maxlength="80"')+
      input('Tanggal terima','br-property-date','type="date" min="2000-01-01" max="2100-12-31"')+
      input('Nominal rupiah','br-property-amount','type="number" min="1" max="999999999999999" step="1"')+
      '<button type="submit" class="btn">Simpan penerimaan</button></div></form>':'')+'<p id="br-property-msg" role="status"></p>'+
      '<p>Rincian menampilkan hingga 200 catatan terbaru. Total memakai semua pembayaran aktif.</p>'+
      (rows.length?'<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Tanggal</th><th>Unit</th><th>Properti</th><th>Bukti</th><th>Nominal</th><th>Status</th></tr></thead><tbody>'+
      rows.map(r=>'<tr><td>'+esc(r.paid_on)+'</td><td>'+esc(labels[r.unit])+'</td><td>'+esc(r.property)+'</td><td>'+esc(r.reference)+'</td><td>'+esc(fmt.format(Number(r.amount)))+'</td><td>'+
      (r.voided?'<span class="badge-status s-mut">Dibatalkan</span>':!canVoid?'<span class="badge-status s-ok">Tercatat</span>':'<button type="button" data-br-void="'+esc(r.id)+'" class="btn ghost sm">Batalkan</button>')+'</td></tr>').join('')+
      '</tbody></table></div>':'<p>Belum ada penerimaan pada pilihan ini.</p>'));
    }
    if(!work&&state.unit==='all')html+='</details>';
    if(!work)html+='<dialog id="br-proof-dialog" class="br-proof-dialog"><div class="br-proof-head"><h3 id="br-proof-title">Bukti transaksi</h3><button id="br-proof-close" type="button" class="btn ghost sm">Tutup</button></div><p id="br-proof-scope" class="br-caption"></p><div id="br-proof-body" aria-live="polite"></div><div id="br-proof-pages" class="br-proof-buttons"></div></dialog>';
    if(grant.unit==='all'&&['OWNER','SYSTEM_ADMIN','FINANCE'].includes(grant.role)&&state.unit==='all'&&state.mode==='month'){
      html+=card('Rekonsiliasi dan Versi Laporan','<div id="br-owner-finance" data-month="'+esc(result.start.slice(0,7))+'" data-role="'+esc(grant.role)+'"><p class="br-empty">Memuat status keuangan…</p></div>',icons.money);
    }
    if(work&&grant.role==='SYSTEM_ADMIN'){
      const field=(label,id,type,attrs='')=>'<label class="br-field">'+label+'<input id="'+id+'" type="'+type+'" '+attrs+'></label>';
      html+=card('Kelola Akses Laporan','<p>Buat akun khusus laporan. Akun lama tidak diubah.</p>'+
        '<form id="br-access-form"><div class="br-form">'+
        field('Nama','br-account-name','text','required maxlength="100"')+
        field('Email','br-account-email','email','required maxlength="200"')+
        field('Kata sandi (min. 12 karakter)','br-account-password','password','required minlength="12" autocomplete="new-password"')+
        label('Peran','br-account-role',opt('','Pilih peran','')+Object.entries(grantLabels).filter(([k])=>k!=='SYSTEM_ADMIN').map(([v,n])=>opt(v,n,'')).join(''))+
        label('Unit','br-account-unit',Object.entries(labels).map(([v,n])=>opt(v,n,'')).join(''))+
        field('Properti yang ditugaskan','br-account-property','text','maxlength="100"')+
        label('Outlet F&B','br-account-branch',opt('','Pilih outlet terpetakan','')+kitchenOutlets.map(b=>opt(b.id,b.name,'')).join(''))+
        '<button type="submit" class="btn">Buat akun</button></div></form><p id="br-access-msg" role="status"></p>'+
        (access.accounts.length?'<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Nama &amp; email</th><th>Peran</th><th>Cakupan</th><th>Status</th></tr></thead><tbody>'+
          access.accounts.map(a=>'<tr><td><strong>'+esc(a.name)+'</strong><br><small>'+esc(a.email)+'</small></td><td>'+esc(grantLabels[a.role])+'</td><td>'+esc(labels[a.unit])+(a.property?' · '+esc(a.role==='KITCHEN'?(kitchenOutlets.find(b=>b.id===a.property)?.name||'Outlet yang ditugaskan'):a.property):'')+'</td><td>'+
          (a.active?'<button type="button" class="btn ghost sm" data-br-disable="'+esc(a.id)+'">Nonaktifkan</button>':'<span class="badge-status s-mut">Nonaktif</span>')+'</td></tr>').join('')+
          '</tbody></table></div>':'<p class="br-empty">Belum ada akun khusus laporan.</p>'),icons.user);
    }
    return html+'</div>';
  };
  W.__after.multibisnis=function(){
    const $=id=>document.getElementById(id);
    if(ops)W.__brLoadOps(ops.unit,ops.grant);
    if($('br-owner-finance'))W.__ownerFinance();
    document.querySelectorAll('[data-br-open-op]').forEach(btn=>btn.onclick=()=>{
      state.unit=btn.dataset.brOpenOp;state.location='';W.goto('multibisnis');
    });

    for(const key of ['unit','mode','month','year','location']){
      const el=$('br-'+key);
      if(el)el.onchange=()=>{state[key]=key==='year'||key==='month'?Number(el.value):el.value;if(key==='unit')state.location='';W.goto('multibisnis');};
    }
    document.querySelectorAll('[data-br-owner-unit]').forEach(btn=>btn.onclick=()=>{
      state.unit=btn.dataset.brOwnerUnit;state.location='';W.goto('multibisnis');
    });
    const proof=$('br-proof-dialog');
    document.querySelectorAll('[data-br-proof]').forEach(btn=>btn.onclick=()=>{
      const spec=JSON.parse(btn.dataset.brProof),unit=spec.u,location=spec.l||'',kind=spec.kind||'sales',shift=spec.shift||'';
      const from=spec.d||data.start,to=spec.d?new Date(Date.parse(spec.d)+86400000).toISOString().slice(0,10):data.end;
      let sequence=0;
      $('br-proof-title').textContent=(kind==='bills'?'Tagihan belum lunas':'Bukti transaksi')+' · '+labels[unit];
      $('br-proof-scope').textContent=from+' hingga sebelum '+to+' (WIB) · '+(W.__isDemo()?'Data contoh':'Sesuai hak akses');
      $('br-proof-close').onclick=()=>{sequence++;proof.close();};
      if(!proof.open)proof.showModal();
      const summary=$('br-proof-body'),pages=$('br-proof-pages');
      async function load(page){
        const id=++sequence;
        summary.textContent='Memuat bukti…';pages.replaceChildren();
        try{
          let result;
          if(W.__isDemo()){
            const source=kind==='bills'?(data.propertyMetrics||[]).filter(r=>r.unit===unit&&(!location||r.branch_id===location)).flatMap(r=>{
              const count=Number(r.unpaid_count),amount=Number(r.unpaid_amount);
              return Array.from({length:count},(_,i)=>({date:from,location:r.property,reference:'DEMO-TAGIHAN-'+(i+1),amount:Math.floor(amount/count)+(i<amount%count?1:0),status:i<r.overdue_count?'OVERDUE':'UNPAID'}));
            }):properties.includes(unit)?(data.receipts||[]).filter(r=>r.unit===unit&&(!location||'property:'+r.property===location)&&r.paid_on>=from&&r.paid_on<to)
              .map(r=>({date:r.paid_on,location:r.property,reference:r.reference,status:r.voided?'VOID':'PAID',amount:r.amount})):
              (data.daily||[]).filter(r=>r.unit===unit&&(!location||r.branch_id===location)&&r.day>=from&&r.day<to).flatMap(r=>
                Array.from({length:r.receipts},(_,i)=>({date:r.day,location:r.branch,reference:'DEMO-'+r.day+'-'+(i+1),
                  status:'PAID',amount:Math.floor(r.sales/r.receipts)+(i<r.sales%r.receipts?1:0)})));
            result={items:source.slice((page-1)*50,page*50),hasNext:source.length>page*50};
          }else result=await reportApi('admin/business-reports/evidence?'+new URLSearchParams({unit,location,from,to,page,kind,shift}));
          if(id!==sequence||!proof.open)return;
          const labelsStatus={PAID:'Lunas',VOID:'Batal',REFUNDED:'Refund',TEMPO:'Tempo',OVERDUE:'Lewat tempo',UNDATED:'Tanpa jatuh tempo',UNPAID:'Belum lunas'};
          summary.innerHTML=result.items.length?'<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Tanggal</th><th>Lokasi</th><th>Referensi</th><th>Kasir / Jatuh tempo</th><th>Status</th><th>Metode</th><th class="num">Nilai asal</th></tr></thead><tbody>'+
            result.items.map(row=>'<tr><td>'+esc(row.date)+'</td><td>'+esc(row.location)+'</td><td>'+esc(row.reference||'—')+'</td><td>'+esc(row.cashier||row.due_on||'—')+'</td><td>'+esc(labelsStatus[row.status]||row.status)+'</td><td>'+esc(row.method||'—')+'</td><td class="num">'+esc(fmt.format(Number(row.amount)))+'</td></tr>').join('')+'</tbody></table></div>':
            '<p class="br-empty">Belum ada bukti pada cakupan ini.</p>';
          for(const [title,next,yes] of [['Sebelumnya',page-1,page>1],['Berikutnya',page+1,result.hasNext]])if(yes){
            const b=document.createElement('button');b.type='button';b.className='btn ghost sm';b.textContent=title;b.onclick=()=>load(next);pages.append(b);
          }
        }catch(e){if(id===sequence&&proof.open)summary.textContent=e.message||'Bukti belum dapat dimuat.';}
      }
      load(1);
    });
    if($('br-print'))$('br-print').onclick=()=>{
      document.body.classList.add('br-print-owner');
      window.addEventListener('afterprint',()=>document.body.classList.remove('br-print-owner'),{once:true});
      window.print();
      document.body.classList.remove('br-print-owner');
    };
    const insights=Array.from(document.querySelectorAll('[data-br-insight]'));
    if(!W.__isDemo()&&insights.length){
      const q=new URLSearchParams({unit:state.unit,year:state.year});
      if(state.mode==='month')q.set('month',state.month);
      reportApi('admin/business-reports/insights?'+q).then(({insights:items})=>{
        for(const el of insights){
          const item=items?.[el.dataset.brInsight];
          if(!el.isConnected||!item?.text)continue;
          el.querySelector('p').textContent=item.text;
          el.querySelector('small').textContent=item.source==='gemini'?'Ringkasan Gemini dari data laporan':'Berdasarkan angka laporan';
        }
      }).catch(()=>{});
    }
    if($('br-csv'))$('br-csv').onclick=()=>{
      const quote=v=>'"'+String(v??'').replace(/^[=+\-@\t\r\n]/,"'$&").replaceAll('"','""')+'"';
      const lines=[['Simaung Corporation - Laporan Multibisnis'],['Cakupan',labels[state.unit]],['Mulai (WIB)',data.start],['Sebelum (WIB)',data.end],['Sumber',W.__isDemo()?'Data contoh':'Data operasi tercatat'],[],['Unit','Bulan','Cabang / Properti','Pembayaran','Omzet'],...filtered.map(r=>[labels[r.unit]||'Belum terpetakan',r.period,r.branch,r.receipts,r.sales])];
      const daily=(data.daily||[]).filter(r=>!state.location||r.branch_id===state.location);
      if(daily.length)lines.push([],['Penjualan Kasir Harian','Tanggal WIB','Cabang / Outlet','Struk lunas','Omzet','Rata-rata struk','Metode bayar (struk)'],...daily.map(r=>[labels[r.unit],r.day,r.branch,r.receipts,r.sales,(Number(r.sales)/Number(r.receipts)).toFixed(2),methods(r)]));
      for(const [key,columns,fields] of [
        ['products',['Cabang','Produk','Kategori','Jumlah','Nilai item','HPP item','Margin item'],r=>[r.branch,r.product,r.category,r.quantity,r.item_total,r.no_cost>0?'':r.item_cost,r.no_cost>0?'':Number(r.item_total)-Number(r.item_cost)]],
        ['shifts',['Cabang','Kasir','Shift dibuka (WIB)','Struk','Omzet','Diskon nota','Void','Refund','Nilai nota refund'],r=>[r.branch,r.cashier,r.shift_opened,r.receipts,r.sales,r.discounts,r.voids,r.refunds,r.refunded_sale_value]],
        ['paymentTotals',['Cabang','Metode','Nilai tercatat'],r=>[r.branch,r.method,r.amount]]
      ]){
        const rows=(data[key]||[]).filter(r=>!state.location||r.branch_id===state.location);
        if(rows.length)lines.push([],['Unit',...columns],...rows.map(r=>[labels[r.unit],...fields(r)]));
      }
      const property=(data.propertyMetrics||[]).filter(r=>!state.location||r.branch_id===state.location);
      if(property.length)lines.push([],['Unit','Properti','Kamar aktif saat ini','Kamar terisi saat ini','Reservasi belum aktif (periode)','Tagihan belum lunas (periode)','Sisa tagihan (periode)','Deposit dipegang saat ini'],
        ...property.map(r=>[labels[r.unit],r.property,r.active_rooms,r.occupied_rooms,r.reserved,r.unpaid_count,r.unpaid_amount,r.held_deposit]));
      if(!state.location)lines.push([],['Ringkasan target','Omzet','Target lengkap','Pencapaian (%)','Status'],...activeTargets.map(t=>[labels[t.u],t.actual,t.p===null?'':t.target,t.p===null?'':t.p.toFixed(2),t.band||'Belum lengkap']));
      const url=URL.createObjectURL(new Blob(['\uFEFF'+lines.map(r=>r.map(quote).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));
      const a=document.createElement('a');a.href=url;a.download=(W.__isDemo()?'demo-':'')+'simaung-'+data.unit+'-'+data.start+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    };
    if(!W.__operationsWorkspace)return;
    for(const unit of ['retail','fnb',...properties]){
      const button=$('br-save-'+unit);
      if(button)button.onclick=async()=>{
        const msg=$('br-target-message'),amount=Number($('br-target-'+unit).value);
        if(!Number.isSafeInteger(amount)||amount<1||amount>999999999999999){msg.textContent='Masukkan nominal target yang valid.';return;}
        button.disabled=true;
        try{await reportApi('admin/business-reports/target',{method:'PUT',body:{unit,year:state.year,month:state.month,amount}});W.goto('multibisnis');}
        catch(e){msg.textContent=e.message;button.disabled=false;}
      };
    }
    const form=$('br-property-form');
    if(form)form.onsubmit=async e=>{
      e.preventDefault();
      const val=key=>$('br-property-'+key).value;
      const body={unit:val('unit'),property:val('name'),reference:val('reference'),paidOn:val('date'),amount:Number(val('amount'))};
      const btn=form.querySelector('button');btn.disabled=true;
      try{
        await reportApi('admin/business-reports/property-receipts',{method:'POST',body});
        state.year=Number(body.paidOn.slice(0,4));state.month=Number(body.paidOn.slice(5,7));state.location='';
        W.goto('multibisnis');
      }catch(error){$('br-property-msg').textContent=error.message;btn.disabled=false;}
    };
    document.querySelectorAll('[data-br-void]').forEach(btn=>btn.onclick=async()=>{
      const reason=prompt('Alasan pembatalan penerimaan (3–300 karakter):');
      if(reason===null)return;
      btn.disabled=true;
      try{
        await reportApi('admin/business-reports/property-receipts/'+encodeURIComponent(btn.dataset.brVoid)+'/void',{method:'POST',body:{reason}});
        W.goto('multibisnis');
      }catch(error){$('br-property-msg').textContent=error.message;btn.disabled=false;}
    });
    const accountForm=$('br-access-form');
    if(accountForm){
      const role=$('br-account-role'),unit=$('br-account-unit'),property=$('br-account-property'),branch=$('br-account-branch');
      const sync=()=>{
        const choices=role.value==='OWNER'?['all']:role.value==='UNIT_MANAGER'?['retail','fnb',...properties]:
          role.value==='PROPERTY_STAFF'?properties:role.value==='KITCHEN'?['fnb']:role.value==='RECEPTION'?['penginapan']:role.value==='RENTAL_MANAGER'?['kosan']:Object.keys(labels);
        unit.innerHTML=choices.map(u=>opt(u,labels[u],unit.value)).join('');
        property.required=['PROPERTY_STAFF','RECEPTION','RENTAL_MANAGER'].includes(role.value);
        branch.required=role.value==='KITCHEN';branch.disabled=!branch.required;branch.closest('label').hidden=!branch.required;
        property.disabled=!property.required;
        property.closest('label').hidden=!property.required;
        if(!property.required)property.value='';
      };
      role.onchange=sync;sync();
    }
    if(accountForm)accountForm.onsubmit=async e=>{
      e.preventDefault();
      const body=Object.fromEntries(['name','email','password','role','unit','property'].map(k=>[k,$('br-account-'+k).value]));
      if(!body.role){$('br-access-msg').textContent='Pilih peran akun terlebih dahulu.';return;}
      if(body.role==='KITCHEN')body.property=$('br-account-branch').value;
      const btn=accountForm.querySelector('button');btn.disabled=true;
      try{await W.__api('admin/business-reports/access',{method:'POST',body});W.goto('multibisnis');}
      catch(err){$('br-access-msg').textContent=err.message;btn.disabled=false;}
    };
    document.querySelectorAll('[data-br-disable]').forEach(btn=>btn.onclick=async()=>{
      if(!confirm('Nonaktifkan akses akun laporan ini?'))return;
      btn.disabled=true;
      try{await W.__api('admin/business-reports/access/'+encodeURIComponent(btn.dataset.brDisable),{method:'DELETE'});W.goto('multibisnis');}
      catch(err){$('br-access-msg').textContent=err.message;btn.disabled=false;}
    });
    const map=$('br-map');
    if(map)map.onclick=async()=>{
      const msg=$('br-message'),unit=$('br-map-unit').value,branch=$('br-map-branch');
      if(!unit){msg.textContent='Pilih unit terlebih dahulu.';return;}
      if(!confirm('Petakan seluruh riwayat '+branch.selectedOptions[0].text+' ke '+labels[unit]+'?'))return;
      map.disabled=true;
      try{await reportApi('admin/business-reports/branch',{method:'PUT',body:{branchId:branch.value,unit}});W.goto('multibisnis');}
      catch(e){msg.textContent=e.message;map.disabled=false;}
    };
  };
})(window);
