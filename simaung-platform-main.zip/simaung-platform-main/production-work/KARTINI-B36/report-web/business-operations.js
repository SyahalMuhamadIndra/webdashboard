(function(W){
 'use strict';
 const esc=W.__esc;
 const prefix='admin/business-reports/operations';
 const labels={fnb:'Antrean Dapur',kosan:'Operasional Kosan',penginapan:'Operasional Penginapan'};
 const states={NEW:'Pesanan baru',PREPARING:'Dimasak',READY:'Siap disajikan',SERVED:'Disajikan',BOOKED:'Dipesan',ACTIVE:'Aktif',CLOSED:'Selesai',CANCELLED:'Dibatalkan'};
 const statusTone={NEW:'s-info',PREPARING:'s-warn',READY:'s-ok',SERVED:'s-mut',BOOKED:'s-info',ACTIVE:'s-ok',CLOSED:'s-mut',CANCELLED:'s-danger'};
 const date=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 const money=v=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(Number(v));
 const control=(label,html)=>'<label class="br-field">'+esc(label)+html+'</label>';
 const select=(name,data,selected='')=>'<select name="'+name+'" required>'+data.map(([v,l])=>'<option value="'+esc(v)+'"'+(String(v)===selected?' selected':'')+'>'+esc(l)+'</option>').join('')+'</select>';
 const input=(name,type='text',attrs='')=>'<input name="'+name+'" type="'+type+'" '+attrs+' required>';
 const button=(label,attrs='')=>'<button class="btn sm ghost" type="button" '+attrs+'>'+esc(label)+'</button>';
 const badge=v=>'<span class="badge-status '+(statusTone[v]||'s-mut')+'">'+esc(states[v]||v)+'</span>';
 const section=(title,body)=>'<section class="card br-card"><div class="card-h"><h3>'+esc(title)+'</h3></div><div class="card-b">'+body+'</div></section>';
 const table=(headers,body,empty)=>body.length?'<div class="tbl-wrap"><table class="tbl"><thead><tr>'+headers.map(x=>'<th>'+esc(x)+'</th>').join('')+'</tr></thead><tbody>'+body.join('')+'</tbody></table></div>':'<p class="br-empty">'+esc(empty)+'</p>';
 const fields=xs=>xs.map(x=>'<td>'+x+'</td>').join('');
 const form=(kind,body,label)=>'<form class="br-form" data-op-form="'+kind+'">'+body+'<button class="btn sm" type="submit">'+esc(label)+'</button></form>';
 const op=(name,payload={})=>' data-op="'+name+'" data-payload="'+esc(JSON.stringify(payload))+'"';
 let seq=0;
 const filter={fnb:{date:date(),branch:''},kosan:{month:date().slice(0,7),property:''},penginapan:{month:date().slice(0,7),property:''}};
 function title(grant,unit){
  const prefixText={KITCHEN:'Dapur',RECEPTION:'Resepsionis',RENTAL_MANAGER:'Pengelola Kos'}[grant.role];
  return prefixText?labels[unit]+' · '+prefixText:labels[unit];
 }
 W.__brOpsContainer=(unit,grant)=>section(title(grant,unit),'<div id="br-ops" aria-live="polite"><p class="br-empty">Memuat operasional…</p></div>');
 W.__brLoadOps=async(unit,grant)=>{
  const box=document.getElementById('br-ops');
  if(!box)return;
  const request=++seq;
  const canEdit=grant.role!=='FINANCE';
  const demo=W.__isDemo();
  const api=(suffix,opts)=>W.__api(prefix+suffix,opts);
  async function draw(){
   const nonce=++seq;
   box.setAttribute('aria-busy','true');
   let data;
   try{
    const q=new URLSearchParams({...filter[unit],unit,...(unit!=='fnb'&&grant.property?{property:grant.property}:{})});
    data=demo?seed(unit):await api((unit==='fnb'?'/kitchen':'/property')+'?'+q);
   }catch(e){if(box.isConnected&&nonce===seq)box.innerHTML='<p class="br-empty">'+esc(e.message)+'</p>';return;}
   finally{if(box.isConnected&&nonce===seq)box.removeAttribute('aria-busy');}
   if(!box.isConnected||nonce!==seq)return;
   const mode=unit==='fnb'?'kitchen':'property';
   box.innerHTML='<div class="br-ops-grid">'+(unit==='fnb'?kitchen(data):property(data))+
    '<p role="status" class="br-ops-message" data-op-msg></p>'+(demo?'<p class="br-caption">Ini contoh tampilan operasional; tindakan aktif dari akun produksi yang berwenang.</p>':'')+'</div>';
   box.querySelectorAll('[data-op-filter]').forEach(el=>el.onchange=()=>{
    filter[unit][el.dataset.opFilter]=el.value;draw();
   });
   box.querySelectorAll('[data-op-refresh]').forEach(el=>el.onclick=draw);
   box.querySelectorAll('[data-invoice]').forEach(el=>el.onclick=()=>{
    const bill=data.bills.find(item=>String(item.id)===el.dataset.invoice);
    if(!bill)return;
    const logos={'Mitra Kost':['Mitra Kost','mitra-kost'],'River Inn':['Puteri River Inn','river-inn']};
    const brand=logos[bill.property];
    if(!brand)return;
    const popup=W.open('','_blank');
    if(!popup){box.querySelector('[data-op-msg]').textContent='Izinkan pop-up untuk mencetak invoice.';return;}
    const [name,logo]=brand;
    const status=bill.receipt_voided?'Penerimaan dibatalkan':bill.paid_at?'Lunas':'Belum lunas';
    popup.opener=null;
    popup.document.write('<!doctype html><html lang="id"><meta charset="utf-8"><title>Invoice '+esc(name)+'</title>'+
      '<style>@page{size:A4;margin:20mm}body{font:15px system-ui;color:#18202c;max-width:700px;margin:32px auto;padding:0 16px}img{max-width:180px;height:84px;object-fit:contain;object-position:left center}header{border-bottom:1px solid #cbd5e1;padding-bottom:16px}dl{display:grid;grid-template-columns:145px 1fr;gap:10px}dt{color:#43536a}dd{margin:0}strong{display:block;font-size:23px;margin-top:24px}</style>'+
      '<header><img src="'+W.location.origin+'/assets/'+logo+'.png" alt=""><h1>Invoice '+esc(name)+'</h1></header>'+
      '<dl>'+[['Nomor tagihan',bill.id],['Kamar',bill.code],['Nama',bill.guest],['Periode',bill.period],['Jatuh tempo',bill.due_on||'—'],['Status',status]].map(([label,value])=>'<dt>'+esc(label)+'</dt><dd>'+esc(value)+'</dd>').join('')+
      '</dl><strong>Total '+esc(money(bill.amount))+'</strong></html>');
    popup.document.close();
    const image=popup.document.querySelector('img');
    (image?.decode()||Promise.resolve()).catch(()=>{}).then(()=>{popup.focus();popup.print();});
   });

   if(demo){
    box.querySelectorAll('[data-op], [data-op-form] button').forEach(el=>el.disabled=true);
    return;
   }
   function bind(el,fn){
    el.onclick=async()=>{el.disabled=true;try{await fn();await draw();}catch(e){if(box.isConnected){box.querySelector('[data-op-msg]').textContent=e.message;el.disabled=false;}}};
   }
   box.querySelectorAll('[data-op]').forEach(el=>bind(el,async()=>{
    const action=el.dataset.op,p=JSON.parse(el.dataset.payload||'{}');
    if(action==='booking/status'){
     if(p.to==='CANCELLED'&&!confirm('Batalkan pesanan kamar ini?'))return;
    }
    if(action==='bill/pay'){
     if(!confirm('Catat pelunasan penuh untuk tanggal '+p.paidOn+'?'))return;
    }
    if(action==='deposit'){
     if(p.action==='receive'){
      const v=prompt('Nominal deposit dalam rupiah (angka tanpa pemisah):');
      if(v===null)return;
      if(!/^\d+$/.test(v)||Number(v)<1)throw Error('Nominal deposit tidak valid.');
      p.amount=Number(v);
     }else if(!confirm('Tandai deposit sudah dikembalikan?'))return;
    }
    await api('/'+mode+'/'+action,{method:'POST',body:p});
    if(action==='bill/pay')W.goto('multibisnis');
   }));
   box.querySelectorAll('[data-op-form]').forEach(el=>el.onsubmit=async event=>{
    event.preventDefault();
    const submit=el.querySelector('button'),body=Object.fromEntries(new FormData(el));
    for(const k of ['amount','rate'])if(k in body)body[k]=Number(body[k]);
    body.unit=unit;
    submit.disabled=true;
    try{await api('/'+mode+'/'+el.dataset.opForm,{method:'POST',body});await draw();}
    catch(e){if(box.isConnected){box.querySelector('[data-op-msg]').textContent=e.message;submit.disabled=false;}}
   });
  }
  if(request!==seq)return;
  function kitchen(d){
   const controls='<div class="br-form">'+control('Tanggal','<input type="date" data-op-filter="date" value="'+esc(d.date)+'">')+
    (grant.property?'':control('Outlet','<select data-op-filter="branch"><option value="">Semua outlet F&amp;B</option>'+d.branches.map(b=>'<option value="'+esc(b.id)+'"'+(filter.fnb.branch===b.id?' selected':'')+'>'+esc(b.name)+'</option>').join('')+'</select>'))+
    button('Muat ulang','data-op-refresh')+'</div>';
   const cards=d.tickets.map(t=>{
    const next={NEW:'PREPARING',PREPARING:'READY',READY:'SERVED'}[t.status];
    return '<article class="br-ticket"><header><strong>'+esc(t.code||'Pesanan POS')+'</strong>'+badge(t.status)+'</header>'+
     '<p class="br-caption">'+esc(t.branch)+(t.source==='restaurant'?' · '+esc(t.kind==='DINE_IN'?'Meja '+t.table_code:'Bungkus')+
       ' · '+(t.sale_id?'Sudah dibayar':t.paid_items?.length?'Dibayar sebagian':'Belum dibayar'):'')+'</p><ul>'+t.items.map(i=>'<li>'+esc(i.qty)+' × '+esc(i.name||'Produk')+'</li>').join('')+'</ul>'+
     (next?button(states[next],op('status',{saleId:t.id,from:t.status,to:next,source:t.source})):'')+'</article>';
   }).join('');
   return '<p>Antrean outlet F&amp;B, termasuk pesanan yang dikirim sebelum pembayaran. Status dapur tidak mengubah omzet atau stok.</p>'+controls+
    (cards?'<div class="br-ticket-grid">'+cards+'</div>':'<p class="br-empty">Belum ada pesanan dapur pada tanggal ini.</p>');
  }
  function property(d){
   const kos=unit==='kosan';
   const propertyName=grant.property||filter[unit].property||'';
   const locations=d.properties||[...new Set(d.rooms.map(room=>room.property))];
   let html='<div class="br-form">'+control('Bulan','<input type="month" data-op-filter="month" value="'+esc(d.month)+'">')+
    (grant.property?'':control('Filter properti','<select data-op-filter="property"><option value="">Semua properti</option>'+locations.map(name=>'<option value="'+esc(name)+'"'+(propertyName===name?' selected':'')+'>'+esc(name)+'</option>').join('')+'</select>'))+
    button('Muat ulang','data-op-refresh')+'</div>';
   const propField=control('Properti',!grant.property&&locations.length?select('property',locations.map(name=>[name,name]),propertyName):input('property','text','maxlength="100" value="'+esc(propertyName)+'"'+(grant.property?' readonly':'')));
   if(canEdit){
    html+='<details class="br-op-detail"><summary>Tambah kamar</summary>'+form('room',propField+control('Kode kamar',input('code','text','maxlength="30"')),'Simpan kamar')+'</details>';
    if(d.rooms.length){
     html+='<details class="br-op-detail"><summary>'+(kos?'Buat kontrak kamar':'Buat reservasi')+'</summary>'+
      form('booking',control('Kamar',select('roomId',d.rooms.filter(r=>r.active).map(r=>[r.id,r.property+' · '+r.code])))+
       control(kos?'Nama penghuni':'Nama tamu',input('guest','text','maxlength="100"'))+
       control('Mulai',input('startsOn','date'))+control('Selesai',input('endsOn','date'))+
       control(kos?'Tarif per bulan (Rp)':'Tarif per malam (Rp)',input('rate','number','min="1" step="1"')),
      kos?'Simpan kontrak':'Simpan reservasi')+'</details>';
    }
    if(kos)html+='<details class="br-op-detail"><summary>Terbitkan tagihan sewa bulanan</summary>'+
      '<p>Tarif satu bulan penuh untuk kontrak aktif pada bulan itu. Terbitkan sekali; tidak diprorata.</p>'+
      form('rent/bills',propField+control('Bulan',input('month','month','value="'+esc(d.month)+'"'))+control('Jatuh tempo (opsional)','<input name="dueOn" type="date">'),'Terbitkan tagihan')+'</details>';
   }
   html+='<h4>Kamar</h4>'+table(['Properti','Kamar','Status','Tindakan'],d.rooms.map(r=>'<tr>'+
     fields([esc(r.property),esc(r.code),badge(r.active?'ACTIVE':'Nonaktif'),canEdit?
       button(r.active?'Nonaktifkan':'Aktifkan',op('room/status',{roomId:r.id,active:!r.active})):'—'])+'</tr>'),'Belum ada kamar.');
   if(!kos&&d.rooms.length){
    if(d.bookingLimit)html+='<p class="br-empty">Terlalu banyak reservasi untuk kalender ini. Pilih satu properti.</p>';
    else{
     const [year,month]=d.month.split('-').map(Number), total=new Date(year,month,0).getDate();
     const days=Array.from({length:total},(_,i)=>d.month+'-'+String(i+1).padStart(2,'0'));
     html+='<details class="br-op-detail"><summary>Kalender kamar</summary><p>Terisi atau dipesan dari tanggal masuk sampai sehari sebelum tanggal keluar.</p>'+
       '<div class="tbl-wrap"><table class="tbl br-calendar"><thead><tr><th>Kamar</th>'+days.map(x=>'<th scope="col">'+esc(x.slice(-2))+'</th>').join('')+'</tr></thead><tbody>'+
       d.rooms.map(r=>{
         const bookings=d.bookings.filter(b=>b.room_id===r.id&&b.status!=='CANCELLED');
         return '<tr><th scope="row">'+esc(r.property+' · '+r.code)+'</th>'+days.map(x=>{
          const busy=bookings.some(b=>b.starts_on<=x&&(x<(b.ended_on||b.ends_on)||(b.status==='ACTIVE'&&x<=d.today)));
          const title=busy?'Terisi atau dipesan':r.active?'Kosong':'Nonaktif';
          return '<td title="'+title+'" aria-label="'+title+'" class="'+(busy?'br-busy':!r.active?'br-inactive':'')+'">'+(busy?'●':!r.active?'–':'')+'</td>';
         }).join('')+'</tr>';
       }).join('')+'</tbody></table></div></details>';
    }
   }
   html+='<h4>'+(kos?'Kontrak penghuni':'Reservasi tamu')+'</h4>'+table(['Lokasi','Nama','Periode','Status','Deposit','Tindakan'],d.bookings.map(b=>{
    const canActivate=b.status==='BOOKED'&&d.today>=b.starts_on&&d.today<b.ends_on;
    const canClose=b.status==='ACTIVE'&&(kos||d.today>=b.ends_on);
    const action=canEdit?[
     canActivate?button(kos?'Aktifkan':'Check-in',op('booking/status',{bookingId:b.id,to:'ACTIVE'})):'',
     canClose?button(kos?'Akhiri kontrak':'Check-out',op('booking/status',{bookingId:b.id,to:'CLOSED'})):'',
     b.status==='BOOKED'?button('Batalkan',op('booking/status',{bookingId:b.id,to:'CANCELLED'})):'',
    ].join(' '):'';
    const deposit=b.deposit?esc(money(b.deposit))+(b.deposit_refunded?' · Dikembalikan':' '+button('Kembalikan',op('deposit',{bookingId:b.id,action:'refund'})))
      :['BOOKED','ACTIVE'].includes(b.status)?button('Catat deposit',op('deposit',{bookingId:b.id,action:'receive'})):'—';
    return '<tr>'+fields([esc(b.property+' · '+b.code),esc(b.guest),esc(b.starts_on+' – '+b.ends_on),badge(b.status),deposit,action||'—'])+'</tr>';
   }),'Belum ada kontrak atau reservasi pada periode ini.');
   html+='<h4>Tagihan</h4>'+table(['Lokasi','Nama','Periode','Jatuh tempo','Nominal','Pembayaran','Invoice'],d.bills.map(b=>'<tr>'+fields([esc(b.property+' · '+b.code),esc(b.guest),esc(b.period),esc(b.due_on||'Belum ditetapkan'),
    esc(money(b.amount)),b.receipt_voided?'<span class="badge-status s-danger">Penerimaan dibatalkan · periksa</span>':b.paid_at?'<span class="badge-status s-ok">Lunas</span>':button('Catat lunas',op('bill/pay',{billId:b.id,paidOn:d.today})),!demo&&['Mitra Kost','River Inn'].includes(b.property)?button('Cetak invoice','data-invoice="'+esc(b.id)+'"'):'—'])+'</tr>'),'Belum ada tagihan pada periode ini.');
   return html;
  }
  function seed(unit){
   if(unit==='fnb')return {date:filter.fnb.date,branches:[{id:'demo-fnb',name:'Outlet Contoh'}],tickets:[
    {id:'a',code:'FNB-021',branch:'Outlet Contoh',kind:'DINE_IN',table_code:'A-02',source:'restaurant',status:'PREPARING',items:[{qty:2,name:'Nasi goreng'},{qty:1,name:'Es teh'}]},
    {id:'b',code:'FNB-022',branch:'Outlet Contoh',status:'NEW',items:[{qty:1,name:'Mi goreng'}]},
    {id:'c',code:'FNB-019',branch:'Outlet Contoh',status:'READY',items:[{qty:3,name:'Kopi susu'}]},
   ].filter(t=>!filter.fnb.branch||filter.fnb.branch==='demo-fnb')};
   const kos=unit==='kosan', property=kos?'Kosan Contoh':'Penginapan Contoh',month=filter[unit].month;
   const matches=!filter[unit].property||filter[unit].property===property;
   return {unit,month,today:date(),rooms:matches?[{id:'demo',property,code:'A-01',active:true}]:[],
    bookings:matches?[{id:'demo',room_id:'demo',property,code:'A-01',guest:kos?'Penghuni Contoh':'Tamu Contoh',starts_on:month+'-01',ends_on:month+'-28',status:'ACTIVE',deposit:200000}]:[],
    bills:matches?[{id:'demo',property,code:'A-01',guest:kos?'Penghuni Contoh':'Tamu Contoh',period:month+'-01',amount:kos?1200000:800000}]:[]};
  }
  return draw();
 };
})(window);
