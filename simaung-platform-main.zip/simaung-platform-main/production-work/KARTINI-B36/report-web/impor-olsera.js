(()=>{
 const base='https://api.simaung.com/api/admin/business-reports',el=id=>document.getElementById(id),branch=el('branch'),format=el('input-format'),kind=el('import-kind'),file=el('bundle'),preview=el('preview'),commit=el('commit'),status=el('status'),review=el('review'),confirm=el('confirm');let pending,busy=false,lastBytes;
 const keys=['paid','all','items','daily','returns','repayments','cancellations'];
 const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const money=c=>'Rp '+(Number(c)/100).toLocaleString('id-ID',{maximumFractionDigits:2});
 const path=()=>'/olsera'+(kind.value==='catalog'?'/catalog':'');
 async function api(p,body){const r=await fetch(base+p,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+localStorage.getItem('tk_report_token'),...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});const d=await r.json();if(!r.ok)throw Error(d.message||'Permintaan gagal.');return d;}
 function ready(){return !!branch.value&&(format.value==='bundle'?!!file.files.length:!!el('source-account').value.trim()&&(kind.value==='report'?!!el('report-month').value&&keys.every(k=>el('raw-'+k).files.length):!!el('catalog-date').value&&el('raw-products').files.length&&el('raw-recipes').files.length));}
 function invalidate(){pending=null;lastBytes=null;review.innerHTML='';confirm.checked=false;el('confirm-label').hidden=true;commit.disabled=true;el('download-bundle').disabled=true;preview.disabled=busy||!ready();el('raw-input').hidden=format.value!=='xlsx';el('bundle-input').hidden=format.value!=='bundle';el('report-input').hidden=kind.value!=='report';el('catalog-input').hidden=kind.value!=='catalog';}
 document.querySelectorAll('input,select').forEach(c=>{if(c!==confirm)c.addEventListener('change',invalidate)});el('source-account').addEventListener('input',invalidate);
 confirm.onchange=()=>commit.disabled=busy||!pending||!confirm.checked;
 function lock(yes){busy=yes;document.querySelectorAll('input,select').forEach(c=>c.disabled=yes);preview.disabled=yes||!ready();commit.disabled=yes||!pending||!confirm.checked;}
 preview.onclick=async()=>{
  if(!ready()||busy)return;lock(true);el('download-bundle').disabled=true;status.textContent='Membaca dan mencocokkan file. Seluruh Excel diproses lokal di browser sebelum bundle dikirim ke server Simaung…';
  try{
   let bytes;
   if(format.value==='bundle'){const f=file.files[0];if(f.size>2900000)throw Error('Bundle terkompresi maksimal 2,9 MB.');bytes=new Uint8Array(await f.arrayBuffer());}
   else{
    const config={sourceAccount:el('source-account').value.trim(),branchCode:branch.selectedOptions[0].dataset.code};
    if(kind.value==='report'){
     const [year,month]=el('report-month').value.split('-').map(Number),start=el('report-month').value+'-01',end=new Date(Date.UTC(year,month,1)).toISOString().slice(0,10);
     bytes=(await window.OlseraXlsx.reports(Object.fromEntries(keys.map(k=>[k,el('raw-'+k).files[0]])),{...config,period:{start,end}})).bytes;
    }else bytes=(await window.OlseraXlsx.catalog([...el('raw-products').files],el('raw-recipes').files[0],{...config,asOfDate:el('catalog-date').value})).bytes;
   }
   let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
   const gzipBase64=btoa(binary),value=await api(path()+'/preview',{branch:branch.value,gzipBase64});
   lastBytes=bytes;pending={...value,branchId:branch.value,gzipBase64,path:path()};
   const common='<h2>Pratinjau</h2><p><b>'+esc(value.sourceAccount)+' → '+esc(value.branch.name)+'</b><br>Periode / tanggal '+esc(value.period.start)+' sampai '+esc(value.period.end)+'</p>';
   review.innerHTML=common+(kind.value==='report'?'<p>'+value.counts.receipts+' baris nota · '+value.counts.items+' item · '+value.counts.returns+' retur · '+value.counts.cancellations+' pembatalan</p><p>Penjualan neto sumber: <b>'+money(value.metrics.settledNet)+'</b><br>Tagihan neto termasuk belum bayar: '+money(value.metrics.billedNet)+'<br>Pengembalian (sudah termasuk dalam neto): '+money(value.metrics.returns)+'</p><p>Seluruh pencocokan server lolos. '+(value.alreadyImported?'Arsip identik sudah tersimpan; tidak digandakan.':'Arsip baru akan disimpan terpisah.')+'</p>':'<p><b>STAGING — BELUM AKTIF DI POS</b></p><p>'+value.summary.productNames+' nama produk · '+value.summary.productVariantRows+' baris produk / varian · '+value.summary.recipeRows+' hubungan resep</p><p>Resep terpetakan: '+value.summary.resolvedRecipes+'<br>Perlu tinjau: '+value.summary.recipeIssues+' hubungan resep; '+value.summary.duplicateSkuCount+' SKU duplikat; '+value.summary.blankSkuRows+' baris tanpa SKU.</p><p>Data tetap disimpan sebagai staging untuk ditinjau. Tidak mengubah produk, stok atau checkout aktif.</p><details><summary>Temuan yang perlu ditinjau</summary><ul>'+value.summary.issues.map(x=>'<li>Baris '+x.line+' · '+esc(x.sku)+' · '+esc(x.type)+'</li>').join('')+'</ul></details>')+'<details><summary>File sumber</summary><ul>'+value.sourceFiles.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul></details>';
   el('confirm-label').hidden=false;el('download-bundle').disabled=false;status.textContent='Pratinjau selesai. Periksa pemetaan outlet sebelum menyimpan.';
  }catch(e){pending=null;status.textContent=e.message;}finally{lock(false);}
 };
 el('download-bundle').onclick=()=>{if(!lastBytes)return;const u=URL.createObjectURL(new Blob([lastBytes],{type:'application/gzip'})),a=document.createElement('a');a.href=u;a.download=kind.value==='catalog'?'simaung-katalog-staging.json.gz':'simaung-arsip-laporan.json.gz';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);};
 commit.onclick=async()=>{
  if(!pending||!confirm.checked||busy)return;lock(true);
  try{const d=await api(pending.path+'/commit',{branch:pending.branchId,gzipBase64:pending.gzipBase64,fingerprint:pending.fingerprint,sourceAccount:pending.sourceAccount,reviewed:true});status.textContent=kind.value==='catalog'?'Katalog / resep disimpan sebagai staging. Stok dan produk POS tetap tidak berubah.':d.replayed?'Arsip sudah ada; tidak digandakan.':'Arsip berhasil disimpan. Buka Arsip Penjualan di Pusat Laporan.';pending=null;confirm.checked=false;}
  catch(e){status.textContent=e.message;pending=null;}finally{lock(false);}
 };
 api('/operations/owner-controls').then(d=>{for(const b of d.outlets.filter(x=>x.id)){const o=new Option(b.name+' · '+b.slug,b.id);o.dataset.code=b.code||b.slug.toUpperCase();branch.add(o);}invalidate();}).catch(e=>status.textContent=e.message+' Login melalui /operasional terlebih dahulu.');
})();
