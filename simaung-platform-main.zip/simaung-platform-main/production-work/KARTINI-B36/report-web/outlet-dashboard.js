/* Pusat Laporan Outlet — dashboard client */
(() => {
  const demo = new URLSearchParams(location.search).get('demo') === '1';
  const state = { mode: 'month', year: 2026, month: 10, outlets: 'all', source:'olsera' };
  const root = document.getElementById('root');
  const heroKpi = document.getElementById('hero-kpi');
  const seg = document.getElementById('mode-seg');
  const selMonth = document.getElementById('sel-month');
  const selYear = document.getElementById('sel-year');
  const selOutlet = document.getElementById('sel-outlet');
  const monthCtrl = document.getElementById('month-ctrl');
  const yearCtrl = document.getElementById('year-ctrl');
  const btnRefresh = document.getElementById('btn-refresh');
  const historyMonths=selMonth.innerHTML;
  const accountingMonths=historyMonths;
  function configurePeriods(){
    if(state.source==='history'){
      selMonth.innerHTML=historyMonths;selYear.innerHTML='<option value="2026">2026</option>';
      const selected=[...selMonth.options].find(o=>Number(o.dataset.year)===state.year&&Number(o.value)===state.month);
      if(selected)selected.selected=true;else{state.year=2026;state.month=11;selMonth.value='11';}
    }else if(state.source==='accounting'){
      selMonth.innerHTML=accountingMonths;selYear.innerHTML='<option value="2026">2026</option>';
      state.year=2026;state.month=9;
      const selected=[...selMonth.options].find(o=>Number(o.dataset.year)===state.year&&Number(o.value)===state.month);
      if(selected)selected.selected=true;else{state.month=1;selMonth.value='2026-01';}
    }else{
      const now=new Date(),currentYear=Number(new Intl.DateTimeFormat('en',{timeZone:'Asia/Jakarta',year:'numeric'}).format(now));
      const firstYear=Math.min(currentYear-3,state.year),lastYear=Math.max(currentYear+1,state.year);
      selMonth.innerHTML='';selYear.innerHTML='';
      for(let y=lastYear;y>=firstYear;y--){
        selYear.add(new Option(String(y),String(y),false,y===state.year));
        for(let m=12;m>=1;m--){const o=new Option(new Intl.DateTimeFormat('id-ID',{month:'long',year:'numeric',timeZone:'UTC'}).format(new Date(Date.UTC(y,m-1,1))),y+'-'+String(m).padStart(2,'0'),false,y===state.year&&m===state.month);o.dataset.year=y;o.dataset.month=m;selMonth.add(o);}
      }
    }
  }


  /* ------------------------------------------------------------ formatting */
  const nf = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 });
  const nf1 = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 1 });
  const rp = (n) =>
    n === null || n === undefined || !isFinite(n) ? '—' : 'Rp ' + nf.format(Math.round(n));
  function compact(n) {
    if (n === null || n === undefined || !isFinite(n)) return '—';
    const a = Math.abs(n);
    const s = n < 0 ? '−' : '';
    if (a >= 1e12) return `${s}Rp ${nf1.format(a / 1e12)} T`;
    if (a >= 1e9) return `${s}Rp ${nf1.format(a / 1e9)} M`;
    if (a >= 1e6) return `${s}Rp ${nf1.format(a / 1e6)} jt`;
    if (a >= 1e3) return `${s}Rp ${nf.format(Math.round(a / 1e3))} rb`;
    return `${s}Rp ${nf.format(a)}`;
  }
  const pct = (x) =>
    x === null || x === undefined || !isFinite(x) ? '—' : nf1.format(x * 100) + '%';
  const dmy = (iso) => {
    const d = new Date(iso + 'T00:00:00Z');
    return `${d.getUTCDate()}/${d.getUTCMonth() + 1}`;
  };
  const esc = (s) =>
    String(s == null ? '' : s).replace(/\btk kartini\b/gi, 'Toko Kartini').replace(/[&<>"']/g, (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]),
    );

  function deltaHTML(x, invertGood) {
    if (x === null || x === undefined || !isFinite(x)) return '';
    const flat = Math.abs(x) < 0.005;
    const good = invertGood ? x < 0 : x > 0;
    const cls = flat ? 'flat' : good ? 'up' : 'down';
    const arrow = flat ? '→' : x > 0 ? '▲' : '▼';
    return `<span class="delta ${cls}">${arrow} ${nf1.format(Math.abs(x) * 100)}%</span>`;
  }

  /* ----------------------------------------------------------------- fetch */
  const qs = () => {
    const p = new URLSearchParams({ mode: state.mode, outlets: state.outlets, month: state.month });
    if (state.mode === 'month') {
      p.set('month', state.month);
      p.set('year', state.year);
    } else {
      p.set('year', state.year);
    }
    return p.toString();
  };

  let reqId = 0;
  async function load() {
    const id = ++reqId;
    window.OwnerConsole.cancel();
    window.OlseraReports.cancel();
    document.getElementById('target-progress').closest('section').hidden=true;
    const live=state.source==='live';
    const olsera=state.source==='olsera';
    const accounting=state.source==='accounting';
    document.getElementById('ttl-cashier').closest('article').hidden=!live;
    document.querySelector('.hero .sub').textContent=accounting?'Laporan keuangan bulanan yang diunggah. Data historis dipisahkan dari transaksi POS aktif.':olsera?'Laporan penjualan historis yang sudah dicocokkan. Terpisah dari transaksi POS Simaung yang sedang berjalan.':live?'Omzet, target dan kondisi outlet dari operasional aktif. Telusuri sumber angka sebelum mengambil keputusan.':'Arsip laporan unggahan. Angka historis tidak dijumlahkan dengan transaksi operasional aktif.';
    const foot=document.querySelector('.foot .wrap')||document.querySelector('.foot');
    foot.textContent=demo?'DEMO · Seluruh data dan analisis adalah contoh.':accounting?'Laporan keuangan unggahan · manifest lokal · perlu verifikasi sebelum integrasi database':olsera?'Arsip penjualan terimpor · bukan data real-time · stok dan nota POS tidak diubah':live?'Operasional aktif · sumber POS dan penerimaan properti · periode WIB':'Arsip historis unggahan 19 November 2026 · 7 outlet · Mar–Nov 2026';
    const aiOutput=document.getElementById('owner-ai-result');if(aiOutput)aiOutput.textContent='';
    heroKpi.innerHTML = `<div class="loading-state" style="grid-column:1/-1"><div class="spinner"></div><p>Menghitung ringkasan…</p></div>`;
    root.innerHTML = `<div class="loading-state"><div class="spinner" style="border-top-color:#364152"></div><p>Memuat rincian…</p></div>`;
    try {
      if(state.source==='olsera'){await window.OlseraReports.load({...state},heroKpi,root,demo);return;}
      if(accounting){document.getElementById('target-progress').closest('section').hidden=true;document.getElementById('cashier-daily').closest('article').hidden=true;document.querySelector('.panel-ai').hidden=true;window.DriveAccountingReports.load({...state},heroKpi,root);return;}
      document.getElementById('target-progress').closest('section').hidden=false;document.getElementById('cashier-daily').closest('article').hidden=!live;document.querySelector('.panel-ai').hidden=false;
      if(state.source==='live'){await window.OwnerConsole.load({...state},heroKpi,root,demo);if(id===reqId)loadCashiers(id);return;}
      if(demo){render(window.reportDemo.summary(state));return;}
      const token=localStorage.getItem('tk_report_token');
      if(!token){location.replace('/');return;}
      const res = await fetch('https://api.simaung.com/api/admin/business-reports/outlet-history?' + qs(),{headers:{Authorization:'Bearer '+token}});
      if(!res.ok){if(res.status===401||res.status===403)location.replace('/');throw Error('Laporan gagal dimuat ('+res.status+').');}
      const data = await res.json();
      if (id !== reqId) return;
      render(data);
    } catch (e) {
      root.innerHTML = `<div class="panel"><div class="empty-ok">Gagal memuat data. ${esc(e.message)}</div></div>`;
    }
  }

  /* ---------------------------------------------------------------- render */
  function render(d) {
    const t = d.totals;
    const p = d.previous;
    const rows = d.rows || [];
    const asks = d.asks || [];
    const trend = d.trend || [];
    // kelengkapan dihitung per outlet, bukan dari total laporan lintas outlet
    const missing = rows.reduce(
      (a, r) => a + Math.max(0, (r.expectedWeeks || 0) - (r.weeks || 0)),
      0,
    );

    const dOmzet = p.omzet > 0 ? (t.omzet - p.omzet) / p.omzet : null;
    const dLaba = p.laba ? (t.laba - p.laba) / p.laba : null;

    /* laba confidence caveat */
    const labaCaveat =
      t.labaCoverageOmzet < 0.999
        ? `<span class="caveat" title="Tidak semua laporan mengisi HPP/beban">laba dari ${pct(t.labaCoverageOmzet)} omzet</span>`
        : '';

    const totalIssues = d.issues.critical + d.issues.warning;
    const healthPill =
      totalIssues === 0
        ? '<span class="pill ok">Bersih</span>'
        : d.issues.critical > 0
          ? `<span class="pill crit">${d.issues.critical} kritis</span>`
          : `<span class="pill warn">${d.issues.warning} perlu dicek</span>`;

    /* ---- KPI (dirender ke hero sebagai glass cards) ---- */
    const kpi = `
      <div class="kpi">
        <div class="kpi-label">Omzet</div>
        <div class="kpi-value is-lg">${compact(t.omzet)}</div>
        <div class="kpi-meta">${deltaHTML(dOmzet)} <span>vs ${esc(d.period.prevLabel)}</span></div>
      </div>
      <div class="kpi">
        <div class="kpi-label">Laba bersih</div>
        <div class="kpi-value">${t.laba ? compact(t.laba) : '—'}</div>
        <div class="kpi-meta">${deltaHTML(dLaba)} ${labaCaveat}</div>
      </div>
      <div class="kpi">
        <div class="kpi-label">Margin</div>
        <div class="kpi-value">${pct(t.margin)}</div>
        <div class="kpi-meta"><span>dari omzet yang dilaporkan lengkap</span></div>
      </div>
      <div class="kpi">
        <div class="kpi-label">Kualitas data</div>
        <div class="kpi-value" style="-webkit-text-fill-color:#fff;color:#fff">${healthPill}</div>
        <div class="kpi-meta"><span>${t.weeks} laporan · ${missing > 0 ? `<b>${missing} minggu belum masuk</b>` : 'semua minggu masuk'}</span></div>
      </div>`;
    heroKpi.innerHTML = kpi;

    /* ---- outlet table ---- */
    const tableRows = rows
      .map((r, i) => {
        const labaCell = r.laba ? compact(r.laba) : '<span style="color:var(--faint)">—</span>';
        const conf =
          r.labaConfidence < 0.999
            ? `<div class="outlet-cat" style="color:var(--warn)">laba ${pct(r.labaConfidence)} omzet</div>`
            : '';
        const wkRatio = r.expectedWeeks ? r.weeks / r.expectedWeeks : 1;
        const wkPill =
          wkRatio >= 0.999
            ? `<span class="pill ok">${r.weeks}/${r.expectedWeeks}</span>`
            : `<span class="pill ${wkRatio < 0.6 ? 'crit' : 'warn'}">${r.weeks}/${r.expectedWeeks}</span>`;
        return `<tr>
          <td><div class="outlet-cell"><div class="outlet-emoji">${r.emoji}</div>
            <div style="min-width:0">
              <div class="outlet-name">${esc(r.name)}</div>
              <div class="outlet-cat">${esc(r.category)}${r.weeks ? '' : ''}</div>
              <div class="share-bar" title="${pct(r.share)} dari total"><span style="width:${Math.max(2, r.share * 100).toFixed(1)}%"></span></div>
            </div></div></td>
          <td class="num">${compact(r.omzet)}<div class="outlet-cat">${pct(r.share)}</div></td>
          <td class="num">${labaCell}${conf}</td>
          <td class="num">${pct(r.margin)}</td>
          <td class="num">${deltaHTML(r.deltaOmzet)}</td>
          <td class="num">${wkPill}</td>
          <td class="num">${r.issues > 0 ? `<span class="pill ${r.issues > 3 ? 'crit' : 'warn'}">${r.issues}</span>` : `<span class="pill ok">0</span>`}</td>
        </tr>`;
      })
      .join('');

    /* ---- asks ---- */
    const asksHTML = asks.length
      ? asks
          .map(
            (a) => `<div class="ask sev-${a.sev}">
        <div class="ask-icon"></div>
        <div class="ask-body">
          <div class="ask-outlet">${a.emoji} ${esc(a.outlet)}</div>
          <div class="ask-title">${esc(a.title)}</div>
          <div class="ask-detail">${esc(a.detail)}</div>
          <div class="ask-q">→ ${esc(a.ask)}</div>
        </div></div>`,
          )
          .join('')
      : `<div class="empty-ok">Tidak ada yang perlu dipertanyakan di periode ini.<br><span style="font-size:12px">Angka konsisten dan laporan lengkap.</span></div>`;

    /* ---- trend ---- */
    const trendHTML = trendChart(trend);

    /* ---- outlet detail (accordion) ---- */
    const detailHTML = (d.outletsDetail || [])
      .map((o) => {
        const meta = rows.find((r) => r.id === o.id);
        const weekRows = o.weeks
          .map((w) => {
            const flags = (w.issues || [])
              .filter((i) => i.sev !== 'info')
              .map(
                (i) =>
                  `<span class="week-flag ${i.sev === 'critical' ? 'crit' : ''}">• ${esc(i.text)}</span>`,
              )
              .join('');
            return `<tr>
              <td>${dmy(w.start)}–${dmy(w.end)}</td>
              <td class="num">${compact(w.omzet)}</td>
              <td class="num">${w.laba !== null ? compact(w.laba) : '<span style="color:var(--faint)">—</span>'}</td>
              <td class="num">${w.beban !== null ? compact(w.beban) : '<span style="color:var(--faint)">—</span>'}</td>
              <td class="num">${w.transaksi ? nf.format(w.transaksi) : '—'}</td>
              <td>${flags || '<span style="color:var(--faint)">—</span>'}</td>
            </tr>`;
          })
          .join('');
        return `<div class="outlet-block" data-outlet="${o.id}">
          <div class="outlet-row">
            <svg class="caret" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M9 6l6 6-6 6"/></svg>
            <div class="outlet-row-main">
              <div class="outlet-emoji">${meta ? meta.emoji : '🏪'}</div>
              <div><div class="outlet-name">${esc(o.name)}</div>
                <div class="outlet-cat">${o.weeks.length} laporan mingguan</div></div>
            </div>
            <div class="outlet-row-nums">
              <div><div class="lbl">Omzet</div>${meta ? compact(meta.omzet) : '—'}</div>
              <div><div class="lbl">Laba</div>${meta && meta.laba ? compact(meta.laba) : '—'}</div>
              <div><div class="lbl">Margin</div>${meta ? pct(meta.margin) : '—'}</div>
              <div><div class="lbl">Basket</div>${meta && meta.avgBasket ? compact(meta.avgBasket) : '—'}</div>
            </div>
          </div>
          <div class="week-detail">
            <table class="week-tbl">
              <thead><tr><th>Minggu</th><th class="num">Omzet</th><th class="num">Laba</th><th class="num">Beban</th><th class="num">Trx</th><th>Catatan</th></tr></thead>
              <tbody>${weekRows}</tbody>
            </table>
          </div>
        </div>`;
      })
      .join('');

    root.innerHTML = `
      <div class="section-head">
        <h2 class="section-title">Perlu dipertanyakan</h2>
        <span class="section-note">Hal yang sebaiknya Bapak/Ibu tanyakan ke tim sebelum ambil keputusan</span>
      </div>
      <div class="panel"><div class="ask-list">${asksHTML}</div></div>

      <div class="split" style="margin-top:26px">
        <div>
          <div class="section-head"><h2 class="section-title">Kontribusi per outlet</h2>
            <span class="section-note">Diurutkan dari omzet terbesar</span></div>
          <div class="panel"><div class="tbl-wrap"><table class="tbl">
            <thead><tr>
              <th>Outlet</th><th class="num">Omzet</th><th class="num">Laba</th>
              <th class="num">Margin</th><th class="num">Δ Omzet</th>
              <th class="num">Laporan</th><th class="num">Isu</th>
            </tr></thead>
            <tbody>${tableRows || '<tr><td colspan="7" class="empty-ok">Tidak ada data pada periode ini.</td></tr>'}</tbody>
          </table></div></div>
        </div>
        <div>
          <div class="section-head"><h2 class="section-title">Tren ${state.mode === 'month' ? 'mingguan' : 'bulanan'}</h2>
            <span class="section-note">${esc(d.period.label)}</span></div>
          <div class="panel">${trendHTML}</div>
        </div>
      </div>

      <div class="section-head">
        <h2 class="section-title">Rincian mingguan per outlet</h2>
        <span class="section-note">Klik outlet untuk melihat angka tiap minggu & catatannya</span>
      </div>
      <div class="panel"><div class="detail-grid">${detailHTML || '<div class="empty-ok">Tidak ada data.</div>'}</div></div>
    `;

    root.querySelectorAll('.outlet-row').forEach((el) => {
      el.addEventListener('click', () => el.closest('.outlet-block').classList.toggle('open'));
    });
  }

  /* ----------------------------------------------------------- trend chart */
  function trendChart(series) {
    if (!series.length) return `<div class="empty-ok">Belum ada data tren.</div>`;
    const W = 420, H = 190, PL = 8, PR = 8, PT = 14, PB = 26;
    const maxV = Math.max(...series.map((s) => Math.max(s.omzet, s.laba || 0)), 1);
    const iw = W - PL - PR, ih = H - PT - PB;
    const x = (i) => PL + (series.length === 1 ? iw / 2 : (i / (series.length - 1)) * iw);
    const y = (v) => PT + ih - (v / maxV) * ih;

    const path = (key) =>
      series
        .map((s, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(s[key] || 0).toFixed(1)}`)
        .join(' ');

    const areaPath = `${path('omzet')} L${x(series.length - 1).toFixed(1)},${(PT + ih).toFixed(1)} L${x(0).toFixed(1)},${(PT + ih).toFixed(1)} Z`;

    const dots = series
      .map(
        (s, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(s.omzet).toFixed(1)}" r="3" fill="#364152"/>
        <title>${esc(s.full)}: ${compact(s.omzet)}</title>`,
      )
      .join('');

    const xlabels = series
      .map(
        (s, i) =>
          `<text x="${x(i).toFixed(1)}" y="${H - 7}" text-anchor="middle" font-size="10.5" fill="#8191aa">${esc(s.label)}</text>`,
      )
      .join('');

    return `<div class="trend-wrap">
      <svg class="trend-svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Grafik tren omzet dan laba">
        <defs><linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#364152" stop-opacity=".16"/>
          <stop offset="100%" stop-color="#364152" stop-opacity="0"/>
        </linearGradient></defs>
        <line x1="${PL}" y1="${PT + ih}" x2="${W - PR}" y2="${PT + ih}" stroke="#dce2ea" stroke-width="1.4"/>
        <path d="${areaPath}" fill="url(#grad)"/>
        <path d="${path('omzet')}" fill="none" stroke="#364152" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>
        <path d="${path('laba')}" fill="none" stroke="#F26A1B" stroke-width="2.2" stroke-dasharray="5 4" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>
        ${dots}${xlabels}
      </svg>
      <div class="trend-legend">
        <span class="legend-item"><span class="legend-dot" style="background:#364152"></span>Omzet</span>
        <span class="legend-item"><span class="legend-dot" style="background:#F26A1B"></span>Laba</span>
        <span class="legend-item" style="margin-left:auto;color:var(--faint)">Puncak ${compact(maxV)}</span>
      </div>
    </div>`;
  }

  async function loadCashiers(id){
    const box=document.getElementById('cashier-daily');
    if(!box)return;
    box.innerHTML='<div class="empty-block">Memuat transaksi kasir…</div>';
    try{
      const r=demo?{ok:true,json:async()=>({rows:window.reportDemo.cashiers(state)})}:await fetch('https://api.simaung.com/api/admin/business-reports/cashier-daily?'+qs(),{headers:{Authorization:'Bearer '+localStorage.getItem('tk_report_token')}});
      const data=await r.json();
      if(!r.ok)throw Error(data.message||'Data belum tersedia.');
      if(id!==reqId)return;
      const rows=(data.rows||[]).filter(row=>state.outlets==='all'||row.code.toLowerCase()===state.outlets);
      box.innerHTML=rows.length
        ? '<div class="tbl-wrap"><table class="outlet-table"><thead><tr><th>Tanggal</th><th>Outlet</th><th>Kasir</th><th class="num">Nota lunas</th><th class="num">Penjualan lunas</th><th class="num">Void</th><th class="num">Refund</th></tr></thead><tbody>'
          +rows.map(row=>'<tr>'
            +`<td>${esc(row.day)}</td><td>${esc(row.outlet)}</td><td>${esc(row.cashier)}</td>`
            +`<td class="num">${nf.format(row.receipts||0)}</td><td class="num"><b>${rp(row.sales)}</b></td>`
            +`<td class="num">${row.voids?'<span class="pill crit">'+esc(row.voids)+'</span>':'<span class="pill neutral">0</span>'}</td>`
            +`<td class="num">${row.refunds?'<span class="pill warn">'+esc(row.refunds)+'</span>':'<span class="pill neutral">0</span>'}</td>`
            +'</tr>').join('')
          +'</tbody></table></div>'
        : '<div class="empty-block">Belum ada transaksi POS aktif untuk periode dan outlet ini.</div>';
    }catch(error){if(id===reqId)box.innerHTML='<div class="empty-block">'+esc(error.message)+'</div>';}
  }
  const controls=document.querySelector('.controls');
  const accountingNote=document.createElement('div');accountingNote.className='accounting-source-note';accountingNote.textContent='Sumber unggahan: laporan keuangan bulanan. Tidak semua file memuat transaksi kasir harian.';accountingNote.hidden=true;controls.insertAdjacentElement('afterend',accountingNote);
  accountingNote.style.cssText='max-width:1280px;margin:12px auto;padding:10px 24px;color:#526078;font-size:12px';
  const aiButton=document.getElementById('owner-ai');
  aiButton.onclick=async()=>{
    const output=document.getElementById('owner-ai-result');
    if(state.source==='olsera'){aiButton.disabled=true;output.textContent='Menganalisis arsip penjualan…';const version=reqId;try{const text=await window.OlseraReports.analysis({...state},demo);if(version===reqId)output.textContent=text;}catch(e){if(version===reqId)output.textContent=e.message;}finally{aiButton.disabled=false;}return;}
    if(state.source==='live'){aiButton.disabled=true;output.textContent='Menganalisis operasional aktif…';const version=reqId;try{const text=await window.OwnerConsole.analysis({...state},demo);if(version===reqId)output.textContent=text;}catch(e){if(version===reqId)output.textContent=e.message;}finally{aiButton.disabled=false;}return;}
    if(demo){output.textContent='CONTOH ANALISIS DEMO — bukan respons Gemini langsung. '+window.reportDemo.analysis(state);return;}
    aiButton.disabled=true;output.textContent='Gemini sedang membaca ringkasan historis…';
    try{
      const r=await fetch('https://api.simaung.com/api/admin/business-reports/outlet-history?'+qs()+'&ai=1',{headers:{Authorization:'Bearer '+localStorage.getItem('tk_report_token')}});
      const value=await r.json();
      if(!r.ok)throw Error(value.message||'Analisis belum tersedia.');
      output.textContent=(value.period.label+' · '+value.analysis).replace(/\btk kartini\b/gi,'Toko Kartini');
    }catch(error){output.textContent=error.message;}
    finally{aiButton.disabled=false;}
  };
  /* ----------------------------------------------------------------- wiring */
  seg.addEventListener('click', (e) => {
    const btn = e.target.closest('.seg-btn');
    if (!btn) return;
    state.mode = btn.dataset.mode;
    seg.querySelectorAll('.seg-btn').forEach((b) => {
      const on = b === btn;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    monthCtrl.hidden = state.mode !== 'month';
    yearCtrl.hidden = state.mode !== 'year';
    load();
  });

  selMonth.addEventListener('change', () => {
    const opt = selMonth.selectedOptions[0];
    state.month = Number(opt.dataset.month||selMonth.value);
    state.year = Number(opt.dataset.year);
    load();
  });
  selYear.addEventListener('change', () => {
    state.year = Number(selYear.value);
    load();
  });
  selOutlet.addEventListener('change', () => {
    state.outlets = selOutlet.value;
    load();
  });
  document.getElementById('sel-source').addEventListener('change',e=>{state.source=e.target.value;configurePeriods();accountingNote.hidden=state.source!=='accounting';
    [...selOutlet.options].forEach(o=>{o.hidden=(state.source==='history'&&['sikecut-manis','mitra-kost'].includes(o.value))||(state.source==='accounting'&&['sikecut-manis','mitra-water','river-inn'].includes(o.value));});
    if(selOutlet.selectedOptions[0]?.hidden){state.outlets='all';selOutlet.value='all';}
    load();
  });
  btnRefresh.addEventListener('click', () => {
    btnRefresh.classList.add('is-spinning');
    load().finally(() => setTimeout(() => btnRefresh.classList.remove('is-spinning'), 400));
  });

  if(demo){
    document.querySelector('.eyebrow').textContent='DEMO · SELURUH ANGKA ADALAH DATA DUMMY';
    const right=document.querySelector('.topbar-right');
    if(right){
      right.innerHTML=
        '<span class="tb-meta"><b>DEMO</b> · data dummy</span>'
        +'<a class="tb-btn" href="/">'
        +'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M11 6 5 12l6 6"/><path d="M5 12h14"/></svg>'
        +'Kembali ke Login</a>';
    }
    const foot=document.querySelector('.foot');
    if(foot)foot.innerHTML='<div class="wrap"><span>Simulasi demonstrasi. Tidak membaca atau mengubah data produksi.</span><span>Mode demo · tanpa akun</span></div>';
    aiButton.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15.5l-1.9-4.6L5.5 9l4.6-1.4L12 3Z"/></svg>Lihat contoh analisis';
  }
  configurePeriods();
  load();
})();
