window.OlseraReports=(()=>{
 const api='https://api.simaung.com/api/admin/business-reports/olsera';
 const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const money=x=>x===null||x===undefined?'—':'Rp '+Number(x).toLocaleString('id-ID',{maximumFractionDigits:2});
 const moneyCents=c=>c===null||c===undefined?'—':'Rp '+(Number(c)/100).toLocaleString('id-ID',{maximumFractionDigits:2});
 const outletName=(code,name)=>code==='TK-KARTINI'?'Toko Kartini':name;
 const dt=x=>new Date(x).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'});
 const row=a=>'<tr>'+a.map(x=>'<td>'+x+'</td>').join('')+'</tr>';
 const table=(h,rs)=>'<div class="tbl-wrap"><table class="tbl"><thead><tr>'+h.map(x=>'<th>'+esc(x)+'</th>').join('')+'</tr></thead><tbody>'+rs.join('')+'</tbody></table></div>';
 const panel=(id,title,sub,body)=>'<section class="panel ex-section" id="'+id+'"><header class="panel-head"><div><h2 class="panel-title">'+title+'</h2><p class="panel-sub">'+sub+'</p></div></header><div class="panel-body">'+body+'</div></section>';
 const query=s=>{const q=new URLSearchParams({year:s.year,outlet:s.outlets});if(s.mode==='month')q.set('month',s.month);return q;};
 let generation=0,current;
 async function get(path){const r=await fetch(api+path,{headers:{Authorization:'Bearer '+localStorage.getItem('tk_report_token')}});const d=await r.json();if(!r.ok)throw Error(d.message||'Arsip belum tersedia.');return d;}
 function fixture(s){const y=s.year,m=s.month,b={id:'demo',branch:'Toko Kartini',code:'TK-KARTINI',sourceAccount:'Data contoh demonstrasi',periodStart:y+'-'+String(m).padStart(2,'0')+'-01',importedAt:new Date().toISOString(),counts:{receipts:240,items:610,returns:2,cancellations:3},sources:[{name:'Contoh data dummy',sha256:'dummy'}],checks:[{key:'Contoh pemeriksaan',ok:true}]};return {batches:s.outlets==='all'||s.outlets==='tk-kartini'?[b]:[],totals:{settledNet:'48000000',settledGross:'49000000',settledDiscount:'0',grossRevenue:'49000000',netRevenue:'48000000',billedNet:'55000000',unsettled:'7000000',returns:'1000000',itemNet:'47995000',itemCogs:'33000000',rounding:'5000',creditRepayments:'3000000'},cashiers:[{outlet:'Toko Kartini',day:b.periodStart,cashier:'Kasir Demo',receipts:24,returns:1,net:'1800000'}],daily:[{outlet:'Toko Kartini',day:b.periodStart,amount:'1800000'}],methods:[{outlet:'Toko Kartini',mode:'CASH',amount:'30000000'}],importedMonths:1,expectedMonths:s.mode==='year'?12:1,period:{start:b.periodStart,end:y+'-'+String(m+1).padStart(2,'0')+'-01'}};}
 async function load(s,hero,root,demo){
  const id=++generation;
  try{
   const d=demo?fixture(s):await get('/summary?'+query(s));if(id!==generation)return;current={d,s,demo};
   if(!d.batches.length){hero.innerHTML='<div class="kpi" style="grid-column:1/-1"><div class="kpi-label">ARSIP PENJUALAN</div><div class="kpi-value">Belum ada data impor</div><div class="kpi-meta">Pilih periode / outlet yang sudah diimpor. Tidak ada angka pengganti.</div></div>';root.innerHTML=panel('olsera-empty','Arsip Penjualan Belum Tersedia','Arsip dibaca terpisah dari transaksi POS Simaung.','Belum ada data untuk cakupan ini. Impor dilakukan di ruang pengelolaan.');return;}
   const t=d.totals;
   const gross=t.grossRevenue??t.settledGross??null,net=t.netRevenue??t.settledNet??null;
   hero.innerHTML=[['PENDAPATAN GROSS',gross,'Penjualan lunas sebelum retur; nilai bruto dari arsip'],['PENDAPATAN NET',net,'Nilai neto nota lunas setelah retur dan pembulatan sesuai arsip'],['TOTAL BEBAN OPERASIONAL','—','Belum tersedia pada arsip penjualan ini'],['LABA','—','Net − HPP − beban operasional; belum dihitung karena beban operasional belum tersedia']].map(([a,b,c])=>'<div class="kpi"><div class="kpi-label">'+a+'</div><div class="kpi-value">'+esc(b==='—'?b:money(b))+'</div><div class="kpi-meta">'+esc(c)+'</div></div>').join('');
   root.innerHTML='<div class="ex-toolbar"><span class="pill neutral">'+(demo?'DEMO · DATA DUMMY':'ARSIP PENJUALAN · TEREKONSILIASI')+'</span><div><button class="btn-ghost" id="olsera-csv">Ekspor Ringkasan CSV</button> <button class="btn-ghost" id="olsera-print">Cetak / PDF</button></div></div>'+
    '<p class="ex-note">Data tersedia untuk '+d.importedMonths+' dari '+d.expectedMonths+' bulan pada pilihan ini. Laporan tahunan tidak diekstrapolasi. Arsip tidak dijumlahkan dengan POS aktif atau arsip unggahan lain. Target: <b>Belum dinilai</b>.</p>'+
    panel('olsera-batches','Asal Data & Riwayat Impor','Data historis dipetakan secara eksplisit ke outlet Simaung. Stok dan transaksi POS tidak diubah oleh impor arsip.',table(['Outlet','Sumber data','Bulan','Diimpor','Cakupan','Bukti'],d.batches.map(b=>row([esc(outletName(b.code,b.branch)),esc(b.sourceAccount),esc(b.periodStart.slice(0,7)),esc(dt(b.importedAt)),b.counts.receipts+' baris nota / '+b.counts.items+' item','<button class="btn-ghost" data-batch="'+esc(b.id)+'">Lihat rincian</button><details><summary>File & pemeriksaan</summary><ul>'+b.sources.map(x=>'<li>'+esc(x.name)+'<br><small>'+esc(x.sha256)+'</small></li>').join('')+'</ul>'+b.checks.map(c=>'<p>'+esc(c.key)+' · '+(c.ok?'Cocok':'Perlu periksa')+'</p>').join('')+'</details>']))))+
    panel('olsera-reconcile','Pencocokan Angka','Rumus laba: pendapatan net − HPP − beban operasional outlet. Arsip penjualan tidak membawa beban operasional, jadi laba belum dihitung agar tidak mengarang nilai.',table(['Komponen','Nilai','Keterangan'],[
     row(['Pendapatan gross',money(gross),'Penjualan nota lunas sebelum diskon dan retur']),
     row(['Pendapatan net',money(net),'Nilai acuan laporan sumber; diskon dan retur tidak dihitung ulang']),
     row(['HPP item',money(t.itemCogs),'Biaya pokok barang dari data item; terpisah dari beban operasional']),
     row(['Total beban operasional outlet','Belum tersedia','Belum ada rincian beban operasional yang terhubung dengan arsip penjualan ini']),
     row(['Laba', 'Belum dapat dihitung','Pendapatan net − HPP − beban operasional outlet']),
     row(['Nilai item neto',money(t.itemNet),'Sudah memuat item retur negatif']),
     row(['Pembulatan nota',money(t.rounding),'Ditambahkan sekali ke nilai item']),
     row(['HPP item',money(t.itemCogs),'HPP historis dalam ekspor']),
     row(['Margin item sebelum pembulatan',money(Number(t.itemNet)-Number(t.itemCogs)),'Bukan laba bersih setelah beban operasional']),
     row(['Pelunasan kredit',money(t.creditRepayments),'Sudah termasuk laporan; tidak ditambahkan ulang']),
     row(['Pengembalian',money(t.returns),'Sudah menjadi nilai negatif pada nota/item; tidak dikurangkan ulang'])
    ]))+
    panel('olsera-cashiers','Kasir / Penjual per Hari','Nama mengikuti field sales name / served by ekspor; bukan bukti shift sudah ditutup.',table(['Outlet','Tanggal','Kasir / penjual','Nota positif','Retur','Penjualan neto'],d.cashiers.map(c=>row([esc(outletName(c.code,c.outlet)),esc(c.day),esc(c.cashier),esc(c.receipts),esc(c.returns),money(c.net)]))))+
    panel('olsera-daily','Penjualan Harian Sumber','Baris mengikuti kelompok/kategori pada data sumber; satu tanggal dapat tampil pada beberapa baris.',table(['Outlet','Tanggal','Penjualan neto'],d.daily.map(r=>row([esc(outletName(r.code,r.outlet)),esc(r.day),money(r.amount)]))))+
    panel('olsera-methods','Metode pada Nota Sumber','Metode TEMPO dapat muncul untuk nota kredit yang dilunasi. Ini pengelompokan field nota, bukan mutasi bank/settlement.',table(['Outlet','Metode','Nilai neto'],d.methods.map(m=>row([esc(outletName(m.code,m.outlet)),esc(m.mode),money(m.amount)]))))+'<div id="olsera-evidence"></div>';
   root.querySelectorAll('[data-batch]').forEach(b=>b.onclick=()=>evidence(b.dataset.batch,'receipts',1,demo));
   document.getElementById('olsera-print').onclick=()=>window.print();
   document.getElementById('olsera-csv').onclick=()=>{
    const lines=[['Sumber','Simaung · arsip penjualan','Cakupan bulan',d.importedMonths+'/'+d.expectedMonths],['Ukuran','Rupiah'],['Pendapatan gross',gross],['Pendapatan net',net],['HPP item',t.itemCogs],['Beban operasional outlet','Belum tersedia'],['Laba','Belum dapat dihitung: net − HPP − beban operasional'],['Data sumber','settledNet',t.settledNet],['Data sumber','settledGross',t.settledGross],['Data sumber','returns',t.returns],['Data sumber','itemCogs',t.itemCogs]],cell=x=>'"'+String(x??'').replace(/^[=+@\-\t\r]/,"'").replace(/"/g,'""')+'"';
    const u=URL.createObjectURL(new Blob(['\uFEFF'+lines.map(r=>r.map(cell).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=u;a.download='Simaung-Arsip-Penjualan-'+s.year+(s.mode==='month'?'-'+s.month:'')+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);
   };
  }catch(e){if(id===generation){hero.innerHTML='<p>Arsip penjualan belum tersedia.</p>';root.innerHTML='<p class="ex-note">'+esc(e.message)+'</p>';}}
 }
 let evidenceVersion=0;
 async function evidence(batch,kind,page,demo,reference=''){
  const box=document.getElementById('olsera-evidence');if(!box)return;const id=++evidenceVersion;box.textContent='Memuat rincian sumber…';box.scrollIntoView({behavior:'smooth'});
  try{
   const q=new URLSearchParams({kind,page,reference}),d=demo?{items:[{reference:'DEMO-001',day:'2026-10-01',cashier:'Kasir Demo',amount:'15000000',kind:'SALE',paid:true,includedInSettledReport:true}],page:1,hasNext:false,total:1}:await get('/batches/'+encodeURIComponent(batch)+'/rows?'+q);
   if(id!==evidenceVersion||!box.isConnected)return;
   box.innerHTML=panel('olsera-evidence-panel','Bukti Data Sumber','Halaman '+page+' · '+d.total+' baris sesuai filter · nilai baris dari arsip impor.', '<label>Jenis bukti <select id="olsera-kind">'+Object.entries({receipts:'Nota',items:'Item barang',returns:'Pengembalian',cancellations:'Pembatalan',repayments:'Pelunasan kredit'}).map(([v,l])=>'<option value="'+v+'"'+(v===kind?' selected':'')+'>'+l+'</option>').join('')+'</select></label>'+table(['Nomor sumber','Tanggal','Kasir / item','Jenis / status','Nilai'],d.items.map(r=>row([esc(r.reference),esc(r.day),esc(r.cashier||r.name||r.mode||'—'),esc(r.kind||kind)+(typeof r.includedInSettledReport==='boolean'?'<div class="panel-sub">Cakupan '+(r.includedInSettledReport?'Telah Bayar':'+Belum Bayar')+' · field paid='+r.paid+'</div>':''),moneyCents(r.amount)])))+'<div class="ex-toolbar" id="olsera-paging"></div>');
   document.getElementById('olsera-kind').onchange=e=>evidence(batch,e.target.value,1,demo);
   const nav=document.getElementById('olsera-paging');for(const [label,p,show]of [['Sebelumnya',page-1,page>1],['Berikutnya',page+1,d.hasNext]])if(show){const b=document.createElement('button');b.className='btn-ghost';b.textContent=label;b.onclick=()=>evidence(batch,kind,p,demo,reference);nav.append(b);}
  }catch(e){if(id===evidenceVersion)box.textContent=e.message;}
 }
 return {load,cancel:()=>{generation++;evidenceVersion++;},analysis:async(s,demo)=>demo?'CONTOH DEMO: angka berasal dari arsip data historis. Retur dan pelunasan kredit sudah masuk ke angka neto; keduanya tidak boleh dihitung ulang.':(await get('/analysis?'+query(s))).analysis};
})();
