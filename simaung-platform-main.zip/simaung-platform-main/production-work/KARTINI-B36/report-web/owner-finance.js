(function(W){
 'use strict';
 const esc=W.__esc,labels={retail:'Retail',fnb:'F&B',kosan:'Kosan',penginapan:'Penginapan'};
 const fmt=new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:2});
 const tag=(label,tone='s-info')=>'<span class="badge-status '+tone+'">'+esc(label)+'</span>';
 const table=(heads,rows)=>'<div class="tbl-wrap"><table class="tbl"><thead><tr>'+heads.map(h=>'<th>'+esc(h)+'</th>').join('')+'</tr></thead><tbody>'+rows.join('')+'</tbody></table></div>';
 const row=fields=>'<tr>'+fields.map(x=>'<td>'+x+'</td>').join('')+'</tr>';
 const root='admin/business-reports/owner-finance';
 const cash=x=>x===null||x===undefined?'—':fmt.format(Number(x));
 const field=(label,body)=>'<label class="br-field">'+esc(label)+body+'</label>';
 const today=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 W.__ownerFinance=async function(){
  const box=document.getElementById('br-owner-finance');
  if(!box)return;
  const demo=W.__isDemo(),work=W.__operationsWorkspace===true,month=box.dataset.month;
  const canClose=['SYSTEM_ADMIN','OWNER'].includes(box.dataset.role);
  const api=(path,body)=>W.__api(root+path,body?{method:'POST',body}:undefined);
  let generation=0;
  async function draw(){
   const seq=++generation;
   let data;
   box.setAttribute('aria-busy','true');
   try{
    data=demo?{
     settlements:[
      {unit:'retail',branch:'Toko Contoh',pos_day:month+'-03',method:'QRIS',recorded:1500000,received:1489500,fee:10500,difference:0,evidence:'DEMO-SET-03',version:1},
      {unit:'fnb',branch:'Outlet Contoh',pos_day:month+'-04',method:'TRANSFER',recorded:850000,received:800000,fee:0,difference:-50000,evidence:'DEMO-SET-04',version:2},
      {unit:'fnb',branch:'Outlet Contoh',pos_day:month+'-06',method:'QRIS',recorded:500000,received:null,fee:null,difference:null},
     ],
     versions:month<today().slice(0,7)?[{version:1,month:month+'-01',approved_at:today()+'T01:00:00Z',reason:'Contoh versi disetujui.',approved_by:'Owner Contoh',
      report:[{unit:'retail',actual:10000000,transactions:124,target:10000000},{unit:'fnb',actual:6000000,transactions:88,target:8000000},
        {unit:'kosan',actual:4000000,transactions:8,target:5000000},{unit:'penginapan',actual:2900000,transactions:6,target:5500000}]}]:[]
    }:await api('?month='+encodeURIComponent(month));
   }catch(error){
    if(box.isConnected&&seq===generation)box.innerHTML='<p class="br-empty">'+esc(error.message||'Data rekonsiliasi belum tersedia.')+'</p>';
    return;
   }finally{if(box.isConnected&&seq===generation)box.removeAttribute('aria-busy');}
   if(!box.isConnected||seq!==generation)return;
   const statuses=data.settlements.reduce((a,r)=>{
    const key=r.difference==null?'Missing':Number(r.difference)===0?'Match':'Diff';a[key]++;return a;
   },{Missing:0,Match:0,Diff:0});
   box.innerHTML='<p class="br-caption">Bandingkan nilai pada nota lunas dengan bukti setoran yang dicatat tim. Selisih = dana masuk + biaya tercatat − nilai POS. Bank tidak terhubung otomatis.</p>'+
    '<p class="br-status">'+tag(statuses.Match+' cocok','s-ok')+tag(statuses.Diff+' selisih','s-danger')+tag(statuses.Missing+' belum dicocokkan','s-warn')+'</p>'+
    (data.settlements.length?'<details class="br-op-detail"><summary>Rincian setoran per outlet dan hari</summary>'+
     table(['Tanggal nota','Outlet','Metode','Nilai POS','Dana masuk','Biaya','Selisih','Bukti','Versi'],data.settlements.map(r=>row([
       esc(r.pos_day),esc(r.branch),esc(r.method),esc(cash(r.recorded)),esc(cash(r.received)),esc(cash(r.fee)),
       r.difference==null?tag('Belum dicek','s-warn'):esc(cash(r.difference)),esc(r.evidence||'—'),esc(r.version||'—')
     ])))+'</details>':'<p class="br-empty">Belum ada transaksi nontunai yang dapat dicocokkan.</p>')+
    (data.limited?'<p class="br-caption">Ringkasan setoran dibatasi pada 1.000 baris pertama.</p>':'')+
    (work&&data.settlements.length?'<details class="br-op-detail"><summary>Catat bukti setoran</summary><form class="br-form" id="br-fin-bank">'+
      field('Outlet · hari · metode','<select name="source" required>'+data.settlements.map((r,i)=>'<option value="'+i+'">'+esc(r.branch+' · '+r.pos_day+' · '+r.method)+'</option>').join('')+'</select>')+
      field('Dana masuk (Rp)','<input name="received" type="number" min="0" step="1" required>')+
      field('Biaya (Rp)','<input name="fee" type="number" min="0" step="1" value="0" required>')+
      field('Referensi bukti','<input name="evidence" maxlength="100" required>')+
      field('Alasan','<input name="reason" minlength="5" maxlength="300" required>')+
      '<button type="submit" class="btn sm"'+(demo?' disabled':'')+'>Simpan pemeriksaan</button></form></details>':'')+
    '<h4>Riwayat pengesahan laporan</h4><p class="br-caption">Snapshot menyimpan angka saat disahkan. Ini tidak mengunci transaksi atau periode jurnal. Koreksi yang mengubah angka dapat disahkan sebagai versi baru.</p>'+
    (data.versions.length?data.versions.map((v,i)=>{
      const prior=data.versions[i+1]?.report||[];
      return '<details class="br-op-detail"'+(i===0?' open':'')+'><summary>Versi '+esc(v.version)+' · '+esc(new Intl.DateTimeFormat('id-ID',{timeZone:'Asia/Jakarta',dateStyle:'medium',timeStyle:'short'}).format(new Date(v.approved_at)))+' WIB</summary>'+
        '<p>'+esc(v.reason)+' · Disahkan '+esc(v.approved_by||'—')+'</p>'+table(['Unit','Aktual','Transaksi','Target','Perubahan vs versi sebelumnya'],v.report.map(r=>{
         const old=prior.find(o=>o.unit===r.unit);
         return row([esc(labels[r.unit]),esc(cash(r.actual)),esc(r.transactions),esc(cash(r.target)),esc(old?cash(Number(r.actual)-Number(old.actual)):'—')]);
        }))+'</details>';
    }).join(''):
      '<p class="br-empty">Belum ada versi yang disahkan untuk bulan ini.</p>')+
    (work&&canClose&&month<today().slice(0,7)?'<form id="br-fin-close" class="br-form">'+
      field('Alasan pengesahan atau revisi','<input name="reason" minlength="5" maxlength="300" required>')+
      '<label class="br-fin-confirm"><input name="reviewed" type="checkbox" required> Saya sudah memeriksa hasil periode ini.</label>'+
      '<button type="submit" class="btn sm"'+(demo?' disabled':'')+'>Sahkan snapshot</button></form>':'')+
    '<p class="br-ops-message" role="status" id="br-fin-msg"></p>';
   if(work&&!demo){
    const node=id=>box.querySelector('#'+id);
    const bind=(id,doWrite)=>{
     const form=node(id);
     if(form)form.onsubmit=async e=>{
      e.preventDefault();
      const input=Object.fromEntries(new FormData(form)),btn=form.querySelector('button');
      btn.disabled=true;
      try{ await doWrite(input);await draw(); }
      catch(err){if(box.isConnected){node('br-fin-msg').textContent=err.message;btn.disabled=false;}}
     };
    };
    bind('br-fin-bank',input=>{
     const r=data.settlements[Number(input.source)];
     return api('/settlement',{branch:r.branch_id,posDay:r.pos_day,method:r.method,received:Number(input.received),fee:Number(input.fee),evidence:input.evidence,reason:input.reason});
    });
    bind('br-fin-close',input=>api('/close',{month,reason:input.reason,reviewed:input.reviewed==='on'}));
   }
  }
  await draw();
 };
})(window);
