/* =====================================================================
   SIMAUNG CORPORATION — PUSAT LAPORAN (Report Hub)
   Konfigurasi alamat API. SATU backend untuk semua aplikasi Simaung Corporation.
   ---------------------------------------------------------------------
   • Data POS / Shift / Opname / Ops  →  https://api.tokokartini.com/api
   • Data Absensi                      →  https://api.tokokartini.com/api
   • Data Jurnal / Keuangan            →  diproksi melalui /j/ (Vercel rewrite)
                                          ke https://jurnal.tokokartini.com/api
                                          (menghindari batasan CORS)
   ===================================================================== */
window.__API_BASE__     = 'https://api.tokokartini.com/api/';
window.__JURNAL_BASE__  = '/j/';
window.__COMPANY_ID__   = 'a4b32ac6-b744-4453-9bc9-04e1fc0b9217';
window.__APP_VERSION__  = '4.0.0';
