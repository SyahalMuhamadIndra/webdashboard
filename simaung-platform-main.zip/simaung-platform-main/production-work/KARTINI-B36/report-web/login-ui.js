/* Pusat Laporan — polesan UI halaman login (tanpa mengubah logika doLogin) */
(function () {
  'use strict';
  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }
  ready(function () {
    /* 1. Toggle lihat/sembunyikan password */
    var pass = document.getElementById('lg-pass');
    var toggle = document.getElementById('pw-toggle');
    if (pass && toggle) {
      toggle.addEventListener('click', function () {
        var show = pass.type === 'password';
        pass.type = show ? 'text' : 'password';
        toggle.textContent = show ? 'Sembunyi' : 'Lihat';
        toggle.setAttribute('aria-pressed', show ? 'true' : 'false');
        pass.focus({ preventScroll: true });
      });
    }

    /* 2. Status tombol submit yang konsisten dengan pesan galat */
    var btn = document.getElementById('lg-btn');
    var msg = document.getElementById('lg-msg');
    if (btn && msg) {
      var obs = new MutationObserver(function () {
        var busy = /Menghubungkan/i.test(msg.textContent || '');
        btn.setAttribute('aria-busy', busy ? 'true' : 'false');
        btn.disabled = busy;
      });
      obs.observe(msg, { childList: true, characterData: true, subtree: true });
    }

    /* 3. Sinkronkan nomor versi di panel brand */
    var v = document.getElementById('aa-ver');
    if (v && window.__APP_VERSION__) v.textContent = window.__APP_VERSION__;

    /* 4. Enter di field email langsung ke password */
    var email = document.getElementById('lg-email');
    if (email && pass) {
      email.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); pass.focus(); }
      });
    }

    /* 5. Bersihkan pesan galat saat pengguna mulai mengetik lagi */
    ['lg-email', 'lg-pass'].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el || !msg) return;
      el.addEventListener('input', function () {
        if (msg.textContent && !/Menghubungkan/i.test(msg.textContent)) msg.textContent = '';
      });
    });
  });
})();
