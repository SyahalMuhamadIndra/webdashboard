(()=>{
 const base='https://api.simaung.com/api/admin/business-reports',root=document.getElementById('manage-root'),message=document.getElementById('manage-message');
 const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const option=(v,n)=>'<option value="'+esc(v)+'">'+esc(n)+'</option>';
 const field=(label,body)=>'<label>'+label+body+'</label>';
 const input=(name,type='text',extra='')=>'<input name="'+name+'" type="'+type+'" '+extra+' required>';
 const card=(title,body)=>'<section class="panel"><h2>'+title+'</h2>'+body+'</section>';
 const money=x=>'Rp '+Number(x).toLocaleString('id-ID');
 let data;
 const today=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 async function api(path,body){const r=await fetch(base+path,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+localStorage.getItem('tk_report_token'),...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});const d=await r.json();if(!r.ok)throw Error(d.message||'Permintaan gagal.');return d;}
 function table(heads,rows){return '<div class="table-list"><table class="tbl"><thead><tr>'+heads.map(x=>'<th>'+esc(x)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map(x=>'<td>'+esc(x)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';}
 async function draw(){
  root.setAttribute('aria-busy','true');
  try{
   data=await api('/operations/owner-controls');
   const outlets=data.outlets.map(o=>option(o.key,o.name)).join(''),accounts=data.accounts.map(a=>option(a.id,a.name+' · '+a.email)).join('');
   root.innerHTML='<div class="manage-grid">'+
   card('Target Bulanan per Outlet','<p>Target tahunan dihitung dari 12 target bulanan. Bulan yang belum diisi tidak dianggap nol.</p><form id="target-form">'+field('Outlet','<select name="outlet">'+outlets+'</select>')+field('Bulan',input('period','month','value="'+today.slice(0,7)+'"'))+field('Target omzet (Rp)',input('amount','number','min="1" max="999999999999999" step="1"'))+'<button>Simpan Target</button></form>')+
   card('Tindak Lanjut & PIC','<form id="action-form">'+field('Tugas','<select id="action-select"><option value="">Buat tugas baru</option>'+data.actions.map(a=>option(a.id,a.title)).join('')+'</select>')+field('Outlet','<select name="outlet">'+option('all','Seluruh unit')+outlets+'</select>')+field('Judul',input('title','text','maxlength="300"'))+field('Penanggung jawab','<select name="assignee">'+accounts+'</select>')+field('Tenggat',input('dueOn','date','value="'+today+'"'))+field('Status','<select name="status"><option value="OPEN">Terbuka</option><option value="IN_PROGRESS">Dikerjakan</option><option value="DONE">Selesai (wajib bukti)</option></select>')+field('Referensi bukti / hasil penyelesaian','<textarea name="evidence" maxlength="1000"></textarea>')+'<button>Simpan Tindak Lanjut</button></form>')+
   card('Snapshot Bulanan','<p>Hanya bulan yang sudah selesai. Periksa data dan rekonsiliasi sebelum mengesahkan. Snapshot menyimpan ringkasan per jenis bisnis pada versi tersebut.</p><form id="close-form">'+field('Bulan',input('month','month'))+field('Alasan / hasil pemeriksaan',input('reason','text','minlength="5" maxlength="300"'))+'<label style="display:flex;align-items:center"><input style="width:auto" type="checkbox" name="reviewed" required> Saya sudah memeriksa data periode ini</label><button>Sahkan Snapshot</button></form>')+
   card('Rekonsiliasi Non-Tunai','<p>Catat nominal yang benar-benar diterima dan referensi bukti. Tidak mengambil saldo bank secara otomatis.</p><form id="settlement-form">'+field('Outlet POS','<select name="branch">'+data.outlets.filter(o=>o.id).map(o=>option(o.id,o.name)).join('')+'</select>')+field('Tanggal transaksi',input('posDay','date','value="'+today+'" max="'+today+'"'))+field('Metode','<select name="method">'+['QRIS','TRANSFER','DEBIT','CREDIT','EWALLET'].map(x=>option(x,x)).join('')+'</select>')+field('Diterima (Rp)',input('received','number','min="0" step="1"'))+field('Biaya (Rp)',input('fee','number','min="0" step="1" value="0"'))+field('Referensi bukti',input('evidence','text','maxlength="100"'))+field('Alasan pemeriksaan',input('reason','text','minlength="5" maxlength="300"'))+'<button>Simpan Rekonsiliasi</button></form>')+'</div>'+
   card('Target Tersimpan',table(['Outlet','Bulan','Target'],data.targets.map(t=>[data.outlets.find(o=>o.key===t.outlet)?.name||t.outlet,t.period,money(t.amount)])))+
   card('Jejak Perubahan Terbaru',table(['Jenis','Catatan','Pelaku','Waktu'],data.audit.map(a=>[a.kind,a.record,a.actor_name||'—',new Date(a.created_at).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})])));
   const selected=document.getElementById('action-select'),form=document.getElementById('action-form');selected.onchange=()=>{const a=data.actions.find(x=>x.id===selected.value);form.reset();selected.value=a?.id||'';if(a)for(const [key,v] of Object.entries({outlet:a.outlet,title:a.title,assignee:a.assignee,dueOn:a.due_on.slice(0,10),status:a.status,evidence:a.evidence}))form.elements.namedItem(key).value=v;};
   bind('target-form','/operations/owner-controls/target',b=>({...b,amount:Number(b.amount)}));
   bind('action-form','/operations/owner-controls/action',b=>{const a=data.actions.find(x=>x.id===selected.value);return {...b,...(a?{id:a.id,version:a.version}:{})};});
   bind('close-form','/owner-finance/close',b=>({...b,reviewed:b.reviewed==='on'}));
   bind('settlement-form','/owner-finance/settlement',b=>({...b,received:Number(b.received),fee:Number(b.fee)}));
  }catch(e){message.textContent=e.message+' Jika sesi belum tersedia, buka Operasional / Login terlebih dahulu.';}
  finally{root.removeAttribute('aria-busy');}
 }
 function bind(id,path,convert){const form=document.getElementById(id);form.onsubmit=async e=>{e.preventDefault();const btn=form.querySelector('button');btn.disabled=true;message.textContent='Menyimpan…';try{await api(path,convert(Object.fromEntries(new FormData(form))));message.textContent='Berhasil disimpan. Riwayat perubahan dapat diperiksa di bawah.';await draw();}catch(e){message.textContent=e.message;}finally{btn.disabled=false;}};}
 draw();
})();
