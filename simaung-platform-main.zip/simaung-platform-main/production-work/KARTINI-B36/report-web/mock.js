/* =====================================================================
   SIMAUNG CORPORATION — PUSAT LAPORAN · MODE DEMO (mock.js)
   ---------------------------------------------------------------------
   Data contoh (deterministik) agar seluruh halaman Pusat Laporan bisa
   dinilai tanpa backend live — dipakai lewat tombol "Lihat Demo (Data
   Contoh)" pada layar masuk, atau otomatis bila API live tak dijangkau.

   TIDAK menggantikan backend. Semua angka hanyalah ilustrasi.
   Aktif hanya saat window.__REPORT_DEMO__ === true.

   Kontrak: window.REPORTMOCK.api(path, opts) -> Promise<data>
   - path  : relative terhadap __API_BASE__ (mis. 'admin/attendance?date=...')
   - data  : objek JSON yang sama bentuknya dengan respons backend asli
   ===================================================================== */
(function () {
  'use strict';

  /* ==================== UTILITAS ==================== */
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function isoOf(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function addDays(iso, days) { var d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + days); return isoOf(d); }
  function daysBetween(from, to) {
    return Math.max(1, Math.round((new Date(to + 'T00:00:00Z').getTime() - new Date(from + 'T00:00:00Z').getTime()) / 86400000) + 1);
  }
  var TODAY = isoOf(new Date());
  function q(dateLike) { return String(dateLike || TODAY).slice(0, 10); }

  // PRNG deterministik (mulberry32) — agar angka demo stabil di setiap muat.
  function seeded(seed) {
    var a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  // Nilai "wajar" untuk sebuah tanggal (stabil per hari).
  function dayFactor(iso, salt) {
    var s = 0, str = String(iso) + '|' + (salt || '');
    for (var i = 0; i < str.length; i++) s = (s * 31 + str.charCodeAt(i)) >>> 0;
    var r = seeded(s + 991)();
    return r;
  }

  /* ==================== MASTER DATA CONTOH ==================== */
  var EMPLOYEES = [
    { id: 'e1', employeeCode: 'EMP001', fullName: 'Andi Saputra', position: 'Kasir', color: '#0B6B2E' },
    { id: 'e2', employeeCode: 'EMP002', fullName: 'Budi Santoso', position: 'Staf Gudang', color: '#C74700' },
    { id: 'e3', employeeCode: 'EMP003', fullName: 'Citra Dewi', position: 'Kasir', color: '#1D6FB8' },
    { id: 'e4', employeeCode: 'EMP004', fullName: 'Dewi Lestari', position: 'Admin Toko', color: '#7A3FB5' },
    { id: 'e5', employeeCode: 'EMP005', fullName: 'Eko Prasetyo', position: 'Kurir', color: '#0E7490' },
    { id: 'e6', employeeCode: 'EMP006', fullName: 'Fitri Handayani', position: 'Pramuniaga', color: '#B34A6B' },
    { id: 'e7', employeeCode: 'EMP007', fullName: 'Gita Puspita', position: 'Kasir', color: '#0B6B2E' },
    { id: 'e8', employeeCode: 'EMP008', fullName: 'Hadi Nugroho', position: 'Kepala Gudang', color: '#1D6FB8' },
    { id: 'e9', employeeCode: 'EMP009', fullName: 'Indah Permata', position: 'Pramuniaga', color: '#0E7490' },
    { id: 'e10', employeeCode: 'EMP010', fullName: 'Joko Susilo', position: 'Kurir', color: '#C74700' },
    { id: 'e11', employeeCode: 'EMP011', fullName: 'Kartika Sari', position: 'Admin Toko', color: '#7A3FB5' },
    { id: 'e12', employeeCode: 'EMP012', fullName: 'Lukman Hakim', position: 'Staf Gudang', color: '#B34A6B' },
  ];
  var CASHIERS = ['Andi Saputra', 'Citra Dewi', 'Gita Puspita', 'Maya Anggraini'];
  var CUSTOMERS = ['Pelanggan Umum', 'Ibu Sari', 'Pak Budi', 'Bu Rina', 'Mas Adi', 'Toko Sebelah'];
  var METHODS = ['CASH', 'QRIS', 'DEBIT', 'TRANSFER'];
  var PRODUCTS = [
    { sku: 'BRG-001', name: 'Beras Premium 5kg', cat: 'Sembako', price: 68000, cost: 60000 },
    { sku: 'BRG-002', name: 'Minyak Goreng 2L', cat: 'Sembako', price: 36000, cost: 32000 },
    { sku: 'BRG-003', name: 'Gula Pasir 1kg', cat: 'Sembako', price: 16000, cost: 14000 },
    { sku: 'MKN-010', name: 'Mie Instan Goreng', cat: 'Makanan', price: 125000, cost: 112000 },
    { sku: 'MNM-021', name: 'Air Mineral 600ml', cat: 'Minuman', price: 55000, cost: 48000 },
    { sku: 'SBN-005', name: 'Sabun Mandi Batang', cat: 'Kebersihan', price: 4500, cost: 3500 },
  ];

  /* ==================== DERIVASI HARIAN ==================== */
  function dailySales(iso) {
    var f = dayFactor(iso, 'sales');
    var count = 18 + Math.round(f * 26);            // 18..44 transaksi
    var subtotal = 0, discount = 0, tax = 0, total = 0, cogs = 0, itemsSold = 0;
    var byMethod = {}, byCashier = {}, byCategory = {}, byHour = {};
    var salesList = [];
    var r = seeded((iso + 'pos').split('').reduce(function (a, c) { return (a * 33 + c.charCodeAt(0)) >>> 0; }, 7));
    for (var i = 0; i < count; i++) {
      var p = PRODUCTS[Math.floor(r() * PRODUCTS.length)];
      var r2 = seeded(iso.charCodeAt(9) * 1000 + i)();
      var qty = 1 + Math.floor(r() * 6);
      var line = p.price * qty;
      var disc = r2 < 0.25 ? Math.round(line * 0.05) : 0;
      var memberDisc = r2 > 0.8 ? Math.round(line * 0.03) : 0;
      var tot = line - disc - memberDisc;
      var method = METHODS[Math.floor(r() * METHODS.length)];
      var cashier = CASHIERS[Math.floor(r() * CASHIERS.length)];
      var hour = 8 + Math.floor(r() * 12);
      subtotal += line; discount += disc + memberDisc; total += tot;
      cogs += p.cost * qty; itemsSold += qty;
      byMethod[method] = (byMethod[method] || 0) + tot;
      byCashier[cashier] = byCashier[cashier] || { count: 0, total: 0, profit: 0 };
      byCashier[cashier].count++; byCashier[cashier].total += tot; byCashier[cashier].profit += (line - p.cost * qty);
      byCategory[p.cat] = byCategory[p.cat] || { total: 0, qty: 0, profit: 0 };
      byCategory[p.cat].total += tot; byCategory[p.cat].qty += qty; byCategory[p.cat].profit += (p.price - p.cost) * qty;
      byHour[hour] = byHour[hour] || { count: 0, total: 0 };
      byHour[hour].count++; byHour[hour].total += tot;
      salesList.push({
        id: 'sl-' + iso + '-' + i, code: 'INV-' + iso.replace(/-/g, '') + '-' + String(1000 + i),
        cashierName: cashier, customerName: CUSTOMERS[Math.floor(r() * CUSTOMERS.length)],
        subtotal: line, discount: disc, memberDiscount: memberDisc, tax: 0, total: tot,
        paid: tot, change: 0, paymentMethod: method, status: 'PAID', voidedAt: null,
        createdAt: iso + 'T' + pad(hour) + ':' + pad(Math.floor(r() * 60)) + ':00.000Z',
      });
    }
    var voidCount = dayFactor(iso, 'void') < 0.25 ? 1 : 0;
    var net = subtotal - discount;
    return {
      count: count, gross: subtotal, discount: discount, tax: 0, total: total,
      netSales: net, cogs: cogs, profit: net - cogs,
      marginPct: net > 0 ? ((net - cogs) / net) * 100 : 0,
      itemsSold: itemsSold, avgBasket: count ? total / count : 0,
      voidCount: voidCount, voidTotal: voidCount ? 90000 : 0,
      _byMethod: byMethod, _byCashier: byCashier, _byCategory: byCategory, _byHour: byHour, _sales: salesList,
    };
  }

  function revenueRange(from, to) {
    var days = daysBetween(from, to);
    var summary = { count: 0, gross: 0, discount: 0, tax: 0, total: 0, netSales: 0, cogs: 0, profit: 0, itemsSold: 0, voidCount: 0, voidTotal: 0 };
    var byMethod = {}, byCashier = {}, byCategory = {}, byHour = {};
    var byDay = [], i;
    for (i = 0; i < days; i++) {
      var d = addDays(from, i);
      var ds = dailySales(d);
      summary.count += ds.count; summary.gross += ds.gross; summary.discount += ds.discount; summary.tax += ds.tax;
      summary.total += ds.total; summary.netSales += ds.netSales; summary.cogs += ds.cogs; summary.profit += ds.profit;
      summary.itemsSold += ds.itemsSold; summary.voidCount += ds.voidCount; summary.voidTotal += ds.voidTotal;
      byDay.push({ date: d, count: ds.count, total: ds.total, profit: ds.profit });
      Object.keys(ds._byMethod).forEach(function (k) { byMethod[k] = (byMethod[k] || 0) + ds._byMethod[k]; });
      Object.keys(ds._byCategory).forEach(function (k) {
        byCategory[k] = byCategory[k] || { total: 0, qty: 0, profit: 0 };
        byCategory[k].total += ds._byCategory[k].total; byCategory[k].qty += ds._byCategory[k].qty; byCategory[k].profit += ds._byCategory[k].profit;
      });
      Object.keys(ds._byHour).forEach(function (k) {
        byHour[k] = byHour[k] || { count: 0, total: 0 };
        byHour[k].count += ds._byHour[k].count; byHour[k].total += ds._byHour[k].total;
      });
      Object.keys(ds._byCashier).forEach(function (k) {
        byCashier[k] = byCashier[k] || { count: 0, total: 0, profit: 0 };
        byCashier[k].count += ds._byCashier[k].count; byCashier[k].total += ds._byCashier[k].total; byCashier[k].profit += ds._byCashier[k].profit;
      });
    }
    summary.marginPct = summary.netSales > 0 ? (summary.profit / summary.netSales) * 100 : 0;
    summary.avgBasket = summary.count ? summary.total / summary.count : 0;

    var prevTo = addDays(from, -1), prevFrom = addDays(from, -days);
    var prev = { count: 0, total: 0, profit: 0, netSales: 0, cogs: 0 };
    for (i = 0; i < days; i++) {
      var ds2 = dailySales(addDays(prevFrom, i));
      prev.count += ds2.count; prev.total += ds2.total; prev.profit += ds2.profit; prev.netSales += ds2.netSales; prev.cogs += ds2.cogs;
    }
    prev.marginPct = prev.netSales > 0 ? (prev.profit / prev.netSales) * 100 : 0;
    prev.avgBasket = prev.count ? prev.total / prev.count : 0;

    var target = 3500000;
    var topProducts = PRODUCTS.map(function (p) {
      var qty = Math.round((dayFactor(from + '|' + p.sku, 'tp') * 0.6 + 0.4) * days * (6 + (p.price % 17)));
      var totalP = qty * p.price;
      return { name: p.name, sku: p.sku, qty: qty, total: totalP, profit: Math.round((p.price - p.cost) * qty) };
    }).sort(function (a, b) { return b.total - a.total; });

    return {
      from: from, to: to, days: days,
      summary: summary,
      comparison: { from: prevFrom, to: prevTo, summary: prev },
      byMethod: Object.keys(byMethod).map(function (k) { return { method: k, amount: byMethod[k] }; }).sort(function (a, b) { return b.amount - a.amount; }),
      byCashier: Object.keys(byCashier).map(function (k) { return { name: k, count: byCashier[k].count, total: byCashier[k].total, profit: byCashier[k].profit }; }).sort(function (a, b) { return b.total - a.total; }),
      byCategory: Object.keys(byCategory).map(function (k) { return { name: k, total: byCategory[k].total, qty: byCategory[k].qty, profit: byCategory[k].profit }; }).sort(function (a, b) { return b.total - a.total; }),
      byHour: Object.keys(byHour).map(function (k) { return { hour: Number(k), count: byHour[k].count, total: byHour[k].total }; }).sort(function (a, b) { return a.hour - b.hour; }),
      byDay: byDay,
      topProducts: topProducts,
      target: target,
      today: { date: TODAY, count: dailySales(TODAY).count, total: dailySales(TODAY).total, profit: dailySales(TODAY).profit, target: target },
    };
  }

  function revenueDaily(from, to) {
    var r = revenueRange(from, to);
    return { from: from, to: to, target: r.target, series: r.byDay.map(function (x) { return { date: x.date, count: x.count, total: x.total, profit: x.profit, target: r.target }; }) };
  }

  function attendanceDay(iso) {
    var items = EMPLOYEES.map(function (e) {
      var f = dayFactor(iso, 'att' + e.id);
      var off = f < 0.08;
      var absent = !off && f < 0.16;
      var late = !off && !absent && f > 0.72;
      var hasOut = !off && !absent && f > 0.25;
      var startH = 8;
      var inMin = late ? Math.round(6 + dayFactor(iso, 'late' + e.id) * 42) : Math.round(dayFactor(iso, 'in' + e.id) * 12) - 6;
      var lateMinutes = late ? Math.max(1, inMin) : 0;
      var inAt = absent || off ? null : (iso + 'T' + pad(startH) + ':' + pad(Math.max(0, inMin)) + ':00.000Z');
      var outAt = hasOut ? (iso + 'T16:' + pad(Math.round(dayFactor(iso, 'out' + e.id) * 55)) + ':00.000Z') : null;
      var work = hasOut && inAt ? 480 - Math.max(0, lateMinutes) : 0;
      var status = off ? 'LIBUR' : (absent ? 'ALFA' : (late ? (hasOut ? 'TERLAMBAT' : 'TERLAMBAT_BELUM_CHECKOUT') : (hasOut ? 'HADIR' : 'BELUM_CHECKOUT')));
      return {
        employeeId: e.id, employeeCode: e.employeeCode, fullName: e.fullName, position: e.position,
        photoBase64: null, shiftId: 'sh-pagi', shiftName: 'Pagi', shiftStart: '08:00', shiftEnd: '16:00',
        checkInAt: inAt, checkOutAt: outAt, lateMinutes: lateMinutes, workMinutes: work,
        checkInDistanceMeters: inAt ? Math.round(8 + dayFactor(iso, 'dist' + e.id) * 60) : null,
        checkOutDistanceMeters: outAt ? Math.round(8 + dayFactor(iso, 'dist2' + e.id) * 60) : null,
        faceScore: inAt ? Math.round(74 + dayFactor(iso, 'face' + e.id) * 24) : null,
        status: status, lemburApprovedMinutes: f > 0.9 ? 60 : 0, lemburPendingCount: f > 0.95 ? 1 : 0, offlineSync: false,
      };
    });
    var hadir = items.filter(function (x) { return x.status === 'HADIR'; }).length;
    var terlambat = items.filter(function (x) { return x.status === 'TERLAMBAT' || x.status === 'TERLAMBAT_BELUM_CHECKOUT'; }).length;
    var alfa = items.filter(function (x) { return x.status === 'ALFA'; }).length;
    var libur = items.filter(function (x) { return x.status === 'LIBUR'; }).length;
    var belumCheckout = items.filter(function (x) { return x.status === 'BELUM_CHECKOUT' || x.status === 'TERLAMBAT_BELUM_CHECKOUT'; }).length;
    var lemburMenit = items.reduce(function (a, x) { return a + (x.lemburApprovedMinutes || 0); }, 0);
    var lemburCount = items.filter(function (x) { return x.lemburApprovedMinutes > 0; }).length;
    return {
      date: iso,
      summary: { total: items.length, hadir: hadir, terlambat: terlambat, alfa: alfa, libur: libur, belumCheckout: belumCheckout, lemburMenit: lemburMenit, lemburCount: lemburCount },
      items: items,
    };
  }

  function hrDashboard(iso) {
    var att = attendanceDay(iso), s = att.summary;
    var trend = [];
    for (var i = 29; i >= 0; i--) {
      var d = addDays(iso, -i);
      var present = 0, late = 0;
      EMPLOYEES.forEach(function (e) {
        var f = dayFactor(d, 'att' + e.id);
        if (f >= 0.16) present++;
        if (f > 0.72) late++;
      });
      trend.push({ date: d, present: present, late: late, absent: Math.max(0, EMPLOYEES.length - present) });
    }
    var sumPresent = trend.reduce(function (a, x) { return a + x.present; }, 0);
    var totalLateMinutes = 0;
    EMPLOYEES.forEach(function (e) { totalLateMinutes += Math.round(dayFactor(iso, 'late' + e.id) * 40); });
    return {
      date: iso, range: { from: addDays(iso, -29), to: iso },
      kpi: { totalEmployees: EMPLOYEES.length, hadir: s.hadir + s.terlambat, terlambat: s.terlambat, totalLateMinutes: totalLateMinutes || 96, alfa: s.alfa, libur: s.libur, absentRate: Math.round(((s.hadir + s.terlambat) / EMPLOYEES.length) * 100) },
      pending: { leaves: 3, overtimes: 2, total: 5 },
      overtime: { approvedMinutes: 480, pendingMinutes: 120, approvedCount: 8, pendingCount: 2 },
      leave: { approvedDays: 12 },
      avgPresent30: Math.round((sumPresent / (EMPLOYEES.length * 30)) * 100),
      trend: trend,
      pendingItems: [
        { id: 'lv1', kind: 'LEAVE', fullName: 'Citra Dewi', employeeCode: 'EMP003', avatarColor: '#1D6FB8', label: 'Cuti Tahunan', startDate: iso, endDate: addDays(iso, 1), reason: 'Acara keluarga', createdAt: iso + 'T07:10:00.000Z' },
        { id: 'lv2', kind: 'LEAVE', fullName: 'Eko Prasetyo', employeeCode: 'EMP005', avatarColor: '#0E7490', label: 'Izin Sakit', startDate: iso, endDate: iso, reason: 'Demam', createdAt: iso + 'T06:40:00.000Z' },
        { id: 'ot1', kind: 'OVERTIME', fullName: 'Budi Santoso', employeeCode: 'EMP002', avatarColor: '#C74700', label: '2j 0m • 18:00→20:00', startDate: iso, endDate: iso, reason: 'Stok masuk', createdAt: iso + 'T06:05:00.000Z' },
      ],
      topLate: EMPLOYEES.slice(0, 5).map(function (e, i) {
        return { employeeId: e.id, employeeCode: e.employeeCode, fullName: e.fullName, position: e.position, avatarColor: e.color, lateMinutes: 78 - i * 11, lateCount: 6 - i };
      }),
    };
  }

  function opsOverview(iso) {
    var ds = dailySales(iso);
    return {
      date: iso,
      trips: { total: 14, active: 4, completed: 10 },
      deliveryNotes: { total: 22, delivered: 19 },
      opnames: { total: 3, pending: 1, approved: 2, rejected: 0 },
      pos: { count: ds.count, total: ds.total, cash: ds._byMethod.CASH || 0, openSessions: 2 },
      products: { total: 148, low: 7 },
    };
  }

  function opnameDetail(id) {
    var seed = String(id || 'op').split('').reduce(function (a, c) { return (a * 33 + c.charCodeAt(0)) >>> 0; }, 11);
    var r = seeded(seed);
    var items = PRODUCTS.map(function (p) {
      var sys = 20 + Math.round(r() * 80);
      var diff = Math.round((r() - 0.5) * 8);
      return {
        productName: p.name, sku: p.sku, systemStock: sys, countedStock: sys + diff,
        diff: diff, qtyIn: Math.round(r() * 20), qtyOut: Math.round(r() * 30),
        note: diff === 0 ? '' : (diff > 0 ? 'Kelebihan hitung' : 'Barang kurang'),
      };
    });
    var totalDiff = items.reduce(function (a, x) { return a + x.diff; }, 0);
    return {
      opname: { id: id, employeeName: 'Budi Santoso', area: 'Rak Sembako', kind: 'PRAMUNIAGA', createdAt: TODAY + 'T09:15:00.000Z', totalItems: items.length, totalDiff: totalDiff, status: 'PENDING' },
      items: items,
    };
  }

  /* ==================== ROUTER ==================== */
  function parse(path) {
    var full = String(path || '');
    var qi = full.indexOf('?');
    var p = qi >= 0 ? full.slice(0, qi) : full;
    var query = {};
    if (qi >= 0) {
      full.slice(qi + 1).split('&').forEach(function (kv) {
        if (!kv) return;
        var i = kv.indexOf('=');
        var k = i >= 0 ? kv.slice(0, i) : kv;
        var v = i >= 0 ? decodeURIComponent(kv.slice(i + 1).replace(/\+/g, ' ')) : '';
        query[k] = v;
      });
    }
    return { p: p.replace(/^\/+|\/+$/g, ''), query: query };
  }

  function route(path, opts) {
    var r = parse(path), qy = r.query;
    // Normalisasi: rute operasional dipanggil sebagai 'ops/admin/...'
    // (backend memasangnya di /api/ops). Cocokkan pada kunci tanpa 'ops/'.
    var p = r.p.replace(/^ops\//, '');

    if (p === 'admin/login' || p === 'admin/me') {
      return { token: 'demo-token', adminId: 'demo', name: 'Super Admin (Demo)', email: 'demo@tokokartini.com', role: 'SUPERADMIN', companyId: window.__COMPANY_ID__ || 'demo', companyName: 'Simaung Corporation', officeName: 'Kantor Pusat' };
    }

    // ---- Dashboard HR (KPI lintas modul) ----
    if (p === 'admin/hr-dashboard') return hrDashboard(q(qy.date));

    // ---- Absensi ----
    if (p === 'admin/attendance') return attendanceDay(q(qy.date));

    // ---- Ops overview ----
    if (p === 'admin/ops/overview') return opsOverview(q(qy.date));

    // ---- POS ----
    if (p === 'admin/pos/revenue') return revenueRange(q(qy.from), q(qy.to));
    if (p === 'admin/pos/revenue/daily') return revenueDaily(q(qy.from), q(qy.to));
    if (p === 'admin/pos/summary') {
      var ds = dailySales(q(qy.date));
      return { date: q(qy.date), count: ds.count, total: ds.total, cash: ds._byMethod.CASH || 0, nonCash: ds.total - (ds._byMethod.CASH || 0), openSessions: 2, itemsSold: ds.itemsSold, avgBasket: ds.avgBasket };
    }
    if (p === 'admin/pos/sales') return { date: q(qy.date), items: dailySales(q(qy.date))._sales };
    if (p === 'admin/pos/sessions') {
      return { items: [
        { id: 'se1', cashierName: 'Andi Saputra', openingCash: 200000, closingCash: null, expectedCash: null, cashDiff: null, status: 'OPEN', openedAt: TODAY + 'T08:02:00.000Z', closedAt: null },
        { id: 'se2', cashierName: 'Citra Dewi', openingCash: 200000, closingCash: 1250000, expectedCash: 1255000, cashDiff: -5000, status: 'CLOSED', openedAt: addDays(TODAY, -1) + 'T08:00:00.000Z', closedAt: addDays(TODAY, -1) + 'T16:10:00.000Z' },
      ] };
    }
    if (p === 'admin/pos/shifts') {
      var items = [], from = q(qy.from), to = q(qy.to), days = daysBetween(from, to);
      for (var i = 0; i < Math.min(days, 20); i++) {
        var d = addDays(from, i);
        var f = dayFactor(d, 'shift');
        var expected = 900000 + Math.round(f * 700000);
        var diff = f > 0.7 ? Math.round((f - 0.5) * 40000) - 5000 : 0;
        items.push({
          id: 'sh-' + d, code: 'SH-' + d.replace(/-/g, ''), shiftLabel: (i % 2 ? 'Siang' : 'Pagi'),
          cashierName: CASHIERS[i % CASHIERS.length], openedAt: d + 'T08:00:00.000Z',
          closedAt: d === TODAY ? null : d + 'T16:05:00.000Z', openingCash: 200000,
          closingCash: d === TODAY ? null : expected + diff, expectedCash: d === TODAY ? null : expected,
          cashDiff: d === TODAY ? null : diff, status: d === TODAY ? 'OPEN' : 'CLOSED',
          totals: { total: Math.round(expected * 1.05) },
        });
      }
      var diffTotal = items.reduce(function (a, x) { return a + (Number(x.cashDiff) || 0); }, 0);
      return { from: from, to: to, items: items, shifts: items, kpi: { diffTotal: diffTotal, closed: items.filter(function (x) { return x.status === 'CLOSED'; }).length } };
    }
    if (p.indexOf('admin/pos/shifts/') === 0) return { shift: null, items: [] };

    // ---- Opname ----
    if (p === 'admin/opnames') {
      return { items: [
        { id: 'op1', employeeName: 'Budi Santoso', kind: 'PRAMUNIAGA', area: 'Rak Sembako', totalItems: 6, totalDiff: 3, status: 'PENDING', reviewedBy: null, createdAt: TODAY + 'T09:15:00.000Z' },
        { id: 'op2', employeeName: 'Dewi Lestari', kind: 'KEPALA_GUDANG', area: 'Semua', totalItems: 6, totalDiff: 1, status: 'APPROVED', reviewedBy: 'Super Admin', createdAt: addDays(TODAY, -1) + 'T15:20:00.000Z' },
        { id: 'op3', employeeName: 'Lukman Hakim', kind: 'PRAMUNIAGA', area: 'Rak Minuman', totalItems: 6, totalDiff: 0, status: 'APPROVED', reviewedBy: 'Super Admin', createdAt: addDays(TODAY, -3) + 'T10:05:00.000Z' },
      ] };
    }
    if (p.indexOf('admin/opnames/') === 0) {
      return opnameDetail(p.split('/')[2]);
    }

    // ---- Jurnal (dipanggil via japi -> path 'accounts' / 'journal') ----
    if (p === 'accounts') {
      return { accounts: [
        { code: '1010', name: 'Kas', type_of_account: { name: 'Aset Lancar', normal_balance: 'DEBIT', report_section: 'ASET' }, is_active: true },
        { code: '1020', name: 'Bank', type_of_account: { name: 'Aset Lancar', normal_balance: 'DEBIT', report_section: 'ASET' }, is_active: true },
        { code: '1030', name: 'Piutang Usaha', type_of_account: { name: 'Aset Lancar', normal_balance: 'DEBIT', report_section: 'ASET' }, is_active: true },
        { code: '2010', name: 'Utang Usaha', type_of_account: { name: 'Liabilitas', normal_balance: 'KREDIT', report_section: 'LIABILITAS' }, is_active: true },
        { code: '3010', name: 'Modal', type_of_account: { name: 'Ekuitas', normal_balance: 'KREDIT', report_section: 'EKUITAS' }, is_active: true },
        { code: '4010', name: 'Penjualan', type_of_account: { name: 'Pendapatan', normal_balance: 'KREDIT', report_section: 'PENDAPATAN' }, is_active: true },
        { code: '5010', name: 'Harga Pokok Penjualan', type_of_account: { name: 'Beban', normal_balance: 'DEBIT', report_section: 'BEBAN' }, is_active: true },
        { code: '5020', name: 'Beban Operasional', type_of_account: { name: 'Beban', normal_balance: 'DEBIT', report_section: 'BEBAN' }, is_active: true },
      ] };
    }
    if (p === 'journal') {
      var entries = [];
      for (var j = 0; j < 12; j++) {
        var d2 = addDays(TODAY, -j);
        var amount = 400000 + Math.round(dayFactor(d2, 'jrn') * 1600000);
        entries.push({
          id: 'jr' + j, entry_no: 'JE-' + d2.replace(/-/g, '') + '-' + (j + 1), entry_date: d2,
          memo: 'Penjualan harian kasir', source: 'POS', journal_lines: [
            { account_id: '1020', accounts: { code: '1020', name: 'Bank' }, debit: amount, credit: 0 },
            { account_id: '4010', accounts: { code: '4010', name: 'Penjualan' }, debit: 0, credit: amount },
          ],
        });
      }
      return { entries: entries };
    }

    // Fallback aman: objek kosong (halaman menampilkan keadaan kosong, bukan error).
    return {};
  }

  window.REPORTMOCK = {
    isDemo: function () { return window.__REPORT_DEMO__ === true; },
    enable: function () { window.__REPORT_DEMO__ = true; },
    disable: function () { window.__REPORT_DEMO__ = false; },
    api: function (path, opts) { return Promise.resolve(route(path, opts)); },
  };
})();
