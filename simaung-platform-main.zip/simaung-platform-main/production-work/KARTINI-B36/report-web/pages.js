/* =====================================================================
   SIMAUNG CORPORATION — PUSAT LAPORAN · HALAMAN (pages.js)  v2
   ---------------------------------------------------------------------
   Setiap fungsi mengembalikan HTML (Promise<string>). Helper inti
   tersedia dari app.js melalui objek window.
   ===================================================================== */
(function () {
  'use strict';
  var W = window;
  var api = W.__api, japi = W.__japi, S = W.__S, CID = W.__CID;
  var kpi = W.__kpi, IC = W.__IC, table = W.__table, state = W.__state, loading = W.__loading;
  var vbars = W.__vbars, hbars = W.__hbars, donut = W.__donut, rangeBar = W.__rangeBar;
  var rp = W.__rp, rpK = W.__rpK, fmt = W.__fmt, fmt1 = W.__fmt1, esc = W.__esc;
  var attBadge = W.__attBadge, shiftStatus = W.__shiftStatus, timeOf = W.__timeOf;
  var dateOf = W.__dateOf, dayName = W.__dayName, durMin = W.__durMin, pct = W.__pct;
  var initials = W.__initials, avColor = W.__avColor, pagehead = W.__pagehead;
  var exportCSV = W.__exportCSV;

  var P = W.__pages = W.__pages || {};
  var A = W.__after = W.__after || {};

  function safe(p) { return p.then(function (d) { return d; }).catch(function () { return null; }); }
  function all() { return Promise.all([].slice.call(arguments)); }

  function hIcon(ic) { return '<span class="hh">' + ic + '</span>'; }
  function card(title, sub, act, body, opt) {
    opt = opt || {};
    return '<div class="card">' +
      (title ? '<div class="card-h">' + (opt.icon ? hIcon(opt.icon) : '') + '<h3>' + (opt.icon ? '' : '') + esc(title) + '</h3>' +
        (sub ? '<span class="h-sub">' + esc(sub) + '</span>' : '') +
        (act ? '<div class="h-act">' + act + '</div>' : '') + '</div>' : '') +
      '<div class="card-b' + (opt.tight ? ' tight' : '') + (opt.center ? ' center' : '') + '">' + body + '</div></div>';
  }
  function expBtn(label, onclick) {
    return '<button class="btn ghost sm" onclick="' + onclick + '" title="Ekspor CSV">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12m0 0-4-4m4 4 4-4M4 19h16"/></svg>' + label + '</button>';
  }
  function cmp(cur, prev) {
    if (!prev) return '';
    var d = pct(cur - prev, prev), up = d >= 0;
    return '<span class="' + (up ? 'up' : 'down') + '">' + (up ? '▲' : '▼') + ' ' + fmt1(Math.abs(d)) + '%</span> vs periode lalu';
  }
  function chartEmpty(title, msg) {
    return '<div class="state compact"><div class="s-ico" style="width:50px;height:50px;border-radius:15px">' + IC.trend + '</div>' +
      '<b style="font-size:14px">' + esc(title) + '</b><p style="font-size:12.5px;max-width:300px">' + esc(msg || '') + '</p></div>';
  }
  function avatarCell(name, code, position, photo) {
    var av = photo
      ? '<span class="avatar ' + (avColor(name).trim() || '') + '">' + initials(name) + '<img src="data:image/jpeg;base64,' + photo + '" onerror="this.style.display=\'none\'"></span>'
      : '<span class="avatar' + avColor(name) + '">' + initials(name) + '</span>';
    return '<div style="display:flex;align-items:center;gap:11px">' + av +
      '<div><div class="tname">' + esc(name || '') + '</div>' +
      '<div class="tsub">' + esc([code, position].filter(Boolean).join(' · ')) + '</div></div></div>';
  }
  function opnBadge(s) {
    s = String(s || '').toUpperCase();
    var cls = { PENDING: 's-warn', APPROVED: 's-ok', REJECTED: 's-danger', DRAFT: 's-mut', REVIEWED: 's-info' }[s] || 's-mut';
    var txt = { PENDING: 'Menunggu', APPROVED: 'Disetujui', REJECTED: 'Ditolak', DRAFT: 'Draft', REVIEWED: 'Ditinjau' }[s] || (s.replace(/_/g, ' ') || '—');
    return '<span class="badge-status ' + cls + '">' + esc(txt) + '</span>';
  }

  /* ==================== RINGKASAN ==================== */
  P.ringkasan = function () {
    var today = S.to;
    return all(
      safe(api('ops/admin/ops/overview?date=' + today)),
      safe(api('ops/admin/pos/summary?date=' + today)),
      safe(api('ops/admin/pos/revenue?from=' + S.from + '&to=' + S.to)),
      safe(api('ops/admin/pos/revenue/daily?from=' + S.from + '&to=' + S.to)),
      safe(api('admin/attendance?date=' + today)),
      safe(api('ops/admin/opnames'))
    ).then(function (r) {
      var ov = r[0] || {}, ps = r[1] || {}, rev = r[2] || {}, daily = r[3] || { series: [] };
      var att = r[4] || { summary: {}, items: [] }, opn = r[5] || { items: [] };
      var sum = rev.summary || {}, prev = (rev.comparison || {}).summary || {};
      var as = att.summary || {};

      var series = (daily.series || []).map(function (d) { return { label: dayName(d.date), value: d.total }; });
      var hasSales = series.some(function (s) { return Number(s.value) > 0; });
      var hadir = (as.hadir || 0) + (as.terlambat || 0);
      var hadirPct = pct(hadir, as.total || 0);
      var lowStock = (ov.products || {}).low || 0;

      var kpis = kpi({ cls: 'k-accent', icon: IC.money, label: 'Omzet Periode', value: rpK(sum.total || 0), sub: fmt(sum.count || 0) + ' transaksi · ' + cmp(sum.total || 0, prev.total || 0) }) +
        kpi({ icon: IC.trend, label: 'Laba Kotor', value: rpK(sum.profit || 0), sub: 'Margin ' + fmt1(sum.marginPct || 0) + '%' }) +
        kpi({ cls: 'k-info', icon: IC.bag, label: 'Rata-rata / Struk', value: rpK(sum.avgBasket || 0), sub: fmt(sum.itemsSold || 0) + ' item terjual' }) +
        kpi({ cls: 'k-info', icon: IC.user, label: 'Kehadiran', value: fmt(hadir) + '/' + fmt(as.total || 0), sub: fmt(as.terlambat || 0) + ' terlambat · ' + fmt(as.alfa || 0) + ' alfa' }) +
        kpi({ cls: 'k-warn', icon: IC.clock, label: 'Sesi Kasir Aktif', value: fmt(ps.openSessions || 0), sub: 'Kas hari ini: ' + rpK(ps.cash || 0) }) +
        kpi({ cls: 'k-warn', icon: IC.box, label: 'Stok Menipis', value: fmt(lowStock), sub: fmt((ov.products || {}).total || 0) + ' produk terdaftar' });

      var chart = card('Tren Omzet Harian', 'Periode ' + S.from + ' s/d ' + S.to,
        expBtn('CSV', 'exportRingkasan()'),
        (hasSales ? vbars(series) : chartEmpty('Belum ada penjualan', 'Grafik tren omzet akan tampil setelah ada transaksi pada periode ini.')),
        { icon: IC.trend });

      var attCard = card('Kehadiran Hari Ini', 'Per ' + today, '', donut(hadirPct, 'Hadir', fmt1(hadirPct) + '%', [
        { color: '#0B6B2E', label: 'Hadir', value: fmt(as.hadir || 0) },
        { color: '#F26A1B', label: 'Terlambat', value: fmt(as.terlambat || 0) },
        { color: '#C62828', label: 'Alfa', value: fmt(as.alfa || 0) },
        { color: '#1D6FB8', label: 'Libur', value: fmt(as.libur || 0) },
      ]), { icon: IC.user });

      var quick = '<div class="grid" style="grid-template-columns:1fr;gap:9px">' +
        [['pos', 'Kasir / POS', IC.sales, 'Penjualan & transaksi'],
         ['shift', 'Shift Kasir', IC.clock, 'Sesi & selisih kas'],
         ['opname', 'Stock Opname', IC.box, 'Sesuaian stok fisik'],
         ['absensi', 'Absensi', IC.user, 'Kehadiran karyawan'],
         ['jurnal', 'Jurnal & Keuangan', IC.book, 'Buku besar & laba rugi']]
        .map(function (q) {
          return '<a class="qlink" onclick="goto(\'' + q[0] + '\')">' +
            '<span class="q-ico">' + q[2] + '</span>' +
            '<div><div class="tname">' + q[1] + '</div><div class="tsub">' + q[3] + '</div></div>' +
            '<span class="q-arrow">›</span></a>';
        }).join('') + '</div>';

      var recentOpn = table([
        { h: 'Tanggal', cell: function (o) { return '<span class="tname">' + dateOf(o.createdAt) + '</span><div class="tsub">' + timeOf(o.createdAt) + '</div>'; } },
        { h: 'Petugas', cell: function (o) { return esc(o.employeeName || '—'); } },
        { h: 'Area', cell: function (o) { return esc(o.area || '—'); } },
        { h: 'Item', cls: 'num', cell: function (o) { return fmt(o.totalItems); } },
        { h: 'Selisih', cls: 'num', cell: function (o) { var d = Number(o.totalDiff) || 0; return '<b style="color:' + (d ? 'var(--danger)' : 'var(--ok)') + '">' + fmt(d) + '</b>'; } },
        { h: 'Status', cell: function (o) { return opnBadge(o.status); } },
      ], (opn.items || []).slice(0, 6), { empty: 'Belum ada sesi opname' });

      return pagehead(IC.ringkas || IC.trend, 'Ringkasan', 'Gambaran menyeluruh seluruh laporan Simaung Corporation',
        '<b>' + rpK(sum.total || 0) + '</b><span>Omzet periode</span>') +
        rangeBar() +
        '<div class="kpis">' + kpis + '</div>' +
        '<div class="grid g2e">' + chart + attCard + '</div>' +
        '<div class="divider"></div>' +
        '<div class="grid g2e">' + card('Akses Cepat', 'Laporan tersedia', '', quick, { icon: IC.grid }) +
        card('Stock Opname Terbaru', (opn.items || []).length + ' sesi terakhir', '', recentOpn, { tight: true, icon: IC.box }) + '</div>';
    });
  };
  W.exportRingkasan = function () {
    var t = S.to;
    safe(api('ops/admin/pos/revenue/daily?from=' + S.from + '&to=' + S.to)).then(function (d) {
      var s = (d || {}).series || [];
      exportCSV('ringkasan-omzet-' + S.from + '_' + S.to + '.csv',
        ['Tanggal', 'Transaksi', 'Omzet', 'Laba', 'Target'],
        s.map(function (x) { return [x.date, x.count, x.total, x.profit, x.target]; }));
    });
  };

  /* ==================== KPI LINTAS MODUL ==================== */
  function ksec(title, icon, cards) {
    return '<div class="kpi-section">' +
      '<div class="kpi-sec-title">' + hIcon(icon) + esc(title) + '</div>' +
      '<div class="kpis">' + cards + '</div></div>';
  }

  P.kpi = function () {
    var date = S.to;
    return all(
      safe(api('admin/hr-dashboard?date=' + date)),
      safe(api('ops/admin/ops/overview?date=' + date)),
      safe(api('ops/admin/pos/revenue?from=' + S.from + '&to=' + S.to)),
      safe(api('ops/admin/pos/revenue/daily?from=' + S.from + '&to=' + S.to)),
      safe(api('admin/attendance?date=' + date)),
      safe(api('ops/admin/pos/summary?date=' + date)),
      safe(api('ops/admin/pos/shifts?from=' + S.from + '&to=' + S.to)),
      safe(api('ops/admin/opnames')),
      safe(japi('accounts')),
      safe(japi('journal'))
    ).then(function (r) {
      var hr = r[0] || {}, ov = r[1] || {}, rev = r[2] || {}, daily = r[3] || { series: [] };
      var att = r[4] || { summary: {} }, ps = r[5] || {}, shifts = r[6] || {}, opn = r[7] || {};
      var accounts = (r[8] || {}).accounts || [], entries = (r[9] || {}).entries || [];

      var hk = hr.kpi || {}, as = att.summary || {};
      var sum = rev.summary || {}, prev = (rev.comparison || {}).summary || {};
      var sk = shifts.kpi || {};
      var today = rev.today || {};

      var hadir = hk.hadir || ((as.hadir || 0) + (as.terlambat || 0));
      var totalEmp = hk.totalEmployees || as.total || 0;
      var hadirPct = pct(hadir, totalEmp);
      var terlambat = hk.terlambat || as.terlambat || 0;
      var lateMin = hk.totalLateMinutes || 0;
      var alfa = hk.alfa || as.alfa || 0;
      var libur = as.libur || hk.libur || 0;
      var avgPresent = hr.avgPresent30 || 0;
      var otAppr = (hr.overtime || {}).approvedMinutes || 0;
      var otPend = (hr.overtime || {}).pendingMinutes || 0;

      var lowStock = (ov.products || {}).low || 0;
      var prodTotal = (ov.products || {}).total || 0;
      var opnPending = (ov.opnames || {}).pending || 0;
      var opnTotal = (ov.opnames || {}).total || 0;
      var openSessions = ps.openSessions || 0;
      var diffTotal = sk.diffTotal || 0;
      var target = rev.target || 0;
      var todayPct = target ? pct(today.total || 0, target) : 0;

      var financeAvailable=Boolean(r[9]);
      var totalDebit = financeAvailable ? entries.reduce(function(n,e){return n+sumLines(e,'debit');},0) : null;
      var totalCredit = financeAvailable ? entries.reduce(function(n,e){return n+sumLines(e,'credit');},0) : null;
      var balanced = financeAvailable ? Math.abs(totalDebit - totalCredit) < 0.01 : null;

      W.__kpiData = {
        hadir: hadir, hadirPct: hadirPct, terlambat: terlambat, lateMin: lateMin, alfa: alfa,
        avgPresent: avgPresent, otAppr: otAppr, todayTotal: today.total || 0, todayCount: today.count || 0,
        avgBasket: sum.avgBasket || 0, openSessions: openSessions, diffTotal: diffTotal,
        lowStock: lowStock, opnPending: opnPending, periodTotal: sum.total || 0, profit: sum.profit || 0,
        margin: sum.marginPct || 0, discount: sum.discount || 0, totalDebit: totalDebit, totalCredit: totalCredit,
        balanced: balanced,
      };

      /* ---- SDM (6) ---- */
      var sdm = kpi({ cls: 'k-accent', icon: IC.user, label: 'Tingkat Kehadiran', value: fmt1(hadirPct) + '%', sub: fmt(hadir) + ' dari ' + fmt(totalEmp) + ' karyawan' }) +
        kpi({ cls: 'k-warn', icon: IC.clock, label: 'Karyawan Terlambat', value: fmt(terlambat), sub: 'Hari ini · ' + date }) +
        kpi({ cls: 'k-warn', icon: IC.clock, label: 'Akumulasi Telat', value: durMin(lateMin), sub: 'Total keterlambatan' }) +
        kpi({ cls: 'k-danger', icon: IC.alert, label: 'Alfa', value: fmt(alfa), sub: 'Tanpa keterangan' }) +
        kpi({ cls: 'k-info', icon: IC.trend, label: 'Rata-rata Hadir 30 Hari', value: fmt1(avgPresent) + '%', sub: 'Konsistensi kehadiran' }) +
        kpi({ icon: IC.check, label: 'Lembur Disetujui', value: durMin(otAppr), sub: durMin(otPend) + ' menunggu' });

      /* ---- Operasional (7) ---- */
      var ops = kpi({ cls: 'k-accent', icon: IC.money, label: 'Omzet Hari Ini', value: rpK(today.total || 0), sub: fmt(today.count || 0) + ' transaksi · ' + fmt1(todayPct) + '% target' }) +
        kpi({ icon: IC.sales, label: 'Transaksi Hari Ini', value: fmt(today.count || 0), sub: 'Struk tercatat' }) +
        kpi({ icon: IC.bag, label: 'Rata-rata / Struk', value: rpK(sum.avgBasket || 0), sub: 'Periode ' + S.from + ' s/d ' + S.to }) +
        kpi({ cls: 'k-info', icon: IC.clock, label: 'Sesi Kasir Aktif', value: fmt(openSessions), sub: 'Belum ditutup' }) +
        kpi({ cls: (diffTotal < 0 ? 'k-danger' : 'k-warn'), icon: IC.alert, label: 'Selisih Kas', value: rpK(diffTotal), sub: 'Akumulasi periode' }) +
        kpi({ cls: (lowStock ? 'k-warn' : ''), icon: IC.box, label: 'Stok Menipis', value: fmt(lowStock), sub: fmt(prodTotal) + ' produk terdaftar' }) +
        kpi({ cls: (opnPending ? 'k-warn' : ''), icon: IC.grid, label: 'Opname Menunggu', value: fmt(opnPending), sub: fmt(opnTotal) + ' sesi total' });

      /* ---- Keuangan (6) ---- */
      var keu = kpi({ cls: 'k-accent', icon: IC.money, label: 'Omzet Periode', value: rpK(sum.total || 0), sub: fmt(sum.count || 0) + ' transaksi · ' + cmp(sum.total || 0, prev.total || 0) }) +
        kpi({ icon: IC.trend, label: 'Laba Kotor', value: rpK(sum.profit || 0), sub: 'Margin ' + fmt1(sum.marginPct || 0) + '%' }) +
        kpi({ cls: 'k-info', icon: IC.money, label: 'Total Diskon', value: rpK(sum.discount || 0), sub: 'Potongan diberikan' }) +
        kpi({ icon: IC.book, label: 'Total Debit', value: financeAvailable?rpK(totalDebit):'—', sub: financeAvailable?fmt(entries.length)+' entri terakhir':'Data jurnal belum tersedia' }) +
        kpi({ icon: IC.book, label: 'Total Kredit', value: financeAvailable?rpK(totalCredit):'—', sub: 'Entri terakhir' }) +
        kpi({ cls: balanced ? '' : 'k-danger', icon: balanced ? IC.check : IC.alert, label: 'Keseimbangan Jurnal', value: !financeAvailable?'—':balanced?'Seimbang':'Tidak Seimbang', sub: financeAvailable?'Entri terakhir':'Data jurnal belum tersedia' });

      /* ---- Grafik ---- */
      var series = (daily.series || []).map(function (t, i, arr) {
        return { label: (i % 5 === 0 || i === arr.length - 1) ? String(t.date).slice(8, 10) : '', value: t.total };
      });
      var hasSales = series.some(function (s) { return Number(s.value) > 0; });
      var trendCard = card('Tren Omzet Harian', 'Periode ' + S.from + ' s/d ' + S.to, expBtn('CSV', 'exportKPI()'),
        hasSales ? vbars(series) : chartEmpty('Belum ada penjualan', 'Grafik tren omzet akan tampil setelah ada transaksi.'), { icon: IC.trend });

      var attCard = card('Kehadiran Hari Ini', 'Per ' + date, '', donut(hadirPct, 'Hadir', fmt1(hadirPct) + '%', [
        { color: '#0B6B2E', label: 'Tepat Waktu', value: fmt(as.hadir || 0) },
        { color: '#F26A1B', label: 'Terlambat', value: fmt(terlambat) },
        { color: '#C62828', label: 'Alfa', value: fmt(alfa) },
        { color: '#1D6FB8', label: 'Libur', value: fmt(libur) },
      ]), { icon: IC.user });

      var payItems = (rev.byMethod || []).map(function (m) { return { label: m.method || 'LAINNYA', value: m.amount || 0, fmt: function (v) { return rpK(v); } }; });
      var payCard = card('Metode Pembayaran', 'Periode ' + S.from + ' s/d ' + S.to, '',
        payItems.length ? hbars(payItems, 'info') : chartEmpty('Belum ada transaksi', 'Rincian metode pembayaran akan tampil di sini.'), { icon: IC.money });

      var catItems = (rev.byCategory || []).map(function (c) { return { label: c.name || '—', value: c.total || 0, fmt: function (v) { return rpK(v); } }; });
      var catCard = card('Penjualan per Kategori', 'Periode ' + S.from + ' s/d ' + S.to, '',
        catItems.length ? hbars(catItems) : chartEmpty('Belum ada penjualan', 'Rincian per kategori akan tampil di sini.'), { icon: IC.grid });

      /* ---- Tabel ---- */
      var topLateCard = card('Paling Sering Terlambat', '30 hari terakhir', '',
        table([
          { h: 'Karyawan', cell: function (e) { return avatarCell(e.fullName, e.employeeCode, e.position); } },
          { h: 'Telat', cls: 'num', cell: function (e) { return '<b style="color:var(--accent-700)">' + fmt(e.lateMinutes) + 'm</b>'; } },
          { h: 'Frekuensi', cls: 'num', cell: function (e) { return fmt(e.lateCount) + '×'; } },
        ], hr.topLate || [], { empty: 'Tidak ada keterlambatan' }), { tight: true, icon: IC.clock });

      var topProdCard = card('Produk Terlaris', 'Periode ' + S.from + ' s/d ' + S.to, '',
        table([
          { h: 'Produk', cell: function (p) { return '<span class="tname">' + esc(p.name) + '</span><div class="tsub">' + esc(p.sku || '') + '</div>'; } },
          { h: 'Terjual', cls: 'num', cell: function (p) { return fmt(p.qty); } },
          { h: 'Omzet', cls: 'num', cell: function (p) { return '<b>' + rp(p.total) + '</b>'; } },
          { h: 'Laba', cls: 'num', cell: function (p) { return rp(p.profit); } },
        ], (rev.topProducts || []).slice(0, 8), { empty: 'Belum ada penjualan' }), { tight: true, icon: IC.bag });

      return pagehead(IC.trend, 'KPI Lintas Modul', 'Indikator kinerja utama dari seluruh modul Simaung Corporation',
        '<b>' + fmt1(hadirPct) + '%</b><span>Kehadiran hari ini</span>') +
        rangeBar() +
        ksec('Sumber Daya Manusia', IC.user, sdm) +
        ksec('Operasional', IC.grid, ops) +
        ksec('Keuangan', IC.money, keu) +
        '<div class="divider"></div>' +
        '<div class="grid g2e">' + trendCard + attCard + '</div>' +
        '<div class="grid g2e">' + payCard + catCard + '</div>' +
        '<div class="divider"></div>' +
        '<div class="grid g2e">' + topLateCard + topProdCard + '</div>';
    });
  };
  W.exportKPI = function () {
    var d = W.__kpiData || {};
    exportCSV('kpi-lintas-modul-' + S.from + '_' + S.to + '.csv', ['Kategori', 'Indikator', 'Nilai'], [
      ['SDM', 'Tingkat Kehadiran', (d.hadirPct || 0) + '%'],
      ['SDM', 'Karyawan Terlambat', d.terlambat || 0],
      ['SDM', 'Akumulasi Telat (menit)', d.lateMin || 0],
      ['SDM', 'Alfa', d.alfa || 0],
      ['SDM', 'Rata-rata Hadir 30 Hari', (d.avgPresent || 0) + '%'],
      ['SDM', 'Lembur Disetujui (menit)', d.otAppr || 0],
      ['Operasional', 'Omzet Hari Ini', d.todayTotal || 0],
      ['Operasional', 'Transaksi Hari Ini', d.todayCount || 0],
      ['Operasional', 'Rata-rata per Struk', d.avgBasket || 0],
      ['Operasional', 'Sesi Kasir Aktif', d.openSessions || 0],
      ['Operasional', 'Selisih Kas', d.diffTotal || 0],
      ['Operasional', 'Stok Menipis', d.lowStock || 0],
      ['Operasional', 'Opname Menunggu', d.opnPending || 0],
      ['Keuangan', 'Omzet Periode', d.periodTotal || 0],
      ['Keuangan', 'Laba Kotor', d.profit || 0],
      ['Keuangan', 'Margin', (d.margin || 0) + '%'],
      ['Keuangan', 'Total Diskon', d.discount || 0],
      ['Keuangan', 'Total Debit Jurnal', d.totalDebit ?? 'Tidak tersedia'],
      ['Keuangan', 'Total Kredit Jurnal', d.totalCredit || 0],
      ['Keuangan', 'Keseimbangan Jurnal', d.balanced ? 'Seimbang' : 'Tidak Balance'],
    ]);
  };

  /* ==================== POS ==================== */
  P.pos = function () {
    var date = S.to;
    return all(
      safe(api('ops/admin/pos/revenue?from=' + S.from + '&to=' + S.to)),
      safe(api('ops/admin/pos/revenue/daily?from=' + S.from + '&to=' + S.to)),
      safe(api('ops/admin/pos/summary?date=' + date)),
      safe(api('ops/admin/pos/sales?date=' + date))
    ).then(function (r) {
      var rev = r[0] || {}, sum = rev.summary || {}, prev = (rev.comparison || {}).summary || {};
      var daily = r[1] || { series: [] }, ps = r[2] || {}, sales = (r[3] || {}).items || [];
      W.__posSales = sales;

      var series = (daily.series || []).map(function (d) { return { label: dayName(d.date), value: d.total }; });
      var hasSales = series.some(function (s) { return Number(s.value) > 0; });
      var payItems = payMethods(sales);

      var kpis = kpi({ cls: 'k-accent', icon: IC.money, label: 'Total Omzet', value: rpK(sum.total || 0), sub: cmp(sum.total || 0, prev.total || 0) }) +
        kpi({ icon: IC.sales, label: 'Transaksi', value: fmt(sum.count || 0), sub: fmt(sum.itemsSold || 0) + ' item' }) +
        kpi({ icon: IC.bag, label: 'Rata-rata / Struk', value: rpK(sum.avgBasket || 0), sub: 'Basket size' }) +
        kpi({ cls: 'k-warn', icon: IC.trend, label: 'Laba Kotor', value: rpK(sum.profit || 0), sub: 'Margin ' + fmt1(sum.marginPct || 0) + '%' }) +
        kpi({ cls: 'k-info', icon: IC.money, label: 'Diskon', value: rpK(sum.discount || 0), sub: 'Total potongan' }) +
        kpi({ cls: 'k-danger', icon: IC.alert, label: 'Void', value: fmt(sum.voidCount || 0), sub: rpK(sum.voidTotal || 0) });

      var chart = card('Omzet Harian', 'Periode ' + S.from + ' s/d ' + S.to, '',
        hasSales ? vbars(series) : chartEmpty('Belum ada penjualan', 'Grafik omzet harian akan tampil setelah ada transaksi.'), { icon: IC.trend });

      var payCard = card('Metode Pembayaran', 'Hari ini · ' + date, '',
        payItems.length ? hbars(payItems, 'info') : chartEmpty('Belum ada transaksi', 'Rincian metode pembayaran akan tampil di sini.'), { icon: IC.money });

      var comp = rev.comparison ? card('Perbandingan Periode', (rev.comparison.from || '') + ' s/d ' + (rev.comparison.to || ''), '',
        '<div class="grid g2e" style="gap:12px">' +
        kpi({ label: 'Omzet Periode Ini', value: rpK(sum.total || 0), sub: fmt(sum.count || 0) + ' transaksi' }) +
        kpi({ label: 'Omzet Periode Lalu', value: rpK(prev.total || 0), sub: cmp(sum.total || 0, prev.total || 0) }) + '</div>', { icon: IC.trend }) : '';

      var salesTbl = card('Transaksi — ' + date, fmt(sales.length) + ' struk', expBtn('Ekspor CSV', 'exportPos()'),
        table([
          { h: 'Waktu', cell: function (s) { return '<span class="tname">' + timeOf(s.createdAt) + '</span>'; } },
          { h: 'Kode', cell: function (s) { return '<span class="mono">' + esc(s.code || (s.id || '').slice(0, 8)) + '</span>'; } },
          { h: 'Kasir', cell: function (s) { return esc(s.cashierName || '—'); } },
          { h: 'Pelanggan', cell: function (s) { return esc(s.customerName || 'Umum'); } },
          { h: 'Metode', cell: function (s) { return '<span class="chip mut">' + esc(s.paymentMethod || '-') + '</span>'; } },
          { h: 'Total', cls: 'num', cell: function (s) { return '<b>' + rp(s.total) + '</b>'; } },
          { h: 'Status', cell: function (s) { return s.voidedAt ? '<span class="badge-status s-danger">VOID</span>' : '<span class="badge-status s-ok">PAID</span>'; } },
        ], sales), { tight: true, icon: IC.sales });

      return pagehead(IC.sales, 'Kasir / POS', 'Laporan penjualan, transaksi & penerimaan kasir',
        '<b>' + rpK(sum.total || 0) + '</b><span>Omzet periode</span>') +
        rangeBar() + '<div class="kpis">' + kpis + '</div>' +
        '<div class="grid g2e">' + chart + payCard + '</div>' +
        (comp ? '<div class="divider"></div>' + comp : '') +
        '<div class="divider"></div>' + salesTbl;
    });
  };
  W.exportPos = function () {
    var sales = W.__posSales || [];
    exportCSV('pos-transaksi-' + S.to + '.csv',
      ['Waktu', 'Kode', 'Kasir', 'Pelanggan', 'Metode', 'Subtotal', 'Diskon', 'Total', 'Status'],
      sales.map(function (s) {
        return [s.createdAt ? new Date(s.createdAt).toLocaleString('id-ID') : '', s.code || s.id, s.cashierName || '', s.customerName || 'Umum',
          s.paymentMethod || '', s.subtotal || 0, (Number(s.discount || 0) + Number(s.memberDiscount || 0)), s.total || 0, s.voidedAt ? 'VOID' : 'PAID'];
      }));
  };
  function payMethods(sales) {
    var m = {};
    (sales || []).forEach(function (s) {
      if (s.voidedAt) return;
      var k = s.paymentMethod || 'LAINNYA';
      m[k] = (m[k] || 0) + (Number(s.total) || 0);
    });
    return Object.keys(m).map(function (k) { return { label: k, value: m[k], fmt: function (v) { return rpK(v); } }; })
      .sort(function (a, b) { return b.value - a.value; });
  }

  /* ==================== SHIFT ==================== */
  P.shift = function () {
    return all(safe(api('ops/admin/pos/shifts?from=' + S.from + '&to=' + S.to)), safe(api('ops/admin/pos/sessions')))
      .then(function (r) {
        var shifts = (r[0] || {}).items || [];
        var sessions = (r[1] || {}).items || [];
        W.__shifts = shifts;
        var open = sessions.filter(function (s) { return s.status === 'OPEN' || s.status === 'PENDING_APPROVAL'; }).length;
        var withClose = shifts.filter(function (s) { return s.cashDiff != null; });
        var diffTotal = withClose.reduce(function (a, s) { return a + (Number(s.cashDiff) || 0); }, 0);
        var expected = shifts.reduce(function (a, s) { return a + (Number(s.expectedCash) || 0); }, 0);
        var revenue = shifts.reduce(function (a, s) { return a + (Number((s.totals || {}).total) || 0); }, 0);

        var kpis = kpi({ cls: 'k-info', icon: IC.clock, label: 'Sesi Aktif', value: fmt(open), sub: 'Belum ditutup' }) +
          kpi({ icon: IC.clock, label: 'Total Sesi', value: fmt(shifts.length), sub: 'Periode ini' }) +
          kpi({ cls: 'k-accent', icon: IC.money, label: 'Omzet Sesi', value: rpK(revenue), sub: 'Akumulasi' }) +
          kpi({ cls: (diffTotal < 0 ? 'k-danger' : 'k-warn'), icon: IC.alert, label: 'Total Selisih Kas', value: rpK(diffTotal), sub: withClose.length + ' sesi ditutup' }) +
          kpi({ icon: IC.money, label: 'Kas Diharapkan', value: rpK(expected), sub: 'Expected cash' });

        var tbl = card('Riwayat Shift', 'Periode ' + S.from + ' s/d ' + S.to, expBtn('Ekspor CSV', 'exportShift()'),
          table([
            { h: 'Shift', cell: function (s) { return '<div class="tname">' + esc(s.shiftLabel || s.code || ('Sesi #' + (s.shiftNo || '—'))) + '</div><div class="tsub">' + esc(s.cashierName || '') + '</div>'; } },
            { h: 'Buka', cell: function (s) { return timeOf(s.openedAt); } },
            { h: 'Tutup', cell: function (s) { return s.closedAt ? timeOf(s.closedAt) : '—'; } },
            { h: 'Kas Awal', cls: 'num', cell: function (s) { return rp(s.openingCash); } },
            { h: 'Kas Akhir', cls: 'num', cell: function (s) { return s.closingCash != null ? rp(s.closingCash) : '—'; } },
            { h: 'Diharapkan', cls: 'num', cell: function (s) { return s.expectedCash != null ? rp(s.expectedCash) : '—'; } },
            { h: 'Selisih', cls: 'num', cell: function (s) { return s.cashDiff != null ? '<b style="color:' + (Number(s.cashDiff) < 0 ? 'var(--danger)' : 'var(--ok)') + '">' + rp(s.cashDiff) + '</b>' : '—'; } },
            { h: 'Status', cell: function (s) { return shiftStatus(s.status); } },
          ], shifts), { tight: true, icon: IC.clock });

        return pagehead(IC.clock, 'Shift Kasir', 'Sesi kas, selisih uang & serah terima shift',
          '<b>' + fmt(open) + '</b><span>Sesi aktif</span>') +
          rangeBar() + '<div class="kpis">' + kpis + '</div>' + tbl;
      });
  };
  W.exportShift = function () {
    exportCSV('shift-' + S.from + '_' + S.to + '.csv',
      ['Shift', 'Kasir', 'Buka', 'Tutup', 'Kas Awal', 'Kas Akhir', 'Diharapkan', 'Selisih', 'Status'],
      (W.__shifts || []).map(function (s) {
        return [s.shiftLabel || s.code || '', s.cashierName || '', s.openedAt || '', s.closedAt || '',
          s.openingCash || 0, s.closingCash == null ? '' : s.closingCash, s.expectedCash == null ? '' : s.expectedCash,
          s.cashDiff == null ? '' : s.cashDiff, s.status || ''];
      }));
  };

  /* ==================== OPNAME ==================== */
  P.opname = function () {
    return safe(api('ops/admin/opnames')).then(function (r) {
      var items = (r || {}).items || [];
      W.__opnames = items;
      var total = items.length;
      var pending = items.filter(function (o) { return String(o.status).toUpperCase() === 'PENDING'; }).length;
      var approved = items.filter(function (o) { return String(o.status).toUpperCase() === 'APPROVED'; }).length;
      var totalDiff = items.reduce(function (a, o) { return a + (Number(o.totalDiff) || 0); }, 0);
      var totalItems = items.reduce(function (a, o) { return a + (Number(o.totalItems) || 0); }, 0);

      var kpis = kpi({ icon: IC.box, label: 'Total Sesi', value: fmt(total), sub: 'Semua waktu' }) +
        kpi({ cls: 'k-warn', icon: IC.clock, label: 'Menunggu Review', value: fmt(pending), sub: 'Perlu persetujuan' }) +
        kpi({ icon: IC.check, label: 'Disetujui', value: fmt(approved), sub: 'Selesai' }) +
        kpi({ cls: 'k-info', icon: IC.bag, label: 'Item Dihitung', value: fmt(totalItems), sub: 'Akumulasi' }) +
        kpi({ cls: (totalDiff ? 'k-danger' : ''), icon: IC.alert, label: 'Total Selisih', value: fmt(totalDiff), sub: 'Unit' });

      var tbl = card('Sesi Opname', 'Klik "Detail" untuk melihat rincian per produk', expBtn('Ekspor CSV', 'exportOpname()'),
        table([
          { h: 'Tanggal', cell: function (o) { return '<span class="tname">' + dateOf(o.createdAt) + '</span><div class="tsub">' + timeOf(o.createdAt) + '</div>'; } },
          { h: 'Petugas', cell: function (o) { return esc(o.employeeName || '—'); } },
          { h: 'Jenis', cell: function (o) { return '<span class="chip mut">' + esc(o.kind || '—') + '</span>'; } },
          { h: 'Area', cell: function (o) { return esc(o.area || '—'); } },
          { h: 'Item', cls: 'num', cell: function (o) { return fmt(o.totalItems); } },
          { h: 'Selisih', cls: 'num', cell: function (o) { var d = Number(o.totalDiff) || 0; return '<b style="color:' + (d ? 'var(--danger)' : 'var(--ok)') + '">' + fmt(d) + '</b>'; } },
          { h: 'Status', cell: function (o) { return opnBadge(o.status); } },
          { h: '', cell: function (o) { return '<button class="btn ghost sm" onclick="showOpname(\'' + o.id + '\')">Detail</button>'; } },
        ], items, { empty: 'Belum ada sesi opname' }), { tight: true, icon: IC.box });

      return pagehead(IC.box, 'Stock Opname', 'Sesuaian stok fisik dengan sistem',
        '<b>' + fmt(total) + '</b><span>Total sesi</span>') +
        '<div class="kpis">' + kpis + '</div>' + tbl +
        '<div id="opname-detail" style="margin-top:16px"></div>';
    });
  };
  W.exportOpname = function () {
    exportCSV('opname.csv', ['Tanggal', 'Petugas', 'Jenis', 'Area', 'Item', 'Selisih', 'Status'],
      (W.__opnames || []).map(function (o) {
        return [o.createdAt || '', o.employeeName || '', o.kind || '', o.area || '', o.totalItems || 0, o.totalDiff || 0, o.status || ''];
      }));
  };
  W.showOpname = function (id) {
    var box = W.document.getElementById('opname-detail');
    box.innerHTML = loading('Memuat rincian…');
    api('ops/admin/opnames/' + id).then(function (r) {
      var o = r.opname || {}, items = r.items || [];
      var diffs = items.filter(function (i) { return Number(i.diff) !== 0; });
      W.__opnameDetail = { head: o, items: items };
      box.innerHTML = card('Rincian Opname — ' + (o.employeeName || ''), dateOf(o.createdAt) + ' · ' + (o.area || '') + ' · ' + items.length + ' item',
        '<button class="btn ghost sm" onclick="exportOpnameDetail()">Ekspor CSV</button>' +
        '<button class="btn ghost sm" onclick="document.getElementById(\'opname-detail\').innerHTML=\'\'">Tutup</button>',
        '<div class="kpis" style="margin-bottom:14px;grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">' +
        kpi({ label: 'Total Item', value: fmt(o.totalItems) }) +
        kpi({ cls: 'k-danger', label: 'Item Beda', value: fmt(diffs.length) }) +
        kpi({ label: 'Total Selisih', value: fmt(o.totalDiff) }) + '</div>' +
        table([
          { h: 'Produk', cell: function (i) { return '<span class="tname">' + esc(i.productName || '') + '</span><div class="tsub">' + esc(i.sku || '') + '</div>'; } },
          { h: 'Stok Sistem', cls: 'num', cell: function (i) { return fmt(i.systemStock); } },
          { h: 'Hasil Hitung', cls: 'num', cell: function (i) { return fmt(i.countedStock); } },
          { h: 'Selisih', cls: 'num', cell: function (i) { var d = Number(i.diff) || 0; return '<b style="color:' + (d ? 'var(--danger)' : 'var(--ok)') + '">' + fmt(d) + '</b>'; } },
          { h: 'Masuk', cls: 'num', cell: function (i) { return fmt(i.qtyIn); } },
          { h: 'Keluar', cls: 'num', cell: function (i) { return fmt(i.qtyOut); } },
          { h: 'Catatan', cell: function (i) { return esc(i.note || '—'); } },
        ], items), { tight: true, icon: IC.box });
    }).catch(function (e) { box.innerHTML = state(IC.alert, 'Gagal memuat rincian', e.message, 'danger'); });
  };
  W.exportOpnameDetail = function () {
    var d = W.__opnameDetail || { items: [] };
    exportCSV('opname-detail.csv', ['Produk', 'SKU', 'Stok Sistem', 'Hasil Hitung', 'Selisih', 'Masuk', 'Keluar', 'Catatan'],
      (d.items || []).map(function (i) { return [i.productName || '', i.sku || '', i.systemStock || 0, i.countedStock || 0, i.diff || 0, i.qtyIn || 0, i.qtyOut || 0, i.note || '']; }));
  };

  /* ==================== ABSENSI ==================== */
  P.absensi = function () {
    var date = S.to;
    return safe(api('admin/attendance?date=' + date)).then(function (r) {
      r = r || { summary: {}, items: [] };
      var s = r.summary || {}, items = r.items || [];
      W.__att = items;
      var hadir = (s.hadir || 0) + (s.terlambat || 0), hp = pct(hadir, s.total || 0);

      var kpis = kpi({ icon: IC.user, label: 'Total Karyawan', value: fmt(s.total || 0), sub: 'Terdaftar aktif' }) +
        kpi({ icon: IC.check, label: 'Hadir', value: fmt(hadir), sub: fmt(s.hadir || 0) + ' tepat waktu' }) +
        kpi({ cls: 'k-warn', icon: IC.clock, label: 'Terlambat', value: fmt(s.terlambat || 0), sub: 'Perlu perhatian' }) +
        kpi({ cls: 'k-danger', icon: IC.alert, label: 'Alfa', value: fmt(s.alfa || 0), sub: 'Tanpa keterangan' }) +
        kpi({ cls: 'k-info', icon: IC.clock, label: 'Belum Checkout', value: fmt(s.belumCheckout || 0), sub: 'Masih di dalam' }) +
        kpi({ icon: IC.trend, label: 'Lembur', value: durMin(s.lemburMenit || 0), sub: fmt(s.lemburCount || 0) + ' karyawan' });

      var don = card('Rekap Kehadiran', 'Per ' + date, '', donut(hp, 'Hadir', fmt1(hp) + '%', [
        { color: '#0B6B2E', label: 'Hadir', value: fmt(s.hadir || 0) },
        { color: '#F26A1B', label: 'Terlambat', value: fmt(s.terlambat || 0) },
        { color: '#C62828', label: 'Alfa', value: fmt(s.alfa || 0) },
        { color: '#1D6FB8', label: 'Libur', value: fmt(s.libur || 0) },
      ]), { icon: IC.user });

      var byStatus = card('Sebaran Status', 'Jumlah karyawan', '', hbars([
        { label: 'Hadir', value: s.hadir || 0 },
        { label: 'Terlambat', value: s.terlambat || 0 },
        { label: 'Alfa', value: s.alfa || 0 },
        { label: 'Libur', value: s.libur || 0 },
        { label: 'Belum Checkout', value: s.belumCheckout || 0 },
      ]), { icon: IC.grid });

      var tbl = card('Daftar Kehadiran — ' + date, fmt(items.length) + ' karyawan', expBtn('Ekspor CSV', 'exportAbsensi()'),
        table([
          { h: 'Karyawan', cell: function (e) { return avatarCell(e.fullName, e.employeeCode, e.position, e.photoBase64); } },
          { h: 'Shift', cell: function (e) { return esc(e.shiftName || '—') + '<div class="tsub">' + esc((e.shiftStart || '') + '–' + (e.shiftEnd || '')) + '</div>'; } },
          { h: 'Masuk', cell: function (e) { return e.checkInAt ? timeOf(e.checkInAt) : '—'; } },
          { h: 'Keluar', cell: function (e) { return e.checkOutAt ? timeOf(e.checkOutAt) : '—'; } },
          { h: 'Telat', cls: 'num', cell: function (e) { return e.lateMinutes ? '<b style="color:var(--accent-700)">' + fmt(e.lateMinutes) + 'm</b>' : '—'; } },
          { h: 'Jam Kerja', cls: 'num', cell: function (e) { return durMin(e.workMinutes); } },
          { h: 'Status', cell: function (e) { return attBadge(e.status); } },
        ], items, { empty: 'Belum ada data kehadiran pada tanggal ini' }), { tight: true, icon: IC.user });

      return pagehead(IC.user, 'Absensi', 'Kehadiran, keterlambatan & jam kerja karyawan',
        '<b>' + fmt(hadir) + '/' + fmt(s.total || 0) + '</b><span>Hadir hari ini</span>') +
        rangeBar('<div class="pill">Tanggal: <b>&nbsp;' + date + '</b></div>') +
        '<div class="kpis">' + kpis + '</div>' +
        '<div class="grid g2e">' + don + byStatus + '</div>' +
        '<div class="divider"></div>' + tbl;
    });
  };
  W.exportAbsensi = function () {
    exportCSV('absensi-' + S.to + '.csv', ['Kode', 'Nama', 'Jabatan', 'Shift', 'Masuk', 'Keluar', 'Telat (menit)', 'Jam Kerja', 'Status'],
      (W.__att || []).map(function (e) {
        return [e.employeeCode || '', e.fullName || '', e.position || '', e.shiftName || '',
          e.checkInAt ? timeOf(e.checkInAt) : '', e.checkOutAt ? timeOf(e.checkOutAt) : '',
          e.lateMinutes || 0, e.workMinutes || 0, e.status || ''];
      }));
  };

  /* ==================== JURNAL / KEUANGAN ==================== */
  P.jurnal = function () {
    return all(safe(japi('accounts')), safe(japi('journal')), W.__isDemo()?Promise.resolve(null):
      safe(api('accounting/trial-balance?from='+encodeURIComponent(S.from)+'&to='+encodeURIComponent(S.to)))).then(function (r) {
      if(!r[0]||!r[1]||(!W.__isDemo()&&!r[2])){
        W.__jAccounts=[];W.__jEntries=[];W.__jTB=[];
        return pagehead(IC.book,'Jurnal & Keuangan','Periksa akses dan ketersediaan data')+
          state(IC.alert,'Data keuangan tidak tersedia','Sesi, hak akses, atau layanan Jurnal perlu diperiksa. Tidak ada angka pengganti.','danger');
      }
      var accounts = (r[0] || {}).accounts || [];
      var entries = (r[1] || {}).entries || [];
      W.__jAccounts = accounts; W.__jEntries = entries;

      var totalDebit = 0, totalCredit = 0;
      (entries || []).forEach(function (e) {
        totalDebit+=sumLines(e,'debit');totalCredit+=sumLines(e,'credit');
      });
      var bal = Math.abs(totalDebit - totalCredit) < 0.01;

      var tb = {};
      (entries || []).forEach(function (e) {
        (e.journal_lines || e.lines || []).forEach(function (l) {
          var acc = l.accounts || {};
          var code = acc.code || (l.account_id || '').slice(0, 8), name = acc.name || '—';
          var k = code + '|' + name;
          tb[k] = tb[k] || { code: code, name: name, debit: 0, credit: 0 };
          tb[k].debit += Number(l.debit) || 0; tb[k].credit += Number(l.credit) || 0;
        });
      });
      var tbRows = Object.keys(tb).map(function (k) { return tb[k]; }).sort(function (a, b) { return String(a.code).localeCompare(String(b.code)); });
      if(r[2]){
        tbRows=r[2].accounts||r[2].items||r[2].rows||[];
        totalDebit=Number(r[2].totalDebit);
        totalCredit=Number(r[2].totalCredit);
        bal=r[2].balanced===true;
      }
      W.__jTB = tbRows;

      var kpis = kpi({ cls: 'k-info', icon: IC.book, label: 'Bagan Akun', value: fmt(accounts.length), sub: 'Chart of accounts' }) +
        kpi({ icon: IC.book, label: 'Entri Jurnal', value: fmt(entries.length), sub: '100 entri terakhir' }) +
        kpi({ cls: 'k-info', icon: IC.trend, label: 'Total Debit', value: rpK(totalDebit), sub: 'Akumulasi' }) +
        kpi({ cls: 'k-info', icon: IC.trend, label: 'Total Kredit', value: rpK(totalCredit), sub: 'Akumulasi' }) +
        kpi({ cls: bal ? '' : 'k-danger', icon: bal ? IC.check : IC.alert, label: 'Keseimbangan', value: bal ? 'Seimbang' : 'Tidak Balance', sub: 'Debit = Kredit' });

      var accTbl = card('Bagan Akun', fmt(accounts.length) + ' akun', expBtn('CSV', 'exportJurnal("accounts")'),
        table([
          { h: 'Kode', cell: function (a) { return '<span class="mono">' + esc(a.code || '') + '</span>'; } },
          { h: 'Nama Akun', cell: function (a) { return '<span class="tname">' + esc(a.name || '') + '</span>'; } },
          { h: 'Tipe', cell: function (a) { var t = a.type_of_account || {}; return esc(t.name || t.report_section || '—'); } },
          { h: 'Normal', cell: function (a) { var t = a.type_of_account || {}; return esc(t.normal_balance || '—'); } },
          { h: 'Status', cell: function (a) { return a.is_active === false ? '<span class="badge-status s-mut">Nonaktif</span>' : '<span class="badge-status s-ok">Aktif</span>'; } },
        ], accounts, { empty: 'Bagan akun belum diisi', emptyMsg: 'Bagan akun belum tersedia untuk periode ini.' }), { tight: true, icon: IC.book });

      var tbTbl = card('Neraca Saldo', W.__isDemo()?'Data contoh':'Jurnal terposting pada periode terpilih', expBtn('CSV', 'exportJurnal("tb")'),
        table([
          { h: 'Kode', cell: function (a) { return '<span class="mono">' + esc(a.code) + '</span>'; } },
          { h: 'Akun', key: 'name' },
          { h: 'Debit', cls: 'num', cell: function (a) { return rp(a.debit); } },
          { h: 'Kredit', cls: 'num', cell: function (a) { return rp(a.credit); } },
          { h: 'Saldo', cls: 'num', cell: function (a) { var s2 = a.debit - a.credit; return '<b style="color:' + (s2 < 0 ? 'var(--danger)' : 'var(--ok)') + '">' + rp(s2) + '</b>'; } },
        ], tbRows, { empty: 'Belum ada mutasi', emptyMsg: 'Neraca saldo dihitung dari entri jurnal' }), { tight: true, icon: IC.grid });

      var entTbl = card('Entri Jurnal Terakhir', fmt(entries.length) + ' entri', expBtn('CSV', 'exportJurnal("entry")'),
        table([
          { h: 'Tanggal', cell: function (e) { return dateOf(e.entry_date || e.entryDate); } },
          { h: 'No.', cell: function (e) { return '<span class="mono">' + esc(e.entry_no || e.entryNo || (e.id || '').slice(0, 8)) + '</span>'; } },
          { h: 'Memo', cell: function (e) { return esc(e.memo || e.description || '—'); } },
          { h: 'Sumber', cell: function (e) { return '<span class="chip mut">' + esc(e.source || '—') + '</span>'; } },
          { h: 'Debit', cls: 'num', cell: function (e) { return rp(sumLines(e, 'debit')); } },
          { h: 'Kredit', cls: 'num', cell: function (e) { return rp(sumLines(e, 'credit')); } },
        ], entries, { empty: 'Belum ada entri jurnal', emptyMsg: 'Entri akan tampil setelah jurnal diisi' }), { tight: true, icon: IC.book });

      return pagehead(IC.book, 'Jurnal & Keuangan', 'Buku besar, neraca saldo & laba rugi',
        '<b>' + fmt(entries.length) + '</b><span>Entri jurnal</span>') +
        rangeBar() + '<div class="kpis">' + kpis + '</div>' +
        '<div class="grid g2e">' + accTbl + tbTbl + '</div>' +
        '<div class="divider"></div>' + entTbl;
    });
  };
  W.exportJurnal = function (what) {
    if (what === 'accounts') {
      exportCSV('jurnal-bagan-akun.csv', ['Kode', 'Nama', 'Tipe', 'Normal', 'Status'],
        (W.__jAccounts || []).map(function (a) { var t = a.type_of_account || {}; return [a.code || '', a.name || '', t.name || '', t.normal_balance || '', a.is_active === false ? 'Nonaktif' : 'Aktif']; }));
    } else if (what === 'tb') {
      exportCSV('jurnal-neraca-saldo.csv', ['Kode', 'Akun', 'Debit', 'Kredit', 'Saldo'],
        (W.__jTB || []).map(function (a) { return [a.code, a.name, a.debit, a.credit, a.debit - a.credit]; }));
    } else {
      exportCSV('jurnal-entri.csv', ['Tanggal', 'No', 'Memo', 'Sumber', 'Debit', 'Kredit'],
        (W.__jEntries || []).map(function (e) { return [e.entry_date || e.entryDate || '', e.entry_no || e.entryNo || e.id || '', e.memo || e.description || '', e.source || '', sumLines(e, 'debit'), sumLines(e, 'credit')]; }));
    }
  };
  function sumLines(e, key) {
    var total=key==='debit'?e.totalDebit:e.totalCredit;
    if(total!==undefined&&total!==null)return Number(total)||0;
    var lines = e.journal_lines || e.lines || [];
    return lines.reduce(function (a, l) { return a + (Number(l[key]) || 0); }, 0);
  }
})();
