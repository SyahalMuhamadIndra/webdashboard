/* =====================================================================
   SIMAUNG CORPORATION — PUSAT LAPORAN (report.tokokartini.com)
   ---------------------------------------------------------------------
   Satu halaman untuk SEMUA laporan:
     1. Ringkasan   — gabungan seluruh domain
     2. Kasir / POS — penjualan harian & periode
     3. Shift Kasir — sesi & selisih kas
     4. Stock Opname
     5. Absensi     — kehadiran karyawan
     6. Jurnal      — keuangan (jurnal.tokokartini.com)
   ---------------------------------------------------------------------
   Auth : satu akun admin terpadu (POST /api/admin/login).
   API  : api.tokokartini.com (POS/Shift/Opname/Absensi)
          /j/  → jurnal.tokokartini.com/api (diproksi via Vercel)
   ===================================================================== */
(function () {
  'use strict';

  /* ==================== KONFIG ==================== */
  var API   = ((window.__API_BASE__ || 'https://api.tokokartini.com/api/').replace(/\/+$/, '')) + '/';
  var JURL  = (window.__JURNAL_BASE__ || '/j/').replace(/\/+$/, '') + '/';
  var CID   = window.__COMPANY_ID__ || 'a4b32ac6-b744-4453-9bc9-04e1fc0b9217';
  var LS    = { token: 'tk_report_token', user: 'tk_report_user', nav: 'tk_report_nav' };

  var S = {
    token: null, user: null, page: 'ringkasan',
    from: null, to: null, range: 7,
    demo: false,          // mode demo (data contoh) aktif?
    liveFailed: false,    // API live tak terjangkau (untuk saran tombol demo)
  };

  /* ==================== MODE DEMO ==================== */
  function isDemo() { return S.demo === true; }
  function mockApi(path, opts) {
    if (window.REPORTMOCK && typeof window.REPORTMOCK.api === 'function') return window.REPORTMOCK.api(path, opts);
    return Promise.resolve({});
  }

  /* ==================== HELPERS ==================== */
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); }
  function num(n) { var v = Number(n); return isFinite(v) ? v : 0; }
  function fmt(n) { return num(n).toLocaleString('id-ID'); }
  function fmt1(n) { return num(n).toLocaleString('id-ID', { maximumFractionDigits: 1 }); }
  function rp(n) { return 'Rp ' + fmt(Math.round(num(n))); }
  function rpK(n) {
    n = num(n);
    if (Math.abs(n) >= 1e9) return 'Rp ' + fmt1(n / 1e9) + ' M';
    if (Math.abs(n) >= 1e6) return 'Rp ' + fmt1(n / 1e6) + ' jt';
    if (Math.abs(n) >= 1e3) return 'Rp ' + fmt1(n / 1e3) + ' rb';
    return 'Rp ' + fmt(n);
  }
  function pct(a, b) { b = num(b); return b ? (num(a) / b) * 100 : 0; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function isoOf(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function todayISO() { return isoOf(new Date()); }
  function addDays(iso, days) { var d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + days); return isoOf(d); }
  function initials(name) { var p = String(name || 'A').trim().split(/\s+/); return ((p[0] || 'A')[0] + (p[1] ? p[1][0] : '')).toUpperCase(); }
  function avColor(name) { var s = String(name || ''), n = 0; for (var i = 0; i < s.length; i++) n = (n + s.charCodeAt(i)) % 5; return n ? ' a' + (n + 1) : ''; }
  function timeOf(v) {
    if (!v) return '—';
    var d = new Date(v); if (isNaN(d)) return '—';
    return pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  function dateOf(v) {
    if (!v) return '—';
    var d = new Date(v); if (isNaN(d)) return '—';
    return d.getDate() + ' ' + ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'][d.getMonth()] + ' ' + d.getFullYear();
  }
  function dayName(iso) {
    var d = new Date(iso + 'T00:00:00'); if (isNaN(d)) return '';
    return ['Min','Sen','Sel','Rab','Kam','Jum','Sab'][d.getDay()];
  }
  function durMin(m) {
    m = num(m); if (!m) return '—';
    var h = Math.floor(m / 60), r = Math.round(m % 60);
    return (h ? h + 'j ' : '') + r + 'm';
  }

  /* ==================== TOAST ==================== */
  function toast(msg, kind) {
    var w = $('toast'), el = document.createElement('div');
    el.className = 'toast ' + (kind || ''); el.textContent = msg; w.appendChild(el);
    setTimeout(function () { el.style.transition = 'opacity .3s'; el.style.opacity = '0'; setTimeout(function () { el.remove(); }, 320); }, 3000);
  }

  /* ==================== EXPORT CSV ==================== */
  function exportCSV(filename, headers, rows) {
    try {
      var q = function (v) { v = (v == null ? '' : String(v)); return '"' + v.replace(/"/g, '""') + '"'; };
      var lines = [headers.map(q).join(';')];
      rows.forEach(function (r) { lines.push(r.map(q).join(';')); });
      var csv = '\ufeff' + lines.join('\r\n');
      var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      var url = URL.createObjectURL(blob), a = document.createElement('a');
      a.href = url; a.download = filename; document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 400);
      toast('Diekspor: ' + filename, 'ok');
    } catch (e) { toast('Gagal ekspor: ' + e.message, 'err'); }
  }

  /* ==================== API CLIENT ==================== */
  function api(path, opts) {
    opts = opts || {};
    if (isDemo()) return mockApi(path, opts);
    var headers = { 'Content-Type': 'application/json' };
    if (opts.auth !== false && S.token) headers['Authorization'] = 'Bearer ' + S.token;
    return fetch(API + String(path).replace(/^\/+/, ''), {
      method: opts.method || 'GET', headers: headers,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (res.status === 401 && opts.auth !== false) {
          var gone = (data && (data.code === 'ACCOUNT_GONE' || /dihapus/i.test(data.message || '')));
          if (!gone) logout(true);
          throw new Error(data.message || 'Sesi berakhir.');
        }
        if (!res.ok) throw new Error((data && data.message) || ('Gagal (' + res.status + ')'));
        return data;
      });
    });
  }
  function japi(path, opts) {
    if (isDemo()) return mockApi(path, opts);
    if(path==='accounts')return api('accounting/accounts').then(function(r){
      if(!Array.isArray(r.items))throw new Error('Daftar akun tidak tersedia.');
      return {accounts:r.items.map(function(a){return {...a,type_of_account:{name:a.typeName,normal_balance:a.normalBalance}}})};
    });
    if(path==='journal')return api('accounting/journal').then(function(r){
      if(!Array.isArray(r.items))throw new Error('Jurnal tidak tersedia.');
      return {entries:r.items.map(function(e){return {...e,entryNo:e.entryNumber}})};
    });
    return Promise.reject(new Error('Laporan keuangan tidak dikenal.'));
  }

  /* ==================== UI SNIPPETS ==================== */
  function kpi(o) {
    return '<div class="kpi ' + (o.cls || '') + '">' +
      '<div class="k-top"><span class="k-ico">' + (o.icon || '') + '</span>' + esc(o.label) + '</div>' +
      '<div class="k-val">' + (o.value) + (o.unit ? ' <small>' + esc(o.unit) + '</small>' : '') + '</div>' +
      (o.sub ? '<div class="k-sub">' + o.sub + '</div>' : '') +
      '</div>';
  }
  var IC = {
    sales: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18M7 15h4"/></svg>',
    money: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/></svg>',
    bag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 8h12l-1 12H7L6 8z"/><path d="M9 8a3 3 0 0 1 6 0"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>',
    user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="3.6"/><path d="M5 20a7 7 0 0 1 14 0"/></svg>',
    box: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 8 12 3 3 8v8l9 5 9-5V8z"/><path d="M3 8l9 5 9-5M12 21V13"/></svg>',
    book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3V4z"/><path d="M19 4v16M9 8h6M9 12h6"/></svg>',
    trend: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/></svg>',
    alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l9 16H3l9-16z"/><path d="M12 10v4M12 17h.01"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12.5 9 17.5 20 6.5"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
    grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
    ringkas: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>',
    down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12m0 0-4-4m4 4 4-4M4 19h16"/></svg>',
  };

  function stateBox(icon, title, msg, cls) {
    return '<div class="state ' + (cls || '') + '"><div class="s-ico">' + icon + '</div><b>' + esc(title) + '</b><p>' + esc(msg || '') + '</p></div>';
  }
  function loadingBox(msg) {
    return '<div class="card"><div class="card-b">' + stateBox('<div class="spinner"></div>', msg || 'Memuat data…', '') + '</div></div>';
  }
  function badge(txt, cls) { return '<span class="badge-status ' + (cls || 's-mut') + '">' + esc(txt) + '</span>'; }

  /* Kotak info header halaman (hero) */
  function pagehead(icon, title, sub, meta) {
    return '<div class="pagehead">' +
      '<div class="ph-ico">' + (icon || IC.trend) + '</div>' +
      '<div class="ph-txt"><h2>' + esc(title) + '</h2><p>' + esc(sub || '') + '</p></div>' +
      (meta ? '<div class="ph-meta">' + meta + '</div>' : '') + '</div>';
  }

  /* Normalisasi status absensi yang mungkin masih mentah dari backend */
  function attLabel(s) {
    s = String(s || '').toUpperCase();
    var m = {
      HADIR: ['Hadir', 's-ok'], TERLAMBAT: ['Terlambat', 's-warn'],
      ALFA: ['Alfa', 's-danger'], LIBUR: ['Libur', 's-info'], CUTI: ['Cuti', 's-info'],
      IZIN: ['Izin', 's-info'], SAKIT: ['Sakit', 's-warn'], OFF: ['Off', 's-mut'],
      BELUM_CHECKOUT: ['Belum Checkout', 's-warn'],
      TERLAMBAT_BELUM_CHECKOUT: ['Terlambat · Belum Checkout', 's-warn'],
    };
    return m[s] || [s.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, function (c) { return c.toUpperCase(); }) || '—', 's-mut'];
  }
  function attBadge(s) { var l = attLabel(s); return badge(l[0], l[1]); }

  /* ==================== CHART: vertical bars ==================== */
  function vbars(series, opt) {
    opt = opt || {};
    var vals = series.map(function (s) { return num(s.value); });
    var max = Math.max.apply(null, vals.concat([1]));
    var alt = opt.alt;
    return '<div class="bars">' + series.map(function (s) {
      var h = Math.max(3, Math.round((num(s.value) / max) * 100));
      return '<div class="bar-col">' +
        '<div class="bar-val">' + (opt.fmt ? opt.fmt(s.value) : fmt(s.value)) + '</div>' +
        '<div class="bar-track"><div class="bar ' + (alt ? 'alt' : '') + '" style="height:' + h + '%"></div></div>' +
        '<div class="bar-lbl">' + esc(s.label) + '</div></div>';
    }).join('') + '</div>';
  }

  /* ==================== CHART: horizontal bars ==================== */
  function hbars(items, cls) {
    var max = Math.max.apply(null, items.map(function (i) { return num(i.value); }).concat([1]));
    return '<div class="hbars">' + items.map(function (i) {
      var w = Math.max(2, Math.round((num(i.value) / max) * 100));
      return '<div class="hbar"><div class="tname" title="' + esc(i.label) + '">' + esc(i.label) + '</div>' +
        '<div class="hb-track"><div class="hb-fill ' + (cls || '') + '" style="width:' + w + '%"></div></div>' +
        '<div class="hb-val">' + (i.fmt ? i.fmt(i.value) : fmt(i.value)) + '</div></div>';
    }).join('') + '</div>';
  }

  /* ==================== CHART: donut ==================== */
  function donut(percent, label, big, legend) {
    return '<div class="donut-wrap">' +
      '<div class="donut" style="--p:' + Math.max(0, Math.min(100, num(percent))) + '">' +
      '<div class="d-lab"><b>' + esc(big) + '</b><span>' + esc(label) + '</span></div></div>' +
      (legend ? '<div class="legend">' + legend.map(function (l) {
        return '<div class="lg-row"><span class="dot" style="background:' + l.color + '"></span>' + esc(l.label) + '<b>' + esc(l.value) + '</b></div>';
      }).join('') + '</div>' : '') + '</div>';
  }

  /* ==================== RANGE CONTROL ==================== */
  function rangeBar(extra) {
    var segs = [['1', 'Hari ini'], ['7', '7 hari'], ['30', '30 hari'], ['90', '90 hari']];
    var h = '<div class="filterbar"><div class="fb-title">' + IC.clock + ' Periode</div><div class="seg">' +
      segs.map(function (s) { return '<button class="' + (String(S.range) === s[0] ? 'on' : '') + '" onclick="setRange(\'' + s[0] + '\')">' + s[1] + '</button>'; }).join('') +
      '</div><div class="dates"><input type="date" id="f-from" value="' + S.from + '" onchange="setDate(\'from\',this.value)">' +
      '<span style="color:var(--mut);font-weight:700">s/d</span>' +
      '<input type="date" id="f-to" value="' + S.to + '" onchange="setDate(\'to\',this.value)"></div>' +
      (extra || '') + '</div>';
    return h;
  }

  /* ==================== TABLES ==================== */
  function table(cols, rows, opt) {
    opt = opt || {};
    var head = '<tr>' + cols.map(function (c) { return '<th class="' + (c.cls || '') + '">' + esc(c.h) + '</th>'; }).join('') + '</tr>';
    var body = rows.length ? rows.map(function (r) {
      return '<tr>' + cols.map(function (c) { return '<td class="' + (c.cls || '') + '">' + (c.cell ? c.cell(r) : esc(r[c.key])) + '</td>'; }).join('') + '</tr>';
    }).join('') : '';
    if (!rows.length) return stateBox(IC.box, opt.empty || 'Belum ada data', opt.emptyMsg || 'Tidak ada catatan pada periode ini.');
    return '<div class="tbl-wrap"><table class="tbl"><thead>' + head + '</thead><tbody>' + body + '</tbody></table></div>';
  }

  /* ==================== STATUS ==================== */
  function shiftStatus(s) {
    switch (s) {
      case 'OPEN': return badge('Berjalan', 's-info');
      case 'CLOSED': return badge('Ditutup', 's-ok');
      case 'APPROVED': return badge('Disetujui', 's-ok');
      case 'FORCE_CLOSED': return badge('Paksa Tutup', 's-warn');
      default: return badge(s || '—', 's-mut');
    }
  }

  /* ==================== NAV / SHELL ==================== */
  var TITLES = {
    multibisnis: ['Laporan Multibisnis', 'Laporan per unit dan seluruh unit'],
    ringkasan: ['Ringkasan', 'Gambaran menyeluruh seluruh laporan Simaung Corporation'],
    kpi: ['KPI Lintas Modul', 'Indikator kinerja utama dari seluruh modul Simaung Corporation'],
    pos: ['Kasir / POS', 'Laporan penjualan, transaksi & penerimaan kasir'],
    shift: ['Shift Kasir', 'Sesi kas, selisih uang & serah terima shift'],
    opname: ['Stock Opname', 'Sesuaian stok fisik dengan sistem'],
    absensi: ['Absensi', 'Kehadiran, keterlambatan & jam kerja karyawan'],
    jurnal: ['Jurnal & Keuangan', 'Buku besar, laba rugi & arus kas'],
  };
  var CRUMB = {
    ringkasan: '', kpi: 'Analitik', pos: 'Operasional', shift: 'Operasional',
    opname: 'Operasional', absensi: 'SDM & Keuangan', jurnal: 'SDM & Keuangan',
  };
  function setTitle(p) {
    var t = window.__operationsWorkspace?[document.body.dataset.propertyLabel||'Operasional Unit','Kelola kegiatan dan pengaturan unit']:TITLES[p] || TITLES.ringkasan;
    $('pg-title').innerHTML = esc(t[0]) + ' <small>' + esc(t[1]) + '</small>';
    var sec = CRUMB[p] || '';
    if ($('pg-crumb')) $('pg-crumb').textContent = window.__operationsWorkspace?(document.body.dataset.propertyLabel||'Operasional Simaung'):sec ? ('Pusat Laporan › ' + sec) : 'Pusat Laporan';
  }
  function openNav() { $('sidebar').classList.add('open'); $('backdrop').classList.add('show'); }
  function closeNav() { $('sidebar').classList.remove('open'); $('backdrop').classList.remove('show'); }

  /* Lencana "MODE DEMO" di topbar + sidebar */
  function renderDemoBadge() {
    var on = isDemo();
    var b = $('demo-badge');
    if (b) {
      b.style.display = on ? 'inline-flex' : 'none';
      b.innerHTML = on ? '<span class="dot"></span>Mode Demo · Data Contoh' : '';
    }
    var sb = $('sb-demo');
    if (sb) sb.style.display = on ? 'inline-block' : 'none';
  }

  function goto(page) {
    if(window.__operationsWorkspace)page='multibisnis';
    if(!S.demo&&S.user?.role==='REPORT_USER')page='multibisnis';
    S.page = page; localStorage.setItem(LS.nav, page);
    var items = document.querySelectorAll('.nav-item');
    for (var i = 0; i < items.length; i++) items[i].classList.toggle('active', items[i].getAttribute('data-nav') === page);
    setTitle(page); closeNav();
    render();
  }

  function render() {
    var c = $('content');
    var page = S.page;                       // capture page for THIS render
    var seq = (S._seq = (S._seq || 0) + 1);  // monotonic guard: only the latest render wins
    c.innerHTML = skeleton();
    var fn = window.__pages[page] || window.__pages.ringkasan;
    Promise.resolve().then(fn).then(function (html) {
      if (S._seq !== seq || S.page !== page) return;   // stale — a newer navigation happened
      c.innerHTML = html;
      if (window.__after[page]) { try { window.__after[page](); } catch (e) {} }
    }).catch(function (e) {
      if (S._seq !== seq || S.page !== page) return;   // stale error — ignore
      var isNet = /Failed to fetch|NetworkError|Load failed|Network request failed/i.test(String(e && e.message || e));
      if (isNet) S.liveFailed = true;
      c.innerHTML = stateBox(IC.alert, 'Gagal memuat laporan', e.message || String(e), 'danger') +
        (isNet && !isDemo() ? '<div class="state-actions" style="text-align:center;margin-top:14px">' +
          '<button class="btn ghost" onclick="useDemoFromError()">Lihat Demo (Data Contoh)</button></div>' : '');
    });
  }
  function skeleton() {
    var one = '<div class="kpi"><div class="skel" style="height:12px;width:52%;margin-bottom:12px"></div><div class="skel" style="height:26px;width:70%;margin-bottom:9px"></div><div class="skel" style="height:10px;width:44%"></div></div>';
    var k = '<div class="kpis">' + one + one + one + one + '</div>';
    return '<div class="skel" style="height:14px;width:230px;margin-bottom:16px"></div>' + k +
      '<div class="grid g2e"><div class="card"><div class="card-b"><div class="skel" style="height:180px"></div></div></div>' +
      '<div class="card"><div class="card-b"><div class="skel" style="height:180px"></div></div></div></div>';
  }

  function reload() { render(); toast('Memuat ulang…'); }
  function setRange(r) {
    S.range = Number(r); var to = todayISO();
    S.to = to; S.from = addDays(to, -(S.range - 1));
    render();
  }
  function setDate(which, val) {
    if (!val) return; S[which] = val;
    if (S.from > S.to) { if (which === 'from') S.to = S.from; else S.from = S.to; }
    render();
  }

  /* ==================== AUTH ==================== */
  function showLogin() { $('auth').classList.remove('hidden'); $('app').classList.add('hidden'); try { $('lg-email').focus(); } catch (e) {} }
  function showApp() { $('auth').classList.add('hidden'); $('app').classList.remove('hidden'); }

  window.doLogin = function (e) {
    if (e && e.preventDefault) e.preventDefault();
    var email = ($('lg-email').value || '').trim(), pass = $('lg-pass').value || '';
    if (!email || !pass) { $('lg-msg').textContent = 'Email dan password wajib diisi.'; return false; }
    // Keluar dari mode demo bila sebelumnya aktif.
    S.demo = false; S.liveFailed = false;
    if (window.REPORTMOCK) window.REPORTMOCK.disable();
    var btn = $('lg-btn'); btn.disabled = true; $('lg-msg').textContent = 'Menghubungkan…';
    api('admin/business-reports/login', { method: 'POST', auth: false, body: { email: email, password: pass } })
      .then(function (r) {
        if (!r.token) throw new Error('Respons login tidak valid.');
        S.token = r.token; S.user = { name: r.name, email: r.email, role: r.role, companyId: r.companyId };
        localStorage.setItem(LS.token, S.token); localStorage.setItem(LS.user, JSON.stringify(S.user));
        return startAuthorized().then(function (allowed) { if(allowed)toast('Selamat datang, ' + (r.name || 'Admin') + '!', 'ok'); });
      })
      .catch(function (err) {
        $('lg-msg').textContent = err.message || 'Gagal masuk.';
        btn.disabled = false;
      });
    return false;
  };

  window.logout = function (silent) {
    localStorage.removeItem(LS.token); localStorage.removeItem(LS.user);
    S.token = null; S.user = null;
    S.demo = false; S.liveFailed = false;
    if (window.REPORTMOCK) window.REPORTMOCK.disable();
    showLogin(); $('lg-msg').textContent = ''; $('lg-btn').disabled = false;
    renderDemoBadge();
    if (!silent) toast('Anda telah keluar.');
  };

  /* Masuk ke mode DEMO — pakai data contoh tanpa backend. */
  window.enterDemo = function () {
    if(!window.__operationsWorkspace)return;
    S.demo = true; S.liveFailed = false;
    if (window.REPORTMOCK) window.REPORTMOCK.enable();
    S.token = 'demo-token';
    S.user = { name: 'Owner Grup (Demo)', email: 'demo@tokokartini.com', role: 'Owner Grup', companyId: window.__COMPANY_ID__ || 'demo' };
    $('lg-msg').textContent = '';
    startApp();
    toast('Mode demo aktif — menampilkan data contoh.', 'ok');
  };

  /* Dipanggil dari tombol pada pesan galat jaringan. */
  window.useDemoFromError = function () { window.enterDemo(); };

  async function startAuthorized() {
    const access=await api('admin/business-reports/access');
    const owner=access.grant?.role==='OWNER';
    const link=$('br-report-link');
    if(link)link.hidden=!owner;
    if(!window.__operationsWorkspace&&!owner){
      showLogin();
      $('lg-msg').textContent='Pusat Laporan hanya tersedia untuk Owner.';
      $('lg-btn').disabled=false;
      return false;
    }
    if(owner&&!window.__operationsWorkspace&&!new URLSearchParams(location.search).has('live')){location.replace('/outlets');return false;}
    startApp();
    return true;
  }

  function startApp() {
    var u = S.user || {};
    $('u-name').textContent = u.name || 'Admin';
    $('u-role').textContent = u.role || '';
    $('u-avatar').textContent = initials(u.name);
    if ($('ver')) $('ver').textContent = window.__APP_VERSION__ || '1.0.0';
    if ($('ver2')) $('ver2').textContent = window.__APP_VERSION__ || '1.0.0';
    renderDemoBadge();
    showApp();
    if($('br-report-link'))$('br-report-link').href=S.demo?'/?demo=1&page=multibisnis':'/?page=multibisnis';
    var reportOnly=!S.demo&&u.role==='REPORT_USER';
    document.querySelectorAll('.nav-item').forEach(function(el){
      if(el.id==='br-report-link'&&el.hidden){el.style.display='none';return;}
      el.style.display=reportOnly&&el.id!=='br-report-link'&&el.getAttribute('data-nav')!=='multibisnis'?'none':'';
    });
    // Mode demo mendarat di Laporan Multibisnis (kecuali deep-link ?page= diminta).
    var last = S.demo ? (S._startPage || 'multibisnis') : (localStorage.getItem(LS.nav) || 'ringkasan');
    goto(TITLES[last] ? last : 'ringkasan');
  }

  /* ==================== BOOT ==================== */
  window.__pages = window.__pages || {};
  window.__after = window.__after || {};

  function boot() {
    S.to = todayISO(); S.from = addDays(S.to, -6); S.range = 7;

    // Deep-link: ?page=<nama> dan ?demo=1
    var qp = {};
    try {
      location.search.replace(/^\?/, '').split('&').forEach(function (kv) {
        if (!kv) return; var i = kv.indexOf('=');
        qp[decodeURIComponent(i >= 0 ? kv.slice(0, i) : kv)] = i >= 0 ? decodeURIComponent(kv.slice(i + 1)) : '';
      });
    } catch (e) {}
    if (qp.page && TITLES[qp.page]) { S._startPage = qp.page; try { localStorage.setItem(LS.nav, qp.page); } catch (e) {} }

    // ?demo=1 langsung membuka mode demo (berguna untuk pratinjau/verifikasi).
    if (window.__operationsWorkspace && String(qp.demo) === '1') { window.enterDemo(); return; }

    var tok = null, usr = null;
    try { tok = localStorage.getItem(LS.token); usr = JSON.parse(localStorage.getItem(LS.user) || 'null'); } catch (e) {}
    if (tok && usr) {
      S.token = tok; S.user = usr;
      api('admin/me').then(function (me) { S.user={...S.user,...me}; return startAuthorized(); })
        .catch(function () { logout(true); toast('Sesi berakhir, silakan masuk lagi.', 'warn'); });
    } else {
      showLogin();
    }
  }

  window.goto = goto; window.reload = reload; window.setRange = setRange; window.setDate = setDate;
  window.openNav = openNav; window.closeNav = closeNav;
  window.__api = api; window.__japi = japi; window.__S = S; window.__CID = CID;
  window.__hbars = hbars; window.__kpi = kpi; window.__IC = IC; window.__donut = donut;
  window.__table = table; window.__state = stateBox; window.__loading = loadingBox;
  window.__vbars = vbars; window.__rangeBar = rangeBar; window.__rp = rp; window.__rpK = rpK;
  window.__fmt = fmt; window.__fmt1 = fmt1; window.__esc = esc; window.__attStatus = attBadge;
  window.__attBadge = attBadge; window.__attLabel = attLabel; window.__badge = badge;
  window.__shiftStatus = shiftStatus; window.__timeOf = timeOf; window.__dateOf = dateOf;
  window.__dayName = dayName; window.__durMin = durMin; window.__toast = toast; window.__pct = pct;
  window.__initials = initials; window.__avColor = avColor; window.__pagehead = pagehead;
  window.__exportCSV = exportCSV; window.__ICON = IC;
  window.__isDemo = isDemo; window.__mockApi = mockApi; window.__renderDemoBadge = renderDemoBadge;

  /* Tunggu seluruh skrip (termasuk pages.js) selesai dimuat baru boot. */
  window.addEventListener('load', function () { boot(); });
})();
