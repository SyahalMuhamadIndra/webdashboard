/* Owner executive reporting: read-only views; data entry lives in owner-settings. */
window.OwnerConsole=(()=>{
 const api='https://api.simaung.com/api/admin/business-reports';
 const esc=x=>String(x??'').replace(/\btk kartini\b/gi,'Toko Kartini').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const num=new Intl.NumberFormat('id-ID',{maximumFractionDigits:1});
 const money=x=>x===null||x===undefined?'Belum tersedia':'Rp '+num.format(Number(x));
 const labels={retail:'Retail',fnb:'F&B',kosan:'Kosan',penginapan:'Penginapan'};
 const band=(p)=>p===null?'neutral':p<50?'crit':p<80?'warn':'ok';
 const badge=(label,tone='neutral')=>'<span class="pill '+tone+'">'+esc(label)+'</span>';
 const date=x=>x?new Date(x).toLocaleString('id-ID',{timeZone:'Asia/Jakarta',dateStyle:'medium',timeStyle:'short'})+' WIB':'Belum tercatat';
 const table=(heads,rows)=>'<div class="tbl-wrap"><table class="tbl"><thead><tr>'+heads.map(x=>'<th>'+esc(x)+'</th>').join('')+'</tr></thead><tbody>'+rows.join('')+'</tbody></table></div>';
 const row=xs=>'<tr>'+xs.map(x=>'<td>'+x+'</td>').join('')+'</tr>';
 const panel=(id,title,sub,body)=>'<section class="panel ex-section" id="'+id+'"><header class="panel-head"><div><h2 class="panel-title">'+title+'</h2><p class="panel-sub">'+sub+'</p></div></header><div class="panel-body">'+body+'</div></section>';
 const params=s=>{const q=new URLSearchParams({year:s.year,outlet:s.outlets});if(s.mode==='month')q.set('month',s.month);return q;};
 let current=null,generation=0;
 async function get(path){const r=await fetch(api+path,{headers:{Authorization:'Bearer '+localStorage.getItem('tk_report_token')}});if(r.status===401||r.status===403){location.replace('/');throw Error('Sesi atau izin tidak berlaku.');}const d=await r.json();if(!r.ok)throw Error(d.message||'Data belum tersedia.');return d;}
 function dummy(s){
  const units=[['tk-kartini','Toko Kartini','retail'],['maja-koffie','Maja Koffie','fnb'],['sweet-escape','Sweet Escape','fnb'],['cherry-bakes-house','Cherry Bakes House','fnb'],['rm-sindang-hurip','RM Sindang Hurip','fnb'],['mitra-water','Mitra Water','retail'],['sikecut-manis','Sikecut Manis','fnb'],['mitra-kost','Mitra Kost','kosan'],['river-inn','River Inn','penginapan']];
  const f=s.mode==='year'?12:1,ratios=[.42,.65,.9,1.1,.76,.85,.56,.95,.83];
  const outlets=units.map(([slug,name,unit],i)=>{const target=(50000000+i*10000000)*f,actual=target*ratios[i],property=i>6;return {key:'demo-'+slug,slug,id:property?null:'demo-'+i,name,unit,target,actual,previousActual:actual/.95,change:-5,receipts:Math.round(actual/75000),percent:ratios[i]*100,gap:Math.max(0,target-actual),band:band(ratios[i]*100),label:ratios[i]<.5?'Kurang':ratios[i]<.8?'Ideal':'Aman',pace:ratios[i]*150,expectedToDate:target/1.5,targetMonths:f,expectedMonths:f,cogs:property?null:actual*.62,grossProfit:property?null:actual*.36,netRevenue:actual*.98,costWarning:i===1?3:0,lastActivity:new Date().toISOString(),receivedReviewed:actual*.5,settlementsReviewed:12,unpaidBills:property?4000000:0,overdueBills:property?1000000:0,dataStatus:'Data dummy demonstrasi'};}).filter(o=>s.outlets==='all'||s.outlets===o.slug);
  const actual=outlets.reduce((n,r)=>n+r.actual,0),target=outlets.reduce((n,r)=>n+r.target,0);
  return {accounting:s.outlets==='all'?{income:{totalRevenue:actual*.98,totalExpenses:actual*.8,netIncome:actual*.18,revenueRows:[{code:'4000',name:'Pendapatan Dummy',amount:actual*.98}],expenseRows:[{code:'5000',name:'Beban Dummy',amount:actual*.8}]},balanced:true,journalCount:45,scope:'Dummy seluruh perusahaan'}:null,outlets,totals:{actual,target,percent:actual/target*100,receivedReviewed:actual*.5,unpaidBills:outlets.reduce((n,r)=>n+r.unpaidBills,0)},calculatedAt:new Date().toISOString(),period:{year:s.year,month:s.mode==='month'?s.month:null,start:s.year+'-'+String(s.mode==='year'?1:s.month).padStart(2,'0')+'-01',end:(s.mode==='year'||s.month===12?s.year+1:s.year)+'-'+String(s.mode==='year'||s.month===12?1:s.month+1).padStart(2,'0')+'-01',elapsed:.66},alerts:outlets.filter(o=>o.percent<80).map(o=>({name:o.name,outlet:o.key,severity:o.band,title:'Target belum tercapai',detail:'Evaluasi transaksi, rata-rata belanja dan jam operasional.',kind:'target'})),actions:[{id:'demo-action',outlet:outlets[0]?.key,title:'Periksa margin dan biaya bahan',assignee:'Manajer Demo',due_on:'2026-11-25',status:'IN_PROGRESS',evidence:'',version:1}],closures:[],limitations:['Seluruh nilai dan penanggung jawab pada demo adalah dummy.','Laba kotor belum dikurangi beban operasional.','Settlement bukan saldo bank langsung.']};
 }
 function render(d,s,hero,root,demo){
  current={d,s:{...s},demo};
  const t=d.totals;
  hero.innerHTML=[['OMZET OPERASIONAL',money(t.actual),'POS lunas + penerimaan properti'],['TARGET OUTLET',t.percent===null?'Belum lengkap':money(t.target),'Jumlah target outlet periode terpilih'],['PENCAPAIAN',t.percent===null?'Belum dinilai':num.format(t.percent)+'%',t.percent===null?'Isi target di ruang pengelolaan':t.percent>=100?'Target tercapai':t.percent>=80?'Aman · target belum 100%':t.percent>=50?'Ideal':'Kurang'],['PERLU PERHATIAN',String(d.alerts.length),'Isu data, target, biaya dan tagihan']].map(([a,b,c])=>'<div class="kpi"><div class="kpi-label">'+a+'</div><div class="kpi-value">'+esc(b)+'</div><div class="kpi-meta">'+esc(c)+'</div></div>').join('');
  const performance=table(['Outlet / bisnis','Omzet lunas','Periode sebelumnya*','Target','Pencapaian','Laju waktu','Kekurangan','Bukti'],d.outlets.map(o=>row([
   '<b>'+esc(o.name)+'</b><div class="panel-sub">'+labels[o.unit]+'</div>',money(o.actual),money(o.previousActual)+(o.change===null||o.change===undefined?'':'<div class="panel-sub">'+num.format(o.change)+'%</div>'),o.percent===null?'Belum lengkap ('+o.targetMonths+'/'+o.expectedMonths+' bulan)':money(o.target),o.percent===null?badge('Belum dinilai'):badge(num.format(o.percent)+'% · '+o.label,band(o.percent))+'<progress class="ex-progress '+band(o.percent)+'" max="100" value="'+Math.min(100,o.percent)+'" aria-label="Pencapaian '+esc(o.name)+'"></progress><div class="panel-sub">'+(o.percent>=100?'Target tercapai':'Belum 100%')+'</div>',
   o.pace===null?'—':num.format(o.pace)+'% dari laju waktu<div class="panel-sub">Target s.d. tanggal ini '+money(o.expectedToDate)+'</div>',o.gap===null?'—':money(o.gap),'<button class="btn-ghost ex-evidence" data-key="'+esc(o.key)+'">Lihat nota</button>'
  ])));
  const finance=table(['Outlet','Pendapatan sebelum pajak','HPP tercatat','Laba kotor*','Settlement diperiksa*','Tagihan belum dibayar'],d.outlets.map(o=>row([esc(o.name),money(o.netRevenue),money(o.cogs)+(o.costWarning?'<div class="panel-sub">'+o.costWarning+' nota HPP nol perlu diperiksa</div>':''),money(o.grossProfit),o.settlementsReviewed?money(o.receivedReviewed):'Belum diperiksa',money(o.unpaidBills)])));
  const alerts=d.alerts.length?d.alerts.map(a=>'<article class="ex-alert"><div>'+badge(a.severity==='crit'?'Prioritas tinggi':'Periksa',a.severity)+'</div><div><b>'+esc(a.name)+' · '+esc(a.title)+'</b><p>'+esc(a.detail)+'</p></div></article>').join(''):'<p>Tidak ada peringatan terukur pada cakupan ini. Tetap periksa kelengkapan sumber data.</p>';
  const actions=d.actions.length?table(['Tindak lanjut','PIC','Tenggat','Status','Bukti'],d.actions.map(a=>row([esc(a.title),esc(a.assignee),esc(a.due_on)+(a.status!=='DONE'&&a.due_on<new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())?'<div>'+badge('Lewat tenggat','crit')+'</div>':''),badge({OPEN:'Terbuka',IN_PROGRESS:'Dikerjakan',DONE:'Selesai'}[a.status]||a.status,a.status==='DONE'?'ok':'warn'),esc(a.evidence||'Belum ada bukti')]))):'<p>Belum ada penugasan tercatat. Pencatatan dilakukan di ruang pengelolaan.</p>';
  const quality=table(['Outlet','Aktivitas terakhir pada periode','Kondisi data'],d.outlets.map(o=>row([esc(o.name),date(o.lastActivity),esc(o.dataStatus)])));
  root.innerHTML='<div class="ex-toolbar"><span>'+badge(demo?'DEMO · Data dummy':'OPERASIONAL AKTIF','neutral')+' Dihitung '+esc(date(d.calculatedAt))+'</span><div><button class="btn-ghost" id="ex-export">Ekspor CSV</button> <button class="btn-ghost" id="ex-print">Cetak / PDF</button></div></div><nav class="ex-nav" aria-label="Bagian laporan"><a href="#ex-performance">Kinerja outlet</a><a href="#ex-finance">Keuangan</a><a href="#ex-alerts">Peringatan</a><a href="#ex-quality">Kualitas data</a><a href="#ex-closure">Laporan final</a></nav>'+
   panel('ex-performance','Kinerja & Target per Outlet','*Periode berjalan dibanding tanggal kalender setara sebelumnya; periode selesai dibanding satu periode penuh. Merah <50% · Ideal kuning 50–<80% · Aman hijau ≥80%. Target baru tercapai pada 100%. Laju waktu memakai pembagian rata kalender; bukan prediksi musiman.',performance)+
   panel('ex-finance','Keuangan yang Dapat Ditelusuri','*Laba kotor belum dikurangi gaji, sewa dan beban lainnya. Settlement adalah penerimaan yang telah ditinjau secara internal; bukan saldo rekening.',finance+accountingHTML(d.accounting)+'<p class="ex-note">Saldo kas/bank langsung dan proyeksi kewajiban pemasok belum tersedia. Angka tersebut tidak diestimasi dari omzet.</p>')+
   panel('ex-alerts','Peringatan & Tindak Lanjut','Peringatan berasal dari angka dan kondisi yang terukur. Penugasan dicatat terpisah dari halaman laporan.',alerts+'<h3>Tugas & Penanggung Jawab</h3>'+actions)+
   panel('ex-unit-details','Rincian Retail, F&B & Properti','Produk, bahan, dapur, selisih kas dan properti mengikuti cakupan outlet. Stok menampilkan kondisi saat ini.', '<button class="btn-ghost" id="ex-load-details">Muat rincian operasional</button><div id="ex-unit-result"></div>')+
   panel('ex-quality','Kelengkapan & Sumber Data','Aktivitas terakhir bukan jaminan seluruh transaksi sudah terkirim. Status koneksi outlet tidak disimpulkan dari tidak adanya transaksi.',quality+'<ul>'+d.limitations.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul>')+
   panel('ex-closure','Arsip Laporan Bulanan','Snapshot ringkasan per jenis bisnis yang disahkan tetap tersimpan sebagai versi. Angka operasional aktif dapat berubah; snapshot tidak mengunci transaksi sumber.',d.closures.length?table(['Bulan','Versi snapshot','Disahkan','Ringkasan tersimpan'],d.closures.map(v=>row([esc(v.month),String(v.version),date(v.approved_at),'<details><summary>Lihat versi tersimpan</summary>'+table(['Jenis bisnis','Omzet','Transaksi','Target jenis bisnis'],(v.report||[]).map(r=>row([esc(labels[r.unit]||r.unit),money(r.actual),esc(r.transactions),money(r.target)])))+'</details>']))):'<p>Belum ada snapshot disahkan untuk periode ini. Data yang ditampilkan masih laporan operasional.</p>')+
   '<div id="ex-detail" aria-live="polite"></div>';
  document.getElementById('ex-export').onclick=()=>exportCSV(d);
  document.getElementById('ex-print').onclick=()=>window.print();
  document.getElementById('ex-load-details').onclick=()=>details(d,s,demo);
  root.querySelectorAll('.ex-evidence').forEach(btn=>btn.onclick=()=>evidence(d.outlets.find(o=>o.key===btn.dataset.key),d.period,demo));
 }
 function accountingHTML(a){
  if(!a)return '<h3>Jurnal Perusahaan</h3><p class="ex-note">Belum ada jurnal posted yang dapat digunakan, atau filter sedang memilih satu outlet. Laba bersih tidak dihitung dari omzet POS.</p>';
  return '<h3>Laba Rugi Jurnal Perusahaan</h3><p class="panel-sub">'+esc(a.scope)+' · '+a.journalCount+' entri posted · '+(a.balanced?'Debit / kredit seimbang':'PERINGATAN: debit / kredit tidak seimbang')+'</p>'+table(['Pendapatan jurnal','Beban jurnal','Hasil bersih jurnal'],[row([money(a.income.totalRevenue),money(a.income.totalExpenses),money(a.income.netIncome)])])+'<details><summary>Rincian akun pendapatan dan beban</summary>'+table(['Kode akun','Nama','Nilai'],[...a.income.revenueRows,...a.income.expenseRows].map(x=>row([esc(x.code),esc(x.name),money(x.amount)])))+'</details>';
 }
 async function details(d,s,demo){
  const box=document.getElementById('ex-unit-result'),button=document.getElementById('ex-load-details');button.disabled=true;box.textContent='Memuat rincian…';
  const renderSection=(title,heads,rows,empty='Belum ada data tercatat untuk cakupan ini.')=>'<h3>'+title+'</h3>'+(rows===null?'<p>Data sumber ini belum dapat dimuat.</p>':rows.length?table(heads,rows):'<p>'+empty+'</p>');
  try{
   const q=new URLSearchParams({year:s.year,unit:'all',daily:'1',alerts:'1',breakdown:'1'});if(s.mode==='month')q.set('month',s.month);
   const source=demo?{products:[{branch_id:d.outlets[0]?.id,branch:d.outlets[0]?.name,product:'Produk Demo',quantity:50,item_total:2500000,item_cost:1500000,no_cost:0}],wasteMetrics:[],kitchenMetrics:[],stockSignals:[],cashSignals:[],propertyMetrics:[],shifts:[],paymentTotals:[]}:await get('?'+q);
   if(current?.d!==d||!box.isConnected)return;
   const matches=r=>d.outlets.some(o=>o.id&&o.id===r.branch_id||!o.id&&r.property===o.name&&r.unit===o.unit);
   const filtered=key=>source[key]===null?null:(source[key]||[]).filter(matches);
   const products=filtered('products'),waste=filtered('wasteMetrics'),kitchen=filtered('kitchenMetrics'),stocks=filtered('stockSignals'),cash=filtered('cashSignals'),properties=filtered('propertyMetrics'),shifts=filtered('shifts'),payments=filtered('paymentTotals');
   box.innerHTML=renderSection('Produk & Margin Tercatat (maks. 100 produk)', ['Outlet','Produk','Jumlah','Nilai item*','Biaya item*','Catatan HPP'],products?.slice(0,100).map(r=>row([esc(r.branch),esc(r.product),num.format(r.quantity),money(r.item_total),money(r.item_cost),r.no_cost?esc(r.no_cost)+' item tanpa biaya':'Biaya tercatat']))??null)+
    '<p class="panel-sub">*Nilai item dan biaya belum tentu mencakup pembagian diskon tingkat nota; gunakan laba kotor nota untuk ringkasan keuangan.</p>'+
    renderSection('Bahan Terbuang', ['Outlet','Bahan','Jumlah','Biaya'],waste?.map(r=>row([esc(r.branch),esc(r.material),num.format(r.quantity)+' '+esc(r.stock_unit),money(r.waste_cost)]))??null)+
    renderSection('Waktu Pelayanan Dapur', ['Outlet','Tipe','Tiket','Belum selesai','Rata-rata siap'],kitchen?.map(r=>row([esc(r.branch),esc(r.kind),esc(r.tickets),esc(r.open),r.mean_ready===null?'Belum terukur':num.format(r.mean_ready)+' menit ('+r.timed+' tiket)']))??null)+
    renderSection('Stok Perlu Perhatian (kondisi saat ini; sumber maks. 100)', ['Outlet','Barang / bahan','Saldo','Minimum'],stocks?.map(r=>row([esc(r.location),esc(r.name),num.format(r.balance)+' '+esc(r.stock_unit),num.format(r.minimum)]))??null)+
    renderSection('Selisih Kas Shift (sumber maks. 100)', ['Outlet','Tanggal','Ekspektasi','Dihitung','Selisih'],cash?.map(r=>row([esc(r.location),esc(r.day),money(r.expected),money(r.counted),money(r.difference)]))??null)+
    renderSection('Kasir & Shift', ['Outlet','Kasir','Buka shift','Nota','Omzet','Diskon','Void / Refund'],shifts?.map(r=>row([esc(r.branch),esc(r.cashier),esc(r.shift_opened||'Tidak tercatat'),esc(r.receipts),money(r.sales),money(r.discounts),esc(r.voids)+' / '+esc(r.refunds)]))??null)+
    renderSection('Metode Pembayaran Tercatat', ['Outlet','Metode','Nilai'],payments?.map(r=>row([esc(r.branch),esc(r.method),money(r.amount)]))??null)+
    renderSection('Kosan & Penginapan', ['Properti','Kamar aktif','Kamar terisi saat ini','Tagihan belum lunas','Deposit dipegang*','Kontrak berakhir dalam periode'],properties?.map(r=>row([esc(r.property),esc(r.active_rooms),esc(r.occupied_rooms),money(r.unpaid_amount),money(r.held_deposit),esc(r.ending)]))??null)+
    '<p class="panel-sub">*Deposit bukan omzet. Kamar terisi mengikuti definisi operasional sumber, bukan persentase okupansi historis. Tarif rata-rata kamar dan pendapatan per malam belum dihitung tanpa verifikasi malam inap.</p>';
  }catch(e){if(current?.d===d)box.textContent=e.message;}finally{button.disabled=false;}
 }
 function exportCSV(d){
  const cell=x=>'"'+String(x??'').replace(/^[=+@\-\t\r]/,"'").replace(/"/g,'""')+'"';
  const rows=[['Sumber','Operasional aktif','Dihitung',d.calculatedAt],['Periode',d.period.start,d.period.end],['Outlet','Omzet','Target lengkap','Pencapaian %','Kekurangan','HPP','Laba kotor','Settlement diperiksa','Tagihan belum dibayar'],...d.outlets.map(o=>[o.name,o.actual,o.percent===null?'':o.target,o.percent,o.gap,o.cogs,o.grossProfit,o.receivedReviewed,o.unpaidBills]),[],['Catatan',...d.limitations]];
  const blob=new Blob(['\uFEFF'+rows.map(r=>r.map(cell).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Simaung-Owner-'+d.period.start+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 let evidenceGeneration=0;
 async function evidence(o,period,demo,page=1){
  const box=document.getElementById('ex-detail');if(!box)return;const id=++evidenceGeneration;
  box.innerHTML=panel('ex-evidence','Bukti '+esc(o.name),'Daftar nota dan penerimaan; status void/refund tetap ditampilkan.','Memuat…');box.scrollIntoView({behavior:'smooth',block:'start'});
  try{
   const q=new URLSearchParams({unit:o.unit,location:o.id||'property:'+o.name,from:period.start,to:period.end,page});
   const d=demo?{items:[{reference:'DEMO-001',date:period.start,location:o.name,cashier:'Kasir Demo',amount:150000,status:'PAID'}],hasNext:false}:await get('/evidence?'+q);
   if(id!==evidenceGeneration||!box.isConnected)return;
   box.innerHTML=panel('ex-evidence','Bukti '+esc(o.name),'Halaman '+page+' · maksimal 50 baris per halaman.',d.items.length?table(['Referensi','Tanggal','Lokasi','Kasir','Nilai','Status'],d.items.map(r=>row([esc(r.reference),esc(r.date),esc(r.location),esc(r.cashier||'—'),money(r.amount),esc(r.status)]))):'<p>Belum ada bukti tercatat pada cakupan ini.</p>');
   const nav=document.createElement('div');nav.className='ex-toolbar';
   for(const [label,p,show] of [['Sebelumnya',page-1,page>1],['Berikutnya',page+1,d.hasNext]])if(show){const b=document.createElement('button');b.className='btn-ghost';b.textContent=label;b.onclick=()=>evidence(o,period,demo,p);nav.append(b);}box.append(nav);
  }catch(e){if(id===evidenceGeneration)box.textContent=e.message;}
 }
 async function load(s,hero,root,demo){
  const id=++generation;
  try{const d=demo?dummy(s):await get('/executive?'+params(s));if(id!==generation)return;render(d,s,hero,root,demo);}
  catch(e){if(id!==generation)return;hero.innerHTML='<p>Ringkasan belum tersedia</p>';root.innerHTML='<p class="ex-note">'+esc(e.message)+'</p>';}
 }
 return {load,cancel:()=>{generation++;evidenceGeneration++;},analysis:async(s,demo)=>demo?'CONTOH DEMO · Evaluasi pencapaian setiap outlet terhadap target penuh dan laju waktu. HPP nol harus diperiksa sebelum menilai margin. Penyebab operasional memerlukan verifikasi pengelola.':(await get('/executive/analysis?'+params(s))).analysis};
})();
